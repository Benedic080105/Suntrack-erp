<?php
/**
 * SunTrack ERP — Subcontractor portal.
 *
 * The same field portal as the technicians (technician/index.php): Dashboard
 * with GPS, Active Job and Time In / Out, My Assignments, Service Requests,
 * Job Details, Site Map, Installation, Maintenance, Work Reports, Job History,
 * Availability and Settings. middleware/technician.php puts the subcontractor
 * session into field mode, so every screen shows only the jobs the company
 * accepted. On top: new job offers from SunTrack (accept / decline), and
 * "Submit for Inspection" in place of "Complete Job" — SunTrack approves.
 */
require __DIR__ . '/../technician/index.php';
