<?php
require_once __DIR__ . '/config/config.php';

if (is_logged_in()) {
    header('Location: ' . redirect_path_for_role(current_role()));
    exit;
}

$token = csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SunTrack ERP — Create Client Account</title>
<script src="<?= APP_BASE_URL ?>/assets/vendor/tailwind/tailwind.js"></script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/vendor/fontawesome/css/all.min.css">
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-password.js"></script>
<link href="<?= APP_BASE_URL ?>/assets/vendor/inter/inter.css" rel="stylesheet">
<script>
  tailwind.config = { theme: { extend: {
    colors: { suntrackDark: '#0b1329', suntrackNav: '#0f1934', suntrackOrange: '#f97316' },
    fontFamily: { sans: ['Inter','sans-serif'] }
  }}}
</script>
<style>body{font-family:'Inter',sans-serif;}</style>
</head>
<body class="bg-suntrackDark min-h-screen flex items-center justify-center p-4">

  <div class="w-full max-w-lg">
    <div class="text-center mb-6">
      <div class="inline-flex items-center justify-center h-14 w-14 rounded-2xl bg-suntrackOrange shadow-lg shadow-orange-600/30 mb-4">
        <i class="fas fa-solar-panel text-white text-2xl"></i>
      </div>
      <h1 class="text-2xl font-extrabold text-white">Create Your Client Account</h1>
      <p class="text-slate-400 text-sm mt-1">Monitor your solar system with SunTrack</p>
    </div>

    <div class="bg-suntrackNav border border-slate-800/60 rounded-2xl p-8 shadow-xl">
      <div id="reg-error" class="hidden bg-red-500/10 border border-red-500/30 text-red-400 text-sm rounded-xl px-4 py-3 mb-4"></div>
      <div id="reg-success" class="hidden bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-sm rounded-xl px-4 py-3 mb-4"></div>

      <form id="register-form" class="space-y-4">
        <div>
          <label class="block text-slate-300 text-sm font-semibold mb-1.5">Full Name</label>
          <input type="text" id="full_name" required
                 class="w-full rounded-xl bg-slate-900/60 border border-slate-700 text-white text-sm px-4 py-3 focus:outline-none focus:ring-2 focus:ring-suntrackOrange">
        </div>
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block text-slate-300 text-sm font-semibold mb-1.5">Email</label>
            <input type="email" id="email" required autocomplete="username"
                   class="w-full rounded-xl bg-slate-900/60 border border-slate-700 text-white text-sm px-4 py-3 focus:outline-none focus:ring-2 focus:ring-suntrackOrange">
          </div>
          <div>
            <label class="block text-slate-300 text-sm font-semibold mb-1.5">Phone</label>
            <input type="text" id="phone" required
                   class="w-full rounded-xl bg-slate-900/60 border border-slate-700 text-white text-sm px-4 py-3 focus:outline-none focus:ring-2 focus:ring-suntrackOrange">
          </div>
        </div>
        <div>
          <label class="block text-slate-300 text-sm font-semibold mb-1.5">Address</label>
          <input type="text" id="address" required
                 class="w-full rounded-xl bg-slate-900/60 border border-slate-700 text-white text-sm px-4 py-3 focus:outline-none focus:ring-2 focus:ring-suntrackOrange">
        </div>
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block text-slate-300 text-sm font-semibold mb-1.5">City</label>
            <input type="text" id="city" required
                   class="w-full rounded-xl bg-slate-900/60 border border-slate-700 text-white text-sm px-4 py-3 focus:outline-none focus:ring-2 focus:ring-suntrackOrange">
          </div>
          <div>
            <label class="block text-slate-300 text-sm font-semibold mb-1.5">Province</label>
            <input type="text" id="province"
                   class="w-full rounded-xl bg-slate-900/60 border border-slate-700 text-white text-sm px-4 py-3 focus:outline-none focus:ring-2 focus:ring-suntrackOrange">
          </div>
        </div>
        <div>
          <label class="block text-slate-300 text-sm font-semibold mb-1.5">Password</label>
          <input type="password" id="password" required minlength="8" autocomplete="new-password"
                 class="w-full rounded-xl bg-slate-900/60 border border-slate-700 text-white text-sm px-4 py-3 focus:outline-none focus:ring-2 focus:ring-suntrackOrange">
          <p class="text-slate-500 text-xs mt-1">At least 8 characters.</p>
        </div>

        <div class="bg-slate-900/50 border border-slate-700 rounded-xl p-4">
          <label class="flex items-start gap-3 cursor-pointer">
            <input type="checkbox" id="agree-privacy" required
                   class="mt-0.5 h-4 w-4 rounded border-slate-600 bg-slate-800 text-suntrackOrange focus:ring-suntrackOrange focus:ring-offset-0">
            <span class="text-slate-300 text-xs leading-relaxed">
              I have read and agree to the
              <a href="privacy.php" target="_blank" rel="noopener"
                 class="text-suntrackOrange font-semibold hover:underline">Privacy Policy and Cookie Notice</a>.
              I understand how <?= h(APP_NAME) ?> collects and uses my information.
            </span>
          </label>
        </div>

        <button type="submit" id="reg-btn"
                class="w-full bg-suntrackOrange hover:bg-orange-600 text-white font-bold text-sm py-3 rounded-xl shadow-lg shadow-orange-600/20 transition">
          Create Account
        </button>
      </form>

      <p class="text-center text-slate-500 text-xs mt-6">
        Already have an account? <a href="login.php" class="text-suntrackOrange font-semibold hover:underline">Sign in</a>
      </p>
    </div>
  </div>

<script>
const CSRF_TOKEN = <?= json_encode($token) ?>;

document.getElementById('register-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = document.getElementById('reg-btn');
  const errBox = document.getElementById('reg-error');
  const okBox = document.getElementById('reg-success');
  errBox.classList.add('hidden');
  okBox.classList.add('hidden');
  if (!document.getElementById('agree-privacy').checked) {
    errBox.textContent = 'Please read and accept the Privacy Policy to continue.';
    errBox.classList.remove('hidden');
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Creating account...';

  try {
    const res = await fetch('api/auth/register.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        full_name: document.getElementById('full_name').value.trim(),
        email: document.getElementById('email').value.trim(),
        phone: document.getElementById('phone').value.trim(),
        address: document.getElementById('address').value.trim(),
        city: document.getElementById('city').value.trim(),
        province: document.getElementById('province').value.trim(),
        password: document.getElementById('password').value,
        accept_privacy: document.getElementById('agree-privacy').checked,
        csrf_token: CSRF_TOKEN
      })
    });
    const data = await res.json();

    if (!data.success) {
      errBox.textContent = data.message || 'Registration failed.';
      errBox.classList.remove('hidden');
      btn.disabled = false;
      btn.textContent = 'Create Account';
      return;
    }

    okBox.textContent = `Account created (${data.data.client_code}). Redirecting to login...`;
    okBox.classList.remove('hidden');
    setTimeout(() => window.location.href = 'login.php', 1500);
  } catch (err) {
    errBox.textContent = 'Network error. Please try again.';
    errBox.classList.remove('hidden');
    btn.disabled = false;
    btn.textContent = 'Create Account';
  }
});
</script>

<?php include ROOT_PATH . '/includes/consent_banner.php'; ?>
</body>
</html>
