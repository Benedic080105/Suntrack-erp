<?php
/**
 * Privacy Policy & Cookie Notice.
 *
 * Reachable without signing in — a technician deciding whether to accept
 * location tracking, or a client deciding whether to register, needs to read
 * this before they have an account.
 */
require_once __DIR__ . '/config/config.php';

$companyName  = setting('company_name', 'NCO Technology Solutions');
$companyEmail = setting('company_email', 'privacy@ncotechsolutions.com');
$version      = privacy_policy_version();
$radius       = geofence_default_radius();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Privacy Policy — <?= h(APP_NAME) ?></title>
<script src="<?= APP_BASE_URL ?>/assets/vendor/tailwind/tailwind.js"></script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/vendor/fontawesome/css/all.min.css">
<link href="<?= APP_BASE_URL ?>/assets/vendor/inter/inter.css" rel="stylesheet">
<script>tailwind.config={theme:{extend:{colors:{navy:'#0f172a',solar:'#f97316'},fontFamily:{sans:['Inter','sans-serif']}}}}</script>
<style>
  body{font-family:'Inter',sans-serif}
  .doc h2{font-size:1.05rem;font-weight:800;color:#0f172a;margin:2rem 0 .6rem}
  .doc h3{font-size:.9rem;font-weight:700;color:#334155;margin:1.2rem 0 .35rem}
  .doc p,.doc li{font-size:.875rem;line-height:1.7;color:#475569}
  .doc ul{list-style:disc;padding-left:1.25rem;margin:.5rem 0}
  .doc table{width:100%;border-collapse:collapse;margin:.75rem 0;font-size:.8rem}
  .doc th{text-align:left;background:#f8fafc;color:#475569;font-weight:700;padding:8px 10px;border:1px solid #e2e8f0}
  .doc td{padding:8px 10px;border:1px solid #e2e8f0;color:#475569;vertical-align:top}
</style>
</head>
<body class="bg-slate-100">

<header class="bg-navy text-white">
  <div class="max-w-4xl mx-auto px-6 py-5 flex items-center justify-between">
    <div class="flex items-center gap-3">
      <div class="h-10 w-10 rounded-xl bg-solar flex items-center justify-center">
        <i class="fas fa-solar-panel text-white"></i>
      </div>
      <div>
        <p class="font-extrabold leading-tight"><?= h(APP_NAME) ?></p>
        <p class="text-[11px] text-slate-400"><?= h($companyName) ?></p>
      </div>
    </div>
    <a href="<?= APP_BASE_URL ?>/login.php" class="text-sm font-semibold text-slate-300 hover:text-solar">
      <i class="fas fa-arrow-left mr-1"></i> Back to sign in
    </a>
  </div>
</header>

<main class="max-w-4xl mx-auto px-6 py-8">
  <div class="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 doc">

    <h1 class="text-2xl font-extrabold text-slate-900">Privacy Policy &amp; Cookie Notice</h1>
    <p class="text-xs text-slate-400 mt-1 mb-6">
      Version <?= h($version) ?> · Last updated <?= date('j F Y') ?> ·
      Governed by the Data Privacy Act of 2012 (Republic Act No. 10173, Philippines)
    </p>

    <div class="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6">
      <p class="text-sm text-amber-900 font-semibold mb-1">
        <i class="fas fa-location-crosshairs mr-1"></i> The short version, for field technicians
      </p>
      <p class="text-[13px] text-amber-800 leading-relaxed">
        SunTrack records your GPS location <strong>only while you have a job active in the field</strong>
        &mdash; from the moment you press Time In until you press Time Out. It is not recorded when you are
        off duty, between jobs, or when the app is closed. The location is used to confirm you were at the
        job site and for nothing else.
      </p>
    </div>

    <h2>1. Who we are</h2>
    <p>
      <?= h($companyName) ?> ("we", "us") operates <?= h(APP_NAME) ?>, an internal enterprise resource
      planning system for solar installation and maintenance work. For the purposes of the Data Privacy
      Act, we are the Personal Information Controller for the data described below.
    </p>
    <p>Questions, requests, or complaints: <a href="mailto:<?= h($companyEmail) ?>" class="text-solar font-semibold"><?= h($companyEmail) ?></a></p>

    <h2>2. What we collect, and why</h2>
    <table>
      <thead>
        <tr><th style="width:26%">Data</th><th style="width:38%">Why we hold it</th><th>Who it applies to</th></tr>
      </thead>
      <tbody>
        <tr>
          <td>Name, email address, phone number</td>
          <td>To create and identify your account and to contact you about work.</td>
          <td>All users</td>
        </tr>
        <tr>
          <td>Password</td>
          <td>Stored only as a one-way hash. We cannot read it, and neither can an administrator.</td>
          <td>All users</td>
        </tr>
        <tr>
          <td>Site address and coordinates</td>
          <td>To route technicians and to define the geofence around a job site.</td>
          <td>Clients</td>
        </tr>
        <tr>
          <td><strong>GPS location</strong> (latitude, longitude, distance from site)</td>
          <td>
            To verify attendance at the job site. Captured at Time In, at Time Out, and roughly every
            <?= (int)setting_int('geofence_ping_seconds', 20) ?> seconds
            <em>while a job is active in the field</em>.
          </td>
          <td>Technicians</td>
        </tr>
        <tr>
          <td>Job, service, and maintenance records</td>
          <td>To deliver and document the work, and to honour warranties.</td>
          <td>Clients, technicians</td>
        </tr>
        <tr>
          <td>Audit log (action, module, time, IP address)</td>
          <td>Security and accountability &mdash; who changed what, and when.</td>
          <td>All users</td>
        </tr>
        <tr>
          <td>Sign-in attempts (email, IP address, time)</td>
          <td>To detect and block password-guessing attacks on accounts.</td>
          <td>All users</td>
        </tr>
      </tbody>
    </table>

    <h2 id="location">3. Location tracking &mdash; the detail</h2>
    <p>This is the most sensitive thing SunTrack does, so it is worth being precise about it.</p>
    <h3>When location IS recorded</h3>
    <ul>
      <li>At the moment you press <strong>Time In</strong> on a job.</li>
      <li>Periodically while that job is in an active field stage &mdash; <em>En route, Arrived, In progress,</em> or <em>Paused</em>.</li>
      <li>At the moment you press <strong>Time Out</strong>.</li>
    </ul>
    <h3>When location is NOT recorded</h3>
    <ul>
      <li>Before Time In and after Time Out.</li>
      <li>When you have no job assigned, or the job is Submitted, Completed, or Cancelled.</li>
      <li>When the SunTrack page is closed. There is no background service and no mobile app daemon.</li>
      <li>On rest days, leave, or outside working hours &mdash; because no job is active.</li>
    </ul>
    <h3>What it is used for</h3>
    <p>
      Confirming that attendance was recorded at the job site, within a radius of
      <?= (int)$radius ?> metres by default (a site may be configured with its own radius). Your
      supervisor and administrators can see the distance between you and the site at each recorded point.
    </p>
    <h3>What it is never used for</h3>
    <ul>
      <li>Tracking you outside working hours or between jobs.</li>
      <li>Sale, sharing, or disclosure to advertisers or data brokers &mdash; we do neither, ever.</li>
      <li>Automated disciplinary decisions. A geofence reading is evidence for a human to weigh, not a verdict.</li>
    </ul>
    <p>
      Your browser will ask for permission before sharing location, and you can revoke it at any time in
      your browser settings. Be aware that refusing it prevents Time In, because attendance cannot then
      be verified &mdash; speak to your supervisor about recording attendance another way.
    </p>

    <h2 id="cookies">4. Cookies</h2>
    <p>SunTrack sets two cookies. Neither is used for advertising, and neither is shared with anyone.</p>
    <table>
      <thead><tr><th style="width:22%">Cookie</th><th style="width:20%">Purpose</th><th style="width:16%">Lifetime</th><th>Type</th></tr></thead>
      <tbody>
        <tr>
          <td><code>PHPSESSID</code></td>
          <td>Keeps you signed in as you move between pages.</td>
          <td>Until you close the browser or sign out</td>
          <td><strong>Strictly necessary.</strong> The system cannot function without it.</td>
        </tr>
        <tr>
          <td><code>suntrack_consent</code></td>
          <td>Remembers your answer to the cookie banner so we stop asking.</td>
          <td>180 days</td>
          <td>Strictly necessary (preference).</td>
        </tr>
      </tbody>
    </table>
    <p>
      We use no analytics, advertising, social-media, or cross-site tracking cookies. Choosing
      "Essential only" on the banner changes nothing about what is stored, because everything we store
      is already essential &mdash; we offer the choice so the record of your preference is honest.
    </p>
    <p class="text-slate-500 text-[13px]">
      Note: some page styling, fonts, and map tiles load from third-party networks
      (Tailwind, Font Awesome, Google Fonts, OpenStreetMap). Those providers may see your IP address
      as a consequence of your browser requesting a file. They receive no SunTrack account data.
    </p>

    <h2>5. Who can see your data</h2>
    <ul>
      <li><strong>You</strong> &mdash; your own records, through your portal.</li>
      <li><strong>Management and Administrators</strong> &mdash; operational records needed to run the work, including attendance and geofence readings.</li>
      <li><strong>Clients</strong> &mdash; only their own systems, jobs, invoices, and service history. A client never sees another client's data, and never sees a technician's location trail.</li>
      <li><strong>Warehouse staff</strong> &mdash; stock and the jobs stock is issued against.</li>
    </ul>
    <p>We do not sell personal data. We do not share it with third parties except where the law requires it.</p>

    <h2>6. How long we keep it</h2>
    <ul>
      <li>Account records: for as long as the account is active, then as required for tax and employment records.</li>
      <li>Job, maintenance, and warranty records: for the life of the installation plus the warranty period.</li>
      <li>Geofence location points and attendance: retained for operational and payroll verification, then reviewed for deletion.</li>
      <li>Sign-in attempt records: automatically deleted after 24 hours.</li>
      <li>Audit logs: retained for security investigation purposes.</li>
    </ul>

    <h2>7. Your rights</h2>
    <p>Under the Data Privacy Act you have the right to be informed, to object, to access, to correct, to erasure or blocking, to damages, to data portability, and to lodge a complaint. To exercise any of these, contact <a href="mailto:<?= h($companyEmail) ?>" class="text-solar font-semibold"><?= h($companyEmail) ?></a>.</p>
    <p>You may also complain to the National Privacy Commission (privacy.gov.ph).</p>

    <h2>8. How we protect it</h2>
    <ul>
      <li>Passwords stored as salted one-way hashes; never recoverable in plain text.</li>
      <li>Role-based access, so each portal can reach only the data its role needs.</li>
      <li>Every change is written to an audit log with the user, action, and IP address.</li>
      <li>Protections against cross-site request forgery, SQL injection, session fixation, and password-guessing attacks.</li>
      <li>Sessions expire automatically after a period of inactivity.</li>
    </ul>
    <p class="text-slate-500 text-[13px]">
      No system is perfectly secure. If you believe your account has been accessed by someone else,
      change your password and tell us immediately.
    </p>

    <h2>9. Changes to this policy</h2>
    <p>
      This policy carries a version number (currently <?= h($version) ?>). When we make a material
      change, the version increments and you will be asked to review and accept it again the next time
      you sign in. We record which version you accepted and when.
    </p>

    <div class="mt-8 pt-6 border-t border-slate-200 flex flex-wrap gap-3">
      <a href="<?= APP_BASE_URL ?>/login.php" class="bg-solar hover:bg-orange-600 text-white text-sm font-bold px-5 py-2.5 rounded-xl">
        Back to sign in
      </a>
      <a href="<?= APP_BASE_URL ?>/register.php" class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-bold px-5 py-2.5 rounded-xl">
        Create a client account
      </a>
    </div>
  </div>

  <p class="text-center text-slate-400 text-xs mt-6">
    &copy; <?= date('Y') ?> <?= h($companyName) ?>. <?= h(APP_NAME) ?> Privacy Policy v<?= h($version) ?>.
  </p>
</main>

<?php include ROOT_PATH . '/includes/consent_banner.php'; ?>
</body>
</html>
