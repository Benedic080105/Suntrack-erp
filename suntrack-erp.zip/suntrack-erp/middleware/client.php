<?php
/**
 * SunTrack ERP — Client portal guard.
 * require_once this at the very top of every /client/*.php page
 * and every API endpoint restricted to the client role.
 */
require_once __DIR__ . '/../config/config.php';

$__is_api = str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/');
require_role(['client'], $__is_api);
