<?php
/**
 * SunTrack ERP — Admin/Management portal guard.
 * require_once this at the very top of every /admin/*.php page
 * and every API endpoint restricted to admin/manager/staff.
 */
require_once __DIR__ . '/../config/config.php';

$__is_api = str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/');
require_role(['admin', 'manager', 'staff'], $__is_api);
