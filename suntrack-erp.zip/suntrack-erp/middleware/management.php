<?php
/**
 * SunTrack ERP — Management portal guard.
 * require_once this at the very top of every /management/*.php page and
 * every API endpoint restricted to Management (manager/staff) only.
 *
 * Deliberately narrower than middleware/admin.php: Admin is a monitoring
 * role and does not belong in the Management portal at all, so an Admin
 * hitting a page here is redirected to their own dashboard rather than
 * just shown a 403 — matching redirect_path_for_role() in middleware/auth.php.
 */
require_once __DIR__ . '/../config/config.php';

$__is_api = str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/');

if (!$__is_api && is_logged_in() && current_role() === 'admin') {
    header('Location: ' . redirect_path_for_role('admin'));
    exit;
}

require_role(['manager', 'staff'], $__is_api);
