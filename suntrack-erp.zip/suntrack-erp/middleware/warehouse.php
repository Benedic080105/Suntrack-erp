<?php
/**
 * SunTrack ERP — Warehouse portal guard.
 * require_once this at the very top of every /warehouse/*.php page
 * and every API endpoint restricted to the warehouse role
 * (admin/manager may also be allowed read access where noted).
 */
require_once __DIR__ . '/../config/config.php';

$__is_api = str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/');
require_role(['warehouse', 'admin', 'manager', 'staff'], $__is_api);
