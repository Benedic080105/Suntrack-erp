<?php
/**
 * SunTrack ERP — Subcontractor portal guard.
 * At the top of every /subcontractor/*.php page and api/subcontractor/*
 * endpoint. Record-level checks (only the company's own assignments) are done
 * in each endpoint via sub_portal_current() and sub_portal_assignment().
 */
require_once __DIR__ . '/../config/config.php';

$__is_api = str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/');
require_role(['subcontractor'], $__is_api);
if ($__is_api) {
    sub_require_schema();
}
