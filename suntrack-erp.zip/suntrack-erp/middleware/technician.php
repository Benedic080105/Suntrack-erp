<?php
/**
 * SunTrack ERP — Technician / Field Operations portal guard.
 * require_once this at the very top of every /technician/*.php page
 * and every API endpoint restricted to the technician role.
 *
 * A subcontractor login is let in too, in field mode: it works its company's
 * accepted jobs with the same tools (see field_mode_enter()).
 */
require_once __DIR__ . '/../config/config.php';

$__is_api = str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/');
field_mode_enter($__is_api);
require_role(['technician'], $__is_api);
