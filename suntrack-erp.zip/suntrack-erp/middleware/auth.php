<?php
/**
 * SunTrack ERP — Core authentication helpers.
 * Included by config.php, so these functions are available everywhere.
 */

/** True if a user is currently logged in. */
function is_logged_in(): bool
{
    return isset($_SESSION['user_id'], $_SESSION['role_key']);
}

/** Get the current session's role key ('admin','manager','staff','technician','client','warehouse'), or null. */
function current_role(): ?string
{
    // Field mode (subcontractor working through the field portal): inside that
    // request the company acts as a technician — see field_mode_enter().
    if (!empty($GLOBALS['__field_sub'])) {
        return 'technician';
    }
    return $_SESSION['role_key'] ?? null;
}

/** The subcontractor company acting in field mode in this request, or null. */
function field_subcontractor(): ?array
{
    return $GLOBALS['__field_sub'] ?? null;
}

/** Get the current session's users.id, or null. */
function current_user_id(): ?int
{
    return $_SESSION['user_id'] ?? null;
}

/**
 * Get the current session's role-specific profile id
 * (clients.id / technicians.id / staff.id), or null for roles without one.
 */
function current_profile_id(): ?int
{
    if (!empty($GLOBALS['__field_sub'])) {
        return (int)$GLOBALS['__field_tech_id']; // the company's field profile (technicians.id)
    }
    return $_SESSION['profile_id'] ?? null;
}

/** Which portal folder a role should land in after login. */
function redirect_path_for_role(string $roleKey): string
{
    return match ($roleKey) {
        'admin'                     => APP_BASE_URL . '/admin/',
        'manager', 'staff'          => APP_BASE_URL . '/management/',
        'technician'                => APP_BASE_URL . '/technician/',
        'client'                    => APP_BASE_URL . '/client/',
        'warehouse'                 => APP_BASE_URL . '/warehouse/',
        'subcontractor'             => APP_BASE_URL . '/subcontractor/',
        default                     => APP_BASE_URL . '/login.php',
    };
}

/**
 * Attempt to log a user in. Returns the user row (with role_key + profile_id) on success,
 * or null on invalid credentials / inactive account.
 *
 * Kept for callers that log in in one step. The login endpoint now uses
 * verify_credentials() + complete_login() so two-step login can sit between.
 */
function attempt_login(string $email, string $password): ?array
{
    $user = verify_credentials($email, $password);
    if ($user) {
        complete_login($user);
    }
    return $user;
}

/**
 * Check email + password WITHOUT signing in. Returns the user row (with
 * profile_id / profile_code resolved) or null for bad credentials or an
 * inactive account.
 */
function verify_credentials(string $email, string $password): ?array
{
    $stmt = db()->prepare(
        'SELECT u.id, u.email, u.password_hash, u.full_name, u.status, r.role_key
         FROM users u
         JOIN roles r ON r.id = u.role_id
         WHERE u.email = :email
         LIMIT 1'
    );
    $stmt->execute([':email' => $email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        return null;
    }

    if ($user['status'] !== 'ACTIVE') {
        return null;
    }

    unset($user['password_hash']);
    return login_resolve_profile($user);
}

/**
 * The same user row as verify_credentials() for an already-verified user id
 * (the second step of two-step login). Null if missing or no longer active.
 */
function verify_credentials_by_id(int $userId): ?array
{
    $stmt = db()->prepare(
        'SELECT u.id, u.email, u.full_name, u.status, r.role_key
         FROM users u JOIN roles r ON r.id = u.role_id
         WHERE u.id = :id LIMIT 1'
    );
    $stmt->execute([':id' => $userId]);
    $user = $stmt->fetch();
    return ($user && $user['status'] === 'ACTIVE') ? login_resolve_profile($user) : null;
}

/** Attach the role-specific profile id (clients / technicians / staff row). */
function login_resolve_profile(array $user): array
{
    $profileId = null;
    switch ($user['role_key']) {
        case 'client':
            $p = db()->prepare('SELECT id, client_code FROM clients WHERE user_id = :uid');
            $p->execute([':uid' => $user['id']]);
            if ($row = $p->fetch()) {
                $profileId = $row['id'];
                $user['profile_code'] = $row['client_code'];
            }
            break;
        case 'technician':
            $p = db()->prepare('SELECT id, technician_code FROM technicians WHERE user_id = :uid');
            $p->execute([':uid' => $user['id']]);
            if ($row = $p->fetch()) {
                $profileId = $row['id'];
                $user['profile_code'] = $row['technician_code'];
            }
            break;
        case 'subcontractor':
            // The company this portal login belongs to (subcontractors.user_id).
            $p = db()->prepare('SELECT id, subcon_code FROM subcontractors WHERE user_id = :uid');
            $p->execute([':uid' => $user['id']]);
            if ($row = $p->fetch()) {
                $profileId = $row['id'];
                $user['profile_code'] = $row['subcon_code'];
            }
            break;
        case 'admin':
        case 'manager':
        case 'staff':
            $p = db()->prepare('SELECT id, staff_code FROM staff WHERE user_id = :uid');
            $p->execute([':uid' => $user['id']]);
            if ($row = $p->fetch()) {
                $profileId = $row['id'];
                $user['profile_code'] = $row['staff_code'];
            }
            break;
    }

    $user['profile_id'] = $profileId;
    return $user;
}

/** Sign in a user whose credentials (and two-step code, if any) were verified. */
function complete_login(array $user): void
{
    // Regenerate session id on privilege change to prevent session fixation.
    session_regenerate_id(true);
    unset($_SESSION['pending_2fa']);

    $_SESSION['user_id']    = (int)$user['id'];
    $_SESSION['role_key']   = $user['role_key'];
    $_SESSION['full_name']  = $user['full_name'];
    $_SESSION['profile_id'] = $user['profile_id'];

    $upd = db()->prepare('UPDATE users SET last_login = NOW() WHERE id = :id');
    $upd->execute([':id' => $user['id']]);

    audit_log('LOGIN', 'auth', (string)$user['id']);
}

/** Destroy the current session (logout). */
function do_logout(): void
{
    if (is_logged_in()) {
        audit_log('LOGOUT', 'auth', (string)current_user_id());
    }
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie('PHPSESSID', '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

/**
 * Require the user to be logged in. Used by page-level middleware (redirects)
 * and API-level middleware (JSON 401) via the $isApi flag.
 */
function require_login(bool $isApi = false): void
{
    if (!is_logged_in()) {
        if ($isApi) {
            json_error('You must be logged in.', 401);
        }
        header('Location: ' . APP_BASE_URL . '/login.php');
        exit;
    }
}

/**
 * Require the current session's role to be one of $allowedRoles.
 */
function require_role(array $allowedRoles, bool $isApi = false): void
{
    require_login($isApi);
    if (!in_array(current_role(), $allowedRoles, true)) {
        if ($isApi) {
            json_error('You are not authorized to access this resource.', 403);
        }
        http_response_code(403);
        die('403 Forbidden — you do not have access to this page.');
    }
}

/**
 * Require the "Management" side (manager/staff). Per the proposal-defense
 * panel's feedback, the Admin role is view & export only — creating,
 * editing, approving, assigning, or issuing/receiving stock is reserved
 * for Management. Always called from an API endpoint context.
 */
function require_management(bool $isApi = true): void
{
    require_login($isApi);
    if (current_role() === 'admin') {
        if ($isApi) {
            json_error('This action is managed by the Management team.', 403);
        }
        http_response_code(403);
        die('This action is managed by the Management team.');
    }
    require_role(['manager', 'staff'], $isApi);
}

/**
 * Require Warehouse-side write access (warehouse staff, or Management).
 * Mirrors require_management() but also allows the dedicated 'warehouse'
 * role, since that portal performs the same stock actions.
 */
function require_warehouse_write(bool $isApi = true): void
{
    require_login($isApi);
    if (current_role() === 'admin') {
        if ($isApi) {
            json_error('This action is managed by the Management team.', 403);
        }
        http_response_code(403);
        die('This action is managed by the Management team.');
    }
    require_role(['warehouse', 'manager', 'staff'], $isApi);
}
