/**
 * SunTrack ERP — inventory QR codes and labels (shared by Warehouse and Management).
 *
 * Needs assets/vendor/qrcode/qrcode.min.js (qrcode-generator, MIT) — the same
 * library the 2FA screen uses. Codes are drawn in the browser as SVG (print)
 * or on a canvas (PNG download), always pure black on white with a quiet zone.
 *
 *   SunTrackQR.svg(text, {margin})          crisp SVG markup of a QR code
 *   SunTrackQR.downloadLabel(label)         save a 50 x 30 mm label as PNG
 *   SunTrackQR.printUrl(base, id, opts)     URL of the printable label sheet
 *   SunTrackQR.openPanel({base, csrf, id, onChanged})
 *                                           the item's QR panel: view / print /
 *                                           download, Generate QR Code, units,
 *                                           unit tracking, quarantine inspection
 *   SunTrackQR.requestKey()                 one key per form, so a double tap
 *                                           or retry is only applied once
 *
 * A label = { title, sku, code, serial, kind: 'product' | 'unit' }. The QR
 * carries `code` only — an identifier, never quantities, prices or clients.
 */
(function (global) {
  'use strict';

  function esc(v) {
    if (v === null || v === undefined || v === '') return '—';
    return String(v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function matrix(text) {
    if (!global.qrcode) throw new Error('QR library not loaded');
    const q = global.qrcode(0, 'M'); // version picked automatically, 15% error correction
    q.addData(String(text));
    q.make();
    return q;
  }

  /** SVG markup; `margin` is the quiet zone in modules (4 = the standard). */
  function svg(text, opts) {
    const margin = (opts && opts.margin != null) ? opts.margin : 4;
    const q = matrix(text);
    const n = q.getModuleCount();
    const size = n + margin * 2;
    let path = '';
    for (let r = 0; r < n; r++) {
      for (let c = 0; c < n; c++) {
        if (q.isDark(r, c)) path += 'M' + (c + margin) + ' ' + (r + margin) + 'h1v1h-1z';
      }
    }
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + size + ' ' + size + '" shape-rendering="crispEdges" '
      + 'role="img" aria-label="QR code ' + esc(text) + '"><rect width="' + size + '" height="' + size + '" fill="#fff"/>'
      + '<path d="' + path + '" fill="#000"/></svg>';
  }

  function wrapLines(ctx, text, maxWidth, maxLines) {
    const words = String(text || '').split(/\s+/).filter(Boolean);
    const lines = [];
    let line = '';
    for (let i = 0; i < words.length; i++) {
      const test = line ? line + ' ' + words[i] : words[i];
      if (ctx.measureText(test).width <= maxWidth || !line) { line = test; continue; }
      lines.push(line);
      line = words[i];
      if (lines.length === maxLines) break;
    }
    if (lines.length < maxLines && line) lines.push(line);
    if (lines.length === maxLines && words.join(' ') !== lines.join(' ')) {
      let last = lines[maxLines - 1];
      while (last.length > 1 && ctx.measureText(last + '…').width > maxWidth) last = last.slice(0, -1);
      lines[maxLines - 1] = last + '…';
    }
    return lines;
  }

  /** A 50 x 30 mm label at 12 px/mm (≈ 305 dpi) on a canvas. */
  function labelCanvas(label) {
    const W = 600, H = 360, pad = 24;
    const canvas = document.createElement('canvas');
    canvas.width = W; canvas.height = H;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);

    // QR: 26 mm square including a 2-module quiet zone; the label's own white
    // padding adds to it.
    const q = matrix(label.code);
    const n = q.getModuleCount();
    const qrBox = H - pad * 2;
    const cell = Math.floor(qrBox / (n + 4));
    const qrSize = cell * (n + 4);
    const ox = pad + Math.floor((qrBox - qrSize) / 2), oy = pad + Math.floor((qrBox - qrSize) / 2);
    ctx.fillStyle = '#000';
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) {
      if (q.isDark(r, c)) ctx.fillRect(ox + (c + 2) * cell, oy + (r + 2) * cell, cell, cell);
    }

    const x = pad + qrBox + 18, maxW = W - x - pad;
    let y = pad + 4;
    ctx.textBaseline = 'top';
    // Brand: sun mark + name
    ctx.beginPath(); ctx.arc(x + 11, y + 11, 9, 0, Math.PI * 2); ctx.fill();
    ctx.font = 'bold 24px Arial, Helvetica, sans-serif';
    ctx.fillText('SunTrack', x + 28, y);
    y += 40;
    ctx.font = 'bold 26px Arial, Helvetica, sans-serif';
    wrapLines(ctx, label.title, maxW, 3).forEach(l => { ctx.fillText(l, x, y); y += 31; });
    y += 8;
    ctx.font = 'bold 28px "Courier New", monospace';
    ctx.fillText(label.sku || '', x, y, maxW);
    y += 36;
    if (label.serial) {
      ctx.font = '22px Arial, Helvetica, sans-serif';
      ctx.fillText((label.kind === 'unit' ? 'S/N ' : 'Lot ') + label.serial, x, y, maxW);
    }
    ctx.font = 'bold 22px "Courier New", monospace';
    ctx.fillText(label.code, x, H - pad - 24, maxW);
    return canvas;
  }

  function downloadLabel(label) {
    const canvas = labelCanvas(label);
    const a = document.createElement('a');
    a.download = 'suntrack-label-' + String(label.code).replace(/[^A-Za-z0-9-]+/g, '_') + '.png';
    a.href = canvas.toDataURL('image/png');
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  /** opts: { units: [unit ids] | 'in_stock', layout: 'thermal' | 'sheet', copies, print } */
  function printUrl(base, id, opts) {
    opts = opts || {};
    const p = new URLSearchParams({ id: String(id), layout: opts.layout || 'thermal' });
    if (opts.units) p.set('units', Array.isArray(opts.units) ? opts.units.join(',') : String(opts.units));
    if (opts.copies) p.set('copies', String(opts.copies));
    if (opts.print !== false) p.set('print', '1');
    return base + '/warehouse/label.php?' + p.toString();
  }

  function requestKey() {
    try { if (global.crypto && crypto.randomUUID) return crypto.randomUUID().replace(/-/g, ''); } catch (e) { /* insecure context */ }
    const b = new Uint8Array(16);
    if (global.crypto && crypto.getRandomValues) crypto.getRandomValues(b);
    else for (let i = 0; i < 16; i++) b[i] = Math.floor(Math.random() * 256);
    return Array.from(b, x => x.toString(16).padStart(2, '0')).join('');
  }

  function notify(msg, isError) {
    if (typeof global.toast === 'function') global.toast(msg, isError);
    else global.alert(msg);
  }

  // ---------------------------------------------------------------------
  // QR panel
  // ---------------------------------------------------------------------
  let panel = null, state = null;

  function ensurePanel() {
    if (panel) return panel;
    panel = document.createElement('div');
    panel.id = 'stqr-panel';
    panel.className = 'hidden fixed inset-0 flex items-center justify-center z-[55] p-4';
    panel.style.background = 'rgba(0,0,0,.45)';
    panel.innerHTML = '<div class="bg-white rounded-2xl w-full max-w-2xl max-h-[92vh] overflow-y-auto shadow-xl">'
      + '<div class="flex items-center justify-between px-5 py-4 border-b border-slate-100">'
      + '<h3 class="font-bold text-slate-900"><i class="fas fa-qrcode text-orange-500 mr-1"></i> <span data-stqr-title>QR Code</span></h3>'
      + '<button type="button" data-stqr-close class="text-slate-400 hover:text-slate-600 px-2" aria-label="Close"><i class="fas fa-xmark"></i></button></div>'
      + '<div data-stqr-body class="p-5 text-sm"></div></div>';
    document.body.appendChild(panel);
    panel.addEventListener('click', e => { if (e.target === panel || e.target.closest('[data-stqr-close]')) closePanel(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && panel && !panel.classList.contains('hidden')) closePanel(); });
    return panel;
  }

  function closePanel() { if (panel) panel.classList.add('hidden'); }

  async function getJ(url) {
    try { const r = await fetch(url, { credentials: 'same-origin' }); return await r.json(); }
    catch (e) { return { success: false, message: 'Network error. Please try again.' }; }
  }
  async function postJ(path, body) {
    try {
      const r = await fetch(state.base + '/api/' + path, {
        method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({}, body, { csrf_token: state.csrf })),
      });
      return await r.json();
    } catch (e) { return { success: false, message: 'Network error. Please try again.' }; }
  }

  async function locked(btn, fn) {
    if (!btn || btn.disabled) return;
    const html = btn.innerHTML;
    btn.disabled = true; btn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i>';
    try { return await fn(); } finally { if (btn.isConnected) { btn.disabled = false; btn.innerHTML = html; } }
  }

  const UNIT_BADGE = {
    IN_STOCK: ['In stock', 'bg-emerald-100 text-emerald-700'], ISSUED: ['Issued', 'bg-orange-100 text-orange-700'],
    QUARANTINE: ['Quarantine', 'bg-amber-100 text-amber-800'], WRITTEN_OFF: ['Written off', 'bg-slate-200 text-slate-600'],
  };
  const COND = { GOOD: 'Good', DAMAGED: 'Damaged', NEEDS_INSPECTION: 'Needs inspection' };
  const btnCls = 'inline-flex items-center justify-center gap-1 rounded-lg text-xs font-bold px-3 py-2';

  function productLabel(it) { return { title: it.item_name, sku: it.sku, code: it.qr_code, serial: it.serial_number, kind: 'product' }; }
  function unitLabel(it, u) { return { title: it.item_name, sku: it.sku, code: u.unit_code, serial: u.serial_number, kind: 'unit' }; }

  function render(d) {
    const it = d.item, units = d.units || [], w = d.can_write;
    const serial = it.tracking_mode === 'SERIAL';
    const body = panel.querySelector('[data-stqr-body]');
    panel.querySelector('[data-stqr-title]').textContent = it.item_name;

    const facts = '<div class="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-slate-500">'
      + '<span>SKU <b class="text-slate-800 font-mono">' + esc(it.sku) + '</b></span>'
      + '<span>Category <b class="text-slate-800">' + esc(it.category_name) + '</b></span>'
      + '<span>Brand / Model <b class="text-slate-800">' + esc((String(it.brand || '') + ' ' + String(it.model || '')).trim()) + '</b></span>'
      + '<span>Location <b class="text-slate-800">' + esc(it.warehouse_location) + '</b></span>'
      + '<span>Available <b class="text-slate-800">' + it.quantity + '</b>' + (it.quarantine_qty ? ' · <b class="text-amber-700">' + it.quarantine_qty + ' in quarantine</b>' : '') + '</span>'
      + '<span>Tracking <b class="text-slate-800">' + (serial ? 'Each unit has its own QR' : 'One QR for the product') + '</b></span></div>';

    let qrBlock;
    if (!it.qr_code) {
      qrBlock = '<div class="rounded-xl border border-dashed border-amber-300 bg-amber-50 p-4 text-center">'
        + '<p class="text-amber-800 font-semibold mb-2"><i class="fas fa-triangle-exclamation mr-1"></i>This item has no QR code yet.</p>'
        + (w ? '<button type="button" data-stqr-generate class="' + btnCls + ' bg-orange-500 hover:bg-orange-600 text-white"><i class="fas fa-wand-magic-sparkles"></i> Generate QR Code</button>'
             : '<p class="text-xs text-amber-700">Ask the warehouse team to generate one.</p>')
        + '</div>';
    } else {
      qrBlock = '<div class="flex flex-col sm:flex-row gap-4 items-center">'
        + '<div class="w-40 h-40 shrink-0 border border-slate-200 rounded-lg p-1 bg-white" data-stqr-qr>' + svg(it.qr_code, { margin: 2 }) + '</div>'
        + '<div class="flex-1 w-full">'
        + '<p class="text-[11px] text-slate-400 uppercase font-semibold">Product QR identifier</p>'
        + '<p class="font-mono font-bold text-slate-900 text-base mb-3">' + esc(it.qr_code) + '</p>'
        + '<div class="grid grid-cols-3 gap-2 mb-3">'
        + '<button type="button" data-stqr-view class="' + btnCls + ' bg-slate-100 hover:bg-slate-200 text-slate-700"><i class="fas fa-expand"></i> View QR Code</button>'
        + '<button type="button" data-stqr-print class="' + btnCls + ' bg-slate-800 hover:bg-slate-900 text-white"><i class="fas fa-print"></i> Print QR Label</button>'
        + '<button type="button" data-stqr-download class="' + btnCls + ' bg-orange-500 hover:bg-orange-600 text-white"><i class="fas fa-download"></i> Download QR Label</button>'
        + '</div>'
        + '<div class="flex flex-wrap gap-2 items-center text-xs text-slate-500">'
        + '<label>Layout <select data-stqr-layout class="border border-slate-200 rounded-lg px-2 py-1 ml-1">'
        + '<option value="thermal">Thermal label 50 × 30 mm</option><option value="sheet">A4 sheet, 21 per page (63.5 × 38.1 mm)</option></select></label>'
        + '<label>Copies <input data-stqr-copies type="number" min="1" max="200" value="1" class="w-16 border border-slate-200 rounded-lg px-2 py-1 ml-1"></label>'
        + '</div>'
        + (serial ? '<p class="text-[11px] text-slate-400 mt-2">This product label is for the shelf or box. Each unit below has its own label for the equipment itself.</p>' : '')
        + '</div></div>';
    }

    let quarantine = '';
    if (it.quarantine_qty > 0 && !serial) {
      quarantine = '<div class="rounded-xl border border-amber-200 bg-amber-50 p-4">'
        + '<p class="font-bold text-amber-900 mb-1"><i class="fas fa-shield-halved mr-1"></i>' + it.quarantine_qty + ' in quarantine</p>'
        + '<p class="text-xs text-amber-800 mb-3">Returned damaged or for inspection. Not counted as available stock until inspected.</p>'
        + (w ? '<div class="flex flex-wrap gap-2 items-center"><input data-stqr-q-qty type="number" min="1" max="' + it.quarantine_qty + '" value="1" class="w-20 border border-amber-200 rounded-lg px-2 py-1.5 text-sm">'
          + '<button type="button" data-stqr-q="restock" class="' + btnCls + ' bg-emerald-600 hover:bg-emerald-700 text-white"><i class="fas fa-check"></i> Passed — restock</button>'
          + '<button type="button" data-stqr-q="write_off" class="' + btnCls + ' bg-red-600 hover:bg-red-700 text-white"><i class="fas fa-trash-can"></i> Write off</button></div>' : '')
        + '</div>';
    }

    let unitsBlock = '';
    if (serial) {
      const inStock = units.filter(u => u.status === 'IN_STOCK');
      unitsBlock = '<div><div class="flex flex-wrap items-center justify-between gap-2 mb-2">'
        + '<h4 class="font-bold text-slate-900">Units <span class="text-xs text-slate-400 font-semibold">' + units.length + ' registered · ' + inStock.length + ' in stock</span></h4>'
        + (inStock.length ? '<button type="button" data-stqr-print-units class="' + btnCls + ' bg-slate-800 hover:bg-slate-900 text-white"><i class="fas fa-print"></i> Print labels for in-stock units</button>' : '')
        + '</div>'
        + (units.length ? '<div class="overflow-x-auto border border-slate-100 rounded-xl"><table class="w-full text-xs"><thead><tr class="text-left text-slate-400 uppercase">'
          + '<th class="px-3 py-2">Unit</th><th class="px-3 py-2">Serial</th><th class="px-3 py-2">Status</th><th class="px-3 py-2">Where</th><th class="px-3 py-2"></th></tr></thead><tbody>'
          + units.map(u => {
            const b = UNIT_BADGE[u.status] || [u.status, 'bg-slate-100'];
            const where = u.status === 'ISSUED' ? (u.job_code || u.request_code || 'Out') : (u.status === 'QUARANTINE' ? COND[u.item_condition] : (u.warehouse_location || it.warehouse_location || '—'));
            const qBtns = (w && u.status === 'QUARANTINE')
              ? '<button type="button" class="text-emerald-700 font-bold mr-2" data-stqr-uq="restock" data-unit="' + u.id + '" title="Passed inspection — restock"><i class="fas fa-check"></i></button>'
                + '<button type="button" class="text-red-600 font-bold mr-2" data-stqr-uq="write_off" data-unit="' + u.id + '" title="Write off"><i class="fas fa-trash-can"></i></button>' : '';
            return '<tr class="border-t border-slate-100"><td class="px-3 py-2 font-mono font-bold">' + esc(u.unit_code) + '</td>'
              + '<td class="px-3 py-2 font-mono">' + esc(u.serial_number) + '</td>'
              + '<td class="px-3 py-2"><span class="rounded-full px-2 py-0.5 font-bold ' + b[1] + '">' + b[0] + '</span></td>'
              + '<td class="px-3 py-2">' + esc(where) + '</td>'
              + '<td class="px-3 py-2 whitespace-nowrap text-right">' + qBtns
              + '<button type="button" class="text-slate-600 hover:text-orange-500 mr-2" data-stqr-uprint="' + u.id + '" title="Print label"><i class="fas fa-print"></i></button>'
              + '<button type="button" class="text-slate-600 hover:text-orange-500 mr-2" data-stqr-udl="' + u.id + '" title="Download label"><i class="fas fa-download"></i></button>'
              + '<button type="button" class="text-slate-600 hover:text-orange-500" data-stqr-uhist="' + u.id + '" title="Service history"><i class="fas fa-clock-rotate-left"></i></button></td></tr>';
          }).join('') + '</tbody></table></div>'
          : '<p class="text-xs text-slate-400">No units yet. Receive stock to register units by serial number.</p>')
        + '<div data-stqr-hist class="mt-3"></div></div>';
    } else if (w) {
      unitsBlock = '<details class="rounded-xl border border-slate-200 p-4"><summary class="font-bold text-slate-800 cursor-pointer">Track each unit separately (inverters, batteries)</summary>'
        + '<p class="text-xs text-slate-500 mt-2 mb-2">Gives every unit its own QR label, serial number and service history. Enter the serial of <b>each of the ' + it.quantity + '</b> units on the shelf, one per line.'
        + (it.quarantine_qty ? ' Inspect the quarantined stock first.' : '') + '</p>'
        + '<textarea data-stqr-serials rows="4" class="w-full border border-slate-200 rounded-lg px-3 py-2 font-mono text-xs" placeholder="One serial number per line"></textarea>'
        + '<div class="flex items-center justify-between mt-2"><span data-stqr-serial-count class="text-xs text-slate-500">0 of ' + it.quantity + '</span>'
        + '<button type="button" data-stqr-register class="' + btnCls + ' bg-slate-800 hover:bg-slate-900 text-white"><i class="fas fa-barcode"></i> Register units</button></div></details>';
    }

    body.innerHTML = '<div class="space-y-5">' + facts + qrBlock + quarantine + unitsBlock + '</div>';
    wire(d);
  }

  function opt(name) { const el = panel.querySelector('[data-stqr-' + name + ']'); return el ? el.value : null; }

  function wire(d) {
    const it = d.item;
    const on = (sel, fn) => panel.querySelectorAll(sel).forEach(el => el.addEventListener('click', e => fn(e.currentTarget)));

    on('[data-stqr-generate]', btn => locked(btn, async () => {
      const j = await postJ('inventory/qr.php', { id: it.id, action: 'generate' });
      notify(j.message, !j.success);
      if (j.success) { render(j.data); changed(); }
    }));
    on('[data-stqr-view]', () => {
      const big = document.createElement('div');
      big.className = 'fixed inset-0 z-[60] bg-white flex flex-col items-center justify-center p-6 cursor-pointer';
      big.innerHTML = '<div style="width:min(80vw,70vh)">' + svg(it.qr_code) + '</div>'
        + '<p class="font-mono font-bold text-xl mt-4">' + esc(it.qr_code) + '</p><p class="text-sm text-slate-500 mt-1">' + esc(it.item_name) + ' · tap to close</p>';
      big.addEventListener('click', () => big.remove());
      document.body.appendChild(big);
    });
    on('[data-stqr-print]', () => global.open(printUrl(state.base, it.id, { layout: opt('layout'), copies: opt('copies') }), '_blank'));
    on('[data-stqr-download]', () => downloadLabel(productLabel(it)));
    on('[data-stqr-print-units]', () => global.open(printUrl(state.base, it.id, { units: 'in_stock', layout: opt('layout') || 'thermal' }), '_blank'));
    on('[data-stqr-uprint]', btn => global.open(printUrl(state.base, it.id, { units: [btn.dataset.stqrUprint], layout: opt('layout') || 'thermal' }), '_blank'));
    on('[data-stqr-udl]', btn => {
      const u = d.units.find(x => String(x.id) === btn.dataset.stqrUdl);
      if (u) downloadLabel(unitLabel(it, u));
    });
    on('[data-stqr-uhist]', btn => locked(btn, async () => {
      const u = d.units.find(x => String(x.id) === btn.dataset.stqrUhist);
      const j = await getJ(state.base + '/api/inventory/movements.php?unit_id=' + encodeURIComponent(btn.dataset.stqrUhist));
      const box = panel.querySelector('[data-stqr-hist]');
      box.innerHTML = '<div class="rounded-xl bg-slate-50 p-3"><p class="font-bold text-slate-800 mb-2">Service history — ' + esc(u && u.unit_code) + '</p>'
        + (j.success && j.data.length ? j.data.map(m => '<div class="flex justify-between gap-3 py-1.5 border-t border-slate-200 first:border-0 text-xs">'
          + '<span><b>' + esc(m.movement_type) + '</b> · ' + esc(m.reference) + (m.item_condition && m.item_condition !== 'GOOD' ? ' · ' + esc(COND[m.item_condition]) : '')
          + (m.original_movement_code ? ' <span class="text-slate-400">(reverses ' + esc(m.original_movement_code) + ')</span>' : '') + '</span>'
          + '<span class="text-slate-400 whitespace-nowrap">' + esc(m.created_at) + ' · ' + esc(m.recorded_by_name) + '</span></div>').join('')
          : '<p class="text-xs text-slate-400">No history yet.</p>') + '</div>';
    }));
    on('[data-stqr-q]', btn => locked(btn, async () => {
      const action = btn.dataset.stqrQ;
      const qty = Number(opt('q-qty'));
      if (action === 'write_off' && !global.confirm('Write off ' + qty + ' x ' + it.item_name + '? It will not return to stock.')) return;
      const j = await postJ('inventory/quarantine.php', { inventory_id: it.id, action, quantity: qty, request_key: requestKey() });
      notify(j.message, !j.success);
      if (j.success) reload();
    }));
    on('[data-stqr-uq]', btn => locked(btn, async () => {
      const action = btn.dataset.stqrUq;
      if (action === 'write_off' && !global.confirm('Write off this unit? It will not return to stock.')) return;
      const j = await postJ('inventory/quarantine.php', { inventory_id: it.id, action, unit_ids: [Number(btn.dataset.unit)], request_key: requestKey() });
      notify(j.message, !j.success);
      if (j.success) reload();
    }));
    const ta = panel.querySelector('[data-stqr-serials]');
    if (ta) {
      const count = () => ta.value.split(/[\r\n,;]+/).map(s => s.trim()).filter(Boolean).length;
      ta.addEventListener('input', () => { panel.querySelector('[data-stqr-serial-count]').textContent = count() + ' of ' + it.quantity; });
      const key = requestKey();
      on('[data-stqr-register]', btn => locked(btn, async () => {
        if (count() !== it.quantity) { notify('Enter exactly ' + it.quantity + ' serial numbers — one for each unit in stock.', true); return; }
        const j = await postJ('inventory/register_units.php', { inventory_id: it.id, serials: ta.value, request_key: key });
        notify(j.message, !j.success);
        if (j.success) reload();
      }));
    }
  }

  function changed() { if (typeof state.onChanged === 'function') state.onChanged(); }

  async function reload() {
    const j = await getJ(state.base + '/api/inventory/qr.php?id=' + encodeURIComponent(state.id));
    if (j.success) render(j.data);
    changed();
  }

  async function openPanel(opts) {
    state = Object.assign({ base: '', csrf: '', id: 0, onChanged: null }, opts);
    ensurePanel();
    panel.querySelector('[data-stqr-title]').textContent = 'QR Code';
    panel.querySelector('[data-stqr-body]').innerHTML = '<p class="text-slate-400">Loading...</p>';
    panel.classList.remove('hidden');
    const j = await getJ(state.base + '/api/inventory/qr.php?id=' + encodeURIComponent(state.id));
    if (!j.success) { panel.querySelector('[data-stqr-body]').innerHTML = '<p class="text-red-600">' + esc(j.message) + '</p>'; return; }
    render(j.data);
  }

  global.SunTrackQR = { svg, labelCanvas, downloadLabel, printUrl, openPanel, closePanel, requestKey };
})(window);
