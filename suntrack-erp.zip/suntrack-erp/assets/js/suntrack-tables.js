/**
 * SunTrack — tables that read on a phone.
 *
 * Gives every `table.data-table` the `st-stack` class and labels each cell
 * with its column heading (data-label), so assets/css/suntrack-mobile.css can
 * show each row as a card below 768px. Desktop tables are untouched.
 *
 * The portals re-render their tables constantly (search as you type, live
 * refresh), so a MutationObserver re-labels whatever was redrawn. Only
 * attributes on the cells change — never the DOM structure — so this cannot
 * trigger itself and cannot break the pages' own event handlers.
 */
(function () {
  'use strict';

  function label(table) {
    table.classList.add('st-stack');
    var ths = table.tHead ? table.tHead.querySelectorAll('th') : [];
    var heads = [];
    for (var i = 0; i < ths.length; i++) {
      var span = ths[i].colSpan || 1;
      var text = ths[i].textContent.trim();
      for (var s = 0; s < span; s++) heads.push(text);
    }
    var rows = table.tBodies.length ? table.tBodies[0].rows : [];
    for (var r = 0; r < rows.length; r++) {
      var col = 0;
      var cells = rows[r].cells;
      for (var c = 0; c < cells.length; c++) {
        var td = cells[c];
        var span2 = td.colSpan || 1;
        // A cell spanning (nearly) the whole row is a loading/empty message.
        var full = span2 > 1 && span2 >= heads.length - 1;
        td.classList.toggle('st-full', full);
        var name = full ? '' : (heads[col] || '');
        if (td.getAttribute('data-label') !== name) td.setAttribute('data-label', name);
        col += span2;
      }
    }
  }

  function labelAll(root) {
    var tables = (root || document).querySelectorAll('table.data-table');
    for (var i = 0; i < tables.length; i++) label(tables[i]);
  }

  var queued = false;
  function schedule() {
    if (queued) return;
    queued = true;
    requestAnimationFrame(function () { queued = false; labelAll(); });
  }

  function start() {
    labelAll();
    new MutationObserver(function (mutations) {
      for (var i = 0; i < mutations.length; i++) {
        if (mutations[i].type === 'childList') { schedule(); return; }
      }
    }).observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
