/**
 * SunTrack — "confirm & sign" dialog for a completed job.
 *
 *   SunTrackSignature.open({
 *     title: 'Confirm job JOB-2026-1001',
 *     name: 'Maria Santos',                 // pre-filled signer name
 *     onSubmit: async ({ signature, signer_name, rating, comment }) => response  // {success, message}
 *   });
 *
 * Finger or mouse; sharp on high-density phone screens; an empty pad cannot be
 * submitted. Builds its own DOM on first use, so any page can include it.
 */
(function (global) {
  'use strict';

  var root, canvas, ctx, drawing = false, inked = false, rating = 0, opts = null;

  function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }

  function build() {
    root = el('div', 'hidden fixed inset-0 bg-black/50 z-[1300] flex items-center justify-center p-4');
    root.innerHTML =
      '<div class="bg-white rounded-2xl w-full max-w-md max-h-[92vh] overflow-y-auto p-5">' +
      '  <h3 class="st-sig-title font-bold text-slate-900 mb-1"></h3>' +
      '  <p class="text-xs text-slate-500 mb-3">By signing, you confirm the work on this job was completed.</p>' +
      '  <div class="st-sig-error hidden bg-red-50 border border-red-200 text-red-600 text-xs rounded-lg px-3 py-2 mb-3"></div>' +
      '  <label class="block text-xs font-semibold text-slate-500 mb-1">Name of person signing</label>' +
      '  <input class="st-sig-name w-full rounded-lg border border-slate-200 text-sm px-3 py-2 mb-3" maxlength="150" autocomplete="name">' +
      '  <div class="flex items-center justify-between mb-1"><label class="text-xs font-semibold text-slate-500">Signature</label>' +
      '    <button type="button" class="st-sig-clear text-xs font-bold text-slate-500 hover:text-orange-600">Clear</button></div>' +
      '  <canvas class="st-sig-pad w-full h-44 rounded-xl border-2 border-dashed border-slate-300 bg-slate-50" style="touch-action:none"></canvas>' +
      '  <label class="block text-xs font-semibold text-slate-500 mt-3 mb-1">How was the service? (optional)</label>' +
      '  <div class="st-sig-stars flex gap-1 mb-3"></div>' +
      '  <textarea class="st-sig-comment w-full rounded-lg border border-slate-200 text-sm px-3 py-2" rows="2" maxlength="500" placeholder="Comment (optional)"></textarea>' +
      '  <div class="flex gap-2 mt-4">' +
      '    <button type="button" class="st-sig-cancel flex-1 border border-slate-200 text-slate-600 text-sm font-semibold py-2.5 rounded-xl">Cancel</button>' +
      '    <button type="button" class="st-sig-ok flex-1 bg-orange-500 hover:bg-orange-600 text-white text-sm font-bold py-2.5 rounded-xl">Confirm &amp; sign</button>' +
      '  </div>' +
      '</div>';
    document.body.appendChild(root);

    canvas = root.querySelector('.st-sig-pad');
    ctx = canvas.getContext('2d');

    var stars = root.querySelector('.st-sig-stars');
    for (var i = 1; i <= 5; i++) {
      var b = el('button', 'st-star text-2xl text-slate-300', '&#9733;');
      b.type = 'button'; b.dataset.v = String(i); b.setAttribute('aria-label', i + ' star' + (i > 1 ? 's' : ''));
      b.addEventListener('click', function () { setRating(+this.dataset.v === rating ? 0 : +this.dataset.v); });
      stars.appendChild(b);
    }

    function pos(e) { var r = canvas.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
    canvas.addEventListener('pointerdown', function (e) { drawing = true; canvas.setPointerCapture(e.pointerId); var p = pos(e); ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x + 0.1, p.y + 0.1); ctx.stroke(); inked = true; });
    canvas.addEventListener('pointermove', function (e) { if (!drawing) return; var p = pos(e); ctx.lineTo(p.x, p.y); ctx.stroke(); });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(function (t) { canvas.addEventListener(t, function () { drawing = false; }); });

    root.querySelector('.st-sig-clear').addEventListener('click', resetPad);
    root.querySelector('.st-sig-cancel').addEventListener('click', close);
    root.querySelector('.st-sig-ok').addEventListener('click', submit);
  }

  function setRating(v) {
    rating = v;
    root.querySelectorAll('.st-star').forEach(function (s) { s.className = 'st-star text-2xl ' + (+s.dataset.v <= v ? 'text-amber-400' : 'text-slate-300'); });
  }

  function resetPad() {
    // Size the drawing buffer to the displayed size × pixel ratio, so lines stay sharp.
    var ratio = Math.max(1, global.devicePixelRatio || 1);
    var r = canvas.getBoundingClientRect();
    canvas.width = Math.round(r.width * ratio);
    canvas.height = Math.round(r.height * ratio);
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.lineWidth = 2.4; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#0f172a';
    ctx.clearRect(0, 0, r.width, r.height);
    inked = false;
  }

  function error(msg) {
    var box = root.querySelector('.st-sig-error');
    box.textContent = msg || ''; box.classList.toggle('hidden', !msg);
  }

  async function submit() {
    var name = root.querySelector('.st-sig-name').value.trim();
    if (name.length < 2) { error('Please type the name of the person signing.'); return; }
    if (!inked) { error('Please sign in the box.'); return; }
    var btn = root.querySelector('.st-sig-ok');
    btn.disabled = true; var label = btn.innerHTML; btn.innerHTML = 'Saving...';
    try {
      var res = await opts.onSubmit({
        signature: canvas.toDataURL('image/png'), signer_name: name,
        rating: rating || '', comment: root.querySelector('.st-sig-comment').value.trim(),
      });
      if (res && res.success) close(); else error((res && res.message) || 'Could not save. Please try again.');
    } catch (e) {
      error('Network error. Please try again.');
    } finally {
      btn.disabled = false; btn.innerHTML = label;
    }
  }

  function open(o) {
    if (!root) build();
    opts = o;
    root.querySelector('.st-sig-title').textContent = o.title || 'Confirm job';
    root.querySelector('.st-sig-name').value = o.name || '';
    root.querySelector('.st-sig-comment').value = '';
    setRating(0); error('');
    root.classList.remove('hidden');
    requestAnimationFrame(resetPad); // after it is visible, so it has a size
  }

  function close() { if (root) root.classList.add('hidden'); }

  global.SunTrackSignature = { open: open, close: close };
})(window);
