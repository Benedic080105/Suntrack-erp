/**
 * SunTrack — installable app + phone notifications.
 *
 * Loaded on every portal page and the login page. It:
 *   - registers sw.js, which makes the site installable ("Add to Home
 *     screen" / "Install app") and shows push notifications;
 *   - fills any <div data-push-card> with an on/off card for phone
 *     notifications on this device, plus an "Install app" button when the
 *     browser offers one;
 *   - keeps an existing subscription linked to whoever is signed in now.
 *
 * Push needs HTTPS (or localhost) and a browser that supports it. Anywhere it
 * is missing, the card simply explains that and nothing else changes.
 */
(function (global) {
  'use strict';

  // The app's base URL, from this script's own address (…/assets/js/suntrack-pwa.js).
  var me = document.currentScript && document.currentScript.src;
  var BASE = me ? me.replace(/assets\/js\/suntrack-pwa\.js.*$/, '') : '/';
  var API = BASE + 'api/push/subscribe.php';
  var installEvent = null;

  var swSupported = 'serviceWorker' in navigator && global.isSecureContext;
  var pushSupported = swSupported && 'PushManager' in global && 'Notification' in global;
  var registration = swSupported
    ? navigator.serviceWorker.register(BASE + 'sw.js', { scope: BASE }).catch(function () { return null; })
    : Promise.resolve(null);

  global.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    installEvent = e;
    refreshAll();
  });
  global.addEventListener('appinstalled', function () { installEvent = null; refreshAll(); });

  function csrf() { return typeof CSRF_TOKEN !== 'undefined' ? CSRF_TOKEN : ''; }
  function loggedIn() { return !!document.querySelector('[data-push-card]') || /\/(admin|management|warehouse|technician|client|subcontractor)\//.test(location.pathname); }

  async function api(method, body) {
    try {
      var res = await fetch(API, method === 'GET' ? { cache: 'no-store' } : {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({}, body, { csrf_token: csrf() })),
      });
      return await res.json();
    } catch (e) { return { success: false, message: 'Network error. Please try again.' }; }
  }

  function keyBytes(b64) {
    var pad = '='.repeat((4 - b64.length % 4) % 4);
    var raw = atob((b64 + pad).replace(/-/g, '+').replace(/_/g, '/'));
    var out = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out;
  }

  async function currentSubscription() {
    var reg = await registration;
    if (!reg || !reg.pushManager) return null;
    try { return await reg.pushManager.getSubscription(); } catch (e) { return null; }
  }

  async function turnOn() {
    var info = await api('GET');
    if (!info.success || !info.data.available) throw new Error('Phone notifications are not available on this server yet.');
    var perm = await Notification.requestPermission();
    if (perm !== 'granted') throw new Error('Notifications were not allowed. You can allow them in the browser\'s site settings.');
    var reg = await registration;
    if (!reg) throw new Error('This browser could not start the app service.');
    await navigator.serviceWorker.ready;
    var key = keyBytes(info.data.public_key);
    var sub;
    try {
      sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: key });
    } catch (e) {
      // An old subscription made with a different server key: replace it.
      var old = await reg.pushManager.getSubscription();
      if (!old) throw e;
      await old.unsubscribe();
      sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: key });
    }
    var j = sub.toJSON();
    var r = await api('POST', { action: 'subscribe', endpoint: j.endpoint, keys: j.keys || {} });
    if (!r.success) { await sub.unsubscribe(); throw new Error(r.message); }
  }

  async function turnOff() {
    var sub = await currentSubscription();
    if (!sub) return;
    await api('POST', { action: 'unsubscribe', endpoint: sub.endpoint });
    await sub.unsubscribe();
  }

  // A phone that already has notifications on is re-linked to the account
  // signed in now (so a shared phone never gets the previous user's alerts).
  async function sync() {
    if (!pushSupported || !loggedIn() || Notification.permission !== 'granted' || !csrf()) return;
    var sub = await currentSubscription();
    if (!sub) return;
    var j = sub.toJSON();
    api('POST', { action: 'subscribe', endpoint: j.endpoint, keys: j.keys || {} });
  }

  var BTN = 'rounded-lg text-sm font-bold px-4 py-2.5 w-full';
  var HEAD = '<h3 class="font-bold text-slate-900 mb-1"><i class="fas fa-bell text-orange-500 mr-1"></i> Phone app &amp; notifications</h3>'
    + '<p class="text-xs text-slate-500 mb-3">Install SunTrack on your phone\'s home screen, and get a notification on this device '
    + 'whenever something new comes in — even when the app is closed.</p><div class="pc-msg hidden"></div>';

  function iosHint() {
    var ios = /iphone|ipad|ipod/i.test(navigator.userAgent);
    var standalone = global.matchMedia && global.matchMedia('(display-mode: standalone)').matches;
    return ios && !standalone
      ? '<p class="text-[11px] text-slate-500 mt-2"><i class="fas fa-circle-info mr-1"></i>iPhone: tap <b>Share</b> → <b>Add to Home Screen</b>, then open SunTrack from the home screen to turn on notifications.</p>'
      : '';
  }

  async function render(box) {
    var html = HEAD;
    if (installEvent) {
      html += '<button type="button" class="pc-install ' + BTN + ' bg-orange-500 hover:bg-orange-600 text-white mb-2"><i class="fas fa-download mr-1"></i> Install SunTrack app</button>';
    }
    var state = 'unsupported';
    if (pushSupported) {
      state = Notification.permission === 'denied' ? 'blocked' : ((await currentSubscription()) ? 'on' : 'off');
    }
    if (state === 'on') {
      html += '<p class="text-sm font-semibold text-emerald-700 mb-2"><i class="fas fa-circle-check mr-1"></i>On for this device</p>'
        + '<button type="button" class="pc-off ' + BTN + ' bg-slate-100 hover:bg-slate-200 text-slate-700">Turn off on this device</button>';
    } else if (state === 'off') {
      html += '<button type="button" class="pc-on ' + BTN + ' bg-slate-800 hover:bg-slate-900 text-white"><i class="fas fa-bell mr-1"></i> Turn on notifications</button>';
    } else if (state === 'blocked') {
      html += '<p class="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">Notifications are blocked for this site. Allow them in the browser\'s site settings (the lock icon next to the address), then reload.</p>';
    } else {
      html += '<p class="text-xs text-slate-500 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">This browser cannot receive notifications here'
        + (global.isSecureContext ? '.' : ' — the site must be opened over <b>https://</b>.') + '</p>';
    }
    box.innerHTML = html + iosHint();

    function msg(text, ok) {
      var m = box.querySelector('.pc-msg');
      m.className = 'pc-msg text-xs rounded-lg px-3 py-2 mb-3 ' + (ok ? 'bg-emerald-50 border border-emerald-200 text-emerald-700' : 'bg-red-50 border border-red-200 text-red-600');
      m.textContent = text;
    }
    function busy(btn, on) { if (btn) { btn.disabled = on; btn.style.opacity = on ? '.6' : ''; } }

    var inst = box.querySelector('.pc-install');
    if (inst) inst.addEventListener('click', async function () {
      if (!installEvent) return;
      installEvent.prompt();
      try { await installEvent.userChoice; } catch (e) { }
      installEvent = null;
      refreshAll();
    });
    var on = box.querySelector('.pc-on');
    if (on) on.addEventListener('click', async function () {
      busy(on, true);
      try { await turnOn(); await render(box); msg('Notifications are on for this device.', true); }
      catch (e) { busy(on, false); msg(e && e.message ? e.message : 'Could not turn on notifications.', false); }
    });
    var off = box.querySelector('.pc-off');
    if (off) off.addEventListener('click', async function () {
      busy(off, true);
      try { await turnOff(); } catch (e) { }
      render(box);
    });
  }

  function refreshAll() {
    document.querySelectorAll('[data-push-card]').forEach(function (b) { render(b); });
  }

  function start() { refreshAll(); sync(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();

  global.SunTrackPWA = { refresh: refreshAll };
})(window);
