/**
 * SunTrack — an eye button on every password box.
 *
 * Tap the eye to see what you typed, tap again to hide it. Works on every
 * input[type=password] on the page, including ones a form or modal adds later
 * (Settings → change password, new-user forms). Pages need no changes beyond
 * loading this file. Add data-no-eye to an input to leave it alone.
 */
(function () {
  'use strict';

  // Classes that size the box in its layout move to the wrapper.
  var LAYOUT = /^(?:[a-z]+:)?(?:flex-1|flex-auto|grow|basis-|min-w-|max-w-|w-)/;

  function setShown(input, btn, shown) {
    input.type = shown ? 'text' : 'password';
    btn.setAttribute('aria-pressed', String(shown));
    btn.setAttribute('aria-label', shown ? 'Hide password' : 'Show password');
    btn.title = shown ? 'Hide password' : 'Show password';
    btn.innerHTML = '<i class="fas ' + (shown ? 'fa-eye-slash' : 'fa-eye') + '"></i>';
  }

  function enhance(input) {
    if (input.dataset.pwEye || input.hasAttribute('data-no-eye')) return;
    input.dataset.pwEye = '1';

    var wrap = document.createElement('span');
    wrap.className = 'st-pw-wrap';
    var keep = [];
    var full = false;
    input.className.split(/\s+/).forEach(function (c) {
      if (!c) return;
      if (LAYOUT.test(c)) { wrap.classList.add(c); if (/(^|:)w-full$/.test(c)) full = true; } else keep.push(c);
    });
    input.className = keep.join(' ');
    // Full-width boxes (and the app's .field boxes) stay full width.
    if (full || input.classList.contains('field') || getComputedStyle(input).display === 'block') wrap.classList.add('st-pw-block');

    input.style.width = '100%';
    input.style.paddingRight = '2.75rem';

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'st-pw-eye';
    setShown(input, btn, false);
    btn.addEventListener('mousedown', function (e) { e.preventDefault(); }); // keep focus (and the caret) in the box
    btn.addEventListener('click', function () {
      setShown(input, btn, input.type === 'password');
      input.focus();
    });
    // A form that resets itself also hides the password again.
    if (input.form) input.form.addEventListener('reset', function () { setShown(input, btn, false); });

    input.parentNode.insertBefore(wrap, input);
    wrap.appendChild(input);
    wrap.appendChild(btn);
  }

  function scan(root) {
    if (!root || !root.querySelectorAll) return;
    if (root.matches && root.matches('input[type="password"]')) enhance(root);
    root.querySelectorAll('input[type="password"]').forEach(enhance);
  }

  var style = document.createElement('style');
  style.textContent = ''
    + '.st-pw-wrap{position:relative;display:inline-block;vertical-align:middle}'
    + '.st-pw-wrap.st-pw-block{display:block;width:100%}'
    + '.st-pw-eye{position:absolute;top:50%;right:.5rem;transform:translateY(-50%);width:2rem;height:2rem;'
    + 'display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:8px;background:transparent;'
    + 'color:#94a3b8;cursor:pointer;font-size:14px}'
    + '.st-pw-eye:hover{color:#f97316}'
    + '.st-pw-eye:focus-visible{outline:2px solid #fdba74;outline-offset:1px}'
    // Hide the browser's own reveal button (Edge) so there is only one eye.
    + 'input::-ms-reveal,input::-ms-clear{display:none}';

  function start() {
    document.head.appendChild(style);
    scan(document.body);
    new MutationObserver(function (records) {
      records.forEach(function (r) { r.addedNodes.forEach(scan); });
    }).observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
