/**
 * SunTrack ERP — Real-time client.
 *
 * Wraps /api/realtime/sync.php in a small subscription API so that every
 * portal gets live updates the same way:
 *
 *   SunTrackRealtime.start({
 *     channels: ['inventory', 'stock_movements'],
 *     on: {
 *       inventory: () => loadInventory(),
 *       '*':       (changed, counters) => updateBadges(counters)
 *     }
 *   });
 *
 * Behaviour that matters in practice:
 *
 *   - Nothing fires on the first poll. That poll establishes the baseline;
 *     firing there would reload every section immediately after the page had
 *     just loaded it.
 *   - Polling pauses while the tab is hidden and resumes (with an immediate
 *     poll) when it becomes visible again. A dashboard left open on a second
 *     monitor overnight otherwise makes thousands of pointless requests.
 *   - Failures back off exponentially up to a ceiling, so a restarting
 *     database gets a slow retry instead of a request storm.
 *   - Overlapping polls are impossible: a request in flight blocks the next.
 */
(function (global) {
  'use strict';

  var DEFAULTS = {
    endpoint: '../api/realtime/sync.php',
    interval: 10000,      // overridden by the server's poll_seconds
    maxInterval: 120000,  // backoff ceiling
    channels: null,       // null = every channel this role may see
    on: {}
  };

  var state = {
    config: null,
    timer: null,
    token: null,
    versions: {},
    counters: {},
    started: false,
    inFlight: false,
    primed: false,     // true once the baseline poll has completed
    failures: 0,
    paused: false
  };

  function log() {
    if (global.SUNTRACK_REALTIME_DEBUG && global.console) {
      global.console.log.apply(global.console, ['[realtime]'].concat([].slice.call(arguments)));
    }
  }

  function buildUrl() {
    var url = state.config.endpoint;
    var params = [];

    if (state.config.channels && state.config.channels.length) {
      params.push('channels=' + encodeURIComponent(state.config.channels.join(',')));
    }
    if (state.token) {
      params.push('since=' + encodeURIComponent(state.token));
    }
    // Defeat any intermediate cache; the endpoint also sends no-store.
    params.push('_=' + Date.now());

    return url + (url.indexOf('?') === -1 ? '?' : '&') + params.join('&');
  }

  function fire(name, payload, counters) {
    var handler = state.config.on[name];
    if (typeof handler === 'function') {
      try {
        handler(payload, counters);
      } catch (err) {
        if (global.console) global.console.error('[realtime] handler "' + name + '" failed', err);
      }
    }
  }

  function currentDelay() {
    if (state.failures === 0) return state.config.interval;
    // 2x per consecutive failure, capped.
    var delay = state.config.interval * Math.pow(2, Math.min(state.failures, 6));
    return Math.min(delay, state.config.maxInterval);
  }

  function schedule() {
    clearTimeout(state.timer);
    if (!state.started || state.paused) return;
    state.timer = setTimeout(poll, currentDelay());
  }

  async function poll() {
    if (!state.started || state.inFlight || state.paused) return;
    state.inFlight = true;

    try {
      var res = await fetch(buildUrl(), {
        credentials: 'same-origin',
        headers: { 'Accept': 'application/json' }
      });

      // The session expired underneath us, or the role lost access.
      if (res.status === 401) {
        log('session expired — stopping');
        stop();
        fire('sessionExpired', null, null);
        return;
      }

      if (!res.ok) throw new Error('HTTP ' + res.status);

      var json = await res.json();
      if (!json || !json.success) throw new Error((json && json.message) || 'sync failed');

      state.failures = 0;
      var data = json.data || {};

      // Let the server dictate the cadence, so an admin can tune polling
      // load from the settings table without a redeploy.
      if (data.poll_seconds) {
        state.config.interval = Math.max(3000, data.poll_seconds * 1000);
      }

      if (data.changed === false) {
        state.token = data.token || state.token;
        return; // nothing moved
      }

      var channels = data.channels || {};
      var counters = data.counters || {};
      var changed = [];

      Object.keys(channels).forEach(function (name) {
        var version = channels[name].version;
        if (state.versions[name] !== undefined && state.versions[name] !== version) {
          changed.push(name);
        }
        state.versions[name] = version;
      });

      state.counters = counters;
      state.token = data.token || state.token;

      // The first successful poll only records the baseline.
      if (!state.primed) {
        state.primed = true;
        log('primed with', Object.keys(state.versions).length, 'channels');
        fire('ready', Object.keys(state.versions), counters);
        return;
      }

      // Counters are pushed on every poll — badges should track the server
      // even when no channel fingerprint happened to move.
      fire('counters', counters, counters);

      if (changed.length) {
        log('changed:', changed.join(', '));
        changed.forEach(function (name) {
          fire(name, name, counters);
        });
        fire('*', changed, counters);
      }
    } catch (err) {
      state.failures++;
      log('poll failed (' + state.failures + '):', err.message);
      fire('error', err, null);
    } finally {
      state.inFlight = false;
      schedule();
    }
  }

  function onVisibilityChange() {
    if (document.hidden) {
      state.paused = true;
      clearTimeout(state.timer);
      log('paused (tab hidden)');
    } else if (state.started) {
      state.paused = false;
      log('resumed (tab visible)');
      poll(); // catch up immediately rather than waiting a full interval
    }
  }

  function start(options) {
    if (state.started) {
      // Allow a portal to add handlers or channels after the fact.
      update(options);
      return;
    }

    state.config = Object.assign({}, DEFAULTS, options || {});
    state.config.on = Object.assign({}, options && options.on);
    state.started = true;
    state.paused = document.hidden;

    document.addEventListener('visibilitychange', onVisibilityChange);

    if (!state.paused) poll();
    else schedule();

    log('started');
  }

  /** Merge in new handlers / channels without losing the established baseline. */
  function update(options) {
    if (!options) return;
    if (options.on) Object.assign(state.config.on, options.on);
    if (options.channels) state.config.channels = options.channels;
    if (options.interval) state.config.interval = options.interval;
  }

  function stop() {
    state.started = false;
    state.paused = false;
    clearTimeout(state.timer);
    document.removeEventListener('visibilitychange', onVisibilityChange);
    log('stopped');
  }

  /** Force an immediate poll — call right after a local mutation succeeds. */
  function refreshNow() {
    if (!state.started) return;
    clearTimeout(state.timer);
    poll();
  }

  /**
   * Mark a channel as stale locally so the NEXT poll treats it as changed.
   * Useful when this tab performed the write: without it, this tab records the
   * new fingerprint as its own baseline and never fires its own handler.
   */
  function invalidate(name) {
    delete state.versions[name];
  }

  global.SunTrackRealtime = {
    start: start,
    stop: stop,
    update: update,
    refreshNow: refreshNow,
    invalidate: invalidate,
    counters: function () { return state.counters; },
    isRunning: function () { return state.started; }
  };
})(window);
