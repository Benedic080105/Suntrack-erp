/**
 * SunTrack ERP — shared operations dashboard (Admin + Management).
 *
 *   const dash = SunTrackDashboard.mount({
 *     root:     document.getElementById('std-root'),
 *     endpoint: '../api/dashboard/overview.php',
 *     targets:  { service_requests: 'service-requests', ... },  // card -> tab key
 *     navigate: (tabKey) => showTab(tabKey),
 *     viewOnly: true | false,
 *   });
 *   dash.refresh();   // first load, and on every live update
 *
 * If the response carries `modules` (includes/dashboard_lib.php), a "By module"
 * card with Clients / Technicians / Warehouse views is drawn under the tiles.
 *
 * Everything is drawn from one API response. A refresh keeps the previous
 * render on screen (dimmed) until the new data arrives, so live updates never
 * flash an empty page. Every chart has a table view, and every status colour
 * is paired with an icon and a text label — colour never carries meaning alone.
 *
 * Colours: categorical slots 1–2 and the fixed status palette of the shared
 * data-viz reference palette (pre-validated for colour-vision deficiency).
 */
(function (global) {
  'use strict';

  var C = {
    series1: '#2a78d6',   // blue   — categorical slot 1
    series2: '#eb6834',   // orange — categorical slot 2
    series3: '#1baf7a',   // aqua   — categorical slot 3 (slots 1–3 validate all-pairs)
    good: '#0ca30c', warning: '#fab219', serious: '#ec835a', critical: '#d03b3b',
    neutral: '#c3c2b7', closed: '#d9d8d2',
    grid: '#e1e0d9', axis: '#c3c2b7', muted: '#898781', ink2: '#52514e', surface: '#ffffff',
  };

  var STYLE = ''
    + '.std{--std-gap:16px;color:#0f172a}'
    + '.std .std-card{background:#fff;border:1px solid #eef0f4;border-radius:1rem;box-shadow:0 1px 3px rgba(0,0,0,.05);padding:1.1rem 1.25rem;min-width:0}'
    + '.std .std-h{font-size:14px;font-weight:700;color:#0f172a;display:flex;align-items:center;gap:8px}'
    + '.std .std-sub{font-size:12px;color:#64748b;margin-top:2px}'
    + '.std .std-tile{text-align:left;width:100%;display:flex;flex-direction:column;gap:6px;transition:box-shadow .15s,border-color .15s}'
    + '.std button.std-tile:hover,.std button.std-tile:focus-visible{border-color:#f97316;box-shadow:0 4px 14px rgba(249,115,22,.15);outline:none}'
    + '.std .std-ico{width:34px;height:34px;border-radius:10px;display:inline-flex;align-items:center;justify-content:center;font-size:15px;flex-shrink:0}'
    + '.std .std-val{font-size:28px;font-weight:800;line-height:1.1;color:#0f172a}'
    + '.std .std-lbl{font-size:12px;font-weight:600;color:#475569;text-transform:uppercase;letter-spacing:.02em}'
    + '.std .std-cap{font-size:12.5px;color:#64748b;line-height:1.35}'
    + '.std .std-chip{display:inline-flex;align-items:center;gap:4px;font-size:11.5px;font-weight:700;padding:2px 8px;border-radius:999px}'
    + '.std .std-row-btn{width:100%;text-align:left;display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:12px;border:1px solid transparent}'
    + '.std .std-row-btn:hover,.std .std-row-btn:focus-visible{background:#f8fafc;border-color:#e2e8f0;outline:none}'
    + '.std .std-hbar{height:10px;border-radius:0 4px 4px 0;min-width:2px}'
    + '.std .std-stack{display:flex;gap:2px;height:14px;border-radius:4px;overflow:hidden;background:#f1f5f9}'
    + '.std .std-chart{position:relative;height:240px}'
    + '.std .std-toggle{font-size:11.5px;font-weight:700;color:#475569;border:1px solid #e2e8f0;border-radius:8px;padding:3px 9px;background:#fff}'
    + '.std .std-toggle:hover{border-color:#f97316;color:#ea580c}'
    + '.std table.std-table{width:100%;font-size:12.5px;border-collapse:collapse}'
    + '.std table.std-table th{font-size:11px;text-transform:uppercase;color:#94a3b8;font-weight:700;text-align:left;padding:6px 8px;border-bottom:1px solid #eef0f4}'
    + '.std table.std-table td{padding:8px;border-bottom:1px solid #f1f5f9;font-variant-numeric:tabular-nums}'
    + '.std .std-dim{opacity:.55;transition:opacity .2s}'
    + '.std .std-badge{font-size:11px;font-weight:700;padding:2px 8px;border-radius:999px;white-space:nowrap;display:inline-flex;align-items:center;gap:4px}'
    + '.std .std-grid-6{display:grid;gap:var(--std-gap);grid-template-columns:repeat(1,minmax(0,1fr))}'
    + '@media(min-width:640px){.std .std-grid-6{grid-template-columns:repeat(2,minmax(0,1fr))}}'
    + '@media(min-width:1280px){.std .std-grid-6{grid-template-columns:repeat(3,minmax(0,1fr))}}'
    + '.std .std-grid-5{display:grid;gap:12px;grid-template-columns:repeat(2,minmax(0,1fr))}'
    + '@media(min-width:768px){.std .std-grid-5{grid-template-columns:repeat(3,minmax(0,1fr))}}'
    + '@media(min-width:1280px){.std .std-grid-5{grid-template-columns:repeat(5,minmax(0,1fr))}}'
    + '.std .std-grid-4{display:grid;gap:12px;grid-template-columns:repeat(1,minmax(0,1fr))}'
    + '@media(min-width:640px){.std .std-grid-4{grid-template-columns:repeat(2,minmax(0,1fr))}}'
    + '@media(min-width:1280px){.std .std-grid-4{grid-template-columns:repeat(4,minmax(0,1fr))}}'
    + '@media(min-width:1280px){.std .std-grid-4.std-n3{grid-template-columns:repeat(3,minmax(0,1fr))}}'
    + '.std .std-charts-2{display:grid;gap:var(--std-gap);grid-template-columns:minmax(0,1fr);margin-top:12px}'
    + '@media(min-width:1000px){.std .std-charts-2{grid-template-columns:minmax(0,1fr) minmax(0,1fr)}}'
    + '.std .std-seg{display:inline-flex;gap:2px;padding:3px;background:#f1f5f9;border-radius:12px;flex-wrap:wrap}'
    + '.std .std-seg button{font-size:12.5px;font-weight:700;color:#475569;padding:6px 12px;border-radius:9px;display:inline-flex;align-items:center;gap:6px}'
    + '.std .std-seg button:hover{color:#0f172a}'
    + '.std .std-seg button[aria-selected="true"]{background:#fff;color:#0f172a;box-shadow:0 1px 3px rgba(0,0,0,.08)}'
    + '.std .std-seg button:focus-visible{outline:2px solid #f97316;outline-offset:1px}';

  // ---- formatting -----------------------------------------------------------
  function esc(v) {
    if (v === null || v === undefined) return '';
    return String(v).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  var nf = new Intl.NumberFormat('en-PH');
  function n(v) { return nf.format(Number(v) || 0); }
  function peso(v) { return '₱' + new Intl.NumberFormat('en-PH', { maximumFractionDigits: 0 }).format(Number(v) || 0); }
  function pesoShort(v) {
    v = Number(v) || 0;
    if (Math.abs(v) >= 1e6) return '₱' + (v / 1e6).toFixed(v >= 1e7 ? 0 : 1) + 'M';
    if (Math.abs(v) >= 1e3) return '₱' + Math.round(v / 1e3) + 'K';
    return '₱' + Math.round(v);
  }
  function plural(count, one, many) { return n(count) + ' ' + (Number(count) === 1 ? one : many); }
  function nice(s) {
    return String(s || '').toLowerCase().replace(/_/g, ' ').replace(/\b\w/g, function (c) { return c.toUpperCase(); });
  }
  function parseTs(s) { return s ? new Date(String(s).replace(' ', 'T')) : null; }
  function ago(s) {
    var d = parseTs(s);
    if (!d || isNaN(d)) return '';
    var sec = Math.round((Date.now() - d.getTime()) / 1000);
    if (sec < 60) return 'just now';
    if (sec < 3600) return Math.round(sec / 60) + ' min ago';
    if (sec < 86400) return Math.round(sec / 3600) + ' h ago';
    if (sec < 86400 * 7) return Math.round(sec / 86400) + ' d ago';
    return d.toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' });
  }
  // A delta chip: arrow icon + words, so direction never depends on colour alone.
  function delta(now, prev, money) {
    now = Number(now) || 0; prev = Number(prev) || 0;
    if (!prev && !now) return '<span class="std-chip" style="background:#f1f5f9;color:#475569">No activity in either period</span>';
    if (!prev) return '<span class="std-chip" style="background:#ecfdf5;color:#047857"><i class="fas fa-arrow-up"></i>New this period</span>';
    var pct = Math.round((now - prev) * 100 / prev);
    var diff = money ? pesoShort(Math.abs(now - prev)) : n(Math.abs(now - prev));
    if (pct === 0) return '<span class="std-chip" style="background:#f1f5f9;color:#475569"><i class="fas fa-equals"></i>Same as the 30 days before</span>';
    var up = pct > 0;
    return '<span class="std-chip" style="background:' + (up ? '#ecfdf5;color:#047857' : '#fef2f2;color:#b91c1c') + '"><i class="fas fa-arrow-' + (up ? 'up' : 'down') + '"></i>'
      + (up ? '+' : '−') + Math.abs(pct) + '% (' + (up ? '+' : '−') + diff + ') vs the 30 days before</span>';
  }


  // Audit-log rows -> plain sentences.
  var MODULE_NOUN = {
    service_requests: 'service request', jobs: 'job', projects: 'project', billing: 'invoice', clients: 'client',
    technicians: 'technician', staff: 'staff member', inventory: 'stock item', material_requests: 'client order',
    maintenance_schedules: 'maintenance schedule', maintenance_records: 'maintenance inspection', maintenance_items: 'inspection item',
    installation_items: 'installation checklist', attendance: 'attendance', subcontractors: 'sub-contractor',
    work_reports: 'work report', stock_movements: 'stock movement', auth: 'account',
  };
  var MODULE_ICON = {
    service_requests: 'fa-ticket', jobs: 'fa-briefcase', projects: 'fa-diagram-project', billing: 'fa-file-invoice-dollar',
    clients: 'fa-users', technicians: 'fa-user-gear', staff: 'fa-id-badge', inventory: 'fa-boxes-stacked',
    material_requests: 'fa-dolly', maintenance_schedules: 'fa-wrench', maintenance_records: 'fa-wrench', maintenance_items: 'fa-wrench',
    installation_items: 'fa-list-check', attendance: 'fa-location-dot', subcontractors: 'fa-helmet-safety', work_reports: 'fa-file-lines',
  };
  var VERB = {
    CREATE: 'created', UPDATE: 'updated', DELETE: 'deleted', ASSIGN: 'assigned', REASSIGN: 'reassigned', APPROVE: 'approved',
    REJECT: 'rejected', CANCEL: 'cancelled', COMPLETE: 'completed', SCHEDULE: 'scheduled', RESCHEDULE: 'rescheduled',
    NOTIFY: 'notified the client about', HOLD: 'put on hold', RESUME: 'resumed', NOTE: 'added a note to',
    RECORD_PAYMENT: 'recorded the final payment on', RECORD_PARTIAL_PAYMENT: 'recorded a payment on', PICK: 'packed items for',
    UNPICK: 'removed an item from', RELEASE: 'released', TIME_IN: 'timed in on', TIME_OUT: 'timed out of',
    PHOTO_UPLOAD: 'added a photo to', CONFIRM: 'signed off', SAVE_MAINTENANCE: 'saved the inspection for',
    TECH_NOTE: 'added a field note to', RESOLUTION: 'wrote the resolution for', UPDATE_PRIORITY: 'changed the priority of',
    SET_PRIORITY: 'changed the priority of', TOGGLE_STATUS: 'changed the status of', RECEIVE: 'received stock for',
    ISSUE: 'issued stock from', RETURN: 'returned stock to',
  };
  function sentence(a) {
    var who = a.actor || 'System';
    var noun = MODULE_NOUN[a.module] || nice(a.module).toLowerCase();
    var rec = a.record_id ? ' ' + a.record_id : '';
    var action = String(a.action || '');
    var m = action.match(/^STATUS_CHANGE:(\w+)->(\w+)$/);
    if (m) return { who: who, text: 'moved ' + noun + rec + ' from “' + nice(m[1]) + '” to “' + nice(m[2]) + '”' };
    m = action.match(/^UNDO_STATUS:(\w+)->(\w+)$/);
    if (m) return { who: who, text: 'undid a step on ' + noun + rec + ' (back to “' + nice(m[2]) + '”)' };
    m = action.match(/^UPDATE_(CHECKLIST|MAINTENANCE)_ITEM:(\w+)$/);
    if (m) return { who: who, text: 'marked an item “' + nice(m[2]) + '” on' + rec };
    var verb = VERB[action] || nice(action).toLowerCase();
    return { who: who, text: verb + ' ' + noun + rec };
  }

  // ---- building blocks ----------------------------------------------------------
  function tile(o, targets) {
    var tab = o.target && targets[o.target];
    var tag = tab ? 'button' : 'div';
    return '<' + tag + ' class="std-card std-tile"' + (tab ? ' type="button" data-nav="' + esc(tab) + '" title="Open ' + esc(o.label) + '"' : '') + '>'
      + '<div style="display:flex;align-items:center;justify-content:space-between;gap:8px">'
      +   '<span class="std-lbl">' + esc(o.label) + '</span>'
      +   '<span class="std-ico" style="background:' + o.tint + ';color:' + o.color + '"><i class="fas ' + o.icon + '"></i></span>'
      + '</div>'
      + '<div class="std-val">' + o.value + '</div>'
      + '<div class="std-cap">' + o.caption + '</div>'
      + (o.extra ? '<div>' + o.extra + '</div>' : '')
      + (tab ? '<div class="std-cap" style="color:#ea580c;font-weight:600;margin-top:2px">Open <i class="fas fa-arrow-right" style="font-size:10px"></i></div>' : '')
      + '</' + tag + '>';
  }

  function miniTile(o, targets) {
    var tab = o.target && targets[o.target];
    var tag = tab ? 'button' : 'div';
    return '<' + tag + ' class="std-card std-tile" style="padding:.85rem 1rem;gap:4px"' + (tab ? ' type="button" data-nav="' + esc(tab) + '"' : '') + '>'
      + '<span class="std-lbl" style="display:flex;align-items:center;gap:6px"><i class="fas ' + o.icon + '" style="color:' + o.color + '"></i>' + esc(o.label) + '</span>'
      + '<span style="font-size:20px;font-weight:800">' + o.value + '</span>'
      + '<span class="std-cap" style="font-size:12px">' + o.caption + '</span>'
      + '</' + tag + '>';
  }

  // Horizontal bars in HTML: label · bar · value, all in text tokens.
  function hbars(items, opts) {
    var max = Math.max.apply(null, items.map(function (i) { return i.count; }).concat([1]));
    return '<div style="display:flex;flex-direction:column;gap:8px">' + items.map(function (i) {
      var w = i.count ? Math.max(2, Math.round(i.count * 100 / max)) : 0;
      return '<div style="display:grid;grid-template-columns:' + (opts.labelWidth || '120px') + ' 1fr 44px;align-items:center;gap:10px">'
        + '<span style="font-size:12.5px;color:#334155;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="' + esc(i.label) + '">' + esc(i.label) + '</span>'
        + '<span style="background:#f1f5f9;border-radius:0 4px 4px 0;height:10px;display:block">'
        +   (w ? '<span class="std-hbar" style="display:block;width:' + w + '%;background:' + (i.color || C.series1) + '"></span>' : '')
        + '</span>'
        + '<span style="font-size:12.5px;font-weight:700;text-align:right;font-variant-numeric:tabular-nums">' + n(i.count) + '</span>'
        + '</div>';
    }).join('') + '</div>';
  }

  // A single stacked bar for a part-to-whole of statuses, with a legend that
  // repeats each value in text (the legend is the readable copy of the bar).
  function stack(parts, fmt) {
    var total = parts.reduce(function (s, p) { return s + p.value; }, 0);
    var bar = total
      ? parts.filter(function (p) { return p.value > 0; }).map(function (p) {
          return '<span title="' + esc(p.label + ': ' + fmt(p.value)) + '" style="flex:' + p.value + ' 1 0;background:' + p.color + '"></span>';
        }).join('')
      : '';
    return '<div class="std-stack" role="img" aria-label="' + esc(parts.map(function (p) { return p.label + ' ' + fmt(p.value); }).join(', ')) + '">' + bar + '</div>'
      + '<div style="display:flex;flex-direction:column;gap:6px;margin-top:12px">' + parts.map(function (p) {
          var pct = total ? Math.round(p.value * 100 / total) : 0;
          return '<div style="display:flex;align-items:center;gap:8px;font-size:12.5px">'
            + '<span style="width:10px;height:10px;border-radius:3px;background:' + p.color + ';flex-shrink:0"></span>'
            + '<i class="fas ' + p.icon + '" style="width:14px;text-align:center;color:#475569"></i>'
            + '<span style="color:#334155;flex:1">' + esc(p.label) + (p.hint ? ' <span style="color:#94a3b8">· ' + esc(p.hint) + '</span>' : '') + '</span>'
            + '<span style="font-weight:700;font-variant-numeric:tabular-nums">' + fmt(p.value) + '</span>'
            + '<span style="color:#94a3b8;width:38px;text-align:right;font-variant-numeric:tabular-nums">' + pct + '%</span>'
            + '</div>';
        }).join('') + '</div>';
  }

  function card(title, sub, body, opts) {
    opts = opts || {};
    return '<section class="std-card"' + (opts.id ? ' id="' + opts.id + '"' : '') + ' style="' + (opts.style || '') + '">'
      + '<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:12px">'
      +   '<div><h3 class="std-h">' + (opts.icon ? '<i class="fas ' + opts.icon + '" style="color:#f97316"></i>' : '') + esc(title) + '</h3>'
      +   (sub ? '<p class="std-sub">' + sub + '</p>' : '') + '</div>'
      +   (opts.action || '')
      + '</div>' + body + '</section>';
  }

  // ---- the dashboard ------------------------------------------------------------
  function mount(cfg) {
    var root = cfg.root;
    var targets = cfg.targets || {};
    var charts = {};
    var tableView = {};       // chart id -> true when its table is showing
    var data = null;
    var busy = false;
    var firstPaint = true;

    if (!document.getElementById('std-style')) {
      var st = document.createElement('style');
      st.id = 'std-style';
      st.textContent = STYLE;
      document.head.appendChild(st);
    }
    root.classList.add('std');

    root.addEventListener('click', function (e) {
      var nav = e.target.closest('[data-nav]');
      if (nav && cfg.navigate) { cfg.navigate(nav.getAttribute('data-nav')); return; }
      var modBtn = e.target.closest('[data-module]');
      if (modBtn) {
        moduleTab = modBtn.getAttribute('data-module');
        try { localStorage.setItem('std-module', moduleTab); } catch (err) { /* not remembered — fine */ }
        if (data && data.modules) renderModules(data.modules);
        return;
      }
      var tog = e.target.closest('[data-toggle-table]');
      if (tog) {
        var id = tog.getAttribute('data-toggle-table');
        tableView[id] = !tableView[id];
        applyChartView(id);
        return;
      }
      if (e.target.closest('[data-refresh]')) refresh();
    });

    function chartCard(id, title, sub, icon) {
      return card(title, sub,
        '<div class="std-chart" id="' + id + '-wrap"><canvas id="' + id + '" role="img" aria-label="' + esc(title) + '"></canvas></div>'
        + '<div id="' + id + '-table" style="display:none;max-height:240px;overflow:auto"></div>',
        { icon: icon, action: '<button type="button" class="std-toggle" data-toggle-table="' + id + '"><i class="fas fa-table-list"></i> <span>Table</span></button>' });
    }

    function applyChartView(id) {
      var showTable = !!tableView[id];
      var wrap = document.getElementById(id + '-wrap');
      var tbl = document.getElementById(id + '-table');
      var btn = root.querySelector('[data-toggle-table="' + id + '"] span');
      if (!wrap || !tbl) return;
      wrap.style.display = showTable ? 'none' : '';
      tbl.style.display = showTable ? '' : 'none';
      if (btn) btn.textContent = showTable ? 'Chart' : 'Table';
    }

    function chartTable(id, labels, series, fmt, head) {
      var el = document.getElementById(id + '-table');
      if (!el) return;
      el.innerHTML = '<table class="std-table"><thead><tr><th>' + esc(head || 'Month') + '</th>' + series.map(function (s) { return '<th style="text-align:right">' + esc(s.label) + '</th>'; }).join('') + '</tr></thead><tbody>'
        + labels.map(function (l, i) {
            return '<tr><td>' + esc(l) + '</td>' + series.map(function (s) { return '<td style="text-align:right">' + fmt(s.data[i]) + '</td>'; }).join('') + '</tr>';
          }).join('') + '</tbody></table>';
      applyChartView(id);
    }

    function baseOptions(fmtTick, fmtTip, legend) {
      return {
        responsive: true, maintainAspectRatio: false,
        animation: firstPaint ? { duration: 500 } : false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: legend ? { display: true, position: 'top', align: 'start', labels: { boxWidth: 10, boxHeight: 10, usePointStyle: true, pointStyle: 'rectRounded', color: C.ink2, font: { size: 12 } } } : { display: false },
          tooltip: {
            backgroundColor: '#0f172a', padding: 10, cornerRadius: 8, titleFont: { weight: '700' },
            callbacks: { label: function (ctx) { return ' ' + ctx.dataset.label + ': ' + fmtTip(ctx.parsed.y); } },
          },
        },
        scales: {
          x: { grid: { display: false }, border: { color: C.axis }, ticks: { color: C.muted, font: { size: 11 } } },
          y: { beginAtZero: true, grid: { color: C.grid }, border: { display: false },
               ticks: { color: C.muted, font: { size: 11 }, precision: 0, callback: function (v) { return fmtTick(v); } } },
        },
      };
    }

    function drawChart(id, config) {
      var canvas = document.getElementById(id);
      if (!canvas || typeof Chart === 'undefined') return;
      if (charts[id]) charts[id].destroy();
      charts[id] = new Chart(canvas, config);
    }

    // ---- by module: Clients / Technicians / Warehouse --------------------------------
    // One module is on screen at a time (a hidden canvas has no size to draw into),
    // and the choice is remembered per browser.
    var MODULES = [
      { key: 'clients', label: 'Clients', icon: 'fa-users' },
      { key: 'technicians', label: 'Technicians', icon: 'fa-user-gear' },
      { key: 'warehouse', label: 'Warehouse', icon: 'fa-warehouse' },
    ];
    var moduleTab = 'clients';
    try {
      var savedTab = localStorage.getItem('std-module');
      if (MODULES.some(function (m) { return m.key === savedTab; })) moduleTab = savedTab;
    } catch (e) { /* storage blocked — keep the default */ }
    var moduleCharts = [];
    var SLOTS = [C.series1, C.series2, C.series3];

    function small(text) { return ' <span style="font-size:13px;color:#94a3b8;font-weight:600">' + text + '</span>'; }
    function sum(list, key) { return list.reduce(function (s, x) { return s + (Number(x[key]) || 0); }, 0); }
    function soFar(labels) { return labels.map(function (l, i) { return i === labels.length - 1 ? l + ' (so far)' : l; }); }

    // Keep the first `max` slices and fold the rest into "Other", so a doughnut
    // never needs more than the validated categorical slots.
    function fold(list, labelKey, valueKey, max) {
      if (list.length <= max) return list.slice();
      var head = list.slice(0, max - 1);
      var other = {}; other[labelKey] = 'Other'; other[valueKey] = sum(list.slice(max - 1), valueKey); other.isOther = true;
      return head.concat([other]);
    }

    function monthDelta(now, prev) {
      now = Number(now) || 0; prev = Number(prev) || 0;
      if (now === prev) return '<span class="std-chip" style="background:#f1f5f9;color:#475569"><i class="fas fa-equals"></i>Same as last month</span>';
      var up = now > prev;
      return '<span class="std-chip" style="background:' + (up ? '#ecfdf5;color:#047857' : '#fef2f2;color:#b91c1c') + '"><i class="fas fa-arrow-' + (up ? 'up' : 'down') + '"></i>'
        + (up ? '+' : '−') + n(Math.abs(now - prev)) + ' vs last month (' + n(prev) + ')</span>';
    }

    function moduleChart(id, title, sub, icon, height) {
      moduleCharts.push(id);
      var h = height || 240;
      return card(title, sub,
        '<div class="std-chart" id="' + id + '-wrap" style="height:' + h + 'px"><canvas id="' + id + '" role="img" aria-label="' + esc(title) + '"></canvas></div>'
        + '<div id="' + id + '-table" style="display:none;max-height:' + Math.max(h, 240) + 'px;overflow:auto"></div>',
        { icon: icon, style: 'box-shadow:none', action: '<button type="button" class="std-toggle" data-toggle-table="' + id + '"><i class="fas fa-table-list"></i> <span>Table</span></button>' });
    }
    function emptyCard(title, message, icon) {
      return card(title, '', '<p class="std-cap" style="padding:24px 0;text-align:center"><i class="fas fa-inbox" style="display:block;font-size:22px;color:#cbd5e1;margin-bottom:8px"></i>' + esc(message) + '</p>',
        { icon: icon, style: 'box-shadow:none' });
    }

    function hBarOptions(fmtTip, stacked, legend) {
      var o = baseOptions(function (v) { return n(v); }, fmtTip, legend);
      o.indexAxis = 'y';
      o.interaction = { mode: 'index', axis: 'y', intersect: false };
      o.plugins.tooltip.callbacks.label = function (ctx) { return ' ' + ctx.dataset.label + ': ' + fmtTip(ctx.parsed.x); };
      o.scales = {
        x: { beginAtZero: true, stacked: !!stacked, grid: { color: C.grid }, border: { display: false },
             ticks: { color: C.muted, font: { size: 11 }, precision: 0 } },
        y: { stacked: !!stacked, grid: { display: false }, border: { color: C.axis },
             ticks: { color: C.ink2, font: { size: 11.5 }, autoSkip: false,
                      callback: function (v) { var l = String(this.getLabelForValue(v)); return l.length > 26 ? l.slice(0, 25) + '…' : l; } } },
      };
      return o;
    }

    function doughnutOptions(fmtTip, total) {
      return {
        responsive: true, maintainAspectRatio: false, cutout: '62%',
        animation: firstPaint ? { duration: 500 } : false,
        plugins: {
          legend: { display: true, position: 'bottom', labels: { boxWidth: 10, boxHeight: 10, usePointStyle: true, pointStyle: 'rectRounded', color: C.ink2, font: { size: 12 }, padding: 14 } },
          tooltip: {
            backgroundColor: '#0f172a', padding: 10, cornerRadius: 8, titleFont: { weight: '700' },
            callbacks: { label: function (ctx) {
              var pct = total ? Math.round(ctx.parsed * 100 / total) : 0;
              return ' ' + ctx.label + ': ' + fmtTip(ctx.parsed) + ' (' + pct + '%)';
            } },
          },
        },
      };
    }

    var hBarStyle = { borderRadius: { topRight: 4, bottomRight: 4 }, borderSkipped: 'start', maxBarThickness: 18, categoryPercentage: 0.8, barPercentage: 0.85 };

    function clientsModule(c) {
      var k = c.kpis, a = c.acquisition;
      var types = fold(c.system_types, 'key', 'count', 3);
      var typeTotal = sum(types, 'count');
      var tiles = [
        { label: 'Active clients', icon: 'fa-users', color: C.series1, tint: '#eff6ff', target: 'clients', value: n(k.active),
          caption: n(k.total) + ' clients on record · ' + plural(k.total - k.active, 'has', 'have') + ' an inactive account' },
        { label: 'New clients this month', icon: 'fa-user-plus', color: '#047857', tint: '#ecfdf5', target: 'clients', value: n(k.new_this_month),
          caption: 'Registered since the 1st of this month', extra: monthDelta(k.new_this_month, k.new_last_month) },
        { label: 'Pending service enquiries', icon: 'fa-ticket', color: k.pending_enquiries ? '#b45309' : C.ink2, tint: k.pending_enquiries ? '#fffbeb' : '#f1f5f9',
          target: 'service_requests', value: n(k.pending_enquiries),
          caption: k.pending_enquiries ? 'New service requests waiting for review' : 'Nothing is waiting for review' },
      ];
      return {
        html: '<div class="std-grid-4 std-n3">' + tiles.map(function (o) { return tile(o, targets); }).join('') + '</div>'
          + '<div class="std-charts-2">'
          +   moduleChart('std-mod-cl-growth', 'Client growth', 'Total clients at the end of each month, last 6 months.', 'fa-chart-line')
          +   (typeTotal
                ? moduleChart('std-mod-cl-types', 'Installed system types', plural(typeTotal, 'project', 'projects') + ' by system type (cancelled ones excluded).', 'fa-solar-panel')
                : emptyCard('Installed system types', 'No projects recorded yet.', 'fa-solar-panel'))
          + '</div>',
        draw: function () {
          var labels = soFar(a.labels);
          var opts = baseOptions(function (v) { return n(v); }, n, false);
          opts.scales.y.beginAtZero = false; // a running total: start near the data so growth is visible
          opts.plugins.tooltip.callbacks.label = function (ctx) {
            return ' ' + plural(ctx.parsed.y, 'client', 'clients') + ' in total (+' + n(a.new[ctx.dataIndex]) + ' new that month)';
          };
          drawChart('std-mod-cl-growth', {
            type: 'line',
            data: { labels: labels, datasets: [{
              label: 'Total clients', data: a.total, borderColor: C.series1, backgroundColor: 'rgba(42,120,214,0.10)', fill: true,
              cubicInterpolationMode: 'monotone', borderWidth: 2, pointRadius: 4, pointHoverRadius: 6,
              pointBackgroundColor: C.series1, pointBorderColor: C.surface, pointBorderWidth: 2,
            }] },
            options: opts,
          });
          chartTable('std-mod-cl-growth', labels, [{ label: 'New', data: a.new }, { label: 'Total', data: a.total }], n);

          if (typeTotal) {
            drawChart('std-mod-cl-types', {
              type: 'doughnut',
              data: { labels: types.map(function (t) { return t.key; }), datasets: [{
                data: types.map(function (t) { return t.count; }),
                backgroundColor: types.map(function (t, i) { return t.isOther ? C.neutral : SLOTS[i]; }),
                borderColor: C.surface, borderWidth: 2, hoverOffset: 4,
              }] },
              options: doughnutOptions(function (v) { return plural(v, 'project', 'projects'); }, typeTotal),
            });
            chartTable('std-mod-cl-types', types.map(function (t) { return t.key; }), [
              { label: 'Projects', data: types.map(function (t) { return n(t.count); }) },
              { label: 'Share', data: types.map(function (t) { return Math.round(t.count * 100 / typeTotal) + '%'; }) },
            ], function (v) { return v; }, 'System type');
          }
        },
      };
    }

    function techniciansModule(t) {
      var k = t.kpis, js = t.job_status, wl = t.workload;
      var tiles = [
        { label: 'Technicians in the field', icon: 'fa-person-digging', color: '#b45309', tint: '#fffbeb', target: 'technicians',
          value: n(k.on_field) + small('of ' + n(k.total)),
          caption: 'On the way, on site or working on a job right now' },
        { label: 'Assigned jobs', icon: 'fa-briefcase', color: C.series1, tint: '#eff6ff', target: 'jobs', value: n(k.assigned_jobs),
          caption: k.unassigned_jobs
            ? '<i class="fas fa-triangle-exclamation" style="color:#b7791f"></i> <b style="color:#92400e">' + plural(k.unassigned_jobs, 'open job has', 'open jobs have') + ' no technician</b>'
            : 'Every open job has a technician' },
        { label: 'Completed today', icon: 'fa-circle-check', color: '#047857', tint: '#ecfdf5', target: 'jobs', value: n(k.completed_today),
          caption: plural(js.completed_30d, 'job', 'jobs') + ' completed in the last 30 days' },
        { label: 'On duty', icon: 'fa-user-clock', color: C.series1, tint: '#eff6ff', target: 'technicians',
          value: n(k.on_duty) + small('of ' + n(k.total)),
          caption: n(k.busy) + ' busy on a job · ' + k.utilization_pct + '% utilization' },
      ];
      var wlHeight = Math.max(160, wl.length * 30 + 60);
      return {
        html: '<div class="std-grid-4">' + tiles.map(function (o) { return tile(o, targets); }).join('') + '</div>'
          + '<div class="std-charts-2">'
          +   moduleChart('std-mod-tc-status', 'Job status', 'Open jobs by stage, next to jobs finished in the last 30 days.', 'fa-chart-column')
          +   (wl.length
                ? moduleChart('std-mod-tc-load', 'Technician workload', 'Open jobs per technician (busiest 10). ' + k.utilization_pct + '% of on-duty technicians are busy right now.', 'fa-users-gear', wlHeight)
                : emptyCard('Technician workload', 'No technician has an open job right now.', 'fa-users-gear'))
          + '</div>',
        draw: function () {
          var labels = ['Waiting to start', 'In progress', 'Completed (30 days)'];
          var values = [js.pending, js.in_progress, js.completed_30d];
          var opts = baseOptions(function (v) { return n(v); }, n, false);
          opts.plugins.tooltip.callbacks.label = function (ctx) { return ' ' + plural(ctx.parsed.y, 'job', 'jobs'); };
          drawChart('std-mod-tc-status', {
            type: 'bar',
            data: { labels: labels, datasets: [{ label: 'Jobs', data: values, backgroundColor: C.series1,
              borderRadius: { topLeft: 4, topRight: 4 }, borderSkipped: 'start', maxBarThickness: 56 }] },
            options: opts,
          });
          chartTable('std-mod-tc-status', labels, [{ label: 'Jobs', data: values }], n, 'Stage');

          if (wl.length) {
            var names = wl.map(function (w) { return w.name; });
            drawChart('std-mod-tc-load', {
              type: 'bar',
              data: { labels: names, datasets: [
                Object.assign({ label: 'In progress', data: wl.map(function (w) { return w.in_progress; }), backgroundColor: C.series1, borderColor: C.surface, borderWidth: 1 }, hBarStyle),
                Object.assign({ label: 'Waiting to start', data: wl.map(function (w) { return w.pending; }), backgroundColor: C.series2, borderColor: C.surface, borderWidth: 1 }, hBarStyle),
              ] },
              options: hBarOptions(function (v) { return plural(v, 'job', 'jobs'); }, true, true),
            });
            chartTable('std-mod-tc-load', names, [
              { label: 'In progress', data: wl.map(function (w) { return w.in_progress; }) },
              { label: 'Waiting to start', data: wl.map(function (w) { return w.pending; }) },
            ], n, 'Technician');
          }
        },
      };
    }

    function warehouseModule(w) {
      var k = w.kpis, top = w.top_issued;
      var cats = fold(w.stock_by_category, 'category', 'value', 3);
      var catTotal = sum(cats, 'value');
      var alerts = k.low_stock + k.out_of_stock;
      var rq = k.requests_by_status || {};
      var tiles = [
        { label: 'Total stock value', icon: 'fa-peso-sign', color: '#047857', tint: '#ecfdf5', target: 'inventory', value: peso(k.stock_value),
          caption: 'At cost, excluding discontinued items' },
        { label: 'Low-stock alerts', icon: 'fa-boxes-stacked', color: k.out_of_stock ? C.critical : (alerts ? '#b45309' : C.ink2),
          tint: k.out_of_stock ? '#fef2f2' : (alerts ? '#fffbeb' : '#f1f5f9'), target: 'inventory', value: n(alerts) + small(alerts === 1 ? 'item' : 'items'),
          caption: k.out_of_stock
            ? '<i class="fas fa-circle-exclamation" style="color:' + C.critical + '"></i> <b style="color:#b91c1c">' + n(k.out_of_stock) + ' out of stock</b> · ' + n(k.low_stock) + ' running low'
            : (alerts ? n(k.low_stock) + ' running low' : 'Nothing is running low') },
        { label: 'Pending material requests', icon: 'fa-dolly', color: C.series1, tint: '#eff6ff', target: 'orders',
          value: k.orders_tracked ? n(k.pending_requests) : '—',
          caption: k.orders_tracked
            ? n(rq.PENDING) + ' new · ' + n(rq.PREPARING) + ' being prepared · ' + n(rq.READY) + ' ready to release'
            : 'Material requests are not set up yet (database migration phase 5).' },
        { label: 'Items issued today', icon: 'fa-truck-ramp-box', color: C.series1, tint: '#eff6ff', target: 'inventory',
          value: n(k.issued_today_units) + small(k.issued_today_units === 1 ? 'unit' : 'units'),
          caption: plural(k.issued_today_moves, 'stock issue', 'stock issues') + ' recorded today' },
      ];
      var topHeight = Math.max(160, top.length * 30 + 40);
      return {
        html: '<div class="std-grid-4">' + tiles.map(function (o) { return tile(o, targets); }).join('') + '</div>'
          + '<div class="std-charts-2">'
          +   (top.length
                ? moduleChart('std-mod-wh-top', 'Most-issued items', 'Units issued from the warehouse in the last 90 days (top ' + top.length + ').', 'fa-ranking-star', topHeight)
                : emptyCard('Most-issued items', 'Nothing was issued in the last 90 days.', 'fa-ranking-star'))
          +   (catTotal
                ? moduleChart('std-mod-wh-cat', 'Stock value by category', peso(catTotal) + ' on hand at cost.', 'fa-chart-pie')
                : emptyCard('Stock value by category', 'No stock on hand.', 'fa-chart-pie'))
          + '</div>',
        draw: function () {
          if (top.length) {
            var names = top.map(function (t) { return t.label; });
            drawChart('std-mod-wh-top', {
              type: 'bar',
              data: { labels: names, datasets: [Object.assign({ label: 'Issued', data: top.map(function (t) { return t.units; }), backgroundColor: C.series1 }, hBarStyle)] },
              options: hBarOptions(function (v) { return plural(v, 'unit', 'units'); }, false, false),
            });
            chartTable('std-mod-wh-top', names, [
              { label: 'SKU', data: top.map(function (t) { return esc(t.sku); }) },
              { label: 'Units', data: top.map(function (t) { return n(t.units); }) },
            ], function (v) { return v; }, 'Item');
          }
          if (catTotal) {
            drawChart('std-mod-wh-cat', {
              type: 'doughnut',
              data: { labels: cats.map(function (c) { return c.category; }), datasets: [{
                data: cats.map(function (c) { return c.value; }),
                backgroundColor: cats.map(function (c, i) { return c.isOther ? C.neutral : SLOTS[i]; }),
                borderColor: C.surface, borderWidth: 2, hoverOffset: 4,
              }] },
              options: doughnutOptions(peso, catTotal),
            });
            chartTable('std-mod-wh-cat', cats.map(function (c) { return c.category; }), [
              { label: 'Units', data: cats.map(function (c) { return c.isOther ? '—' : n(c.units); }) },
              { label: 'Value', data: cats.map(function (c) { return peso(c.value); }) },
              { label: 'Share', data: cats.map(function (c) { return Math.round(c.value * 100 / catTotal) + '%'; }) },
            ], function (v) { return v; }, 'Category');
          }
        },
      };
    }

    function renderModules(m) {
      var el = document.getElementById('std-modules');
      if (!el) return;
      moduleCharts.forEach(function (id) { if (charts[id]) { charts[id].destroy(); delete charts[id]; } });
      moduleCharts = [];

      var head = '<div style="display:flex;flex-wrap:wrap;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:14px">'
        + '<div><h3 class="std-h"><i class="fas fa-layer-group" style="color:#f97316"></i>By module</h3>'
        + '<p class="std-sub">Key figures and trends for clients, field technicians and the warehouse.'
        + (m.is_demo ? ' <span class="std-badge" style="background:#fffbeb;color:#92400e"><i class="fas fa-flask"></i>Sample data — not from the database</span>' : '')
        + '</p></div>'
        + '<div class="std-seg" role="tablist" aria-label="Module">' + MODULES.map(function (x) {
            return '<button type="button" role="tab" aria-selected="' + (x.key === moduleTab) + '" data-module="' + x.key + '"><i class="fas ' + x.icon + '"></i>' + x.label + '</button>';
          }).join('') + '</div>'
        + '</div>';

      var mod = m[moduleTab];
      if (!mod || !mod.available) {
        el.innerHTML = head + '<p class="std-cap" style="padding:12px 0"><i class="fas fa-circle-exclamation" style="color:' + C.critical + '"></i> '
          + 'These figures could not be loaded. The rest of the dashboard is unaffected.</p>';
        return;
      }
      var view = moduleTab === 'clients' ? clientsModule(mod) : (moduleTab === 'technicians' ? techniciansModule(mod) : warehouseModule(mod));
      el.innerHTML = head + '<div role="tabpanel">' + view.html + '</div>';
      view.draw();
    }

    function render(d) {
      var h = d.headline;
      var b = d.breakdowns;
      // The current month is still in progress: say so, so a low last bar is
      // not read as a collapse.
      var t = Object.assign({}, d.trends, {
        labels: d.trends.labels.map(function (l, i, all) { return i === all.length - 1 ? l + ' (so far)' : l; }),
      });

      // -- headline tiles ------------------------------------------------------
      var tiles = [
        { label: 'Open service requests', icon: 'fa-ticket', color: C.series1, tint: '#eff6ff', target: 'service_requests',
          value: n(h.sr_open),
          caption: plural(h.sr_pending, 'new request waits', 'new requests wait') + ' for review · ' + plural(h.sr_urgent_open, 'is', 'are') + ' urgent or high priority' },
        { label: 'Work in the field', icon: 'fa-person-digging', color: '#b45309', tint: '#fffbeb', target: 'jobs',
          value: n(h.jobs_in_field),
          caption: 'Jobs on the way or on site now · ' + plural(h.tech_on_site, 'technician is', 'technicians are') + ' timed in · ' + n(h.jobs_open) + ' open jobs in total' },
        { label: 'Jobs completed · 30 days', icon: 'fa-circle-check', color: '#047857', tint: '#ecfdf5', target: 'jobs',
          value: n(h.jobs_completed_30d),
          caption: 'Installations, repairs, inspections and maintenance finished',
          extra: delta(h.jobs_completed_30d, h.jobs_completed_prev, false) },
        { label: 'Money collected · 30 days', icon: 'fa-peso-sign', color: '#047857', tint: '#ecfdf5', target: 'billing',
          value: peso(h.collected_30d),
          caption: 'Payments recorded against invoices',
          extra: delta(h.collected_30d, h.collected_prev_30d, true) },
        { label: 'Still to collect', icon: 'fa-hand-holding-dollar', color: h.overdue_amount > 0 ? C.critical : C.ink2, tint: h.overdue_amount > 0 ? '#fef2f2' : '#f1f5f9', target: 'billing',
          value: peso(h.receivable),
          caption: h.overdue_amount > 0
            ? '<i class="fas fa-circle-exclamation" style="color:' + C.critical + '"></i> <b style="color:#b91c1c">' + peso(h.overdue_amount) + ' overdue</b> on ' + plural(h.overdue_invoices, 'invoice', 'invoices')
            : 'Nothing is overdue' },
        { label: 'Solar systems running', icon: 'fa-solar-panel', color: '#ea580c', tint: '#fff7ed', target: 'projects',
          value: n(h.systems_active),
          caption: n(Math.round(h.capacity_kw_active * 10) / 10) + ' kW installed capacity · ' + plural(h.projects_installing, 'installation', 'installations') + ' in progress' },
      ];

      var minis = [
        { label: 'Clients', icon: 'fa-users', color: C.series1, target: 'clients', value: n(h.clients_total),
          caption: n(h.clients_active) + ' active · ' + n(h.clients_new_30d) + ' new in 30 days' },
        { label: 'Technicians free', icon: 'fa-user-gear', color: C.series1, target: 'technicians', value: n(h.tech_available) + ' <span style="font-size:13px;color:#94a3b8;font-weight:600">of ' + n(h.tech_total) + '</span>',
          caption: n(h.tech_busy) + ' busy on a job right now' },
        { label: 'Maintenance', icon: 'fa-wrench', color: h.maint_overdue ? C.critical : C.series1, target: 'maintenance',
          value: n(h.maint_overdue + h.maint_due) + ' <span style="font-size:13px;color:#94a3b8;font-weight:600">need a visit</span>',
          caption: n(h.maint_overdue) + ' overdue · ' + n(h.maint_due) + ' due within 14 days' },
        { label: 'Stock alerts', icon: 'fa-boxes-stacked', color: h.stock_out ? C.critical : C.series1, target: 'inventory',
          value: n(h.stock_low + h.stock_out) + ' <span style="font-size:13px;color:#94a3b8;font-weight:600">items</span>',
          caption: n(h.stock_out) + ' out of stock · ' + n(h.stock_low) + ' running low' },
        { label: 'Client orders', icon: 'fa-dolly', color: C.series1, target: 'orders', value: n(h.orders_open) + ' <span style="font-size:13px;color:#94a3b8;font-weight:600">open</span>',
          caption: n(h.orders_ready) + ' packed and ready to release' },
      ];


      // -- breakdowns ----------------------------------------------------------------
      var prjLabels = { PLANNED: 'Planned', SCHEDULED: 'Scheduled', IN_PROGRESS: 'Being installed', MAINTENANCE: 'Under maintenance', COMPLETED: 'Installed', CANCELLED: 'Cancelled' };
      var prjBars = hbars(b.projects.map(function (p) {
        return { label: prjLabels[p.key] || nice(p.key), count: p.count, color: p.key === 'CANCELLED' ? C.closed : C.series1 };
      }), { labelWidth: '130px' });

      var inv = b.invoices;
      var invStack = stack([
        { label: 'Paid', hint: plural(inv.PAID.count, 'invoice', 'invoices'), value: inv.PAID.amount, color: C.good, icon: 'fa-circle-check' },
        { label: 'Pending', hint: plural(inv.PENDING.count, 'invoice', 'invoices'), value: inv.PENDING.amount, color: C.warning, icon: 'fa-clock' },
        { label: 'Overdue', hint: plural(inv.OVERDUE.count, 'invoice', 'invoices'), value: inv.OVERDUE.amount, color: C.critical, icon: 'fa-circle-exclamation' },
        { label: 'Cancelled', hint: plural(inv.CANCELLED.count, 'invoice', 'invoices'), value: inv.CANCELLED.amount, color: C.neutral, icon: 'fa-ban' },
      ], pesoShort);

      // -- activity --------------------------------------------------------------------------
      var activity = d.activity.length
        ? '<div style="display:flex;flex-direction:column">' + d.activity.map(function (a) {
            var s = sentence(a);
            return '<div style="display:flex;gap:10px;padding:9px 0;border-bottom:1px solid #f1f5f9">'
              + '<span class="std-ico" style="width:28px;height:28px;font-size:12px;background:#f1f5f9;color:#475569"><i class="fas ' + (MODULE_ICON[a.module] || 'fa-clock-rotate-left') + '"></i></span>'
              + '<span style="flex:1;font-size:13px;color:#334155;line-height:1.4"><b style="color:#0f172a">' + esc(s.who) + '</b> ' + esc(s.text)
              + '<span style="display:block;font-size:11.5px;color:#94a3b8">' + esc(ago(a.created_at)) + '</span></span></div>';
          }).join('') + '</div>'
        : '<p class="std-cap">No activity recorded yet.</p>';

      var updated = parseTs(d.generated_at);
      root.innerHTML = ''
        + '<div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:10px;margin-bottom:var(--std-gap)">'
        +   '<p class="std-cap"><i class="fas fa-circle" style="color:' + C.good + ';font-size:8px"></i> Live — updates automatically when anything changes. Last updated '
        +     esc(updated ? updated.toLocaleTimeString('en-PH', { hour: 'numeric', minute: '2-digit' }) : '') + '.'
        +     (cfg.viewOnly ? ' <span class="std-badge" style="background:#f1f5f9;color:#475569"><i class="fas fa-eye"></i>View only</span>' : '') + '</p>'
        +   '<button type="button" class="std-toggle" data-refresh="1"><i class="fas fa-rotate"></i> Refresh</button>'
        + '</div>'
        + '<div class="std-grid-6">' + tiles.map(function (o) { return tile(o, targets); }).join('') + '</div>'
        + '<div class="std-grid-5" style="margin-top:12px">' + minis.map(function (o) { return miniTile(o, targets); }).join('') + '</div>'
        + (d.modules ? '<section class="std-card" id="std-modules" style="margin-top:var(--std-gap)"></section>' : '')
        + '<div style="display:grid;gap:var(--std-gap);margin-top:var(--std-gap)" class="std-three">'
        +   chartCard('std-chart-work', 'Work completed per month', 'Jobs finished in each of the last 6 months.', 'fa-chart-column')
        +   chartCard('std-chart-money', 'Money collected per month', 'Total payments recorded each month.', 'fa-chart-line')
        +   chartCard('std-chart-requests', 'Service requests received per month', 'New requests from clients and the office.', 'fa-chart-column')
        + '</div>'
        + '<div style="display:grid;gap:var(--std-gap);margin-top:var(--std-gap)" class="std-pair">'
        +   card('Installation projects', n(h.projects_total) + ' projects in total.', prjBars,
               { icon: 'fa-diagram-project', action: targets.projects ? '<button type="button" class="std-toggle" data-nav="' + esc(targets.projects) + '">Open</button>' : '' })
        +   card('Invoices by status', 'Invoice value in each payment status.', invStack,
               { icon: 'fa-file-invoice-dollar', action: targets.billing ? '<button type="button" class="std-toggle" data-nav="' + esc(targets.billing) + '">Open</button>' : '' })
        + '</div>'
        + '<div style="margin-top:var(--std-gap)">'
        +   card('Recent activity', 'The latest changes made in the system.', activity,
               { icon: 'fa-clock-rotate-left', action: targets.logs ? '<button type="button" class="std-toggle" data-nav="' + esc(targets.logs) + '">Full log</button>' : '' })
        + '</div>';

      // Responsive columns for the card rows (kept here so the CSS block stays generic).
      var mq = window.matchMedia('(min-width:1100px)').matches;
      var mqMid = window.matchMedia('(min-width:760px)').matches;
      // minmax(0, …): a column may shrink below its longest line, so nothing
      // pushes the page wider than a phone screen.
      root.querySelectorAll('.std-three').forEach(function (el) { el.style.gridTemplateColumns = mq ? 'repeat(3,minmax(0,1fr))' : (mqMid ? 'repeat(2,minmax(0,1fr))' : 'minmax(0,1fr)'); });
      root.querySelectorAll('.std-pair').forEach(function (el) { el.style.gridTemplateColumns = mqMid ? 'repeat(2,minmax(0,1fr))' : 'minmax(0,1fr)'; });

      // -- charts ----------------------------------------------------------------------------------
      var barStyle = { borderRadius: { topLeft: 4, topRight: 4 }, borderSkipped: 'start', maxBarThickness: 26, categoryPercentage: 0.7, barPercentage: 0.85 };
      drawChart('std-chart-work', {
        type: 'bar',
        data: { labels: t.labels, datasets: [
          Object.assign({ label: 'Installations', data: t.installations_done, backgroundColor: C.series1, borderColor: C.surface, borderWidth: 1 }, barStyle),
          Object.assign({ label: 'Service & maintenance', data: t.service_jobs_done, backgroundColor: C.series2, borderColor: C.surface, borderWidth: 1 }, barStyle),
        ] },
        options: baseOptions(function (v) { return n(v); }, function (v) { return plural(v, 'job', 'jobs'); }, true),
      });
      chartTable('std-chart-work', t.labels, [
        { label: 'Installations', data: t.installations_done }, { label: 'Service & maintenance', data: t.service_jobs_done },
      ], n);

      drawChart('std-chart-money', {
        type: 'line',
        data: { labels: t.labels, datasets: [{
          label: 'Collected', data: t.collected, borderColor: C.series1, backgroundColor: 'rgba(42,120,214,0.10)', fill: true,
          // Monotone: the line never swings above or below the real values between months.
          cubicInterpolationMode: 'monotone', borderWidth: 2, pointRadius: 4, pointHoverRadius: 6, pointBackgroundColor: C.series1, pointBorderColor: C.surface, pointBorderWidth: 2,
        }] },
        options: baseOptions(pesoShort, peso, false),
      });
      chartTable('std-chart-money', t.labels, [{ label: 'Collected', data: t.collected }], peso);

      drawChart('std-chart-requests', {
        type: 'bar',
        data: { labels: t.labels, datasets: [Object.assign({ label: 'Requests', data: t.requests_received, backgroundColor: C.series1 }, barStyle)] },
        options: baseOptions(function (v) { return n(v); }, function (v) { return plural(v, 'request', 'requests'); }, false),
      });
      chartTable('std-chart-requests', t.labels, [{ label: 'Requests', data: t.requests_received }], n);

      if (d.modules) renderModules(d.modules);
      firstPaint = false;
    }

    var again = false;
    function refresh() {
      if (busy) { again = true; return Promise.resolve(); } // run once more when this one finishes
      busy = true;
      if (data) root.classList.add('std-dim'); // keep the last render on screen while loading
      else root.innerHTML = '<p class="std-cap" style="padding:24px 0"><i class="fas fa-spinner fa-spin"></i> Loading the dashboard…</p>';
      return fetch(cfg.endpoint, { headers: { Accept: 'application/json' }, credentials: 'same-origin' })
        .then(function (res) { return res.json(); })
        .then(function (json) {
          if (!json.success) throw new Error(json.message || 'The dashboard could not be loaded.');
          data = json.data;
          render(data);
        })
        .catch(function (err) {
          if (!data) {
            root.innerHTML = '<div class="std-card" style="color:#b91c1c"><i class="fas fa-circle-exclamation"></i> ' + esc(err.message || 'The dashboard could not be loaded.')
              + ' <button type="button" class="std-toggle" data-refresh="1" style="margin-left:8px">Try again</button></div>';
          }
        })
        .then(function () {
          busy = false;
          root.classList.remove('std-dim');
          if (again) { again = false; refresh(); }
        });
    }

    var resizeTimer = null;
    window.addEventListener('resize', function () {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(function () { if (data && root.offsetParent !== null) render(data); }, 250);
    });

    return { refresh: refresh };
  }

  global.SunTrackDashboard = { mount: mount };
})(window);
