/**
 * SunTrack ERP — Admin dashboard (general, system-wide summary).
 *
 *   const dash = SunTrackAdminDashboard.mount({
 *     root:     document.getElementById('sad-root'),
 *     endpoint: '../api/dashboard/admin.php',
 *     navigate: (tabKey) => showTab(tabKey),
 *   });
 *   dash.refresh();
 *
 * One reporting period (7 days / 30 days / 12 months) drives the time-based
 * card and the line graph. The page holds exactly:
 *   - four summary cards (Total Clients, Active Jobs, Completed Jobs, Needs Attention)
 *   - one line graph  (Job Completion Trend)
 *   - one pie graph   (Overall Job Status)
 *   - a short Needs Attention list (max 5)
 *   - the Clients / Technicians / Warehouse buttons, each showing that
 *     module's key figures (tiles, no extra charts) and a link into it.
 *
 * Every chart has a table view and every colour sits next to a text label.
 * Colours: categorical slots of the shared data-viz palette, one fixed colour
 * per status, validated (light surface) with scripts/validate_palette.js.
 * Used by Admin and Management. Links are written with Admin tab keys;
 * pass `tabs` / `tabNames` to map them onto another portal's tabs.
 */
(function (global) {
  'use strict';

  var C = {
    completed: '#1baf7a',   // aqua   — slot 3
    inProgress: '#2a78d6',  // blue   — slot 1
    pending: '#eb6834',     // orange — slot 2
    onHold: '#4a3aa7',      // violet — slot 7 (orange↔yellow failed the normal-vision floor)
    created: '#2a78d6',     // "New jobs" line — blue
    critical: '#d03b3b', warning: '#fab219',
    grid: '#e1e0d9', axis: '#c3c2b7', muted: '#898781', ink: '#0f172a', ink2: '#52514e', surface: '#ffffff',
  };

  var PERIODS = [
    { key: '7d', label: '7 days' },
    { key: '30d', label: '30 days' },
    { key: '12m', label: '12 months' },
  ];

  var STATUS = [
    { key: 'completed', label: 'Completed', color: C.completed, hint: 'Finished' },
    { key: 'in_progress', label: 'In Progress', color: C.inProgress, hint: 'En route, on site or working' },
    { key: 'pending', label: 'Pending', color: C.pending, hint: 'Submitted or assigned, not started' },
    { key: 'on_hold', label: 'On Hold', color: C.onHold, hint: 'Paused' },
  ];

  var MODULES = [
    { key: 'clients', label: 'Clients', icon: 'fa-users', tab: 'clients' },
    { key: 'technicians', label: 'Technicians', icon: 'fa-user-gear', tab: 'technicians' },
    { key: 'warehouse', label: 'Warehouse', icon: 'fa-warehouse', tab: 'inventory' },
  ];

  var STYLE = ''
    + '.sad{color:#0f172a;--sad-gap:20px}'
    + '.sad .sad-card{background:#fff;border:1px solid #eef0f4;border-radius:16px;box-shadow:0 1px 3px rgba(15,23,42,.05);padding:20px 22px;min-width:0}'
    + '.sad .sad-head{display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:12px;margin-bottom:var(--sad-gap)}'
    + '.sad .sad-h{font-size:15px;font-weight:700;display:flex;align-items:center;gap:8px;margin:0}'
    + '.sad .sad-sub{font-size:12.5px;color:#64748b;margin:3px 0 0}'
    + '.sad .sad-seg{display:inline-flex;gap:2px;padding:3px;background:#f1f5f9;border-radius:12px;flex-wrap:wrap}'
    + '.sad .sad-seg button{font-size:12.5px;font-weight:700;color:#475569;padding:7px 13px;border-radius:9px;display:inline-flex;align-items:center;gap:6px;border:0;background:transparent;cursor:pointer}'
    + '.sad .sad-seg button:hover{color:#0f172a}'
    + '.sad .sad-seg button[aria-pressed="true"],.sad .sad-seg button[aria-selected="true"]{background:#fff;color:#0f172a;box-shadow:0 1px 3px rgba(0,0,0,.08)}'
    + '.sad .sad-seg button:focus-visible,.sad .sad-btn:focus-visible,.sad .sad-kpi:focus-visible,.sad .sad-alert:focus-visible{outline:2px solid #f97316;outline-offset:2px}'
    + '.sad .sad-btn{font-size:12px;font-weight:700;color:#475569;border:1px solid #e2e8f0;border-radius:9px;padding:6px 11px;background:#fff;cursor:pointer;display:inline-flex;align-items:center;gap:6px}'
    + '.sad .sad-btn:hover{border-color:#f97316;color:#ea580c}'
    + '.sad .sad-kpis{display:grid;gap:16px;grid-template-columns:minmax(0,1fr)}'
    + '@media(min-width:620px){.sad .sad-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}}'
    + '@media(min-width:1180px){.sad .sad-kpis{grid-template-columns:repeat(4,minmax(0,1fr))}}'
    + '.sad .sad-section-h{display:flex;flex-wrap:wrap;align-items:baseline;justify-content:space-between;gap:8px;margin:var(--sad-gap) 0 10px}'
    + '.sad .sad-kpi.sad-compact{padding:14px 16px;gap:4px}'
    + '.sad .sad-compact .sad-val{font-size:24px}'
    + '.sad .sad-compact .sad-ico{width:32px;height:32px;font-size:14px;border-radius:9px}'
    + '.sad .sad-unit{font-size:13px;font-weight:600;color:#94a3b8;margin-left:4px}'
    + '.sad .sad-kpi{text-align:left;width:100%;display:flex;flex-direction:column;gap:8px;font:inherit;color:inherit}'
    + '.sad button.sad-kpi{cursor:pointer;transition:border-color .15s,box-shadow .15s}'
    + '.sad button.sad-kpi:hover{border-color:#fdba74;box-shadow:0 6px 18px rgba(249,115,22,.12)}'
    + '.sad .sad-kpi-top{display:flex;align-items:center;justify-content:space-between;gap:8px}'
    + '.sad .sad-ico{width:38px;height:38px;border-radius:11px;display:inline-flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0}'
    + '.sad .sad-scope{font-size:11px;font-weight:700;color:#64748b;background:#f1f5f9;border-radius:999px;padding:3px 9px;white-space:nowrap}'
    + '.sad .sad-val{font-size:32px;font-weight:800;line-height:1.05;font-variant-numeric:tabular-nums}'
    + '.sad .sad-lbl{font-size:13px;font-weight:700;color:#334155}'
    + '.sad .sad-cap{font-size:12.5px;color:#64748b;line-height:1.4}'
    + '.sad .sad-open{font-size:12px;font-weight:700;color:#ea580c;margin-top:auto}'
    + '.sad .sad-charts{display:grid;gap:var(--sad-gap);grid-template-columns:minmax(0,1fr);margin-top:var(--sad-gap)}'
    + '@media(min-width:1100px){.sad .sad-charts{grid-template-columns:minmax(0,1.7fr) minmax(0,1fr)}}'
    + '.sad .sad-card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:14px}'
    + '.sad .sad-chart{position:relative;height:280px}'
    + '.sad .sad-pie{position:relative;height:220px}'
    + '.sad .sad-empty{height:100%;min-height:180px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;color:#94a3b8;font-size:13px;text-align:center}'
    + '.sad .sad-legend{display:flex;flex-direction:column;gap:7px;margin-top:14px}'
    + '.sad .sad-legend-row{display:grid;grid-template-columns:12px 1fr auto 44px;align-items:center;gap:8px;font-size:12.5px}'
    + '.sad .sad-sw{width:12px;height:12px;border-radius:3px}'
    + '.sad .sad-line-legend{display:flex;flex-wrap:wrap;gap:16px;font-size:12.5px;color:#334155;margin-bottom:8px}'
    + '.sad .sad-line-legend span{display:inline-flex;align-items:center;gap:6px}'
    + '.sad .sad-line-legend i{display:inline-block;width:18px;height:0;border-top:2px solid}'
    + '.sad table.sad-table{width:100%;font-size:12.5px;border-collapse:collapse}'
    + '.sad table.sad-table th{font-size:11px;text-transform:uppercase;color:#94a3b8;font-weight:700;text-align:left;padding:6px 8px;border-bottom:1px solid #eef0f4;position:sticky;top:0;background:#fff}'
    + '.sad table.sad-table td{padding:7px 8px;border-bottom:1px solid #f1f5f9;font-variant-numeric:tabular-nums}'
    + '.sad .sad-alerts{display:flex;flex-direction:column;gap:6px}'
    + '.sad .sad-alert{display:grid;grid-template-columns:auto 1fr auto;align-items:center;gap:14px;padding:12px 14px;border-radius:12px;border:1px solid #f1f5f9;background:#fff;text-align:left;font:inherit;color:inherit;width:100%}'
    + '.sad button.sad-alert{cursor:pointer}'
    + '.sad button.sad-alert:hover{background:#f8fafc;border-color:#e2e8f0}'
    + '.sad .sad-count{font-size:20px;font-weight:800;min-width:40px;text-align:right;font-variant-numeric:tabular-nums}'
    + '.sad .sad-tag{font-size:11px;font-weight:700;padding:2px 8px;border-radius:999px;display:inline-flex;align-items:center;gap:4px;white-space:nowrap}'
    + '.sad .sad-tiles{display:grid;gap:12px;grid-template-columns:minmax(0,1fr)}'
    + '@media(min-width:620px){.sad .sad-tiles{grid-template-columns:repeat(2,minmax(0,1fr))}}'
    + '@media(min-width:1180px){.sad .sad-tiles{grid-template-columns:repeat(4,minmax(0,1fr))}}'
    + '.sad .sad-tile{border:1px solid #eef0f4;border-radius:12px;padding:14px 16px;display:flex;flex-direction:column;gap:4px;background:#fcfcfb}'
    + '.sad .sad-tile b{font-size:22px;font-weight:800;font-variant-numeric:tabular-nums}'
    + '.sad .sad-dim{opacity:.55;transition:opacity .2s}';

  var nf = new Intl.NumberFormat('en-PH');
  function n(v) { return nf.format(Number(v) || 0); }
  function peso(v) { return '₱' + new Intl.NumberFormat('en-PH', { maximumFractionDigits: 0 }).format(Number(v) || 0); }
  function plural(count, one, many) { return n(count) + ' ' + (Number(count) === 1 ? one : many); }
  function esc(v) {
    if (v === null || v === undefined) return '';
    return String(v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; });
  }
  function pct(part, total) { return total ? Math.round(part * 1000 / total) / 10 : 0; }

  function mount(cfg) {
    var root = cfg.root;
    var charts = {};
    var tableView = {};
    var data = null;
    var reqId = 0;
    var period = '7d';
    var moduleTab = 'clients';
    try {
      var savedP = localStorage.getItem('sad-period');
      if (PERIODS.some(function (p) { return p.key === savedP; })) period = savedP;
      var savedM = localStorage.getItem('sad-module');
      if (MODULES.some(function (m) { return m.key === savedM; })) moduleTab = savedM;
    } catch (e) { /* storage blocked — defaults are fine */ }

    if (!document.getElementById('sad-style')) {
      var st = document.createElement('style');
      st.id = 'sad-style';
      st.textContent = STYLE;
      document.head.appendChild(st);
    }
    root.classList.add('sad');

    root.addEventListener('click', function (e) {
      var nav = e.target.closest('[data-nav]');
      if (nav && cfg.navigate) { cfg.navigate(tabKey(nav.getAttribute('data-nav'))); return; }
      var p = e.target.closest('[data-period]');
      if (p) {
        period = p.getAttribute('data-period');
        try { localStorage.setItem('sad-period', period); } catch (err) { /* fine */ }
        refresh();
        return;
      }
      var m = e.target.closest('[data-module]');
      if (m) {
        moduleTab = m.getAttribute('data-module');
        try { localStorage.setItem('sad-module', moduleTab); } catch (err) { /* fine */ }
        if (data) renderModules(data.modules);
        return;
      }
      var tog = e.target.closest('[data-table]');
      if (tog) {
        var id = tog.getAttribute('data-table');
        tableView[id] = !tableView[id];
        applyTable(id);
        return;
      }
      if (e.target.closest('[data-refresh]')) refresh();
    });

    // Links use Admin tab keys; a portal with other tabs passes
    // tabs: { sitemap: 'jobs', ... } and tabNames: { sitemap: 'Jobs', ... }.
    function tabKey(k) { return (cfg.tabs && cfg.tabs[k]) || k; }
    function tabName(k, fallback) { return (cfg.tabNames && cfg.tabNames[k]) || fallback; }

    // ---- pieces -----------------------------------------------------------
    function kpi(o) {
      if (o.tab) o.tabLabel = tabName(o.tab, o.tabLabel);
      var tag = o.tab ? 'button' : 'div';
      return '<' + tag + ' class="sad-card sad-kpi' + (o.compact ? ' sad-compact' : '') + '"' + (o.tab ? ' type="button" data-nav="' + esc(o.tab) + '" title="Open ' + esc(o.tabLabel) + '"' : '') + '>'
        + '<div class="sad-kpi-top"><span class="sad-ico" style="background:' + o.tint + ';color:' + o.color + '"><i class="fas ' + o.icon + '"></i></span>'
        + '<span class="sad-scope">' + esc(o.scope) + '</span></div>'
        + '<div class="sad-val">' + o.value + '</div>'
        + '<div class="sad-lbl">' + esc(o.label) + '</div>'
        + '<div class="sad-cap">' + o.caption + '</div>'
        + (o.tab ? '<div class="sad-open">Open ' + esc(o.tabLabel) + ' <i class="fas fa-arrow-right" style="font-size:10px"></i></div>' : '')
        + '</' + tag + '>';
    }

    function cardHead(title, sub, icon, tableId) {
      return '<div class="sad-card-head"><div><h3 class="sad-h"><i class="fas ' + icon + '" style="color:#f97316"></i>' + esc(title) + '</h3>'
        + '<p class="sad-sub">' + sub + '</p></div>'
        + (tableId ? '<button type="button" class="sad-btn" data-table="' + tableId + '" aria-pressed="false"><i class="fas fa-table-list"></i><span>Table</span></button>' : '')
        + '</div>';
    }

    function empty(msg) {
      return '<div class="sad-empty"><i class="fas fa-chart-simple" style="font-size:22px"></i>' + esc(msg) + '</div>';
    }

    function applyTable(id) {
      var on = !!tableView[id];
      var wrap = document.getElementById(id + '-wrap');
      var table = document.getElementById(id + '-table');
      var btn = root.querySelector('[data-table="' + id + '"]');
      if (wrap) wrap.style.display = on ? 'none' : '';
      if (table) table.style.display = on ? '' : 'none';
      if (btn) { btn.setAttribute('aria-pressed', String(on)); btn.querySelector('span').textContent = on ? 'Chart' : 'Table'; }
    }

    function destroyCharts() {
      Object.keys(charts).forEach(function (k) { charts[k].destroy(); delete charts[k]; });
    }

    function tooltipBase() {
      return { backgroundColor: '#0f172a', titleColor: '#fff', bodyColor: '#e2e8f0', padding: 10, cornerRadius: 8,
        titleFont: { weight: '700' }, boxPadding: 4, usePointStyle: true };
    }

    // ---- render -----------------------------------------------------------
    function render(d) {
      destroyCharts();
      var k = d.kpis, t = d.trend, s = d.status;
      var periodName = d.period.label;
      var updated = new Date(String(d.generated_at).replace(' ', 'T'));

      var kpis = [
        { label: 'Total Clients', icon: 'fa-users', color: '#1d4ed8', tint: '#eff6ff', scope: 'All time', tab: 'clients', tabLabel: 'Clients',
          value: n(k.clients_total),
          caption: n(k.clients_active) + ' active accounts · ' + plural(k.clients_new, 'new client', 'new clients') + ' in the ' + periodName.toLowerCase() },
        { label: 'Active Jobs', icon: 'fa-person-digging', color: C.inProgress, tint: '#eff6ff', scope: 'Right now', tab: 'sitemap', tabLabel: 'Site Map',
          value: n(k.active_jobs),
          caption: 'En route, on site or in progress · ' + n(k.on_hold) + ' on hold · ' + n(k.pending) + ' not started' },
        { label: 'Completed Jobs', icon: 'fa-circle-check', color: '#047857', tint: '#ecfdf5', scope: periodName, tab: 'work-reports', tabLabel: 'Work Reports',
          value: n(k.completed_period),
          caption: 'Finished in the ' + periodName.toLowerCase() + ' · ' + n(k.completed_total) + ' completed all time' },
        { label: 'Needs Attention', icon: 'fa-triangle-exclamation', color: k.needs_attention ? C.critical : C.ink2,
          tint: k.needs_attention ? '#fef2f2' : '#f1f5f9', scope: 'Right now',
          value: n(k.needs_attention),
          caption: k.needs_attention ? 'Overdue work, requests to review and stock problems — listed below' : 'Nothing needs action right now' },
      ];

      // Billing Overview: ₱ amounts and invoice counts are labelled as such.
      // Definitions: includes/billing_lib.php (billing_overview).
      var b = d.billing || {};
      var billing = [
        { compact: true, label: 'Payments Received', icon: 'fa-peso-sign', color: '#047857', tint: '#ecfdf5', scope: periodName, tab: 'billing', tabLabel: 'Billing',
          value: peso(b.payments_received),
          caption: plural(b.payments_count, 'payment', 'payments') + ' recorded · voided payments not counted' },
        { compact: true, label: 'Outstanding Balance', icon: 'fa-scale-unbalanced', color: '#1d4ed8', tint: '#eff6ff', scope: 'Right now', tab: 'billing', tabLabel: 'Billing',
          value: peso(b.outstanding_amount),
          caption: 'Still owed on ' + plural(b.outstanding_count, 'invoice', 'invoices') + (b.partial_count ? ' · ' + n(b.partial_count) + ' partly paid' : '') },
        { compact: true, label: 'Overdue Invoices', icon: 'fa-calendar-xmark', color: b.overdue_count ? C.critical : C.ink2, tint: b.overdue_count ? '#fef2f2' : '#f1f5f9',
          scope: 'Right now', tab: 'billing', tabLabel: 'Billing',
          value: n(b.overdue_count) + '<span class="sad-unit">' + (Number(b.overdue_count) === 1 ? 'invoice' : 'invoices') + '</span>',
          caption: b.overdue_count ? peso(b.overdue_amount) + ' unpaid past the due date' : 'Nothing is past due' },
        { compact: true, label: 'Pending Payments', icon: 'fa-hourglass-half', color: '#b45309', tint: '#fffbeb', scope: 'Right now', tab: 'billing', tabLabel: 'Billing',
          value: n(b.pending_count) + '<span class="sad-unit">' + (Number(b.pending_count) === 1 ? 'invoice' : 'invoices') + '</span>',
          caption: b.pending_count ? peso(b.pending_amount) + ' awaiting payment, not yet due' : 'No unpaid invoices waiting' },
      ];
      var billingHtml = b.has_data
        ? '<div class="sad-kpis">' + billing.map(kpi).join('') + '</div>'
        : '<div class="sad-card"><div class="sad-empty" style="min-height:90px"><i class="fas fa-file-invoice-dollar" style="font-size:20px"></i>'
          + 'No billing data yet. Invoices and payments appear here once they are recorded in Billing.</div></div>';

      var statusTotal = STATUS.reduce(function (sum, x) { return sum + (Number(s[x.key]) || 0); }, 0);
      var hasTrend = t.completed.some(Number) || t.created.some(Number);
      var axisName = d.period.grouping === 'month' ? 'Month' : 'Date';

      var alerts = d.attention.length
        ? '<div class="sad-alerts">' + d.attention.map(function (a) {
            var crit = a.severity === 'critical';
            var tag = crit
              ? '<span class="sad-tag" style="background:#fef2f2;color:#b91c1c"><i class="fas fa-circle-exclamation"></i>Urgent</span>'
              : '<span class="sad-tag" style="background:#fffbeb;color:#92400e"><i class="fas fa-triangle-exclamation"></i>Review</span>';
            return '<button type="button" class="sad-alert" data-nav="' + esc(a.target) + '">'
              + '<span class="sad-count" style="color:' + (crit ? '#b91c1c' : '#92400e') + '">' + n(a.count) + '</span>'
              + '<span style="min-width:0"><span style="display:flex;flex-wrap:wrap;align-items:center;gap:8px;font-size:13.5px;font-weight:700">' + esc(a.title) + tag + '</span>'
              + '<span class="sad-cap" style="display:block">' + esc(a.detail) + '</span></span>'
              + '<span class="sad-open" style="white-space:nowrap">Open <i class="fas fa-arrow-right" style="font-size:10px"></i></span></button>';
          }).join('') + '</div>'
        : '<p class="sad-cap" style="padding:6px 0"><i class="fas fa-circle-check" style="color:#047857"></i> All clear — no overdue work, pending reviews or stock problems.</p>';

      root.innerHTML = ''
        + '<div class="sad-head">'
        +   '<div><h2 class="sad-h" style="font-size:17px">System overview</h2>'
        +     '<p class="sad-sub">Clients, jobs and issues across SunTrack. Details live in each module. '
        +     'Updates automatically · last updated ' + esc(isNaN(updated) ? '' : updated.toLocaleTimeString('en-PH', { hour: 'numeric', minute: '2-digit' })) + '.</p></div>'
        +   '<div style="display:flex;flex-wrap:wrap;align-items:center;gap:8px">'
        +     '<span class="sad-cap" style="font-weight:600">Reporting period</span>'
        +     '<div class="sad-seg" role="group" aria-label="Reporting period">' + PERIODS.map(function (p) {
                return '<button type="button" data-period="' + p.key + '" aria-pressed="' + (p.key === period) + '">' + p.label + '</button>';
              }).join('') + '</div>'
        +     '<button type="button" class="sad-btn" data-refresh="1" title="Reload now"><i class="fas fa-rotate"></i><span class="sr-only">Refresh</span></button>'
        +   '</div>'
        + '</div>'

        + '<div class="sad-kpis">' + kpis.map(kpi).join('') + '</div>'

        + '<div class="sad-section-h"><div><h3 class="sad-h"><i class="fas fa-file-invoice-dollar" style="color:#f97316"></i>Billing Overview</h3>'
        +   '<p class="sad-sub">Money received in the period, and what clients still owe right now. Voided invoices and payments are left out.</p></div>'
        +   '<button type="button" class="sad-btn" data-nav="billing">Open Billing <i class="fas fa-arrow-right" style="font-size:10px"></i></button></div>'
        + billingHtml

        + '<div class="sad-charts">'
        +   '<section class="sad-card">' + cardHead('Job Completion Trend',
              'Jobs completed (by actual completion time) and new jobs created, per ' + (d.period.grouping === 'month' ? 'month' : 'day') + ' · ' + esc(periodName) + '.',
              'fa-chart-line', hasTrend ? 'sad-line' : null)
        +     (hasTrend
                ? '<div class="sad-line-legend"><span><i style="border-color:' + C.completed + '"></i>Completed</span><span><i style="border-color:' + C.created + ';border-top-style:dashed"></i>New jobs created</span></div>'
                  + '<div class="sad-chart" id="sad-line-wrap"><canvas id="sad-line" role="img" aria-label="Line graph of jobs completed and created per ' + axisName.toLowerCase() + '"></canvas></div>'
                  + '<div id="sad-line-table" style="display:none;max-height:300px;overflow:auto"></div>'
                : '<div class="sad-chart">' + empty('No data available for this period.') + '</div>')
        +   '</section>'
        +   '<section class="sad-card">' + cardHead('Overall Job Status', 'Every job by its current status (all time).', 'fa-chart-pie', statusTotal ? 'sad-pie' : null)
        +     (statusTotal
                ? '<div class="sad-pie" id="sad-pie-wrap"><canvas id="sad-pie" role="img" aria-label="Pie chart of jobs by status"></canvas></div>'
                  + '<div id="sad-pie-table" style="display:none"></div>'
                  + '<div class="sad-legend">' + STATUS.map(function (x) {
                      var v = Number(s[x.key]) || 0;
                      return '<div class="sad-legend-row" title="' + esc(x.hint) + '"><span class="sad-sw" style="background:' + x.color + '"></span>'
                        + '<span style="color:#334155">' + esc(x.label) + '</span><b style="font-variant-numeric:tabular-nums">' + n(v) + '</b>'
                        + '<span style="color:#94a3b8;text-align:right">' + pct(v, statusTotal) + '%</span></div>';
                    }).join('') + '</div>'
                  + '<p class="sad-cap" style="margin-top:10px">' + n(statusTotal) + ' jobs. Cancelled jobs are left out of the pie'
                  + (s.cancelled ? ' (' + n(s.cancelled) + ' cancelled).' : ' (none so far).') + '</p>'
                : '<div class="sad-pie">' + empty('No jobs recorded yet.') + '</div>')
        +   '</section>'
        + '</div>'

        + '<section class="sad-card" style="margin-top:var(--sad-gap)">'
        +   cardHead('Needs Attention', 'The most important things to act on right now — up to five.'
              + (k.active_subcontractors != null ? ' <span class="sad-tag" style="background:#f1f5f9;color:#475569;margin-left:4px"><i class="fas fa-helmet-safety"></i>'
                + n(k.active_subcontractors) + ' active subcontractor' + (Number(k.active_subcontractors) === 1 ? '' : 's') + '</span>' : ''), 'fa-bell', null)
        +   alerts
        +   (d.attention_more ? '<p class="sad-cap" style="margin-top:8px">+ ' + n(d.attention_more) + ' more type' + (d.attention_more === 1 ? '' : 's')
              + ' of item also counted above — open the modules to see them.</p>' : '')
        + '</section>'

        + '<section class="sad-card" id="sad-modules" style="margin-top:var(--sad-gap)"></section>';

      // -- line graph ------------------------------------------------------------
      if (hasTrend && global.Chart) {
        var many = t.labels.length > 12;
        charts.line = new Chart(document.getElementById('sad-line'), {
          type: 'line',
          data: { labels: t.labels, datasets: [
            { label: 'Completed', data: t.completed, borderColor: C.completed, backgroundColor: C.completed, borderWidth: 2,
              pointRadius: many ? 0 : 4, pointHoverRadius: 6, pointBackgroundColor: C.completed, pointBorderColor: C.surface, pointBorderWidth: 2, tension: 0 },
            { label: 'New jobs created', data: t.created, borderColor: C.created, backgroundColor: C.created, borderWidth: 2, borderDash: [6, 4],
              pointRadius: many ? 0 : 4, pointHoverRadius: 6, pointBackgroundColor: C.created, pointBorderColor: C.surface, pointBorderWidth: 2, tension: 0 },
          ] },
          options: {
            responsive: true, maintainAspectRatio: false, animation: false,
            interaction: { mode: 'index', intersect: false },
            plugins: {
              legend: { display: false }, // HTML legend above (solid vs dashed + text)
              tooltip: Object.assign(tooltipBase(), { callbacks: { label: function (ctx) { return ' ' + ctx.dataset.label + ': ' + plural(ctx.parsed.y, 'job', 'jobs'); } } }),
            },
            scales: {
              x: { grid: { display: false }, border: { color: C.axis }, title: { display: true, text: axisName, color: C.muted, font: { size: 11, weight: '600' } },
                   ticks: { color: C.muted, font: { size: 11 }, maxRotation: 0, autoSkip: true, maxTicksLimit: many ? 8 : 12 } },
              y: { beginAtZero: true, grid: { color: C.grid }, border: { display: false }, title: { display: true, text: 'Jobs', color: C.muted, font: { size: 11, weight: '600' } },
                   ticks: { color: C.muted, font: { size: 11 }, precision: 0 } },
            },
          },
        });
        document.getElementById('sad-line-table').innerHTML = '<table class="sad-table"><thead><tr><th>' + axisName + '</th><th style="text-align:right">Completed</th><th style="text-align:right">New jobs</th></tr></thead><tbody>'
          + t.labels.map(function (l, i) { return '<tr><td>' + esc(l) + '</td><td style="text-align:right">' + n(t.completed[i]) + '</td><td style="text-align:right">' + n(t.created[i]) + '</td></tr>'; }).join('')
          + '<tr><td><b>Total</b></td><td style="text-align:right"><b>' + n(t.completed.reduce(function (a, b) { return a + b; }, 0)) + '</b></td><td style="text-align:right"><b>'
          + n(t.created.reduce(function (a, b) { return a + b; }, 0)) + '</b></td></tr></tbody></table>';
        applyTable('sad-line');
      }

      // -- pie graph -------------------------------------------------------------
      if (statusTotal && global.Chart) {
        charts.pie = new Chart(document.getElementById('sad-pie'), {
          type: 'pie',
          data: { labels: STATUS.map(function (x) { return x.label; }), datasets: [{
            data: STATUS.map(function (x) { return Number(s[x.key]) || 0; }),
            backgroundColor: STATUS.map(function (x) { return x.color; }),
            borderColor: C.surface, borderWidth: 2, hoverOffset: 6,
          }] },
          options: {
            responsive: true, maintainAspectRatio: false, animation: false,
            plugins: {
              legend: { display: false }, // the HTML legend below shows counts and percentages
              tooltip: Object.assign(tooltipBase(), { callbacks: { label: function (ctx) {
                return ' ' + ctx.label + ': ' + plural(ctx.parsed, 'job', 'jobs') + ' (' + pct(ctx.parsed, statusTotal) + '%)';
              } } }),
            },
          },
        });
        document.getElementById('sad-pie-table').innerHTML = '<table class="sad-table"><thead><tr><th>Status</th><th>Includes</th><th style="text-align:right">Jobs</th><th style="text-align:right">Share</th></tr></thead><tbody>'
          + STATUS.map(function (x) { var v = Number(s[x.key]) || 0; return '<tr><td>' + esc(x.label) + '</td><td style="color:#64748b">' + esc(x.hint) + '</td><td style="text-align:right">' + n(v) + '</td><td style="text-align:right">' + pct(v, statusTotal) + '%</td></tr>'; }).join('')
          + '</tbody></table>';
        applyTable('sad-pie');
      }

      renderModules(d.modules);
    }

    // ---- Clients / Technicians / Warehouse (figures only, no extra charts) ----
    function tile(label, value, caption) {
      return '<div class="sad-tile"><span class="sad-lbl" style="font-size:12px">' + esc(label) + '</span><b>' + value + '</b><span class="sad-cap">' + caption + '</span></div>';
    }
    function small(text) { return ' <span style="font-size:13px;color:#94a3b8;font-weight:600">' + esc(text) + '</span>'; }

    function moduleTiles(key, m) {
      var k = m.kpis || {};
      if (key === 'clients') {
        return [
          tile('Active clients', n(k.active), n(k.total) + ' clients on record'),
          tile('New this month', n(k.new_this_month), n(k.new_last_month) + ' last month'),
          tile('Pending enquiries', n(k.pending_enquiries), k.pending_enquiries ? 'Service requests waiting for review' : 'Nothing waiting for review'),
        ];
      }
      if (key === 'technicians') {
        return [
          tile('In the field', n(k.on_field) + small('of ' + n(k.total)), 'On the way, on site or working now'),
          tile('Assigned jobs', n(k.assigned_jobs), k.unassigned_jobs ? plural(k.unassigned_jobs, 'open job has', 'open jobs have') + ' no technician' : 'Every open job has a technician'),
          tile('Completed today', n(k.completed_today), 'Jobs finished today'),
          tile('On duty', n(k.on_duty) + small('of ' + n(k.total)), n(k.busy) + ' busy · ' + n(k.utilization_pct) + '% utilization'),
        ];
      }
      var rq = k.requests_by_status || {};
      return [
        tile('Stock value', peso(k.stock_value), 'At cost, excluding discontinued items'),
        tile('Stock alerts', n((k.low_stock || 0) + (k.out_of_stock || 0)), n(k.out_of_stock) + ' out of stock · ' + n(k.low_stock) + ' running low'),
        tile('Pending material requests', k.orders_tracked ? n(k.pending_requests) : '—',
             k.orders_tracked ? n(rq.PENDING) + ' new · ' + n(rq.PREPARING) + ' preparing · ' + n(rq.READY) + ' ready' : 'Not set up yet'),
        tile('Issued today', n(k.issued_today_units) + small(Number(k.issued_today_units) === 1 ? 'unit' : 'units'), plural(k.issued_today_moves, 'stock issue', 'stock issues') + ' today'),
      ];
    }

    function renderModules(mods) {
      var el = document.getElementById('sad-modules');
      if (!el) return;
      var meta = MODULES.filter(function (x) { return x.key === moduleTab; })[0];
      var m = mods && mods[moduleTab];
      var head = '<div class="sad-card-head" style="flex-wrap:wrap"><div><h3 class="sad-h"><i class="fas fa-layer-group" style="color:#f97316"></i>By module</h3>'
        + '<p class="sad-sub">Key figures for clients, field technicians and the warehouse.'
        + (mods && mods.is_demo ? ' <span class="sad-tag" style="background:#fffbeb;color:#92400e">Sample data — not from the database</span>' : '') + '</p></div>'
        + '<div class="sad-seg" role="tablist" aria-label="Module">' + MODULES.map(function (x) {
            return '<button type="button" role="tab" aria-selected="' + (x.key === moduleTab) + '" data-module="' + x.key + '"><i class="fas ' + x.icon + '"></i>' + x.label + '</button>';
          }).join('') + '</div></div>';
      if (!m || !m.available) {
        el.innerHTML = head + '<p class="sad-cap">These figures could not be loaded. The rest of the dashboard is unaffected.</p>';
        return;
      }
      el.innerHTML = head + '<div role="tabpanel"><div class="sad-tiles">' + moduleTiles(moduleTab, m).join('') + '</div>'
        + '<div style="margin-top:14px;text-align:right"><button type="button" class="sad-btn" data-nav="' + meta.tab + '">Open ' + esc(tabName(meta.tab, meta.label)) + ' <i class="fas fa-arrow-right" style="font-size:10px"></i></button></div></div>';
    }

    // ---- loading --------------------------------------------------------------
    function refresh() {
      var my = ++reqId; // a slower, older response never overwrites a newer one
      if (data) root.classList.add('sad-dim');
      else root.innerHTML = '<p class="sad-cap" style="padding:24px 0"><i class="fas fa-spinner fa-spin"></i> Loading the dashboard…</p>';
      var url = cfg.endpoint + (cfg.endpoint.indexOf('?') >= 0 ? '&' : '?') + 'period=' + encodeURIComponent(period);
      return fetch(url, { headers: { Accept: 'application/json' }, credentials: 'same-origin' })
        .then(function (res) { return res.json(); })
        .then(function (json) {
          if (my !== reqId) return;
          if (!json.success) throw new Error(json.message || 'The dashboard could not be loaded.');
          data = json.data;
          render(data);
        })
        .catch(function (err) {
          if (my !== reqId) return;
          if (data) return; // keep the last good view; the next live update tries again
          destroyCharts();
          root.innerHTML = '<div class="sad-card" style="color:#b91c1c"><i class="fas fa-circle-exclamation"></i> '
            + esc(err && err.message ? err.message : 'The dashboard could not be loaded.')
            + ' <button type="button" class="sad-btn" data-refresh="1" style="margin-left:8px">Try again</button></div>';
        })
        .then(function () { if (my === reqId) root.classList.remove('sad-dim'); });
    }

    return { refresh: refresh };
  }

  global.SunTrackAdminDashboard = { mount: mount };
})(window);
