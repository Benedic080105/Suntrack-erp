/**
 * SunTrack — lists longer than one page.
 *
 * List endpoints return at most one page (500 rows) and, when more remain,
 * say so in an X-Next-Offset response header. SunTrackPaging.fetchAll() is a
 * drop-in for fetch(): if the response has no such header it is returned
 * untouched (so it is safe for every call, POSTs included); if it does, the
 * remaining pages are fetched and merged into the first response's rows, up to
 * MAX_ROWS. Pages keep their existing code — they just call stFetch() instead
 * of fetch().
 *
 * The merged response mimics fetch's: .ok, .status, .headers, .json().
 * json().truncated is true when MAX_ROWS was reached.
 */
(function (global) {
  'use strict';

  var MAX_ROWS = 5000;

  function rowsOf(data) {
    if (Array.isArray(data)) return data;
    if (data && Array.isArray(data.rows)) return data.rows;
    return null;
  }

  function wrap(res, body) {
    return { ok: res.ok, status: res.status, headers: res.headers, json: function () { return Promise.resolve(body); } };
  }

  async function fetchAll(url, init) {
    var res = await fetch(url, init);
    var next = res.headers.get('X-Next-Offset');
    if (!next) return res;

    var first = await res.json();
    var rows = first && first.success ? rowsOf(first.data) : null;
    if (!rows) return wrap(res, first);

    var all = rows.slice();
    var truncated = false;
    var guard = 0;
    while (next && guard++ < 100) {
      if (all.length >= MAX_ROWS) { truncated = true; break; }
      var u = new URL(url, location.href);
      u.searchParams.set('offset', next);
      var r = await fetch(u.toString(), init);
      var j = await r.json();
      var more = j && j.success ? rowsOf(j.data) : null;
      if (!more) break;               // a failed page never discards what was already loaded
      all = all.concat(more);
      next = r.headers.get('X-Next-Offset');
    }

    if (Array.isArray(first.data)) first.data = all; else first.data.rows = all;
    first.truncated = truncated;
    return wrap(res, first);
  }

  global.SunTrackPaging = { fetchAll: fetchAll, MAX_ROWS: MAX_ROWS };
  global.stFetch = fetchAll;
})(window);
