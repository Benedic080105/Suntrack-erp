/**
 * SunTrack ERP — Mobile field support.
 *
 * The technician portal runs on a phone in the field and the warehouse portal
 * runs on a phone at the racking. Three things bite on mobile that never show
 * up on a desktop test, and this file handles all three.
 *
 * 1. INSECURE ORIGIN
 *    Browsers only expose geolocation and the camera on a secure context —
 *    HTTPS, or localhost. Over plain http:// on a LAN address they refuse, and
 *    Chrome reports it as PERMISSION_DENIED. That is the single most misleading
 *    error in this whole system: the technician is told to fix a permission
 *    that is already granted, and no amount of tapping "Allow" helps. We detect
 *    the real cause up front and say so.
 *
 * 2. SCREEN SLEEP
 *    A phone left on a job site locks its screen after a minute or two. The
 *    geofence ping timer stops with it, leaving a gap in the location trail
 *    that looks like the technician wandered off. A wake lock keeps the screen
 *    alive while a job is actually active.
 *
 * 3. UNHELPFUL FAILURES
 *    "Could not access the camera" tells a warehouse clerk nothing. The helpers
 *    below name the actual cause each time.
 */
(function (global) {
  'use strict';

  // -------------------------------------------------------------------------
  // Secure context
  // -------------------------------------------------------------------------

  /**
   * True when this page may use geolocation and getUserMedia.
   *
   * window.isSecureContext covers it on every modern browser; the hostname
   * check is a fallback for older WebViews that predate the property.
   */
  function isSecure() {
    if (typeof global.isSecureContext === 'boolean') return global.isSecureContext;
    var h = location.hostname;
    return location.protocol === 'https:' || h === 'localhost' || h === '127.0.0.1' || h === '::1';
  }

  /** A plain-language explanation of why hardware access is blocked. */
  function insecureReason(feature) {
    return 'This page is served over an unsecured connection (' + location.protocol + '//'
      + location.hostname + '), and browsers only allow ' + feature + ' over HTTPS. '
      + 'This is a browser rule, not a SunTrack setting — granting permission will not help. '
      + 'Ask your administrator to serve SunTrack over HTTPS.';
  }

  /**
   * Show a persistent warning strip at the top of the page.
   *
   * Deliberately not dismissible: on an insecure origin the technician simply
   * cannot time in, and hiding that fact wastes their time at a customer site.
   */
  function warnInsecure(feature) {
    if (document.getElementById('suntrack-insecure-warning')) return;

    var bar = document.createElement('div');
    bar.id = 'suntrack-insecure-warning';
    bar.setAttribute('role', 'alert');
    bar.style.cssText =
      'position:sticky;top:0;z-index:60;background:#7f1d1d;color:#fecaca;' +
      'padding:calc(10px + env(safe-area-inset-top,0px)) 14px 10px;font-size:12.5px;' +
      'line-height:1.5;font-family:Inter,system-ui,sans-serif;border-bottom:2px solid #dc2626';
    bar.innerHTML =
      '<strong style="color:#fff">\u26A0 ' + feature + ' is unavailable on this connection.</strong><br>' +
      'SunTrack is being served over <code>' + location.protocol + '//</code> — browsers only permit ' +
      feature.toLowerCase() + ' over <strong>HTTPS</strong> (or on localhost). ' +
      'Granting permission will not help; the site needs an HTTPS address.';

    document.body.insertBefore(bar, document.body.firstChild);
  }

  // -------------------------------------------------------------------------
  // Diagnostics
  // -------------------------------------------------------------------------

  /** Turn a GeolocationPositionError into something a technician can act on. */
  function describeGpsError(err) {
    if (!isSecure()) return insecureReason('location access');
    if (!err) return 'Unknown GPS error.';

    switch (err.code) {
      case 1:
        return 'Location permission was denied. Tap the padlock or \u24D8 icon in the address bar, '
             + 'set Location to Allow, then reload this page.';
      case 2:
        return 'Your position is unavailable right now. Step outside or move somewhere with a clearer '
             + 'view of the sky, make sure your phone\u2019s Location setting is switched on, and try again.';
      case 3:
        return 'Getting your location timed out. This is common indoors — move outside and try again.';
      default:
        return err.message || 'Unable to read your location.';
    }
  }

  /** Turn a getUserMedia failure into something a warehouse clerk can act on. */
  function describeCameraError(err) {
    if (!isSecure()) return insecureReason('camera access');
    if (!err) return 'Could not access the camera.';

    var name = err.name || '';
    if (name === 'NotAllowedError' || name === 'PermissionDeniedError') {
      return 'Camera permission was denied. Tap the padlock or \u24D8 icon in the address bar, '
           + 'set Camera to Allow, then reload this page.';
    }
    if (name === 'NotFoundError' || name === 'DevicesNotFoundError') {
      return 'No camera was found on this device. Use the manual code box below instead.';
    }
    if (name === 'NotReadableError' || name === 'TrackStartError') {
      return 'The camera is already in use by another app. Close any other app using the camera '
           + '(or another SunTrack tab) and try again.';
    }
    if (name === 'OverconstrainedError') {
      return 'This device has no rear-facing camera available. Try again, or use the manual code box.';
    }
    return 'Could not start the camera (' + (name || 'unknown error') + '). '
         + 'You can still look up a code manually below.';
  }

  // -------------------------------------------------------------------------
  // Wake lock
  // -------------------------------------------------------------------------

  var wakeLock = null;

  /**
   * Keep the screen awake. Safe to call repeatedly.
   *
   * The Screen Wake Lock API is unsupported on some browsers (notably older
   * iOS Safari), so this resolves to false rather than throwing — callers just
   * get no wake lock, which is the same as the old behaviour.
   */
  async function keepAwake() {
    if (!('wakeLock' in navigator)) return false;
    if (wakeLock && !wakeLock.released) return true;

    try {
      wakeLock = await navigator.wakeLock.request('screen');
      // The browser drops the lock whenever the tab is backgrounded, so it has
      // to be re-acquired when the technician returns to the page.
      wakeLock.addEventListener('release', function () { wakeLock = null; });
      return true;
    } catch (e) {
      return false;
    }
  }

  async function releaseAwake() {
    try {
      if (wakeLock) { await wakeLock.release(); wakeLock = null; }
    } catch (e) { /* already gone */ }
  }

  // Re-acquire after the tab comes back, if the caller still wants it.
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden && global.SunTrackMobile && global.SunTrackMobile._wantAwake) {
      keepAwake();
    }
  });

  // -------------------------------------------------------------------------

  global.SunTrackMobile = {
    isSecure: isSecure,
    insecureReason: insecureReason,
    warnInsecure: warnInsecure,
    describeGpsError: describeGpsError,
    describeCameraError: describeCameraError,

    _wantAwake: false,
    keepAwake: function () { this._wantAwake = true; return keepAwake(); },
    releaseAwake: function () { this._wantAwake = false; return releaseAwake(); },

    /** True when the UA looks like a phone or tablet. Used for layout hints only. */
    isTouchDevice: function () {
      return ('ontouchstart' in global) || (navigator.maxTouchPoints > 0);
    }
  };
})(window);
