/**
 * SunTrack — "Two-step login" card for a staff member's Settings.
 *
 *   SunTrackAccount.renderTwoFactor('twofa-card');
 *
 * Needs the page's CSRF_TOKEN and assets/vendor/qrcode/qrcode.min.js. Talks
 * only to api/account/two_factor.php, which always acts on the signed-in
 * account. Renders nothing for roles that cannot use two-step login.
 */
(function (global) {
  'use strict';

  var API = '../api/account/two_factor.php';

  function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; });
  }
  async function call(method, body) {
    try {
      var res = await fetch(API, method === 'GET' ? {} : {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        // Pages declare `const CSRF_TOKEN`, which is shared by name across
        // scripts but is NOT a property of window.
        body: JSON.stringify(Object.assign({}, body, { csrf_token: typeof CSRF_TOKEN !== 'undefined' ? CSRF_TOKEN : '' })),
      });
      return await res.json();
    } catch (e) { return { success: false, message: 'Network error. Please try again.' }; }
  }
  function msg(box, text, ok) {
    var m = box.querySelector('.tf-msg');
    m.className = 'tf-msg text-xs rounded-lg px-3 py-2 mb-3 ' + (ok ? 'bg-emerald-50 border border-emerald-200 text-emerald-700' : 'bg-red-50 border border-red-200 text-red-600');
    m.textContent = text;
  }
  var HEAD = '<h3 class="font-bold text-slate-900 mb-1"><i class="fas fa-shield-halved text-orange-500 mr-1"></i> Two-step login</h3>'
    + '<p class="text-xs text-slate-500 mb-3">After your password, sign-in also asks for a 6-digit code from an authenticator app on your phone '
    + '(Google Authenticator, Microsoft Authenticator, Authy). A stolen password alone is then not enough.</p>'
    + '<div class="tf-msg hidden"></div>';
  var INPUT = 'w-full rounded-lg border border-slate-200 text-sm px-3 py-2';
  var BTN = 'rounded-lg text-sm font-bold px-4 py-2.5';

  async function render(id) {
    var box = document.getElementById(id);
    if (!box) return;
    var s = await call('GET');
    if (!s.success) { box.innerHTML = HEAD; msg(box, s.message, false); return; }
    if (!s.data.eligible) { box.classList.add('hidden'); return; }
    box.classList.remove('hidden');

    if (s.data.enabled) {
      box.innerHTML = HEAD
        + '<p class="text-sm font-semibold text-emerald-700 mb-1"><i class="fas fa-circle-check mr-1"></i>On</p>'
        + '<p class="text-xs text-slate-500 mb-3">Unused backup codes: <b>' + Number(s.data.recovery_codes_left) + '</b> of 8.</p>'
        + '<details><summary class="text-xs font-bold text-slate-600 cursor-pointer">Turn off two-step login</summary>'
        + '<div class="space-y-2 mt-2"><input type="password" class="tf-pw ' + INPUT + '" placeholder="Your password" autocomplete="current-password">'
        + '<input class="tf-code ' + INPUT + '" placeholder="6-digit code or a backup code" inputmode="numeric" autocomplete="one-time-code">'
        + '<button type="button" class="tf-off ' + BTN + ' w-full bg-red-600 hover:bg-red-700 text-white">Turn off</button></div></details>';
      box.querySelector('.tf-off').addEventListener('click', async function () {
        var r = await call('POST', { action: 'disable', password: box.querySelector('.tf-pw').value, code: box.querySelector('.tf-code').value.trim() });
        if (r.success) render(id); else msg(box, r.message, false);
      });
      return;
    }

    box.innerHTML = HEAD
      + '<p class="text-sm font-semibold text-slate-500 mb-3"><i class="fas fa-circle-xmark mr-1"></i>Off — recommended to turn on</p>'
      + '<button type="button" class="tf-start ' + BTN + ' w-full bg-slate-800 hover:bg-slate-900 text-white">Turn on two-step login</button>';
    box.querySelector('.tf-start').addEventListener('click', async function () {
      var r = await call('POST', { action: 'start' });
      if (!r.success) { msg(box, r.message, false); return; }
      var qrImg = '';
      if (global.qrcode) {
        var q = global.qrcode(0, 'M'); q.addData(r.data.uri); q.make();
        qrImg = '<img src="' + q.createDataURL(5, 8) + '" alt="QR code for your authenticator app" class="mx-auto rounded-lg border border-slate-200">';
      }
      box.innerHTML = HEAD
        + '<ol class="text-xs text-slate-600 list-decimal ml-4 space-y-1 mb-3"><li>Open your authenticator app and add an account by scanning this code.</li>'
        + '<li>Type the 6-digit code it shows, then press Confirm.</li></ol>'
        + qrImg
        + '<p class="text-[11px] text-slate-400 text-center mt-2">Can\'t scan? Enter this key: <span class="font-mono text-slate-700 break-all">' + esc(r.data.secret) + '</span></p>'
        + '<div class="flex gap-2 mt-3"><input class="tf-code ' + INPUT + '" placeholder="123456" inputmode="numeric" maxlength="6" autocomplete="one-time-code">'
        + '<button type="button" class="tf-confirm ' + BTN + ' bg-orange-500 hover:bg-orange-600 text-white">Confirm</button></div>';
      box.querySelector('.tf-confirm').addEventListener('click', async function () {
        var c = await call('POST', { action: 'confirm', code: box.querySelector('.tf-code').value.trim() });
        if (!c.success) { msg(box, c.message, false); return; }
        box.innerHTML = HEAD
          + '<p class="text-sm font-semibold text-emerald-700 mb-2"><i class="fas fa-circle-check mr-1"></i>Two-step login is on.</p>'
          + '<p class="text-xs text-slate-600 mb-2"><b>Save these backup codes</b> (print them or keep them in a safe place). Each works once, if you ever lose your phone. They will not be shown again.</p>'
          + '<div class="grid grid-cols-2 gap-1.5 font-mono text-sm bg-slate-50 border border-slate-200 rounded-lg p-3 mb-3">'
          + c.data.recovery_codes.map(function (x) { return '<span>' + esc(x) + '</span>'; }).join('') + '</div>'
          + '<button type="button" class="tf-done ' + BTN + ' w-full bg-slate-800 hover:bg-slate-900 text-white">I have saved my backup codes</button>';
        box.querySelector('.tf-done').addEventListener('click', function () { render(id); });
      });
    });
  }

  global.SunTrackAccount = { renderTwoFactor: render };
})(window);
