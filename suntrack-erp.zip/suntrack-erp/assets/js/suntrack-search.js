/**
 * SunTrack — a Search button on the right of every search box.
 *
 * Every portal's search boxes already search while you type (and on Enter);
 * this adds a visible button for people who expect one. It finds the boxes by
 * id (`*-search`, `search-*`) or type="search", including boxes a page builds
 * later (Management's Clients / Technicians / … tabs), and joins each box and
 * its button into one control without touching the page's own code.
 *
 * Clicking the button fires the same events typing + Enter would, so it runs
 * whatever search that page already wires up:
 *   - pages using SunTrackFilters search immediately on Enter
 *   - pages that search on 'input' (debounced) search from that event
 * Add data-no-search-button to an input to leave it alone.
 */
(function () {
  'use strict';

  var SELECTOR = 'input[id$="-search"], input[id^="search-"], input[type="search"]';
  // Classes that size the box inside its toolbar move to the wrapper.
  var LAYOUT = /^(?:[a-z]+:)?(?:flex-1|flex-auto|grow|basis-|min-w-|max-w-|w-)/;

  function runSearch(input) {
    // 'input' first (debounced searches), then Enter (immediate searches, which
    // also cancel the pending debounce) — so each page searches exactly once.
    input.dispatchEvent(new Event('input', { bubbles: true }));
    ['keydown', 'keyup'].forEach(function (type) {
      input.dispatchEvent(new KeyboardEvent(type, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
    });
  }

  function enhance(input) {
    if (input.dataset.searchButton || input.hasAttribute('data-no-search-button') || input.type === 'hidden') return;
    input.dataset.searchButton = '1';

    var wrap = document.createElement('div');
    wrap.className = 'st-search-group';
    var keep = [];
    input.className.split(/\s+/).forEach(function (c) {
      if (!c) return;
      if (LAYOUT.test(c)) wrap.classList.add(c); else keep.push(c);
    });
    input.className = keep.join(' ');
    // No inline min-width here: it would override the box's own min-w-* class,
    // and on a crowded toolbar the search box got squeezed down to its button.
    // A box with no min-w-* class still keeps room to type.
    wrap.style.cssText = 'display:flex;align-items:stretch';
    if (!Array.prototype.some.call(wrap.classList, function (c) { return /(^|:)min-w-/.test(c); })) {
      wrap.style.minWidth = '200px';
    }

    var radius = getComputedStyle(input).borderTopLeftRadius || '8px';
    input.style.flex = '1 1 auto';
    input.style.minWidth = '0';
    input.style.width = 'auto';
    input.style.borderTopRightRadius = '0';
    input.style.borderBottomRightRadius = '0';

    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'st-search-btn';
    btn.title = 'Search';
    btn.setAttribute('aria-label', 'Search');
    btn.innerHTML = '<i class="fas fa-magnifying-glass"></i><span class="st-search-btn-text">Search</span>';
    btn.style.borderTopRightRadius = radius;
    btn.style.borderBottomRightRadius = radius;
    btn.addEventListener('click', function () {
      runSearch(input);
      input.focus();
    });

    input.parentNode.insertBefore(wrap, input);
    wrap.appendChild(input);
    wrap.appendChild(btn);
  }

  function scan(root) {
    if (!root || !root.querySelectorAll) return;
    if (root.matches && root.matches(SELECTOR)) enhance(root);
    root.querySelectorAll(SELECTOR).forEach(enhance);
  }

  var style = document.createElement('style');
  style.textContent = ''
    + '.st-search-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;flex:0 0 auto;'
    + 'padding:0 14px;font-size:12.5px;font-weight:700;color:#fff;background:#f97316;border:1px solid #f97316;'
    + 'border-radius:0;cursor:pointer;transition:background .15s}'
    + '.st-search-btn:hover{background:#ea580c;border-color:#ea580c}'
    + '.st-search-btn:focus-visible{outline:2px solid #fdba74;outline-offset:1px}'
    + '@media (max-width:420px){.st-search-btn-text{display:none}}';

  function start() {
    document.head.appendChild(style);
    scan(document.body);
    new MutationObserver(function (records) {
      records.forEach(function (r) { r.addedNodes.forEach(scan); });
    }).observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
