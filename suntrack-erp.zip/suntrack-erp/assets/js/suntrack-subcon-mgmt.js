/**
 * SunTrack ERP — Sub-contractors tab (Management: full; Admin: view only).
 *
 *   const m = SunTrackSubcon.mount({ root, base, csrf, canManage });
 *   m.refresh(); m.openAssignment(id);
 *   SunTrackSubcon.assignJob({ jobId, jobCode, hasTechnician, onDone })   // Jobs tab
 *
 * Views:
 *   Auto-assignment  team capacity (slots per technician), the rules, jobs
 *                    waiting, and every automatic decision with its reason
 *   Subcontractors   register / approve / suspend, profile, portal login, job limit
 *   Assignments      offer → accept → work → inspection → complete, per job
 * Every action is re-checked on the server; buttons here are a convenience.
 */
(function (global) {
  'use strict';

  var S = { base: '', csrf: '', canManage: false, root: null, view: 'auto', search: '', status: '' };
  var SA_BADGE = {
    AWAITING_ACCEPTANCE: 'bg-amber-100 text-amber-800', ACCEPTED: 'bg-sky-100 text-sky-700', SCHEDULED: 'bg-indigo-100 text-indigo-700',
    IN_PROGRESS: 'bg-blue-100 text-blue-700', AWAITING_INSPECTION: 'bg-violet-100 text-violet-700', REVISION_REQUIRED: 'bg-orange-100 text-orange-700',
    APPROVED: 'bg-emerald-100 text-emerald-700', COMPLETED: 'bg-emerald-600 text-white', DECLINED: 'bg-slate-200 text-slate-600', CANCELLED: 'bg-slate-200 text-slate-500',
  };
  var SUB_BADGE = { PENDING: 'bg-amber-100 text-amber-800', APPROVED: 'bg-emerald-100 text-emerald-700', SUSPENDED: 'bg-red-100 text-red-700', INACTIVE: 'bg-slate-200 text-slate-600' };
  var inputCls = 'w-full border border-slate-200 rounded-lg px-3 py-2 text-sm bg-white';
  var btn = 'inline-flex items-center gap-1.5 rounded-lg text-xs font-bold px-3 py-2';

  function esc(v) {
    if (v === null || v === undefined || v === '') return '—';
    return String(v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; });
  }
  function raw(v) { return v === null || v === undefined ? '' : esc(v); }
  function peso(v) { return '₱' + Number(v || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function nice(s) { return String(s || '').toLowerCase().replace(/_/g, ' ').replace(/^\w/, function (c) { return c.toUpperCase(); }); }
  function date(v) { if (!v) return '—'; var d = new Date(String(v).replace(' ', 'T')); return isNaN(d) ? esc(v) : d.toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' }); }
  function when(v) { if (!v) return '—'; var d = new Date(String(v).replace(' ', 'T')); return isNaN(d) ? esc(v) : d.toLocaleString('en-PH', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }); }
  function badge(map, k, label) { return '<span class="inline-block text-[11px] font-bold px-2 py-0.5 rounded-full ' + (map[k] || 'bg-slate-100 text-slate-600') + '">' + esc(label || nice(k)) + '</span>'; }
  function toast(msg, err) {
    if (typeof global.toast === 'function') return global.toast(msg, err);
    var el = document.createElement('div');
    el.className = 'fixed bottom-6 right-4 z-[80] px-4 py-3 rounded-xl shadow-lg text-sm font-semibold text-white ' + (err ? 'bg-red-500' : 'bg-emerald-600');
    el.textContent = msg; document.body.appendChild(el); setTimeout(function () { el.remove(); }, err ? 5000 : 3500);
  }
  async function get(path, params) {
    try { var r = await fetch(S.base + '/api/' + path + (params ? '?' + new URLSearchParams(params) : ''), { credentials: 'same-origin' }); return await r.json(); }
    catch (e) { return { success: false, message: 'Network error. Please try again.' }; }
  }
  async function post(path, body) {
    try {
      var r = await fetch(S.base + '/api/' + path, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({}, body, { csrf_token: S.csrf })) });
      return await r.json();
    } catch (e) { return { success: false, message: 'Network error. Please try again.' }; }
  }
  async function locked(b, fn) {
    if (!b || b.disabled) return;
    var h = b.innerHTML; b.disabled = true; b.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i>';
    try { return await fn(); } finally { if (b.isConnected) { b.disabled = false; b.innerHTML = h; } }
  }
  function ask(q, min) {
    var v = global.prompt(q); if (v === null) return null; v = v.trim();
    if (min && v.length < min) { toast('Please give a reason (at least ' + min + ' characters).', true); return null; }
    return v;
  }
  function field(label, html, hint) {
    return '<label class="block"><span class="block text-xs font-semibold text-slate-500 mb-1">' + label + '</span>' + html
      + (hint ? '<span class="block text-[11px] text-slate-400 mt-1">' + hint + '</span>' : '') + '</label>';
  }
  function input(id, v, type, extra) { return '<input id="' + id + '" type="' + (type || 'text') + '" value="' + raw(v) + '" class="' + inputCls + '" ' + (extra || '') + '>'; }
  function area(id, v, rows) { return '<textarea id="' + id + '" rows="' + (rows || 3) + '" class="' + inputCls + '">' + raw(v) + '</textarea>'; }
  function val(id) { var el = document.getElementById(id); return el ? el.value.trim() : ''; }

  // ---- modal ------------------------------------------------------------------
  var modal = null;
  function openModal(title, html, wide) {
    if (!modal) {
      modal = document.createElement('div');
      modal.className = 'fixed inset-0 z-[70] flex items-start sm:items-center justify-center p-3 sm:p-6';
      modal.style.background = 'rgba(15,23,42,.45)';
      modal.innerHTML = '<div data-box class="bg-white rounded-2xl w-full max-h-[94vh] overflow-y-auto shadow-xl"><div class="sticky top-0 bg-white z-10 flex items-center justify-between px-5 py-4 border-b border-slate-100">'
        + '<h3 data-title class="font-bold text-slate-900"></h3><button type="button" data-close class="text-slate-400 hover:text-slate-600 px-2" aria-label="Close"><i class="fas fa-xmark"></i></button></div><div data-body class="p-5 text-sm"></div></div>';
      document.body.appendChild(modal);
      modal.addEventListener('click', function (e) { if (e.target === modal || e.target.closest('[data-close]')) closeModal(); });
      document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && modal.style.display !== 'none') closeModal(); });
    }
    modal.querySelector('[data-box]').className = 'bg-white rounded-2xl w-full max-h-[94vh] overflow-y-auto shadow-xl ' + (wide ? 'max-w-4xl' : 'max-w-lg');
    modal.querySelector('[data-title]').textContent = title;
    modal.querySelector('[data-body]').innerHTML = html;
    modal.style.display = 'flex';
    return modal.querySelector('[data-body]');
  }
  function closeModal() { if (modal) modal.style.display = 'none'; }

  // ---- shell ----------------------------------------------------------------------
  function mount(cfg) {
    Object.assign(S, cfg);
    S.root.innerHTML = '<div class="bg-white rounded-2xl border border-slate-100 shadow-sm p-4 mb-4"><div class="flex flex-wrap items-end gap-3">'
      + '<div class="inline-flex gap-1 p-1 bg-slate-100 rounded-xl" role="tablist">'
      + [['auto', 'Auto-assignment', 'fa-wand-magic-sparkles'], ['subs', 'Subcontractors', 'fa-helmet-safety'], ['assign', 'Assignments', 'fa-clipboard-list']].map(function (v) {
          return '<button type="button" data-view="' + v[0] + '" class="px-3 py-2 rounded-lg text-xs font-bold text-slate-600"><i class="fas ' + v[2] + ' mr-1"></i>' + v[1] + '</button>'; }).join('')
      + '</div>'
      + '<label data-filters class="flex-1 min-w-[200px]"><span class="block text-xs font-semibold text-slate-500 mb-1">Search</span><input data-search type="search" class="' + inputCls + '" placeholder="Name, code, job, client…"></label>'
      + '<label data-filters><span class="block text-xs font-semibold text-slate-500 mb-1">Status</span><select data-status class="' + inputCls + '" style="min-width:190px"></select></label>'
      + (S.canManage ? '<button type="button" data-add class="' + btn + ' bg-orange-500 hover:bg-orange-600 text-white h-[38px]"><i class="fas fa-plus"></i> Add subcontractor</button>'
                     : '<span class="text-[11px] font-semibold text-slate-500 bg-slate-100 rounded-lg px-3 py-2"><i class="fas fa-eye mr-1"></i>View only</span>')
      + '</div></div><div data-content></div>';
    S.root.querySelectorAll('[data-view]').forEach(function (b) { b.addEventListener('click', function () { setView(b.dataset.view); }); });
    var t = null;
    S.root.querySelector('[data-search]').addEventListener('input', function (e) { clearTimeout(t); t = setTimeout(function () { S.search = e.target.value.trim(); load(); }, 300); });
    S.root.querySelector('[data-status]').addEventListener('change', function (e) { S.status = e.target.value; load(); });
    var add = S.root.querySelector('[data-add]');
    if (add) add.addEventListener('click', function () { editSub(null); });
    setView('auto', true); // first load when the tab is opened (refresh)
    return { refresh: load, openAssignment: openAssignment, openProfile: openProfile, setView: setView };
  }

  function setView(v, noLoad) {
    S.view = v;
    S.root.querySelectorAll('[data-view]').forEach(function (b) { var on = b.dataset.view === v; b.classList.toggle('bg-white', on); b.classList.toggle('shadow-sm', on); b.classList.toggle('text-slate-900', on); });
    S.root.querySelectorAll('[data-filters]').forEach(function (el) { el.style.display = v === 'auto' ? 'none' : ''; });
    var opts = v === 'subs' ? [['', 'All statuses'], ['PENDING', 'Pending approval'], ['APPROVED', 'Approved'], ['SUSPENDED', 'Suspended'], ['INACTIVE', 'Inactive']]
      : [['open', 'Open assignments'], ['', 'All'], ['AWAITING_ACCEPTANCE', 'Awaiting acceptance'], ['AWAITING_INSPECTION', 'Awaiting inspection'], ['REVISION_REQUIRED', 'Revision required'],
         ['IN_PROGRESS', 'In progress'], ['COMPLETED', 'Completed'], ['DECLINED', 'Declined'], ['CANCELLED', 'Cancelled']];
    S.root.querySelector('[data-status]').innerHTML = opts.map(function (o) { return '<option value="' + o[0] + '">' + o[1] + '</option>'; }).join('');
    S.status = opts[0][0];
    var add = S.root.querySelector('[data-add]'); if (add) add.style.display = v === 'subs' ? '' : 'none';
    if (!noLoad) load();
  }

  function table(head, rows, empty) {
    return rows.length ? '<table class="w-full text-sm"><thead><tr class="text-left text-[11px] uppercase text-slate-400">' + head.map(function (h) { return '<th class="px-4 py-3 font-bold">' + h + '</th>'; }).join('') + '</tr></thead><tbody>' + rows.join('') + '</tbody></table>'
      : '<p class="text-slate-400 text-sm p-8 text-center">' + empty + '</p>';
  }
  function card(inner, extra) { return '<div class="bg-white rounded-2xl border border-slate-100 shadow-sm ' + (extra || 'p-5') + '">' + inner + '</div>'; }

  async function load() {
    var c = S.root.querySelector('[data-content]');
    c.innerHTML = '<p class="text-slate-400 text-sm p-6">Loading…</p>';
    if (S.view === 'auto') return loadAuto(c);
    if (S.view === 'subs') {
      var j = await get('subcontractors/list.php', { search: S.search, status: S.status, limit: 200 });
      if (!j.success) { c.innerHTML = '<p class="text-red-600 p-6">' + esc(j.message) + '</p>'; return; }
      var st = j.data.stats;
      c.innerHTML = '<div class="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4">' + [['Approved', st.approved, 'text-emerald-700'], ['Pending approval', st.pending, 'text-amber-700'], ['Suspended', st.suspended, 'text-red-600'], ['Inactive', st.inactive, 'text-slate-500']]
          .map(function (x) { return card('<p class="text-[11px] font-bold uppercase text-slate-400">' + x[0] + '</p><p class="text-xl font-extrabold ' + x[2] + '">' + x[1] + '</p>', 'px-4 py-3'); }).join('') + '</div>'
        + card(table(['Code', 'Subcontractor', 'Area / specialties', 'Status', 'Workload', 'Portal'], j.data.rows.map(function (r) {
            var load = Number(r.open_jobs || 0), max = Number(r.max_active_jobs || 3);
            return '<tr class="border-t border-slate-100 hover:bg-orange-50/40 cursor-pointer" data-sub="' + r.id + '"><td class="px-4 py-3 font-mono text-xs">' + esc(r.subcon_code) + '</td>'
              + '<td class="px-4 py-3"><b>' + esc(r.name) + '</b><span class="block text-xs text-slate-400">' + esc(r.contact_person || r.email || r.phone) + '</span></td>'
              + '<td class="px-4 py-3 text-xs">' + esc(r.area) + '<span class="block text-slate-400">' + esc(r.specialties || r.specialization) + '</span></td>'
              + '<td class="px-4 py-3">' + badge(SUB_BADGE, r.status) + '</td>'
              + '<td class="px-4 py-3"><div class="w-24 bg-slate-100 rounded-full h-2"><div class="h-2 rounded-full ' + (load >= max ? 'bg-red-500' : 'bg-emerald-500') + '" style="width:' + Math.min(100, Math.round(load * 100 / max)) + '%"></div></div><span class="text-[11px] text-slate-500">' + load + ' of ' + max + ' jobs</span></td>'
              + '<td class="px-4 py-3">' + (Number(r.has_login) ? '<span class="text-emerald-700 text-xs font-bold"><i class="fas fa-mobile-screen mr-1"></i>Active</span>' : '<span class="text-xs text-amber-600 font-semibold">No login</span>') + '</td></tr>';
          }), 'No subcontractors match.'), 'overflow-x-auto');
      c.querySelectorAll('[data-sub]').forEach(function (tr) { tr.addEventListener('click', function () { openProfile(tr.dataset.sub); }); });
      return;
    }
    var a = await get('subcontractors/assignments.php', { search: S.search, status: S.status, limit: 300 });
    if (!a.success) { c.innerHTML = '<p class="text-red-600 p-6">' + esc(a.message) + '</p>'; return; }
    c.innerHTML = card(table(['Assignment', 'Job / client', 'Subcontractor', 'Status', 'Expected', 'How'], a.data.rows.map(function (r) {
        return '<tr class="border-t border-slate-100 hover:bg-orange-50/40 cursor-pointer" data-asg="' + r.id + '"><td class="px-4 py-3 font-mono text-xs">' + esc(r.assignment_code) + '</td>'
          + '<td class="px-4 py-3"><b>' + esc(r.job_code) + '</b> <span class="text-xs text-slate-400">' + esc(nice(r.job_type)) + '</span><span class="block text-xs text-slate-500">' + esc(r.client_name) + '</span></td>'
          + '<td class="px-4 py-3">' + esc(r.subcontractor_name) + '</td><td class="px-4 py-3">' + badge(SA_BADGE, r.status, r.status_label) + (r.overdue ? ' <b class="text-[11px] text-red-600">Overdue</b>' : '') + '</td>'
          + '<td class="px-4 py-3 text-xs">' + date(r.expected_completion) + '</td>'
          + '<td class="px-4 py-3 text-xs">' + (Number(r.auto_assigned) ? '<span class="text-violet-700 font-bold"><i class="fas fa-wand-magic-sparkles mr-1"></i>Automatic</span>' : 'By hand') + '</td></tr>';
      }), 'No assignments match.'), 'overflow-x-auto');
    c.querySelectorAll('[data-asg]').forEach(function (tr) { tr.addEventListener('click', function () { openAssignment(tr.dataset.asg); }); });
  }

  // ---- auto-assignment view ------------------------------------------------------------
  async function loadAuto(c) {
    var j = await get('subcontractors/auto.php');
    if (!j.success) { c.innerHTML = '<p class="text-red-600 p-6">' + esc(j.message) + '</p>'; return; }
    var d = j.data, cap = d.capacity, cfg = d.settings, manage = S.canManage && d.can_manage;
    var pct = cap.pct, color = cap.near_full ? '#dc2626' : (pct >= cap.threshold - 15 ? '#d97706' : '#059669');
    var modeLabel = { auto: 'Automatic', suggest: 'Suggest only', off: 'Off' }[cfg.mode];
    var techRows = cap.technicians.map(function (t) {
      var w = t.slots ? Math.min(100, Math.round(t.open_jobs * 100 / t.slots)) : 100;
      return '<div class="flex items-center gap-3 py-1.5 text-xs"><span class="w-40 truncate font-semibold text-slate-700" title="' + esc(t.full_name) + '">' + esc(t.full_name) + '</span>'
        + '<div class="flex-1 bg-slate-100 rounded-full h-2.5"><div class="h-2.5 rounded-full" style="width:' + w + '%;background:' + (!t.on_duty ? '#94a3b8' : t.free ? '#059669' : '#dc2626') + '"></div></div>'
        + '<span class="w-28 text-right ' + (t.free ? 'text-slate-600' : 'text-red-600 font-bold') + '">' + (t.on_duty ? t.open_jobs + ' / ' + t.slots + (t.free ? ' · ' + t.free + ' free' : ' · full') : esc(nice(t.availability))) + '</span></div>';
    }).join('');
    c.innerHTML = '<div class="grid lg:grid-cols-3 gap-4">'
      + card('<p class="text-[11px] font-bold uppercase text-slate-400">Technician capacity</p>'
          + '<div class="flex items-end gap-3 mt-1"><p class="text-4xl font-extrabold" style="color:' + color + '">' + pct + '%</p><p class="text-xs text-slate-500 pb-1">' + cap.used + ' of ' + cap.slots + ' job slots used · ' + cap.free_technicians + ' technician(s) with a free slot</p></div>'
          + '<div class="relative bg-slate-100 rounded-full h-3 mt-3"><div class="h-3 rounded-full" style="width:' + Math.min(100, pct) + '%;background:' + color + '"></div>'
          + '<div class="absolute top-[-4px] h-5 w-0.5 bg-slate-700" style="left:' + cfg.threshold + '%" title="Threshold ' + cfg.threshold + '%"></div></div>'
          + '<p class="text-xs mt-3 ' + (cap.near_full ? 'text-red-700 font-bold' : 'text-emerald-700 font-semibold') + '">'
          + (cap.near_full ? '<i class="fas fa-triangle-exclamation mr-1"></i>Technicians are almost full — new jobs go to subcontractors' + (cfg.mode === 'auto' ? ' automatically.' : (cfg.mode === 'suggest' ? ' as suggestions.' : ' (automatic assignment is off).'))
                           : '<i class="fas fa-circle-check mr-1"></i>Technicians have room — new jobs stay with them until ' + cfg.threshold + '% of slots are used.') + '</p>', 'p-5 lg:col-span-2')
      + card('<p class="text-[11px] font-bold uppercase text-slate-400 mb-2">Rules</p>'
          + (manage ? '<div class="space-y-2">'
              + field('Automatic assignment', '<select id="au-mode" class="' + inputCls + '">' + [['auto', 'Automatic — offer jobs to subcontractors'], ['suggest', 'Suggest only — Management decides'], ['off', 'Off']].map(function (o) { return '<option value="' + o[0] + '"' + (cfg.mode === o[0] ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select>')
              + '<div class="grid grid-cols-3 gap-2">' + field('Jobs per tech', input('au-max', cfg.tech_max, 'number', 'min="1" max="20"')) + field('Near full at %', input('au-thr', cfg.threshold, 'number', 'min="10" max="100"')) + field('Offer valid (h)', input('au-hrs', cfg.offer_hours, 'number', 'min="1" max="168"')) + '</div>'
              + '<button data-au-save class="' + btn + ' bg-slate-800 text-white w-full justify-center">Save rules</button></div>'
            : '<p class="text-sm"><b>' + modeLabel + '</b> · ' + cfg.tech_max + ' jobs per technician · near full at ' + cfg.threshold + '% · offers valid ' + cfg.offer_hours + ' h</p>')
          + '<p class="text-[11px] text-slate-400 mt-2">' + d.subcontractors_ready + ' approved subcontractor(s) with an active portal login can receive offers.</p>', 'p-5')
      + '</div>'
      + '<div class="grid lg:grid-cols-2 gap-4 mt-4">'
      + card('<p class="text-[11px] font-bold uppercase text-slate-400 mb-2">Technician slots</p>' + (techRows || '<p class="text-xs text-slate-400">No active technicians.</p>'), 'p-5')
      + card('<div class="flex items-center justify-between mb-2"><p class="text-[11px] font-bold uppercase text-slate-400">Jobs waiting for someone</p>'
          + (manage ? '<button data-au-run class="' + btn + ' bg-orange-500 hover:bg-orange-600 text-white"><i class="fas fa-play"></i> Run auto-assign now</button>' : '') + '</div>'
          + (d.waiting.length ? d.waiting.map(function (w) {
              return '<div class="flex flex-wrap items-center justify-between gap-2 py-2 border-b border-slate-50 text-xs"><span><b>' + esc(w.job_code) + '</b> ' + esc(nice(w.job_type)) + ' · ' + esc(w.client_name) + '<span class="block text-slate-400">' + esc(w.site_address) + ' · ' + when(w.created_at) + '</span></span>'
                + (manage ? '<button class="' + btn + ' bg-slate-100 text-slate-700" data-assign-job="' + w.id + '" data-code="' + esc(w.job_code) + '">Offer…</button>' : '') + '</div>'; }).join('')
            : '<p class="text-xs text-slate-400">Every open job has a technician or a subcontractor.</p>'), 'p-5')
      + '</div>'
      + card('<p class="text-[11px] font-bold uppercase text-slate-400 mb-2">Automatic decisions</p>' + (d.log.length ? d.log.map(function (l) {
          return '<button class="w-full text-left py-2 border-b border-slate-50 text-xs hover:bg-slate-50" data-asg="' + l.assignment_id + '"><b>' + esc(l.job_code) + '</b> → ' + esc(l.subcontractor_name)
            + ' <span class="text-slate-400">' + when(l.created_at) + '</span><span class="block text-slate-500">' + esc(l.action === 'AUTO_ASSIGNED' ? l.note : nice(l.to_status) + ' — ' + (l.note || '')) + '</span></button>'; }).join('')
          : '<p class="text-xs text-slate-400">No automatic decisions yet. They appear here, with the reason, as soon as the system offers a job.</p>'), 'p-5 mt-4');
    c.querySelectorAll('[data-asg]').forEach(function (b) { b.addEventListener('click', function () { openAssignment(b.dataset.asg); }); });
    c.querySelectorAll('[data-assign-job]').forEach(function (b) { b.addEventListener('click', function () { assignJob({ jobId: Number(b.dataset.assignJob), jobCode: b.dataset.code, hasTechnician: false, onDone: load }); }); });
    var save = c.querySelector('[data-au-save]');
    if (save) save.addEventListener('click', function () { locked(save, async function () {
      var r = await post('subcontractors/auto.php', { action: 'save', mode: val('au-mode'), tech_max_open_jobs: val('au-max'), capacity_threshold: val('au-thr'), offer_hours: val('au-hrs') });
      toast(r.message, !r.success); if (r.success) load();
    }); });
    var run = c.querySelector('[data-au-run]');
    if (run) run.addEventListener('click', function () { locked(run, async function () {
      var older = d.waiting.length && global.confirm('Also offer jobs that were waiting from before automatic assignment was switched on?\n\nOK = include them, Cancel = only new jobs.');
      var r = await post('subcontractors/auto.php', { action: 'run', include_older: older ? 1 : 0 });
      toast(r.message, !r.success); if (r.success) load();
    }); });
  }

  // ---- add / edit -------------------------------------------------------------------
  function editSub(sc) {
    var s = sc || { max_active_jobs: 3 };
    var body = openModal(sc ? 'Edit ' + sc.subcon_code : 'Add subcontractor', '<div class="grid sm:grid-cols-2 gap-3">'
      + field('Company / contractor name *', input('sc-name', s.name)) + field('Contact person', input('sc-contact', s.contact_person))
      + field('Phone', input('sc-phone', s.phone)) + field('Email', input('sc-email', s.email, 'email'))
      + field('Service area', input('sc-area', s.area), 'Cities / provinces they cover, e.g. Bacolod / Talisay — used to match jobs') + field('Address', input('sc-address', s.address))
      + field('Main specialization', input('sc-spec', s.specialization)) + field('Specialties', input('sc-specialties', s.specialties), 'e.g. Solar installation, inverter repair, maintenance')
      + field('Jobs at a time', input('sc-max', s.max_active_jobs, 'number', 'min="1" max="50"'), 'The most open jobs the system will give them')
      + field('Agreed rate (₱)', input('sc-rate', s.default_rate, 'number', 'min="0" step="0.01"'))
      + field('Contract start', input('sc-cstart', s.contract_start, 'date')) + field('Contract end', input('sc-cend', s.contract_end, 'date'))
      + field('Insurance reference', input('sc-ins', s.insurance_ref)) + field('Insurance expiry', input('sc-ins-exp', s.insurance_expiry, 'date'))
      + field('Permit / license reference', input('sc-permit', s.permit_ref)) + field('Contract document reference', input('sc-doc', s.contract_doc_ref))
      + '<div class="sm:col-span-2">' + field('Qualifications', area('sc-qual', s.qualifications, 2)) + '</div>'
      + '<div class="sm:col-span-2">' + field('Notes', area('sc-notes', s.notes, 2)) + '</div></div>'
      + '<div class="flex justify-end gap-2 mt-4"><button data-close class="' + btn + ' bg-slate-100 text-slate-700">Cancel</button><button data-save class="' + btn + ' bg-orange-500 hover:bg-orange-600 text-white">' + (sc ? 'Save changes' : 'Register') + '</button></div>');
    body.querySelector('[data-save]').addEventListener('click', function (e) { locked(e.currentTarget, async function () {
      var p = { name: val('sc-name'), contact_person: val('sc-contact'), phone: val('sc-phone'), email: val('sc-email'), area: val('sc-area'), address: val('sc-address'),
        specialization: val('sc-spec'), specialties: val('sc-specialties'), max_active_jobs: val('sc-max') || 3, default_rate: val('sc-rate'), contract_start: val('sc-cstart'),
        contract_end: val('sc-cend'), insurance_ref: val('sc-ins'), insurance_expiry: val('sc-ins-exp'), permit_ref: val('sc-permit'), contract_doc_ref: val('sc-doc'),
        qualifications: val('sc-qual'), notes: val('sc-notes') };
      if (sc) p.id = sc.id;
      var r = await post(sc ? 'subcontractors/update.php' : 'subcontractors/create.php', p);
      toast(r.message, !r.success); if (!r.success) return;
      closeModal(); load(); openProfile(sc ? sc.id : r.data.id);
    }); });
  }

  // ---- profile -------------------------------------------------------------------------
  async function openProfile(id) {
    openModal('Subcontractor', '<p class="text-slate-400">Loading…</p>', true);
    var j = await get('subcontractors/profile.php', { id: id });
    if (!j.success) { openModal('Subcontractor', '<p class="text-red-600">' + esc(j.message) + '</p>'); return; }
    var d = j.data, s = d.subcontractor, st = d.stats, manage = S.canManage && d.can_manage;
    var row = function (k, v) { return '<div class="flex justify-between gap-3 py-1.5 border-b border-slate-50"><span class="text-slate-400 text-xs font-semibold">' + k + '</span><span class="text-right">' + v + '</span></div>'; };
    var expired = function (dt) { return dt && dt < new Date().toISOString().slice(0, 10) ? ' <b class="text-red-600 text-[11px]">expired</b>' : ''; };
    var acts = '';
    if (manage) {
      acts += '<button data-act="edit" class="' + btn + ' bg-slate-100 text-slate-700"><i class="fas fa-pen"></i> Edit</button>';
      if (s.status !== 'APPROVED') acts += '<button data-act="APPROVED" class="' + btn + ' bg-emerald-600 text-white"><i class="fas fa-check"></i> ' + (s.status === 'PENDING' ? 'Approve' : 'Reactivate') + '</button>';
      if (s.status === 'APPROVED' || s.status === 'PENDING') acts += '<button data-act="SUSPENDED" class="' + btn + ' bg-red-50 text-red-700"><i class="fas fa-ban"></i> Suspend</button>';
      if (s.status !== 'INACTIVE') acts += '<button data-act="INACTIVE" class="' + btn + ' bg-slate-100 text-slate-700"><i class="fas fa-power-off"></i> Deactivate</button>';
      acts += !d.login ? '<button data-act="login" class="' + btn + ' bg-slate-800 text-white"><i class="fas fa-key"></i> Create portal login</button>'
        : '<button data-act="' + (d.login.status === 'ACTIVE' ? 'disable' : 'enable') + '" class="' + btn + ' bg-slate-100 text-slate-700"><i class="fas fa-key"></i> ' + (d.login.status === 'ACTIVE' ? 'Disable login' : 'Enable login') + '</button>';
    }
    var ready = s.status === 'APPROVED' && d.login && d.login.status === 'ACTIVE';
    var body = openModal(s.name + ' · ' + s.subcon_code, '<div class="flex flex-wrap items-center justify-between gap-2 mb-3"><div>' + badge(SUB_BADGE, s.status)
      + (s.status_reason ? ' <span class="text-xs text-slate-500">' + esc(s.status_reason) + '</span>' : '') + '<span class="block text-[11px] text-slate-400 mt-1">Status changed ' + when(s.status_changed_at) + (s.status_changed_by_name ? ' by ' + esc(s.status_changed_by_name) : '') + '</span></div>'
      + '<div class="flex flex-wrap gap-2">' + acts + '</div></div>'
      + '<p class="text-xs rounded-lg px-3 py-2 mb-4 ' + (ready ? 'bg-emerald-50 text-emerald-800' : 'bg-amber-50 text-amber-800') + '"><i class="fas ' + (ready ? 'fa-circle-check' : 'fa-circle-info') + ' mr-1"></i>'
      + (ready ? 'Ready for automatic offers' + (d.login.phone_alerts == 1 ? ' — phone notifications are on.' : ' — ask them to turn on phone notifications in their portal.')
               : 'Not receiving automatic offers yet: ' + (s.status !== 'APPROVED' ? 'approve it' : '') + (s.status !== 'APPROVED' && !(d.login && d.login.status === 'ACTIVE') ? ' and ' : '') + (!(d.login && d.login.status === 'ACTIVE') ? 'create an active portal login' : '') + '.') + '</p>'
      + '<div class="grid sm:grid-cols-5 gap-2 mb-4">' + [['Open jobs', st.open + ' / ' + st.limit], ['Completed', st.completed], ['On time', st.on_time_pct == null ? '—' : st.on_time_pct + '%'], ['Revisions', st.revisions], ['Auto-offered', st.auto_assigned]].map(function (t) {
          return '<div class="bg-slate-50 rounded-xl px-3 py-2"><p class="text-[11px] font-bold uppercase text-slate-400">' + t[0] + '</p><p class="text-lg font-extrabold">' + t[1] + '</p></div>'; }).join('') + '</div>'
      + '<div class="grid md:grid-cols-2 gap-5"><div><p class="text-[11px] font-bold uppercase text-slate-400 mb-1">Details</p>'
      + row('Contact', esc(s.contact_person)) + row('Phone', esc(s.phone)) + row('Email', esc(s.email)) + row('Service area', esc(s.area)) + row('Address', esc(s.address))
      + row('Specialties', esc([s.specialization, s.specialties].filter(Boolean).join(' · '))) + row('Agreed rate', s.default_rate != null ? peso(s.default_rate) : '—')
      + row('Contract', date(s.contract_start) + ' – ' + date(s.contract_end) + expired(s.contract_end)) + row('Insurance', esc(s.insurance_ref) + (s.insurance_expiry ? ' · until ' + date(s.insurance_expiry) + expired(s.insurance_expiry) : ''))
      + row('Permit / license', esc(s.permit_ref)) + row('Contract document', esc(s.contract_doc_ref)) + row('Qualifications', esc(s.qualifications))
      + row('Portal login', d.login ? esc(d.login.email) + ' · ' + esc(nice(d.login.status)) + (d.login.last_login ? ' · last ' + when(d.login.last_login) : '') : 'None') + '</div>'
      + '<div><p class="text-[11px] font-bold uppercase text-slate-400 mb-1">Quality issues</p>' + (d.quality_issues.length ? d.quality_issues.map(function (q) {
          return '<div class="py-1.5 border-b border-slate-50 text-xs"><b>' + esc(q.job_code) + '</b> ' + esc(nice(q.to_status)) + ' — ' + esc(q.note) + '<span class="block text-slate-400">' + when(q.created_at) + '</span></div>'; }).join('')
          : '<p class="text-xs text-slate-400">No revisions, declines or cancellations.</p>')
      + '<p class="text-[11px] font-bold uppercase text-slate-400 mt-4 mb-1">History</p>' + d.history.map(function (h) { return '<div class="text-xs py-1 border-b border-slate-50"><b>' + esc(nice(h.action)) + '</b>' + (h.to_status ? ' → ' + esc(nice(h.to_status)) : '') + (h.note ? ' · ' + esc(h.note) : '') + '<span class="text-slate-400"> · ' + when(h.created_at) + (h.by_name ? ' · ' + esc(h.by_name) : '') + '</span></div>'; }).join('') + '</div></div>'
      + '<p class="text-[11px] font-bold uppercase text-slate-400 mt-5 mb-2">Assigned jobs</p>'
      + (d.assignments.length ? '<div class="border border-slate-100 rounded-xl overflow-x-auto">' + table(['Assignment', 'Job', 'Client', 'Status', 'How'], d.assignments.map(function (a) {
          return '<tr class="border-t border-slate-100 hover:bg-orange-50/40 cursor-pointer" data-asg="' + a.id + '"><td class="px-4 py-2 font-mono text-xs">' + esc(a.assignment_code) + '</td><td class="px-4 py-2">' + esc(a.job_code) + '</td><td class="px-4 py-2">' + esc(a.client_name) + '</td>'
            + '<td class="px-4 py-2">' + badge(SA_BADGE, a.status, a.status_label) + (a.overdue ? ' <b class="text-[11px] text-red-600">Overdue</b>' : '') + '</td><td class="px-4 py-2 text-xs">' + (a.auto_assigned ? 'Automatic' : 'By hand') + '</td></tr>'; }), '') + '</div>'
        : '<p class="text-xs text-slate-400">No jobs yet.</p>'), true);
    body.querySelectorAll('[data-asg]').forEach(function (tr) { tr.addEventListener('click', function () { openAssignment(tr.dataset.asg); }); });
    body.querySelectorAll('[data-act]').forEach(function (b) { b.addEventListener('click', function () {
      var act = b.dataset.act;
      if (act === 'edit') return editSub(s);
      if (act === 'login') return createLogin(s);
      locked(b, async function () {
        var r;
        if (act === 'disable' || act === 'enable') r = await post('subcontractors/account.php', { id: s.id, action: act });
        else {
          var reason = '';
          if (act !== 'APPROVED') { reason = ask((act === 'SUSPENDED' ? 'Suspend ' : 'Deactivate ') + s.name + '? Reason (required):', 5); if (reason === null) return; }
          r = await post('subcontractors/status.php', { id: s.id, status: act, reason: reason });
        }
        toast(r.message, !r.success); if (r.success) { load(); openProfile(s.id); }
      });
    }); });
  }

  function createLogin(s) {
    var body = openModal('Portal login — ' + s.name, '<p class="text-xs text-slate-500 mb-3">They sign in on the normal SunTrack login page, see only their own jobs, and get a phone notification for every job offered to them (after turning notifications on in the portal).</p>'
      + '<div class="space-y-3">' + field('Name of the person signing in', input('lg-name', s.contact_person)) + field('Email', input('lg-email', s.email, 'email'))
      + field('Temporary password', input('lg-pass', '', 'text', 'autocomplete="new-password"'), 'At least 8 characters.') + '</div>'
      + '<div class="flex justify-end gap-2 mt-4"><button data-close class="' + btn + ' bg-slate-100 text-slate-700">Cancel</button><button data-save class="' + btn + ' bg-slate-800 text-white">Create login</button></div>');
    body.querySelector('[data-save]').addEventListener('click', function (e) { locked(e.currentTarget, async function () {
      var r = await post('subcontractors/account.php', { id: s.id, action: 'create', full_name: val('lg-name'), email: val('lg-email'), password: document.getElementById('lg-pass').value });
      toast(r.message, !r.success); if (r.success) { load(); openProfile(s.id); }
    }); });
  }

  // ---- assignment -------------------------------------------------------------------------
  async function openAssignment(id) {
    openModal('Assignment', '<p class="text-slate-400">Loading…</p>', true);
    var j = await get('subcontractors/assignments.php', { id: id });
    if (!j.success) { openModal('Assignment', '<p class="text-red-600">' + esc(j.message) + '</p>'); return; }
    var d = j.data, a = d.assignment, cl = d.checklist;
    var sec = function (t, h) { return '<div class="mt-5"><p class="text-[11px] font-bold uppercase text-slate-400 mb-2">' + t + '</p>' + h + '</div>'; };
    var acts = '';
    if (d.actions.indexOf('approve') >= 0) acts += '<button data-a="approve" class="' + btn + ' bg-emerald-600 text-white"><i class="fas fa-check"></i> Approve &amp; complete</button>';
    if (d.actions.indexOf('revision') >= 0) acts += '<button data-a="revision" class="' + btn + ' bg-orange-500 text-white"><i class="fas fa-rotate-left"></i> Request revision</button>';
    if (d.actions.indexOf('cancel') >= 0) acts += '<button data-a="cancel" class="' + btn + ' bg-red-50 text-red-700"><i class="fas fa-ban"></i> Cancel assignment</button>';
    var files = d.files.length ? '<div class="grid grid-cols-2 sm:grid-cols-4 gap-2">' + d.files.map(function (f) {
        return '<a href="' + esc(f.url) + '" target="_blank" rel="noopener" class="block border border-slate-200 rounded-xl overflow-hidden hover:border-orange-400">'
          + (f.mime.indexOf('image/') === 0 ? '<img src="' + esc(f.url) + '" alt="" loading="lazy" class="w-full h-24 object-cover bg-slate-100">' : '<div class="h-24 flex items-center justify-center bg-slate-50 text-slate-400"><i class="fas fa-file-pdf text-2xl"></i></div>')
          + '<div class="px-2 py-1 text-[11px]"><b class="block truncate">' + esc(f.original_name) + '</b><span class="text-slate-400">' + esc(nice(f.category)) + ' · round ' + (f.round + 1) + '</span></div></a>'; }).join('') + '</div>'
      : '<p class="text-xs text-slate-400">No photos or documents yet.</p>';
    var body = openModal(a.assignment_code + ' · ' + a.job_code, '<div class="flex flex-wrap items-start justify-between gap-3"><div><p class="text-lg font-extrabold">' + esc(a.subcontractor_name) + ' <span class="text-xs text-slate-400">' + esc(a.subcon_code) + '</span></p>'
      + '<p class="text-xs text-slate-500">' + esc(nice(a.job_type)) + ' for ' + esc(a.client_name) + ' · ' + esc(a.site_address) + ' · job stage ' + esc(nice(a.job_stage)) + '</p></div>' + badge(SA_BADGE, a.status, a.status_label) + '</div>'
      + '<p class="mt-3 text-xs rounded-lg px-3 py-2 ' + (Number(a.auto_assigned) ? 'bg-violet-50 text-violet-800' : 'bg-slate-50 text-slate-600') + '"><i class="fas ' + (Number(a.auto_assigned) ? 'fa-wand-magic-sparkles' : 'fa-user') + ' mr-1"></i><b>' + (Number(a.auto_assigned) ? 'Assigned automatically' : 'Assigned by ' + esc(a.assigned_by_name)) + ':</b> ' + esc(a.assignment_reason) + '</p>'
      + (a.status === 'AWAITING_ACCEPTANCE' && a.offer_expires_at ? '<p class="mt-2 text-xs text-amber-700"><i class="fas fa-hourglass-half mr-1"></i>Waiting for their answer until ' + when(a.offer_expires_at) + '. If they decline or do not answer, the next-best subcontractor is offered the job.</p>' : '')
      + (a.review_note ? '<p class="mt-2 text-xs rounded-lg px-3 py-2 bg-orange-50 text-orange-800"><b>Last review:</b> ' + esc(a.review_note) + '</p>' : '')
      + (a.decline_reason ? '<p class="mt-2 text-xs rounded-lg px-3 py-2 bg-slate-50 text-slate-600"><b>Declined:</b> ' + esc(a.decline_reason) + '</p>' : '')
      + (acts ? '<div class="flex flex-wrap gap-2 mt-3">' + acts + '</div>' : '')
      + sec('Scope', '<p class="whitespace-pre-line">' + esc(a.scope) + '</p>' + (a.instructions ? '<p class="whitespace-pre-line text-slate-600 mt-2">' + esc(a.instructions) + '</p>' : '') + (a.materials_note ? '<p class="text-slate-600 mt-2"><b>Materials:</b> ' + esc(a.materials_note) + '</p>' : ''))
      + sec('Dates', '<div class="grid sm:grid-cols-3 gap-2 text-xs"><span>Offered ' + when(a.assigned_at) + '</span><span>Answered ' + when(a.responded_at) + '</span><span>Scheduled ' + date(a.scheduled_date) + '</span>'
          + '<span>Expected ' + date(a.expected_completion) + '</span><span>Submitted ' + when(a.submitted_at) + '</span><span>Completed ' + when(a.completed_at) + (a.completed_by_name ? ' by ' + esc(a.completed_by_name) : '') + '</span></div>')
      + sec('Checklist', cl.type ? '<p class="text-xs mb-1">' + (cl.items.length - cl.pending) + ' of ' + cl.items.length + ' done (the same checklist the ' + (cl.type === 'installation' ? 'Installation' : 'Maintenance') + ' tab shows).</p><details><summary class="text-xs font-bold text-orange-600 cursor-pointer">Show items</summary>'
          + cl.items.map(function (i) { return '<div class="text-xs py-1 border-b border-slate-50">' + (i.status === 'PENDING' ? '<i class="far fa-square text-slate-300"></i>' : '<i class="fas fa-square-check text-emerald-600"></i>') + ' ' + esc(i.description) + ' <span class="text-slate-400">' + esc(nice(i.status)) + (i.remarks ? ' · ' + esc(i.remarks) : '') + '</span></div>'; }).join('') + '</details>'
        : '<p class="text-xs text-slate-400">' + (['INSTALLATION', 'MAINTENANCE'].indexOf(a.job_type) >= 0 ? 'Created when the subcontractor starts work.' : 'No checklist for this job type — evidence is the photos and documents.') + '</p>')
      + sec('Photos and documents', files)
      + sec('History', d.events.map(function (e) { return '<div class="text-xs py-1.5 border-b border-slate-50"><b>' + esc(nice(e.action)) + '</b>' + (e.to_status ? ' → ' + esc(nice(e.to_status)) : '') + (e.note ? ' · ' + esc(e.note) : '')
          + '<span class="text-slate-400"> · ' + when(e.created_at) + ' · ' + esc(e.actor_name || (e.actor_role === 'system' ? 'Automatic' : 'System')) + (e.actor_role && e.actor_role !== 'system' ? ' (' + esc(e.actor_role) + ')' : '') + '</span></div>'; }).join('')), true);
    body.querySelectorAll('[data-a]').forEach(function (b) { b.addEventListener('click', function () {
      var act = b.dataset.a, note = '';
      if (act === 'revision') { note = ask('What must be corrected? (sent to the subcontractor)', 5); if (note === null) return; }
      if (act === 'cancel') { note = ask('Cancel ' + a.assignment_code + '? The job is offered again automatically if technicians are still near full. Reason:', 5); if (note === null) return; }
      if (act === 'approve') { if (!global.confirm('Approve the work on ' + a.job_code + '? The job becomes COMPLETED.')) return; note = global.prompt('Inspection note (optional):', '') || ''; }
      locked(b, async function () { var r = await post('subcontractors/assignment_action.php', { assignment_id: a.id, action: act, note: note }); toast(r.message, !r.success); if (r.success) { load(); openAssignment(id); } });
    }); });
  }

  // ---- offer a job by hand (Jobs tab or waiting list) -----------------------------------------
  async function assignJob(o) {
    var body = openModal('Offer ' + o.jobCode + ' to a subcontractor', '<p class="text-slate-400">Finding the best matches…</p>');
    var j = await get('subcontractors/assign.php', { job_id: o.jobId });
    var c = j.success ? j.data.candidates : [];
    if (!c.length) { body.innerHTML = '<p class="text-sm text-slate-500">No approved subcontractor with an active portal login and free capacity right now. Approve one and create its login in the Subcontractors view.</p>'; return; }
    body.innerHTML = '<div class="space-y-3">'
      + field('Subcontractor (best match first)', '<select id="as-sub" class="' + inputCls + '">' + c.map(function (s, i) { return '<option value="' + s.id + '">' + (i === 0 ? '★ ' : '') + esc(s.subcon_code + ' — ' + s.name) + ' · ' + esc(s.reasons.join(', ')) + '</option>'; }).join('') + '</select>')
      + field('Job scope *', area('as-scope', '', 3)) + field('Work instructions', area('as-ins', '', 2)) + field('Materials and equipment', area('as-mat', '', 2))
      + '<div class="grid grid-cols-2 gap-3">' + field('Agreed amount (₱)', input('as-amt', '', 'number', 'min="0" step="0.01"')) + field('Expected completion', input('as-exp', '', 'date', 'min="' + new Date().toISOString().slice(0, 10) + '"')) + '</div>'
      + (o.hasTechnician ? '<label class="flex items-start gap-2 text-xs bg-amber-50 text-amber-800 rounded-lg p-3"><input id="as-replace" type="checkbox" class="mt-0.5"> Take this job off its technician (who has not started) and give it to the subcontractor.</label>' : '')
      + '</div><div class="flex justify-end gap-2 mt-4"><button data-close class="' + btn + ' bg-slate-100 text-slate-700">Cancel</button><button data-save class="' + btn + ' bg-orange-500 hover:bg-orange-600 text-white">Offer the job</button></div>'
      + '<p class="text-[11px] text-slate-400 mt-2">They get a phone notification and see it on their dashboard. If they decline, the job goes to the next-best subcontractor automatically.</p>';
    body.querySelector('[data-save]').addEventListener('click', function (e) { locked(e.currentTarget, async function () {
      var r = await post('subcontractors/assign.php', { job_id: o.jobId, subcontractor_id: Number(val('as-sub')), scope: val('as-scope'), instructions: val('as-ins'), materials_note: val('as-mat'),
        contract_amount: val('as-amt') || 0, expected_completion: val('as-exp'), replace_technician: !!(document.getElementById('as-replace') || {}).checked });
      toast(r.message, !r.success); if (r.success) { closeModal(); if (o.onDone) o.onDone(r.data); }
    }); });
  }

  global.SunTrackSubcon = { mount: mount, assignJob: function (o) { return assignJob(o); } };
})(window);
