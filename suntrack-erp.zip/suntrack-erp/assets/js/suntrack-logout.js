/**
 * SunTrack — "Ready to sign out?" before logging out.
 *
 * Every logout link (a[href$="logout.php"], sidebar and mobile header alike)
 * asks first, in plain words, instead of signing out on a stray tap. The link
 * itself still works without JavaScript. Esc or "Stay signed in" closes the
 * box; nothing is lost either way.
 */
(function () {
  'use strict';

  var box = null;
  var lastFocus = null;
  var target = null;

  function build() {
    var isTech = /\/technician\//.test(location.pathname);
    box = document.createElement('div');
    box.className = 'st-logout';
    box.setAttribute('role', 'dialog');
    box.setAttribute('aria-modal', 'true');
    box.setAttribute('aria-labelledby', 'st-logout-title');
    box.innerHTML = ''
      + '<div class="st-logout-card">'
      +   '<div class="st-logout-icon"><i class="fas fa-right-from-bracket"></i></div>'
      +   '<h3 id="st-logout-title">Ready to sign out?</h3>'
      +   '<p>You\'ll need to sign in again to get back to SunTrack. Everything you\'ve already saved is safe.</p>'
      +   (isTech ? '<p class="st-logout-tip"><i class="fas fa-location-dot"></i> Still on a job? Remember to <b>Time Out</b> first so your hours are recorded.</p>' : '')
      +   '<div class="st-logout-actions">'
      +     '<button type="button" class="st-logout-stay">Stay signed in</button>'
      +     '<button type="button" class="st-logout-go"><i class="fas fa-right-from-bracket"></i> Yes, sign me out</button>'
      +   '</div>'
      + '</div>';
    document.body.appendChild(box);

    box.addEventListener('click', function (e) { if (e.target === box) close(); }); // tap outside = stay
    box.querySelector('.st-logout-stay').addEventListener('click', close);
    box.querySelector('.st-logout-go').addEventListener('click', function () {
      var go = box.querySelector('.st-logout-go');
      go.disabled = true;
      go.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Signing you out...';
      window.location.href = target;
    });
    box.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { e.preventDefault(); close(); }
      if (e.key === 'Tab') { // keep focus inside the box
        var b = box.querySelectorAll('button');
        if (e.shiftKey && document.activeElement === b[0]) { e.preventDefault(); b[b.length - 1].focus(); }
        else if (!e.shiftKey && document.activeElement === b[b.length - 1]) { e.preventDefault(); b[0].focus(); }
      }
    });
  }

  function open(href) {
    if (!box) build();
    target = href;
    lastFocus = document.activeElement;
    box.classList.add('st-logout-open');
    var go = box.querySelector('.st-logout-go');
    go.disabled = false;
    go.innerHTML = '<i class="fas fa-right-from-bracket"></i> Yes, sign me out';
    box.querySelector('.st-logout-stay').focus(); // the safe choice has focus
  }

  function close() {
    box.classList.remove('st-logout-open');
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }

  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[href$="logout.php"]');
    if (!a || e.ctrlKey || e.metaKey || e.shiftKey) return;
    e.preventDefault();
    open(a.href);
  });

  var style = document.createElement('style');
  style.textContent = ''
    + '.st-logout{position:fixed;inset:0;z-index:3000;display:none;align-items:center;justify-content:center;padding:16px;background:rgba(15,23,42,.55)}'
    + '.st-logout.st-logout-open{display:flex}'
    + '.st-logout-card{width:100%;max-width:380px;background:#fff;border-radius:18px;padding:26px 24px 20px;text-align:center;box-shadow:0 20px 50px rgba(0,0,0,.25);font-family:inherit}'
    + '.st-logout-icon{width:52px;height:52px;margin:0 auto 12px;border-radius:999px;background:#fff7ed;color:#f97316;display:flex;align-items:center;justify-content:center;font-size:20px}'
    + '.st-logout-card h3{margin:0 0 6px;font-size:18px;font-weight:800;color:#0f172a}'
    + '.st-logout-card p{margin:0;font-size:14px;line-height:1.5;color:#475569}'
    + '.st-logout-card .st-logout-tip{margin-top:10px;font-size:12.5px;background:#fffbeb;color:#92400e;border-radius:10px;padding:8px 10px;text-align:left}'
    + '.st-logout-tip i{margin-right:4px}'
    + '.st-logout-actions{display:flex;gap:8px;margin-top:20px}'
    + '.st-logout-actions button{flex:1;padding:11px 12px;border-radius:12px;font-size:14px;font-weight:700;cursor:pointer;transition:background .15s}'
    + '.st-logout-stay{background:#fff;color:#334155;border:1px solid #e2e8f0}'
    + '.st-logout-stay:hover{background:#f8fafc}'
    + '.st-logout-go{background:#f97316;color:#fff;border:1px solid #f97316}'
    + '.st-logout-go:hover{background:#ea580c}'
    + '.st-logout-go:disabled{opacity:.7;cursor:wait}'
    + '.st-logout-actions button:focus-visible{outline:2px solid #fdba74;outline-offset:2px}'
    + '.st-logout-go i{margin-right:4px}';
  (document.head || document.documentElement).appendChild(style);
})();
