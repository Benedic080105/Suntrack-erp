/**
 * SunTrack — search & filter bars.
 *
 * One behaviour for every list's toolbar, so each portal does not wire it by
 * hand (and get it slightly different each time):
 *
 *   - typing searches by itself after a short pause
 *   - Enter searches immediately, Esc clears the search box
 *   - changing any dropdown / date filter reloads at once
 *   - a "Clear" button resets everything in one tap
 *   - a small "N results" counter the page fills in after each load
 *
 * The page keeps its own loader; this only decides WHEN to call it.
 *
 *   const bar = SunTrackFilters.bind({
 *     search:  'job-search',                 // text input id (optional)
 *     fields:  ['job-stage', 'job-from'],    // selects / date inputs that reload on change
 *     reset:   ['job-unassigned'],           // extra inputs Clear resets but that already reload themselves
 *     anchor:  'job-refresh',                // element to put Clear + counter after (default: last field)
 *     onChange: loadJobs,
 *     onClear:  () => {},                    // optional: reset page-held state too
 *   });
 *   bar.setCount(rows.length);              // after the loader renders
 */
(function (global) {
  'use strict';

  function el(id) {
    return typeof id === 'string' ? document.getElementById(id) : id;
  }

  function bind(opts) {
    var delay = opts.delay || 350;
    var search = opts.search ? el(opts.search) : null;
    var fields = (opts.fields || []).map(el).filter(Boolean);
    var resetOnly = (opts.reset || []).map(el).filter(Boolean);
    var timer = null;

    function run() {
      clearTimeout(timer);
      timer = null;
      opts.onChange();
    }

    if (search) {
      search.setAttribute('autocomplete', 'off');
      if (!search.getAttribute('title')) {
        search.setAttribute('title', 'Type any words — every word must match, in any order. Enter to search, Esc to clear.');
      }
      search.addEventListener('input', function () {
        clearTimeout(timer);
        timer = setTimeout(run, delay);
      });
      search.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); run(); }
        else if (e.key === 'Escape' && search.value !== '') { search.value = ''; run(); }
      });
    }

    fields.forEach(function (f) { f.addEventListener('change', run); });

    // Clear button + result counter, placed after the anchor.
    var anchor = el(opts.anchor) || fields[fields.length - 1] || search;
    var wrap = document.createElement('span');
    wrap.className = 'st-filter-tools';
    wrap.style.cssText = 'display:inline-flex;align-items:center;gap:8px;align-self:center';

    var clearBtn = document.createElement('button');
    clearBtn.type = 'button';
    clearBtn.textContent = 'Clear';
    clearBtn.title = 'Clear the search and all filters';
    clearBtn.style.cssText = 'font-size:12px;font-weight:700;color:#64748b;padding:6px 10px;border-radius:8px;border:1px solid #e2e8f0;background:#fff;cursor:pointer';
    clearBtn.addEventListener('click', function () {
      if (search) search.value = '';
      fields.concat(resetOnly).forEach(function (f) {
        if (f.type === 'checkbox') f.checked = false;
        else if (f.tagName === 'SELECT') f.selectedIndex = 0;
        else f.value = '';
      });
      if (opts.onClear) opts.onClear();
      run();
      if (search) search.focus();
    });

    var count = document.createElement('span');
    count.style.cssText = 'font-size:12px;color:#94a3b8;white-space:nowrap';

    wrap.appendChild(clearBtn);
    wrap.appendChild(count);
    if (anchor && anchor.parentNode) {
      // A field wrapped in its own small <div><label/><input/></div> gets the
      // tools after that wrapper, not squeezed inside it.
      var host = anchor;
      var p = anchor.parentNode;
      if (p.tagName === 'DIV' && p.children.length === 2 && p.children[0].tagName === 'LABEL') host = p;
      host.parentNode.insertBefore(wrap, host.nextSibling);
    }

    function isFiltered() {
      if (search && search.value.trim() !== '') return true;
      return fields.concat(resetOnly).some(function (f) {
        return f.type === 'checkbox' ? f.checked : (f.tagName === 'SELECT' ? f.selectedIndex > 0 : f.value !== '');
      });
    }

    return {
      /** Show "N results" (or "N of M" when a total is known). */
      setCount: function (n, total) {
        if (typeof n !== 'number') { count.textContent = ''; return; }
        var label = n === 1 ? ' result' : ' results';
        // Lists load past 500 automatically (see suntrack-paging.js) up to 5000.
        count.textContent = (typeof total === 'number' && total !== n ? n + ' of ' + total : n) + label + (n >= 5000 ? ' (first 5000 — narrow the search)' : '');
        clearBtn.style.color = isFiltered() ? '#f97316' : '#64748b';
        clearBtn.style.borderColor = isFiltered() ? '#fdba74' : '#e2e8f0';
      },
      run: run,
    };
  }

  global.SunTrackFilters = { bind: bind };
})(window);
