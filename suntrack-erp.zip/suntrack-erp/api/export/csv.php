<?php
/**
 * CSV Exports — generic export endpoint.
 * Accepts ?type=<whitelisted table key> plus the same filters the matching
 * list.php endpoint accepts, and streams a CSV download instead of JSON.
 * One shared file keeps every tab's "Export CSV" button working the same way.
 */
require_once __DIR__ . '/../../middleware/admin.php';

$pdo = db();
$type = $_GET['type'] ?? '';

// Searches use search_clause() + search_columns() — the same columns as each
// list.php — so an export always contains exactly what the screen showed.

$columns = [];
$rows = [];
$filenameBase = 'export';

switch ($type) {
    case 'staff': {
        $filenameBase = 'staff';
        $where = []; $params = [];
        if ($clause = search_clause($_GET['search'] ?? '', search_columns('staff'), $params)) { $where[] = $clause; }
        if (!empty($_GET['status'])) { $where[] = 's.status = :status'; $params[':status'] = $_GET['status']; }
        $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
        $stmt = $pdo->prepare("SELECT s.staff_code, u.full_name, u.email, u.phone, s.department, s.position, s.status
                                FROM staff s JOIN users u ON u.id = s.user_id $whereSql ORDER BY s.id DESC");
        $stmt->execute($params); $rows = $stmt->fetchAll();
        $columns = ['staff_code'=>'Code','full_name'=>'Name','email'=>'Email','phone'=>'Phone','department'=>'Department','position'=>'Position','status'=>'Status'];
        break;
    }
    case 'projects': {
        $filenameBase = 'projects';
        $where = []; $params = [];
        if ($clause = search_clause($_GET['search'] ?? '', search_columns('projects'), $params)) { $where[] = $clause; }
        if (!empty($_GET['status'])) { $where[] = 'p.status = :status'; $params[':status'] = $_GET['status']; }
        if (!empty($_GET['technician_id'])) { $where[] = 'p.assigned_technician_id = :tech_id'; $params[':tech_id'] = (int)$_GET['technician_id']; }
        apply_date_range('p.installation_date', $where, $params);
        $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
        $stmt = $pdo->prepare("SELECT p.project_code, p.site_name, cu.full_name AS client_name, p.capacity_kw,
                                       tu.full_name AS technician_name, p.progress, p.status, p.installation_date
                                FROM projects p JOIN clients c ON c.id = p.client_id JOIN users cu ON cu.id = c.user_id
                                LEFT JOIN technicians t ON t.id = p.assigned_technician_id LEFT JOIN users tu ON tu.id = t.user_id
                                $whereSql ORDER BY p.id DESC");
        $stmt->execute($params); $rows = $stmt->fetchAll();
        $columns = ['project_code'=>'Code','site_name'=>'Site','client_name'=>'Client','capacity_kw'=>'Capacity (kW)','technician_name'=>'Technician','progress'=>'Progress %','status'=>'Status','installation_date'=>'Installation Date'];
        break;
    }
    case 'maintenance': {
        $filenameBase = 'maintenance_reminders';
        maintenance_refresh_statuses();
        $where = []; $params = [];
        if ($clause = search_clause($_GET['search'] ?? '', search_columns('maintenance'), $params)) { $where[] = $clause; }
        if (!empty($_GET['status'])) { $where[] = 'ms.status = :status'; $params[':status'] = $_GET['status']; }
        apply_date_range('ms.next_maintenance', $where, $params);
        $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
        $stmt = $pdo->prepare("SELECT p.project_code, p.site_name, cu.full_name AS client_name,
                                       ms.last_maintenance, ms.next_maintenance, ms.status, ms.client_notified
                                FROM maintenance_schedules ms JOIN projects p ON p.id = ms.project_id
                                JOIN clients c ON c.id = p.client_id JOIN users cu ON cu.id = c.user_id
                                $whereSql ORDER BY ms.next_maintenance ASC");
        $stmt->execute($params); $rows = $stmt->fetchAll();
        $columns = ['project_code'=>'Project','site_name'=>'Site','client_name'=>'Client','last_maintenance'=>'Last Maintenance','next_maintenance'=>'Next Maintenance','status'=>'Status','client_notified'=>'Client Notified'];
        break;
    }
    case 'subcontractors': {
        $filenameBase = 'subcontractors';
        $where = []; $params = [];
        if ($clause = search_clause($_GET['search'] ?? '', search_columns('subcontractors'), $params)) { $where[] = $clause; }
        if (isset($_GET['approved']) && $_GET['approved'] !== '') { $where[] = 'approved = :approved'; $params[':approved'] = (int)$_GET['approved']; }
        $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
        $stmt = $pdo->prepare("SELECT subcon_code, name, specialization, area, phone, email, approved
                                FROM subcontractors $whereSql ORDER BY id DESC");
        $stmt->execute($params); $rows = $stmt->fetchAll();
        $columns = ['subcon_code'=>'Code','name'=>'Name','specialization'=>'Specialization','area'=>'Area','phone'=>'Phone','email'=>'Email','approved'=>'Approved'];
        break;
    }
    case 'logs': {
        $filenameBase = 'audit_logs';
        $where = []; $params = [];
        if ($clause = search_clause($_GET['search'] ?? '', search_columns('logs'), $params)) { $where[] = $clause; }
        if (!empty($_GET['module'])) { $where[] = 'al.module = :module'; $params[':module'] = $_GET['module']; }
        audit_view_filter(audit_view_for_search($_GET['role'] ?? 'team', $_GET['search'] ?? ''), $where, $params);
        if (!empty($_GET['date_from']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['date_from'])) { $where[] = 'al.created_at >= :date_from'; $params[':date_from'] = $_GET['date_from']; }
        if (!empty($_GET['date_to']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['date_to'])) { $where[] = 'al.created_at < :date_to'; $params[':date_to'] = date('Y-m-d', strtotime($_GET['date_to'] . ' +1 day')); } // inclusive of date_to
        $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
        $stmt = $pdo->prepare("SELECT al.created_at, u.full_name, al.role_key, al.action, al.module, al.record_id, al.ip_address
                                FROM audit_logs al LEFT JOIN users u ON u.id = al.user_id
                                $whereSql ORDER BY al.created_at DESC LIMIT 5000");
        $stmt->execute($params); $rows = $stmt->fetchAll();
        $columns = ['created_at'=>'Timestamp','full_name'=>'User','role_key'=>'Role','action'=>'Action','module'=>'Module','record_id'=>'Record','ip_address'=>'IP Address'];
        break;
    }
    case 'clients': {
        $filenameBase = 'clients';
        $where = []; $params = [];
        if ($clause = search_clause($_GET['search'] ?? '', search_columns('clients'), $params)) { $where[] = $clause; }
        if (!empty($_GET['status'])) { $where[] = 'u.status = :status'; $params[':status'] = $_GET['status']; }
        if (!empty($_GET['city'])) { $where[] = 'c.city = :city'; $params[':city'] = $_GET['city']; }
        if (isset($_GET['has_location']) && $_GET['has_location'] !== '') {
            $where[] = $_GET['has_location'] ? '(c.lat IS NOT NULL AND c.lng IS NOT NULL)' : '(c.lat IS NULL OR c.lng IS NULL)';
        }
        $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
        $stmt = $pdo->prepare("SELECT c.client_code, u.full_name, u.email, u.phone, c.city, c.province, u.status
                                FROM clients c JOIN users u ON u.id = c.user_id $whereSql ORDER BY c.id DESC");
        $stmt->execute($params); $rows = $stmt->fetchAll();
        $columns = ['client_code'=>'Code','full_name'=>'Name','email'=>'Email','phone'=>'Phone','city'=>'City','province'=>'Province','status'=>'Status'];
        break;
    }
    case 'technicians': {
        $filenameBase = 'technicians';
        $where = []; $params = [];
        if ($clause = search_clause($_GET['search'] ?? '', search_columns('technicians'), $params)) { $where[] = $clause; }
        if (!empty($_GET['status'])) { $where[] = 'u.status = :status'; $params[':status'] = $_GET['status']; }
        if (!empty($_GET['availability'])) { $where[] = 'ta.status = :availability'; $params[':availability'] = $_GET['availability']; }
        $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
        $stmt = $pdo->prepare("SELECT t.technician_code, u.full_name, u.email, u.phone, t.specialization, ta.status AS availability, u.status
                                FROM " . tech_staff_table() . " t JOIN users u ON u.id = t.user_id
                                LEFT JOIN technician_availability ta ON ta.technician_id = t.id
                                $whereSql ORDER BY u.full_name");
        $stmt->execute($params); $rows = $stmt->fetchAll();
        $columns = ['technician_code'=>'Code','full_name'=>'Name','email'=>'Email','phone'=>'Phone','specialization'=>'Specialization','availability'=>'Availability','status'=>'Status'];
        break;
    }
    case 'inventory': {
        $filenameBase = 'inventory';
        $where = []; $params = [];
        if ($clause = search_clause($_GET['search'] ?? '', search_columns('inventory'), $params)) { $where[] = $clause; }
        if (!empty($_GET['category'])) { $where[] = 'ic.category_name = :category'; $params[':category'] = $_GET['category']; }
        if (!empty($_GET['status'])) { $where[] = 'i.status = :status'; $params[':status'] = $_GET['status']; }
        $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
        $stmt = $pdo->prepare("SELECT i.sku, i.item_name, ic.category_name, i.brand, i.model, i.quantity, i.unit_cost, i.warehouse_location, i.status
                                FROM inventory i JOIN inventory_categories ic ON ic.id = i.category_id
                                $whereSql ORDER BY i.item_name ASC");
        $stmt->execute($params); $rows = $stmt->fetchAll();
        $columns = ['sku'=>'SKU','item_name'=>'Item','category_name'=>'Category','brand'=>'Brand','model'=>'Model','quantity'=>'Qty','unit_cost'=>'Unit Cost','warehouse_location'=>'Location','status'=>'Status'];
        break;
    }
    case 'attendance': {
        $filenameBase = 'attendance';
        $where = []; $params = [];
        if ($clause = search_clause($_GET['search'] ?? '', search_columns('attendance'), $params)) { $where[] = $clause; }
        if (!empty($_GET['geofence_status'])) { $where[] = 'a.geofence_status = :gs'; $params[':gs'] = $_GET['geofence_status']; }
        if (!empty($_GET['open_only'])) { $where[] = 'a.time_out IS NULL'; }
        apply_date_range('a.time_in', $where, $params);
        $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
        $stmt = $pdo->prepare("SELECT u.full_name AS technician_name, t.technician_code, j.job_code, a.time_in, a.time_out,
                                       a.distance_in_m, a.distance_out_m, a.geofence_status
                                FROM attendance a JOIN technicians t ON t.id = a.technician_id JOIN users u ON u.id = t.user_id
                                JOIN jobs j ON j.id = a.job_id $whereSql ORDER BY a.time_in DESC LIMIT 2000");
        $stmt->execute($params); $rows = $stmt->fetchAll();
        $columns = ['technician_name'=>'Technician','technician_code'=>'Code','job_code'=>'Job','time_in'=>'Time In','time_out'=>'Time Out','distance_in_m'=>'Distance In (m)','distance_out_m'=>'Distance Out (m)','geofence_status'=>'Geofence'];
        break;
    }
    case 'work_reports': {
        $filenameBase = 'work_reports';
        $where = []; $params = [];
        if ($clause = search_clause($_GET['search'] ?? '', search_columns('work_reports'), $params)) { $where[] = $clause; }
        apply_date_range('wr.submitted_date', $where, $params);
        $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
        $stmt = $pdo->prepare("SELECT wr.report_code, j.job_code, tu.full_name AS technician_name, cu.full_name AS client_name,
                                       wr.work_type, wr.submitted_date, COALESCE(wr.duration_text, wr.duration_minutes) AS duration_text, wr.remarks
                                FROM work_reports wr JOIN jobs j ON j.id = wr.job_id
                                JOIN technicians t ON t.id = wr.technician_id JOIN users tu ON tu.id = t.user_id
                                JOIN clients c ON c.id = wr.client_id JOIN users cu ON cu.id = c.user_id
                                $whereSql ORDER BY wr.submitted_date DESC LIMIT 2000");
        $stmt->execute($params); $rows = $stmt->fetchAll();
        $columns = ['report_code'=>'Report','job_code'=>'Job','technician_name'=>'Technician','client_name'=>'Client','work_type'=>'Type','submitted_date'=>'Submitted','duration_text'=>'Duration','remarks'=>'Remarks'];
        break;
    }
    case 'service_requests': {
        $filenameBase = 'service_requests';
        $where = []; $params = [];
        if (!empty($_GET['status'])) { $where[] = 'sr.status = :status'; $params[':status'] = $_GET['status']; }
        if (!empty($_GET['priority'])) { $where[] = 'sr.priority = :priority'; $params[':priority'] = $_GET['priority']; }
        if (!empty($_GET['unassigned'])) { $where[] = 'sr.assigned_technician_id IS NULL'; }
        if ($clause = search_clause($_GET['search'] ?? '', search_columns('service_requests'), $params)) { $where[] = $clause; }
        apply_date_range('sr.date_requested', $where, $params);
        $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
        $stmt = $pdo->prepare("SELECT sr.request_code, u.full_name AS client_name, sr.request_type, sr.priority, sr.status,
                                       tu.full_name AS technician_name, sr.date_requested, sr.completion_date
                                FROM service_requests sr JOIN clients c ON c.id = sr.client_id JOIN users u ON u.id = c.user_id
                                LEFT JOIN technicians t ON t.id = sr.assigned_technician_id LEFT JOIN users tu ON tu.id = t.user_id
                                $whereSql ORDER BY sr.date_requested DESC");
        $stmt->execute($params); $rows = $stmt->fetchAll();
        $columns = ['request_code'=>'Code','client_name'=>'Client','request_type'=>'Type','priority'=>'Priority','status'=>'Status','technician_name'=>'Technician','date_requested'=>'Requested','completion_date'=>'Completed'];
        break;
    }
    case 'billing': {
        $filenameBase = 'billing';
        $where = []; $params = [];
        if ($clause = search_clause($_GET['search'] ?? '', search_columns('billing'), $params)) { $where[] = $clause; }
        if (!empty($_GET['status'])) { $where[] = 'i.payment_status = :status'; $params[':status'] = $_GET['status']; }
        if (!empty($_GET['date_from'])) { $where[] = 'i.due_date >= :date_from'; $params[':date_from'] = $_GET['date_from']; }
        if (!empty($_GET['date_to'])) { $where[] = 'i.due_date <= :date_to'; $params[':date_to'] = $_GET['date_to']; }
        $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
        $stmt = $pdo->prepare("SELECT i.invoice_code, u.full_name AS client_name, p.project_code, i.amount, i.due_date,
                                       i.payment_status, i.payment_date, i.payment_reference
                                FROM invoices i JOIN clients c ON c.id = i.client_id JOIN users u ON u.id = c.user_id
                                LEFT JOIN projects p ON p.id = i.project_id
                                $whereSql ORDER BY i.id DESC");
        $stmt->execute($params); $rows = $stmt->fetchAll();
        $columns = ['invoice_code'=>'Invoice','client_name'=>'Client','project_code'=>'Project','amount'=>'Amount','due_date'=>'Due Date','payment_status'=>'Status','payment_date'=>'Paid On','payment_reference'=>'Reference'];
        break;
    }
    case 'jobs': {
        $filenameBase = 'jobs';
        $where = []; $params = [];
        if ($clause = search_clause($_GET['search'] ?? '', search_columns('jobs'), $params)) { $where[] = $clause; }
        $stage = $_GET['stage'] ?? ($_GET['status'] ?? ''); // Reports sends "status"; the Jobs tab calls it "stage"
        if ($stage !== '') { $where[] = 'j.stage = :status'; $params[':status'] = $stage; }
        if (!empty($_GET['job_type'])) { $where[] = 'j.job_type = :job_type'; $params[':job_type'] = $_GET['job_type']; }
        if (!empty($_GET['priority'])) { $where[] = 'j.priority = :priority'; $params[':priority'] = $_GET['priority']; }
        if (!empty($_GET['technician_id'])) { $where[] = 'j.technician_id = :tech_id'; $params[':tech_id'] = (int)$_GET['technician_id']; }
        if (!empty($_GET['client_id'])) { $where[] = 'j.client_id = :client_id'; $params[':client_id'] = (int)$_GET['client_id']; }
        if (!empty($_GET['unassigned'])) { $where[] = 'j.technician_id IS NULL'; }
        apply_date_range('j.scheduled_date', $where, $params);
        $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
        $stmt = $pdo->prepare("SELECT j.job_code, j.job_type, cu.full_name AS client_name, tu.full_name AS technician_name,
                                       j.priority, j.stage, j.progress, j.scheduled_date, j.created_at
                                FROM jobs j JOIN clients c ON c.id = j.client_id JOIN users cu ON cu.id = c.user_id
                                LEFT JOIN technicians t ON t.id = j.technician_id LEFT JOIN users tu ON tu.id = t.user_id
                                LEFT JOIN projects p ON p.id = j.project_id
                                $whereSql ORDER BY j.created_at DESC");
        $stmt->execute($params); $rows = $stmt->fetchAll();
        $columns = ['job_code'=>'Job','job_type'=>'Type','client_name'=>'Client','technician_name'=>'Technician','priority'=>'Priority','stage'=>'Stage','progress'=>'Progress %','scheduled_date'=>'Scheduled','created_at'=>'Created'];
        break;
    }
    default:
        json_error('Unknown export type.', 422);
}

audit_log('EXPORT', $type);

$filename = $filenameBase . '_' . date('Y-m-d_His') . '.csv';
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$out = fopen('php://output', 'w');
fputcsv($out, array_values($columns));
foreach ($rows as $row) {
    $line = [];
    foreach (array_keys($columns) as $key) {
        $line[] = csv_safe_cell($row[$key] ?? '');
    }
    fputcsv($out, $line);
}
fclose($out);
exit;
