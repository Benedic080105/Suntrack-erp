<?php
/**
 * POST /api/installation/photo_delete.php
 * Body: { photo_id, csrf_token }
 *
 * The assigned technician removes one of their stage proof photos while the
 * job is open. The last photo of a stage cannot be removed once a later stage
 * has work ticked — that stage's proof is what unlocked the work after it.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
$input = json_input();
require_csrf($input);
require_fields($input, ['photo_id']);

$pdo = db();
$stmt = $pdo->prepare('SELECT id, checklist_id, job_id, stage, file_name FROM installation_photos WHERE id = :id');
$stmt->execute([':id' => (int)$input['photo_id']]);
$photo = $stmt->fetch();
if (!$photo) {
    json_error('Photo not found.', 404);
}

$job = tech_job_or_fail((int)$photo['job_id']);
if (tech_stage_is_closed($job['stage'])) {
    json_error('This job is closed — its photos can no longer be changed.', 422);
}

$checklistId = (int)$photo['checklist_id'];
if ($why = install_plan_edit_blocker($checklistId, (int)$photo['job_id'], $photo['stage'])) {
    json_error($why, 422, ['plan_locked' => true]);
}
$items =$pdo->prepare('SELECT category, status FROM installation_items WHERE checklist_id = :c');
$items->execute([':c' => $checklistId]);
$stages = tech_installation_stage_status($items->fetchAll(), installation_photo_counts($checklistId));
$names = array_column($stages, 'name');
$pos = array_search($photo['stage'], $names, true);
if ($pos !== false && $stages[$pos]['photos'] <= 1) {
    for ($i = $pos + 1; $i < count($stages); $i++) {
        if ($stages[$i]['resolved'] > 0) {
            json_error("This is the only proof photo for {$photo['stage']}. Add another one first, or untick the {$stages[$i]['name']} items.", 422);
        }
    }
}

$pdo->prepare('DELETE FROM installation_photos WHERE id = :id')->execute([':id' => $photo['id']]);
storage_delete('installation_photos', $photo['file_name']);
audit_log('PHOTO_DELETE:' . $photo['stage'], 'installation_items', $job['job_code']);

json_success([], 'Photo removed.');
