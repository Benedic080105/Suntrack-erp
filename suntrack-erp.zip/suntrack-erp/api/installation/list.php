<?php
/**
 * GET /api/installation/list.php
 * Admin (read-only) + Management. List of installation jobs (job_type =
 * INSTALLATION) with checklist progress, for the monitoring/scheduling
 * view. Use installation/get.php?job_id=... (existing endpoint) for the
 * full item-by-item checklist of one job.
 *
 * Query params:
 *   search   job_code, client name, technician name, site address
 *   status   IN_PROGRESS | COMPLETED | NOT_STARTED
 */
require_once __DIR__ . '/../../middleware/admin.php';

$pdo = db();
[$pageLimit, $pageOffset] = list_page(500);
$where  = ["j.job_type = 'INSTALLATION'"];
$params = [];

if ($clause = search_clause($_GET['search'] ?? '', search_columns('installation'), $params)) {
    $where[] = $clause;
}
apply_date_range('j.scheduled_date', $where, $params);
if (!empty($_GET['status'])) {
    if ($_GET['status'] === 'NOT_STARTED') {
        $where[] = 'ic.id IS NULL';
    } elseif ($_GET['status'] === 'COMPLETED') {
        $where[] = 'ic.progress = 100';
    } elseif ($_GET['status'] === 'IN_PROGRESS') {
        $where[] = 'ic.progress IS NOT NULL AND ic.progress < 100';
    } elseif ($_GET['status'] === 'NEEDS_REVIEW' && install_plan_available()) {
        $where[] = "EXISTS (SELECT 1 FROM installation_stage_plan sp WHERE sp.checklist_id = ic.id AND sp.status = 'SUBMITTED')";
    }
}

$whereSql = 'WHERE ' . implode(' AND ', $where);

$sql = "SELECT j.id AS job_id, j.job_code, j.stage, j.site_address, j.scheduled_date,
               p.project_code, p.site_name,
               c.client_code, cu.full_name AS client_name,
               t.technician_code, tu.full_name AS technician_name,
               ic.progress AS checklist_progress,
               (SELECT COUNT(*) FROM installation_items ii WHERE ii.checklist_id = ic.id AND ii.status = 'COMPLETED') AS items_done,
               (SELECT COUNT(*) FROM installation_items ii WHERE ii.checklist_id = ic.id) AS items_total
        FROM jobs j
        JOIN clients c ON c.id = j.client_id
        JOIN users cu ON cu.id = c.user_id
        LEFT JOIN projects p ON p.id = j.project_id
        LEFT JOIN technicians t ON t.id = j.technician_id
        LEFT JOIN users tu ON tu.id = t.user_id
        LEFT JOIN installation_checklists ic ON ic.job_id = j.id
        $whereSql
        ORDER BY j.created_at DESC, j.id DESC
        " . list_page_sql($pageLimit, $pageOffset);

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = list_page_finish($stmt->fetchAll(), $pageLimit, $pageOffset);

// Where each installation stands in its stage-by-stage schedule.
foreach ($rows as &$r) {
    $r['plan'] = install_plan_summary_for_job((int)$r['job_id']);
}
unset($r);

json_success($rows);
