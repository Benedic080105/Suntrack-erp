<?php
/**
 * POST /api/installation/stage_schedule.php — Management only.
 * Body: { job_id, stage, date (YYYY-MM-DD), csrf_token }
 *
 * Books a stage for a day, or moves it to another day. A stage can be booked
 * once the stage before it is approved; a stage already submitted or approved
 * cannot be moved.
 */
require_once __DIR__ . '/../../config/config.php';
require_management();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
$input = json_input();
require_csrf($input);
require_fields($input, ['job_id', 'stage', 'date']);

if (!install_plan_available()) {
    json_error('Stage scheduling is not set up yet. Run database/phase13_installation_stage_plan.sql.', 503);
}
$date = mr_parse_date($input['date']);
if ($date === null || $date < date('Y-m-d')) {
    json_error('Pick today or a later date.', 422);
}

$pdo = db();
$jobStmt = $pdo->prepare('SELECT * FROM jobs WHERE id = :id');
$jobStmt->execute([':id' => (int)$input['job_id']]);
$job = $jobStmt->fetch();
if (!$job) {
    json_error('Job not found.', 404);
}
if (in_array($job['stage'], ['COMPLETED', 'CANCELLED'], true)) {
    json_error('This job is closed.', 422);
}
$jobId = (int)$job['id'];
$checklist = tech_checklist_for_job($jobId);
if (!$checklist) {
    json_error('This job has no installation checklist.', 422);
}
$checklistId = (int)$checklist['id'];
$stageName = trim((string)$input['stage']);

$plan = install_plan($checklistId, $jobId);
$row = install_plan_stage($plan, $stageName);
if (!$row) {
    json_error('Unknown installation stage.', 422);
}
if (in_array($row['status'], ['SUBMITTED', 'APPROVED'], true)) {
    json_error("{$stageName} is " . strtolower($row['status_label']) . ' and cannot be rescheduled.', 422);
}
// Any stage may be booked ahead of time. The crew can still only work it once
// every stage before it is approved (install_plan_edit_blocker), and a later
// stage cannot be booked earlier than one before it.
foreach ($plan as $r) {
    if ($r['position'] < $row['position'] && $r['status'] !== 'APPROVED' && $r['scheduled_date'] && $r['scheduled_date'] > $date) {
        json_error("{$stageName} cannot be before {$r['stage']} (" . install_plan_date($r['scheduled_date']) . '). Stages are done one after the other.', 422);
    }
    if ($r['position'] > $row['position'] && in_array($r['status'], ['SCHEDULED', 'RETURNED'], true) && $r['scheduled_date'] && $r['scheduled_date'] < $date) {
        json_error("{$stageName} cannot be after {$r['stage']} (" . install_plan_date($r['scheduled_date']) . '). Move that stage first.', 422);
    }
}

$pdo->prepare("UPDATE installation_stage_plan SET status = IF(status = 'PLANNED', 'SCHEDULED', status), scheduled_date = :d
               WHERE checklist_id = :c AND stage = :s")->execute([':d' => $date, ':c' => $checklistId, ':s' => $stageName]);
// The job's date is the visit being worked on now — not a later stage booked ahead.
$current = null;
foreach ($plan as $r) {
    if ($r['status'] !== 'APPROVED') { $current = $r; break; }
}
if ($current && $current['stage'] === $stageName) {
    $pdo->prepare('UPDATE jobs SET scheduled_date = :d WHERE id = :id')->execute([':d' => $date, ':id' => $jobId]);
}

audit_log('STAGE_SCHEDULE:' . $stageName, 'installation_items', $job['job_code']);
foreach (crew_user_ids_for_job($job) as $uid) { // the whole crew
    notify($uid, 'INSTALLATION_REVIEW', "{$job['job_code']}: {$stageName} is scheduled for " . install_plan_date($date) . '.', 'jobs', $jobId);
}

json_success([], "{$stageName} scheduled for " . install_plan_date($date) . '.');
