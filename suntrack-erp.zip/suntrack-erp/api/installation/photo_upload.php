<?php
/**
 * POST /api/installation/photo_upload.php   (multipart/form-data)
 *
 * The assigned technician adds a proof photo to one stage of an installation
 * checklist. Fields: csrf_token, job_id, stage (e.g. "Mounting"), photo (file)
 *
 * Allowed only while the job is open, and only for a stage that is already
 * unlocked (every stage before it finished) — a photo cannot be added ahead of
 * the work. Up to INSTALLATION_PHOTO_MAX_PER_STAGE photos per stage.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
// An upload larger than post_max_size arrives with an empty $_POST — say so
// plainly instead of reporting a missing security token.
if (empty($_POST) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    json_error('That photo is too large (max 8 MB).', 413);
}
require_csrf($_POST);
require_fields($_POST, ['job_id', 'stage']);

$job = tech_job_or_fail((int)$_POST['job_id']);
$jobId = (int)$job['id'];
if (tech_stage_is_closed($job['stage'])) {
    json_error('This job is closed — its photos can no longer be changed.', 422);
}
$checklist = tech_checklist_for_job($jobId);
if (!$checklist) {
    json_error('This job has no installation checklist.', 422);
}
$checklistId = (int)$checklist['id'];

$pdo = db();
$items = $pdo->prepare('SELECT category, status FROM installation_items WHERE checklist_id = :c');
$items->execute([':c' => $checklistId]);
$photoCounts = installation_photo_counts($checklistId);
if ($photoCounts === null) {
    json_error('Stage photos are not set up yet. Ask the administrator to run database/phase12_installation_stage_photos.sql.', 503);
}

$stageName = trim((string)$_POST['stage']);
$stage = null;
foreach (tech_installation_stage_status($items->fetchAll(), $photoCounts) as $s) {
    if ($s['name'] === $stageName) {
        $stage = $s;
    }
}
if (!$stage) {
    json_error('Unknown installation stage.', 422);
}
if ($why = install_plan_edit_blocker($checklistId, $jobId, $stage['name'])) {
    json_error($why, 422, ['plan_locked' => true]);
}
// With a stage plan, the plan check above decides the order (stages booked for
// the same day are worked together); without one, the stage must be unlocked.
if (!$stage['unlocked'] && !install_plan_available()) {
    json_error("Finish the stages before {$stage['name']} first — photos are added as each stage is worked on.", 422);
}
if ($stage['photos'] >= INSTALLATION_PHOTO_MAX_PER_STAGE) {
    json_error("{$stage['name']} already has the maximum of " . INSTALLATION_PHOTO_MAX_PER_STAGE . ' photos.', 422);
}

[$name, $mime, $size, $w, $h] = store_uploaded_image($_FILES['photo'] ?? [], 'installation_photos');

try {
    $pdo->prepare(
        'INSERT INTO installation_photos (checklist_id, job_id, stage, uploaded_by, file_name, mime, size_bytes, width, height, created_at)
         VALUES (:c, :j, :st, :u, :f, :m, :s, :w, :h, :t)'
    )->execute([
        ':c' => $checklistId, ':j' => $jobId, ':st' => $stage['name'], ':u' => current_user_id(), ':f' => $name,
        ':m' => $mime, ':s' => $size, ':w' => $w, ':h' => $h, ':t' => date('Y-m-d H:i:s'),
    ]);
} catch (PDOException $e) {
    storage_delete('installation_photos', $name); // never leave an orphan file behind
    json_error('The photo could not be saved. Please try again.', 500);
}

audit_log('PHOTO_UPLOAD:' . $stage['name'], 'installation_items', $job['job_code']);

json_success(['stage' => $stage['name'], 'photos' => $stage['photos'] + 1], "Proof photo added to {$stage['name']}.");
