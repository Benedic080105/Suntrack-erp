<?php
/**
 * GET /api/installation/get.php?job_id=N
 *
 * The installation checklist for a job, grouped by the existing seeded
 * categories. The structure in installation_checklists / installation_items is
 * used as-is — nothing is reduced or replaced.
 *
 * Technicians see only their own jobs; clients see only their own (and may omit
 * job_id, which auto-resolves to their latest installation); admin/manager/staff
 * may view any.
 */
require_once __DIR__ . '/../../config/config.php';
field_mode_enter(true); // a subcontractor uses this through the field portal
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed.', 405);
}

$role  = current_role();
$pdo   = db();
$jobId = (int)($_GET['job_id'] ?? 0);

if (!in_array($role, ['technician', 'client', 'admin', 'manager', 'staff'], true)) {
    json_error('Not authorized.', 403);
}

// Clients may omit job_id — auto-resolve to their most recent installation job.
if (!$jobId && $role === 'client') {
    $auto = $pdo->prepare(
        "SELECT id FROM jobs WHERE client_id = :c AND job_type = 'INSTALLATION' ORDER BY id DESC LIMIT 1"
    );
    $auto->execute([':c' => current_profile_id()]);
    $jobId = (int)$auto->fetchColumn();
}
if (!$jobId) {
    json_error('No installation job found.', 404);
}

// Ownership. Technicians go through the shared guard so the rule lives in one place.
if ($role === 'technician') {
    $job = tech_job_or_fail($jobId);
} else {
    $jobStmt = $pdo->prepare(
        'SELECT j.*, c.client_code, cu.full_name AS client_name
         FROM jobs j JOIN clients c ON c.id = j.client_id JOIN users cu ON cu.id = c.user_id
         WHERE j.id = :id'
    );
    $jobStmt->execute([':id' => $jobId]);
    $job = $jobStmt->fetch();
    if (!$job) {
        json_error('Job not found.', 404);
    }
    if ($role === 'client' && (int)$job['client_id'] !== (int)current_profile_id()) {
        json_error('This job does not belong to you.', 403);
    }
}

$checklist = tech_checklist_for_job($jobId);

// Installation jobs created before checklists were generated automatically get
// theirs the first time the assigned technician opens the job (the same way a
// maintenance job gets its inspection items). Viewers never create one.
if (!$checklist && $role === 'technician' && $job['job_type'] === 'INSTALLATION' && !tech_stage_is_closed($job['stage'])) {
    $checklist = tech_ensure_installation_checklist($jobId);
}

$jobSummary = [
    'id'             => (int)$job['id'],
    'job_code'       => $job['job_code'],
    'job_type'       => $job['job_type'],
    'stage'          => $job['stage'],
    'progress'       => (int)$job['progress'],
    'is_closed'      => tech_stage_is_closed($job['stage']),
    'client_name'    => $job['client_name'] ?? null,
    'client_code'    => $job['client_code'] ?? null,
    'site_address'   => $job['site_address'],
    'scheduled_date' => $job['scheduled_date'],
    // A helper on the crew ticks and photographs; the lead submits the stage.
    'is_lead'        => $job['is_lead'] ?? true,
    'crew'           => ($job['project_id'] && crew_available())
                        ? array_map(fn($m) => ['name' => $m['name'], 'code' => $m['code'], 'is_lead' => $m['is_lead']], crew_list((int)$job['project_id']))
                        : [],
];

if (!$checklist) {
    json_success([
        'job'       => $jobSummary,
        'checklist' => null,
        'counts'    => null,
        'items'     => [],
        'editable'  => false,
    ], 'No installation checklist exists for this job.');
}

$itemsStmt = $pdo->prepare(
    'SELECT ii.id, ii.item_key, ii.category, ii.description, ii.status, ii.remarks,
            ii.completed_date, u.full_name AS completed_by_name
     FROM installation_items ii
     LEFT JOIN users u ON u.id = ii.completed_by
     WHERE ii.checklist_id = :c ORDER BY ii.id ASC'
);
$itemsStmt->execute([':c' => $checklist['id']]);
$items = $itemsStmt->fetchAll();

json_success([
    'job'       => $jobSummary,
    'checklist' => [
        'id'         => (int)$checklist['id'],
        'progress'   => (int)$checklist['progress'],
        'updated_at' => $checklist['updated_at'],
    ],
    'counts'   => tech_checklist_counts((int)$checklist['id']),
    'items'    => $items,
    // In working order, with which ones are open to the technician yet. A stage
    // is finished only with all items ticked and at least one proof photo.
    'stages'   => tech_installation_stage_status($items, installation_photo_counts((int)$checklist['id'])),
    'photos'   => installation_photos_list((int)$checklist['id']),
    // Each stage is its own scheduled visit, reviewed by Management (installation_plan_lib.php).
    'plan'     => $plan = install_plan((int)$checklist['id'], (int)$job['id']),
    'plan_summary' => install_plan_summary($plan),
    'today'    => date('Y-m-d'),
    'photo_max_per_stage' => INSTALLATION_PHOTO_MAX_PER_STAGE,
    // Only the assigned technician, and only while the job is open, may edit.
    'editable' => $role === 'technician' && !tech_stage_is_closed($job['stage']),
]);
