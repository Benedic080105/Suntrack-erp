<?php
/**
 * POST /api/installation/stage_submit.php
 * Body: { job_id, stage, note?, csrf_token }
 *
 * The technician sends today's stage to Management for review. Requires every
 * item of the stage ticked (or N/A) and at least one proof photo. The stage is
 * then locked (SUBMITTED) and the job paused until Management approves it and
 * schedules the next visit.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
$input = json_input();
require_csrf($input);
require_fields($input, ['job_id', 'stage']);

if (!install_plan_available()) {
    json_error('Stage scheduling is not set up yet. Ask the administrator to run database/phase13_installation_stage_plan.sql.', 503);
}

$job = tech_job_or_fail((int)$input['job_id']);
tech_require_lead($job); // the lead sends the crew's stage for review
$jobId = (int)$job['id'];
if (tech_stage_is_closed($job['stage'])) {
    json_error('This job is closed.', 422);
}
$checklist = tech_checklist_for_job($jobId);
if (!$checklist) {
    json_error('This job has no installation checklist.', 422);
}
$checklistId = (int)$checklist['id'];
$stageName = trim((string)$input['stage']);
$note = trim((string)($input['note'] ?? ''));
if (str_len($note) > 500) {
    json_error('The note is limited to 500 characters.', 422);
}

$pdo = db();
$pdo->beginTransaction();
try {
    $pdo->prepare('SELECT id FROM installation_checklists WHERE id = :c FOR UPDATE')->execute([':c' => $checklistId]);

    if ($why = install_plan_edit_blocker($checklistId, $jobId, $stageName)) {
        $pdo->rollBack();
        json_error($why, 422);
    }

    $items = $pdo->prepare('SELECT category, status FROM installation_items WHERE checklist_id = :c');
    $items->execute([':c' => $checklistId]);
    $stage = null;
    foreach (tech_installation_stage_status($items->fetchAll(), installation_photo_counts($checklistId)) as $s) {
        if ($s['name'] === $stageName) {
            $stage = $s;
        }
    }
    if (!$stage) {
        $pdo->rollBack();
        json_error('Unknown installation stage.', 422);
    }
    $left = $stage['total'] - $stage['resolved'];
    if ($left > 0) {
        $pdo->rollBack();
        json_error("Tick the remaining {$left} item" . ($left === 1 ? '' : 's') . " of {$stageName} (or mark them N/A) before submitting.", 422);
    }
    if ($stage['photos'] < 1) {
        $pdo->rollBack();
        json_error("Add at least one proof photo for {$stageName} before submitting.", 422);
    }

    $pdo->prepare(
        "UPDATE installation_stage_plan
         SET status = 'SUBMITTED', submitted_at = NOW(), submitted_by = :u, submit_note = :n, review_note = NULL, reviewed_at = NULL, reviewed_by = NULL
         WHERE checklist_id = :c AND stage = :s"
    )->execute([':u' => current_user_id(), ':n' => $note !== '' ? $note : null, ':c' => $checklistId, ':s' => $stageName]);

    // The visit is over: the job waits (PAUSED) until the next stage is approved and scheduled.
    if ($job['stage'] === 'IN_PROGRESS') {
        $pdo->prepare("UPDATE jobs SET stage = 'PAUSED' WHERE id = :id")->execute([':id' => $jobId]);
        $pdo->prepare(
            "INSERT INTO job_status_history (job_id, from_stage, to_stage, changed_by, note) VALUES (:j, 'IN_PROGRESS', 'PAUSED', :u, :n)"
        )->execute([':j' => $jobId, ':u' => current_user_id(), ':n' => "{$stageName} submitted for review"]);
    }
    $techId = (int)$job['technician_id'];
    $stillWorking = array_filter(tech_active_field_jobs($techId, $jobId), fn($j) => $j['stage'] === 'IN_PROGRESS');
    if (!$stillWorking && tech_availability($techId) === 'BUSY') {
        tech_set_availability($techId, 'AVAILABLE');
    }
    $pdo->commit();
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('SunTrack stage submit: ' . $e->getMessage());
    json_error('The stage could not be submitted. Please try again.', 500);
}

audit_log('STAGE_SUBMIT:' . $stageName, 'installation_items', $job['job_code']);
foreach (install_plan_manager_ids() as $uid) {
    notify($uid, 'INSTALLATION_REVIEW', "{$job['job_code']}: {$stageName} is ready for your review"
        . ($note !== '' ? " — \"" . str_cut($note, 0, 120) . '"' : '') . '.', 'jobs', $jobId);
}

json_success(['stage' => $stageName, 'status' => 'SUBMITTED'], "{$stageName} submitted. Management will review it and schedule the next visit.");
