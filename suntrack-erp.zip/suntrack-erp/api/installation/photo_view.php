<?php
/**
 * GET /api/installation/photo_view.php?id=N — streams one installation stage
 * proof photo to someone allowed to see its job (the technician on it, its
 * client, Management, Admin).
 */
require_once __DIR__ . '/../../config/config.php';
field_mode_enter(true); // a subcontractor uses this through the field portal
require_login(true);

$stmt = db()->prepare('SELECT job_id, file_name, mime FROM installation_photos WHERE id = :id');
$stmt->execute([':id' => (int)($_GET['id'] ?? 0)]);
$photo = $stmt->fetch();
if (!$photo) {
    json_error('Photo not found.', 404);
}
job_access_or_fail((int)$photo['job_id']);
storage_send('installation_photos', $photo['file_name'], $photo['mime']);
