<?php
/**
 * POST /api/installation/update_item.php
 *
 * Update one checklist item. Every update:
 *   1. validates the technician session and CSRF token
 *   2. validates that the item's checklist belongs to a job assigned to them
 *   3. validates the status against the table's ENUM
 *   4. enforces the stage order (Site Preparation -> Mounting -> Electrical ->
 *      Testing -> Finalization; see tech_installation_step_blocker())
 *   5. updates the item
 *   5. recalculates checklist progress
 *   6. cascades to jobs.progress and the parent project's progress
 *   7. writes an audit row
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['item_id', 'status']);

$itemId  = (int)$input['item_id'];
$status  = strtoupper(trim((string)$input['status']));
$remarks = trim((string)($input['remarks'] ?? ''));

if ($itemId <= 0) {
    json_error('Invalid checklist item.', 422);
}
if (!in_array($status, ['PENDING', 'COMPLETED', 'NOT_APPLICABLE'], true)) {
    json_error('Invalid status.', 422);
}
if (str_len($remarks) > 255) {
    json_error('Remarks are limited to 255 characters.', 422);
}

$pdo = db();

// Resolve the item to its job, then run the job through the shared ownership guard.
$itemStmt = $pdo->prepare(
    'SELECT ii.id, ii.checklist_id, ii.description, ii.category, ic.job_id
     FROM installation_items ii
     JOIN installation_checklists ic ON ic.id = ii.checklist_id
     WHERE ii.id = :id'
);
$itemStmt->execute([':id' => $itemId]);
$item = $itemStmt->fetch();

if (!$item) {
    json_error('Checklist item not found.', 404);
}

$job = tech_job_or_fail((int)$item['job_id']);

if (tech_stage_is_closed($job['stage'])) {
    json_error('This job is closed — its checklist can no longer be changed.', 422);
}
// Only the stage scheduled for today (and not yet submitted) can be changed.
if ($why = install_plan_edit_blocker((int)$item['checklist_id'], (int)$item['job_id'], $item['category'])) {
    json_error($why, 422, ['plan_locked' => true]);
}

$pdo->beginTransaction();
try {
    // Lock the checklist so two quick taps cannot both pass the order check.
    $pdo->prepare('SELECT id FROM installation_checklists WHERE id = :c FOR UPDATE')->execute([':c' => $item['checklist_id']]);
    $blocker = tech_installation_step_blocker((int)$item['checklist_id'], $itemId, $status);
    if ($blocker !== null) {
        $pdo->rollBack();
        json_error($blocker, 422, ['out_of_order' => true]);
    }

    $pdo->prepare(
        'UPDATE installation_items
         SET status = :s,
             remarks = :r,
             completed_by = IF(:s2 = "COMPLETED", :by, completed_by),
             completed_date = IF(:s3 = "COMPLETED", NOW(), NULL)
         WHERE id = :id'
    )->execute([
        ':s'  => $status,
        ':r'  => $remarks !== '' ? $remarks : null,
        ':s2' => $status,
        ':by' => current_user_id(),
        ':s3' => $status,
        ':id' => $itemId,
    ]);

    $progress = tech_recalc_installation((int)$item['checklist_id'], (int)$item['job_id']);

    $pdo->commit();
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    json_error('Failed to update checklist item.', 500);
}

audit_log('UPDATE_CHECKLIST_ITEM:' . $status, 'installation_items', $job['job_code'] . '#' . $itemId);

$counts = tech_checklist_counts((int)$item['checklist_id']);

json_success([
    'item_id'    => $itemId,
    'status'     => $status,
    'progress'   => $progress,
    'counts'     => $counts,
    'can_complete_job' => $counts['pending'] === 0,
], 'Checklist item updated.');
