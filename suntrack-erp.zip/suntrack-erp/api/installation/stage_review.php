<?php
/**
 * POST /api/installation/stage_review.php — Management only.
 * Body: {
 *   job_id, stage, decision: APPROVE | RETURN, note?,
 *   next_date?                         APPROVE: schedule the next stage for this day
 *   mr_panels?, mr_inverters?, mr_batteries?, mr_needed_by?
 *                                      APPROVE: send a material request to the warehouse
 *   csrf_token
 * }
 *
 * RETURN needs a note — it is what the technician reads to fix the stage.
 */
require_once __DIR__ . '/../../config/config.php';
require_management();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
$input = json_input();
require_csrf($input);
require_fields($input, ['job_id', 'stage', 'decision']);

if (!install_plan_available()) {
    json_error('Stage scheduling is not set up yet. Run database/phase13_installation_stage_plan.sql.', 503);
}

$decision = strtoupper(trim((string)$input['decision']));
if (!in_array($decision, ['APPROVE', 'RETURN'], true)) {
    json_error('Decision must be APPROVE or RETURN.', 422);
}
$note = trim((string)($input['note'] ?? ''));
if (str_len($note) > 500) {
    json_error('The note is limited to 500 characters.', 422);
}
if ($decision === 'RETURN' && $note === '') {
    json_error('Write what the technician needs to fix.', 422);
}
$nextDate = mr_parse_date($input['next_date'] ?? null);
if ($nextDate !== null && $nextDate < date('Y-m-d')) {
    json_error('The next visit cannot be scheduled in the past.', 422);
}
$materialLines = $decision === 'APPROVE' ? mr_parse_quantities($input, 'mr_') : [];
$neededBy = mr_parse_date($input['mr_needed_by'] ?? null) ?? $nextDate;

$pdo = db();
$jobStmt = $pdo->prepare('SELECT * FROM jobs WHERE id = :id');
$jobStmt->execute([':id' => (int)$input['job_id']]);
$job = $jobStmt->fetch();
if (!$job) {
    json_error('Job not found.', 404);
}
$jobId = (int)$job['id'];
$checklist = tech_checklist_for_job($jobId);
if (!$checklist) {
    json_error('This job has no installation checklist.', 422);
}
$checklistId = (int)$checklist['id'];
$stageName = trim((string)$input['stage']);

$mrCode = null;
$mrId = null;
$next = null;
$pdo->beginTransaction();
try {
    $pdo->prepare('SELECT id FROM installation_checklists WHERE id = :c FOR UPDATE')->execute([':c' => $checklistId]);
    $plan = install_plan($checklistId, $jobId);
    $row = install_plan_stage($plan, $stageName);
    if (!$row) {
        $pdo->rollBack();
        json_error('Unknown installation stage.', 422);
    }
    if ($row['status'] !== 'SUBMITTED') {
        $pdo->rollBack();
        json_error("{$stageName} is not waiting for review (it is " . strtolower($row['status_label']) . ').', 422);
    }
    foreach ($plan as $r) {
        if ($r['position'] === $row['position'] + 1) {
            $next = $r;
        }
    }

    $pdo->prepare(
        'UPDATE installation_stage_plan SET status = :s, reviewed_at = NOW(), reviewed_by = :u, review_note = :n
         WHERE checklist_id = :c AND stage = :st'
    )->execute([':s' => $decision === 'APPROVE' ? 'APPROVED' : 'RETURNED', ':u' => current_user_id(),
                ':n' => $note !== '' ? $note : null, ':c' => $checklistId, ':st' => $stageName]);

    if ($decision === 'APPROVE' && $next && $nextDate) {
        $pdo->prepare("UPDATE installation_stage_plan SET status = IF(status = 'RETURNED', status, 'SCHEDULED'), scheduled_date = :d WHERE checklist_id = :c AND stage = :st")
            ->execute([':d' => $nextDate, ':c' => $checklistId, ':st' => $next['stage']]);
        $pdo->prepare('UPDATE jobs SET scheduled_date = :d WHERE id = :id')->execute([':d' => $nextDate, ':id' => $jobId]);
    } elseif ($decision === 'APPROVE' && $next && $next['scheduled_date']) {
        // The next stage was booked ahead: keep that date and make it the job's date.
        $nextDate = $next['scheduled_date'];
        $pdo->prepare('UPDATE jobs SET scheduled_date = :d WHERE id = :id')->execute([':d' => $nextDate, ':id' => $jobId]);
    }
    if ($decision === 'RETURN') {
        // The fix is done today unless the stage was booked later.
        $pdo->prepare('UPDATE installation_stage_plan SET scheduled_date = LEAST(COALESCE(scheduled_date, CURDATE()), CURDATE())
                       WHERE checklist_id = :c AND stage = :st')->execute([':c' => $checklistId, ':st' => $stageName]);
    }

    if ($materialLines) {
        mr_require_schema();
        $open = $pdo->prepare(
            "SELECT request_code FROM material_requests
             WHERE status IN ('PENDING','PREPARING','READY')
               AND (job_id = :j OR (:p IS NOT NULL AND project_id = :p2)) LIMIT 1"
        );
        $open->execute([':j' => $jobId, ':p' => $job['project_id'], ':p2' => $job['project_id']]);
        if ($existing = $open->fetchColumn()) {
            $pdo->rollBack();
            json_error("This installation already has an open material request ({$existing}). Leave the quantities blank, or update that request.", 422);
        }
        [$mrId, $mrCode] = mr_create($pdo, (int)$job['client_id'], $materialLines, $job['project_id'] ? (int)$job['project_id'] : null,
            $jobId, $neededBy, "For {$job['job_code']} — requested after {$stageName}");
    }
    $pdo->commit();
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('SunTrack stage review: ' . $e->getMessage());
    json_error('The review could not be saved. Please try again.', 500);
}

audit_log(($decision === 'APPROVE' ? 'STAGE_APPROVE:' : 'STAGE_RETURN:') . $stageName, 'installation_items', $job['job_code']);

// The whole crew hears about it, not only the lead.
$crewUsers = crew_user_ids_for_job($job);
if ($crewUsers) {
    if ($decision === 'RETURN') {
        $msg = "{$job['job_code']}: {$stageName} was returned — {$note}";
    } elseif (!$next) {
        $msg = "{$job['job_code']}: every stage is approved. You can now complete the job.";
    } elseif ($nextDate) {
        $msg = "{$job['job_code']}: {$stageName} approved. Next visit: {$next['stage']} on " . install_plan_date($nextDate) . '.';
    } else {
        $msg = "{$job['job_code']}: {$stageName} approved. The next visit will be scheduled soon.";
    }
    foreach ($crewUsers as $uid) {
        notify($uid, 'INSTALLATION_REVIEW', str_cut($msg, 0, 250), 'jobs', $jobId);
    }
}
if ($mrId) {
    audit_log('CREATE', 'material_requests', $mrCode);
    mr_notify_warehouse("New client order {$mrCode} for {$job['job_code']}: " . mr_lines_summary($materialLines)
        . ($neededBy ? ', needed by ' . install_plan_date($neededBy) : '') . '.', $mrId);
}

$message = $decision === 'RETURN'
    ? "{$stageName} returned to the technician."
    : "{$stageName} approved." . ($next && $nextDate ? " {$next['stage']} scheduled for " . install_plan_date($nextDate) . '.' : '')
      . ($next && !$nextDate ? " Schedule {$next['stage']} when you are ready." : '')
      . ($mrCode ? " Material request {$mrCode} sent to the warehouse." : '');
json_success(['material_request_code' => $mrCode], $message);
