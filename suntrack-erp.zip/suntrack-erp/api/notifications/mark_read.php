<?php
/**
 * POST /api/notifications/mark_read.php
 * Any signed-in role. Marks the current user's own notification(s) as read.
 *
 * Body:
 *   id   int   mark one notification read
 *   all  bool  mark every unread notification for this user read (ignored if id is set)
 */
require_once __DIR__ . '/../../config/config.php';
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);

$userId = current_user_id();
$pdo    = db();

if (!empty($input['id'])) {
    $id = (int)$input['id'];
    // Scoped to user_id so nobody can mark someone else's notification read
    // by guessing an id.
    $stmt = $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE id = :id AND user_id = :uid');
    $stmt->execute([':id' => $id, ':uid' => $userId]);
    if ($stmt->rowCount() === 0) {
        json_error('Notification not found.', 404);
    }
    json_success([], 'Notification marked as read.');
}

if (!empty($input['all'])) {
    $pdo->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = :uid AND is_read = 0')
        ->execute([':uid' => $userId]);
    json_success([], 'All notifications marked as read.');
}

json_error('Provide either "id" or "all".', 422);
