<?php
/**
 * GET /api/notifications/list.php
 * Any signed-in role. Returns the current user's own notifications only —
 * user_id always comes from the session, never from the request.
 *
 * Query params:
 *   unread_only=1   only rows where is_read = 0
 *   limit=N         default 50, max 200
 */
require_once __DIR__ . '/../../config/config.php';
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed.', 405);
}

$userId     = current_user_id();
$unreadOnly = !empty($_GET['unread_only']);
$limit      = max(1, min(200, (int)($_GET['limit'] ?? 50)));

$pdo = db();

$sql = 'SELECT id, type, message, related_table, related_id, is_read, created_at
        FROM notifications WHERE user_id = :uid';
if ($unreadOnly) {
    $sql .= ' AND is_read = 0';
}
$sql .= ' ORDER BY created_at DESC LIMIT ' . $limit;

$stmt = $pdo->prepare($sql);
$stmt->execute([':uid' => $userId]);
$rows = $stmt->fetchAll();

$countStmt = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = :uid AND is_read = 0');
$countStmt->execute([':uid' => $userId]);
$unreadCount = (int)$countStmt->fetchColumn();

json_success([
    'rows'          => $rows,
    'unread_count'  => $unreadCount,
]);
