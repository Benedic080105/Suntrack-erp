<?php
/**
 * Staff — list + stats for the Admin/Management view.
 * Create/update are in create.php and update.php.
 */
require_once __DIR__ . '/../../middleware/admin.php';

$pdo = db();
[$pageLimit, $pageOffset] = list_page(500);
$where = [];
$params = [];

if ($clause = search_clause($_GET['search'] ?? '', search_columns('staff'), $params)) {
    $where[] = $clause;
}
if (!empty($_GET['status'])) {
    $where[] = 's.status = :status';
    $params[':status'] = $_GET['status'];
}
if (!empty($_GET['department'])) {
    $where[] = 's.department = :department';
    $params[':department'] = $_GET['department'];
}
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$sql = "SELECT s.id, s.staff_code, u.full_name, u.email, u.phone, u.status AS account_status,
               s.department, s.position, s.status, s.created_at
        FROM staff s
        JOIN users u ON u.id = s.user_id
        $whereSql
        ORDER BY s.id DESC
        " . list_page_sql($pageLimit, $pageOffset);
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = list_page_finish($stmt->fetchAll(), $pageLimit, $pageOffset);

// KPI summary (unfiltered — company-wide totals)
$total    = (int)$pdo->query("SELECT COUNT(*) FROM staff")->fetchColumn();
$active   = (int)$pdo->query("SELECT COUNT(*) FROM staff WHERE status='ACTIVE'")->fetchColumn();
$onLeave  = (int)$pdo->query("SELECT COUNT(*) FROM staff WHERE status='ON_LEAVE'")->fetchColumn();
$inactive = (int)$pdo->query("SELECT COUNT(*) FROM staff WHERE status='INACTIVE'")->fetchColumn();

// Bar chart: headcount by department
$byDept = $pdo->query(
    "SELECT COALESCE(NULLIF(department,''),'Unassigned') AS label, COUNT(*) AS total
     FROM staff GROUP BY label ORDER BY total DESC"
)->fetchAll();

json_success([
    'rows' => $rows,
    'stats' => [
        'total' => $total,
        'active' => $active,
        'on_leave' => $onLeave,
        'inactive' => $inactive,
    ],
    'chart' => [
        'labels' => array_map(fn($r) => $r['label'], $byDept),
        'values' => array_map(fn($r) => (int)$r['total'], $byDept),
    ],
]);
