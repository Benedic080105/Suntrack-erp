<?php
require_once __DIR__ . '/../../config/config.php';
require_management(); // Admin role is view/export only; only Management (manager/staff) may mutate.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['id']);

$id = (int)$input['id'];
$pdo = db();

$stfStmt = $pdo->prepare('SELECT s.*, u.id AS user_id FROM staff s JOIN users u ON u.id = s.user_id WHERE s.id = :id');
$stfStmt->execute([':id' => $id]);
$stf = $stfStmt->fetch();
if (!$stf) {
    json_error('Staff record not found.', 404);
}

$userFields = [];
$userParams = [':uid' => $stf['user_id']];
foreach (['full_name', 'phone'] as $f) {
    if (isset($input[$f])) {
        $userFields[] = "$f = :$f";
        $userParams[":$f"] = trim($input[$f]);
    }
}
if ($userFields) {
    $pdo->prepare('UPDATE users SET ' . implode(', ', $userFields) . ' WHERE id = :uid')->execute($userParams);
}

$staffFields = [];
$staffParams = [':id' => $id];
if (isset($input['department'])) {
    $staffFields[] = 'department = :dept';
    $staffParams[':dept'] = trim($input['department']) ?: null;
}
if (isset($input['position'])) {
    $staffFields[] = 'position = :pos';
    $staffParams[':pos'] = trim($input['position']) ?: null;
}
if (!empty($input['status'])) {
    if (!in_array($input['status'], ['ACTIVE', 'ON_LEAVE', 'INACTIVE'], true)) {
        json_error('Invalid status value.', 422);
    }
    $staffFields[] = 'status = :status';
    $staffParams[':status'] = $input['status'];

    // An INACTIVE staff member (e.g. offboarded) loses portal access; reactivating restores it.
    // ON_LEAVE intentionally leaves login access untouched.
    if ($input['status'] === 'INACTIVE') {
        $pdo->prepare('UPDATE users SET status = "INACTIVE" WHERE id = :uid')->execute([':uid' => $stf['user_id']]);
    } elseif ($input['status'] === 'ACTIVE') {
        $pdo->prepare('UPDATE users SET status = "ACTIVE" WHERE id = :uid')->execute([':uid' => $stf['user_id']]);
    }
}
if ($staffFields) {
    $pdo->prepare('UPDATE staff SET ' . implode(', ', $staffFields) . ' WHERE id = :id')->execute($staffParams);
}

if (!empty($input['new_password'])) {
    if (str_len($input['new_password']) < PASSWORD_MIN_LENGTH) {
        json_error('New password must be at least ' . PASSWORD_MIN_LENGTH . ' characters.', 422);
    }
    $pdo->prepare('UPDATE users SET password_hash = :h WHERE id = :uid')
        ->execute([':h' => password_hash($input['new_password'], PASSWORD_DEFAULT), ':uid' => $stf['user_id']]);
    audit_log('RESET_PASSWORD', 'staff', $stf['staff_code']);
}

audit_log('UPDATE', 'staff', $stf['staff_code']);

json_success([], 'Staff record updated.');
