<?php
require_once __DIR__ . '/../../middleware/warehouse.php';

$pdo = db();

$activeSkus       = (int)$pdo->query("SELECT COUNT(*) FROM inventory WHERE status != 'DISCONTINUED'")->fetchColumn();
$totalQuantity    = (int)$pdo->query("SELECT COALESCE(SUM(quantity),0) FROM inventory")->fetchColumn();
$lowStock         = (int)$pdo->query("SELECT COUNT(*) FROM inventory WHERE status = 'LOW_STOCK'")->fetchColumn();
$outOfStock       = (int)$pdo->query("SELECT COUNT(*) FROM inventory WHERE status = 'OUT_OF_STOCK'")->fetchColumn();

$byCategory = $pdo->query(
    "SELECT ic.category_name, COALESCE(SUM(i.quantity),0) AS total_qty, COUNT(i.id) AS sku_count
     FROM inventory_categories ic
     LEFT JOIN inventory i ON i.category_id = ic.id
     GROUP BY ic.id, ic.category_name"
)->fetchAll();

$lowStockList = $pdo->query(
    "SELECT sku, item_name, quantity, reorder_level, status FROM inventory
     WHERE status IN ('LOW_STOCK','OUT_OF_STOCK') ORDER BY quantity ASC"
)->fetchAll();

// --- Today's activity -------------------------------------------------------
// One grouped query rather than four counts: the warehouse dashboard is polled
// by the real-time heartbeat, so it should stay cheap.
$todayRows = $pdo->query(
    "SELECT movement_type, COUNT(*) AS moves, COALESCE(SUM(quantity),0) AS units
     FROM stock_movements
     WHERE created_at >= CURDATE() AND created_at < CURDATE() + INTERVAL 1 DAY
     GROUP BY movement_type"
)->fetchAll();

$today = ['received' => 0, 'issued' => 0, 'returned' => 0, 'total_movements' => 0];
foreach ($todayRows as $r) {
    $units = (int)$r['units'];
    $today['total_movements'] += (int)$r['moves'];
    if ($r['movement_type'] === 'RECEIVE')      $today['received'] += $units;
    elseif ($r['movement_type'] === 'ISSUE')    $today['issued']   += $units;
    elseif ($r['movement_type'] === 'RETURN')   $today['returned'] += $units;
}

// --- Warehouse identity -----------------------------------------------------
$warehouse = $pdo->query('SELECT warehouse_name, location FROM warehouses ORDER BY id LIMIT 1')->fetch()
    ?: ['warehouse_name' => 'Main Warehouse', 'location' => null];

// --- Recent movements, with the context the Warehouse tab needs -------------
// The dashboard's own list stays lean; this one carries job, client and user
// so the Warehouse overview does not need a second endpoint.
$recentMovements = $pdo->query(
    "SELECT sm.movement_code, sm.movement_type, sm.quantity, sm.created_at, sm.reference,
            i.item_name, i.sku,
            j.job_code,
            cu.full_name AS client_name,
            u.full_name  AS recorded_by_name
     FROM stock_movements sm
     JOIN inventory i       ON i.id = sm.inventory_id
     LEFT JOIN jobs j       ON j.id = sm.job_id
     LEFT JOIN clients c    ON c.id = j.client_id
     LEFT JOIN users cu     ON cu.id = c.user_id
     LEFT JOIN users u      ON u.id = sm.recorded_by
     ORDER BY sm.created_at DESC, sm.id DESC
     LIMIT 15"
)->fetchAll();

$recentActivity = $pdo->query(
    "SELECT sm.movement_code, sm.movement_type, sm.quantity, sm.created_at, i.item_name
     FROM stock_movements sm JOIN inventory i ON i.id = sm.inventory_id
     ORDER BY sm.created_at DESC LIMIT 10"
)->fetchAll();

json_success([
    'kpis' => [
        'active_skus'    => $activeSkus,
        'total_quantity' => $totalQuantity,
        'low_stock'      => $lowStock,
        'out_of_stock'   => $outOfStock,
    ],
    'by_category'     => $byCategory,
    'low_stock_list'  => $lowStockList,
    'recent_activity' => $recentActivity,
    'today'           => $today,
    'warehouse'       => $warehouse,
    'recent_movements'=> $recentMovements,
]);
