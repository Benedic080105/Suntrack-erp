<?php
require_once __DIR__ . '/../../middleware/technician.php';

$techId = current_profile_id();
if (!$techId) {
    json_error('Technician profile not found.', 404);
}

$pdo = db();

$availStmt = $pdo->prepare("SELECT status FROM technician_availability WHERE technician_id = :t");
$availStmt->execute([':t' => $techId]);
$availability = $availStmt->fetchColumn() ?: 'AVAILABLE';

$assignmentsStmt = $pdo->prepare(
    "SELECT j.id, j.job_code, j.job_type, j.stage, j.progress, j.priority, j.scheduled_date, j.site_address,
            j.site_lat, j.site_lng, j.geofence_radius_m,
            c.client_code, u.full_name AS client_name,
            (SELECT a.id FROM attendance a WHERE a.job_id = j.id AND a.technician_id = :t2 AND a.time_out IS NULL LIMIT 1) AS open_attendance_id
     FROM jobs j
     JOIN clients c ON c.id = j.client_id
     JOIN users u ON u.id = c.user_id
     WHERE " . crew_job_condition('j', ':t') . " AND j.stage NOT IN ('COMPLETED','CANCELLED')
     ORDER BY j.scheduled_date ASC"
);
$assignmentsStmt->execute([':t' => $techId, ':t2' => $techId] + (crew_available() ? [':tc' => $techId] : []));

$completedTodayStmt = $pdo->prepare(
    "SELECT COUNT(*) FROM jobs WHERE technician_id = :t AND stage = 'COMPLETED' AND DATE(updated_at) = CURDATE()"
);
$completedTodayStmt->execute([':t' => $techId]);

$historyStmt = $pdo->prepare(
    "SELECT j.id, j.job_code, j.job_type, j.stage, j.updated_at,
            (SELECT id FROM work_reports wr WHERE wr.job_id = j.id) AS existing_report_id
     FROM jobs j WHERE j.technician_id = :t AND j.stage = 'COMPLETED'
     ORDER BY j.updated_at DESC LIMIT 8"
);
$historyStmt->execute([':t' => $techId]);

json_success([
    'availability'      => $availability,
    'assignments'       => $assignmentsStmt->fetchAll(),
    'completed_today'   => (int)$completedTodayStmt->fetchColumn(),
    'recent_completed'  => $historyStmt->fetchAll(),
]);
