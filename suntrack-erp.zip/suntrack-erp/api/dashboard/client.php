<?php
require_once __DIR__ . '/../../middleware/client.php';

$clientId = current_profile_id();
if (!$clientId) {
    json_error('Client profile not found.', 404);
}

maintenance_refresh_statuses(); // keep DUE/OVERDUE current as days pass
$pdo = db();

// The system the dashboard describes: an installed one (newest first) before
// one that is still planned or being installed.
$sysStmt = $pdo->prepare(
    "SELECT * FROM solar_systems WHERE client_id = :c
     ORDER BY FIELD(status, 'ACTIVE', 'FAULT', 'INSTALLING', 'PLANNED', 'DECOMMISSIONED'), id DESC LIMIT 1"
);
$sysStmt->execute([':c' => $clientId]);
$system = $sysStmt->fetch() ?: null;
$summary = $system ? system_client_summary($system) : null;

$arStmt = $pdo->prepare("SELECT COUNT(*) FROM service_requests WHERE client_id = :c AND status NOT IN ('COMPLETED','CANCELLED','REJECTED')");
$arStmt->execute([':c' => $clientId]);
$activeRequests = (int)$arStmt->fetchColumn();

$project = null;
if ($system) {
    $projStmt = $pdo->prepare("SELECT * FROM projects WHERE solar_system_id = :s ORDER BY id DESC LIMIT 1");
    $projStmt->execute([':s' => $system['id']]);
    $project = $projStmt->fetch() ?: null;
}

$nextMaintenance = null;
if ($project) {
    $nmStmt = $pdo->prepare("SELECT next_maintenance, status FROM maintenance_schedules WHERE project_id = :p LIMIT 1");
    $nmStmt->execute([':p' => $project['id']]);
    $nextMaintenance = $nmStmt->fetch() ?: null;
}

$recentHistory = $pdo->prepare(
    "SELECT job_code, job_type, stage, scheduled_date, updated_at FROM jobs WHERE client_id = :c ORDER BY updated_at DESC LIMIT 5"
);
$recentHistory->execute([':c' => $clientId]);

$notifStmt = $pdo->prepare(
    "SELECT n.id, n.type, n.message, n.is_read, n.created_at
     FROM notifications n JOIN clients c ON c.user_id = n.user_id
     WHERE c.id = :c ORDER BY n.created_at DESC LIMIT 10"
);
$notifStmt->execute([':c' => $clientId]);

json_success([
    'system'            => $system,
    'system_summary'    => $summary,
    'project'           => $project,
    'installation_age_days' => $summary['age_days'] ?? null,
    'active_service_requests' => $activeRequests,
    'next_maintenance'  => $nextMaintenance,
    'recent_history'    => $recentHistory->fetchAll(),
    'notifications'     => $notifStmt->fetchAll(),
]);
