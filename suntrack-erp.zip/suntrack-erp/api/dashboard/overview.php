<?php
/**
 * GET /api/dashboard/overview.php
 *
 * Everything the Admin and Management dashboards show, in one call:
 *
 *   headline     the numbers a manager checks first, each with a short
 *                explanation and a comparison where one is meaningful
 *   attention    a ranked to-do list (critical first), each item pointing at
 *                the module that resolves it
 *   agenda       what is scheduled for the next 14 days
 *   trends       the last 6 months: work completed, requests received, money collected
 *   breakdowns   service-request pipeline, projects, maintenance health,
 *                invoices by status, stock by category
 *   technicians  each technician's workload right now
 *   activity     the latest audit-log events
 *   modules      Clients / Technicians / Warehouse KPIs and chart series
 *                (includes/dashboard_lib.php)
 *
 * Read-only, for admin / manager / staff. Every figure is a plain aggregate of
 * live tables — nothing is cached or stored.
 */
require_once __DIR__ . '/../../middleware/admin.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed.', 405);
}

maintenance_refresh_statuses(); // keep DUE / OVERDUE current as days pass
billing_refresh_overdue();      // PENDING invoices past their due date -> OVERDUE

$pdo = db();
$num = function (string $sql, array $p = []) use ($pdo) {
    $s = $pdo->prepare($sql);
    $s->execute($p);
    return $s->fetchColumn();
};
$rows = function (string $sql, array $p = []) use ($pdo): array {
    $s = $pdo->prepare($sql);
    $s->execute($p);
    return $s->fetchAll();
};

$today      = date('Y-m-d');
$in14       = date('Y-m-d', strtotime('+14 days'));
$ago30      = date('Y-m-d H:i:s', strtotime('-30 days'));
$ago60      = date('Y-m-d H:i:s', strtotime('-60 days'));
$openSr     = "('PENDING','APPROVED','ASSIGNED','SCHEDULED','IN_PROGRESS','ON_HOLD')";
$fieldStage = "('EN_ROUTE','ARRIVED','IN_PROGRESS','PAUSED')";

// Material requests ship in their own migration; the dashboard must not break without it.
$hasOrders = true;
try {
    $pdo->query('SELECT 1 FROM material_requests LIMIT 0');
} catch (PDOException $e) {
    $hasOrders = false;
}

// ---------------------------------------------------------------------------
// Headline numbers
// ---------------------------------------------------------------------------
$h = [
    'clients_total'        => (int)$num('SELECT COUNT(*) FROM clients'),
    'clients_active'       => (int)$num("SELECT COUNT(*) FROM clients c JOIN users u ON u.id = c.user_id WHERE u.status = 'ACTIVE'"),
    'clients_new_30d'      => (int)$num('SELECT COUNT(*) FROM clients WHERE created_at >= :d', [':d' => $ago30]),

    'sr_open'              => (int)$num("SELECT COUNT(*) FROM service_requests WHERE status IN $openSr"),
    'sr_pending'           => (int)$num("SELECT COUNT(*) FROM service_requests WHERE status = 'PENDING'"),
    'sr_urgent_open'       => (int)$num("SELECT COUNT(*) FROM service_requests WHERE status IN $openSr AND priority IN ('URGENT','HIGH')"),
    'sr_unassigned'        => (int)$num("SELECT COUNT(*) FROM service_requests WHERE status = 'APPROVED' AND assigned_technician_id IS NULL"),
    'sr_completed_30d'     => (int)$num("SELECT COUNT(*) FROM service_requests WHERE status = 'COMPLETED' AND completion_date >= :d", [':d' => $ago30]),

    'jobs_open'            => (int)$num("SELECT COUNT(*) FROM jobs WHERE stage NOT IN ('COMPLETED','CANCELLED')"),
    'jobs_in_field'        => (int)$num("SELECT COUNT(*) FROM jobs WHERE stage IN $fieldStage"),
    'jobs_unassigned'      => (int)$num("SELECT COUNT(*) FROM jobs WHERE technician_id IS NULL AND stage NOT IN ('COMPLETED','CANCELLED')"),
    'jobs_completed_30d'   => (int)$num("SELECT COUNT(DISTINCT job_id) FROM job_status_history WHERE to_stage = 'COMPLETED' AND created_at >= :d", [':d' => $ago30]),
    'jobs_completed_prev'  => (int)$num("SELECT COUNT(DISTINCT job_id) FROM job_status_history WHERE to_stage = 'COMPLETED' AND created_at >= :a AND created_at < :b", [':a' => $ago60, ':b' => $ago30]),
    'reports_missing'      => (int)$num("SELECT COUNT(*) FROM jobs j WHERE j.stage = 'COMPLETED' AND NOT EXISTS (SELECT 1 FROM work_reports wr WHERE wr.job_id = j.id)"),
    'jobs_paused_long'     => (int)$num("SELECT COUNT(*) FROM jobs WHERE stage = 'PAUSED' AND updated_at < DATE_SUB(NOW(), INTERVAL 2 DAY)"),

    'projects_total'       => (int)$num('SELECT COUNT(*) FROM projects'),
    'projects_active'      => (int)$num("SELECT COUNT(*) FROM projects WHERE status IN ('PLANNED','SCHEDULED','IN_PROGRESS')"),
    'projects_installing'  => (int)$num("SELECT COUNT(*) FROM projects WHERE status = 'IN_PROGRESS'"),
    'systems_active'       => (int)$num("SELECT COUNT(*) FROM solar_systems WHERE status = 'ACTIVE'"),
    'capacity_kw_active'   => (float)$num("SELECT COALESCE(SUM(capacity_kw), 0) FROM solar_systems WHERE status = 'ACTIVE'"),

    'tech_total'           => (int)$num("SELECT COUNT(*) FROM " . tech_staff_table() . " t JOIN users u ON u.id = t.user_id WHERE u.status = 'ACTIVE'"),
    'tech_available'       => (int)$num("SELECT COUNT(*) FROM technician_availability ta JOIN " . tech_staff_table() . " t ON t.id = ta.technician_id JOIN users u ON u.id = t.user_id WHERE u.status = 'ACTIVE' AND ta.status = 'AVAILABLE'"),
    'tech_busy'            => (int)$num("SELECT COUNT(*) FROM technician_availability ta JOIN " . tech_staff_table() . " t ON t.id = ta.technician_id JOIN users u ON u.id = t.user_id WHERE u.status = 'ACTIVE' AND ta.status = 'BUSY'"),
    'tech_on_site'         => (int)$num('SELECT COUNT(DISTINCT technician_id) FROM attendance WHERE time_in IS NOT NULL AND time_out IS NULL'),

    'collected_30d'        => (float)$num('SELECT COALESCE(SUM(p.amount), 0) FROM payments p WHERE ' . billing_valid_payment('p') . ' AND p.paid_at >= :d', [':d' => $ago30]),
    'collected_prev_30d'   => (float)$num('SELECT COALESCE(SUM(p.amount), 0) FROM payments p WHERE ' . billing_valid_payment('p') . ' AND p.paid_at >= :a AND p.paid_at < :b', [':a' => $ago60, ':b' => $ago30]),
    'collected_total'      => (float)$num('SELECT COALESCE(SUM(p.amount), 0) FROM payments p WHERE ' . billing_valid_payment('p')),
    // What clients still owe = invoice amount minus what they already paid on it.
    'receivable'           => (float)$num("SELECT COALESCE(SUM(i.amount - COALESCE(p.paid, 0)), 0) FROM invoices i
                                            LEFT JOIN (" . billing_paid_subquery() . ") p ON p.invoice_id = i.id
                                            WHERE i.payment_status IN ('PENDING','OVERDUE')"),
    'overdue_amount'       => (float)$num("SELECT COALESCE(SUM(i.amount - COALESCE(p.paid, 0)), 0) FROM invoices i
                                            LEFT JOIN (" . billing_paid_subquery() . ") p ON p.invoice_id = i.id
                                            WHERE i.payment_status = 'OVERDUE'"),
    'overdue_invoices'     => (int)$num("SELECT COUNT(*) FROM invoices WHERE payment_status = 'OVERDUE'"),

    'maint_overdue'        => (int)$num("SELECT COUNT(*) FROM maintenance_schedules WHERE status = 'OVERDUE'"),
    'maint_due'            => (int)$num("SELECT COUNT(*) FROM maintenance_schedules WHERE status = 'DUE'"),
    'maint_upcoming'       => (int)$num("SELECT COUNT(*) FROM maintenance_schedules WHERE status = 'UPCOMING'"),

    'stock_low'            => (int)$num("SELECT COUNT(*) FROM inventory WHERE status = 'LOW_STOCK'"),
    'stock_out'            => (int)$num("SELECT COUNT(*) FROM inventory WHERE status = 'OUT_OF_STOCK'"),
    'stock_value'          => (float)$num("SELECT COALESCE(SUM(quantity * unit_cost), 0) FROM inventory WHERE status <> 'DISCONTINUED'"),
    'stock_units'          => (int)$num("SELECT COALESCE(SUM(quantity), 0) FROM inventory WHERE status <> 'DISCONTINUED'"),

    'orders_open'          => $hasOrders ? (int)$num("SELECT COUNT(*) FROM material_requests WHERE status IN ('PENDING','PREPARING','READY')") : 0,
    'orders_ready'         => $hasOrders ? (int)$num("SELECT COUNT(*) FROM material_requests WHERE status = 'READY'") : 0,
    'orders_pending'       => $hasOrders ? (int)$num("SELECT COUNT(*) FROM material_requests WHERE status = 'PENDING'") : 0,
];

// ---------------------------------------------------------------------------
// Needs attention — ranked: critical, then warning, then info
// ---------------------------------------------------------------------------
$peso = fn(float $v) => '₱' . number_format($v, 0);
$plural = fn(int $n, string $one, string $many) => $n . ' ' . ($n === 1 ? $one : $many);
$attention = [];
$add = function (string $severity, int $count, string $title, string $detail, string $target) use (&$attention) {
    if ($count > 0) {
        $attention[] = compact('severity', 'count', 'title', 'detail', 'target');
    }
};
$add('critical', $h['sr_urgent_open'], $plural($h['sr_urgent_open'], 'urgent or high-priority service request is open', 'urgent or high-priority service requests are open'),
     'Clients are waiting on these first.', 'service_requests');
$add('critical', $h['maint_overdue'], $plural($h['maint_overdue'], 'system is overdue for maintenance', 'systems are overdue for maintenance'),
     'The planned service date has already passed.', 'maintenance');
$add('critical', $h['overdue_invoices'], $plural($h['overdue_invoices'], 'invoice is overdue', 'invoices are overdue'),
     $peso($h['overdue_amount']) . ' unpaid past the due date.', 'billing');
$add('critical', $h['stock_out'], $plural($h['stock_out'], 'stock item is out of stock', 'stock items are out of stock'),
     'Orders that need them cannot be prepared.', 'inventory');
$add('warning', $h['sr_pending'], $plural($h['sr_pending'], 'new service request needs review', 'new service requests need review'),
     'Approve or reject them so work can be scheduled.', 'service_requests');
$add('warning', $h['sr_unassigned'], $plural($h['sr_unassigned'], 'approved request has no technician', 'approved requests have no technician'),
     'Assign a technician to move them forward.', 'service_requests');
$add('warning', $h['jobs_unassigned'], $plural($h['jobs_unassigned'], 'open job has no technician', 'open jobs have no technician'),
     'Nobody will go to these sites until one is assigned.', 'jobs');
$add('warning', $h['maint_due'], $plural($h['maint_due'], 'system is due for maintenance within 14 days', 'systems are due for maintenance within 14 days'),
     'Book a technician and notify the client.', 'maintenance');
$add('warning', $h['stock_low'], $plural($h['stock_low'], 'stock item is running low', 'stock items are running low'),
     'Fewer than ' . INVENTORY_LOW_STOCK_BELOW . ' units left.', 'inventory');
$add('warning', $h['jobs_paused_long'], $plural($h['jobs_paused_long'], 'job has been paused for over 2 days', 'jobs have been paused for over 2 days'),
     'Check whether parts or approvals are holding them up.', 'jobs');
$add('warning', $h['reports_missing'], $plural($h['reports_missing'], 'completed job has no work report', 'completed jobs have no work report'),
     'The technician still needs to file it.', 'reports');
$add('info', $h['orders_ready'], $plural($h['orders_ready'], 'client order is packed and ready to release', 'client orders are packed and ready to release'),
     'The warehouse can hand these over.', 'orders');
$add('info', $h['orders_pending'], $plural($h['orders_pending'], 'client order is waiting for the warehouse', 'client orders are waiting for the warehouse'),
     'Not yet started in the warehouse.', 'orders');

// ---------------------------------------------------------------------------
// Agenda — the next 14 days (and anything scheduled earlier that is still open)
// ---------------------------------------------------------------------------
$agendaJobs = $rows(
    "SELECT j.scheduled_date AS date, j.job_code AS code, j.job_type AS type, j.stage, j.priority,
            cu.full_name AS client, c.city, tu.full_name AS technician
     FROM jobs j
     JOIN clients c ON c.id = j.client_id
     JOIN users cu ON cu.id = c.user_id
     LEFT JOIN technicians t ON t.id = j.technician_id
     LEFT JOIN users tu ON tu.id = t.user_id
     WHERE j.stage NOT IN ('COMPLETED','CANCELLED') AND j.scheduled_date IS NOT NULL AND j.scheduled_date <= :to
     ORDER BY j.scheduled_date ASC, FIELD(j.priority, 'URGENT','HIGH','NORMAL','LOW'), j.id ASC
     LIMIT 15",
    [':to' => $in14]
);
$agendaMaint = $rows(
    "SELECT ms.next_maintenance AS date, p.project_code AS code, 'MAINTENANCE_DUE' AS type, ms.status AS stage, NULL AS priority,
            cu.full_name AS client, c.city, NULL AS technician
     FROM maintenance_schedules ms
     JOIN projects p ON p.id = ms.project_id
     JOIN clients c ON c.id = p.client_id
     JOIN users cu ON cu.id = c.user_id
     WHERE ms.next_maintenance <= :to AND ms.status IN ('DUE','OVERDUE')
       AND NOT EXISTS (SELECT 1 FROM jobs mj WHERE mj.project_id = p.id AND mj.job_type = 'MAINTENANCE'
                       AND mj.stage NOT IN ('COMPLETED','CANCELLED'))
     ORDER BY ms.next_maintenance ASC
     LIMIT 10",
    [':to' => $in14]
);
$agenda = array_merge($agendaJobs, $agendaMaint);
usort($agenda, fn($a, $b) => strcmp((string)$a['date'], (string)$b['date']));
$agenda = array_slice($agenda, 0, 15);

// ---------------------------------------------------------------------------
// Trends — the last 6 calendar months, including this one
// ---------------------------------------------------------------------------
$months = [];
for ($i = 5; $i >= 0; $i--) {
    $ts = strtotime(date('Y-m-01') . " -$i months");
    $months[date('Y-m', $ts)] = date('M Y', $ts);
}
$since = array_key_first($months) . '-01';
$series = fn(array $map) => array_map(fn($k) => $map[$k] ?? 0, array_keys($months));

$completedByMonth = ['INSTALLATION' => [], 'SERVICE' => []];
foreach ($rows(
    "SELECT DATE_FORMAT(h.first_done, '%Y-%m') AS ym, IF(j.job_type = 'INSTALLATION', 'INSTALLATION', 'SERVICE') AS kind, COUNT(*) AS n
     FROM (SELECT job_id, MIN(created_at) AS first_done FROM job_status_history WHERE to_stage = 'COMPLETED' GROUP BY job_id) h
     JOIN jobs j ON j.id = h.job_id
     WHERE h.first_done >= :s
     GROUP BY ym, kind",
    [':s' => $since]
) as $r) {
    $completedByMonth[$r['kind']][$r['ym']] = (int)$r['n'];
}
$requestsByMonth = [];
foreach ($rows("SELECT DATE_FORMAT(date_requested, '%Y-%m') AS ym, COUNT(*) AS n FROM service_requests WHERE date_requested >= :s GROUP BY ym", [':s' => $since]) as $r) {
    $requestsByMonth[$r['ym']] = (int)$r['n'];
}
$collectedByMonth = [];
foreach ($rows("SELECT DATE_FORMAT(p.paid_at, '%Y-%m') AS ym, SUM(p.amount) AS total FROM payments p WHERE " . billing_valid_payment('p') . " AND p.paid_at >= :s GROUP BY ym", [':s' => $since]) as $r) {
    $collectedByMonth[$r['ym']] = round((float)$r['total'], 2);
}

// ---------------------------------------------------------------------------
// Breakdowns — every status listed in workflow order, zeros included
// ---------------------------------------------------------------------------
$ordered = function (array $order, string $sql) use ($rows): array {
    $counts = array_fill_keys($order, 0);
    foreach ($rows($sql) as $r) {
        if (array_key_exists($r['k'], $counts)) {
            $counts[$r['k']] = (int)$r['n'];
        }
    }
    return array_map(fn($k, $v) => ['key' => $k, 'count' => $v], array_keys($counts), $counts);
};

$srPipeline = $ordered(['PENDING', 'APPROVED', 'ASSIGNED', 'SCHEDULED', 'IN_PROGRESS', 'ON_HOLD', 'COMPLETED', 'CANCELLED', 'REJECTED'],
    'SELECT status AS k, COUNT(*) AS n FROM service_requests GROUP BY status');
$projects = $ordered(['PLANNED', 'SCHEDULED', 'IN_PROGRESS', 'MAINTENANCE', 'COMPLETED', 'CANCELLED'],
    'SELECT status AS k, COUNT(*) AS n FROM projects GROUP BY status');
$jobsByStage = $ordered(['SUBMITTED', 'ASSIGNED', 'EN_ROUTE', 'ARRIVED', 'IN_PROGRESS', 'PAUSED'],
    "SELECT stage AS k, COUNT(*) AS n FROM jobs WHERE stage NOT IN ('COMPLETED','CANCELLED') GROUP BY stage");
$srByType = $rows("SELECT COALESCE(request_type, 'Other') AS k, COUNT(*) AS n FROM service_requests
                   WHERE status IN $openSr GROUP BY k ORDER BY n DESC, k ASC");

$invoiceStatus = [];
foreach (['PAID', 'PENDING', 'OVERDUE', 'CANCELLED'] as $st) {
    $invoiceStatus[$st] = ['count' => 0, 'amount' => 0.0];
}
foreach ($rows('SELECT payment_status AS k, COUNT(*) AS n, COALESCE(SUM(amount), 0) AS amt FROM invoices GROUP BY payment_status') as $r) {
    if (isset($invoiceStatus[$r['k']])) {
        $invoiceStatus[$r['k']] = ['count' => (int)$r['n'], 'amount' => round((float)$r['amt'], 2)];
    }
}

$stockByCategory = $rows(
    "SELECT ic.category_name AS category,
            COALESCE(SUM(CASE WHEN i.status <> 'DISCONTINUED' THEN i.quantity END), 0) AS units,
            COALESCE(SUM(CASE WHEN i.status <> 'DISCONTINUED' THEN i.quantity * i.unit_cost END), 0) AS value,
            SUM(i.status = 'LOW_STOCK') AS low, SUM(i.status = 'OUT_OF_STOCK') AS out_of_stock,
            COUNT(i.id) AS skus
     FROM inventory_categories ic
     LEFT JOIN inventory i ON i.category_id = ic.id
     GROUP BY ic.id, ic.category_name
     ORDER BY ic.id"
);
foreach ($stockByCategory as &$s) {
    $s['units'] = (int)$s['units'];
    $s['value'] = round((float)$s['value'], 2);
    $s['low'] = (int)$s['low'];
    $s['out_of_stock'] = (int)$s['out_of_stock'];
    $s['skus'] = (int)$s['skus'];
}
unset($s);

// ---------------------------------------------------------------------------
// Technician workload
// ---------------------------------------------------------------------------
$technicians = $rows(
    "SELECT t.id, t.technician_code AS code, u.full_name AS name, COALESCE(ta.status, 'AVAILABLE') AS availability,
            (SELECT COUNT(*) FROM jobs j WHERE j.technician_id = t.id AND j.stage NOT IN ('COMPLETED','CANCELLED')) AS open_jobs,
            (SELECT CONCAT(j.job_code, '|', j.stage) FROM jobs j WHERE j.technician_id = t.id AND j.stage IN $fieldStage
             ORDER BY j.updated_at DESC LIMIT 1) AS field_job,
            (SELECT COUNT(*) FROM attendance a WHERE a.technician_id = t.id AND a.time_in IS NOT NULL AND a.time_out IS NULL) AS on_site,
            (SELECT COUNT(DISTINCT h.job_id) FROM job_status_history h JOIN jobs j ON j.id = h.job_id
             WHERE j.technician_id = t.id AND h.to_stage = 'COMPLETED' AND h.created_at >= :d) AS completed_30d
     FROM " . tech_staff_table() . " t
     JOIN users u ON u.id = t.user_id
     LEFT JOIN technician_availability ta ON ta.technician_id = t.id
     WHERE u.status = 'ACTIVE'
     ORDER BY open_jobs DESC, u.full_name ASC",
    [':d' => $ago30]
);
foreach ($technicians as &$t) {
    $t['open_jobs'] = (int)$t['open_jobs'];
    $t['on_site'] = (int)$t['on_site'] > 0;
    $t['completed_30d'] = (int)$t['completed_30d'];
    if ($t['field_job']) {
        [$t['field_job_code'], $t['field_stage']] = explode('|', $t['field_job'], 2);
    } else {
        $t['field_job_code'] = $t['field_stage'] = null;
    }
    unset($t['field_job']);
}
unset($t);

// ---------------------------------------------------------------------------
// Recent activity
// ---------------------------------------------------------------------------
$activity = $rows(
    "SELECT a.action, a.module, a.record_id, a.created_at, a.role_key, u.full_name AS actor
     FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
     WHERE a.action NOT IN ('LOGIN','LOGOUT')
     ORDER BY a.created_at DESC, a.id DESC
     LIMIT 12"
);

json_success([
    'generated_at' => date('Y-m-d H:i:s'),
    'headline'     => $h,
    'attention'    => $attention,
    'agenda'       => $agenda,
    'trends'       => [
        'labels'              => array_values($months),
        'installations_done'  => $series($completedByMonth['INSTALLATION']),
        'service_jobs_done'   => $series($completedByMonth['SERVICE']),
        'requests_received'   => $series($requestsByMonth),
        'collected'           => $series($collectedByMonth),
    ],
    'breakdowns'   => [
        'service_requests' => $srPipeline,
        'requests_by_type' => array_map(fn($r) => ['key' => $r['k'], 'count' => (int)$r['n']], $srByType),
        'projects'         => $projects,
        'jobs_by_stage'    => $jobsByStage,
        'invoices'         => $invoiceStatus,
        'stock'            => $stockByCategory,
    ],
    'technicians'  => $technicians,
    'activity'     => $activity,
    'modules'      => dashboard_modules($pdo),
]);
