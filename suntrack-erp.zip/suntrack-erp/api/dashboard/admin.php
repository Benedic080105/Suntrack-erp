<?php
/**
 * GET /api/dashboard/admin.php?period=7d|30d|12m
 *
 * The Admin dashboard (admin/index.php, assets/js/suntrack-admin-dashboard.js).
 * Admin / manager / staff only (middleware/admin.php). Read-only.
 *
 * Definitions — each job is counted in exactly one status group:
 *   Pending      SUBMITTED, ASSIGNED          (not started yet)
 *   In Progress  EN_ROUTE, ARRIVED, IN_PROGRESS (technician on the way / on site)
 *   On Hold      PAUSED
 *   Completed    COMPLETED
 *   Cancelled    CANCELLED — reported separately, not part of the pie
 *
 *   Total Clients    all registered clients (all time); "+N new" follows the period
 *   Active Jobs      jobs In Progress right now
 *   Completed Jobs   jobs that are COMPLETED and whose completion (the
 *                    job_status_history row that moved them to COMPLETED) falls
 *                    in the period — the real completion time, never created_at
 *   Needs Attention  the sum of the alert counts listed under "Needs Attention"
 *                    (each item is counted once; see $alertsSql)
 *   Billing          four figures from billing_overview() — see the comment
 *                    where it is called (valid payments only, voided excluded)
 *
 * Periods: 7d = today and the 6 days before (daily), 30d = 30 days (daily),
 * 12m = this month and the 11 before (monthly). Times are Asia/Manila
 * (config/config.php and the +08:00 database session, config/database.php).
 */
require_once __DIR__ . '/../../middleware/admin.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed.', 405);
}

$period = $_GET['period'] ?? '7d';
if (!in_array($period, ['7d', '30d', '12m'], true)) {
    $period = '7d';
}

try {
    maintenance_refresh_statuses(); // keep DUE / OVERDUE current as days pass
    $pdo = db();

    // -----------------------------------------------------------------------
    // Reporting period and its buckets (missing days / months become zeros)
    // -----------------------------------------------------------------------
    $buckets = [];
    if ($period === '12m') {
        $first = new DateTimeImmutable(date('Y-m-01'));
        for ($i = 11; $i >= 0; $i--) {
            $d = $first->modify("-$i months");
            $buckets[$d->format('Y-m')] = $d->format('M Y');
        }
        $start = $first->modify('-11 months')->format('Y-m-d 00:00:00');
        $bucketSql = "DATE_FORMAT(%s, '%%Y-%%m')";
        $periodLabel = 'Last 12 months';
    } else {
        $days = $period === '30d' ? 30 : 7;
        $today = new DateTimeImmutable(date('Y-m-d'));
        for ($i = $days - 1; $i >= 0; $i--) {
            $d = $today->modify("-$i days");
            $buckets[$d->format('Y-m-d')] = $days === 7 ? $d->format('D, M j') : $d->format('M j');
        }
        $start = $today->modify('-' . ($days - 1) . ' days')->format('Y-m-d 00:00:00');
        $bucketSql = 'DATE(%s)';
        $periodLabel = "Last $days days";
    }

    // -----------------------------------------------------------------------
    // Trend: completed (real completion time) and newly created jobs per bucket
    // -----------------------------------------------------------------------
    // A job can be reopened and completed again; its completion time is the
    // latest move to COMPLETED, and only jobs still COMPLETED count.
    $completedSql = "SELECT " . sprintf($bucketSql, 'done.completed_at') . " AS b, COUNT(*) AS n
        FROM (SELECT h.job_id, MAX(h.created_at) AS completed_at
              FROM job_status_history h
              JOIN jobs j ON j.id = h.job_id AND j.stage = 'COMPLETED'
              WHERE h.to_stage = 'COMPLETED'
              GROUP BY h.job_id) done
        WHERE done.completed_at >= :start
        GROUP BY b";
    $createdSql = "SELECT " . sprintf($bucketSql, 'created_at') . " AS b, COUNT(*) AS n
        FROM jobs WHERE created_at >= :start GROUP BY b";

    $completed = array_fill_keys(array_keys($buckets), 0);
    $stmt = $pdo->prepare($completedSql);
    $stmt->execute([':start' => $start]);
    foreach ($stmt as $r) {
        if (isset($completed[$r['b']])) {
            $completed[$r['b']] = (int)$r['n'];
        }
    }
    $created = array_fill_keys(array_keys($buckets), 0);
    $stmt = $pdo->prepare($createdSql);
    $stmt->execute([':start' => $start]);
    foreach ($stmt as $r) {
        if (isset($created[$r['b']])) {
            $created[$r['b']] = (int)$r['n'];
        }
    }

    // -----------------------------------------------------------------------
    // Job status groups (pie + Active Jobs), one query
    // -----------------------------------------------------------------------
    $groupOf = [
        'SUBMITTED' => 'pending', 'ASSIGNED' => 'pending',
        'EN_ROUTE' => 'in_progress', 'ARRIVED' => 'in_progress', 'IN_PROGRESS' => 'in_progress',
        'PAUSED' => 'on_hold', 'COMPLETED' => 'completed', 'CANCELLED' => 'cancelled',
    ];
    $groups = ['completed' => 0, 'in_progress' => 0, 'pending' => 0, 'on_hold' => 0, 'cancelled' => 0];
    foreach ($pdo->query('SELECT stage, COUNT(*) AS n FROM jobs GROUP BY stage') as $r) {
        if (isset($groupOf[$r['stage']])) {
            $groups[$groupOf[$r['stage']]] += (int)$r['n'];
        }
    }

    // -----------------------------------------------------------------------
    // Clients and attention counts, one round trip
    // -----------------------------------------------------------------------
    // Overdue maintenance only counts when no open maintenance job exists for
    // the project — otherwise that job is already counted (if overdue) above.
    // Subcontracted jobs are tracked by their assignment's own deadline below.
    if (sub_is_management()) {
        sub_auto_sweep($pdo); // expired offers move on to the next subcontractor
    }
    $notSubcontracted = sub_ready() ? 'AND id NOT IN (SELECT job_id FROM subcontractor_assignments WHERE active_job_id IS NOT NULL)' : '';
    $alertsSql = "SELECT
        (SELECT COUNT(*) FROM clients) AS clients_total,
        (SELECT COUNT(*) FROM clients c JOIN users u ON u.id = c.user_id WHERE u.status = 'ACTIVE') AS clients_active,
        (SELECT COUNT(*) FROM clients WHERE created_at >= :start) AS clients_new,
        (SELECT COUNT(*) FROM jobs WHERE stage NOT IN ('COMPLETED','CANCELLED') AND scheduled_date < CURDATE() $notSubcontracted) AS overdue_jobs,
        (SELECT MIN(scheduled_date) FROM jobs WHERE stage NOT IN ('COMPLETED','CANCELLED') AND scheduled_date < CURDATE() $notSubcontracted) AS oldest_overdue,
        (SELECT COUNT(*) FROM maintenance_schedules ms WHERE ms.status = 'OVERDUE'
            AND NOT EXISTS (SELECT 1 FROM jobs mj WHERE mj.project_id = ms.project_id AND mj.job_type = 'MAINTENANCE'
                            AND mj.stage NOT IN ('COMPLETED','CANCELLED'))) AS overdue_maintenance,
        (SELECT COUNT(*) FROM service_requests WHERE status = 'PENDING') AS pending_requests,
        (SELECT MIN(date_requested) FROM service_requests WHERE status = 'PENDING') AS oldest_request,
        (SELECT COUNT(*) FROM inventory WHERE status = 'OUT_OF_STOCK') AS out_of_stock,
        (SELECT COUNT(*) FROM inventory WHERE status = 'LOW_STOCK') AS low_stock";
    $stmt = $pdo->prepare($alertsSql);
    $stmt->execute([':start' => $start]);
    $a = $stmt->fetch();

    $plural = fn(int $n, string $one, string $many) => $n . ' ' . ($n === 1 ? $one : $many);
    $since = fn(?string $d) => $d ? ' Oldest from ' . date('M j', strtotime($d)) . '.' : '';
    $candidates = [
        ['critical', (int)$a['overdue_jobs'], 'Overdue jobs', 'Scheduled date has passed and the job is not finished.' . $since($a['oldest_overdue']), 'sitemap'],
        ['critical', (int)$a['overdue_maintenance'], 'Overdue maintenance', 'Systems past their service date with no maintenance job booked.', 'maintenance'],
        ['critical', (int)$a['out_of_stock'], 'Out of stock', 'Items with zero units — orders needing them cannot be prepared.', 'inventory'],
        ['warning', (int)$a['pending_requests'], 'Service requests to review', 'New requests waiting for approval or rejection.' . $since($a['oldest_request']), 'service-requests'],
        ['warning', (int)$a['low_stock'], 'Low stock', 'Items below ' . INVENTORY_LOW_STOCK_BELOW . ' units.', 'inventory'],
    ];
    // Subcontractor work — each a different thing to act on.
    $sc = sub_dashboard_counts($pdo);
    $candidates[] = ['critical', $sc['overdue'], 'Overdue subcontractor work', 'Past the expected completion date and not finished.', 'subcontractors'];
    $candidates[] = ['warning', $sc['awaiting_inspection'], 'Subcontractor work to inspect', 'Submitted — approve it or request a revision.', 'subcontractors'];
    $candidates[] = ['warning', $sc['awaiting_acceptance'], 'Offers awaiting subcontractor reply', 'Jobs offered to subcontractors that are not accepted yet.', 'subcontractors'];

    $attention = [];
    foreach ($candidates as [$severity, $count, $title, $detail, $target]) {
        if ($count > 0) {
            $attention[] = compact('severity', 'count', 'title', 'detail', 'target');
        }
    }
    // Critical first, then the biggest. The card counts all; the list shows five.
    usort($attention, fn($x, $y) => [$x['severity'] !== 'critical', -$x['count']] <=> [$y['severity'] !== 'critical', -$y['count']]);
    $attentionTotal = array_sum(array_column($attention, 'count'));
    $attentionMore = max(0, count($attention) - 5);
    $attention = array_slice($attention, 0, 5);

    // Billing Overview — definitions in includes/billing_lib.php (billing_overview):
    //   Payments Received    valid (not voided) payments with paid_at in the period
    //   Outstanding Balance  Σ max(amount − valid payments, 0) over non-voided invoices, now
    //   Overdue Invoices     non-voided invoices with a balance and a due date before today
    //   Pending Payments     non-voided invoices with a balance, not yet due (or no due date)
    //   Outstanding = Overdue amount + Pending amount (each invoice in exactly one).
    $billing = billing_overview($pdo, $start);

    $wantDemo = APP_ENV === 'development' && ($_GET['demo'] ?? '') === '1';

    json_success([
        'generated_at' => date('Y-m-d H:i:s'),
        'timezone'     => date_default_timezone_get(),
        'period'       => ['key' => $period, 'label' => $periodLabel, 'start' => substr($start, 0, 10), 'end' => date('Y-m-d'),
                           'grouping' => $period === '12m' ? 'month' : 'day'],
        'kpis'         => [
            'clients_total'    => (int)$a['clients_total'],
            'clients_active'   => (int)$a['clients_active'],
            'clients_new'      => (int)$a['clients_new'],
            'active_jobs'      => $groups['in_progress'],
            'on_hold'          => $groups['on_hold'],
            'pending'          => $groups['pending'],
            'completed_period' => array_sum($completed),
            'completed_total'  => $groups['completed'],
            'needs_attention'  => $attentionTotal,
            'active_subcontractors' => $sc['active_subcontractors'],
        ],
        'trend'        => [
            'labels'    => array_values($buckets),
            'keys'      => array_keys($buckets),
            'completed' => array_values($completed),
            'created'   => array_values($created),
        ],
        'billing'      => $billing,
        'status'       => $groups,
        'attention'    => $attention,
        'attention_more' => $attentionMore,
        // Figures behind the Clients / Technicians / Warehouse buttons.
        'modules'      => $wantDemo ? dashboard_modules_demo() : dashboard_modules($pdo),
    ]);
} catch (Throwable $e) {
    error_log('dashboard/admin failed: ' . $e->getMessage());
    json_error('The dashboard could not be loaded. Please try again.', 500);
}
