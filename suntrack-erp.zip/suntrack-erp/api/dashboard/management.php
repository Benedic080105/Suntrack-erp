<?php
/**
 * GET /api/dashboard/management.php
 * Management only (manager/staff). The operational dashboard from the
 * Phase 2 brief: the 12 KPI cards plus a "Requires Attention" list, each
 * item linking to the module that handles it.
 */
require_once __DIR__ . '/../../config/config.php';
require_management();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed.', 405);
}

maintenance_refresh_statuses(); // keep DUE/OVERDUE current as days pass
$pdo = db();

$kpis = [
    'total_clients'          => (int)$pdo->query("SELECT COUNT(*) FROM clients")->fetchColumn(),
    'active_projects'        => (int)$pdo->query("SELECT COUNT(*) FROM projects WHERE status NOT IN ('COMPLETED','CANCELLED')")->fetchColumn(),
    'pending_service_requests' => (int)$pdo->query("SELECT COUNT(*) FROM service_requests WHERE status = 'PENDING'")->fetchColumn(),
    'active_jobs'             => (int)$pdo->query("SELECT COUNT(*) FROM jobs WHERE stage NOT IN ('COMPLETED','CANCELLED')")->fetchColumn(),
    'jobs_in_progress'        => (int)$pdo->query("SELECT COUNT(*) FROM jobs WHERE stage = 'IN_PROGRESS'")->fetchColumn(),
    'completed_jobs'          => (int)$pdo->query("SELECT COUNT(*) FROM jobs WHERE stage = 'COMPLETED'")->fetchColumn(),
    'available_technicians'   => (int)$pdo->query("SELECT COUNT(*) FROM technician_availability WHERE status = 'AVAILABLE'")->fetchColumn(),
    'busy_technicians'        => (int)$pdo->query("SELECT COUNT(*) FROM technician_availability WHERE status = 'BUSY'")->fetchColumn(),
    'low_inventory_items'     => (int)$pdo->query("SELECT COUNT(*) FROM inventory WHERE status IN ('LOW_STOCK','OUT_OF_STOCK')")->fetchColumn(),
    'upcoming_maintenance'    => (int)$pdo->query("SELECT COUNT(*) FROM maintenance_schedules WHERE status = 'UPCOMING'")->fetchColumn(),
    'overdue_maintenance'     => (int)$pdo->query("SELECT COUNT(*) FROM maintenance_schedules WHERE status = 'OVERDUE'")->fetchColumn(),
    'pending_reports'         => (int)$pdo->query(
        "SELECT COUNT(*) FROM jobs j
         WHERE j.stage = 'COMPLETED'
           AND NOT EXISTS (SELECT 1 FROM work_reports wr WHERE wr.job_id = j.id)"
    )->fetchColumn(),
];

// --- Requires Attention --------------------------------------------------
$attention = [];

$pendingSr = (int)$pdo->query("SELECT COUNT(*) FROM service_requests WHERE status = 'PENDING'")->fetchColumn();
if ($pendingSr > 0) {
    $attention[] = ['label' => "$pendingSr pending service request" . ($pendingSr === 1 ? '' : 's') . ' awaiting review', 'module' => 'service_requests', 'count' => $pendingSr];
}

$unassigned = (int)$pdo->query("SELECT COUNT(*) FROM jobs WHERE technician_id IS NULL AND stage NOT IN ('COMPLETED','CANCELLED')")->fetchColumn();
if ($unassigned > 0) {
    $attention[] = ['label' => "$unassigned job" . ($unassigned === 1 ? '' : 's') . ' with no technician assigned', 'module' => 'jobs', 'count' => $unassigned];
}

$overdueMaint = $kpis['overdue_maintenance'];
if ($overdueMaint > 0) {
    $attention[] = ['label' => "$overdueMaint project" . ($overdueMaint === 1 ? '' : 's') . ' overdue for maintenance', 'module' => 'maintenance', 'count' => $overdueMaint];
}

$lowStock = $kpis['low_inventory_items'];
if ($lowStock > 0) {
    $attention[] = ['label' => "$lowStock inventory item" . ($lowStock === 1 ? '' : 's') . ' low or out of stock', 'module' => 'warehouse', 'count' => $lowStock];
}

$stuckJobs = (int)$pdo->query("SELECT COUNT(*) FROM jobs WHERE stage = 'PAUSED' AND updated_at < DATE_SUB(NOW(), INTERVAL 2 DAY)")->fetchColumn();
if ($stuckJobs > 0) {
    $attention[] = ['label' => "$stuckJobs job" . ($stuckJobs === 1 ? '' : 's') . ' paused for over 2 days', 'module' => 'jobs', 'count' => $stuckJobs];
}

$pendingReports = $kpis['pending_reports'];
if ($pendingReports > 0) {
    $attention[] = ['label' => "$pendingReports completed job" . ($pendingReports === 1 ? '' : 's') . ' awaiting a work report', 'module' => 'work_reports', 'count' => $pendingReports];
}

// Recent activity, scoped to this dashboard (not the full audit log).
$recentActivity = $pdo->query(
    "SELECT a.action, a.module, a.record_id, a.created_at, u.full_name AS actor_name
     FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
     ORDER BY a.created_at DESC LIMIT 10"
)->fetchAll();

json_success([
    'kpis'             => $kpis,
    'requires_attention' => $attention,
    'recent_activity'  => $recentActivity,
]);
