<?php
/**
 * /api/account/profile.php — the signed-in user's own account.
 *
 * Deliberately NOT api/warehouse/profile.php.
 *
 * "My name, my email, my phone, my password" is identical work for every
 * role. A warehouse-scoped copy would be duplicated the moment Technician or
 * Client settings arrive, and the password path is exactly where divergent
 * copies become a security problem — one of them eventually forgets to
 * regenerate the session, or to verify the current password. One endpoint,
 * scoped to whoever is signed in, is the version of "do not create duplicate
 * profile systems" that still holds in six months.
 *
 * It is inherently safe for every role because it never accepts a user id:
 * the row it reads and writes is always current_user_id(). There is no
 * parameter an attacker could change to reach another account.
 *
 *   GET                       → the current user's safe profile
 *   POST action=update_profile → full_name, phone, email
 *   POST action=change_password → current_password, new_password, confirm_password
 */
require_once __DIR__ . '/../../config/config.php';
require_login(true);

$pdo    = db();
$userId = (int)current_user_id();

// ---------------------------------------------------------------------------
// GET — read
// ---------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $pdo->prepare(
        'SELECT u.id, u.full_name, u.email, u.phone, u.status, u.last_login, u.created_at,
                r.role_key, r.role_label
         FROM users u
         JOIN roles r ON r.id = u.role_id
         WHERE u.id = :id'
    );
    $stmt->execute([':id' => $userId]);
    $user = $stmt->fetch();

    if (!$user) {
        json_error('Your account could not be loaded.', 404);
    }

    // password_hash is never selected, so it cannot be leaked by accident.
    json_success([
        'id'         => (int)$user['id'],
        'full_name'  => $user['full_name'],
        'email'      => $user['email'],
        'phone'      => $user['phone'],
        'status'     => $user['status'],
        'role_key'   => $user['role_key'],
        'role_name'  => $user['role_label'],
        'last_login' => $user['last_login'],
        'member_since' => $user['created_at'],
    ]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);

$action = $input['action'] ?? '';

// ---------------------------------------------------------------------------
// POST action=update_profile
// ---------------------------------------------------------------------------
if ($action === 'update_profile') {
    $fields = [];
    $params = [':id' => $userId];

    if (isset($input['full_name'])) {
        $name = trim((string)$input['full_name']);
        if (str_len($name) < 2) {
            json_error('Please enter your full name.', 422);
        }
        if (str_len($name) > 150) {
            json_error('That name is too long.', 422);
        }
        $fields[] = 'full_name = :full_name';
        $params[':full_name'] = $name;
    }

    if (isset($input['phone'])) {
        $phone = trim((string)$input['phone']);
        if ($phone !== '' && !preg_match('/^[0-9+()\-\s]{7,30}$/', $phone)) {
            json_error('Please enter a valid phone number.', 422);
        }
        $fields[] = 'phone = :phone';
        $params[':phone'] = $phone === '' ? null : $phone;
    }

    if (isset($input['email'])) {
        $email = trim(strtolower((string)$input['email']));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            json_error('Please enter a valid email address.', 422);
        }

        // Someone else's address is a conflict; your own is a no-op.
        $dupe = $pdo->prepare('SELECT id FROM users WHERE email = :e AND id <> :id');
        $dupe->execute([':e' => $email, ':id' => $userId]);
        if ($dupe->fetch()) {
            json_error('That email address is already in use.', 409);
        }

        $fields[] = 'email = :email';
        $params[':email'] = $email;
    }

    // Anything not listed above — role_id, status, id, password_hash — is
    // simply never built into the statement, so sending it has no effect.
    if (!$fields) {
        json_error('There was nothing to update.', 422);
    }

    $pdo->prepare('UPDATE users SET ' . implode(', ', $fields) . ' WHERE id = :id')->execute($params);

    // Keep the header name in step with the change.
    if (isset($params[':full_name'])) {
        $_SESSION['full_name'] = $params[':full_name'];
    }

    audit_log('UPDATE', 'users', 'own profile');
    json_success([], 'Settings saved.');
}

// ---------------------------------------------------------------------------
// POST action=change_password
// ---------------------------------------------------------------------------
if ($action === 'change_password') {
    require_fields($input, ['current_password', 'new_password', 'confirm_password']);

    $current = (string)$input['current_password'];
    $new     = (string)$input['new_password'];
    $confirm = (string)$input['confirm_password'];

    if ($new !== $confirm) {
        json_error('The new passwords do not match.', 422);
    }
    if (str_len($new) < PASSWORD_MIN_LENGTH) {
        json_error('Your new password must be at least ' . PASSWORD_MIN_LENGTH . ' characters.', 422);
    }
    if ($new === $current) {
        json_error('Your new password must be different from your current one.', 422);
    }

    $stmt = $pdo->prepare('SELECT email, password_hash FROM users WHERE id = :id');
    $stmt->execute([':id' => $userId]);
    $user = $stmt->fetch();
    if (!$user) {
        json_error('Your account could not be loaded.', 404);
    }

    // The current-password field is a password oracle: someone who walks up to
    // an unlocked terminal could sit and guess it. Reuse the same throttle the
    // login endpoint uses rather than leaving this one unlimited.
    login_guard_or_fail($user['email']);

    if (!password_verify($current, $user['password_hash'])) {
        login_record_attempt($user['email'], false);
        json_error('Your current password is incorrect.', 401);
    }

    $pdo->prepare('UPDATE users SET password_hash = :h WHERE id = :id')
        ->execute([':h' => password_hash($new, PASSWORD_DEFAULT), ':id' => $userId]);

    // A successful change clears the throttle counter for this account.
    login_record_attempt($user['email'], true);

    // Rotate the session id. Without this, anyone holding a stolen session
    // cookie keeps their access after the victim changes their password —
    // which is usually the very reason they are changing it.
    session_regenerate_id(true);
    $_SESSION['session_started_at'] = time();

    audit_log('PASSWORD_CHANGE', 'users', 'own account');
    json_success([], 'Your password has been changed.');
}

json_error('Unknown action.', 422);
