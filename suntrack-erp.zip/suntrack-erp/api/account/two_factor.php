<?php
/**
 * /api/account/two_factor.php — two-step login for the signed-in staff member.
 *
 *   GET                          { eligible, enabled, recovery_codes_left }
 *   POST action=start            new secret (kept in the session until
 *                                confirmed) + otpauth link for the QR code
 *   POST action=confirm  {code}  proves the app is set up; turns it on and
 *                                returns 8 one-time backup codes (shown once)
 *   POST action=disable  {password, code}
 *                                needs BOTH the password and a current code
 *                                (or a backup code), so a stolen unlocked
 *                                laptop cannot quietly switch it off
 *
 * Only staff roles (admin, manager, staff, warehouse). Always acts on the
 * session's own account — no user id is ever accepted.
 */
require_once __DIR__ . '/../../config/config.php';
require_login(true);

$userId = (int)current_user_id();
$eligible = in_array(current_role(), TOTP_ROLES, true);
$pdo = db();

try {
    $pdo->query('SELECT totp_enabled FROM users LIMIT 0');
} catch (PDOException $e) {
    json_error('Two-step login is not set up yet. Import database/phase7_beta_features.sql.', 503);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $left = (int)$pdo->query("SELECT COUNT(*) FROM user_recovery_codes WHERE user_id = $userId AND used_at IS NULL")->fetchColumn();
    json_success(['eligible' => $eligible, 'enabled' => totp_enabled_for($userId), 'recovery_codes_left' => $left]);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
if (!$eligible) {
    json_error('Two-step login is for staff accounts.', 403);
}

$input = json_input();
require_csrf($input);
$action = (string)($input['action'] ?? '');

if ($action === 'start') {
    if (totp_enabled_for($userId)) {
        json_error('Two-step login is already on.', 409);
    }
    $secret = totp_new_secret();
    $_SESSION['twofa_setup'] = ['secret' => $secret, 'at' => time()];
    $email = (string)$pdo->query("SELECT email FROM users WHERE id = $userId")->fetchColumn();
    json_success(['secret' => $secret, 'uri' => totp_uri($secret, $email)], 'Scan the QR code with your authenticator app.');
}

if ($action === 'confirm') {
    $setup = $_SESSION['twofa_setup'] ?? null;
    if (!$setup || time() - (int)$setup['at'] > 900) {
        unset($_SESSION['twofa_setup']);
        json_error('The setup expired. Please start again.', 422);
    }
    $step = totp_match($setup['secret'], (string)($input['code'] ?? ''));
    if ($step === null) {
        json_error('That code does not match. Make sure the phone\'s time is set automatically, then try the newest code.', 422);
    }
    $pdo->beginTransaction();
    $pdo->prepare('UPDATE users SET totp_secret = :s, totp_enabled = 1, totp_last_step = :st WHERE id = :id')
        ->execute([':s' => $setup['secret'], ':st' => $step, ':id' => $userId]);
    $codes = totp_new_recovery_codes($userId);
    $pdo->commit();
    unset($_SESSION['twofa_setup']);
    audit_log('2FA_ENABLE', 'auth', (string)$userId);
    json_success(['recovery_codes' => $codes], 'Two-step login is on. Save your backup codes somewhere safe.');
}

if ($action === 'disable') {
    $hash = (string)$pdo->query("SELECT password_hash FROM users WHERE id = $userId")->fetchColumn();
    if (!password_verify((string)($input['password'] ?? ''), $hash)) {
        json_error('Your password is not correct.', 422);
    }
    if (!totp_verify_user($userId, (string)($input['code'] ?? ''))) {
        json_error('That code is not right.', 422);
    }
    $pdo->prepare('UPDATE users SET totp_secret = NULL, totp_enabled = 0, totp_last_step = NULL WHERE id = :id')->execute([':id' => $userId]);
    $pdo->prepare('DELETE FROM user_recovery_codes WHERE user_id = :u')->execute([':u' => $userId]);
    audit_log('2FA_DISABLE', 'auth', (string)$userId);
    json_success([], 'Two-step login is off.');
}

json_error('Unknown action.', 422);
