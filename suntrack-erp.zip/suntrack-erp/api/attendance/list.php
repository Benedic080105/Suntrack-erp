<?php
require_once __DIR__ . '/../../middleware/admin.php';

$pdo = db();
[$pageLimit, $pageOffset] = list_page(200);
$where = [];
$params = [];

if ($clause = search_clause($_GET['search'] ?? '', search_columns('attendance'), $params)) {
    $where[] = $clause;
}
apply_date_range('a.time_in', $where, $params);
if (!empty($_GET['geofence_status'])) {
    $where[] = 'a.geofence_status = :gs';
    $params[':gs'] = $_GET['geofence_status'];
}
if (!empty($_GET['open_only'])) {
    $where[] = 'a.time_out IS NULL';
}

$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$sql = "SELECT a.*, t.technician_code, u.full_name AS technician_name, j.job_code, j.site_address
        FROM attendance a
        JOIN technicians t ON t.id = a.technician_id
        JOIN users u ON u.id = t.user_id
        JOIN jobs j ON j.id = a.job_id
        $whereSql
        ORDER BY a.time_in DESC, a.id DESC
        " . list_page_sql($pageLimit, $pageOffset);

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

json_success(list_page_finish($stmt->fetchAll(), $pageLimit, $pageOffset));
