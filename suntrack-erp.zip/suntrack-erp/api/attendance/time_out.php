<?php
/**
 * POST /api/attendance/time_out.php
 *
 * GPS Time Out. The exit coordinates and distance are always recorded, even
 * when the technician has already stepped outside the geofence — the point is
 * to have an honest record of where they left from.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['job_id', 'latitude', 'longitude']);

if (!is_numeric($input['latitude']) || !is_numeric($input['longitude'])) {
    json_error('Invalid coordinates.', 422);
}

$techId = (int)current_profile_id();
$lat    = (float)$input['latitude'];
$lng    = (float)$input['longitude'];

$job = tech_job_or_fail((int)$input['job_id']);
$att = tech_open_attendance((int)$job['id'], $techId);

if (!$att) {
    json_error('No open time-in found for this job.', 404);
}

$radius   = tech_geofence_radius($job);
$distance = tech_distance_to_site($job, $lat, $lng);

$pdo = db();
$pdo->prepare(
    'UPDATE attendance SET time_out = NOW(), lat_out = :lat, lng_out = :lng, distance_out_m = :dist
     WHERE id = :id AND technician_id = :t'
)->execute([
    ':lat'  => round($lat, 7),
    ':lng'  => round($lng, 7),
    ':dist' => $distance !== null ? round($distance, 2) : null,
    ':id'   => $att['id'],
    ':t'    => $techId,
]);

if ($distance !== null) {
    $accuracy = isset($input['accuracy']) && is_numeric($input['accuracy']) ? (float)$input['accuracy'] : null;
    $jump = tech_gps_jump($techId, $lat, $lng, $accuracy);
    tech_record_geofence((int)$job['id'], $techId, $lat, $lng, $distance, $distance <= $radius ? 'INSIDE' : 'OUTSIDE',
        $accuracy, $jump ? 'IMPOSSIBLE_JUMP' : null);
    tech_report_gps_jump($job, $techId, $jump);
}

audit_log('TIME_OUT', 'attendance', $job['job_code']);

$durStmt = $pdo->prepare('SELECT TIMESTAMPDIFF(MINUTE, time_in, time_out) FROM attendance WHERE id = :id');
$durStmt->execute([':id' => $att['id']]);

json_success([
    'attendance_id'    => (int)$att['id'],
    'job_id'           => (int)$job['id'],
    'distance'         => $distance !== null ? round($distance) : null,
    'radius'           => $radius,
    'inside'           => $distance !== null ? $distance <= $radius : null,
    'duration_minutes' => (int)$durStmt->fetchColumn(),
], 'Timed out successfully.');
