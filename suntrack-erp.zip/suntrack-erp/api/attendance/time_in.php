<?php
/**
 * POST /api/attendance/time_in.php
 *
 * GPS Time In. Allowed only inside the job's geofence (job radius, falling
 * back to the 500 m default) and only on a job assigned to this technician.
 * Also writes the entry point to geofence_records so the location trail starts
 * at time-in.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['job_id', 'latitude', 'longitude']);

if (!is_numeric($input['latitude']) || !is_numeric($input['longitude'])) {
    json_error('Invalid coordinates.', 422);
}

$techId = (int)current_profile_id();
$lat    = (float)$input['latitude'];
$lng    = (float)$input['longitude'];

$job = tech_job_or_fail((int)$input['job_id']);

if (tech_stage_is_closed($job['stage'])) {
    json_error('This job is closed — you cannot time in.', 422);
}

if (tech_open_attendance((int)$job['id'], $techId)) {
    json_error('You are already timed in for this job. Please time out first.', 422);
}

$radius   = tech_geofence_radius($job);
$distance = tech_distance_to_site($job, $lat, $lng);

// GPS accuracy (metres, as reported by the phone). Indoors or on Wi-Fi-only
// location a phone may only know it is "somewhere within 800 m" — a reading
// that cannot prove the technician is inside a 500 m fence, or outside it.
// Optional, so an older cached copy of the app that does not send it still works.
$accuracy = isset($input['accuracy']) && is_numeric($input['accuracy']) ? (float)$input['accuracy'] : null;
if ($distance !== null && $accuracy !== null && $accuracy > $radius) {
    json_error(
        sprintf('Your GPS signal is too rough right now (±%d m, the site allows %d m). Step outside or turn on high-accuracy location, wait a few seconds, then try again.', round($accuracy), $radius),
        422,
        ['distance' => round($distance), 'radius' => $radius, 'inside' => false, 'low_accuracy' => true, 'accuracy' => round($accuracy)]
    );
}

// A job with no site coordinates used to mean "no geofence" — the distance
// check was skipped and the technician could time in from anywhere, which
// quietly defeated the whole feature. Under the geofence_strict setting
// (on by default) a job without coordinates is refused instead, and
// Management is told to plot the site.
if ($distance === null) {
    if (geofence_is_strict()) {
        json_error(
            'This job has no site coordinates, so your location cannot be verified. '
            . 'Please ask Management to set the site location before timing in.',
            422,
            ['distance' => null, 'radius' => $radius, 'inside' => false, 'missing_coordinates' => true]
        );
    }
} elseif ($distance > $radius) {
    json_error(
        sprintf('You are too far from the job site (%d m away — must be within %d m to time in).', round($distance), $radius),
        422,
        ['distance' => round($distance), 'radius' => $radius, 'inside' => false]
    );
}

// Compared with the previous stored reading before this one is written.
$jump = $distance !== null ? tech_gps_jump($techId, $lat, $lng, $accuracy) : null;

$pdo = db();
$pdo->prepare(
    'INSERT INTO attendance (technician_id, job_id, time_in, lat_in, lng_in, distance_in_m, geofence_status)
     VALUES (:t, :j, NOW(), :lat, :lng, :dist, :status)'
)->execute([
    ':status' => $distance === null ? null : 'INSIDE',
    ':t'    => $techId,
    ':j'    => $job['id'],
    ':lat'  => round($lat, 7),
    ':lng'  => round($lng, 7),
    ':dist' => $distance !== null ? round($distance, 2) : null,
]);
$attendanceId = (int)$pdo->lastInsertId();

// Start the location trail at the entry point (same table, no duplicate system).
if ($distance !== null) {
    tech_record_geofence((int)$job['id'], $techId, $lat, $lng, $distance, 'INSIDE', $accuracy, $jump ? 'IMPOSSIBLE_JUMP' : null);
    tech_report_gps_jump($job, $techId, $jump);
}

audit_log('TIME_IN', 'attendance', $job['job_code']);

json_success([
    'attendance_id' => $attendanceId,
    'job_id'        => (int)$job['id'],
    'distance'      => $distance !== null ? round($distance) : null,
    'radius'        => $radius,
    'inside'        => true,
    'time_in'       => date('Y-m-d H:i:s'),
], 'Timed in successfully.');
