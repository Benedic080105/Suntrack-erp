<?php
/**
 * GET /api/reports/export.php?type=<report>&search=&status=&date_from=&date_to=
 * Admin / manager / staff. CSV download of a Reports-tab report with the same
 * filters as the on-screen preview (includes/report_lib.php), without the
 * preview's row limit. Errors come back as JSON, so the page can show them.
 */
require_once __DIR__ . '/../../middleware/admin.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed.', 405);
}

const EXPORT_LIMIT = 10000;

$report = report_build(db(), (string)($_GET['type'] ?? ''), EXPORT_LIMIT);

audit_log('EXPORT', 'reports', $report['type']);

$filename = $report['type'] . '_' . date('Y-m-d_His') . '.csv';
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('X-Total-Rows: ' . $report['total']);
header('X-Exported-Rows: ' . count($report['rows']));

$out = fopen('php://output', 'w');
fwrite($out, "\xEF\xBB\xBF"); // UTF-8 BOM so Excel shows ñ and ₱ correctly
fputcsv($out, array_column($report['columns'], 'label'));
foreach ($report['rows'] as $row) {
    $line = [];
    foreach ($report['columns'] as $col) {
        $line[] = csv_safe_cell($row[$col['key']] ?? '');
    }
    fputcsv($out, $line);
}
fclose($out);
exit;
