<?php
/**
 * GET /api/reports/get_report.php?type=<report>&search=&status=&date_from=&date_to=
 * Admin / manager / staff. On-screen preview for the Reports tab: the first
 * PREVIEW_LIMIT matching rows plus the full match count. Report definitions
 * live in includes/report_lib.php (shared with api/reports/export.php).
 *
 * data: { type, label, columns: [{key,label,type}], rows: [...], total, shown, limit }
 */
require_once __DIR__ . '/../../middleware/admin.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed.', 405);
}

const PREVIEW_LIMIT = 200;

$report = report_build(db(), (string)($_GET['type'] ?? ''), PREVIEW_LIMIT);
$report['shown'] = count($report['rows']);
$report['limit'] = PREVIEW_LIMIT;

json_success($report, $report['total'] . ' matching record' . ($report['total'] === 1 ? '' : 's') . '.');
