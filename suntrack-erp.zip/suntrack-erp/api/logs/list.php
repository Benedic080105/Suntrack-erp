<?php
/**
 * Logs & Audit — READ-ONLY viewer endpoint for the Admin tab (table + bar
 * chart). Filters: search, module, role, date_from / date_to (YYYY-MM-DD,
 * inclusive). api/export/csv.php?type=logs accepts the same filters.
 */
require_once __DIR__ . '/../../middleware/admin.php';

$pdo = db();
[$pageLimit, $pageOffset] = list_page(200);
$where = [];
$params = [];

if ($clause = search_clause($_GET['search'] ?? '', search_columns('logs'), $params)) {
    $where[] = $clause;
}
if (!empty($_GET['module'])) {
    $where[] = 'al.module = :module';
    $params[':module'] = $_GET['module'];
}
// Team work by default; a search looks through everything (see audit_view_for_search).
$view = audit_view_for_search($_GET['role'] ?? 'team', $_GET['search'] ?? '');
audit_view_filter($view, $where, $params);
if (!empty($_GET['date_from']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['date_from'])) {
    $where[] = 'al.created_at >= :date_from';
    $params[':date_from'] = $_GET['date_from'];
}
if (!empty($_GET['date_to']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['date_to'])) {
    // Inclusive: everything before the start of the following day.
    $where[] = 'al.created_at < :date_to';
    $params[':date_to'] = date('Y-m-d', strtotime($_GET['date_to'] . ' +1 day'));
}
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$sql = "SELECT al.id, al.action, al.module, al.record_id, al.role_key, al.ip_address, al.created_at,
               u.full_name
        FROM audit_logs al
        LEFT JOIN users u ON u.id = al.user_id
        $whereSql
        ORDER BY al.created_at DESC, al.id DESC
        " . list_page_sql($pageLimit, $pageOffset);
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = list_page_finish($stmt->fetchAll(), $pageLimit, $pageOffset);

$total     = (int)$pdo->query("SELECT COUNT(*) FROM audit_logs")->fetchColumn();
$today     = (int)$pdo->query("SELECT COUNT(*) FROM audit_logs WHERE DATE(created_at) = CURDATE()")->fetchColumn();
$modules   = (int)$pdo->query("SELECT COUNT(DISTINCT module) FROM audit_logs")->fetchColumn();

// The chart follows the chosen view and the search, so searching a person
// charts that person's activity, and sign-ins no longer dwarf the real work.
$chartWhere = []; $chartParams = [];
if ($clause = search_clause($_GET['search'] ?? '', search_columns('logs'), $chartParams)) {
    $chartWhere[] = $clause;
}
audit_view_filter($view, $chartWhere, $chartParams);
$chartStmt = $pdo->prepare(
    'SELECT al.module AS label, COUNT(*) AS total FROM audit_logs al LEFT JOIN users u ON u.id = al.user_id'
    . ($chartWhere ? ' WHERE ' . implode(' AND ', $chartWhere) : '')
    . ' GROUP BY al.module ORDER BY total DESC LIMIT 10'
);
$chartStmt->execute($chartParams);
$byModule = $chartStmt->fetchAll();

json_success([
    'rows' => $rows,
    'stats' => [
        'total' => $total,
        'today' => $today,
        'modules' => $modules,
    ],
    'chart' => [
        'labels' => array_map(fn($r) => $r['label'], $byModule),
        'values' => array_map(fn($r) => (int)$r['total'], $byModule),
    ],
]);
