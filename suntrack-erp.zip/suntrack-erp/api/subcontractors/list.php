<?php
/**
 * GET /api/subcontractors/list.php — Admin (view) / Management.
 * Filters: search, status (PENDING | APPROVED | SUSPENDED | INACTIVE),
 * approved (0/1, older screens), limit / offset paging. Each row carries its
 * open / completed jobs, its job limit and whether it has a portal login.
 */
require_once __DIR__ . '/../../middleware/admin.php';

$pdo = db();
[$pageLimit, $pageOffset] = list_page(500);
$where = [];
$params = [];

if ($clause = search_clause($_GET['search'] ?? '', search_columns('subcontractors'), $params)) {
    $where[] = $clause;
}
$ready = sub_ready();
if ($ready && !empty($_GET['status']) && in_array($_GET['status'], SUB_STATUSES, true)) {
    $where[] = 's.status = :status';
    $params[':status'] = $_GET['status'];
}
if (isset($_GET['approved']) && $_GET['approved'] !== '') {
    $where[] = 's.approved = :approved';
    $params[':approved'] = (int)$_GET['approved'];
}
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$extra = $ready
    ? ", s.status, s.contact_person, s.specialties, s.contract_end, s.insurance_expiry, s.max_active_jobs,
         (s.user_id IS NOT NULL AND EXISTS (SELECT 1 FROM users u WHERE u.id = s.user_id AND u.status = 'ACTIVE')) AS has_login,
         (SELECT COUNT(*) FROM subcontractor_assignments a WHERE a.subcontractor_id = s.id AND a.status IN ('" . implode("','", SA_OPEN) . "')) AS open_jobs,
         (SELECT COUNT(*) FROM subcontractor_assignments a WHERE a.subcontractor_id = s.id AND a.status = 'COMPLETED') AS completed_jobs"
    : ", IF(s.approved = 1, 'APPROVED', 'PENDING') AS status";
$sql = "SELECT s.id, s.subcon_code, s.name, s.specialization, s.phone, s.email, s.area, s.approved, s.created_at $extra
        FROM subcontractors s
        $whereSql
        ORDER BY s.id DESC
        " . list_page_sql($pageLimit, $pageOffset);
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = list_page_finish($stmt->fetchAll(), $pageLimit, $pageOffset);

$counts = ['total' => (int)$pdo->query('SELECT COUNT(*) FROM subcontractors')->fetchColumn()];
if ($ready) {
    foreach ($pdo->query('SELECT status, COUNT(*) AS n FROM subcontractors GROUP BY status') as $r) {
        $counts[strtolower($r['status'])] = (int)$r['n'];
    }
}
foreach (['pending', 'approved', 'suspended', 'inactive'] as $k) {
    $counts[$k] = $counts[$k] ?? 0;
}

json_success(['rows' => $rows, 'stats' => $counts, 'can_manage' => sub_is_management()]);
