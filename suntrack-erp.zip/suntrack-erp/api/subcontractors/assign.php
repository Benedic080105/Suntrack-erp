<?php
/**
 * /api/subcontractors/assign.php — Management only.
 *
 * GET  ?job_id=N   the ranked subcontractors for that job (best first, with reasons)
 * POST             offer a job to a chosen subcontractor by hand.
 *   Body: job_id, subcontractor_id, scope, instructions, materials_note,
 *         contract_amount, expected_completion (YYYY-MM-DD), replace_technician
 * One open subcontractor assignment per job. The offer reaches the
 * subcontractor's phone and dashboard; they accept or decline.
 */
require_once __DIR__ . '/../../config/config.php';
require_management();
sub_require_schema();

$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $s = $pdo->prepare("SELECT j.*, c.city AS client_city, c.province AS client_province FROM jobs j JOIN clients c ON c.id = j.client_id WHERE j.id = :id");
    $s->execute([':id' => (int)($_GET['job_id'] ?? 0)]);
    $job = $s->fetch();
    if (!$job) {
        json_error('Job not found.', 404);
    }
    json_success(['candidates' => sub_rank_candidates($pdo, $job), 'capacity' => sub_team_capacity($pdo)]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
$input = json_input();
require_csrf($input);
require_fields($input, ['job_id', 'subcontractor_id', 'scope']);

$scope = trim((string)$input['scope']);
if (mb_strlen($scope) < 10 || mb_strlen($scope) > 5000) {
    json_error('Describe the job scope (10 to 5,000 characters).', 422);
}
$amount = $input['contract_amount'] ?? 0;
if (!is_numeric($amount) || (float)$amount < 0 || (float)$amount > 99999999) {
    json_error('Contract amount must be zero or more.', 422);
}
$expected = trim((string)($input['expected_completion'] ?? ''));
if ($expected !== '') {
    $d = DateTime::createFromFormat('!Y-m-d', $expected);
    if (!$d || $d->format('Y-m-d') !== $expected || $expected < date('Y-m-d')) {
        json_error('Expected completion must be a valid date, today or later.', 422);
    }
}

$pdo->beginTransaction();
try {
    $js = $pdo->prepare('SELECT j.*, cu.full_name AS client_name FROM jobs j JOIN clients c ON c.id = j.client_id JOIN users cu ON cu.id = c.user_id WHERE j.id = :id FOR UPDATE');
    $js->execute([':id' => (int)$input['job_id']]);
    $job = $js->fetch();
    if (!$job) {
        sub_fail('Job not found.', 404);
    }
    if (in_array($job['stage'], ['COMPLETED', 'CANCELLED'], true)) {
        sub_fail("{$job['job_code']} is closed and cannot be assigned.");
    }
    $sc = sub_get($pdo, (int)$input['subcontractor_id'], true);
    if (!$sc) {
        sub_fail('Sub-contractor not found.', 404);
    }
    if ($sc['status'] !== 'APPROVED') {
        sub_fail("{$sc['subcon_code']} is " . strtolower($sc['status']) . '. Only approved subcontractors can be given work.');
    }
    if ($sc['contract_end'] && $sc['contract_end'] < date('Y-m-d')) {
        sub_fail("{$sc['subcon_code']}'s contract ended on {$sc['contract_end']}.");
    }
    if ($sc['insurance_expiry'] && $sc['insurance_expiry'] < date('Y-m-d')) {
        sub_fail("{$sc['subcon_code']}'s insurance expired on {$sc['insurance_expiry']}.");
    }
    if ($open = sub_active_assignment_for_job($pdo, (int)$job['id'])) {
        sub_fail("{$job['job_code']} already has an open subcontractor assignment ({$open['assignment_code']}).", 409);
    }
    if ($job['technician_id']) {
        if (in_array($job['stage'], ['EN_ROUTE', 'ARRIVED', 'IN_PROGRESS', 'PAUSED'], true)) {
            sub_fail("{$job['job_code']}'s technician is already working on it.", 409);
        }
        if (empty($input['replace_technician'])) {
            sub_fail("{$job['job_code']} is assigned to an internal technician. Confirm that the subcontractor replaces them.", 409);
        }
        $oldTech = (int)$job['technician_id'];
        $pdo->prepare("UPDATE jobs SET technician_id = NULL, stage = 'SUBMITTED' WHERE id = :id")->execute([':id' => $job['id']]);
        $pdo->prepare('INSERT INTO job_status_history (job_id, from_stage, to_stage, changed_by, note) VALUES (:j, :f, "SUBMITTED", :u, :n)')
            ->execute([':j' => $job['id'], ':f' => $job['stage'], ':u' => current_user_id(), ':n' => "Technician replaced by subcontractor {$sc['subcon_code']}"]);
        $job['stage'] = 'SUBMITTED';
    }
    try {
        [$aid, $code] = sub_create_offer($pdo, $job, $sc, [
            'auto' => false, 'reason' => "Offered by hand to {$sc['subcon_code']}", 'scope' => $scope,
            'instructions' => mb_substr(trim((string)($input['instructions'] ?? '')), 0, 5000) ?: null,
            'materials_note' => mb_substr(trim((string)($input['materials_note'] ?? '')), 0, 5000) ?: null,
            'contract_amount' => round((float)$amount, 2), 'expected_completion' => $expected ?: null,
        ]);
    } catch (DomainException $e) {
        sub_fail($e->getMessage(), 409);
    }
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('subcontractors/assign failed: ' . $e->getMessage());
    json_error('Could not assign the job. Nothing was changed.', 500);
}

audit_log('ASSIGN', 'subcontractor_assignments', $code);
$hours = sub_auto_settings()['offer_hours'];
sub_notify_subcontractor((int)$sc['id'], "New job for you: {$job['job_code']} (" . strtolower($job['job_type']) . ')'
    . ($job['site_address'] ? " at {$job['site_address']}" : '') . ". Open SunTrack to accept within $hours hours.", $aid);
if (!empty($oldTech)) {
    $t = $pdo->prepare('SELECT user_id FROM technicians WHERE id = :id');
    $t->execute([':id' => $oldTech]);
    if ($uid = $t->fetchColumn()) {
        notify((int)$uid, 'JOB_STATUS', "Job {$job['job_code']} has been given to a subcontractor.", 'jobs', (int)$job['id']);
    }
}

json_success(['id' => $aid, 'assignment_code' => $code], "{$job['job_code']} offered to {$sc['name']} ($code). They have been notified.");
