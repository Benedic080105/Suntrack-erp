<?php
/**
 * POST /api/subcontractors/status.php — Management only.
 * Body: id, status (APPROVED | SUSPENDED | INACTIVE | PENDING), reason
 * (required for SUSPENDED / INACTIVE).
 * Only APPROVED subcontractors receive new work (manual or automatic) or act
 * in the portal. Open assignments are left for Management to cancel / reassign.
 */
require_once __DIR__ . '/../../config/config.php';
require_management();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['id', 'status']);
sub_require_schema();

$to = strtoupper(trim((string)$input['status']));
if (!in_array($to, SUB_STATUSES, true)) {
    json_error('Status must be Pending, Approved, Suspended or Inactive.', 422);
}
$reason = trim((string)($input['reason'] ?? ''));
if (in_array($to, ['SUSPENDED', 'INACTIVE'], true) && mb_strlen($reason) < 5) {
    json_error('Give a reason (at least 5 characters) for suspending or deactivating.', 422);
}
if (mb_strlen($reason) > 255) {
    json_error('Reason is too long (255 characters max).', 422);
}

$pdo = db();
$pdo->beginTransaction();
try {
    $sc = sub_get($pdo, (int)$input['id'], true);
    if (!$sc) {
        sub_fail('Sub-contractor not found.', 404);
    }
    if ($sc['status'] === $to) {
        sub_fail("{$sc['subcon_code']} is already " . strtolower($to) . '.', 409);
    }
    if ($to === 'APPROVED' && $sc['contract_end'] && $sc['contract_end'] < date('Y-m-d')) {
        sub_fail("The contract ended on {$sc['contract_end']}. Extend the contract end date before approving.");
    }
    $pdo->prepare('UPDATE subcontractors SET status = :s, approved = :a, status_reason = :r, status_changed_at = NOW(), status_changed_by = :u WHERE id = :id')
        ->execute([':s' => $to, ':a' => $to === 'APPROVED' ? 1 : 0, ':r' => $reason ?: null, ':u' => current_user_id(), ':id' => $sc['id']]);
    sub_event($pdo, null, (int)$sc['id'], 'STATUS', $sc['status'], $to, $reason ?: null);
    $open = $pdo->prepare("SELECT COUNT(*) FROM subcontractor_assignments WHERE subcontractor_id = :s AND status IN ('" . implode("','", SA_OPEN) . "')");
    $open->execute([':s' => $sc['id']]);
    $openCount = (int)$open->fetchColumn();
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('subcontractors/status failed: ' . $e->getMessage());
    json_error('Could not change the status. Nothing was changed.', 500);
}

audit_log('STATUS_' . $to, 'subcontractors', $sc['subcon_code']);
sub_notify_subcontractor((int)$sc['id'], 'Your SunTrack subcontractor status is now ' . strtolower($to) . ($reason ? ": $reason" : '.'));

$msg = "{$sc['subcon_code']} is now " . strtolower($to) . '.';
if ($openCount && $to !== 'APPROVED') {
    $msg .= " It still has $openCount open assignment" . ($openCount === 1 ? '' : 's') . ' — cancel and reassign them if needed.';
}
json_success(['status' => $to, 'open_assignments' => $openCount], $msg);
