<?php
/**
 * POST /api/subcontractors/account.php — Management only.
 * The subcontractor's portal login on the existing users table (role
 * "subcontractor", same login page and password rules). Without an active
 * login a subcontractor is never chosen automatically — offers must reach them.
 *   action=create   email, full_name, password
 *   action=disable  / enable
 */
require_once __DIR__ . '/../../config/config.php';
require_management();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['id', 'action']);
sub_require_schema();

$pdo = db();
$sc = sub_get($pdo, (int)$input['id']);
if (!$sc) {
    json_error('Sub-contractor not found.', 404);
}
$action = (string)$input['action'];

if ($action === 'create') {
    require_fields($input, ['email', 'full_name', 'password']);
    if ($sc['user_id']) {
        json_error("{$sc['subcon_code']} already has a portal login.", 409);
    }
    $email = trim((string)$input['email']);
    $name = trim((string)$input['full_name']);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        json_error('Please enter a valid email address.', 422);
    }
    if ($name === '' || mb_strlen($name) > 150) {
        json_error('Enter the name of the person who will sign in.', 422);
    }
    if (str_len((string)$input['password']) < PASSWORD_MIN_LENGTH) {
        json_error('Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters.', 422);
    }
    $roleId = $pdo->query("SELECT id FROM roles WHERE role_key = 'subcontractor'")->fetchColumn();
    $pdo->beginTransaction();
    try {
        $dupe = $pdo->prepare('SELECT 1 FROM users WHERE email = :e');
        $dupe->execute([':e' => $email]);
        if ($dupe->fetchColumn()) {
            sub_fail('That email is already used by another SunTrack account.', 409);
        }
        $pdo->prepare('INSERT INTO users (role_id, email, password_hash, full_name, phone, status) VALUES (:r, :e, :h, :n, :p, "ACTIVE")')
            ->execute([':r' => $roleId, ':e' => $email, ':h' => password_hash((string)$input['password'], PASSWORD_DEFAULT), ':n' => $name, ':p' => $sc['phone']]);
        $userId = (int)$pdo->lastInsertId();
        $link = $pdo->prepare('UPDATE subcontractors SET user_id = :u WHERE id = :id AND user_id IS NULL');
        $link->execute([':u' => $userId, ':id' => $sc['id']]);
        if ($link->rowCount() !== 1) {
            sub_fail("{$sc['subcon_code']} already has a portal login.", 409);
        }
        sub_event($pdo, null, (int)$sc['id'], 'LOGIN_CREATED', null, null, "Portal login created for $email");
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('subcontractors/account failed: ' . $e->getMessage());
        json_error('Could not create the login. Nothing was saved.', 500);
    }
    audit_log('CREATE_LOGIN', 'subcontractors', $sc['subcon_code']);
    json_success(['user_id' => $userId], "Portal login created. $name can sign in with $email and turn on phone notifications in the portal.");
}

if (in_array($action, ['disable', 'enable'], true)) {
    if (!$sc['user_id']) {
        json_error("{$sc['subcon_code']} has no portal login yet.", 422);
    }
    $status = $action === 'disable' ? 'INACTIVE' : 'ACTIVE';
    $pdo->prepare('UPDATE users SET status = :s WHERE id = :id')->execute([':s' => $status, ':id' => $sc['user_id']]);
    sub_event($pdo, null, (int)$sc['id'], $action === 'disable' ? 'LOGIN_DISABLED' : 'LOGIN_ENABLED', null, null, null);
    audit_log(strtoupper($action) . '_LOGIN', 'subcontractors', $sc['subcon_code']);
    json_success(['status' => $status], $action === 'disable' ? 'Portal login disabled.' : 'Portal login enabled.');
}

json_error('Unknown action.', 422);
