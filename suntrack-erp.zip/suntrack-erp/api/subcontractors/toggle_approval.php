<?php
/**
 * POST /api/subcontractors/toggle_approval.php — kept for older screens.
 * Body: id, approved (1 / 0) → APPROVED / PENDING (see status.php).
 */
require_once __DIR__ . '/../../config/config.php';
require_management(); // Admin role is view/export only; only Management (manager/staff) may mutate.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['id', 'approved']);
sub_require_schema();

$id = (int)$input['id'];
$to = !empty($input['approved']) ? 'APPROVED' : 'PENDING';
$pdo = db();
$sc = sub_get($pdo, $id);
if (!$sc) {
    json_error('Sub-contractor not found.', 404);
}
if ($to === 'APPROVED' && $sc['contract_end'] && $sc['contract_end'] < date('Y-m-d')) {
    json_error("The contract ended on {$sc['contract_end']}. Extend the contract end date before approving.", 422);
}
if ($sc['status'] !== $to) {
    $pdo->prepare('UPDATE subcontractors SET status = :s, approved = :a, status_changed_at = NOW(), status_changed_by = :u WHERE id = :id')
        ->execute([':s' => $to, ':a' => $to === 'APPROVED' ? 1 : 0, ':u' => current_user_id(), ':id' => $id]);
    sub_event($pdo, null, $id, 'STATUS', $sc['status'], $to, 'Approval toggled');
}
audit_log($to === 'APPROVED' ? 'APPROVE' : 'UNAPPROVE', 'subcontractors', $sc['subcon_code']);

json_success([], $to === 'APPROVED' ? 'Sub-contractor approved.' : 'Approval revoked.');
