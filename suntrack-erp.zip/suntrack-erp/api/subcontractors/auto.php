<?php
/**
 * /api/subcontractors/auto.php — automatic assignment control.
 *
 * GET   (Admin view / Management)   team capacity per technician, the
 *       settings, what is waiting for a subcontractor, and the latest
 *       automatic decisions. Also runs the sweep (expired offers move on).
 * POST  (Management only)
 *   action=save   mode (auto | suggest | off), tech_max_open_jobs (1–20),
 *                 capacity_threshold (10–100 %), offer_hours (1–168)
 *   action=run    run the sweep now; include_older=1 also covers unassigned
 *                 jobs created before automatic assignment was switched on
 */
require_once __DIR__ . '/../../middleware/admin.php';
sub_require_schema();

$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_management();
    $input = json_input();
    require_csrf($input);
    $action = (string)($input['action'] ?? '');
    if ($action === 'save') {
        $mode = (string)($input['mode'] ?? 'auto');
        if (!in_array($mode, ['auto', 'suggest', 'off'], true)) {
            json_error('Mode must be Automatic, Suggest only or Off.', 422);
        }
        $max = (int)($input['tech_max_open_jobs'] ?? 4);
        $thr = (int)($input['capacity_threshold'] ?? 85);
        $hrs = (int)($input['offer_hours'] ?? 24);
        if ($max < 1 || $max > 20 || $thr < 10 || $thr > 100 || $hrs < 1 || $hrs > 168) {
            json_error('Jobs per technician 1–20, capacity threshold 10–100 %, offer time 1–168 hours.', 422);
        }
        $was = sub_auto_settings()['mode'];
        setting_set('subcon_auto_mode', $mode);
        setting_set('tech_max_open_jobs', (string)$max);
        setting_set('subcon_capacity_threshold', (string)$thr);
        setting_set('subcon_offer_hours', (string)$hrs);
        if ($mode === 'auto' && $was !== 'auto') {
            // Switching on applies to new jobs from now — the backlog is not sent out.
            setting_set('subcon_auto_since', date('Y-m-d H:i:s'));
        }
        audit_log('SETTINGS', 'subcontractors', "auto=$mode");
        json_success([], 'Automatic assignment settings saved.');
    }
    if ($action === 'run') {
        $results = sub_auto_sweep($pdo, !empty($input['include_older']));
        $assigned = array_values(array_filter($results, fn($r) => $r['status'] === 'assigned'));
        $suggested = array_values(array_filter($results, fn($r) => $r['status'] === 'suggested'));
        $none = array_values(array_filter($results, fn($r) => $r['status'] === 'none'));
        $cap = sub_team_capacity($pdo);
        $msg = $assigned ? count($assigned) . ' job(s) offered to subcontractors.'
             : ($suggested ? count($suggested) . ' suggestion(s) ready.'
             : ($cap['near_full'] ? 'Nothing to assign.' : "Technicians still have room ({$cap['pct']}% of slots used) — nothing sent out."));
        if ($none) {
            $msg .= ' ' . count($none) . ' job(s) found no available subcontractor.';
        }
        json_success(['results' => $results], $msg);
    }
    json_error('Unknown action.', 422);
}

// GET: keep offers moving (expired ones go to the next subcontractor).
if (sub_is_management()) {
    sub_auto_sweep($pdo);
}
$cfg = sub_auto_settings();
$cap = sub_team_capacity($pdo);

$waiting = $pdo->query(
    "SELECT j.id, j.job_code, j.job_type, j.priority, j.site_address, j.created_at, cu.full_name AS client_name
     FROM jobs j JOIN clients c ON c.id = j.client_id JOIN users cu ON cu.id = c.user_id
     WHERE j.technician_id IS NULL AND j.stage IN ('SUBMITTED','ASSIGNED')
       AND NOT EXISTS (SELECT 1 FROM subcontractor_assignments a WHERE a.active_job_id = j.id)
     ORDER BY FIELD(j.priority,'URGENT','HIGH','NORMAL','LOW'), j.id DESC LIMIT 20"
)->fetchAll();

$log = $pdo->query(
    "SELECT e.action, e.to_status, e.note, e.created_at, a.id AS assignment_id, a.assignment_code, j.job_code, s.subcon_code, s.name AS subcontractor_name
     FROM subcontractor_events e
     JOIN subcontractor_assignments a ON a.id = e.assignment_id
     JOIN jobs j ON j.id = a.job_id JOIN subcontractors s ON s.id = e.subcontractor_id
     WHERE e.action = 'AUTO_ASSIGNED' OR (e.actor_role = 'system')
     ORDER BY e.id DESC LIMIT 15"
)->fetchAll();

$ready = $pdo->query(
    "SELECT COUNT(*) FROM subcontractors s JOIN users u ON u.id = s.user_id AND u.status = 'ACTIVE' WHERE s.status = 'APPROVED'"
)->fetchColumn();

json_success([
    'settings'  => $cfg,
    'capacity'  => $cap,
    'waiting'   => $waiting,
    'log'       => $log,
    'subcontractors_ready' => (int)$ready,
    'can_manage' => sub_is_management(),
]);
