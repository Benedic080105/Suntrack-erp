<?php
/**
 * GET /api/subcontractors/assignments.php — Admin (view) / Management.
 *   ?id=N   one assignment: job, scope, why it was chosen, the job's existing
 *           checklist, files, full history and the actions allowed now
 *   else    list; filters status (or "open"), subcontractor_id, search
 */
require_once __DIR__ . '/../../middleware/admin.php';
sub_require_schema();

$pdo = db();

if (!empty($_GET['id'])) {
    $a = sub_assignment($pdo, (int)$_GET['id']);
    if (!$a) {
        json_error('Assignment not found.', 404);
    }
    $names = $pdo->prepare('SELECT id, full_name FROM users WHERE id IN (?, ?, ?, ?)');
    $names->execute([(int)$a['assigned_by'], (int)$a['responded_by'], (int)$a['reviewed_by'], (int)$a['completed_by']]);
    $who = array_column($names->fetchAll(), 'full_name', 'id');
    foreach (['assigned_by', 'responded_by', 'reviewed_by', 'completed_by'] as $k) {
        $a[$k . '_name'] = $who[(int)$a[$k]] ?? null;
    }
    $a['status_label'] = SA_LABELS[$a['status']];
    $manage = sub_is_management();
    $actions = [];
    if ($manage) {
        if ($a['status'] === 'AWAITING_INSPECTION') {
            $actions = ['approve', 'revision'];
        }
        if (isset(SA_MOVES[$a['status']]['CANCELLED'])) {
            $actions[] = 'cancel';
        }
    }
    json_success([
        'assignment' => $a,
        'checklist'  => sub_checklist($pdo, $a, false),
        'files'      => sub_files($pdo, (int)$a['id']),
        'events'     => sub_events($pdo, (int)$a['id']),
        'can_manage' => $manage,
        'actions'    => $actions,
    ]);
}

[$pageLimit, $pageOffset] = list_page(500);
$where = [];
$params = [];
$status = $_GET['status'] ?? '';
if ($status === 'open') {
    $where[] = "a.status IN ('" . implode("','", SA_OPEN) . "')";
} elseif ($status !== '' && isset(SA_LABELS[$status])) {
    $where[] = 'a.status = :st';
    $params[':st'] = $status;
}
if (!empty($_GET['subcontractor_id'])) {
    $where[] = 'a.subcontractor_id = :sid';
    $params[':sid'] = (int)$_GET['subcontractor_id'];
}
if ($clause = search_clause($_GET['search'] ?? '', ['a.assignment_code', 'j.job_code', 'cu.full_name', 'c.client_code', 's.name', 's.subcon_code'], $params)) {
    $where[] = $clause;
}
$sql = sub_assignment_sql() . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
     . " ORDER BY FIELD(a.status, 'AWAITING_INSPECTION','AWAITING_ACCEPTANCE','REVISION_REQUIRED','IN_PROGRESS','SCHEDULED','ACCEPTED','APPROVED','DECLINED','COMPLETED','CANCELLED'), a.id DESC "
     . list_page_sql($pageLimit, $pageOffset);
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = list_page_finish($stmt->fetchAll(), $pageLimit, $pageOffset);
foreach ($rows as &$r) {
    $r['status_label'] = SA_LABELS[$r['status']];
    $r['overdue'] = $r['expected_completion'] && $r['expected_completion'] < date('Y-m-d')
        && in_array($r['status'], ['ACCEPTED', 'SCHEDULED', 'IN_PROGRESS', 'REVISION_REQUIRED'], true);
    unset($r['client_phone']);
}
unset($r);
json_success(['rows' => $rows, 'can_manage' => sub_is_management()]);
