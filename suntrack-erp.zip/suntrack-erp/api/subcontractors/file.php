<?php
/**
 * GET /api/subcontractors/file.php?id=N — stream one assignment file.
 * Admin / Management: any. Subcontractor: only its own assignments' files
 * (anything else is a 404). storage/ itself is never web-served.
 */
require_once __DIR__ . '/../../config/config.php';
require_role(['admin', 'manager', 'staff', 'subcontractor'], true);
sub_require_schema();

$pdo = db();
$s = $pdo->prepare('SELECT f.*, a.subcontractor_id FROM subcontractor_files f JOIN subcontractor_assignments a ON a.id = f.assignment_id WHERE f.id = :id');
$s->execute([':id' => (int)($_GET['id'] ?? 0)]);
$f = $s->fetch();
if (!$f) {
    json_error('File not found.', 404);
}
if (current_role() === 'subcontractor' && (int)$f['subcontractor_id'] !== (int)sub_portal_current()['id']) {
    json_error('File not found.', 404);
}
$path = storage_dir('subcontractor_files') . '/' . $f['file_name'];
if (!sub_file_name_ok($f['file_name']) || !is_file($path)) {
    json_error('File not found.', 404);
}
header('Content-Type: ' . $f['mime']);
header('Content-Length: ' . filesize($path));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=300');
header('Content-Disposition: ' . ($f['mime'] === 'application/pdf' ? 'attachment' : 'inline') . '; filename="' . str_replace('"', '', $f['original_name']) . '"');
header("Content-Security-Policy: default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox");
readfile($path);
