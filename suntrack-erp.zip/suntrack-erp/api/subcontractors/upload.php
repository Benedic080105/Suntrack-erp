<?php
/**
 * POST /api/subcontractors/upload.php (multipart) — Management only.
 * Attach a drawing, permit or instruction (photo or PDF) to an open assignment.
 * Fields: csrf_token, assignment_id, file.
 */
require_once __DIR__ . '/../../config/config.php';
require_management();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
if (empty($_POST) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    json_error('That file is too large (max 10 MB).', 413);
}
require_csrf($_POST);
require_fields($_POST, ['assignment_id']);
sub_require_schema();

$pdo = db();
$a = sub_assignment($pdo, (int)$_POST['assignment_id']);
if (!$a) {
    json_error('Assignment not found.', 404);
}
if (in_array($a['status'], ['COMPLETED', 'CANCELLED', 'DECLINED'], true)) {
    json_error('This assignment is closed — its files can no longer change.', 422);
}
$saved = sub_save_upload($pdo, $a, 'ASSIGNMENT_ATTACHMENT', $_FILES['file'] ?? []);
audit_log('ATTACH', 'subcontractor_assignments', $a['assignment_code']);
json_success($saved, 'Attachment added.');
