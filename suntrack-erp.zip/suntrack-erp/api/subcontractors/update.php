<?php
/**
 * POST /api/subcontractors/update.php — Management only. Edits profile fields
 * (incl. max_active_jobs). Status changes go through status.php; `approved`
 * from older screens is mapped to the status.
 */
require_once __DIR__ . '/../../config/config.php';
require_management(); // Admin role is view/export only; only Management (manager/staff) may mutate.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['id']);
sub_require_schema();

$id = (int)$input['id'];
$pdo = db();
$sc = sub_get($pdo, $id);
if (!$sc) {
    json_error('Sub-contractor not found.', 404);
}

$f = sub_profile_fields($input + ['__current_start' => $sc['contract_start'], '__current_end' => $sc['contract_end']], true);
if ($f) {
    $params = [':id' => $id];
    foreach ($f as $k => $v) {
        $params[":$k"] = $v;
    }
    $pdo->prepare('UPDATE subcontractors SET ' . implode(', ', array_map(fn($c) => "$c = :$c", array_keys($f))) . ' WHERE id = :id')->execute($params);
}
if (isset($input['approved']) && !isset($input['status'])) {
    $to = !empty($input['approved']) ? 'APPROVED' : 'PENDING';
    if ($to !== $sc['status']) {
        $pdo->prepare('UPDATE subcontractors SET status = :s, approved = :a, status_changed_at = NOW(), status_changed_by = :u WHERE id = :id')
            ->execute([':s' => $to, ':a' => $to === 'APPROVED' ? 1 : 0, ':u' => current_user_id(), ':id' => $id]);
        sub_event($pdo, null, $id, 'STATUS', $sc['status'], $to, 'Changed from the edit form');
    }
}

sub_event($pdo, null, $id, 'PROFILE_UPDATED', null, null, $f ? 'Changed: ' . implode(', ', array_keys($f)) : null);
audit_log('UPDATE', 'subcontractors', $sc['subcon_code']);

json_success([], 'Sub-contractor updated.');
