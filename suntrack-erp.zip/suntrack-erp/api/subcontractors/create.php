<?php
/**
 * POST /api/subcontractors/create.php — Management only.
 * Registers a subcontractor company or independent contractor. It starts as
 * PENDING approval; approving is a separate, recorded action (status.php).
 */
require_once __DIR__ . '/../../config/config.php';
require_management(); // Admin role is view/export only; only Management (manager/staff) may mutate.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
sub_require_schema();

$f = sub_profile_fields($input, false);
$pdo = db();
$cols = array_keys($f);
$stmt = $pdo->prepare(
    'INSERT INTO subcontractors (subcon_code, ' . implode(', ', $cols) . ", approved, status, status_changed_at, status_changed_by)
     VALUES (:code, " . implode(', ', array_map(fn($c) => ":$c", $cols)) . ", 0, 'PENDING', NOW(), :by)"
);
// Collision-safe sequential code (see with_unique_code() in helpers.php).
$code = with_unique_code('subcontractors', 'subcon_code', 'SC-', function (string $code) use ($stmt, $f) {
    $params = [':code' => $code, ':by' => current_user_id()];
    foreach ($f as $k => $v) {
        $params[":$k"] = $v;
    }
    $stmt->execute($params);
    return $code;
}, pad: 2);
$id = (int)$pdo->lastInsertId();

sub_event($pdo, null, $id, 'REGISTERED', null, 'PENDING', 'Registered by Management');
audit_log('CREATE', 'subcontractors', $code);

json_success(['id' => $id, 'subcon_code' => $code], "Subcontractor $code registered. Approve it and create its portal login before it can receive jobs.");
