<?php
/**
 * POST /api/subcontractors/assignment_action.php — Management only.
 * Body: assignment_id, action, note
 *   approve    AWAITING_INSPECTION → APPROVED → COMPLETED (the job is completed)
 *   revision   AWAITING_INSPECTION → REVISION_REQUIRED (note = what to fix, required)
 *   cancel     any open status → CANCELLED (note required); the job goes back
 *              to Management and is offered again automatically if the
 *              technicians are still near full
 * Completed / cancelled / declined assignments are locked.
 */
require_once __DIR__ . '/../../config/config.php';
require_management();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['assignment_id', 'action']);
sub_require_schema();

$action = (string)$input['action'];
$note = trim((string)($input['note'] ?? ''));
if (mb_strlen($note) > 500) {
    json_error('Note is too long (500 characters max).', 422);
}
if (in_array($action, ['revision', 'cancel'], true) && mb_strlen($note) < 5) {
    json_error('Give a reason (at least 5 characters).', 422);
}

$pdo = db();
$pdo->beginTransaction();
try {
    $a = sub_lock_assignment($pdo, (int)$input['assignment_id']);
    $jobId = (int)$a['job_id'];
    switch ($action) {
        case 'approve':
            $now = date('Y-m-d H:i:s');
            $a = sub_move($pdo, $a, 'APPROVED', 'mgmt', $note ?: 'Inspection passed',
                ['reviewed_at' => $now, 'reviewed_by' => current_user_id(), 'review_note' => $note ?: null]);
            $a = sub_move($pdo, $a, 'COMPLETED', 'mgmt', 'Final completion approved', ['completed_at' => $now, 'completed_by' => current_user_id()]);
            $message = "{$a['job_code']} passed inspection and is now COMPLETED.";
            $toSub = "Your work on {$a['job_code']} passed inspection and is complete. Thank you!";
            break;
        case 'revision':
            $a = sub_move($pdo, $a, 'REVISION_REQUIRED', 'mgmt', $note,
                ['reviewed_at' => date('Y-m-d H:i:s'), 'reviewed_by' => current_user_id(), 'review_note' => $note,
                 'revision_count' => ['raw' => 'revision_count + 1']]);
            $message = "Revision requested on {$a['assignment_code']}. The subcontractor has been told why.";
            $toSub = "Revision required on {$a['job_code']}: $note";
            break;
        case 'cancel':
            $a = sub_move($pdo, $a, 'CANCELLED', 'mgmt', $note, ['cancelled_reason' => $note]);
            $message = "{$a['assignment_code']} cancelled. {$a['job_code']} is back with Management.";
            $toSub = "Assignment {$a['assignment_code']} ({$a['job_code']}) was cancelled: $note";
            break;
        default:
            sub_fail('Unknown action.');
    }
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('subcontractors/assignment_action failed: ' . $e->getMessage());
    json_error('Could not save that. Nothing was changed.', 500);
}

audit_log(strtoupper($action), 'subcontractor_assignments', $a['assignment_code']);
sub_notify_subcontractor((int)$a['subcontractor_id'], $toSub, (int)$a['id']);
if ($action === 'approve') {
    // As when a technician completes a job: the linked request and the client.
    sr_notify_job_sync($GLOBALS['__sub_sr_changed'] ?? [], $_SESSION['full_name'] ?? 'SunTrack');
    $cu = $pdo->prepare('SELECT c.user_id FROM jobs j JOIN clients c ON c.id = j.client_id WHERE j.id = :j');
    $cu->execute([':j' => $jobId]);
    if ($clientUser = $cu->fetchColumn()) {
        notify((int)$clientUser, 'JOB_STATUS', "Job {$a['job_code']}: Your job has been completed.", 'jobs', $jobId);
    }
}
if ($action === 'cancel') {
    $r = sub_auto_sweep($pdo, false, [$jobId]);
    foreach ($r as $x) {
        if ($x['status'] === 'assigned') {
            $message .= " It was offered automatically to {$x['subcontractor']['name']}.";
        }
    }
}
json_success(['status' => $a['status'], 'status_label' => SA_LABELS[$a['status']]], $message);
