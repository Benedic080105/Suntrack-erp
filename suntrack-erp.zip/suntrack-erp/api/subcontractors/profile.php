<?php
/**
 * GET /api/subcontractors/profile.php?id=N — Admin (view) / Management.
 * Details, portal login, workload (open / limit), assigned jobs, completion
 * history (on-time rate), quality issues (revisions, declines, cancellations)
 * and the status / profile history.
 */
require_once __DIR__ . '/../../middleware/admin.php';
sub_require_schema();

$pdo = db();
$sc = sub_get($pdo, (int)($_GET['id'] ?? 0));
if (!$sc) {
    json_error('Sub-contractor not found.', 404);
}
$login = null;
if ($sc['user_id']) {
    $u = $pdo->prepare('SELECT email, full_name, status, last_login,
                               EXISTS (SELECT 1 FROM push_subscriptions p WHERE p.user_id = users.id) AS phone_alerts
                        FROM users WHERE id = :id');
    try {
        $u->execute([':id' => $sc['user_id']]);
        $login = $u->fetch() ?: null;
    } catch (PDOException $e) {
        $u = $pdo->prepare('SELECT email, full_name, status, last_login, 0 AS phone_alerts FROM users WHERE id = :id');
        $u->execute([':id' => $sc['user_id']]);
        $login = $u->fetch() ?: null;
    }
}
$by = null;
if ($sc['status_changed_by']) {
    $u = $pdo->prepare('SELECT full_name FROM users WHERE id = :id');
    $u->execute([':id' => $sc['status_changed_by']]);
    $by = $u->fetchColumn() ?: null;
}

$as = $pdo->prepare(sub_assignment_sql() . ' WHERE a.subcontractor_id = :s ORDER BY a.id DESC LIMIT 200');
$as->execute([':s' => $sc['id']]);
$assignments = array_map(fn($r) => [
    'id' => (int)$r['id'], 'assignment_code' => $r['assignment_code'], 'job_code' => $r['job_code'], 'job_type' => $r['job_type'],
    'client_name' => $r['client_name'], 'status' => $r['status'], 'status_label' => SA_LABELS[$r['status']],
    'auto_assigned' => (bool)$r['auto_assigned'], 'contract_amount' => (float)$r['contract_amount'],
    'expected_completion' => $r['expected_completion'], 'assigned_at' => $r['assigned_at'], 'completed_at' => $r['completed_at'],
    'revision_count' => (int)$r['revision_count'],
    'overdue' => $r['expected_completion'] && $r['expected_completion'] < date('Y-m-d') && in_array($r['status'], ['ACCEPTED', 'SCHEDULED', 'IN_PROGRESS', 'REVISION_REQUIRED'], true),
], $as->fetchAll());
$completed = array_values(array_filter($assignments, fn($r) => $r['status'] === 'COMPLETED'));
$onTime = count(array_filter($completed, fn($r) => !$r['expected_completion'] || substr((string)$r['completed_at'], 0, 10) <= $r['expected_completion']));
$open = count(array_filter($assignments, fn($r) => in_array($r['status'], SA_OPEN, true)));

$q = $pdo->prepare(
    "SELECT e.to_status, e.note, e.created_at, j.job_code
     FROM subcontractor_events e JOIN subcontractor_assignments a ON a.id = e.assignment_id JOIN jobs j ON j.id = a.job_id
     WHERE e.subcontractor_id = :s AND e.action = 'STATUS' AND e.to_status IN ('REVISION_REQUIRED','DECLINED','CANCELLED')
     ORDER BY e.id DESC LIMIT 50"
);
$q->execute([':s' => $sc['id']]);
$h = $pdo->prepare(
    "SELECT e.action, e.from_status, e.to_status, e.note, e.created_at, u.full_name AS by_name
     FROM subcontractor_events e LEFT JOIN users u ON u.id = e.actor_user_id
     WHERE e.subcontractor_id = :s AND e.assignment_id IS NULL ORDER BY e.id DESC LIMIT 30"
);
$h->execute([':s' => $sc['id']]);

$sc['status_changed_by_name'] = $by;
unset($sc['user_id']);
json_success([
    'subcontractor' => $sc,
    'login'         => $login,
    'assignments'   => $assignments,
    'stats'         => [
        'open' => $open, 'limit' => (int)$sc['max_active_jobs'], 'completed' => count($completed),
        'on_time_pct' => $completed ? (int)round($onTime * 100 / count($completed)) : null,
        'revisions' => array_sum(array_column($assignments, 'revision_count')),
        'declined' => count(array_filter($assignments, fn($r) => $r['status'] === 'DECLINED')),
        'auto_assigned' => count(array_filter($assignments, fn($r) => $r['auto_assigned'])),
    ],
    'quality_issues' => $q->fetchAll(),
    'history'       => $h->fetchAll(),
    'can_manage'    => sub_is_management(),
]);
