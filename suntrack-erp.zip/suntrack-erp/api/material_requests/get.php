<?php
/**
 * GET /api/material_requests/get.php?id=N   (or ?code=MR-2026-0001)
 *
 * One client order with its lines, the items currently scanned out for it,
 * and its movement history. Read-only; Warehouse, Management and Admin.
 */
require_once __DIR__ . '/../../middleware/warehouse.php';

mr_require_schema();
$pdo = db();
$id = (int)($_GET['id'] ?? 0);

if (!$id && !empty($_GET['code'])) {
    $stmt = $pdo->prepare('SELECT id FROM material_requests WHERE request_code = :c');
    $stmt->execute([':c' => trim((string)$_GET['code'])]);
    $id = (int)$stmt->fetchColumn();
}
if (!$id) {
    json_error('Material request not found.', 404);
}

$detail = mr_detail($pdo, $id);
if (!$detail) {
    json_error('Material request not found.', 404);
}

json_success($detail);
