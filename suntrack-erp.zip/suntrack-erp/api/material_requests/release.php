<?php
/**
 * POST /api/material_requests/release.php
 *
 * Hand a READY order over (to the technician, driver or client). Records who
 * released it, who took it and when — the sign-off that closes the order.
 * Stock was already deducted when each item was scanned, so this moves no
 * stock; it only closes the record.
 *
 * Body: request_id, released_to (optional name of the person receiving it)
 */
require_once __DIR__ . '/../../config/config.php';
require_warehouse_write();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['request_id']);

$requestId  = (int)$input['request_id'];
$releasedTo = trim((string)($input['released_to'] ?? ''));
if (str_len($releasedTo) > 150) {
    json_error('The receiver name is too long.', 422);
}

mr_require_schema();
$pdo = db();
$pdo->beginTransaction();
$request = mr_lock($pdo, $requestId);

if ($request['status'] !== 'READY') {
    $pdo->rollBack();
    json_error("Only a READY order can be released. {$request['request_code']} is {$request['status']}.", 409);
}

$pdo->prepare(
    "UPDATE material_requests
     SET status = 'RELEASED', released_at = NOW(), released_by = :u, released_to = :to
     WHERE id = :id"
)->execute([':u' => current_user_id(), ':to' => $releasedTo !== '' ? $releasedTo : null, ':id' => $requestId]);
// Bill the client for exactly what left the warehouse on this request.
$invoice = mr_create_invoice($pdo, $request);
$pdo->commit();

audit_log('RELEASE', 'material_requests', $request['request_code']);
$peso = '₱' . number_format($invoice[2] ?? 0, 2);
mr_notify_management(
    "Client order {$request['request_code']} was released by the warehouse" . ($releasedTo !== '' ? " to {$releasedTo}" : '') . '.'
        . ($invoice ? " Invoice {$invoice[1]} ({$peso}) was created for the materials." : ''),
    $request,
    true
);
if ($invoice) {
    audit_log('CREATE', 'billing', $invoice[1]);
    $cu = $pdo->prepare('SELECT user_id FROM clients WHERE id = :c');
    $cu->execute([':c' => $request['client_id']]);
    if ($clientUser = (int)$cu->fetchColumn()) {
        notify($clientUser, 'INVOICE', "Invoice {$invoice[1]} for {$peso} was issued for the materials released for your installation ({$request['request_code']}).", 'invoices', $invoice[0]);
    }
}

json_success(
    ['detail' => mr_detail($pdo, $requestId), 'invoice_code' => $invoice[1] ?? null],
    "{$request['request_code']} released." . ($invoice ? " Invoice {$invoice[1]} ({$peso}) created." : '')
);
