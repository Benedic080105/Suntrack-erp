<?php
/**
 * POST /api/material_requests/cancel.php
 *
 * Management withdraws an order. Allowed only while nothing is scanned out
 * for it: stock already set aside must be returned first (Warehouse
 * "remove item"), otherwise cancelling would strand those units with no order
 * and no job pointing at them.
 *
 * Body: request_id
 */
require_once __DIR__ . '/../../config/config.php';
require_management();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['request_id']);

$requestId = (int)$input['request_id'];

mr_require_schema();
$pdo = db();
$pdo->beginTransaction();
$request = mr_lock($pdo, $requestId);

if (!in_array($request['status'], MR_OPEN_STATUSES, true)) {
    $pdo->rollBack();
    json_error("{$request['request_code']} is already {$request['status']}.", 409);
}

$stmt = $pdo->prepare('SELECT COALESCE(SUM(qty_prepared), 0) FROM material_request_items WHERE request_id = :id');
$stmt->execute([':id' => $requestId]);
if ((int)$stmt->fetchColumn() > 0) {
    $pdo->rollBack();
    json_error("The warehouse has already prepared items for {$request['request_code']}. Ask them to return those items to stock first.", 409);
}

$pdo->prepare("UPDATE material_requests SET status = 'CANCELLED', ready_at = NULL WHERE id = :id")
    ->execute([':id' => $requestId]);
$pdo->commit();

audit_log('CANCEL', 'material_requests', $request['request_code']);
mr_notify_warehouse("Client order {$request['request_code']} was cancelled by Management. No need to prepare it.", $requestId);

json_success([], "{$request['request_code']} cancelled.");
