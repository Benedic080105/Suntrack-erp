<?php
/**
 * POST /api/material_requests/create.php
 *
 * Management tells the Warehouse what a client needs. Every active warehouse
 * user is notified, and the order appears in their Client Orders tab.
 *
 * Body:
 *   client_id                    required
 *   project_id, job_id           optional; must belong to the same client
 *   panels, inverters, batteries at least one must be > 0
 *   needed_by                    optional YYYY-MM-DD
 *   notes                        optional, e.g. preferred brand
 */
require_once __DIR__ . '/../../config/config.php';
require_management(); // Admin role is view/export only; only Management (manager/staff) may mutate.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['client_id']);

mr_require_schema();
$pdo = db();
$clientId = (int)$input['client_id'];

$stmt = $pdo->prepare('SELECT c.id, c.client_code, u.full_name FROM clients c JOIN users u ON u.id = c.user_id WHERE c.id = :id');
$stmt->execute([':id' => $clientId]);
$client = $stmt->fetch();
if (!$client) {
    json_error('Selected client was not found.', 422);
}

$lines = mr_parse_quantities($input);
if (!$lines) {
    json_error('Enter how many panels, inverters or batteries the client needs.', 422);
}

// A project or job from a different client would send the stock to the wrong
// address and file it under the wrong customer, so both are checked here.
$projectId = !empty($input['project_id']) ? (int)$input['project_id'] : null;
if ($projectId) {
    $stmt = $pdo->prepare('SELECT client_id FROM projects WHERE id = :id');
    $stmt->execute([':id' => $projectId]);
    $owner = $stmt->fetchColumn();
    if ($owner === false) {
        json_error('Selected project was not found.', 422);
    }
    if ((int)$owner !== $clientId) {
        json_error('That project belongs to a different client.', 422);
    }
}

$jobId = !empty($input['job_id']) ? (int)$input['job_id'] : null;
if ($jobId) {
    $stmt = $pdo->prepare('SELECT client_id FROM jobs WHERE id = :id');
    $stmt->execute([':id' => $jobId]);
    $owner = $stmt->fetchColumn();
    if ($owner === false) {
        json_error('Selected job was not found.', 422);
    }
    if ((int)$owner !== $clientId) {
        json_error('That job belongs to a different client.', 422);
    }
}

$neededBy = mr_parse_date($input['needed_by'] ?? null);
$notes = trim((string)($input['notes'] ?? ''));

$pdo->beginTransaction();
try {
    [$requestId, $code] = mr_create($pdo, $clientId, $lines, $projectId, $jobId, $neededBy, $notes);
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    json_error('Failed to create the material request.', 500);
}

audit_log('CREATE', 'material_requests', $code);
mr_notify_warehouse(
    "New client order {$code} for {$client['full_name']} ({$client['client_code']}): " . mr_lines_summary($lines)
        . ($neededBy ? ", needed by {$neededBy}" : '') . '.',
    $requestId
);

json_success(['id' => $requestId, 'request_code' => $code], 'Material request sent to the warehouse.');
