<?php
/**
 * POST /api/material_requests/pick.php
 *
 * Scan an item out of stock and into a client order. This is the warehouse's
 * "prepare order" action: one scan = one unit by default.
 *
 * Body:
 *   request_id               required
 *   code  OR  inventory_id   the scanned SKU / QR value, or the item id
 *   quantity                 optional, default 1
 *
 * Rejected when the item's category is not on the order, when that line is
 * already filled, or when there is not enough stock. The stock deduction, the
 * movement row and the order count commit together or not at all.
 */
require_once __DIR__ . '/../../config/config.php';
require_warehouse_write(); // Admin role is view/export only; only Warehouse/Management may mutate stock.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['request_id']);

$requestId   = (int)$input['request_id'];
$inventoryId = !empty($input['inventory_id']) ? (int)$input['inventory_id'] : null;
$code        = trim((string)($input['code'] ?? ''));
$qty         = isset($input['quantity']) && $input['quantity'] !== '' ? (int)$input['quantity'] : 1;

if (!$inventoryId && $code === '') {
    json_error('Scan an item or choose one to add.', 422);
}
if ($qty <= 0) {
    json_error('Quantity must be greater than zero.', 422);
}

mr_require_schema();
inv_require_qr_schema();
$pdo = db();
$pdo->beginTransaction();
try {
    $request = mr_lock($pdo, $requestId);

    if ($request['status'] === 'READY') {
        $pdo->rollBack();
        json_error("{$request['request_code']} is already complete. Release it, or remove an item first.", 409);
    }
    if (!in_array($request['status'], ['PENDING', 'PREPARING'], true)) {
        $pdo->rollBack();
        json_error("{$request['request_code']} is {$request['status']} and can no longer be changed.", 409);
    }

    // A unit label picks that exact unit; a SKU / product QR picks by quantity.
    $unit = null;
    if ($inventoryId) {
        $item = mr_lock_inventory($pdo, $inventoryId, null);
    } else {
        $hit = inv_resolve_code($pdo, $code, true);
        if (!$hit) {
            inv_fail("No stock item matches code {$code}.", 404);
        }
        [$item, $unit] = [$hit['item'], $hit['unit']];
    }
    if (($item['tracking_mode'] ?? 'PRODUCT') === 'SERIAL') {
        if (!$unit) {
            inv_fail("{$item['item_name']} is tracked by unit — scan the unit's own label (UNIT-…) instead of the product code.");
        }
        if ($unit['status'] !== 'IN_STOCK') {
            inv_fail("{$unit['unit_code']} (S/N {$unit['serial_number']}) is " . strtolower(str_replace('_', ' ', $unit['status'])) . ' and cannot be picked.', 409);
        }
        if ($qty !== 1) {
            inv_fail('Scan each unit separately — one unit per scan.');
        }
    }

    $lineStmt = $pdo->prepare(
        'SELECT mri.id, mri.qty_required, mri.qty_prepared, ic.category_name
         FROM material_request_items mri
         JOIN inventory_categories ic ON ic.id = mri.category_id
         WHERE mri.request_id = :r AND mri.category_id = :c
         FOR UPDATE'
    );
    $lineStmt->execute([':r' => $requestId, ':c' => $item['category_id']]);
    $line = $lineStmt->fetch();

    if (!$line) {
        $pdo->rollBack();
        json_error("{$item['item_name']} is not needed for {$request['request_code']}.", 422);
    }

    $remaining = (int)$line['qty_required'] - (int)$line['qty_prepared'];
    if ($remaining <= 0) {
        $pdo->rollBack();
        json_error("All {$line['qty_required']} {$line['category_name']} for {$request['request_code']} are already prepared.", 422);
    }
    if ($qty > $remaining) {
        $pdo->rollBack();
        json_error("Only {$remaining} more {$line['category_name']} needed for {$request['request_code']}.", 422);
    }
    if ((int)$item['quantity'] < $qty) {
        $pdo->rollBack();
        json_error("Insufficient stock. Only {$item['quantity']} units of {$item['item_name']} available.", 422);
    }

    $newQty = (int)$item['quantity'] - $qty;
    $pdo->prepare('UPDATE inventory SET quantity = :q, status = :s WHERE id = :id')
        ->execute([':q' => $newQty, ':s' => inventory_status($newQty, $item['status']), ':id' => $item['id']]);

    $techId = null;
    if ($request['job_id']) {
        $t = $pdo->prepare('SELECT technician_id FROM jobs WHERE id = :id');
        $t->execute([':id' => $request['job_id']]);
        $techId = $t->fetchColumn() ?: null;
    }

    if ($unit) {
        $pdo->prepare("UPDATE inventory_units SET status = 'ISSUED', job_id = :job, material_request_id = :mr WHERE id = :id AND status = 'IN_STOCK'")
            ->execute([':job' => $request['job_id'], ':mr' => $requestId, ':id' => $unit['id']]);
    }

    inv_add_movement($pdo, [
        'inventory_id' => $item['id'], 'type' => 'ISSUE', 'quantity' => $qty,
        'job_id' => $request['job_id'], 'material_request_id' => $requestId, 'technician_id' => $techId,
        'unit_id' => $unit['id'] ?? null, 'reference' => 'Prepared for ' . $request['request_code'],
    ]);

    $pdo->prepare('UPDATE material_request_items SET qty_prepared = qty_prepared + :q WHERE id = :id')
        ->execute([':q' => $qty, ':id' => $line['id']]);

    $status = mr_recalc($pdo, $request);
    $pdo->commit();
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    json_error('Failed to add the item to the order.', 500);
}

audit_log('PICK', 'material_requests', $request['request_code']);

if ($status === 'READY') {
    mr_notify_management("Client order {$request['request_code']} is prepared and ready to go.", $request);
}

$remainingAfter = $remaining - $qty;
json_success([
    'status'        => $status,
    'item_name'     => $item['item_name'],
    'sku'           => $item['sku'],
    'category_name' => $line['category_name'],
    'new_quantity'  => $newQty,
    'line_remaining'=> $remainingAfter,
    'detail'        => mr_detail($pdo, $requestId),
], $status === 'READY'
    ? "{$item['item_name']} added. {$request['request_code']} is complete and ready to release."
    : ($remainingAfter > 0
        ? "{$qty} x {$item['item_name']} added. {$remainingAfter} more {$line['category_name']} needed."
        : "{$qty} x {$item['item_name']} added. {$line['category_name']} complete for {$request['request_code']}."));
