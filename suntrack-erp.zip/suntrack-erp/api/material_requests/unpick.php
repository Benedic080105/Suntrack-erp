<?php
/**
 * POST /api/material_requests/unpick.php
 *
 * Take an item back off a client order and return it to stock — the undo for
 * a wrong scan. Recorded as a RETURN movement tagged with the order, so the
 * history shows both the mistake and its correction.
 *
 * Body: request_id, inventory_id, quantity (default 1)
 *
 * Only what is actually on the order can come back: the net quantity of that
 * item scanned into it (ISSUE minus RETURN) is checked under the order lock.
 */
require_once __DIR__ . '/../../config/config.php';
require_warehouse_write();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['request_id', 'inventory_id']);

$requestId   = (int)$input['request_id'];
$inventoryId = (int)$input['inventory_id'];
$qty         = isset($input['quantity']) && $input['quantity'] !== '' ? (int)$input['quantity'] : 1;

if ($qty <= 0) {
    json_error('Quantity must be greater than zero.', 422);
}

mr_require_schema();
inv_require_qr_schema();
$pdo = db();
$pdo->beginTransaction();
try {
    $request = mr_lock($pdo, $requestId);
    if (!in_array($request['status'], MR_OPEN_STATUSES, true)) {
        $pdo->rollBack();
        json_error("{$request['request_code']} is {$request['status']} and can no longer be changed.", 409);
    }

    $item = mr_lock_inventory($pdo, $inventoryId, null);

    $net = $pdo->prepare(
        "SELECT COALESCE(SUM(CASE movement_type WHEN 'ISSUE' THEN quantity WHEN 'RETURN' THEN -quantity ELSE 0 END), 0)
         FROM stock_movements WHERE material_request_id = :r AND inventory_id = :i"
    );
    $net->execute([':r' => $requestId, ':i' => $inventoryId]);
    $onOrder = (int)$net->fetchColumn();

    if ($onOrder < $qty) {
        $pdo->rollBack();
        json_error("Only {$onOrder} x {$item['item_name']} " . ($onOrder === 1 ? 'is' : 'are') . " on {$request['request_code']}.", 422);
    }

    $lineStmt = $pdo->prepare(
        'SELECT id, qty_prepared FROM material_request_items WHERE request_id = :r AND category_id = :c FOR UPDATE'
    );
    $lineStmt->execute([':r' => $requestId, ':c' => $item['category_id']]);
    $line = $lineStmt->fetch();

    $newQty = (int)$item['quantity'] + $qty;
    $pdo->prepare('UPDATE inventory SET quantity = :q, status = :s WHERE id = :id')
        ->execute([':q' => $newQty, ':s' => inventory_status($newQty, $item['status']), ':id' => $item['id']]);

    $ref = 'Removed from ' . $request['request_code'];
    if (($item['tracking_mode'] ?? 'PRODUCT') === 'SERIAL') {
        // The named unit, or else the most recently picked ones — never a
        // unit that is not on this order. They never left the warehouse, so
        // they go straight back IN_STOCK.
        if (!empty($input['unit_code'])) {
            $u = $pdo->prepare(
                "SELECT * FROM inventory_units WHERE inventory_id = :i AND material_request_id = :r AND status = 'ISSUED'
                 AND (unit_code = :c1 OR serial_number = :c2) FOR UPDATE"
            );
            $u->execute([':i' => $item['id'], ':r' => $requestId, ':c1' => trim((string)$input['unit_code']), ':c2' => trim((string)$input['unit_code'])]);
        } else {
            $u = $pdo->prepare(
                "SELECT * FROM inventory_units WHERE inventory_id = :i AND material_request_id = :r AND status = 'ISSUED'
                 ORDER BY updated_at DESC, id DESC LIMIT " . (int)$qty . ' FOR UPDATE'
            );
            $u->execute([':i' => $item['id'], ':r' => $requestId]);
        }
        $units = $u->fetchAll();
        if (count($units) < $qty) {
            inv_fail('That unit is not on ' . $request['request_code'] . '.', 422);
        }
        $back = $pdo->prepare("UPDATE inventory_units SET status = 'IN_STOCK', job_id = NULL, material_request_id = NULL WHERE id = :id");
        foreach ($units as $unit) {
            $back->execute([':id' => $unit['id']]);
            $issue = inv_unit_last_issue($pdo, (int)$unit['id']);
            inv_add_movement($pdo, [
                'inventory_id' => $item['id'], 'type' => 'RETURN', 'quantity' => 1, 'job_id' => $request['job_id'],
                'material_request_id' => $requestId, 'unit_id' => $unit['id'], 'condition' => 'GOOD',
                'original_movement_id' => $issue['id'] ?? null, 'reference' => $ref,
            ]);
        }
    } else {
        inv_add_movement($pdo, [
            'inventory_id' => $item['id'], 'type' => 'RETURN', 'quantity' => $qty, 'job_id' => $request['job_id'],
            'material_request_id' => $requestId, 'condition' => 'GOOD', 'reference' => $ref,
        ]);
    }

    if ($line) {
        // GREATEST guards the unsigned column even if counts ever drifted.
        $pdo->prepare('UPDATE material_request_items SET qty_prepared = GREATEST(CAST(qty_prepared AS SIGNED) - :q, 0) WHERE id = :id')
            ->execute([':q' => $qty, ':id' => $line['id']]);
    }

    $status = mr_recalc($pdo, $request);
    $pdo->commit();
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    json_error('Failed to remove the item from the order.', 500);
}

audit_log('UNPICK', 'material_requests', $request['request_code']);

json_success([
    'status'       => $status,
    'new_quantity' => $newQty,
    'detail'       => mr_detail($pdo, $requestId),
], "{$qty} x {$item['item_name']} returned to stock.");
