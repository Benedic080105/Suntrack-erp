<?php
/**
 * GET /api/material_requests/list.php
 *
 * Client orders for the Warehouse "Client Orders" tab and the Management
 * "Material Requests" tab. Read-only; Warehouse, Management and Admin.
 *
 * Query parameters (all optional):
 *   status   open (PENDING/PREPARING/READY, the default) | all | one status
 *   search   request code, client code/name, project or job code
 *   client_id
 *
 * Two queries regardless of row count: the orders, then every line for those
 * orders in one IN (...) — never one query per order.
 */
require_once __DIR__ . '/../../middleware/warehouse.php';

mr_require_schema();
$pdo = db();
[$pageLimit, $pageOffset] = list_page(300);
$where = [];
$params = [];

$status = strtoupper(trim((string)($_GET['status'] ?? 'open')));
if ($status === 'OPEN') {
    $where[] = "mr.status IN ('PENDING','PREPARING','READY')";
} elseif ($status !== 'ALL') {
    if (!in_array($status, ['PENDING', 'PREPARING', 'READY', 'RELEASED', 'CANCELLED'], true)) {
        json_error('Unknown status filter.', 422);
    }
    $where[] = 'mr.status = :status';
    $params[':status'] = $status;
}

if ($clause = search_clause($_GET['search'] ?? '', search_columns('material_requests'), $params)) {
    $where[] = $clause;
}
apply_date_range('mr.created_at', $where, $params);

if (!empty($_GET['client_id'])) {
    $where[] = 'mr.client_id = :client';
    $params[':client'] = (int)$_GET['client_id'];
}

$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

// Open orders first, soonest needed first; finished ones newest first.
$stmt = $pdo->prepare(
    "SELECT mr.id, mr.request_code, mr.status, mr.needed_by, mr.notes, mr.created_at, mr.ready_at,
            mr.released_at, mr.released_to, mr.client_id, mr.project_id, mr.job_id,
            c.client_code, cu.full_name AS client_name, c.city AS client_city,
            p.project_code, p.site_name, j.job_code,
            ru.full_name AS requested_by_name
     FROM material_requests mr
     JOIN clients c ON c.id = mr.client_id
     JOIN users cu  ON cu.id = c.user_id
     LEFT JOIN projects p ON p.id = mr.project_id
     LEFT JOIN jobs j     ON j.id = mr.job_id
     LEFT JOIN users ru   ON ru.id = mr.requested_by
     $whereSql
     ORDER BY FIELD(mr.status, 'READY', 'PREPARING', 'PENDING', 'RELEASED', 'CANCELLED'),
              mr.needed_by IS NULL, mr.needed_by, mr.id DESC
     " . list_page_sql($pageLimit, $pageOffset)
);
$stmt->execute($params);
$rows = list_page_finish($stmt->fetchAll(), $pageLimit, $pageOffset);

if ($rows) {
    $ids = array_map(fn($r) => (int)$r['id'], $rows);
    $in = implode(',', $ids); // integers from the database, not user input
    $lineRows = $pdo->query(
        "SELECT mri.request_id, mri.category_id, ic.category_name, mri.qty_required, mri.qty_prepared
         FROM material_request_items mri
         JOIN inventory_categories ic ON ic.id = mri.category_id
         WHERE mri.request_id IN ($in)
         ORDER BY ic.id"
    )->fetchAll();

    $byRequest = [];
    foreach ($lineRows as $l) {
        $byRequest[(int)$l['request_id']][] = $l;
    }
    foreach ($rows as &$r) {
        $r['lines'] = $byRequest[(int)$r['id']] ?? [];
        $req = $prep = 0;
        foreach ($r['lines'] as $l) {
            $req  += (int)$l['qty_required'];
            $prep += min((int)$l['qty_prepared'], (int)$l['qty_required']);
        }
        $r['qty_required'] = $req;
        $r['qty_prepared'] = $prep;
        $r['progress'] = $req > 0 ? (int)floor($prep * 100 / $req) : 0;
    }
    unset($r);
}

$counts = ['PENDING' => 0, 'PREPARING' => 0, 'READY' => 0, 'RELEASED' => 0, 'CANCELLED' => 0];
foreach ($pdo->query('SELECT status, COUNT(*) AS n FROM material_requests GROUP BY status') as $c) {
    $counts[$c['status']] = (int)$c['n'];
}

json_success(['rows' => $rows, 'counts' => $counts]);
