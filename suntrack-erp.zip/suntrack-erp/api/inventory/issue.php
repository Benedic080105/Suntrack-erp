<?php
/**
 * POST /api/inventory/issue.php — stock out to a job.
 *
 * Body: inventory_id, job_id, request_key, and
 *   PRODUCT items: quantity
 *   SERIAL items:  unit_codes[] — the scanned unit labels (or unit ids)
 *
 * Never lets stock go negative: the quantity is re-read under a row lock.
 * A serialized unit can only leave once — a second scan of a unit already
 * issued is refused.
 */
require_once __DIR__ . '/../../config/config.php';
require_warehouse_write(); // Admin role is view/export only; only Warehouse/Management may mutate stock.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['inventory_id', 'job_id']);
inv_require_qr_schema();

$invId = (int)$input['inventory_id'];
$pdo = db();
$job = inv_job($pdo, (int)$input['job_id'], true);

$pdo->beginTransaction();
try {
    $requestKey = inv_request_key_begin($pdo, $input, 'inventory/issue');
    $item = inv_lock_item($pdo, $invId);
    $ref = 'Issued to ' . $job['job_code'];

    $issuedUnits = [];
    if ($item['tracking_mode'] === 'SERIAL') {
        $units = inv_lock_units($pdo, $item, $input['unit_codes'] ?? ($input['unit_ids'] ?? []));
        foreach ($units as $u) {
            if ($u['status'] !== 'IN_STOCK') {
                $where = $u['status'] === 'ISSUED' ? 'already issued' : ($u['status'] === 'QUARANTINE' ? 'in quarantine' : 'written off');
                inv_fail("{$u['unit_code']} (S/N {$u['serial_number']}) is {$where} and cannot be issued.", 409);
            }
        }
        $upd = $pdo->prepare("UPDATE inventory_units SET status = 'ISSUED', job_id = :job, material_request_id = NULL WHERE id = :id AND status = 'IN_STOCK'");
        foreach ($units as $u) {
            $upd->execute([':job' => $job['id'], ':id' => $u['id']]);
            inv_add_movement($pdo, [
                'inventory_id' => $invId, 'type' => 'ISSUE', 'quantity' => 1, 'job_id' => $job['id'],
                'technician_id' => $job['technician_id'], 'unit_id' => $u['id'], 'reference' => $ref,
            ]);
            $issuedUnits[] = $u['unit_code'];
        }
        $qty = count($units);
    } else {
        $qty = (int)($input['quantity'] ?? 0);
        if ($qty <= 0 || $qty > INV_MAX_QTY) {
            inv_fail('Quantity must be between 1 and ' . INV_MAX_QTY . '.');
        }
        if ((int)$item['quantity'] < $qty) {
            inv_fail("Insufficient stock. Only {$item['quantity']} units of {$item['item_name']} available.");
        }
        inv_add_movement($pdo, [
            'inventory_id' => $invId, 'type' => 'ISSUE', 'quantity' => $qty, 'job_id' => $job['id'],
            'technician_id' => $job['technician_id'], 'reference' => $ref,
        ]);
    }

    $newQty = (int)$item['quantity'] - $qty;
    inv_set_stock($pdo, $item, $newQty, (int)$item['quarantine_qty']);

    $data = ['inventory_id' => $invId, 'issued' => $qty, 'new_quantity' => $newQty, 'units' => $issuedUnits];
    $message = "{$qty} x {$item['item_name']} issued to {$job['job_code']}.";
    inv_request_key_finish($pdo, $requestKey, $data, $message);
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('inventory/issue failed: ' . $e->getMessage());
    json_error('Failed to issue stock. Nothing was changed.', 500);
}

audit_log('ISSUE', 'inventory', $item['sku']);

// Notify the assigned technician, if any.
if ($job['technician_id']) {
    $techUserStmt = $pdo->prepare('SELECT user_id FROM technicians WHERE id = :id');
    $techUserStmt->execute([':id' => $job['technician_id']]);
    $techUserId = $techUserStmt->fetchColumn();
    if ($techUserId) {
        notify((int)$techUserId, 'INVENTORY', "$qty x {$item['item_name']} issued to your job {$job['job_code']}.", 'jobs', (int)$job['id']);
    }
}

json_success($data, $message);
