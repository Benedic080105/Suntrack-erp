<?php
require_once __DIR__ . '/../../config/config.php';
require_warehouse_write(); // Admin role is view/export only; only Warehouse/Management may mutate stock.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['id']);

$id = (int)$input['id'];
$pdo = db();

$itemStmt = $pdo->prepare('SELECT * FROM inventory WHERE id = :id');
$itemStmt->execute([':id' => $id]);
$item = $itemStmt->fetch();
if (!$item) {
    json_error('Inventory item not found.', 404);
}

$fields = [];
$params = [':id' => $id];

foreach (['item_name', 'brand', 'model', 'serial_number', 'warehouse_location'] as $f) {
    if (isset($input[$f])) {
        $fields[] = "$f = :$f";
        $params[":$f"] = trim($input[$f]);
    }
}
if (isset($input['unit_cost'])) {
    $fields[] = 'unit_cost = :unit_cost';
    $params[':unit_cost'] = (float)$input['unit_cost'];
}
if (isset($input['reorder_level'])) {
    $reorder = (int)$input['reorder_level'];
    if ($reorder < 0) {
        json_error('Reorder level cannot be negative.', 422);
    }
    $fields[] = 'reorder_level = :reorder_level';
    $params[':reorder_level'] = $reorder;
}
if (isset($input['category_id'])) {
    $catId = (int)$input['category_id'];
    $catOk = $pdo->prepare('SELECT id FROM inventory_categories WHERE id = :c');
    $catOk->execute([':c' => $catId]);
    if (!$catOk->fetch()) {
        json_error('Please choose a valid category.', 422);
    }
    $fields[] = 'category_id = :category_id';
    $params[':category_id'] = $catId;
}

// Retiring an item is the one status change a human makes by hand; every
// other status is derived from quantity. This edit form is the only place it
// can be set or cleared — stock movements deliberately preserve it.
$discontinueRequest = null;
if (isset($input['status'])) {
    $requested = strtoupper(trim((string)$input['status']));
    if (!in_array($requested, ['ACTIVE', 'DISCONTINUED'], true)) {
        json_error('Status may only be set to Active or Discontinued.', 422);
    }
    $discontinueRequest = $requested;
}

if (empty($fields) && $discontinueRequest === null) {
    json_error('No fields to update.', 422);
}

if (!empty($fields)) {
    $sql = 'UPDATE inventory SET ' . implode(', ', $fields) . ' WHERE id = :id';
    $pdo->prepare($sql)->execute($params);
}

// Recompute status from the stored row, which now reflects any edit above.
$fresh = $pdo->prepare('SELECT quantity, reorder_level, status FROM inventory WHERE id = :id');
$fresh->execute([':id' => $id]);
$row = $fresh->fetch();

// An explicit request wins: DISCONTINUED sticks, ACTIVE clears the retirement
// and lets the quantity decide. With no request, the existing status is passed
// through so a retired item is not silently revived.
$basis = $discontinueRequest === 'DISCONTINUED' ? 'DISCONTINUED'
       : ($discontinueRequest === 'ACTIVE' ? null : ($row['status'] ?? null));

$status = inventory_status((int)$row['quantity'], $basis);
$pdo->prepare('UPDATE inventory SET status = :s WHERE id = :id')->execute([':s' => $status, ':id' => $id]);

audit_log('UPDATE', 'inventory', $item['sku']);

json_success([], 'Inventory item updated.');
