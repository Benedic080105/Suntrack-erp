<?php
/**
 * POST /api/inventory/quarantine.php — inspect returned stock held in quarantine.
 *
 * Body: inventory_id, action (restock | write_off), note (optional), request_key, and
 *   PRODUCT items: quantity (no more than is in quarantine)
 *   SERIAL items:  unit_codes[] — units currently in QUARANTINE
 *
 * restock    passed inspection: back into available stock
 * write_off  not usable: leaves quarantine and never returns to stock
 *
 * Both are recorded as ADJUST movements; nothing in the history is rewritten.
 */
require_once __DIR__ . '/../../config/config.php';
require_warehouse_write();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['inventory_id', 'action']);
inv_require_qr_schema();

$invId = (int)$input['inventory_id'];
$action = (string)$input['action'];
if (!in_array($action, ['restock', 'write_off'], true)) {
    json_error('Action must be restock or write_off.', 422);
}
$restock = $action === 'restock';
$note = trim((string)($input['note'] ?? ''));
$ref = ($restock ? 'Passed inspection' : 'Written off') . ($note !== '' ? ': ' . $note : '');

$pdo = db();
$pdo->beginTransaction();
try {
    $requestKey = inv_request_key_begin($pdo, $input, 'inventory/quarantine');
    $item = inv_lock_item($pdo, $invId);

    if ($item['tracking_mode'] === 'SERIAL') {
        $units = inv_lock_units($pdo, $item, $input['unit_codes'] ?? ($input['unit_ids'] ?? []));
        $upd = $pdo->prepare("UPDATE inventory_units SET status = :s, item_condition = :c WHERE id = :id AND status = 'QUARANTINE'");
        foreach ($units as $u) {
            if ($u['status'] !== 'QUARANTINE') {
                inv_fail("{$u['unit_code']} is not in quarantine.", 409);
            }
            $upd->execute([':s' => $restock ? 'IN_STOCK' : 'WRITTEN_OFF', ':c' => $restock ? 'GOOD' : 'DAMAGED', ':id' => $u['id']]);
            inv_add_movement($pdo, [
                'inventory_id' => $invId, 'type' => 'ADJUST', 'quantity' => 1, 'unit_id' => $u['id'],
                'condition' => $restock ? 'GOOD' : 'DAMAGED', 'reference' => $ref,
            ]);
        }
        $qty = count($units);
    } else {
        $qty = (int)($input['quantity'] ?? 0);
        if ($qty <= 0) {
            inv_fail('Quantity must be at least 1.');
        }
        if ($qty > (int)$item['quarantine_qty']) {
            inv_fail("Only {$item['quarantine_qty']} x {$item['item_name']} " . ((int)$item['quarantine_qty'] === 1 ? 'is' : 'are') . ' in quarantine.');
        }
        inv_add_movement($pdo, [
            'inventory_id' => $invId, 'type' => 'ADJUST', 'quantity' => $qty,
            'condition' => $restock ? 'GOOD' : 'DAMAGED', 'reference' => $ref,
        ]);
    }

    $newQty = (int)$item['quantity'] + ($restock ? $qty : 0);
    $newHeld = (int)$item['quarantine_qty'] - $qty;
    inv_set_stock($pdo, $item, $newQty, $newHeld);

    $data = ['inventory_id' => $invId, 'quantity' => $qty, 'new_quantity' => $newQty, 'quarantine_qty' => $newHeld];
    $message = $restock
        ? "{$qty} x {$item['item_name']} passed inspection and is back in stock."
        : "{$qty} x {$item['item_name']} written off. It stays in the history but not in stock.";
    inv_request_key_finish($pdo, $requestKey, $data, $message);
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('inventory/quarantine failed: ' . $e->getMessage());
    json_error('Could not save the inspection. Nothing was changed.', 500);
}

audit_log($restock ? 'QUARANTINE_RESTOCK' : 'WRITE_OFF', 'inventory', $item['sku']);

json_success($data, $message);
