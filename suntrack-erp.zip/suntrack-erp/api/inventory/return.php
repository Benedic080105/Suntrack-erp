<?php
/**
 * POST /api/inventory/return.php — stock coming back from a job.
 *
 * Body: inventory_id, condition (GOOD | DAMAGED | NEEDS_INSPECTION, default
 * GOOD), request_key, and
 *   PRODUCT items: job_id, quantity — no more than that job still holds
 *                  (issued minus already returned)
 *   SERIAL items:  unit_codes[] — each must currently be issued; its job is
 *                  taken from the unit (job_id, if sent, must match)
 *
 * GOOD returns go back into available stock. DAMAGED / NEEDS_INSPECTION go to
 * quarantine and stay unavailable until Inspection restocks or writes them
 * off (api/inventory/quarantine.php). Each RETURN row points at the ISSUE it
 * reverses (original_movement_id).
 */
require_once __DIR__ . '/../../config/config.php';
require_warehouse_write(); // Admin role is view/export only; only Warehouse/Management may mutate stock.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['inventory_id']);
inv_require_qr_schema();

$invId = (int)$input['inventory_id'];
$condition = strtoupper(trim((string)($input['condition'] ?? 'GOOD')));
if (!in_array($condition, INV_CONDITIONS, true)) {
    json_error('Condition must be Good, Damaged or Needs inspection.', 422);
}
$good = $condition === 'GOOD';
$suffix = $good ? '' : ($condition === 'DAMAGED' ? ' (damaged)' : ' (to inspect)');

$pdo = db();
$job = !empty($input['job_id']) ? inv_job($pdo, (int)$input['job_id']) : null;

$pdo->beginTransaction();
try {
    $requestKey = inv_request_key_begin($pdo, $input, 'inventory/return');
    $item = inv_lock_item($pdo, $invId);

    $returnedUnits = [];
    if ($item['tracking_mode'] === 'SERIAL') {
        $units = inv_lock_units($pdo, $item, $input['unit_codes'] ?? ($input['unit_ids'] ?? []));
        $jobCodes = $pdo->prepare('SELECT job_code, technician_id FROM jobs WHERE id = :id');
        $mrCodes = $pdo->prepare('SELECT request_code FROM material_requests WHERE id = :id');
        $upd = $pdo->prepare(
            "UPDATE inventory_units SET status = :s, item_condition = :c, job_id = NULL, material_request_id = NULL
             WHERE id = :id AND status = 'ISSUED'"
        );
        foreach ($units as $u) {
            if ($u['status'] !== 'ISSUED') {
                inv_fail("{$u['unit_code']} (S/N {$u['serial_number']}) is not out on a job, so it cannot be returned.", 409);
            }
            if ($job && (int)$u['job_id'] !== (int)$job['id']) {
                inv_fail("{$u['unit_code']} was not issued to {$job['job_code']}.", 409);
            }
            $issue = inv_unit_last_issue($pdo, (int)$u['id']);
            $from = 'stock';
            $techId = null;
            if ($u['job_id']) {
                $jobCodes->execute([':id' => $u['job_id']]);
                $j = $jobCodes->fetch();
                $from = $j['job_code'] ?? $from;
                $techId = $j['technician_id'] ?? null;
            } elseif ($u['material_request_id']) {
                $mrCodes->execute([':id' => $u['material_request_id']]);
                $from = $mrCodes->fetchColumn() ?: $from;
            }
            $upd->execute([':s' => $good ? 'IN_STOCK' : 'QUARANTINE', ':c' => $condition, ':id' => $u['id']]);
            inv_add_movement($pdo, [
                'inventory_id' => $invId, 'type' => 'RETURN', 'quantity' => 1,
                'job_id' => $u['job_id'], 'material_request_id' => $u['material_request_id'], 'technician_id' => $techId,
                'unit_id' => $u['id'], 'condition' => $condition, 'original_movement_id' => $issue['id'] ?? null,
                'reference' => 'Returned from ' . $from . $suffix,
            ]);
            $returnedUnits[] = $u['unit_code'];
        }
        $qty = count($units);
        $label = $job['job_code'] ?? ($from ?? 'the job');
    } else {
        if (!$job) {
            inv_fail('Choose the job this stock is coming back from.');
        }
        $qty = (int)($input['quantity'] ?? 0);
        if ($qty <= 0 || $qty > INV_MAX_QTY) {
            inv_fail('Quantity must be between 1 and ' . INV_MAX_QTY . '.');
        }
        [$held, $lastIssue] = inv_outstanding($pdo, $invId, (int)$job['id']);
        if ($held < $qty) {
            inv_fail($held === 0
                ? "{$job['job_code']} has no {$item['item_name']} to return — none was issued to it, or all of it is already back."
                : "Only {$held} x {$item['item_name']} " . ($held === 1 ? 'was' : 'were') . " issued to {$job['job_code']} and not yet returned.");
        }
        inv_add_movement($pdo, [
            'inventory_id' => $invId, 'type' => 'RETURN', 'quantity' => $qty, 'job_id' => $job['id'],
            'technician_id' => $job['technician_id'], 'condition' => $condition, 'original_movement_id' => $lastIssue,
            'reference' => 'Returned from ' . $job['job_code'] . $suffix,
        ]);
        $label = $job['job_code'];
    }

    $newQty = (int)$item['quantity'] + ($good ? $qty : 0);
    $newHeld = (int)$item['quarantine_qty'] + ($good ? 0 : $qty);
    inv_set_stock($pdo, $item, $newQty, $newHeld);

    $data = ['inventory_id' => $invId, 'returned' => $qty, 'condition' => $condition, 'new_quantity' => $newQty,
             'quarantine_qty' => $newHeld, 'units' => $returnedUnits];
    $message = $good
        ? "{$qty} x {$item['item_name']} returned from {$label} and back in stock."
        : "{$qty} x {$item['item_name']} returned from {$label} and held in quarantine — not available until inspected.";
    inv_request_key_finish($pdo, $requestKey, $data, $message);
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('inventory/return failed: ' . $e->getMessage());
    json_error('Failed to return stock. Nothing was changed.', 500);
}

audit_log('RETURN', 'inventory', $item['sku']);

json_success($data, $message);
