<?php
require_once __DIR__ . '/../../middleware/warehouse.php';

$pdo = db();
[$pageLimit, $pageOffset] = list_page(500);

$where = [];
$params = [];

if ($clause = search_clause($_GET['search'] ?? '', search_columns('inventory'), $params)) {
    $where[] = $clause;
}
if (!empty($_GET['category'])) {
    $where[] = 'ic.category_name = :category';
    $params[':category'] = $_GET['category'];
}
if (!empty($_GET['status'])) {
    $where[] = 'i.status = :status';
    $params[':status'] = $_GET['status'];
}

$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$sql = "SELECT i.*, ic.category_name
        FROM inventory i
        JOIN inventory_categories ic ON ic.id = i.category_id
        $whereSql
        ORDER BY i.item_name ASC, i.id ASC
        " . list_page_sql($pageLimit, $pageOffset);

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

json_success(list_page_finish($stmt->fetchAll(), $pageLimit, $pageOffset));
