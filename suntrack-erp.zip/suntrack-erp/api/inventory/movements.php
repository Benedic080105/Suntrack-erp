<?php
/**
 * GET /api/inventory/movements.php?inventory_id=N  — an item's stock history
 * GET /api/inventory/movements.php?unit_id=N       — one serialized unit's
 *                                                    service history
 */
require_once __DIR__ . '/../../middleware/warehouse.php';

$invId  = (int)($_GET['inventory_id'] ?? 0);
$unitId = (int)($_GET['unit_id'] ?? 0);
if (!$invId && !$unitId) {
    json_error('inventory_id or unit_id is required.', 422);
}

$pdo = db();

if (!inv_qr_ready()) {
    // Before phase 16 there are no units or conditions to show.
    $stmt = $pdo->prepare(
        "SELECT sm.*, j.job_code, u.full_name AS recorded_by_name
         FROM stock_movements sm
         LEFT JOIN jobs j ON j.id = sm.job_id
         LEFT JOIN users u ON u.id = sm.recorded_by
         WHERE sm.inventory_id = :id
         ORDER BY sm.created_at DESC, sm.id DESC"
    );
    $stmt->execute([':id' => $invId]);
    json_success($stmt->fetchAll());
}

$stmt = $pdo->prepare(
    "SELECT sm.*, j.job_code, mr.request_code, u.full_name AS recorded_by_name,
            iu.unit_code, iu.serial_number AS unit_serial, orig.movement_code AS original_movement_code
     FROM stock_movements sm
     LEFT JOIN jobs j ON j.id = sm.job_id
     LEFT JOIN material_requests mr ON mr.id = sm.material_request_id
     LEFT JOIN users u ON u.id = sm.recorded_by
     LEFT JOIN inventory_units iu ON iu.id = sm.unit_id
     LEFT JOIN stock_movements orig ON orig.id = sm.original_movement_id
     WHERE " . ($unitId ? 'sm.unit_id = :id' : 'sm.inventory_id = :id') . "
     ORDER BY sm.created_at DESC, sm.id DESC
     LIMIT 500"
);
$stmt->execute([':id' => $unitId ?: $invId]);

json_success($stmt->fetchAll());
