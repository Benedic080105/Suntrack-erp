<?php
/**
 * POST /api/inventory/receive.php — stock in (supplier delivery, restock).
 *
 * Body: inventory_id, reference (optional), request_key, and
 *   PRODUCT items: quantity
 *   SERIAL items:  serials[] — the serial number of every unit received;
 *                  each becomes a unit with its own QR label
 *
 * Stock only goes up once the transaction commits.
 */
require_once __DIR__ . '/../../config/config.php';
require_warehouse_write(); // Admin role is view/export only; only Warehouse/Management may mutate stock.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['inventory_id']);
inv_require_qr_schema();

$invId = (int)$input['inventory_id'];
$ref   = mb_substr(trim((string)($input['reference'] ?? '')), 0, 50) ?: 'Stock receipt';

$pdo = db();
$pdo->beginTransaction();
try {
    $requestKey = inv_request_key_begin($pdo, $input, 'inventory/receive');
    // Row lock: a concurrent issue / receive on this item waits for us.
    $item = inv_lock_item($pdo, $invId);

    $units = [];
    if ($item['tracking_mode'] === 'SERIAL') {
        $serials = inv_clean_serials($input['serials'] ?? []);
        if (!$serials) {
            inv_fail("{$item['item_name']} is tracked by unit. Enter the serial number of each unit received.");
        }
        if (isset($input['quantity']) && $input['quantity'] !== '' && (int)$input['quantity'] !== count($serials)) {
            inv_fail('Quantity (' . (int)$input['quantity'] . ') does not match the ' . count($serials) . ' serial numbers entered.');
        }
        $qty = count($serials);
        $units = inv_create_units($pdo, $item, $serials, $item['warehouse_location']);
        foreach ($units as $u) {
            inv_add_movement($pdo, [
                'inventory_id' => $invId, 'type' => 'RECEIVE', 'quantity' => 1, 'unit_id' => $u['id'],
                'condition' => 'GOOD', 'reference' => $ref,
            ]);
        }
    } else {
        $qty = (int)($input['quantity'] ?? 0);
        if ($qty <= 0 || $qty > INV_MAX_QTY) {
            inv_fail('Quantity must be between 1 and ' . INV_MAX_QTY . '.');
        }
        inv_add_movement($pdo, [
            'inventory_id' => $invId, 'type' => 'RECEIVE', 'quantity' => $qty, 'condition' => 'GOOD', 'reference' => $ref,
        ]);
    }

    $newQty = (int)$item['quantity'] + $qty;
    inv_set_stock($pdo, $item, $newQty, (int)$item['quarantine_qty']);

    $data = ['inventory_id' => $invId, 'received' => $qty, 'new_quantity' => $newQty, 'units' => $units];
    $message = $units
        ? "{$qty} unit" . ($qty === 1 ? '' : 's') . " of {$item['item_name']} received. Print their labels from the QR panel."
        : "{$qty} x {$item['item_name']} received.";
    inv_request_key_finish($pdo, $requestKey, $data, $message);
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('inventory/receive failed: ' . $e->getMessage());
    json_error('Failed to receive stock. Nothing was changed.', 500);
}

audit_log('RECEIVE', 'inventory', $item['sku']);

json_success($data, $message);
