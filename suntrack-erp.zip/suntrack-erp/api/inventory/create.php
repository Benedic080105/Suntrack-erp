<?php
/**
 * POST /api/inventory/create.php — register a product.
 *
 * Body: item_name, category, unit_cost, brand, model, serial_number (lot /
 * batch no.), warehouse_location, request_key, and
 *   tracking_mode = PRODUCT (default): quantity
 *   tracking_mode = SERIAL:            serials[] — one per unit on hand
 *                                      (quantity is their count)
 *
 * The item, its QR identifier, its units and the opening RECEIVE movements
 * are saved together or not at all.
 */
require_once __DIR__ . '/../../config/config.php';
require_warehouse_write(); // Admin role is view/export only; only Warehouse/Management may mutate stock.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['item_name', 'category', 'unit_cost']);
inv_require_qr_schema();

$allowedCategories = ['Solar Panel', 'Inverter', 'Battery'];
if (!in_array($input['category'], $allowedCategories, true)) {
    json_error('Category must be one of: ' . implode(', ', $allowedCategories), 422);
}

$tracking = strtoupper(trim((string)($input['tracking_mode'] ?? 'PRODUCT')));
if (!in_array($tracking, ['PRODUCT', 'SERIAL'], true)) {
    json_error('Tracking must be PRODUCT (one QR per product) or SERIAL (one QR per unit).', 422);
}

$name = trim((string)$input['item_name']);
if ($name === '' || mb_strlen($name) > 150) {
    json_error('Item name is required (150 characters max).', 422);
}
$unitCost = (float)$input['unit_cost'];
if (!is_numeric($input['unit_cost']) || $unitCost < 0) {
    json_error('Unit cost must be zero or more.', 422);
}

$serials = [];
if ($tracking === 'SERIAL') {
    $serials = inv_clean_serials($input['serials'] ?? []);
    $quantity = count($serials);
} else {
    if (!isset($input['quantity']) || $input['quantity'] === '' || !is_numeric($input['quantity'])) {
        json_error('Quantity is required.', 422);
    }
    $quantity = (int)$input['quantity'];
}
if ($quantity < 0 || $quantity > INV_MAX_QTY) {
    json_error('Quantity must be between 0 and ' . INV_MAX_QTY . '.', 422);
}

$pdo = db();

$catStmt = $pdo->prepare('SELECT id FROM inventory_categories WHERE category_name = :c');
$catStmt->execute([':c' => $input['category']]);
$categoryId = $catStmt->fetchColumn();
if (!$categoryId) {
    json_error('Unknown category.', 422);
}

// Reorder level is no longer shown or used (status follows INVENTORY_LOW_STOCK_BELOW);
// the column is kept and stays 0 unless an older client still sends one.
$reorderLevel = max(0, (int)($input['reorder_level'] ?? 0));
$status = inventory_status($quantity);
$location = mb_substr(trim((string)($input['warehouse_location'] ?? '')), 0, 50);
$warehouseId = (int)$pdo->query('SELECT id FROM warehouses LIMIT 1')->fetchColumn();

$pdo->beginTransaction();
try {
    $requestKey = inv_request_key_begin($pdo, $input, 'inventory/create');

    $stmt = $pdo->prepare(
        'INSERT INTO inventory (sku, item_name, category_id, brand, model, serial_number, quantity, unit_cost, reorder_level,
                                warehouse_id, warehouse_location, status, qr_code, tracking_mode)
         VALUES (:sku, :name, :cat, :brand, :model, :serial, :qty, :cost, :reorder, :wh, :loc, :status, NULL, :mode)'
    );
    // Collision-safe sequential SKU (ST-INV-9001 upward; see with_unique_code()).
    $sku = with_unique_code('inventory', 'sku', 'ST-INV-', function (string $sku) use ($stmt, $input, $name, $categoryId, $quantity, $unitCost, $reorderLevel, $warehouseId, $location, $status, $tracking) {
        $stmt->execute([
            ':sku' => $sku,
            ':name' => $name,
            ':cat' => $categoryId,
            ':brand' => mb_substr(trim((string)($input['brand'] ?? '')), 0, 100),
            ':model' => mb_substr(trim((string)($input['model'] ?? '')), 0, 100),
            ':serial' => mb_substr(trim((string)($input['serial_number'] ?? '')), 0, 100),
            ':qty' => $quantity,
            ':cost' => $unitCost,
            ':reorder' => $reorderLevel,
            ':wh' => $warehouseId ?: null,
            ':loc' => $location,
            ':status' => $status,
            ':mode' => $tracking,
        ]);
        return $sku;
    }, pad: 4, floor: 9000);
    $newId = (int)$pdo->lastInsertId();

    $qr = inv_assign_qr($pdo, $newId)['qr_code'];

    $units = [];
    if ($tracking === 'SERIAL') {
        $item = inv_lock_item($pdo, $newId);
        $units = inv_create_units($pdo, $item, $serials, $location);
        foreach ($units as $u) {
            inv_add_movement($pdo, [
                'inventory_id' => $newId, 'type' => 'RECEIVE', 'quantity' => 1, 'unit_id' => $u['id'],
                'condition' => 'GOOD', 'reference' => 'Initial stock on item creation',
            ]);
        }
    } elseif ($quantity > 0) {
        inv_add_movement($pdo, [
            'inventory_id' => $newId, 'type' => 'RECEIVE', 'quantity' => $quantity,
            'condition' => 'GOOD', 'reference' => 'Initial stock on item creation',
        ]);
    }

    $data = ['id' => $newId, 'sku' => $sku, 'qr_code' => $qr, 'tracking_mode' => $tracking, 'quantity' => $quantity, 'units' => $units];
    $message = "Inventory item created. QR code {$qr} is ready to print.";
    inv_request_key_finish($pdo, $requestKey, $data, $message);
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('inventory/create failed: ' . $e->getMessage());
    json_error('Could not save the item. Nothing was saved — please try again.', 500);
}

audit_log('CREATE', 'inventory', $sku);
audit_log('QR_GENERATE', 'inventory', $qr);

json_success($data, $message);
