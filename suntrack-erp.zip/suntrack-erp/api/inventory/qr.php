<?php
/**
 * /api/inventory/qr.php — an item's QR identifier and label data.
 *
 * GET  ?id=N                       the item, its QR identifier and (for
 *                                  serialized items) every unit's label data.
 *                                  Warehouse, Management and Admin (view).
 * POST {id, action: "generate"}    give an item that has no QR identifier one.
 *                                  Never replaces an existing code — labels
 *                                  already printed must keep scanning.
 */
require_once __DIR__ . '/../../middleware/warehouse.php';
inv_require_qr_schema();

$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) {
        json_error('id is required.', 422);
    }
    $payload = inv_item_payload($pdo, $id);
    if (!$payload) {
        json_error('Inventory item not found.', 404);
    }
    json_success($payload);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

require_warehouse_write();
$input = json_input();
require_csrf($input);
require_fields($input, ['id', 'action']);
if ($input['action'] !== 'generate') {
    json_error('Unknown action.', 422);
}
$id = (int)$input['id'];

$pdo->beginTransaction();
try {
    $result = inv_assign_qr($pdo, $id);
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('inventory/qr generate failed: ' . $e->getMessage());
    json_error('Could not generate the QR code. Please try again.', 500);
}

if ($result['created']) {
    audit_log('QR_GENERATE', 'inventory', $result['qr_code']);
}

json_success(inv_item_payload($pdo, $id) + ['created' => $result['created']],
    $result['created'] ? "QR code {$result['qr_code']} generated." : "This item already has QR code {$result['qr_code']} — it was kept.");
