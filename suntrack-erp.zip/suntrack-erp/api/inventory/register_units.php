<?php
/**
 * POST /api/inventory/register_units.php — switch a product to unit tracking.
 *
 * Body: inventory_id, serials[] (one per unit on the shelf), request_key
 *
 * Only safe when every unit in stock gets a serial: the list must hold
 * exactly as many serials as the available quantity, and nothing may be in
 * quarantine (inspect it first). Stock levels do not change; each unit gets a
 * zero-quantity ADJUST row so its own history starts here.
 */
require_once __DIR__ . '/../../config/config.php';
require_warehouse_write();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['inventory_id']);
inv_require_qr_schema();

$invId = (int)$input['inventory_id'];

$pdo = db();
$pdo->beginTransaction();
try {
    $requestKey = inv_request_key_begin($pdo, $input, 'inventory/register_units');
    $item = inv_lock_item($pdo, $invId);

    if ($item['tracking_mode'] === 'SERIAL') {
        inv_fail("{$item['item_name']} is already tracked by unit.", 409);
    }
    if ((int)$item['quarantine_qty'] > 0) {
        inv_fail("Inspect the {$item['quarantine_qty']} unit(s) in quarantine first, then switch to unit tracking.", 409);
    }
    $serials = inv_clean_serials($input['serials'] ?? []);
    if (count($serials) !== (int)$item['quantity']) {
        inv_fail("There are {$item['quantity']} in stock, so enter exactly {$item['quantity']} serial numbers (you entered " . count($serials) . ').');
    }

    $units = inv_create_units($pdo, $item, $serials, $item['warehouse_location']);
    foreach ($units as $u) {
        inv_add_movement($pdo, [
            'inventory_id' => $invId, 'type' => 'ADJUST', 'quantity' => 0, 'unit_id' => $u['id'],
            'condition' => 'GOOD', 'reference' => 'Registered for unit tracking',
        ]);
    }
    $pdo->prepare("UPDATE inventory SET tracking_mode = 'SERIAL' WHERE id = :id")->execute([':id' => $invId]);

    $data = ['inventory_id' => $invId, 'units' => $units];
    $message = count($units) . " unit(s) of {$item['item_name']} registered. Print a label for each one.";
    inv_request_key_finish($pdo, $requestKey, $data, $message);
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('inventory/register_units failed: ' . $e->getMessage());
    json_error('Could not register the units. Nothing was changed.', 500);
}

audit_log('REGISTER_UNITS', 'inventory', $item['sku']);

json_success($data, $message);
