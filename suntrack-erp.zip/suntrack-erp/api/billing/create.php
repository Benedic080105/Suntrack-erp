<?php
require_once __DIR__ . '/../../config/config.php';
require_management(); // Admin role is view/export only; only Management (manager/staff) may mutate.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['client_id', 'amount']);

$clientId = (int)$input['client_id'];
$amount = (float)$input['amount'];
if ($amount <= 0) {
    json_error('Amount must be greater than zero.', 422);
}

$pdo = db();

$clientCheck = $pdo->prepare('SELECT id FROM clients WHERE id = :id');
$clientCheck->execute([':id' => $clientId]);
if (!$clientCheck->fetch()) {
    json_error('Selected client was not found.', 422);
}

$projectId = null;
if (!empty($input['project_id'])) {
    $projectId = (int)$input['project_id'];
    $projCheck = $pdo->prepare('SELECT id FROM projects WHERE id = :id AND client_id = :cid');
    $projCheck->execute([':id' => $projectId, ':cid' => $clientId]);
    if (!$projCheck->fetch()) {
        json_error('Selected project does not belong to this client.', 422);
    }
}

$dueDate = trim($input['due_date'] ?? '') ?: null;

// The job order this invoice bills: chosen, or else the project's installation job.
$jobId = null;
if (billing_void_ready()) {
    if (!empty($input['job_id'])) {
        $jobId = (int)$input['job_id'];
        $jobCheck = $pdo->prepare('SELECT id FROM jobs WHERE id = :id AND client_id = :cid');
        $jobCheck->execute([':id' => $jobId, ':cid' => $clientId]);
        if (!$jobCheck->fetch()) {
            json_error('Selected job order does not belong to this client.', 422);
        }
    } elseif ($projectId) {
        $j = $pdo->prepare("SELECT MIN(id) FROM jobs WHERE project_id = :p AND job_type = 'INSTALLATION'");
        $j->execute([':p' => $projectId]);
        $jobId = (int)$j->fetchColumn() ?: null;
    }
}

$stmt = $pdo->prepare(billing_void_ready()
    ? 'INSERT INTO invoices (invoice_code, client_id, project_id, job_id, amount, due_date, payment_status, notes)
       VALUES (:code, :client_id, :project_id, :job_id, :amount, :due_date, "PENDING", :notes)'
    : 'INSERT INTO invoices (invoice_code, client_id, project_id, amount, due_date, payment_status, notes)
       VALUES (:code, :client_id, :project_id, :amount, :due_date, "PENDING", :notes)'
);
// Collision-safe sequential code (see with_unique_code() in helpers.php).
$code = with_unique_code('invoices', 'invoice_code', 'INV-' . date('Y') . '-', function (string $code) use ($stmt, $clientId, $projectId, $jobId, $amount, $dueDate, $input) {
    $stmt->execute(array_merge(billing_void_ready() ? [':job_id' => $jobId] : [], [
        ':code' => $code,
        ':client_id' => $clientId,
        ':project_id' => $projectId,
        ':amount' => $amount,
        ':due_date' => $dueDate,
        ':notes' => trim($input['notes'] ?? '') ?: null,
    ]));
    return $code;
}, pad: 4);

audit_log('CREATE', 'billing', $code);

json_success(['invoice_code' => $code], 'Invoice created.');
