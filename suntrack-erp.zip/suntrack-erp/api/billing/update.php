<?php
require_once __DIR__ . '/../../config/config.php';
require_management(); // Admin role is view/export only; only Management (manager/staff) may mutate.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['id']);

$id = (int)$input['id'];
$pdo = db();

$invStmt = $pdo->prepare('SELECT * FROM invoices WHERE id = :id');
$invStmt->execute([':id' => $id]);
$inv = $invStmt->fetch();
if (!$inv) {
    json_error('Invoice not found.', 404);
}

// A CANCELLED request is handled on its own — it's the one transition allowed from any non-PAID state.
if (!empty($input['cancel'])) {
    if ($inv['payment_status'] === 'PAID') {
        json_error('A paid invoice cannot be cancelled.', 422);
    }
    $pdo->prepare('UPDATE invoices SET payment_status = "CANCELLED" WHERE id = :id')->execute([':id' => $id]);
    audit_log('CANCEL', 'billing', $inv['invoice_code']);
    json_success([], 'Invoice cancelled.');
}

// Financial details can only be edited while the invoice is still PENDING (or OVERDUE, which is just
// PENDING past its due date) — once paid or cancelled, the record is settled and shouldn't be rewritten.
if (!in_array($inv['payment_status'], ['PENDING', 'OVERDUE'], true)) {
    json_error('Only pending invoices can be edited. Paid or cancelled invoices are locked.', 422);
}

$fields = [];
$params = [':id' => $id];

if (isset($input['amount'])) {
    $amount = (float)$input['amount'];
    if ($amount <= 0) json_error('Amount must be greater than zero.', 422);
    // With partial payments, an invoice can be lowered only down to what has
    // already been received — never below it, or the balance goes negative.
    $alreadyPaid = billing_paid_cents($pdo, $id) / 100; // valid (not voided) payments only
    if (round($amount * 100) < round($alreadyPaid * 100)) {
        json_error(sprintf('Amount cannot be lower than the ₱%s already paid on this invoice.', number_format($alreadyPaid, 2)), 422);
    }
    $fields[] = 'amount = :amount';
    $params[':amount'] = $amount;
}
if (isset($input['due_date'])) {
    $fields[] = 'due_date = :due_date';
    $params[':due_date'] = trim($input['due_date']) ?: null;
}
if (isset($input['notes'])) {
    $fields[] = 'notes = :notes';
    $params[':notes'] = trim($input['notes']) ?: null;
}
if (array_key_exists('project_id', $input)) {
    if (empty($input['project_id'])) {
        $fields[] = 'project_id = NULL';
    } else {
        $projectId = (int)$input['project_id'];
        $projCheck = $pdo->prepare('SELECT id FROM projects WHERE id = :id AND client_id = :cid');
        $projCheck->execute([':id' => $projectId, ':cid' => $inv['client_id']]);
        if (!$projCheck->fetch()) json_error('Selected project does not belong to this invoice\'s client.', 422);
        $fields[] = 'project_id = :project_id';
        $params[':project_id'] = $projectId;
    }
}

if (array_key_exists('job_id', $input) && billing_void_ready()) {
    if (empty($input['job_id'])) {
        $fields[] = 'job_id = NULL';
    } else {
        $jobId = (int)$input['job_id'];
        $jobCheck = $pdo->prepare('SELECT id FROM jobs WHERE id = :id AND client_id = :cid');
        $jobCheck->execute([':id' => $jobId, ':cid' => $inv['client_id']]);
        if (!$jobCheck->fetch()) json_error('Selected job order does not belong to this invoice\'s client.', 422);
        $fields[] = 'job_id = :job_id';
        $params[':job_id'] = $jobId;
    }
}

if ($fields) {
    $pdo->prepare('UPDATE invoices SET ' . implode(', ', $fields) . ' WHERE id = :id')->execute($params);
}

audit_log('UPDATE', 'billing', $inv['invoice_code']);

json_success([], 'Invoice updated.');
