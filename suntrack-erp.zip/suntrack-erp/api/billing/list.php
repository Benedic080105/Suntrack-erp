<?php
/**
 * Billing — list + summary stats for the Billing tab.
 * Mutations (create/edit/cancel/record payment) live in create.php,
 * update.php, and record_payment.php, all Management-only.
 */
require_once __DIR__ . '/../../middleware/admin.php';

billing_refresh_overdue(); // PENDING past its due date -> OVERDUE
$pdo = db();
[$pageLimit, $pageOffset] = list_page(500);
$where = [];
$params = [];

if ($clause = search_clause($_GET['search'] ?? '', search_columns('billing'), $params)) {
    $where[] = $clause;
}
if (!empty($_GET['status'])) {
    $where[] = 'i.payment_status = :status';
    $params[':status'] = $_GET['status'];
}
if (!empty($_GET['date_from'])) {
    $where[] = 'i.due_date >= :date_from';
    $params[':date_from'] = $_GET['date_from'];
}
if (!empty($_GET['date_to'])) {
    $where[] = 'i.due_date <= :date_to';
    $params[':date_to'] = $_GET['date_to'];
}
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

// Material requests' code (phase 15): which invoices were raised by a warehouse release.
$mrCol = mr_invoicing_available() ? '(SELECT mr.request_code FROM material_requests mr WHERE mr.id = i.material_request_id)' : 'NULL';
// Paid = valid payments only (voided ones are history, not money received).
// A cancelled (voided) invoice owes nothing.
$jobCols = billing_void_ready() ? 'i.job_id, (SELECT j.job_code FROM jobs j WHERE j.id = i.job_id) AS job_code,' : 'NULL AS job_id, NULL AS job_code,';
$sql = "SELECT i.id, i.invoice_code, i.client_id, i.project_id, $jobCols u.full_name AS client_name, p.project_code,
               $mrCol AS material_request_code,
               i.amount, i.due_date, i.payment_status, i.payment_date, i.payment_reference, i.notes,
               COALESCE(pay.paid, 0) AS amount_paid,
               CASE WHEN i.payment_status = 'CANCELLED' THEN 0 ELSE GREATEST(i.amount - COALESCE(pay.paid, 0), 0) END AS balance
        FROM invoices i
        LEFT JOIN (" . billing_paid_subquery() . ") pay
               ON pay.invoice_id = i.id
        JOIN clients c ON c.id = i.client_id
        JOIN users u ON u.id = c.user_id
        LEFT JOIN projects p ON p.id = i.project_id
        $whereSql
        ORDER BY i.id DESC
        " . list_page_sql($pageLimit, $pageOffset);
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = list_page_finish($stmt->fetchAll(), $pageLimit, $pageOffset);

$totalInvoiced = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM invoices")->fetchColumn();
$paid          = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM invoices WHERE payment_status='PAID'")->fetchColumn();
$pending       = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM invoices WHERE payment_status='PENDING'")->fetchColumn();
$overdue       = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM invoices WHERE payment_status='OVERDUE'")->fetchColumn();

$byStatus = $pdo->query(
    "SELECT payment_status AS label, COALESCE(SUM(amount),0) AS total
     FROM invoices GROUP BY payment_status ORDER BY total DESC"
)->fetchAll();

json_success([
    'rows' => $rows,
    'stats' => [
        'total_invoiced' => $totalInvoiced,
        'paid' => $paid,
        'pending' => $pending,
        'overdue' => $overdue,
    ],
    'chart' => [
        'labels' => array_map(fn($r) => $r['label'], $byStatus),
        'values' => array_map(fn($r) => (float)$r['total'], $byStatus),
    ],
]);
