<?php
/**
 * POST /api/billing/void_payment.php — correct a wrongly recorded payment.
 * Management only (manager / staff). Body: payment_id, reason (5–255 chars).
 *
 * The payment is never deleted or edited: it is marked VOIDED with who voided
 * it, when and why, stays visible in the invoice's payment history, and stops
 * counting toward what the client has paid. The invoice's status follows
 * (a PAID invoice with a balance again goes back to PENDING / OVERDUE).
 * To fix an amount: void the wrong payment, then record the right one.
 */
require_once __DIR__ . '/../../config/config.php';
require_management();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['payment_id', 'reason']);
billing_require_schema();

$paymentId = (int)$input['payment_id'];
$reason = trim((string)$input['reason']);
if (mb_strlen($reason) < 5 || mb_strlen($reason) > 255) {
    json_error('Give a reason for voiding this payment (5 to 255 characters).', 422);
}

$pdo = db();
$p = $pdo->prepare('SELECT invoice_id FROM payments WHERE id = :id');
$p->execute([':id' => $paymentId]);
$invoiceId = (int)$p->fetchColumn();
if (!$invoiceId) {
    json_error('Payment not found.', 404);
}

$pdo->beginTransaction();
try {
    // Same lock order as record_payment.php: the invoice first, then its payment.
    $inv = $pdo->prepare('SELECT * FROM invoices WHERE id = :id FOR UPDATE');
    $inv->execute([':id' => $invoiceId]);
    $invoice = $inv->fetch();

    $pay = $pdo->prepare('SELECT * FROM payments WHERE id = :id FOR UPDATE');
    $pay->execute([':id' => $paymentId]);
    $payment = $pay->fetch();
    if ($payment['voided_at'] !== null) {
        $pdo->rollBack();
        json_error('This payment was already voided on ' . date('M j, Y g:i A', strtotime($payment['voided_at'])) . '.', 409);
    }

    $pdo->prepare('UPDATE payments SET voided_at = NOW(), voided_by = :u, void_reason = :r WHERE id = :id AND voided_at IS NULL')
        ->execute([':u' => current_user_id(), ':r' => $reason, ':id' => $paymentId]);
    $status = billing_sync_status($pdo, $invoice);
    // Moves the invoices fingerprint so open dashboards / billing lists refresh live.
    $pdo->prepare('UPDATE invoices SET updated_at = CURRENT_TIMESTAMP WHERE id = :id')->execute([':id' => $invoiceId]);
    $balance = $invoice['payment_status'] === 'CANCELLED'
        ? 0 : max(0, (int)round((float)$invoice['amount'] * 100) - billing_paid_cents($pdo, $invoiceId)) / 100;

    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('billing/void_payment failed: ' . $e->getMessage());
    json_error('Could not void the payment. Nothing was changed.', 500);
}

// Who / when / why live on the payment row itself (voided_by, voided_at, void_reason).
audit_log('VOID_PAYMENT', 'billing', $invoice['invoice_code']);

json_success(['invoice_status' => $status, 'balance' => $balance],
    'Payment ₱' . number_format((float)$payment['amount'], 2) . ' voided. It stays in the history but no longer counts as paid.'
    . ($balance > 0 ? ' Balance now ₱' . number_format($balance, 2) . '.' : ''));
