<?php
/**
 * POST /api/billing/record_payment.php
 * Management only. Records one payment against an invoice.
 *
 * Body: invoice_id, amount, payment_method (CASH | GCASH | BANK_TRANSFER |
 * CHECK | CREDIT_CARD), reference (optional), paid_on (optional YYYY-MM-DD,
 * not in the future; default today), request_key (one per form).
 *
 * Payments accumulate: the invoice becomes PAID only once its valid payments
 * cover the full amount. A payment larger than the outstanding balance is
 * refused rather than silently recorded as an overpayment.
 *
 * Duplicates: the same form sent twice (same request_key) records once and
 * answers with the first payment; a reference already on another valid
 * payment (e.g. the same bank transfer typed in twice) is refused.
 * Who recorded it and when is stored with every payment. Mistakes are
 * corrected with api/billing/void_payment.php — payments are never deleted.
 */
require_once __DIR__ . '/../../config/config.php';
require_management(); // Admin role is view/export only; only Management (manager/staff) may mutate.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['invoice_id', 'amount']);
billing_require_schema();

$invoiceId = (int)$input['invoice_id'];
if (!is_numeric($input['amount'])) {
    json_error('Payment amount must be a number.', 422);
}
// Money is compared in whole centavos so that float rounding can never leave
// an invoice ₱0.00000001 short of PAID.
$amountCents = (int)round((float)$input['amount'] * 100);
if ($amountCents <= 0) {
    json_error('Payment amount must be greater than zero.', 422);
}

$methods = ['CASH', 'GCASH', 'BANK_TRANSFER', 'CHECK', 'CREDIT_CARD'];
$method = strtoupper(trim((string)($input['payment_method'] ?? ''))) ?: 'CASH';
if (!in_array($method, $methods, true)) {
    json_error('Payment method must be one of: ' . implode(', ', $methods) . '.', 422);
}

$paidAt = date('Y-m-d H:i:s');
if (!empty($input['paid_on'])) {
    $d = DateTime::createFromFormat('!Y-m-d', (string)$input['paid_on']);
    if (!$d || $d->format('Y-m-d') !== $input['paid_on']) {
        json_error('Payment date must be a valid date.', 422);
    }
    if ($input['paid_on'] > date('Y-m-d')) {
        json_error('Payment date cannot be in the future.', 422);
    }
    $paidAt = $input['paid_on'] === date('Y-m-d') ? $paidAt : $input['paid_on'] . ' 12:00:00';
}

$requestKey = trim((string)($input['request_key'] ?? '')) ?: null;
if ($requestKey !== null && !preg_match('/^[A-Za-z0-9_-]{8,64}$/', $requestKey)) {
    json_error('Invalid request key.', 422);
}
$typedReference = mb_substr(trim((string)($input['reference'] ?? '')), 0, 50);
// Auto-reference is unique per payment: a timestamp alone repeated when two
// payments were recorded in the same second.
$reference = $typedReference !== '' ? $typedReference : sprintf('PMT-%s-%d-%s', date('YmdHis'), $invoiceId, bin2hex(random_bytes(2)));

$pdo = db();

/** Answer a repeated form with the payment it already recorded. */
$replay = function (array $p, array $inv) use ($pdo) {
    $balance = max(0, (int)round((float)$inv['amount'] * 100) - billing_paid_cents($pdo, (int)$inv['id']));
    json_success([
        'payment_id' => (int)$p['id'], 'reference' => $p['reference'], 'duplicate' => true,
        'fully_paid' => $balance === 0, 'balance' => $balance / 100,
    ], 'Already recorded — this payment was saved once. Nothing was added twice.');
};

$pdo->beginTransaction();
try {
    // Row lock — two clerks recording payments at once must see each other's
    // payment, or both could pass the balance check and overpay the invoice.
    $invStmt = $pdo->prepare('SELECT * FROM invoices WHERE id = :id FOR UPDATE');
    $invStmt->execute([':id' => $invoiceId]);
    $inv = $invStmt->fetch();
    if (!$inv) {
        $pdo->rollBack();
        json_error('Invoice not found.', 404);
    }

    // The same form again (double click, retry): it already counted.
    if ($requestKey !== null) {
        $k = $pdo->prepare('SELECT id, invoice_id, reference FROM payments WHERE request_key = :k');
        $k->execute([':k' => $requestKey]);
        if ($prior = $k->fetch()) {
            $pdo->rollBack();
            if ((int)$prior['invoice_id'] !== $invoiceId) {
                json_error('This form was already used for another invoice. Please reopen it.', 409);
            }
            $replay($prior, $inv);
        }
    }

    if ($inv['payment_status'] === 'PAID') {
        $pdo->rollBack();
        json_error('This invoice is already fully paid.', 422);
    }
    if ($inv['payment_status'] === 'CANCELLED') {
        $pdo->rollBack();
        json_error('This invoice has been voided and cannot receive a payment.', 422);
    }

    // The same bank / GCash / check reference recorded twice is a duplicate.
    if ($typedReference !== '') {
        $dup = $pdo->prepare(
            'SELECT i.invoice_code FROM payments p JOIN invoices i ON i.id = p.invoice_id
             WHERE p.reference = :r AND ' . billing_valid_payment('p') . ' LIMIT 1'
        );
        $dup->execute([':r' => $typedReference]);
        if ($code = $dup->fetchColumn()) {
            $pdo->rollBack();
            json_error("Reference {$typedReference} is already recorded on {$code}. If that one was wrong, void it first.", 409);
        }
    }

    $paidCents    = billing_paid_cents($pdo, $invoiceId);
    $totalCents   = (int)round((float)$inv['amount'] * 100);
    $balanceCents = $totalCents - $paidCents;

    if ($amountCents > $balanceCents) {
        $pdo->rollBack();
        json_error(sprintf(
            'Payment exceeds the outstanding balance of ₱%s.',
            number_format(max(0, $balanceCents) / 100, 2)
        ), 422, ['balance' => max(0, $balanceCents) / 100]);
    }

    try {
        $pdo->prepare(
            'INSERT INTO payments (invoice_id, amount, payment_method, reference, paid_at, recorded_by, request_key)
             VALUES (:invoice_id, :amount, :method, :reference, :paid_at, :recorded_by, :request_key)'
        )->execute([
            ':invoice_id'  => $invoiceId,
            ':amount'      => $amountCents / 100,
            ':method'      => $method,
            ':reference'   => $reference,
            ':paid_at'     => $paidAt,
            ':recorded_by' => current_user_id(),
            ':request_key' => $requestKey,
        ]);
    } catch (PDOException $e) {
        // A simultaneous copy of this form got in first.
        if (($e->errorInfo[1] ?? null) === 1062 && $requestKey !== null) {
            $pdo->rollBack();
            $k = $pdo->prepare('SELECT id, invoice_id, reference FROM payments WHERE request_key = :k');
            $k->execute([':k' => $requestKey]);
            if ($prior = $k->fetch()) {
                $replay($prior, $inv);
            }
        }
        throw $e;
    }
    $paymentId = (int)$pdo->lastInsertId();

    $newBalanceCents = $balanceCents - $amountCents;
    $fullyPaid = $newBalanceCents <= 0;

    if ($fullyPaid) {
        $pdo->prepare(
            'UPDATE invoices SET payment_status = "PAID", payment_date = :d, payment_reference = :ref WHERE id = :id'
        )->execute([':d' => substr($paidAt, 0, 10), ':ref' => $reference, ':id' => $invoiceId]);
    } else {
        // Status stays PENDING/OVERDUE. The reference still moves, so the
        // invoice row shows the most recent payment against it.
        $pdo->prepare('UPDATE invoices SET payment_reference = :ref WHERE id = :id')
            ->execute([':ref' => $reference, ':id' => $invoiceId]);
    }

    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('billing/record_payment failed: ' . $e->getMessage());
    json_error('Failed to record payment. Nothing was saved.', 500);
}

audit_log($fullyPaid ? 'RECORD_PAYMENT' : 'RECORD_PARTIAL_PAYMENT', 'billing', $inv['invoice_code']);

json_success([
    'payment_id'  => $paymentId,
    'reference'   => $reference,
    'fully_paid'  => $fullyPaid,
    'amount_paid' => ($paidCents + $amountCents) / 100,
    'balance'     => max(0, $newBalanceCents) / 100,
], $fullyPaid
    ? 'Payment recorded. Invoice marked as paid.'
    : sprintf('Partial payment recorded. Remaining balance: ₱%s.', number_format($newBalanceCents / 100, 2)));
