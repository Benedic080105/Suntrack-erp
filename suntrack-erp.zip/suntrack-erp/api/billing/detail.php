<?php
/**
 * GET /api/billing/detail.php?id=N — Admin / Management. Everything about one
 * invoice for the Billing detail view: the invoice, the client and project,
 * its line items (frozen lines for a released material request, otherwise the
 * project's installed materials), every payment recorded, and the totals.
 */
require_once __DIR__ . '/../../middleware/admin.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed.', 405);
}
$id = (int)($_GET['id'] ?? 0);
billing_refresh_overdue();
$pdo = db();

$mrCol = mr_invoicing_available()
    ? '(SELECT mr.request_code FROM material_requests mr WHERE mr.id = i.material_request_id)' : 'NULL';
$stmt = $pdo->prepare(
    "SELECT i.*, $mrCol AS material_request_code,
            c.client_code, c.address, c.city, c.province, u.full_name AS client_name, u.email AS client_email, u.phone AS client_phone,
            p.project_code, p.site_name, p.capacity_kw, p.system_type, p.status AS project_status
     FROM invoices i
     JOIN clients c ON c.id = i.client_id
     JOIN users u ON u.id = c.user_id
     LEFT JOIN projects p ON p.id = i.project_id
     WHERE i.id = :id"
);
$stmt->execute([':id' => $id]);
$inv = $stmt->fetch();
if (!$inv) {
    json_error('Invoice not found.', 404);
}

// Every payment ever recorded, voided ones included (marked) — the history is
// never rewritten. Only valid ones count toward "paid".
$pay = $pdo->prepare(billing_void_ready()
    ? 'SELECT p.id, p.amount, p.payment_method, p.reference, p.paid_at, u.full_name AS recorded_by_name,
              p.voided_at, p.void_reason, vu.full_name AS voided_by_name
       FROM payments p LEFT JOIN users u ON u.id = p.recorded_by LEFT JOIN users vu ON vu.id = p.voided_by
       WHERE p.invoice_id = :i ORDER BY p.paid_at, p.id'
    : 'SELECT p.id, p.amount, p.payment_method, p.reference, p.paid_at, u.full_name AS recorded_by_name,
              NULL AS voided_at, NULL AS void_reason, NULL AS voided_by_name
       FROM payments p LEFT JOIN users u ON u.id = p.recorded_by
       WHERE p.invoice_id = :i ORDER BY p.paid_at, p.id'
);
$pay->execute([':i' => $id]);
$payments = $pay->fetchAll();
$paid = round(array_sum(array_map(fn($p) => $p['voided_at'] === null ? (float)$p['amount'] : 0.0, $payments)), 2);
if (billing_void_ready() && $inv['job_id']) {
    $j = $pdo->prepare('SELECT job_code, job_type, stage FROM jobs WHERE id = :id');
    $j->execute([':id' => $inv['job_id']]);
    $inv['job'] = $j->fetch() ?: null;
}

$lines = invoice_lines($id);
$source = 'invoice';
if (!$lines && $inv['project_id']) {
    $lines = project_material_costs((int)$inv['project_id'])['items'];
    $source = $lines ? 'project' : 'none';
} elseif (!$lines) {
    $source = 'none';
}

json_success([
    'invoice'  => $inv,
    'lines'    => $lines,
    'lines_source' => $source, // invoice = billed lines; project = materials installed (for reference)
    'lines_total'  => round(array_sum(array_column($lines, 'line_total')), 2),
    'payments' => $payments,
    'paid'     => $paid,
    'balance'  => $inv['payment_status'] === 'CANCELLED' ? 0 : max(0, round((float)$inv['amount'] - $paid, 2)),
    'pdf_url'  => APP_BASE_URL . '/invoice.php?id=' . $id,
    'can_void' => in_array(current_role(), ['manager', 'staff'], true) && billing_void_ready(),
]);
