<?php
/**
 * POST /api/maintenance/update_item.php
 *
 * Update one maintenance inspection item (status + remarks), using the
 * existing maintenance_items ENUM values.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['item_id', 'status']);

$itemId  = (int)$input['item_id'];
$status  = strtoupper(trim((string)$input['status']));
$remarks = trim((string)($input['remarks'] ?? ''));

if ($itemId <= 0) {
    json_error('Invalid inspection item.', 422);
}
if (!in_array($status, ['PENDING', 'COMPLETED', 'NOT_APPLICABLE'], true)) {
    json_error('Invalid status.', 422);
}
if (str_len($remarks) > 255) {
    json_error('Remarks are limited to 255 characters.', 422);
}

$pdo = db();
$itemStmt = $pdo->prepare(
    'SELECT mi.id, mi.maintenance_id, mr.job_id
     FROM maintenance_items mi
     JOIN maintenance_records mr ON mr.id = mi.maintenance_id
     WHERE mi.id = :id'
);
$itemStmt->execute([':id' => $itemId]);
$item = $itemStmt->fetch();

if (!$item) {
    json_error('Inspection item not found.', 404);
}

$job = tech_job_or_fail((int)$item['job_id']);

if (tech_stage_is_closed($job['stage'])) {
    json_error('This job is closed — its inspection can no longer be changed.', 422);
}

$recStmt = $pdo->prepare('SELECT * FROM maintenance_records WHERE id = :m');
$recStmt->execute([':m' => $item['maintenance_id']]);
if ($why = maint_edit_blocker($recStmt->fetch() ?: [])) {
    json_error($why, 422);
}

if (maint_review_ready()) {
    // Who ticked it and when (cleared again when it is unticked) — as on the installation checklist.
    $pdo->prepare(
        'UPDATE maintenance_items SET status = :s, remarks = :r,
                completed_at = IF(:s2 = "PENDING", NULL, IF(status = :s3 AND completed_at IS NOT NULL, completed_at, NOW())),
                completed_by = IF(:s4 = "PENDING", NULL, IF(status = :s5 AND completed_by IS NOT NULL, completed_by, :u))
         WHERE id = :id'
    )->execute([':s' => $status, ':r' => $remarks !== '' ? $remarks : null, ':s2' => $status, ':s3' => $status,
                ':s4' => $status, ':s5' => $status, ':u' => current_user_id(), ':id' => $itemId]);
} else {
    $pdo->prepare('UPDATE maintenance_items SET status = :s, remarks = :r WHERE id = :id')
        ->execute([':s' => $status, ':r' => $remarks !== '' ? $remarks : null, ':id' => $itemId]);
}

$pdo->prepare('UPDATE maintenance_records SET status = IF(status = "COMPLETED", "COMPLETED", "IN_PROGRESS") WHERE id = :m')
    ->execute([':m' => $item['maintenance_id']]);

// Mirror inspection progress onto the job so the dashboard bar means something.
$counts = tech_maintenance_counts((int)$item['maintenance_id']);
$pdo->prepare('UPDATE jobs SET progress = :p WHERE id = :j')
    ->execute([':p' => $counts['progress'], ':j' => $job['id']]);

audit_log('UPDATE_MAINTENANCE_ITEM:' . $status, 'maintenance_items', $job['job_code'] . '#' . $itemId);

json_success([
    'item_id'            => $itemId,
    'status'             => $status,
    'counts'             => $counts,
    'completion_blocker' => tech_maintenance_blocker($job),
], 'Inspection item updated.');
