<?php
/**
 * POST /api/maintenance/photo_upload.php   (multipart/form-data)
 *
 * The technician on a maintenance job adds a proof photo to one section of the
 * inspection (Solar Panels, Battery, Inverter) — the same as an installation
 * stage photo. Fields: csrf_token, job_id, section, photo (file).
 * Only while the job is open and the inspection is not submitted / approved.
 * Up to MAINTENANCE_PHOTO_MAX_PER_SECTION photos per section.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
// An upload larger than post_max_size arrives with an empty $_POST.
if (empty($_POST) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    json_error('That photo is too large (max 8 MB).', 413);
}
require_csrf($_POST);
require_fields($_POST, ['job_id', 'section']);
if (!maint_review_ready()) {
    json_error('Maintenance photos are not set up yet. Ask the administrator to run database/phase20_maintenance_checklist.sql.', 503);
}

$job = tech_job_or_fail((int)$_POST['job_id']);
if ($job['job_type'] !== 'MAINTENANCE') {
    json_error('This job is not a maintenance job.', 422);
}
if (tech_stage_is_closed($job['stage'])) {
    json_error('This job is closed — its photos can no longer be changed.', 422);
}
$section = trim((string)$_POST['section']);
if (!array_key_exists($section, tech_maintenance_sections())) {
    json_error('Unknown inspection section.', 422);
}
$record = tech_maintenance_record_for_job($job, true);
if ($why = maint_edit_blocker($record)) {
    json_error($why, 422);
}
$count = (int)((maint_photo_counts((int)$record['id']) ?? [])[$section] ?? 0);
if ($count >= MAINTENANCE_PHOTO_MAX_PER_SECTION) {
    json_error("{$section} already has the maximum of " . MAINTENANCE_PHOTO_MAX_PER_SECTION . ' photos.', 422);
}

[$name, $mime, $size, $w, $h] = store_uploaded_image($_FILES['photo'] ?? [], 'maintenance_photos');
try {
    db()->prepare(
        'INSERT INTO maintenance_photos (maintenance_id, job_id, section, uploaded_by, file_name, mime, size_bytes, width, height, created_at)
         VALUES (:m, :j, :s, :u, :f, :mi, :sz, :w, :h, :t)'
    )->execute([
        ':m' => $record['id'], ':j' => $job['id'], ':s' => $section, ':u' => current_user_id(), ':f' => $name,
        ':mi' => $mime, ':sz' => $size, ':w' => $w, ':h' => $h, ':t' => date('Y-m-d H:i:s'),
    ]);
    db()->prepare('UPDATE maintenance_records SET status = IF(status = "COMPLETED", "COMPLETED", "IN_PROGRESS") WHERE id = :m')
        ->execute([':m' => $record['id']]);
} catch (PDOException $e) {
    storage_delete('maintenance_photos', $name); // never leave an orphan file behind
    json_error('The photo could not be saved. Please try again.', 500);
}

audit_log('MAINT_PHOTO_UPLOAD:' . $section, 'maintenance_records', $job['job_code']);
json_success(['section' => $section, 'photos' => $count + 1], "Proof photo added to {$section}.");
