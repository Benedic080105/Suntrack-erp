<?php
/**
 * POST /api/maintenance/submit.php
 * Body: { job_id, note?, csrf_token }
 *
 * The technician sends the maintenance inspection to Management for review —
 * the same step as submitting an installation stage. Requires every item
 * ticked (or N/A), each section's condition recorded and at least one proof
 * photo per section. The inspection is then locked until Management approves
 * it (the job can be completed) or returns it with a note (fix and resubmit).
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
$input = json_input();
require_csrf($input);
require_fields($input, ['job_id']);
if (!maint_review_ready()) {
    json_error('Maintenance review is not set up yet. Ask the administrator to run database/phase20_maintenance_checklist.sql.', 503);
}
$note = trim((string)($input['note'] ?? ''));
if (str_len($note) > 500) {
    json_error('The note is limited to 500 characters.', 422);
}

$pdo = db();
$pdo->beginTransaction();
try {
    $job = tech_job_or_fail((int)$input['job_id'], true);
    tech_require_lead($job);
    if ($job['job_type'] !== 'MAINTENANCE') {
        $pdo->rollBack();
        json_error('This job is not a maintenance job.', 422);
    }
    if (tech_stage_is_closed($job['stage'])) {
        $pdo->rollBack();
        json_error('This job is closed.', 422);
    }
    $record = tech_maintenance_record_for_job($job, true);
    $pdo->prepare('SELECT id FROM maintenance_records WHERE id = :m FOR UPDATE')->execute([':m' => $record['id']]);
    $record = tech_maintenance_record_for_job($job, false);
    if ($why = maint_edit_blocker($record)) {
        $pdo->rollBack();
        json_error($why, 409);
    }
    $items = $pdo->prepare('SELECT item_key, description, status FROM maintenance_items WHERE maintenance_id = :m');
    $items->execute([':m' => $record['id']]);
    $rows = array_map(function ($i) {
        $i['category'] = tech_maintenance_category($i['item_key'], $i['description']);
        return $i;
    }, $items->fetchAll());
    $sections = maint_section_status($record, $rows, maint_photo_counts((int)$record['id']) ?? []);
    if ($why = maint_submit_blocker($record, $sections)) {
        $pdo->rollBack();
        json_error($why, 422);
    }
    $pdo->prepare(
        "UPDATE maintenance_records
         SET review_status = 'SUBMITTED', submitted_at = NOW(), submitted_by = :u, submit_note = :n,
             reviewed_at = NULL, reviewed_by = NULL, review_note = NULL, status = 'IN_PROGRESS'
         WHERE id = :m"
    )->execute([':u' => current_user_id(), ':n' => $note !== '' ? $note : null, ':m' => $record['id']]);
    $pdo->prepare('UPDATE jobs SET updated_at = CURRENT_TIMESTAMP WHERE id = :j')->execute([':j' => $job['id']]);
    $pdo->commit();
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('SunTrack maintenance submit: ' . $e->getMessage());
    json_error('The inspection could not be submitted. Please try again.', 500);
}

audit_log('MAINT_SUBMIT', 'maintenance_records', $job['job_code']);
foreach (install_plan_manager_ids() as $uid) {
    notify($uid, 'MAINTENANCE_REVIEW', "{$job['job_code']}: the maintenance inspection is ready for your review"
        . ($note !== '' ? ' — "' . str_cut($note, 0, 120) . '"' : '') . '.', 'jobs', (int)$job['id']);
}
json_success(['review_status' => 'SUBMITTED'], 'Inspection submitted. Management will review it — you will be notified.');
