<?php
/**
 * GET /api/maintenance/get.php?job_id=N
 *
 * The maintenance inspection for one of the technician's own MAINTENANCE jobs,
 * using the existing maintenance_records / maintenance_items tables. The record
 * (and its six inspection items) is created on first open if it does not exist
 * yet — no new tables, no duplicate structures.
 *
 * Inspection categories are exactly the ones the source requirements define:
 * Solar Panels, Battery, Inverter.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed.', 405);
}

$jobId = (int)($_GET['job_id'] ?? 0);
$job   = tech_job_or_fail($jobId);

if ($job['job_type'] !== 'MAINTENANCE') {
    json_error('This job is not a maintenance job.', 422);
}

$pdo = db();

// Read-only for closed jobs; created on demand for open ones.
$record = tech_maintenance_record_for_job($job, !tech_stage_is_closed($job['stage']));
if (!$record) {
    json_success([
        'job'      => ['id' => (int)$job['id'], 'job_code' => $job['job_code'], 'stage' => $job['stage']],
        'record'   => null,
        'items'    => [],
        'editable' => false,
    ], 'No maintenance record exists for this closed job.');
}

$ready = maint_review_ready();
$itemsStmt = $pdo->prepare($ready
    ? 'SELECT mi.id, mi.item_key, mi.description, mi.status, mi.remarks, mi.completed_at AS completed_date, u.full_name AS completed_by_name
       FROM maintenance_items mi LEFT JOIN users u ON u.id = mi.completed_by
       WHERE mi.maintenance_id = :m ORDER BY mi.id ASC'
    : 'SELECT id, item_key, description, status, remarks FROM maintenance_items
       WHERE maintenance_id = :m ORDER BY id ASC'
);
$itemsStmt->execute([':m' => $record['id']]);
$items = [];
foreach ($itemsStmt->fetchAll() as $it) {
    $it['category'] = tech_maintenance_category($it['item_key'], $it['description']);
    $items[] = $it;
}

$sections = $ready ? maint_section_status($record, $items, maint_photo_counts((int)$record['id']) ?? []) : [];
$reviewer = null;
if ($ready && $record['reviewed_by']) {
    $rv = $pdo->prepare('SELECT full_name FROM users WHERE id = :id');
    $rv->execute([':id' => $record['reviewed_by']]);
    $reviewer = $rv->fetchColumn() ?: null;
}

$sysStmt = $pdo->prepare(
    'SELECT system_code, panel_brand, inverter_brand, battery_brand, capacity_kw,
            installation_date, warranty_info, status
     FROM solar_systems WHERE client_id = :c ORDER BY id DESC LIMIT 1'
);
$sysStmt->execute([':c' => $job['client_id']]);

json_success([
    'job' => [
        'id'             => (int)$job['id'],
        'job_code'       => $job['job_code'],
        'stage'          => $job['stage'],
        'progress'       => (int)$job['progress'],
        'priority'       => $job['priority'],
        'scheduled_date' => $job['scheduled_date'],
        'description'    => $job['description'],
        'site_address'   => $job['site_address'],
        'is_closed'      => tech_stage_is_closed($job['stage']),
        'allowed_next'   => tech_allowed_next($job['stage']),
    ],
    'client' => [
        'name'        => $job['client_name'],
        'client_code' => $job['client_code'],
        'phone'       => $job['client_phone'],
        'address'     => $job['client_address'],
    ],
    'solar_system' => $sysStmt->fetch() ?: null,
    'record' => [
        'id'                    => (int)$record['id'],
        'status'                => $record['status'],
        'panel_condition'       => $record['panel_condition'],
        'battery_condition'     => $record['battery_condition'],
        'inverter_condition'    => $record['inverter_condition'],
        'electrical_condition'  => $record['electrical_condition'],
        'inspection_results'    => $record['inspection_results'],
        'materials_used'        => $record['materials_used'],
        'issues_found'          => $record['issues_found'],
        'remarks'               => $record['remarks'],
        'completion_date'       => $record['completion_date'],
    ],
    'counts'          => tech_maintenance_counts((int)$record['id']),
    'condition_values'=> ['Good', 'Fair', 'Poor'],
    'categories'      => array_keys(tech_maintenance_sections()),
    'items'           => $items,
    'editable'        => !tech_stage_is_closed($job['stage']),
    'completion_blocker' => tech_maintenance_blocker($job),
    // Phase 20 — the installation-style checklist: sections with proof photos,
    // submitted to Management for review.
    'checklist_ready' => $ready,
    'sections'        => $sections,
    'photos'          => maint_photos_list((int)$record['id']),
    'photo_max_per_section' => MAINTENANCE_PHOTO_MAX_PER_SECTION,
    'review'          => $ready ? [
        'status' => $record['review_status'], 'submitted_at' => $record['submitted_at'], 'submit_note' => $record['submit_note'],
        'reviewed_at' => $record['reviewed_at'], 'review_note' => $record['review_note'], 'reviewed_by_name' => $reviewer,
    ] : null,
    'locked'          => $ready ? maint_edit_blocker($record) : null,
    'submit_blocker'  => $ready ? maint_submit_blocker($record, $sections) : null,
    'is_lead'         => !empty($job['is_lead']),
]);
