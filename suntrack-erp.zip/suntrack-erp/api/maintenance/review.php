<?php
/**
 * POST /api/maintenance/review.php — Management only.
 * Body: { job_id, decision: APPROVE | RETURN, note?, csrf_token }
 *
 * The decision on a submitted maintenance inspection, as for an installation
 * stage. APPROVE: the technician can file the work report and complete the
 * job. RETURN (note required — it is what the technician reads): the
 * inspection opens again for fixing and resubmitting.
 */
require_once __DIR__ . '/../../config/config.php';
require_management();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
$input = json_input();
require_csrf($input);
require_fields($input, ['job_id', 'decision']);
if (!maint_review_ready()) {
    json_error('Maintenance review is not set up yet. Run database/phase20_maintenance_checklist.sql.', 503);
}
$decision = strtoupper(trim((string)$input['decision']));
if (!in_array($decision, ['APPROVE', 'RETURN'], true)) {
    json_error('Decision must be APPROVE or RETURN.', 422);
}
$note = trim((string)($input['note'] ?? ''));
if (str_len($note) > 500) {
    json_error('The note is limited to 500 characters.', 422);
}
if ($decision === 'RETURN' && $note === '') {
    json_error('Write what the technician needs to fix.', 422);
}

$pdo = db();
$pdo->beginTransaction();
try {
    $j = $pdo->prepare('SELECT * FROM jobs WHERE id = :id FOR UPDATE');
    $j->execute([':id' => (int)$input['job_id']]);
    $job = $j->fetch();
    if (!$job || $job['job_type'] !== 'MAINTENANCE') {
        $pdo->rollBack();
        json_error('Maintenance job not found.', 404);
    }
    $r = $pdo->prepare('SELECT * FROM maintenance_records WHERE job_id = :j ORDER BY id DESC LIMIT 1 FOR UPDATE');
    $r->execute([':j' => $job['id']]);
    $record = $r->fetch();
    if (!$record || $record['review_status'] !== 'SUBMITTED') {
        $pdo->rollBack();
        json_error('This inspection is not waiting for review' . ($record ? ' (it is ' . strtolower($record['review_status']) . ').' : '.'), 409);
    }
    $pdo->prepare('UPDATE maintenance_records SET review_status = :s, reviewed_at = NOW(), reviewed_by = :u, review_note = :n WHERE id = :m')
        ->execute([':s' => $decision === 'APPROVE' ? 'APPROVED' : 'RETURNED', ':u' => current_user_id(),
                   ':n' => $note !== '' ? $note : null, ':m' => $record['id']]);
    $pdo->prepare('UPDATE jobs SET updated_at = CURRENT_TIMESTAMP WHERE id = :j')->execute([':j' => $job['id']]);
    $pdo->commit();
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('SunTrack maintenance review: ' . $e->getMessage());
    json_error('The decision could not be saved. Please try again.', 500);
}

audit_log('MAINT_REVIEW:' . $decision, 'maintenance_records', $job['job_code']);
if ($job['technician_id']) {
    $t = $pdo->prepare('SELECT user_id FROM technicians WHERE id = :id');
    $t->execute([':id' => $job['technician_id']]);
    if ($uid = $t->fetchColumn()) {
        notify((int)$uid, 'MAINTENANCE_REVIEW', $decision === 'APPROVE'
            ? "{$job['job_code']}: your maintenance inspection was approved. File the work report and complete the job."
            : "{$job['job_code']}: your maintenance inspection was returned — {$note}", 'jobs', (int)$job['id']);
    }
}
json_success(['review_status' => $decision === 'APPROVE' ? 'APPROVED' : 'RETURNED'],
    $decision === 'APPROVE' ? 'Inspection approved. The technician can now complete the job.' : 'Inspection returned to the technician with your note.');
