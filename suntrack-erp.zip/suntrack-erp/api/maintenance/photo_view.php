<?php
/**
 * GET /api/maintenance/photo_view.php?id=N — streams one maintenance proof
 * photo to someone allowed to see its job (the technician on it, its client,
 * Management, Admin).
 */
require_once __DIR__ . '/../../config/config.php';
field_mode_enter(true); // a subcontractor sees its own job's photos through the field portal
require_login(true);

if (!maint_review_ready()) {
    json_error('Photo not found.', 404);
}
$stmt = db()->prepare('SELECT job_id, file_name, mime FROM maintenance_photos WHERE id = :id');
$stmt->execute([':id' => (int)($_GET['id'] ?? 0)]);
$photo = $stmt->fetch();
if (!$photo) {
    json_error('Photo not found.', 404);
}
job_access_or_fail((int)$photo['job_id']);
storage_send('maintenance_photos', $photo['file_name'], $photo['mime']);
