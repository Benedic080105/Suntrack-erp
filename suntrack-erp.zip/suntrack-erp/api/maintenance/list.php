<?php
/**
 * Maintenance Reminders — READ-ONLY summary endpoint.
 * Reminder scheduling/notification actions are not implemented yet
 * ("soon"); this only surfaces existing data for the view-only Admin tab.
 */
require_once __DIR__ . '/../../middleware/admin.php';

maintenance_refresh_statuses(); // keep DUE/OVERDUE current as days pass
$pdo = db();
[$pageLimit, $pageOffset] = list_page(500);
$where = [];
$params = [];

if ($clause = search_clause($_GET['search'] ?? '', search_columns('maintenance'), $params)) {
    $where[] = $clause;
}
apply_date_range('ms.next_maintenance', $where, $params);
if (!empty($_GET['status'])) {
    $where[] = 'ms.status = :status';
    $params[':status'] = $_GET['status'];
}
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$sql = "SELECT ms.id, ms.project_id, p.project_code, p.site_name, cu.full_name AS client_name,
               ms.last_maintenance, ms.next_maintenance, ms.status, ms.client_notified, ms.notified_at
        FROM maintenance_schedules ms
        JOIN projects p ON p.id = ms.project_id
        JOIN clients c ON c.id = p.client_id
        JOIN users cu ON cu.id = c.user_id
        $whereSql
        ORDER BY ms.next_maintenance ASC, ms.id ASC
        " . list_page_sql($pageLimit, $pageOffset);
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = list_page_finish($stmt->fetchAll(), $pageLimit, $pageOffset);

$total    = (int)$pdo->query("SELECT COUNT(*) FROM maintenance_schedules")->fetchColumn();
$upcoming = (int)$pdo->query("SELECT COUNT(*) FROM maintenance_schedules WHERE status='UPCOMING'")->fetchColumn();
$due      = (int)$pdo->query("SELECT COUNT(*) FROM maintenance_schedules WHERE status='DUE'")->fetchColumn();
$overdue  = (int)$pdo->query("SELECT COUNT(*) FROM maintenance_schedules WHERE status='OVERDUE'")->fetchColumn();

$byStatus = $pdo->query(
    "SELECT status AS label, COUNT(*) AS total FROM maintenance_schedules GROUP BY status ORDER BY FIELD(status,'OVERDUE','DUE','UPCOMING')"
)->fetchAll();

// Maintenance inspections submitted by technicians and waiting for a decision.
$reviews = [];
if (maint_review_ready()) {
    $reviews = $pdo->query(
        "SELECT mr.job_id, j.job_code, cu.full_name AS client_name, mr.submitted_at
         FROM maintenance_records mr JOIN jobs j ON j.id = mr.job_id
         JOIN clients c ON c.id = j.client_id JOIN users cu ON cu.id = c.user_id
         WHERE mr.review_status = 'SUBMITTED' ORDER BY mr.submitted_at ASC LIMIT 50"
    )->fetchAll();
}

json_success([
    'rows' => $rows,
    'pending_reviews' => $reviews,
    'stats' => [
        'total' => $total,
        'upcoming' => $upcoming,
        'due' => $due,
        'overdue' => $overdue,
    ],
    'chart' => [
        'labels' => array_map(fn($r) => $r['label'], $byStatus),
        'values' => array_map(fn($r) => (int)$r['total'], $byStatus),
    ],
]);
