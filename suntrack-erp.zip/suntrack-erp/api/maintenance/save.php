<?php
/**
 * POST /api/maintenance/save.php
 *
 * Save the inspection findings for a maintenance job: panel / battery /
 * inverter (and electrical) condition, inspection results, materials used,
 * issues found and remarks. Writes to the existing maintenance_records row.
 *
 * Conditions are constrained to the table's own ENUM ('Good','Fair','Poor').
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['job_id']);

$job = tech_job_or_fail((int)$input['job_id']);

if ($job['job_type'] !== 'MAINTENANCE') {
    json_error('This job is not a maintenance job.', 422);
}
if (tech_stage_is_closed($job['stage'])) {
    json_error('This job is closed — the inspection can no longer be edited.', 422);
}

$record = tech_maintenance_record_for_job($job, true);
if (!$record) {
    json_error('Unable to open a maintenance record for this job.', 500);
}
if ($why = maint_edit_blocker($record)) {
    json_error($why, 422);
}

$conditions = ['Good', 'Fair', 'Poor'];
$fields = [
    'panel_condition'      => 'enum',
    'battery_condition'    => 'enum',
    'inverter_condition'   => 'enum',
    'electrical_condition' => 'enum',
    'inspection_results'   => 'text',
    'materials_used'       => 'text',
    'issues_found'         => 'text',
    'remarks'              => 'text',
];

$set    = [];
$params = [':id' => $record['id']];

foreach ($fields as $field => $type) {
    if (!array_key_exists($field, $input)) {
        continue;
    }
    $value = $input[$field];

    if ($type === 'enum') {
        $value = trim((string)$value);
        if ($value === '') {
            $value = null;
        } elseif (!in_array($value, $conditions, true)) {
            json_error('Invalid value for ' . str_replace('_', ' ', $field) . '. Use Good, Fair or Poor.', 422);
        }
    } else {
        $value = trim((string)$value);
        if (str_len($value) > 4000) {
            json_error(ucfirst(str_replace('_', ' ', $field)) . ' is too long.', 422);
        }
        $value = $value !== '' ? $value : null;
    }

    $set[] = "$field = :$field";
    $params[":$field"] = $value;
}

if (!$set) {
    json_error('Nothing to save.', 422);
}

// Any saved finding moves the record out of PENDING.
$set[] = 'status = IF(status = "COMPLETED", "COMPLETED", "IN_PROGRESS")';
$set[] = 'technician_id = :tech';
$params[':tech'] = current_profile_id();

db()->prepare('UPDATE maintenance_records SET ' . implode(', ', $set) . ' WHERE id = :id')->execute($params);

audit_log('SAVE_MAINTENANCE', 'maintenance_records', $job['job_code']);

json_success([
    'record_id'          => (int)$record['id'],
    'counts'             => tech_maintenance_counts((int)$record['id']),
    'completion_blocker' => tech_maintenance_blocker($job),
], 'Inspection saved.');
