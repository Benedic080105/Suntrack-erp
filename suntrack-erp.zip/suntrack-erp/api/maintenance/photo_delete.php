<?php
/**
 * POST /api/maintenance/photo_delete.php
 * Body: { photo_id, csrf_token }
 * The technician removes one of the inspection's proof photos — only while the
 * job is open and the inspection is not submitted / approved.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
$input = json_input();
require_csrf($input);
require_fields($input, ['photo_id']);
if (!maint_review_ready()) {
    json_error('Maintenance photos are not set up yet.', 503);
}

$pdo = db();
$stmt = $pdo->prepare('SELECT id, maintenance_id, job_id, section, file_name FROM maintenance_photos WHERE id = :id');
$stmt->execute([':id' => (int)$input['photo_id']]);
$photo = $stmt->fetch();
if (!$photo) {
    json_error('Photo not found.', 404);
}
$job = tech_job_or_fail((int)$photo['job_id']);
if (tech_stage_is_closed($job['stage'])) {
    json_error('This job is closed — its photos can no longer be changed.', 422);
}
$rec = $pdo->prepare('SELECT * FROM maintenance_records WHERE id = :m');
$rec->execute([':m' => $photo['maintenance_id']]);
if ($why = maint_edit_blocker($rec->fetch() ?: [])) {
    json_error($why, 422);
}

$pdo->prepare('DELETE FROM maintenance_photos WHERE id = :id')->execute([':id' => $photo['id']]);
storage_delete('maintenance_photos', $photo['file_name']);
audit_log('MAINT_PHOTO_DELETE:' . $photo['section'], 'maintenance_records', $job['job_code']);

json_success([], 'Photo removed.');
