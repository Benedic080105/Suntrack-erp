<?php
/**
 * POST /api/maintenance/schedule.php
 * Management only. Fills the gap flagged in maintenance/list.php: schedule,
 * reschedule, assign a technician to, or notify the client about upcoming
 * maintenance for a project.
 *
 * Body:
 *   project_id       int     required
 *   action           string  required — SCHEDULE | RESCHEDULE | ASSIGN | NOTIFY
 *   next_maintenance date    required for SCHEDULE / RESCHEDULE (YYYY-MM-DD)
 *   technician_id    int     required for ASSIGN
 *
 * SCHEDULE / RESCHEDULE upsert the project's maintenance_schedules row and
 * recompute status from next_maintenance (OVERDUE if past, DUE within 14
 * days, else UPCOMING).
 * ASSIGN creates a MAINTENANCE job for the project (so it appears in the
 * technician's My Assignments, the same way service_requests/assign.php
 * does for repairs) and notifies the technician.
 * NOTIFY flags the schedule as client_notified and sends the client a
 * notification.
 */
require_once __DIR__ . '/../../config/config.php';
require_management();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['project_id', 'action']);

$projectId = (int)$input['project_id'];
$action    = strtoupper($input['action']);
$validActions = ['SCHEDULE', 'RESCHEDULE', 'ASSIGN', 'NOTIFY'];
if (!in_array($action, $validActions, true)) {
    json_error('action must be one of: ' . implode(', ', $validActions), 422);
}

$pdo = db();

$projStmt = $pdo->prepare(
    'SELECT p.id, p.project_code, p.site_name, p.address, p.client_id, c.city
     FROM projects p JOIN clients c ON c.id = p.client_id WHERE p.id = :id'
);
$projStmt->execute([':id' => $projectId]);
$project = $projStmt->fetch();
if (!$project) {
    json_error('Project not found.', 404);
}

function maintenance_status_for(string $nextDate): string
{
    $days = (strtotime($nextDate) - strtotime(date('Y-m-d'))) / 86400;
    if ($days < 0) {
        return 'OVERDUE';
    }
    if ($days <= 14) {
        return 'DUE';
    }
    return 'UPCOMING';
}

if ($action === 'SCHEDULE' || $action === 'RESCHEDULE') {
    require_fields($input, ['next_maintenance']);
    $nextDate = $input['next_maintenance'];
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $nextDate)) {
        json_error('next_maintenance must be in YYYY-MM-DD format.', 422);
    }
    $status = maintenance_status_for($nextDate);

    if ($action === 'RESCHEDULE') {
        $existingStmt = $pdo->prepare('SELECT id FROM maintenance_schedules WHERE project_id = :p');
        $existingStmt->execute([':p' => $projectId]);
        if (!$existingStmt->fetchColumn()) {
            json_error('No existing maintenance schedule to reschedule — use action SCHEDULE first.', 422);
        }
    }

    // Atomic upsert — relies on the unique key on project_id added by
    // database/phase2_management_migration.sql, so two concurrent requests
    // for the same project can never create two rows.
    $pdo->prepare(
        'INSERT INTO maintenance_schedules (project_id, next_maintenance, status)
         VALUES (:p, :n, :s)
         ON DUPLICATE KEY UPDATE next_maintenance = VALUES(next_maintenance), status = VALUES(status)'
    )->execute([':p' => $projectId, ':n' => $nextDate, ':s' => $status]);

    audit_log($action === 'SCHEDULE' ? 'SCHEDULE' : 'RESCHEDULE', 'maintenance_schedules', $project['project_code']);
    json_success(['next_maintenance' => $nextDate, 'status' => $status], 'Maintenance schedule saved.');
}

if ($action === 'ASSIGN') {
    require_fields($input, ['technician_id']);
    $techId = (int)$input['technician_id'];

    $techStmt = $pdo->prepare('SELECT t.id, u.full_name FROM ' . tech_staff_table() . ' t JOIN users u ON u.id = t.user_id WHERE t.id = :id');
    $techStmt->execute([':id' => $techId]);
    $tech = $techStmt->fetch();
    if (!$tech) {
        json_error('Technician not found.', 404);
    }

    $jobId = null;
    $jobCode = null;

    $pdo->beginTransaction();
    try {
        // Inherit the client's plotted site, or the technician can never Time In.
        [$siteLat, $siteLng, $radius] = client_site_location((int)$project['client_id']);

        $jobStmt = $pdo->prepare(
            'INSERT INTO jobs (job_code, project_id, client_id, technician_id, job_type, site_address, site_lat, site_lng, geofence_radius_m, priority, description, stage, progress)
             VALUES (:code, :project_id, :client_id, :tech_id, "MAINTENANCE", :addr, :lat, :lng, :radius, "NORMAL", :desc, "ASSIGNED", 0)'
        );
        [$jobId, $jobCode] = insert_job_with_code(fn(string $code) => $jobStmt->execute([
            ':code'       => $code,
            ':project_id' => $projectId,
            ':client_id'  => $project['client_id'],
            ':tech_id'    => $techId,
            ':addr'       => trim(($project['address'] ?? '') . ', ' . ($project['city'] ?? '')),
            ':lat'        => $siteLat,
            ':lng'        => $siteLng,
            ':radius'     => $radius,
            ':desc'       => 'Scheduled maintenance for ' . $project['site_name'],
        ]));

        $pdo->prepare('INSERT INTO job_status_history (job_id, from_stage, to_stage, changed_by, note) VALUES (:j, NULL, "ASSIGNED", :u, "Maintenance scheduled by Management")')
            ->execute([':j' => $jobId, ':u' => current_user_id()]);

        $pdo->commit();
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        json_error('Failed to assign maintenance job.', 500);
    }

    audit_log('ASSIGN', 'maintenance_schedules', $project['project_code']);

    $techUserStmt = $pdo->prepare('SELECT user_id FROM technicians WHERE id = :id');
    $techUserStmt->execute([':id' => $techId]);
    $techUserId = $techUserStmt->fetchColumn();
    if ($techUserId) {
        notify((int)$techUserId, 'JOB_STATUS', "New maintenance job assigned to you: $jobCode.", 'jobs', $jobId);
    }

    json_success(['job_id' => $jobId, 'job_code' => $jobCode], 'Technician assigned to maintenance.');
}

if ($action === 'NOTIFY') {
    $existingStmt = $pdo->prepare('SELECT id, next_maintenance FROM maintenance_schedules WHERE project_id = :p');
    $existingStmt->execute([':p' => $projectId]);
    $schedule = $existingStmt->fetch();
    if (!$schedule) {
        json_error('This project has no maintenance schedule yet.', 422);
    }

    $pdo->prepare('UPDATE maintenance_schedules SET client_notified = 1, notified_at = NOW() WHERE id = :id')
        ->execute([':id' => $schedule['id']]);

    audit_log('NOTIFY', 'maintenance_schedules', $project['project_code']);

    $clientUserStmt = $pdo->prepare('SELECT user_id FROM clients WHERE id = :id');
    $clientUserStmt->execute([':id' => $project['client_id']]);
    $clientUserId = $clientUserStmt->fetchColumn();
    if ($clientUserId) {
        notify(
            (int)$clientUserId,
            'MAINTENANCE_DUE',
            "Your maintenance schedule has been updated. Next visit: {$schedule['next_maintenance']}.",
            'maintenance_schedules',
            (int)$schedule['id']
        );
    }

    json_success([], 'Client notified.');
}
