<?php
/**
 * GET /api/work_reports/list.php
 *
 * Technicians see ONLY their own reports — the filter is applied from the
 * session, so no query string can widen the scope. Admin / manager / staff see
 * everything. Any other role is refused.
 *
 * Optional: ?search= ?job_id= ?id=
 */
require_once __DIR__ . '/../../config/config.php';
field_mode_enter(true); // a subcontractor uses this through the field portal
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed.', 405);
}

$role   = current_role();
$pdo    = db();
[$pageLimit, $pageOffset] = list_page(200);
$where  = [];
$params = [];

if ($role === 'technician') {
    $where[] = 'wr.technician_id = :tech_id';
    $params[':tech_id'] = current_profile_id();
} elseif (!in_array($role, ['admin', 'manager', 'staff'], true)) {
    json_error('You are not authorized to view work reports.', 403);
}

if ($clause = search_clause($_GET['search'] ?? '', search_columns('work_reports'), $params)) {
    $where[] = $clause;
}
apply_date_range('wr.submitted_date', $where, $params);
if (!empty($_GET['job_id'])) {
    $where[] = 'wr.job_id = :job_id';
    $params[':job_id'] = (int)$_GET['job_id'];
}
if (!empty($_GET['id'])) {
    $where[] = 'wr.id = :id';
    $params[':id'] = (int)$_GET['id'];
}

$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$sql = "SELECT wr.id, wr.report_code, wr.job_id, wr.work_type, wr.remarks, wr.materials_used,
               wr.issues_found, wr.duration_text, wr.duration_minutes, wr.status, wr.submitted_date, wr.created_at,
               j.job_code, j.job_type, j.site_address, j.scheduled_date,
               tu.full_name AS technician_name, t.technician_code,
               cu.full_name AS client_name, c.client_code
        FROM work_reports wr
        JOIN jobs j        ON j.id = wr.job_id
        JOIN technicians t ON t.id = wr.technician_id
        JOIN users tu      ON tu.id = t.user_id
        JOIN clients c     ON c.id = wr.client_id
        JOIN users cu      ON cu.id = c.user_id
        $whereSql
        ORDER BY wr.submitted_date DESC, wr.id DESC
        " . list_page_sql($pageLimit, $pageOffset);

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = list_page_finish($stmt->fetchAll(), $pageLimit, $pageOffset);

// Technicians also get the list of their completed jobs that still need a report.
$pending = [];
if ($role === 'technician') {
    $pendStmt = $pdo->prepare(
        "SELECT j.id, j.job_code, j.job_type, j.updated_at, cu.full_name AS client_name, c.client_code
         FROM jobs j
         JOIN clients c ON c.id = j.client_id
         JOIN users cu  ON cu.id = c.user_id
         WHERE j.technician_id = :t AND j.stage = 'COMPLETED'
           AND NOT EXISTS (SELECT 1 FROM work_reports wr2 WHERE wr2.job_id = j.id)
         ORDER BY j.updated_at DESC LIMIT 50"
    );
    $pendStmt->execute([':t' => current_profile_id()]);
    $pending = $pendStmt->fetchAll();
}

json_success(['rows' => $rows, 'pending_jobs' => $pending, 'total' => count($rows)]);
