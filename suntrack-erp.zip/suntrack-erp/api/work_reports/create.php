<?php
/**
 * POST /api/work_reports/create.php
 *
 * A technician files the work report for one of their own jobs — while it
 * is In Progress / Paused (the report is now required BEFORE the job can be
 * completed), or for a job completed before that rule existed.
 * One report per job, enforced both here and by a unique index on
 * work_reports.job_id, so a double-clicked Submit button can never create two.
 * Before/after photos are no longer part of the report.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['job_id', 'work_type', 'remarks']);

$techId = (int)current_profile_id();
$job    = tech_job_or_fail((int)$input['job_id']);
tech_require_lead($job); // one report per job, filed by the lead

if (!in_array($job['stage'], ['IN_PROGRESS', 'PAUSED', 'COMPLETED'], true)) {
    json_error('Start the work (In Progress) before filing its work report.', 422);
}

$workType = trim((string)$input['work_type']);
$remarks  = trim((string)$input['remarks']);

if (!in_array($workType, ['Installation', 'Maintenance', 'Repair', 'Inspection'], true)) {
    json_error('Invalid work type.', 422);
}
if (str_len($remarks) < 5) {
    json_error('Please summarise the work performed (at least 5 characters).', 422);
}

// Duration is free text ("2 hours 30 mins", "1.5 hrs", "half day"...), kept as
// typed. Minutes are worked out from it when it reads as a time, for averages.
// Older app versions still send duration_minutes as a number.
$durationText = trim((string)($input['duration'] ?? $input['duration_minutes'] ?? ''));
if (str_len($durationText) > 100) {
    json_error('Duration is limited to 100 characters.', 422);
}
$durationText = $durationText !== '' ? $durationText : null;
$duration = work_duration_minutes($durationText);

$pdo = db();

$existsStmt = $pdo->prepare('SELECT report_code FROM work_reports WHERE job_id = :j');
$existsStmt->execute([':j' => $job['id']]);
if ($existing = $existsStmt->fetchColumn()) {
    json_error('A work report (' . $existing . ') has already been submitted for this job.', 409);
}

try {
    $stmt = $pdo->prepare(
        'INSERT INTO work_reports
            (report_code, job_id, technician_id, client_id, work_type, remarks, materials_used, issues_found, duration_text, duration_minutes, status, submitted_date)
         VALUES (:code, :job, :tech, :client, :work_type, :remarks, :materials, :issues, :duration_text, :duration, "SUBMITTED", NOW())'
    );
    // Next code from the highest existing numeric suffix, retried if two
    // technicians submit at the same moment and draw the same number.
    $reportCode = with_unique_code('work_reports', 'report_code', 'WR-', function (string $code) use ($stmt, $job, $techId, $workType, $remarks, $input, $duration, $durationText) {
        $stmt->execute([
            ':code'      => $code,
            ':job'       => $job['id'],
            ':tech'      => $techId,
            ':client'    => $job['client_id'],
            ':work_type' => $workType,
            ':remarks'   => $remarks,
            ':materials' => trim((string)($input['materials_used'] ?? '')) ?: null,
            ':issues'    => trim((string)($input['issues_found'] ?? '')) ?: null,
            ':duration_text' => $durationText,
            ':duration'  => $duration,
        ]);
        return $code;
    }, pad: 4);
} catch (PDOException $e) {
    // 23000 here = the one-report-per-job unique index caught a race
    // (a report_code collision is retried inside with_unique_code instead).
    if ($e->getCode() === '23000') {
        json_error('A work report has already been submitted for this job.', 409);
    }
    json_error('Failed to submit the work report.', 500);
}

$reportId = (int)$pdo->lastInsertId();

audit_log('CREATE', 'work_reports', $reportCode);

$adminUsers = $pdo->query(
    "SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id WHERE r.role_key IN ('admin','manager','staff')"
)->fetchAll();
foreach ($adminUsers as $u) {
    notify((int)$u['id'], 'WORK_REPORT', "Work report $reportCode submitted for {$job['job_code']}.", 'work_reports', $reportId);
}

json_success([
    'report_id'   => $reportId,
    'report_code' => $reportCode,
    'job_code'    => $job['job_code'],
], 'Work report ' . $reportCode . ' submitted.');
