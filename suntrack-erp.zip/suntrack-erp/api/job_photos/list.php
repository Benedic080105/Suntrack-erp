<?php
/**
 * GET /api/job_photos/list.php?job_id=N
 *
 * A job's before/after photos. Technician (own job), client (own job),
 * Management and Admin (any job).
 */
require_once __DIR__ . '/../../config/config.php';
require_login(true);

$job = job_access_or_fail((int)($_GET['job_id'] ?? 0));

json_success([
    'photos'           => job_photos_list((int)$job['id']),
    'counts'           => job_photo_counts((int)$job['id']),
    'requires_photos'  => work_report_requires_photos(),
    'has_report'       => job_has_report((int)$job['id']),
]);
