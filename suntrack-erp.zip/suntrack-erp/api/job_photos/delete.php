<?php
/**
 * POST /api/job_photos/delete.php  { photo_id }
 *
 * A technician removes a wrong photo from their own job — only until the work
 * report is filed; after that the photos are part of the record.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
$input = json_input();
require_csrf($input);
require_fields($input, ['photo_id']);

$stmt = db()->prepare('SELECT id, job_id, file_name FROM job_photos WHERE id = :id');
$stmt->execute([':id' => (int)$input['photo_id']]);
$photo = $stmt->fetch();
if (!$photo) {
    json_error('Photo not found.', 404);
}
$job = tech_job_or_fail((int)$photo['job_id']);
if (job_has_report((int)$job['id'])) {
    json_error('The work report is already filed, so its photos can no longer be removed.', 422);
}

db()->prepare('DELETE FROM job_photos WHERE id = :id')->execute([':id' => $photo['id']]);
storage_delete('job_photos', $photo['file_name']);
audit_log('PHOTO_DELETE', 'jobs', $job['job_code']);

json_success(['counts' => job_photo_counts((int)$job['id'])], 'Photo removed.');
