<?php
/**
 * GET /api/job_photos/view.php?id=N — streams one photo to someone allowed to
 * see its job (technician on it, its client, Management, Admin).
 */
require_once __DIR__ . '/../../config/config.php';
require_login(true);

$stmt = db()->prepare('SELECT job_id, file_name, mime FROM job_photos WHERE id = :id');
$stmt->execute([':id' => (int)($_GET['id'] ?? 0)]);
$photo = $stmt->fetch();
if (!$photo) {
    json_error('Photo not found.', 404);
}
job_access_or_fail((int)$photo['job_id']);
storage_send('job_photos', $photo['file_name'], $photo['mime']);
