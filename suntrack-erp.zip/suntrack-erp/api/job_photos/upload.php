<?php
/**
 * POST /api/job_photos/upload.php   (multipart/form-data)
 *
 * A technician adds a BEFORE or AFTER photo to one of their own jobs.
 * Fields: csrf_token, job_id, kind (BEFORE|AFTER), photo (file)
 *
 * Allowed while the job is in the field, or after completion only if the work
 * report has not been filed yet (jobs completed before photos existed). Once a
 * report is filed the photos are part of the record and are locked.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
// An upload larger than post_max_size arrives with an empty $_POST — say so
// plainly instead of reporting a missing security token.
if (empty($_POST) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    json_error('That photo is too large (max 8 MB).', 413);
}
require_csrf($_POST);
require_fields($_POST, ['job_id', 'kind']);

$kind = strtoupper(trim((string)$_POST['kind']));
if (!in_array($kind, ['BEFORE', 'AFTER'], true)) {
    json_error('Photo type must be BEFORE or AFTER.', 422);
}

$job = tech_job_or_fail((int)$_POST['job_id']);
$jobId = (int)$job['id'];

// Once the report is filed its photos are part of the record — locked,
// whatever stage the job is in.
if (job_has_report($jobId)) {
    json_error('Photos can no longer be added to this job — its work report is already filed.', 422);
}
if (!in_array($job['stage'], ['ASSIGNED', 'EN_ROUTE', 'ARRIVED', 'IN_PROGRESS', 'PAUSED', 'COMPLETED'], true)) {
    json_error('Photos cannot be added to a cancelled job.', 422);
}
if (job_photo_counts($jobId)[$kind] >= JOB_PHOTO_MAX_PER_KIND) {
    json_error('This job already has the maximum of ' . JOB_PHOTO_MAX_PER_KIND . ' ' . strtolower($kind) . ' photos.', 422);
}

[$name, $mime, $size, $w, $h] = store_uploaded_image($_FILES['photo'] ?? [], 'job_photos');

try {
    db()->prepare(
        'INSERT INTO job_photos (job_id, uploaded_by, kind, file_name, mime, size_bytes, width, height, created_at)
         VALUES (:j, :u, :k, :f, :m, :s, :w, :h, :t)'
    )->execute([
        ':j' => $jobId, ':u' => current_user_id(), ':k' => $kind, ':f' => $name,
        ':m' => $mime, ':s' => $size, ':w' => $w, ':h' => $h, ':t' => date('Y-m-d H:i:s'),
    ]);
} catch (PDOException $e) {
    storage_delete('job_photos', $name); // never leave an orphan file behind
    json_error('The photo could not be saved. Please try again.', 500);
}
$photoId = (int)db()->lastInsertId();

audit_log('PHOTO_UPLOAD', 'jobs', $job['job_code']);

json_success([
    'photo'  => ['id' => $photoId, 'kind' => $kind, 'url' => APP_BASE_URL . '/api/job_photos/view.php?id=' . $photoId],
    'counts' => job_photo_counts($jobId),
], ucfirst(strtolower($kind)) . ' photo added.');
