<?php
require_once __DIR__ . '/../../config/config.php';
require_management(); // Admin role is view/export only; only Management (manager/staff) may mutate.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['id']);

$id = (int)$input['id'];
$pdo = db();

$clientStmt = $pdo->prepare('SELECT c.*, u.id AS user_id FROM clients c JOIN users u ON u.id = c.user_id WHERE c.id = :id');
$clientStmt->execute([':id' => $id]);
$client = $clientStmt->fetch();
if (!$client) {
    json_error('Client not found.', 404);
}

$userFields = [];
$userParams = [':uid' => $client['user_id']];
foreach (['full_name', 'phone'] as $f) {
    if (isset($input[$f])) {
        $userFields[] = "$f = :$f";
        $userParams[":$f"] = trim($input[$f]);
    }
}
if ($userFields) {
    $pdo->prepare('UPDATE users SET ' . implode(', ', $userFields) . ' WHERE id = :uid')->execute($userParams);
}

if (!empty($input['new_password'])) {
    if (str_len($input['new_password']) < PASSWORD_MIN_LENGTH) {
        json_error('New password must be at least ' . PASSWORD_MIN_LENGTH . ' characters.', 422);
    }
    $pdo->prepare('UPDATE users SET password_hash = :h WHERE id = :uid')
        ->execute([':h' => password_hash($input['new_password'], PASSWORD_DEFAULT), ':uid' => $client['user_id']]);
    audit_log('RESET_PASSWORD', 'clients', $client['client_code']);
}

$clientFields = [];
$clientParams = [':id' => $id];
foreach (['address', 'city', 'province'] as $f) {
    if (isset($input[$f])) {
        $clientFields[] = "$f = :$f";
        $clientParams[":$f"] = trim($input[$f]);
    }
}

// Site coordinates. Sent together or not at all, so a partial submit cannot
// leave the record half-plotted.
if (array_key_exists('lat', $input) || array_key_exists('lng', $input)) {
    [$lat, $lng] = parse_coordinates($input['lat'] ?? null, $input['lng'] ?? null);
    $clientFields[] = 'lat = :lat';
    $clientFields[] = 'lng = :lng';
    $clientParams[':lat'] = $lat;
    $clientParams[':lng'] = $lng;
}

if (isset($input['geofence_radius_m']) && $input['geofence_radius_m'] !== '') {
    $radius = (int)$input['geofence_radius_m'];
    if ($radius < 20 || $radius > 20000) {
        json_error('Geofence radius must be between 20 and 20000 metres.', 422);
    }
    $clientFields[] = 'geofence_radius_m = :radius';
    $clientParams[':radius'] = $radius;
}
if ($clientFields) {
    $pdo->prepare('UPDATE clients SET ' . implode(', ', $clientFields) . ' WHERE id = :id')->execute($clientParams);
}

// Moving a client's pin should move the geofence on the work that has not
// happened yet. Jobs already completed keep the coordinates they were done
// under, because their attendance records were judged against those.
$propagated = 0;
if (!empty($input['apply_to_open_jobs']) && isset($lat) && $lat !== null) {
    $stmt = $pdo->prepare(
        "UPDATE jobs
         SET site_lat = :lat, site_lng = :lng
         WHERE client_id = :cid
           AND stage NOT IN ('COMPLETED', 'CANCELLED')"
    );
    $stmt->execute([':lat' => $lat, ':lng' => $lng, ':cid' => $id]);
    $propagated = $stmt->rowCount();

    if ($propagated > 0) {
        audit_log('GEOFENCE_PROPAGATE', 'jobs', $client['client_code'] . ' (' . $propagated . ' jobs)');
    }
}

audit_log('UPDATE', 'clients', $client['client_code']);

json_success([
    'jobs_updated' => $propagated,
], $propagated > 0
    ? sprintf('Client updated. Site location applied to %d open job%s.', $propagated, $propagated === 1 ? '' : 's')
    : 'Client updated.');
