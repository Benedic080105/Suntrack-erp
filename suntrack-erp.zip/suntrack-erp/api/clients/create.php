<?php
/**
 * POST /api/clients/create.php
 *
 * Creates a client login plus their client record.
 *
 * Coordinates are part of the client record now: jobs raised for this client
 * inherit them as the geofence centre, so plotting the site once here means
 * every future job is geofenced without anyone re-entering the location.
 */
require_once __DIR__ . '/../../config/config.php';
require_management(); // Admin role is view/export only; only Management (manager/staff) may mutate.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['full_name', 'email', 'password', 'phone', 'address', 'city']);

$email = trim(strtolower($input['email']));
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_error('Please enter a valid email address.', 422);
}
if (str_len($input['password']) < PASSWORD_MIN_LENGTH) {
    json_error('Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters.', 422);
}

// Optional site coordinates. Validated together so a half-filled pair is
// rejected rather than stored as a plausible-looking wrong location.
[$lat, $lng] = parse_coordinates($input['lat'] ?? null, $input['lng'] ?? null);

$radius = isset($input['geofence_radius_m']) && $input['geofence_radius_m'] !== ''
    ? (int)$input['geofence_radius_m']
    : geofence_default_radius();

if ($radius < 20 || $radius > 20000) {
    json_error('Geofence radius must be between 20 and 20000 metres.', 422);
}

$pdo = db();
$check = $pdo->prepare('SELECT id FROM users WHERE email = :e');
$check->execute([':e' => $email]);
if ($check->fetch()) {
    json_error('An account with this email already exists.', 409);
}

try {
    // The transaction wraps both inserts so a failed client row can never
    // leave an orphaned login behind.
    $code = with_unique_code('clients', 'client_code', 'CLIENT-', function (string $code) use ($pdo, $input, $email, $lat, $lng, $radius) {
        $pdo->beginTransaction();
        try {
            $roleId = $pdo->query("SELECT id FROM roles WHERE role_key = 'client'")->fetchColumn();

            $pdo->prepare(
                'INSERT INTO users (role_id, email, password_hash, full_name, phone, status)
                 VALUES (:role_id, :email, :hash, :name, :phone, "ACTIVE")'
            )->execute([
                ':role_id' => $roleId,
                ':email'   => $email,
                ':hash'    => password_hash($input['password'], PASSWORD_DEFAULT),
                ':name'    => trim($input['full_name']),
                ':phone'   => trim($input['phone']),
            ]);
            $userId = (int)$pdo->lastInsertId();

            $pdo->prepare(
                'INSERT INTO clients (user_id, client_code, address, city, province, lat, lng, geofence_radius_m, date_registered)
                 VALUES (:uid, :code, :addr, :city, :prov, :lat, :lng, :radius, CURDATE())'
            )->execute([
                ':uid'    => $userId,
                ':code'   => $code,
                ':addr'   => trim($input['address']),
                ':city'   => trim($input['city']),
                ':prov'   => trim($input['province'] ?? ''),
                ':lat'    => $lat,
                ':lng'    => $lng,
                ':radius' => $radius,
            ]);

            $pdo->commit();
            return $code;
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    });
} catch (PDOException $e) {
    json_error('Failed to create client.', 500);
} catch (Throwable $e) {
    json_error('Failed to create client.', 500);
}

audit_log('CREATE', 'clients', $code);

json_success([
    'client_code'    => $code,
    'has_coordinates' => $lat !== null,
    'lat'            => $lat,
    'lng'            => $lng,
], $lat !== null
    ? 'Client account created and site location plotted.'
    : 'Client account created. Add site coordinates so their jobs can be geofenced.');
