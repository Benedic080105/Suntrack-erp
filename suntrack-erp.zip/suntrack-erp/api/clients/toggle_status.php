<?php
require_once __DIR__ . '/../../config/config.php';
require_management(); // Admin role is view/export only; only Management (manager/staff) may mutate.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['id', 'status']);

$id = (int)$input['id'];
$status = $input['status'];
if (!in_array($status, ['ACTIVE', 'INACTIVE'], true)) {
    json_error('Invalid status.', 422);
}

$pdo = db();
$clientStmt = $pdo->prepare('SELECT c.client_code, c.user_id FROM clients c WHERE c.id = :id');
$clientStmt->execute([':id' => $id]);
$client = $clientStmt->fetch();
if (!$client) {
    json_error('Client not found.', 404);
}

$pdo->prepare('UPDATE users SET status = :s WHERE id = :uid')->execute([':s' => $status, ':uid' => $client['user_id']]);

audit_log($status === 'ACTIVE' ? 'ACTIVATE' : 'DEACTIVATE', 'clients', $client['client_code']);

json_success([], 'Client status updated.');
