<?php
require_once __DIR__ . '/../../middleware/admin.php';

$pdo = db();
[$pageLimit, $pageOffset] = list_page(500);
$where = [];
$params = [];

if ($clause = search_clause($_GET['search'] ?? '', search_columns('clients'), $params)) {
    $where[] = $clause;
}
if (!empty($_GET['status'])) {
    $where[] = 'u.status = :status';
    $params[':status'] = $_GET['status'];
}
if (!empty($_GET['city'])) {
    $where[] = 'c.city = :city';
    $params[':city'] = $_GET['city'];
}
// has_location=1 pinned on the map, 0 not yet pinned.
if (isset($_GET['has_location']) && $_GET['has_location'] !== '') {
    $where[] = $_GET['has_location'] ? '(c.lat IS NOT NULL AND c.lng IS NOT NULL)' : '(c.lat IS NULL OR c.lng IS NULL)';
}

$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

// Phase 5 columns (barangay / postal code) are read only once the migration is in.
$p5 = sr_phase5_ready() ? 'c.barangay, c.postal_code,' : 'NULL AS barangay, NULL AS postal_code,';

$sql = "SELECT c.id, c.client_code, u.id AS user_id, u.full_name, u.email, u.phone, u.status, u.last_login,
               c.address, $p5 c.city, c.province, c.date_registered,
               c.lat, c.lng, c.geofence_radius_m,
               (c.lat IS NOT NULL AND c.lng IS NOT NULL) AS has_coordinates,
               (SELECT COUNT(*) FROM solar_systems s WHERE s.client_id = c.id) AS system_count,
               (SELECT COUNT(*) FROM service_requests sr WHERE sr.client_id = c.id AND sr.status NOT IN ('COMPLETED','CANCELLED','REJECTED')) AS open_requests,
               -- Most pressing open request, so the client map can colour each pin by urgency.
               (SELECT sr.priority FROM service_requests sr
                WHERE sr.client_id = c.id AND sr.status NOT IN ('COMPLETED','CANCELLED','REJECTED')
                ORDER BY FIELD(sr.priority, 'LOW', 'NORMAL', 'HIGH', 'URGENT') DESC, sr.date_requested DESC
                LIMIT 1) AS top_open_priority,
               (SELECT COUNT(*) FROM service_requests sr WHERE sr.client_id = c.id) AS total_requests,
               -- Technician on the client's newest open request, for the map popup.
               (SELECT tu.full_name FROM service_requests sr
                JOIN technicians t ON t.id = sr.assigned_technician_id
                JOIN users tu ON tu.id = t.user_id
                WHERE sr.client_id = c.id AND sr.status NOT IN ('COMPLETED','CANCELLED','REJECTED')
                ORDER BY sr.id DESC LIMIT 1) AS assigned_technician,
               GREATEST(
                   COALESCE((SELECT MAX(sr.completion_date) FROM service_requests sr WHERE sr.client_id = c.id AND sr.status = 'COMPLETED'), '1000-01-01'),
                   COALESCE((SELECT MAX(j.updated_at) FROM jobs j WHERE j.client_id = c.id AND j.stage = 'COMPLETED'), '1000-01-01')
               ) AS last_service_raw
        FROM clients c
        JOIN users u ON u.id = c.user_id
        $whereSql
        ORDER BY c.id DESC
        " . list_page_sql($pageLimit, $pageOffset);

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

$rows = list_page_finish($stmt->fetchAll(), $pageLimit, $pageOffset);
foreach ($rows as &$r) {
    $r['last_service'] = str_starts_with((string)$r['last_service_raw'], '1000-01-01') ? null : substr((string)$r['last_service_raw'], 0, 10);
    unset($r['last_service_raw']);
}
unset($r);

json_success($rows);
