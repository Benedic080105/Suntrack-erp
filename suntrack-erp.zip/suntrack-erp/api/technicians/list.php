<?php
require_once __DIR__ . '/../../middleware/admin.php';

$pdo = db();
[$pageLimit, $pageOffset] = list_page(500);
$where = [];
$params = [];

if ($clause = search_clause($_GET['search'] ?? '', search_columns('technicians'), $params)) {
    $where[] = $clause;
}
if (!empty($_GET['status'])) {
    $where[] = 'u.status = :status';
    $params[':status'] = $_GET['status'];
}
if (!empty($_GET['availability'])) {
    $where[] = 'ta.status = :availability';
    $params[':availability'] = $_GET['availability'];
}

$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$sql = "SELECT t.id, t.technician_code, u.id AS user_id, u.full_name, u.email, u.phone, u.status,
               t.specialization, ta.status AS availability,
               (SELECT COUNT(*) FROM jobs j WHERE j.technician_id = t.id AND j.stage NOT IN ('COMPLETED','CANCELLED')) AS open_jobs
        FROM " . tech_staff_table() . " t
        JOIN users u ON u.id = t.user_id
        LEFT JOIN technician_availability ta ON ta.technician_id = t.id
        $whereSql
        ORDER BY u.full_name, t.id ASC
        " . list_page_sql($pageLimit, $pageOffset);

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

json_success(list_page_finish($stmt->fetchAll(), $pageLimit, $pageOffset));
