<?php
require_once __DIR__ . '/../../config/config.php';
require_management(); // Admin role is view/export only; only Management (manager/staff) may mutate.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['id', 'status']);

$id = (int)$input['id'];
$status = $input['status'];
if (!in_array($status, ['ACTIVE', 'INACTIVE'], true)) {
    json_error('Invalid status.', 422);
}

$pdo = db();
$techStmt = $pdo->prepare('SELECT technician_code, user_id FROM technicians WHERE id = :id');
$techStmt->execute([':id' => $id]);
$tech = $techStmt->fetch();
if (!$tech) {
    json_error('Technician not found.', 404);
}

$pdo->prepare('UPDATE users SET status = :s WHERE id = :uid')->execute([':s' => $status, ':uid' => $tech['user_id']]);

audit_log($status === 'ACTIVE' ? 'ACTIVATE' : 'DEACTIVATE', 'technicians', $tech['technician_code']);

json_success([], 'Technician status updated.');
