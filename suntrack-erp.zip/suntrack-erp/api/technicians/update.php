<?php
require_once __DIR__ . '/../../config/config.php';
require_management(); // Admin role is view/export only; only Management (manager/staff) may mutate.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['id']);

$id = (int)$input['id'];
$pdo = db();

$techStmt = $pdo->prepare('SELECT t.*, u.id AS user_id FROM technicians t JOIN users u ON u.id = t.user_id WHERE t.id = :id');
$techStmt->execute([':id' => $id]);
$tech = $techStmt->fetch();
if (!$tech) {
    json_error('Technician not found.', 404);
}

$userFields = [];
$userParams = [':uid' => $tech['user_id']];
foreach (['full_name', 'phone'] as $f) {
    if (isset($input[$f])) {
        $userFields[] = "$f = :$f";
        $userParams[":$f"] = trim($input[$f]);
    }
}
if ($userFields) {
    $pdo->prepare('UPDATE users SET ' . implode(', ', $userFields) . ' WHERE id = :uid')->execute($userParams);
}

if (isset($input['specialization'])) {
    $pdo->prepare('UPDATE technicians SET specialization = :s WHERE id = :id')
        ->execute([':s' => trim($input['specialization']), ':id' => $id]);
}

if (!empty($input['availability'])) {
    if (!in_array($input['availability'], ['AVAILABLE','BUSY','OFF_DUTY','ON_LEAVE'], true)) {
        json_error('Invalid availability value.', 422);
    }
    $pdo->prepare(
        'INSERT INTO technician_availability (technician_id, status) VALUES (:t, :s)
         ON DUPLICATE KEY UPDATE status = :s2'
    )->execute([':t' => $id, ':s' => $input['availability'], ':s2' => $input['availability']]);
}

if (!empty($input['new_password'])) {
    if (str_len($input['new_password']) < PASSWORD_MIN_LENGTH) {
        json_error('New password must be at least ' . PASSWORD_MIN_LENGTH . ' characters.', 422);
    }
    $pdo->prepare('UPDATE users SET password_hash = :h WHERE id = :uid')
        ->execute([':h' => password_hash($input['new_password'], PASSWORD_DEFAULT), ':uid' => $tech['user_id']]);
    audit_log('RESET_PASSWORD', 'technicians', $tech['technician_code']);
}

audit_log('UPDATE', 'technicians', $tech['technician_code']);

json_success([], 'Technician updated.');
