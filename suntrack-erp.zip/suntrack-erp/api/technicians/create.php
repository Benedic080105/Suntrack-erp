<?php
require_once __DIR__ . '/../../config/config.php';
require_management(); // Admin role is view/export only; only Management (manager/staff) may mutate.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['full_name', 'email', 'password', 'phone', 'specialization']);

$email = trim(strtolower($input['email']));
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_error('Please enter a valid email address.', 422);
}
if (str_len($input['password']) < PASSWORD_MIN_LENGTH) {
    json_error('Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters.', 422);
}

$pdo = db();
$check = $pdo->prepare('SELECT id FROM users WHERE email = :e');
$check->execute([':e' => $email]);
if ($check->fetch()) {
    json_error('An account with this email already exists.', 409);
}

$pdo->beginTransaction();
try {
    $roleId = $pdo->query("SELECT id FROM roles WHERE role_key = 'technician'")->fetchColumn();

    $pdo->prepare(
        'INSERT INTO users (role_id, email, password_hash, full_name, phone, status)
         VALUES (:role_id, :email, :hash, :name, :phone, "ACTIVE")'
    )->execute([
        ':role_id' => $roleId, ':email' => $email,
        ':hash' => password_hash($input['password'], PASSWORD_DEFAULT),
        ':name' => trim($input['full_name']), ':phone' => trim($input['phone']),
    ]);
    $userId = (int)$pdo->lastInsertId();

    // Collision-safe sequential code, matching the seeded TECH-01 format.
    $techStmt = $pdo->prepare(
        'INSERT INTO technicians (user_id, technician_code, specialization) VALUES (:uid, :code, :spec)'
    );
    $code = with_unique_code('technicians', 'technician_code', 'TECH-', function (string $code) use ($techStmt, $userId, $input) {
        $techStmt->execute([':uid' => $userId, ':code' => $code, ':spec' => trim($input['specialization'])]);
        return $code;
    }, pad: 2);
    $techId = (int)$pdo->lastInsertId();

    $pdo->prepare('INSERT INTO technician_availability (technician_id, status) VALUES (:t, "AVAILABLE")')
        ->execute([':t' => $techId]);

    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
    json_error('Failed to create technician.', 500);
}

audit_log('CREATE', 'technicians', $code);

json_success(['technician_code' => $code], 'Technician account created.');
