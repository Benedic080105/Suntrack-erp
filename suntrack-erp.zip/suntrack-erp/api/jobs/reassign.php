<?php
/**
 * POST /api/jobs/reassign.php
 * Management only. Assigns or reassigns the technician on an existing job.
 * This is how "Management assigns a technician" makes the job appear in
 * that technician's My Assignments (technician/assignments.php reads
 * jobs.technician_id directly, so no separate sync step is needed).
 *
 * Body:
 *   job_id          int      required
 *   technician_id   int      required
 *   note            string   optional, ≤255 chars
 */
require_once __DIR__ . '/../../config/config.php';
require_management();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['job_id', 'technician_id']);

$jobId  = (int)$input['job_id'];
$techId = (int)$input['technician_id'];
$note   = trim($input['note'] ?? '');

$pdo = db();

$techStmt = $pdo->prepare('SELECT t.id, u.full_name FROM ' . tech_staff_table() . ' t JOIN users u ON u.id = t.user_id WHERE t.id = :id');
$techStmt->execute([':id' => $techId]);
$tech = $techStmt->fetch();
if (!$tech) {
    json_error('Technician not found.', 404);
}

$pdo->beginTransaction();
try {
    // Row lock so a reassignment can't race a technician's own stage change.
    $jobStmt = $pdo->prepare('SELECT * FROM jobs WHERE id = :id FOR UPDATE');
    $jobStmt->execute([':id' => $jobId]);
    $job = $jobStmt->fetch();

    if (!$job) {
        $pdo->rollBack();
        json_error('Job not found.', 404);
    }
    if (in_array($job['stage'], ['COMPLETED', 'CANCELLED'], true)) {
        $pdo->rollBack();
        json_error('This job is already closed and cannot be reassigned.', 422);
    }

    // A job with an open subcontractor assignment belongs to that subcontractor.
    if ($subA = sub_active_assignment_for_job($pdo, $jobId)) {
        $pdo->rollBack();
        json_error("{$job['job_code']} is with subcontractor {$subA['subcon_code']} ({$subA['assignment_code']}). Cancel that assignment before giving it to a technician.", 409);
    }

    $previousTechId = $job['technician_id'] ? (int)$job['technician_id'] : null;
    if ($previousTechId === $techId) {
        $pdo->rollBack();
        json_error('That technician is already assigned to this job.', 422);
    }

    $newStage = $job['stage'] === 'SUBMITTED' ? 'ASSIGNED' : $job['stage'];

    $pdo->prepare('UPDATE jobs SET technician_id = :t, stage = :stage WHERE id = :id')
        ->execute([':t' => $techId, ':stage' => $newStage, ':id' => $jobId]);

    $pdo->prepare(
        'INSERT INTO job_status_history (job_id, from_stage, to_stage, changed_by, note)
         VALUES (:j, :from, :to, :u, :note)'
    )->execute([
        ':j'    => $jobId,
        ':from' => $job['stage'],
        ':to'   => $newStage,
        ':u'    => current_user_id(),
        ':note' => $note !== '' ? str_cut($note, 0, 255) : 'Reassigned by Management',
    ]);

    // A job raised from a service request carries that request's technician:
    // keep them the same, or the old technician would still see the request
    // and the new one would not.
    $linkedSr = $pdo->prepare(
        "SELECT id, status FROM service_requests
         WHERE job_id = :j AND status NOT IN ('COMPLETED','CANCELLED','REJECTED') FOR UPDATE"
    );
    $linkedSr->execute([':j' => $jobId]);
    foreach ($linkedSr->fetchAll() as $lsr) {
        $pdo->prepare('UPDATE service_requests SET assigned_technician_id = :t WHERE id = :id')
            ->execute([':t' => $techId, ':id' => $lsr['id']]);
        sr_log((int)$lsr['id'], 'REASSIGNED', $lsr['status'], $lsr['status'],
            "Job {$job['job_code']} reassigned to {$tech['full_name']}" . ($note !== '' ? " — $note" : ''));
    }

    $pdo->commit();
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    json_error('Failed to reassign job.', 500);
}

audit_log('REASSIGN', 'jobs', $job['job_code']);

// Notify the newly assigned technician.
$newTechUserStmt = $pdo->prepare('SELECT user_id FROM technicians WHERE id = :id');
$newTechUserStmt->execute([':id' => $techId]);
$newTechUserId = $newTechUserStmt->fetchColumn();
if ($newTechUserId) {
    notify((int)$newTechUserId, 'JOB_STATUS', "You've been assigned job {$job['job_code']}.", 'jobs', $jobId);
}

// Let the previous technician know they've been taken off it.
if ($previousTechId) {
    $oldTechUserStmt = $pdo->prepare('SELECT user_id FROM technicians WHERE id = :id');
    $oldTechUserStmt->execute([':id' => $previousTechId]);
    $oldTechUserId = $oldTechUserStmt->fetchColumn();
    if ($oldTechUserId) {
        notify((int)$oldTechUserId, 'JOB_STATUS', "Job {$job['job_code']} has been reassigned to another technician.", 'jobs', $jobId);
    }
}

json_success(['job_id' => $jobId, 'technician_name' => $tech['full_name']], 'Job reassigned successfully.');
