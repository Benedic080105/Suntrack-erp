<?php
/**
 * POST /api/jobs/status.php
 *
 * The single, controlled entry point for a technician advancing a job stage.
 *
 * Guarantees:
 *   1. Technician session + technician role (middleware).
 *   2. CSRF token required.
 *   3. Job ownership verified server-side — the job_id from JavaScript is never trusted.
 *   4. Only transitions listed in tech_stage_flow() are accepted.
 *   5. COMPLETED / CANCELLED jobs can never be modified again.
 *   6. Field work requires a GPS Time In; completion requires the checklist /
 *      inspection to be finished and the Time Out to be recorded.
 *   7. The jobs row is locked FOR UPDATE, so a double-clicked button cannot
 *      produce two history rows — the second request sees the new stage and
 *      is rejected as an invalid transition.
 *   8. jobs.stage, jobs.progress, job_status_history, the linked service
 *      request and the parent project are all updated in one transaction.
 *   9. The client is notified and an audit row is written.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['job_id', 'stage']);

$jobId  = (int)$input['job_id'];
$stage  = strtoupper(trim((string)$input['stage']));
$note   = trim((string)($input['note'] ?? ''));
$techId = (int)current_profile_id();

// Stages a technician is ever allowed to set.
if (!in_array($stage, ['EN_ROUTE', 'ARRIVED', 'IN_PROGRESS', 'PAUSED', 'COMPLETED'], true)) {
    json_error('Invalid stage.', 422);
}

$pdo = db();
$pdo->beginTransaction();

try {
    // Row lock — serialises concurrent/double-submitted requests for this job.
    $job = tech_job_or_fail($jobId, true);
    tech_require_lead($job); // helpers on a crew do not move the job's stage

    if (tech_stage_is_closed($job['stage'])) {
        $pdo->rollBack();
        json_error('This job is already ' . strtolower($job['stage']) . ' and can no longer be changed.', 422);
    }

    $allowed = tech_allowed_next($job['stage']);
    if (!in_array($stage, $allowed, true)) {
        $pdo->rollBack();
        json_error(
            sprintf(
                'Cannot move from %s to %s. %s',
                tech_stage_label($job['stage']),
                tech_stage_label($stage),
                $allowed
                    ? 'Allowed next step: ' . implode(' or ', array_map('tech_stage_label', $allowed)) . '.'
                    : 'This job has no further steps.'
            ),
            422,
            ['current_stage' => $job['stage'], 'allowed_next' => $allowed]
        );
    }

    // --- Subcontractor (field mode): its assignment follows the job ----------
    $fieldSub = field_subcontractor();
    $fieldAsg = null;
    if ($fieldSub) {
        $fieldAsg = sub_field_assignment($pdo, $jobId, (int)$fieldSub['id'], true);
        if (!$fieldAsg) {
            $pdo->rollBack();
            json_error('This job is no longer assigned to your company.', 403);
        }
        if ($fieldAsg['status'] === 'AWAITING_INSPECTION') {
            $pdo->rollBack();
            json_error('SunTrack is inspecting your work on this job. You will be notified of the result.', 409);
        }
    }

    // --- Attendance gate: no on-site work without a GPS Time In ------------
    if (in_array($stage, ['IN_PROGRESS'], true) && !tech_open_attendance($jobId, $techId)) {
        $pdo->rollBack();
        json_error('Record your GPS Time In at the site before starting work on this job.', 422, [
            'requires' => 'TIME_IN',
        ]);
    }

    // --- Completion gate: checklist / inspection / time out ----------------
    if ($stage === 'COMPLETED') {
        $blocker = tech_completion_blocker($job);
        if ($blocker !== null) {
            $pdo->rollBack();
            // 'requires' lets the phone open the report form straight away.
            json_error($blocker, 422, ['blocked' => true, 'requires' => $blocker === TECH_REPORT_REQUIRED ? 'WORK_REPORT' : null]);
        }

        // A subcontractor's finished work goes to SunTrack for inspection; the
        // job is completed when Management approves it (subcontractors/assignment_action.php).
        if ($fieldAsg) {
            sub_move($pdo, $fieldAsg, 'AWAITING_INSPECTION', 'sub', $note !== '' ? str_cut($note, 0, 500) : 'Work finished — submitted for inspection',
                ['submitted_at' => date('Y-m-d H:i:s'), 'submission_round' => ['raw' => 'submission_round + 1']]);
            if (!tech_active_field_jobs($techId, $jobId) && tech_availability($techId) === 'BUSY') {
                tech_set_availability($techId, 'AVAILABLE');
            }
            $pdo->commit();
            audit_log('SUBCON_SUBMIT', 'subcontractor_assignments', $fieldAsg['assignment_code']);
            sub_notify_management("{$fieldSub['name']} finished {$job['job_code']} ({$fieldAsg['assignment_code']}) — ready for your inspection.", (int)$fieldAsg['id']);
            json_success([
                'job_id' => $jobId, 'stage' => $job['stage'], 'progress' => (int)$job['progress'],
                'allowed_next' => [], 'can_undo' => false, 'assignment_status' => 'AWAITING_INSPECTION',
            ], 'Submitted to SunTrack for inspection. You will be notified when it is approved.');
        }
    }

    $newProgress = tech_progress_for_stage($job, $stage);

    $pdo->prepare('UPDATE jobs SET stage = :stage, progress = :progress WHERE id = :id')
        ->execute([':stage' => $stage, ':progress' => $newProgress, ':id' => $jobId]);

    $pdo->prepare(
        'INSERT INTO job_status_history (job_id, from_stage, to_stage, changed_by, note)
         VALUES (:j, :from, :to, :u, :note)'
    )->execute([
        ':j'    => $jobId,
        ':from' => $job['stage'],
        ':to'   => $stage,
        ':u'    => current_user_id(),
        ':note' => $note !== '' ? str_cut($note, 0, 255) : null,
    ]);

    if ($fieldAsg && $stage === 'IN_PROGRESS' && in_array($fieldAsg['status'], ['ACCEPTED', 'SCHEDULED'], true)) {
        sub_move($pdo, $fieldAsg, 'IN_PROGRESS', 'sub', 'Work started', ['started_at' => date('Y-m-d H:i:s')]);
    }

    // --- Keep the linked service request and parent project in sync --------
    // The request follows the job (IN PROGRESS / ON HOLD / COMPLETED) and
    // records the change in its own history — see sr_sync_from_job().
    $srChanged = sr_sync_from_job($jobId, $stage, $note);

    if ($stage === 'COMPLETED') {
        if ($job['project_id']) {
            $pdo->prepare('UPDATE projects SET status = "COMPLETED", progress = 100 WHERE id = :p')
                ->execute([':p' => $job['project_id']]);
        }

        if ($job['job_type'] === 'MAINTENANCE') {
            $pdo->prepare(
                'UPDATE maintenance_records SET status = "COMPLETED", completion_date = NOW()
                 WHERE job_id = :j AND status <> "COMPLETED"'
            )->execute([':j' => $jobId]);
        }
    } else {
        // Installation progress drives the project; a maintenance visit on an
        // installed system must not reset it to IN_PROGRESS / 60% (handled below).
        if ($job['project_id'] && $job['job_type'] !== 'MAINTENANCE') {
            $pdo->prepare(
                'UPDATE projects SET status = "IN_PROGRESS", progress = :p
                 WHERE id = :pid AND status NOT IN ("COMPLETED","CANCELLED")'
            )->execute([':p' => $newProgress, ':pid' => $job['project_id']]);
        }

        if ($stage === 'IN_PROGRESS' && $job['job_type'] === 'MAINTENANCE') {
            $pdo->prepare('UPDATE maintenance_records SET status = "IN_PROGRESS" WHERE job_id = :j AND status = "PENDING"')
                ->execute([':j' => $jobId]);
        }

        // A maintenance visit on an installed system shows as MAINTENANCE
        // while it is under way (completion above puts it back to COMPLETED).
        if ($job['project_id'] && $job['job_type'] === 'MAINTENANCE' && in_array($stage, ['ARRIVED', 'IN_PROGRESS', 'PAUSED'], true)) {
            $pdo->prepare('UPDATE projects SET status = "MAINTENANCE" WHERE id = :pid AND status = "COMPLETED"')
                ->execute([':pid' => $job['project_id']]);
        }
    }

    // Solar system status and the maintenance schedule follow the project's
    // installation / maintenance jobs (see includes/project_lib.php).
    project_on_job_stage($job, $stage);

    // --- Availability follows the work ------------------------------------
    if ($stage === 'IN_PROGRESS') {
        tech_set_availability($techId, 'BUSY');
    } elseif ($stage === 'COMPLETED' && !tech_active_field_jobs($techId, $jobId)) {
        if (tech_availability($techId) === 'BUSY') {
            tech_set_availability($techId, 'AVAILABLE');
        }
    }

    $pdo->commit();
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    json_error('Failed to update job status.', 500);
}

audit_log('STATUS_CHANGE:' . $job['stage'] . '->' . $stage, 'jobs', $job['job_code']);

// --- Tell Management (and, on completion, the client) about the request ----
sr_notify_job_sync($srChanged, $_SESSION['full_name'] ?? 'The technician');

// --- Notify the client -----------------------------------------------------
$clientUserStmt = $pdo->prepare('SELECT user_id FROM clients WHERE id = :id');
$clientUserStmt->execute([':id' => $job['client_id']]);
$clientUserId = $clientUserStmt->fetchColumn();

if ($clientUserId) {
    $messages = [
        'EN_ROUTE'    => 'Your technician is on the way to the site.',
        'ARRIVED'     => 'Your technician has arrived at the site.',
        'IN_PROGRESS' => 'Work has started on your job.',
        'PAUSED'      => 'Work on your job has been paused.',
        'COMPLETED'   => 'Your job has been completed.',
    ];
    notify(
        (int)$clientUserId,
        'JOB_STATUS',
        "Job {$job['job_code']}: " . ($messages[$stage] ?? tech_stage_label($stage)),
        'jobs',
        $jobId
    );
}

json_success([
    'job_id'       => $jobId,
    'stage'        => $stage,
    'progress'     => $newProgress,
    'allowed_next' => tech_allowed_next($stage),
    'can_undo'     => $stage !== 'COMPLETED',
], 'Job moved to ' . tech_stage_label($stage) . '.');
