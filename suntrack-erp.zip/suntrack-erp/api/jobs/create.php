<?php
/**
 * POST /api/jobs/create.php
 * Management only (manager/staff). Creates a job directly — for work that
 * did not originate from a client service request (e.g. a new
 * installation tied to a project). For service-request-driven jobs, use
 * service_requests/assign.php instead, which keeps the one-job-per-request
 * rule.
 *
 * Body:
 *   client_id        int      required
 *   job_type          string   required — INSTALLATION | MAINTENANCE | REPAIR | INSPECTION
 *   site_address       string   optional
 *   site_lat / site_lng number optional — enables the technician geofence check
 *   geofence_radius_m  int      optional, default 500
 *   scheduled_date      date     optional (YYYY-MM-DD)
 *   priority            string   optional, default NORMAL
 *   description         string   optional
 *   project_id          int      optional — links the job to an existing project
 *   technician_id        int      optional — assign immediately (else stays SUBMITTED)
 */
require_once __DIR__ . '/../../config/config.php';
require_management();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['client_id', 'job_type']);

$validTypes = ['INSTALLATION', 'MAINTENANCE', 'REPAIR', 'INSPECTION'];
if (!in_array($input['job_type'], $validTypes, true)) {
    json_error('job_type must be one of: ' . implode(', ', $validTypes), 422);
}

$validPriorities = ['LOW', 'NORMAL', 'HIGH', 'URGENT'];
$priority = $input['priority'] ?? 'NORMAL';
if (!in_array($priority, $validPriorities, true)) {
    json_error('priority must be one of: ' . implode(', ', $validPriorities), 422);
}

$pdo = db();

$clientId = (int)$input['client_id'];
$clientStmt = $pdo->prepare('SELECT id FROM clients WHERE id = :id');
$clientStmt->execute([':id' => $clientId]);
if (!$clientStmt->fetch()) {
    json_error('Client not found.', 404);
}

$projectId = null;
if (!empty($input['project_id'])) {
    $projStmt = $pdo->prepare('SELECT id, client_id FROM projects WHERE id = :id');
    $projStmt->execute([':id' => (int)$input['project_id']]);
    $project = $projStmt->fetch();
    if (!$project) {
        json_error('Project not found.', 404);
    }
    if ((int)$project['client_id'] !== $clientId) {
        json_error('That project does not belong to the selected client.', 422);
    }
    $projectId = (int)$project['id'];
}

$technicianId = null;
if (!empty($input['technician_id'])) {
    $techStmt = $pdo->prepare('SELECT id FROM ' . tech_staff_table() . ' t WHERE id = :id');
    $techStmt->execute([':id' => (int)$input['technician_id']]);
    if (!$techStmt->fetch()) {
        json_error('Technician not found.', 404);
    }
    $technicianId = (int)$input['technician_id'];
}

[$siteLat, $siteLng] = parse_coordinates($input['site_lat'] ?? null, $input['site_lng'] ?? null);

$radius = isset($input['geofence_radius_m']) && $input['geofence_radius_m'] !== ''
    ? (int)$input['geofence_radius_m']
    : null;

// Fall back to the client's plotted site. A job with no coordinates cannot be
// geofenced at all, and under the geofence_strict setting the technician will
// be refused Time In — so inheriting the client's location here is what makes
// "plot the client once" actually work.
$inheritedLocation = false;
if ($siteLat === null || $siteLng === null) {
    $geoStmt = $pdo->prepare('SELECT lat, lng, geofence_radius_m FROM clients WHERE id = :id');
    $geoStmt->execute([':id' => $clientId]);
    $clientGeo = $geoStmt->fetch();

    if ($clientGeo && $clientGeo['lat'] !== null && $clientGeo['lng'] !== null) {
        $siteLat = (float)$clientGeo['lat'];
        $siteLng = (float)$clientGeo['lng'];
        $inheritedLocation = true;
        if ($radius === null && !empty($clientGeo['geofence_radius_m'])) {
            $radius = (int)$clientGeo['geofence_radius_m'];
        }
    }
}

if ($radius === null) {
    $radius = geofence_default_radius();
}
if ($radius < 20 || $radius > 20000) {
    json_error('Geofence radius must be between 20 and 20000 metres.', 422);
}

$scheduledDate = !empty($input['scheduled_date']) ? $input['scheduled_date'] : null;

$jobCode = null;
$jobId   = null;
$stage   = $technicianId ? 'ASSIGNED' : 'SUBMITTED';

$pdo->beginTransaction();
try {
    $stmt = $pdo->prepare(
        'INSERT INTO jobs (job_code, project_id, client_id, technician_id, job_type, site_address,
                            site_lat, site_lng, geofence_radius_m, scheduled_date, priority, description, stage, progress)
         VALUES (:code, :project_id, :client_id, :tech_id, :job_type, :addr,
                 :lat, :lng, :radius, :sched, :priority, :desc, :stage, 0)'
    );
    [$jobId, $jobCode] = insert_job_with_code(fn(string $code) => $stmt->execute([
        ':code'       => $code,
        ':project_id' => $projectId,
        ':client_id'  => $clientId,
        ':tech_id'    => $technicianId,
        ':job_type'   => $input['job_type'],
        ':addr'       => $input['site_address'] ?? null,
        ':lat'        => $siteLat,
        ':lng'        => $siteLng,
        ':radius'     => $radius,
        ':sched'      => $scheduledDate,
        ':priority'   => $priority,
        ':desc'       => $input['description'] ?? null,
        ':stage'      => $stage,
    ]));

    $pdo->prepare(
        'INSERT INTO job_status_history (job_id, from_stage, to_stage, changed_by, note)
         VALUES (:j, NULL, :stage, :u, "Created by Management")'
    )->execute([':j' => $jobId, ':stage' => $stage, ':u' => current_user_id()]);

    // An installation job carries the 17-item checklist the technician works
    // through (and that its completion is gated on).
    if ($input['job_type'] === 'INSTALLATION') {
        tech_ensure_installation_checklist((int)$jobId);
    }

    $pdo->commit();
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    json_error('Failed to create job.', 500);
}

audit_log('CREATE', 'jobs', $jobCode);

if ($technicianId) {
    $techUserStmt = $pdo->prepare('SELECT user_id FROM technicians WHERE id = :id');
    $techUserStmt->execute([':id' => $technicianId]);
    $techUserId = $techUserStmt->fetchColumn();
    if ($techUserId) {
        notify((int)$techUserId, 'JOB_STATUS', "New job assigned to you: $jobCode.", 'jobs', $jobId);
    }
}

// No technician given: if the team is near full, offer it to the best
// subcontractor right away (includes/subcontractor_lib.php).
$autoNote = '';
if (!$technicianId && function_exists('sub_auto_sweep')) {
    foreach (sub_auto_sweep($pdo, false, [(int)$jobId]) as $r) {
        if ($r['status'] === 'assigned') {
            $autoNote = " Technicians are near full, so it was offered automatically to {$r['subcontractor']['name']} ({$r['assignment_code']}).";
        } elseif ($r['status'] === 'suggested') {
            $autoNote = " Technicians are near full — suggested subcontractor: {$r['subcontractor']['name']}.";
        }
    }
}

json_success([
    'job_id'              => $jobId,
    'job_code'            => $jobCode,
    'site_lat'            => $siteLat,
    'site_lng'            => $siteLng,
    'geofence_radius_m'   => $radius,
    'inherited_location'  => $inheritedLocation,
    'geofenced'           => $siteLat !== null,
], ($siteLat === null
    ? 'Job created — but the site has no coordinates, so the technician will not be able to Time In. Plot the client\'s location first.'
    : ($inheritedLocation
        ? 'Job created. Geofence set from the client\'s registered site location.'
        : 'Job created successfully.')) . $autoNote);
