<?php
/**
 * POST /api/jobs/undo.php
 *
 * Undo the most recent *reversible* stage change the technician made on one of
 * their own jobs — the safety net for a mis-tapped "Mark Arrived".
 *
 * Rules:
 *   - Only the latest job_status_history row for that job counts.
 *   - That row must have been written by the current user.
 *   - Its to_stage must still be the job's current stage (nothing happened since).
 *   - The job must not be COMPLETED or CANCELLED — closed jobs are never reopened here.
 *   - There must be a from_stage to return to.
 *   - The undo window is UNDO_WINDOW_MINUTES; after that the change stands.
 *   - The reversal is *recorded* as a new history row. Audit history is never deleted.
 */
require_once __DIR__ . '/../../middleware/technician.php';

const UNDO_WINDOW_MINUTES = 15;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['job_id']);

$jobId  = (int)$input['job_id'];
$techId = (int)current_profile_id();

$pdo = db();
$pdo->beginTransaction();

try {
    $job = tech_job_or_fail($jobId, true);
    tech_require_lead($job);

    if (tech_stage_is_closed($job['stage'])) {
        $pdo->rollBack();
        json_error('Completed and cancelled jobs cannot be undone here. Contact your coordinator.', 422);
    }
    if (($fs = field_subcontractor()) && ($fa = sub_field_assignment($pdo, $jobId, (int)$fs['id'])) && $fa['status'] === 'AWAITING_INSPECTION') {
        $pdo->rollBack();
        json_error('SunTrack is inspecting your work on this job, so it cannot be undone now.', 409);
    }

    $lastStmt = $pdo->prepare(
        'SELECT *, TIMESTAMPDIFF(SECOND, created_at, NOW()) AS age_seconds
         FROM job_status_history WHERE job_id = :j ORDER BY id DESC LIMIT 1'
    );
    $lastStmt->execute([':j' => $jobId]);
    $last = $lastStmt->fetch();

    if (!$last) {
        $pdo->rollBack();
        json_error('There is no stage change to undo on this job.', 422);
    }
    if ((int)$last['changed_by'] !== (int)current_user_id()) {
        $pdo->rollBack();
        json_error('The last change on this job was not made by you, so it cannot be undone here.', 403);
    }
    if ($last['to_stage'] !== $job['stage']) {
        $pdo->rollBack();
        json_error('This job has moved on since that change. Nothing to undo.', 422);
    }
    if (empty($last['from_stage'])) {
        $pdo->rollBack();
        json_error('This is the first recorded stage for the job — there is nothing to go back to.', 422);
    }
    if (str_starts_with((string)$last['note'], 'UNDO')) {
        $pdo->rollBack();
        json_error('That change was already an undo. Move the job forward instead.', 422);
    }
    // The age is computed by MySQL (TIMESTAMPDIFF against its own NOW()) rather
    // than by comparing a MySQL timestamp to PHP's time(). PHP runs on
    // Asia/Manila while the MySQL server may be on UTC, and mixing the two
    // clocks made every change look hours old and killed the undo window.
    if ((int)$last['age_seconds'] > UNDO_WINDOW_MINUTES * 60) {
        $pdo->rollBack();
        json_error('The ' . UNDO_WINDOW_MINUTES . '-minute undo window for this change has passed.', 422);
    }

    $revertTo = $last['from_stage'];
    if (tech_stage_is_closed($revertTo)) {
        $pdo->rollBack();
        json_error('Cannot revert this job into a closed stage.', 422);
    }

    $newProgress = tech_progress_for_stage($job, $revertTo);

    $pdo->prepare('UPDATE jobs SET stage = :s, progress = :p WHERE id = :id')
        ->execute([':s' => $revertTo, ':p' => $newProgress, ':id' => $jobId]);

    $pdo->prepare(
        'INSERT INTO job_status_history (job_id, from_stage, to_stage, changed_by, note)
         VALUES (:j, :from, :to, :u, :note)'
    )->execute([
        ':j'    => $jobId,
        ':from' => $job['stage'],
        ':to'   => $revertTo,
        ':u'    => current_user_id(),
        ':note' => 'UNDO — reverted an accidental change to ' . $job['stage'],
    ]);

    // The linked service request steps back with the job (e.g. ON HOLD -> IN PROGRESS).
    sr_sync_from_job($jobId, $revertTo, 'Undo of an accidental change to ' . tech_stage_label($job['stage']));

    $pdo->commit();
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    json_error('Failed to undo the last change.', 500);
}

audit_log('UNDO_STATUS:' . $job['stage'] . '->' . $revertTo, 'jobs', $job['job_code']);

json_success([
    'job_id'       => $jobId,
    'stage'        => $revertTo,
    'progress'     => $newProgress,
    'allowed_next' => tech_allowed_next($revertTo),
], 'Reverted to ' . tech_stage_label($revertTo) . '.');
