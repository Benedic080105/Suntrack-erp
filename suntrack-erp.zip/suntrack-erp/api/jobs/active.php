<?php
require_once __DIR__ . '/../../middleware/warehouse.php';

$pdo = db();
$stmt = $pdo->query(
    "SELECT j.id, j.job_code, j.job_type, c.client_code, cu.full_name AS client_name,
            t.technician_code, tu.full_name AS technician_name
     FROM jobs j
     JOIN clients c ON c.id = j.client_id
     JOIN users cu ON cu.id = c.user_id
     LEFT JOIN technicians t ON t.id = j.technician_id
     LEFT JOIN users tu ON tu.id = t.user_id
     WHERE j.stage NOT IN ('COMPLETED','CANCELLED')
     ORDER BY j.created_at DESC"
);

json_success($stmt->fetchAll());
