<?php
/**
 * GET /api/jobs/list.php
 * Admin (read-only) + Management (manager/staff). Full job list for the
 * Management "Jobs" module and the Admin monitoring view.
 *
 * Query params (all optional):
 *   search         job_code, client name, technician name, site address
 *   stage          SUBMITTED | ASSIGNED | EN_ROUTE | ARRIVED | IN_PROGRESS | PAUSED | COMPLETED | CANCELLED
 *   job_type       INSTALLATION | MAINTENANCE | REPAIR | INSPECTION
 *   priority       LOW | NORMAL | HIGH | URGENT
 *   technician_id  int
 *   client_id      int
 *   unassigned=1   only jobs with no technician
 *   date_from, date_to   scheduled date range (YYYY-MM-DD, inclusive)
 */
require_once __DIR__ . '/../../middleware/admin.php';

$pdo = db();
[$pageLimit, $pageOffset] = list_page(500);
$where  = [];
$params = [];

if ($clause = search_clause($_GET['search'] ?? '', search_columns('jobs'), $params)) {
    $where[] = $clause;
}
if (!empty($_GET['client_id'])) {
    $where[] = 'j.client_id = :client_id';
    $params[':client_id'] = (int)$_GET['client_id'];
}
apply_date_range('j.scheduled_date', $where, $params);
if (!empty($_GET['stage'])) {
    $where[] = 'j.stage = :stage';
    $params[':stage'] = $_GET['stage'];
}
if (!empty($_GET['job_type'])) {
    $where[] = 'j.job_type = :job_type';
    $params[':job_type'] = $_GET['job_type'];
}
if (!empty($_GET['priority'])) {
    $where[] = 'j.priority = :priority';
    $params[':priority'] = $_GET['priority'];
}
if (!empty($_GET['technician_id'])) {
    $where[] = 'j.technician_id = :tech_id';
    $params[':tech_id'] = (int)$_GET['technician_id'];
}
$subReady = sub_ready();
if (!empty($_GET['unassigned'])) {
    // A job with an open subcontractor assignment is not unassigned.
    $where[] = 'j.technician_id IS NULL' . ($subReady ? ' AND NOT EXISTS (SELECT 1 FROM subcontractor_assignments sa WHERE sa.active_job_id = j.id)' : '');
}
// The subcontractor holding the job, if any ("name|status|assignment id|auto").
$subCol = $subReady
    ? "(SELECT CONCAT(s.name, '|', sa.status, '|', sa.id, '|', sa.auto_assigned) FROM subcontractor_assignments sa JOIN subcontractors s ON s.id = sa.subcontractor_id WHERE sa.active_job_id = j.id) AS subcontract,"
    : 'NULL AS subcontract,';

$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$sql = "SELECT j.id, j.job_code, j.job_type, j.priority, j.stage, j.progress,
               j.site_address, j.scheduled_date, j.created_at, j.updated_at,
               j.project_id, p.project_code,
               c.id AS client_id, c.client_code, cu.full_name AS client_name,
               t.id AS technician_id, t.technician_code, " . (sub_field_ready() ? 'COALESCE((SELECT s.name FROM subcontractors s WHERE s.id = t.subcontractor_id), tu.full_name)' : 'tu.full_name') . " AS technician_name, $subCol
               (SELECT COUNT(*) FROM work_reports wr WHERE wr.job_id = j.id) AS has_report
        FROM jobs j
        JOIN clients c ON c.id = j.client_id
        JOIN users cu ON cu.id = c.user_id
        LEFT JOIN projects p ON p.id = j.project_id
        LEFT JOIN technicians t ON t.id = j.technician_id
        LEFT JOIN users tu ON tu.id = t.user_id
        $whereSql
        ORDER BY
            FIELD(j.priority,'URGENT','HIGH','NORMAL','LOW'),
            j.created_at DESC, j.id DESC
        " . list_page_sql($pageLimit, $pageOffset);

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = list_page_finish($stmt->fetchAll(), $pageLimit, $pageOffset);
foreach ($rows as &$r) {
    $r['subcontractor'] = null;
    if ($r['subcontract']) {
        [$name, $st, $aid, $auto] = explode('|', $r['subcontract'], 4);
        $r['subcontractor'] = ['name' => $name, 'status' => $st, 'status_label' => SA_LABELS[$st] ?? $st, 'assignment_id' => (int)$aid, 'auto' => $auto === '1'];
    }
    unset($r['subcontract']);
}
unset($r);

$statsStmt = $pdo->query(
    "SELECT
        SUM(stage NOT IN ('COMPLETED','CANCELLED')) AS active,
        SUM(stage = 'SUBMITTED' OR (stage = 'ASSIGNED' AND technician_id IS NULL)) AS unassigned,
        SUM(stage NOT IN ('COMPLETED','CANCELLED') AND technician_id IS NOT NULL AND stage <> 'SUBMITTED') AS assigned,
        SUM(stage = 'COMPLETED') AS completed,
        SUM(stage = 'CANCELLED') AS cancelled
     FROM jobs"
);
$stats = $statsStmt->fetch() ?: [];

json_success(['rows' => $rows, 'stats' => $stats]);
