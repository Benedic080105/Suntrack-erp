<?php
/**
 * GET /api/jobs/detail.php?job_id=123
 * Admin (read-only) + Management. Everything about one job: the job row,
 * client/technician/project context, full stage history, attendance,
 * installation checklist summary (if any), maintenance record summary
 * (if any), and the work report (if filed).
 */
require_once __DIR__ . '/../../middleware/admin.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed.', 405);
}
if (empty($_GET['job_id'])) {
    json_error('job_id is required.', 422);
}
$jobId = (int)$_GET['job_id'];

$pdo = db();

$jobStmt = $pdo->prepare(
    "SELECT j.*, p.project_code, p.site_name,
            c.client_code, cu.full_name AS client_name, cu.phone AS client_phone,
            t.technician_code, tu.full_name AS technician_name, tu.phone AS technician_phone
     FROM jobs j
     JOIN clients c ON c.id = j.client_id
     JOIN users cu ON cu.id = c.user_id
     LEFT JOIN projects p ON p.id = j.project_id
     LEFT JOIN technicians t ON t.id = j.technician_id
     LEFT JOIN users tu ON tu.id = t.user_id
     WHERE j.id = :id"
);
$jobStmt->execute([':id' => $jobId]);
$job = $jobStmt->fetch();
if (!$job) {
    json_error('Job not found.', 404);
}

$historyStmt = $pdo->prepare(
    "SELECT h.from_stage, h.to_stage, h.note, h.created_at, u.full_name AS changed_by_name
     FROM job_status_history h
     LEFT JOIN users u ON u.id = h.changed_by
     WHERE h.job_id = :id ORDER BY h.created_at ASC"
);
$historyStmt->execute([':id' => $jobId]);
$history = $historyStmt->fetchAll();

$attendanceStmt = $pdo->prepare(
    "SELECT time_in, time_out, geofence_status, distance_in_m, distance_out_m
     FROM attendance WHERE job_id = :id ORDER BY time_in DESC"
);
$attendanceStmt->execute([':id' => $jobId]);
$attendance = $attendanceStmt->fetchAll();

$checklistStmt = $pdo->prepare(
    'SELECT id, progress FROM installation_checklists WHERE job_id = :id'
);
$checklistStmt->execute([':id' => $jobId]);
$checklistRow = $checklistStmt->fetch() ?: null;
$checklist = $checklistRow ? ['progress' => (int)$checklistRow['progress']] : null;

$maintStmt = $pdo->prepare(
    'SELECT id, status, panel_condition, battery_condition, inverter_condition,
            electrical_condition, issues_found, completion_date
     FROM maintenance_records WHERE job_id = :id'
);
$maintStmt->execute([':id' => $jobId]);
$maintenance = $maintStmt->fetch() ?: null;
// Phase 20: the inspection's sections, items (who ticked them), proof photos
// and review — what Management looks at before approving it.
if ($maintenance && maint_review_ready()) {
    $mr = $pdo->prepare('SELECT * FROM maintenance_records WHERE id = :m');
    $mr->execute([':m' => $maintenance['id']]);
    $rec = $mr->fetch();
    $mi = $pdo->prepare(
        'SELECT mi.item_key, mi.description, mi.status, mi.remarks, mi.completed_at, u.full_name AS completed_by_name
         FROM maintenance_items mi LEFT JOIN users u ON u.id = mi.completed_by WHERE mi.maintenance_id = :m ORDER BY mi.id'
    );
    $mi->execute([':m' => $maintenance['id']]);
    $mItems = array_map(function ($i) {
        $i['category'] = tech_maintenance_category($i['item_key'], $i['description']);
        return $i;
    }, $mi->fetchAll());
    $names = $pdo->prepare('SELECT full_name FROM users WHERE id = :id');
    $nameOf = function ($id) use ($names) {
        if (!$id) {
            return null;
        }
        $names->execute([':id' => $id]);
        return $names->fetchColumn() ?: null;
    };
    $maintenance += [
        'review_status' => $rec['review_status'], 'submitted_at' => $rec['submitted_at'], 'submit_note' => $rec['submit_note'],
        'submitted_by_name' => $nameOf($rec['submitted_by']), 'reviewed_at' => $rec['reviewed_at'],
        'reviewed_by_name' => $nameOf($rec['reviewed_by']), 'review_note' => $rec['review_note'],
        'inspection_results' => $rec['inspection_results'], 'materials_used' => $rec['materials_used'], 'remarks' => $rec['remarks'],
        'items' => $mItems,
        'sections' => maint_section_status($rec, $mItems, maint_photo_counts((int)$rec['id']) ?? []),
        'photos' => maint_photos_list((int)$rec['id']),
    ];
}

// The technician's full work report — shown in place of the old before/after photos.
$reportStmt = $pdo->prepare(
    'SELECT wr.report_code, wr.work_type, wr.status, wr.remarks, wr.materials_used, wr.issues_found,
            wr.duration_text, wr.duration_minutes, wr.submitted_date,
            tu.full_name AS technician_name, t.technician_code
     FROM work_reports wr
     LEFT JOIN technicians t ON t.id = wr.technician_id
     LEFT JOIN users tu ON tu.id = t.user_id
     WHERE wr.job_id = :id'
);
$reportStmt->execute([':id' => $jobId]);
$workReport = $reportStmt->fetch() ?: null;

// An open warehouse order for this installation, so the review form can say so.
$openMr = null;
try {
    $mrStmt = $pdo->prepare(
        "SELECT request_code, status, needed_by FROM material_requests
         WHERE status IN ('PENDING','PREPARING','READY')
           AND (job_id = :j OR (:p IS NOT NULL AND project_id = :p2)) ORDER BY id DESC LIMIT 1"
    );
    $mrStmt->execute([':j' => $jobId, ':p' => $job['project_id'] ?? null, ':p2' => $job['project_id'] ?? null]);
    $openMr = $mrStmt->fetch() ?: null;
} catch (PDOException $e) {
    $openMr = null; // phase 5 (material requests) not installed
}

json_success([
    'job'          => $job,
    'history'      => $history,
    'attendance'   => $attendance,
    'checklist'    => $checklist,
    'maintenance'  => $maintenance,
    'work_report'  => $workReport,
    // Proof photos the technician took at each installation stage.
    'installation_photos' => $checklistRow ? installation_photos_list((int)$checklistRow['id']) : [],
    // Stage-by-stage schedule and Management review (installation_plan_lib.php).
    'installation_plan'   => $plan = ($checklistRow ? install_plan((int)$checklistRow['id'], $jobId) : []),
    'installation_plan_summary' => install_plan_summary($plan),
    'open_material_request' => $openMr,
    // Installation crew, and the next day (from tomorrow, Sundays skipped) the
    // whole crew is free — pre-filled as the next visit when approving a stage.
    'crew'          => $crewList = (($job['project_id'] && $job['job_type'] === 'INSTALLATION' && crew_available()) ? crew_list((int)$job['project_id']) : []),
    'suggested_next_date' => $crewList
        ? crew_next_free_day(array_column($crewList, 'id'), date('Y-m-d', strtotime('+1 day')), (int)$job['project_id'])
        : date('Y-m-d', strtotime('+1 day')),
    'confirmation' => job_confirmation($jobId),
]);
