<?php
/**
 * POST /api/sr_checklist/update_item.php
 * Body: { item_id, status: PENDING | COMPLETED | NOT_APPLICABLE, remarks?, csrf_token }
 * Tick / untick one item of a service checklist; who and when are recorded.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
$input = json_input();
require_csrf($input);
require_fields($input, ['item_id', 'status']);
if (!srcl_ready()) {
    json_error('Service checklists are not set up yet.', 503);
}
$status = strtoupper(trim((string)$input['status']));
$remarks = trim((string)($input['remarks'] ?? ''));
if (!in_array($status, ['PENDING', 'COMPLETED', 'NOT_APPLICABLE'], true)) {
    json_error('Invalid status.', 422);
}
if (str_len($remarks) > 255) {
    json_error('Remarks are limited to 255 characters.', 422);
}

$pdo = db();
$s = $pdo->prepare('SELECT i.id, i.status, c.id AS checklist_id, c.job_id, c.status AS cl_status FROM sr_checklist_items i JOIN sr_checklists c ON c.id = i.checklist_id WHERE i.id = :id');
$s->execute([':id' => (int)$input['item_id']]);
$item = $s->fetch();
if (!$item) {
    json_error('Checklist item not found.', 404);
}
$job = tech_job_or_fail((int)$item['job_id']);
if (tech_stage_is_closed($job['stage'])) {
    json_error('This job is closed — its checklist can no longer be changed.', 422);
}
if ($why = srcl_edit_blocker(['status' => $item['cl_status']])) {
    json_error($why, 422);
}

$pdo->prepare(
    'UPDATE sr_checklist_items SET status = :s, remarks = :r,
            completed_at = IF(:s2 = "PENDING", NULL, IF(status = :s3 AND completed_at IS NOT NULL, completed_at, NOW())),
            completed_by = IF(:s4 = "PENDING", NULL, IF(status = :s5 AND completed_by IS NOT NULL, completed_by, :u))
     WHERE id = :id'
)->execute([':s' => $status, ':r' => $remarks !== '' ? $remarks : null, ':s2' => $status, ':s3' => $status,
            ':s4' => $status, ':s5' => $status, ':u' => current_user_id(), ':id' => $item['id']]);

$progress = srcl_progress(srcl_items($pdo, (int)$item['checklist_id']));
$pdo->prepare('UPDATE jobs SET progress = :p WHERE id = :j AND stage NOT IN ("COMPLETED","CANCELLED")')->execute([':p' => $progress, ':j' => $job['id']]);
audit_log('SR_CHECKLIST_ITEM:' . $status, 'sr_checklist_items', $job['job_code'] . '#' . $item['id']);
json_success(['progress' => $progress], $status === 'PENDING' ? "Unchecked — {$progress}%" : "Checked — {$progress}%");
