<?php
/**
 * POST /api/sr_checklist/submit.php — Body: { job_id, note?, csrf_token }
 *
 * The technician submits the finished service checklist. Needs every item
 * ticked (or N/A), at least one proof photo per step and the GPS Time Out
 * recorded. The checklist locks; Management is notified on the service
 * request and approves it (job + request COMPLETED) or returns it.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
$input = json_input();
require_csrf($input);
require_fields($input, ['job_id']);
if (!srcl_ready()) {
    json_error('Service checklists are not set up yet.', 503);
}
$note = trim((string)($input['note'] ?? ''));
if (str_len($note) > 1000) {
    json_error('The note is limited to 1000 characters.', 422);
}

$pdo = db();
$pdo->beginTransaction();
try {
    $job = tech_job_or_fail((int)$input['job_id'], true);
    tech_require_lead($job);
    if (tech_stage_is_closed($job['stage'])) {
        $pdo->rollBack();
        json_error('This job is closed.', 422);
    }
    if (!in_array($job['stage'], ['ARRIVED', 'IN_PROGRESS', 'PAUSED'], true)) {
        $pdo->rollBack();
        json_error('Do the work on site first — start the job (Start Work) before submitting the checklist.', 422);
    }
    $cl = srcl_for_job($pdo, $job, true);
    if (!$cl) {
        $pdo->rollBack();
        json_error('This job has no service checklist.', 422);
    }
    $pdo->prepare('SELECT id FROM sr_checklists WHERE id = :c FOR UPDATE')->execute([':c' => $cl['id']]);
    $cl = srcl_for_job($pdo, $job, false);
    if ($why = srcl_edit_blocker($cl)) {
        $pdo->rollBack();
        json_error($why, 409);
    }
    $steps = srcl_steps(srcl_items($pdo, (int)$cl['id']), srcl_photos($pdo, (int)$cl['id']));
    if ($why = srcl_submit_blocker($steps, $job)) {
        $pdo->rollBack();
        json_error($why, 422);
    }
    $pdo->prepare(
        "UPDATE sr_checklists SET status = 'SUBMITTED', submitted_at = NOW(), submitted_by = :u, submit_note = :n,
                reviewed_at = NULL, reviewed_by = NULL, review_note = NULL WHERE id = :c"
    )->execute([':u' => current_user_id(), ':n' => $note !== '' ? $note : null, ':c' => $cl['id']]);
    sr_log((int)$cl['service_request_id'], 'CHECKLIST_SUBMITTED', null, null,
        'Checklist submitted for approval' . ($note !== '' ? ': ' . str_cut($note, 0, 200) : ''));
    $pdo->prepare('UPDATE jobs SET updated_at = CURRENT_TIMESTAMP WHERE id = :j')->execute([':j' => $job['id']]);
    $pdo->commit();
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('SunTrack sr checklist submit: ' . $e->getMessage());
    json_error('The checklist could not be submitted. Please try again.', 500);
}

$sr = srcl_request_for_job((int)$job['id']);
audit_log('SR_CHECKLIST_SUBMIT', 'service_requests', $sr['request_code'] ?? $job['job_code']);
sr_notify_management(($_SESSION['full_name'] ?? 'The technician') . " finished {$cl['request_type']} request " . ($sr['request_code'] ?? '')
    . " ({$job['job_code']}) — the checklist is waiting for your approval.", (int)$cl['service_request_id']);
json_success(['status' => 'SUBMITTED'], 'Checklist submitted. Management will review it — the request is completed when they approve it.');
