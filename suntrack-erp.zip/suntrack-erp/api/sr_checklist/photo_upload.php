<?php
/**
 * POST /api/sr_checklist/photo_upload.php (multipart/form-data)
 * Fields: csrf_token, job_id, step, photo — a proof photo for one step of the
 * job's service checklist. Up to SRCL_PHOTO_MAX_PER_STEP per step.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
if (empty($_POST) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    json_error('That photo is too large (max 8 MB).', 413);
}
require_csrf($_POST);
require_fields($_POST, ['job_id', 'step']);
if (!srcl_ready()) {
    json_error('Service checklists are not set up yet.', 503);
}
$job = tech_job_or_fail((int)$_POST['job_id']);
if (tech_stage_is_closed($job['stage'])) {
    json_error('This job is closed — its photos can no longer be changed.', 422);
}
$pdo = db();
$cl = srcl_for_job($pdo, $job, true);
if (!$cl) {
    json_error('This job has no service checklist.', 422);
}
if ($why = srcl_edit_blocker($cl)) {
    json_error($why, 422);
}
$step = trim((string)$_POST['step']);
$known = $pdo->prepare('SELECT COUNT(*) FROM sr_checklist_items WHERE checklist_id = :c AND step = :s');
$known->execute([':c' => $cl['id'], ':s' => $step]);
if (!(int)$known->fetchColumn()) {
    json_error('Unknown checklist step.', 422);
}
$n = $pdo->prepare('SELECT COUNT(*) FROM sr_checklist_photos WHERE checklist_id = :c AND step = :s');
$n->execute([':c' => $cl['id'], ':s' => $step]);
$count = (int)$n->fetchColumn();
if ($count >= SRCL_PHOTO_MAX_PER_STEP) {
    json_error("{$step} already has the maximum of " . SRCL_PHOTO_MAX_PER_STEP . ' photos.', 422);
}

[$name, $mime, $size, $w, $h] = store_uploaded_image($_FILES['photo'] ?? [], 'sr_checklist_photos');
try {
    $pdo->prepare(
        'INSERT INTO sr_checklist_photos (checklist_id, job_id, step, uploaded_by, file_name, mime, size_bytes, width, height, created_at)
         VALUES (:c, :j, :s, :u, :f, :m, :sz, :w, :h, NOW())'
    )->execute([':c' => $cl['id'], ':j' => $job['id'], ':s' => $step, ':u' => current_user_id(), ':f' => $name,
                ':m' => $mime, ':sz' => $size, ':w' => $w, ':h' => $h]);
} catch (PDOException $e) {
    storage_delete('sr_checklist_photos', $name);
    json_error('The photo could not be saved. Please try again.', 500);
}
audit_log('SR_CHECKLIST_PHOTO:' . $step, 'sr_checklists', $job['job_code']);
json_success(['step' => $step, 'photos' => $count + 1], "Proof photo added to {$step}.");
