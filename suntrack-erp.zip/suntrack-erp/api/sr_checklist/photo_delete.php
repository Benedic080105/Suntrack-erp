<?php
/**
 * POST /api/sr_checklist/photo_delete.php — Body: { photo_id, csrf_token }
 * Remove a proof photo while the checklist can still be edited.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
$input = json_input();
require_csrf($input);
require_fields($input, ['photo_id']);
if (!srcl_ready()) {
    json_error('Service checklists are not set up yet.', 503);
}
$pdo = db();
$s = $pdo->prepare('SELECT p.id, p.job_id, p.step, p.file_name, c.status FROM sr_checklist_photos p JOIN sr_checklists c ON c.id = p.checklist_id WHERE p.id = :id');
$s->execute([':id' => (int)$input['photo_id']]);
$photo = $s->fetch();
if (!$photo) {
    json_error('Photo not found.', 404);
}
$job = tech_job_or_fail((int)$photo['job_id']);
if (tech_stage_is_closed($job['stage'])) {
    json_error('This job is closed — its photos can no longer be changed.', 422);
}
if ($why = srcl_edit_blocker(['status' => $photo['status']])) {
    json_error($why, 422);
}
$pdo->prepare('DELETE FROM sr_checklist_photos WHERE id = :id')->execute([':id' => $photo['id']]);
storage_delete('sr_checklist_photos', $photo['file_name']);
audit_log('SR_CHECKLIST_PHOTO_DELETE:' . $photo['step'], 'sr_checklists', $job['job_code']);
json_success([], 'Photo removed.');
