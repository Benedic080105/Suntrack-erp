<?php
/**
 * GET /api/sr_checklist/photo_view.php?id=N — streams one checklist proof
 * photo to someone allowed to see its job (the technician on it, its client,
 * Management, Admin).
 */
require_once __DIR__ . '/../../config/config.php';
field_mode_enter(true); // a subcontractor sees its own job's photos through the field portal
require_login(true);

if (!srcl_ready()) {
    json_error('Photo not found.', 404);
}
$s = db()->prepare('SELECT job_id, file_name, mime FROM sr_checklist_photos WHERE id = :id');
$s->execute([':id' => (int)($_GET['id'] ?? 0)]);
$photo = $s->fetch();
if (!$photo) {
    json_error('Photo not found.', 404);
}
job_access_or_fail((int)$photo['job_id']);
storage_send('sr_checklist_photos', $photo['file_name'], $photo['mime']);
