<?php
/**
 * POST /api/sr_checklist/review.php — Management only.
 * Body: { service_request_id, decision: APPROVE | RETURN, note?, csrf_token }
 *
 * APPROVE: the job is completed and the service request becomes COMPLETED;
 *          the technician and the client are told.
 * RETURN:  note required — the checklist opens again for the technician.
 */
require_once __DIR__ . '/../../config/config.php';
require_management();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
$input = json_input();
require_csrf($input);
require_fields($input, ['service_request_id', 'decision']);
if (!srcl_ready()) {
    json_error('Service checklists are not set up yet. Run database/phase21_service_checklists.sql.', 503);
}
$decision = strtoupper(trim((string)$input['decision']));
if (!in_array($decision, ['APPROVE', 'RETURN'], true)) {
    json_error('Decision must be APPROVE or RETURN.', 422);
}
$note = trim((string)($input['note'] ?? ''));
if (str_len($note) > 500) {
    json_error('The note is limited to 500 characters.', 422);
}
if ($decision === 'RETURN' && $note === '') {
    json_error('Write what the technician needs to fix.', 422);
}

$pdo = db();
$pdo->beginTransaction();
$changed = [];
try {
    // Job row first, then the request — the same order as a job completion
    // (api/jobs/status.php -> sr_sync_from_job), so the two cannot deadlock.
    $q = $pdo->prepare('SELECT job_id FROM service_requests WHERE id = :id');
    $q->execute([':id' => (int)$input['service_request_id']]);
    $jobId = (int)$q->fetchColumn();
    if (!$jobId) {
        $pdo->rollBack();
        json_error('Service request not found.', 404);
    }
    $j = $pdo->prepare('SELECT * FROM jobs WHERE id = :id FOR UPDATE');
    $j->execute([':id' => $jobId]);
    $job = $j->fetch();
    $sr = sr_lock((int)$input['service_request_id']);
    $c = $pdo->prepare('SELECT * FROM sr_checklists WHERE job_id = :j FOR UPDATE');
    $c->execute([':j' => $sr['job_id']]);
    $cl = $c->fetch();
    if (!$job || !$cl || $cl['status'] !== 'SUBMITTED') {
        $pdo->rollBack();
        json_error('This checklist is not waiting for approval' . ($cl ? ' (it is ' . strtolower($cl['status']) . ').' : '.'), 409);
    }
    $pdo->prepare('UPDATE sr_checklists SET status = :s, reviewed_at = NOW(), reviewed_by = :u, review_note = :n WHERE id = :c')
        ->execute([':s' => $decision === 'APPROVE' ? 'APPROVED' : 'RETURNED', ':u' => current_user_id(),
                   ':n' => $note !== '' ? $note : null, ':c' => $cl['id']]);
    if ($decision === 'APPROVE') {
        sr_log((int)$sr['id'], 'CHECKLIST_APPROVED', null, null, 'Checklist approved by Management' . ($note !== '' ? ': ' . $note : ''));
        $changed = srcl_complete_job($pdo, $job, 'Service checklist approved by Management' . ($note !== '' ? ' — ' . $note : ''));
    } else {
        sr_log((int)$sr['id'], 'CHECKLIST_RETURNED', null, null, 'Checklist returned: ' . $note);
        $pdo->prepare('UPDATE jobs SET updated_at = CURRENT_TIMESTAMP WHERE id = :j')->execute([':j' => $job['id']]);
    }
    $pdo->commit();
} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('SunTrack sr checklist review: ' . $e->getMessage());
    json_error('The decision could not be saved. Please try again.', 500);
}

$label = $sr['request_code'];
audit_log('SR_CHECKLIST_' . $decision, 'service_requests', $label);
if ($decision === 'APPROVE') {
    sr_notify_job_sync($changed, $_SESSION['full_name'] ?? 'Management'); // the client hears it is completed
    sr_notify_technician($job['technician_id'] ? (int)$job['technician_id'] : null,
        "Your checklist for {$label} ({$job['job_code']}) was approved — the request is completed.", (int)$sr['id']);
    json_success(['status' => 'APPROVED'], "Approved. {$job['job_code']} and request {$label} are now COMPLETED.");
}
sr_notify_technician($job['technician_id'] ? (int)$job['technician_id'] : null,
    "Your checklist for {$label} ({$job['job_code']}) was returned: {$note}", (int)$sr['id']);
json_success(['status' => 'RETURNED'], 'Checklist returned to the technician with your note.');
