<?php
/**
 * GET /api/sr_checklist/get.php?job_id=N — the technician's checklist for a
 * service-request job (created from the request's type on first open):
 * steps, items (who ticked them, when), proof photos, review state.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if (!srcl_ready()) {
    json_error('Service checklists are not set up yet. Ask the administrator to run database/phase21_service_checklists.sql.', 503);
}
$job = tech_job_or_fail((int)($_GET['job_id'] ?? 0));
$pdo = db();
$cl = srcl_for_job($pdo, $job, !tech_stage_is_closed($job['stage']));
if (!$cl) {
    json_error('This job has no service checklist (Maintenance jobs use the Maintenance tab).', 404);
}
$sr = srcl_request_for_job((int)$job['id']);
json_success([
    'job' => ['id' => (int)$job['id'], 'job_code' => $job['job_code'], 'job_type' => $job['job_type'], 'stage' => $job['stage'],
              'client_name' => $job['client_name'], 'site_address' => $job['site_address'], 'is_lead' => !empty($job['is_lead']),
              'timed_in' => (bool)tech_open_attendance((int)$job['id'], (int)current_profile_id())],
    'description' => $sr ? (function () use ($pdo, $sr) {
        $d = $pdo->prepare('SELECT description FROM service_requests WHERE id = :id');
        $d->execute([':id' => $sr['id']]);
        return $d->fetchColumn() ?: null;
    })() : null,
    'checklist' => srcl_payload($pdo, $job, $cl),
    'editable' => !tech_stage_is_closed($job['stage']),
]);
