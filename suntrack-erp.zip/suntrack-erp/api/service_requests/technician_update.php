<?php
/**
 * POST /api/service_requests/technician_update.php
 * Technician only, and only on a request assigned to them (checked under a
 * row lock — the id from the browser is never trusted).
 *
 * Body: { id, action, text }
 *   NOTE        append a time-stamped line to the request's technician notes
 *   RESOLUTION  set the resolution (what was found and what was done)
 *
 * Starting, pausing and completing the work are NOT here on purpose: they go
 * through api/jobs/status.php on the request's job, which enforces the GPS
 * Time In, the inspection / work report and the Time Out, and then moves the
 * request's status (see sr_sync_from_job()).
 */
require_once __DIR__ . '/../../middleware/technician.php';
sr_require_phase5();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['id', 'action', 'text']);

$id     = (int)$input['id'];
$action = strtoupper(trim((string)$input['action']));
$text   = trim((string)$input['text']);
$techId = (int)current_profile_id();

if (!in_array($action, ['NOTE', 'RESOLUTION'], true)) {
    json_error('Unknown action.', 422);
}
if ($text === '') {
    json_error('Please type something first.', 422);
}
if (str_len($text) > ($action === 'NOTE' ? 1000 : 5000)) {
    json_error($action === 'NOTE' ? 'A note must be 1000 characters or fewer.' : 'The resolution must be 5000 characters or fewer.', 422);
}

$pdo = db();
$pdo->beginTransaction();
try {
    $sr = sr_lock($id);
    if (!$sr || !sr_field_visible($sr)) {
        $pdo->rollBack();
        json_error('Service request not found.', 404);
    }
    if (in_array($sr['status'], ['CANCELLED', 'REJECTED'], true)) {
        $pdo->rollBack();
        json_error('This request was ' . strtolower($sr['status']) . ' and can no longer be updated.', 422);
    }

    if ($action === 'NOTE') {
        $line  = '[' . date('Y-m-d H:i') . '] ' . $text;
        $notes = trim((string)$sr['technician_notes']);
        $pdo->prepare('UPDATE service_requests SET technician_notes = :n WHERE id = :id')
            ->execute([':n' => $notes === '' ? $line : $notes . "\n" . $line, ':id' => $id]);
        sr_log($id, 'TECH_NOTE', $sr['status'], $sr['status'], $text);
    } else {
        $pdo->prepare('UPDATE service_requests SET resolution = :r WHERE id = :id')
            ->execute([':r' => $text, ':id' => $id]);
        sr_log($id, 'RESOLUTION_UPDATED', $sr['status'], $sr['status'], $text);
    }

    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    json_error('Failed to save. Please try again.', 500);
}

audit_log($action === 'NOTE' ? 'TECH_NOTE' : 'RESOLUTION', 'service_requests', $sr['request_code']);

$who = $_SESSION['full_name'] ?? 'Technician';
$label = sr_label($sr);
sr_notify_management(
    $action === 'NOTE'
        ? "$who added a note on $label: " . str_cut($text, 0, 140)
        : "$who updated the resolution on $label.",
    (int)$sr['id']
);

json_success(['id' => (int)$sr['id']], $action === 'NOTE' ? 'Note added.' : 'Resolution saved.');
