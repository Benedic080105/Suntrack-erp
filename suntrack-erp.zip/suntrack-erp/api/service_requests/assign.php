<?php
/**
 * POST /api/service_requests/assign.php
 * Management only. Assigns — or reassigns — the technician on a request.
 *
 * The first assignment creates the request's job (one job per request, under
 * the same row lock), which is what puts it in the technician's My Assignments
 * and under the geofence. A reassignment moves the existing job to the new
 * technician instead of creating a second one.
 *
 * Body:
 *   id              int   required — service_requests.id
 *   technician_id   int   required — technicians.id (must be an ACTIVE account)
 *   scheduled_date  date  optional — YYYY-MM-DD, sets the service date at the same time
 *   note            str   optional — kept in the request history
 */
require_once __DIR__ . '/../../config/config.php';
require_management(); // Admin role is view/export only; only Management (manager/staff) may mutate.
sr_require_phase5();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['id', 'technician_id']);

$srId   = (int)$input['id'];
$techId = (int)$input['technician_id'];
$note   = trim((string)($input['note'] ?? ''));
$date   = !empty($input['scheduled_date']) ? sr_parse_date($input['scheduled_date'], 'Scheduled date') : null;
if ($date !== null && $date < date('Y-m-d')) {
    json_error('The scheduled date cannot be in the past.', 422);
}

$pdo = db();

$techStmt = $pdo->prepare(
    'SELECT t.id, t.technician_code, u.full_name, u.status
     FROM ' . tech_staff_table() . ' t JOIN users u ON u.id = t.user_id WHERE t.id = :id'
);
$techStmt->execute([':id' => $techId]);
$tech = $techStmt->fetch();
if (!$tech) {
    json_error('Technician not found.', 404);
}
if ($tech['status'] !== 'ACTIVE') {
    json_error("{$tech['full_name']}'s account is not active, so they cannot receive work.", 422);
}

$jobCode = null;
$jobId = null;
$sr = null;
$previousTechId = null;
$newStatus = null;

$pdo->beginTransaction();
try {
    // Row lock — re-read the request under FOR UPDATE so a double-click or
    // two Management users assigning at once can never create two jobs.
    $srStmt = $pdo->prepare(
        'SELECT sr.*, c.address, c.barangay, c.city, c.province
         FROM service_requests sr
         JOIN clients c ON c.id = sr.client_id WHERE sr.id = :id FOR UPDATE'
    );
    $srStmt->execute([':id' => $srId]);
    $sr = $srStmt->fetch();

    if (!$sr) {
        $pdo->rollBack();
        json_error('Service request not found.', 404);
    }
    if (in_array($sr['status'], sr_closed_statuses(), true)) {
        $pdo->rollBack();
        json_error('This request is already ' . strtolower($sr['status']) . ' and can no longer be assigned.', 422);
    }
    if ($sr['status'] === 'PENDING') {
        $pdo->rollBack();
        json_error('Approve the request before assigning a technician.', 422);
    }

    $previousTechId = $sr['assigned_technician_id'] ? (int)$sr['assigned_technician_id'] : null;
    if ($previousTechId === $techId) {
        $pdo->rollBack();
        json_error("{$tech['full_name']} is already assigned to this request.", 422);
    }

    $scheduled = $date ?? $sr['scheduled_date'];
    $reusedExisting = false;

    // Already has a job — move the existing job to the new technician instead
    // of creating a duplicate one.
    if (!empty($sr['job_id'])) {
        $jobStmt = $pdo->prepare('SELECT id, job_code, stage FROM jobs WHERE id = :id FOR UPDATE');
        $jobStmt->execute([':id' => $sr['job_id']]);
        $existingJob = $jobStmt->fetch();

        if ($existingJob) {
            if (tech_stage_is_closed($existingJob['stage'])) {
                $pdo->rollBack();
                json_error("Job {$existingJob['job_code']} is already " . strtolower($existingJob['stage']) . ' and cannot be reassigned.', 422);
            }
            $newStage = $existingJob['stage'] === 'SUBMITTED' ? 'ASSIGNED' : $existingJob['stage'];
            $pdo->prepare('UPDATE jobs SET technician_id = :t, stage = :st, scheduled_date = COALESCE(:d, scheduled_date) WHERE id = :id')
                ->execute([':t' => $techId, ':st' => $newStage, ':d' => $date, ':id' => $existingJob['id']]);
            $pdo->prepare(
                'INSERT INTO job_status_history (job_id, from_stage, to_stage, changed_by, note)
                 VALUES (:j, :from, :to, :u, :note)'
            )->execute([
                ':j' => $existingJob['id'], ':from' => $existingJob['stage'], ':to' => $newStage, ':u' => current_user_id(),
                ':note' => str_cut('Reassigned to ' . $tech['full_name'] . ' from service request ' . $sr['request_code'], 0, 255),
            ]);

            $jobId   = (int)$existingJob['id'];
            $jobCode = $existingJob['job_code'];
            $reusedExisting = true;
        }
        // Falls through to the create branch only if the linked job somehow no longer exists.
    }

    if (!$reusedExisting) {
        // Inherit the request's service location (or the client's plotted
        // site), or the technician can never Time In.
        [$siteLat, $siteLng, $radius] = client_site_location((int)$sr['client_id']);
        if ($sr['location_lat'] !== null && $sr['location_lng'] !== null) {
            $siteLat = (float)$sr['location_lat'];
            $siteLng = (float)$sr['location_lng'];
        }
        $siteAddress = trim((string)$sr['site_address']) !== ''
            ? $sr['site_address']
            : implode(', ', array_filter([$sr['address'], $sr['barangay'], $sr['city'], $sr['province']], fn($v) => trim((string)$v) !== ''));

        $jobStmt = $pdo->prepare(
            'INSERT INTO jobs (job_code, client_id, technician_id, job_type, site_address, site_lat, site_lng, geofence_radius_m, scheduled_date, priority, description, stage, progress)
             VALUES (:code, :client_id, :tech_id, :type, :addr, :lat, :lng, :radius, :sched, :priority, :desc, "ASSIGNED", 0)'
        );
        [$jobId, $jobCode] = insert_job_with_code(fn(string $code) => $jobStmt->execute([
            ':code'      => $code,
            ':client_id' => $sr['client_id'],
            ':tech_id'   => $techId,
            ':type'      => sr_job_type_for((string)$sr['request_type']),
            ':addr'      => str_cut($siteAddress, 0, 255),
            ':lat'       => $siteLat,
            ':lng'       => $siteLng,
            ':radius'    => $radius,
            ':sched'     => $scheduled,
            ':priority'  => $sr['priority'],
            ':desc'      => $sr['request_code'] . ' — ' . ($sr['subject'] ?: $sr['request_type']) . ' (' . $sr['request_type'] . '): ' . $sr['description'],
        ]));

        $pdo->prepare('INSERT INTO job_status_history (job_id, from_stage, to_stage, changed_by, note) VALUES (:j, NULL, "ASSIGNED", :u, :note)')
            ->execute([':j' => $jobId, ':u' => current_user_id(), ':note' => 'Created from service request ' . $sr['request_code']]);
    }

    // Assigning does not rewind a request whose work is already under way.
    $newStatus = in_array($sr['status'], ['APPROVED', 'ASSIGNED', 'SCHEDULED'], true)
        ? ($scheduled ? 'SCHEDULED' : 'ASSIGNED')
        : $sr['status'];

    $pdo->prepare(
        'UPDATE service_requests
         SET status = :s, assigned_technician_id = :t, job_id = :j, scheduled_date = :d
         WHERE id = :id'
    )->execute([':s' => $newStatus, ':t' => $techId, ':j' => $jobId, ':d' => $scheduled, ':id' => $srId]);

    $remark = ($previousTechId ? 'Reassigned to ' : 'Assigned to ') . "{$tech['full_name']} ({$tech['technician_code']}), job $jobCode"
        . ($date ? ", scheduled $date" : '') . ($note !== '' ? " — $note" : '');
    sr_log($srId, $previousTechId ? 'REASSIGNED' : 'ASSIGNED', $sr['status'], $newStatus, $remark);

    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    json_error('Failed to assign technician.', 500);
}

audit_log($previousTechId ? 'REASSIGN' : 'ASSIGN', 'service_requests', $sr['request_code']);

$label = sr_label($sr);
$when  = ($date ?? $sr['scheduled_date']) ? ' on ' . ($date ?? $sr['scheduled_date']) : '';

sr_notify_technician($techId, "You've been assigned service request $label — job $jobCode$when.", $srId);
if ($previousTechId) {
    sr_notify_technician($previousTechId, "Service request $label (job $jobCode) has been reassigned to another technician.", $srId);
}
sr_notify_client($sr, "{$tech['full_name']} has been assigned to your request $label$when.");

json_success(['job_id' => $jobId, 'job_code' => $jobCode, 'status' => $newStatus, 'technician_name' => $tech['full_name']],
    $previousTechId ? 'Technician reassigned.' : 'Technician assigned.');
