<?php
/**
 * GET /api/service_requests/detail.php?id=N
 *
 * One request with everything around it: client (contact, address,
 * coordinates, account status), technician, linked job and the full history.
 *
 * Access is checked server-side:
 *   client       own requests only; internal notes are left out
 *   technician   requests assigned to them only
 *   admin / manager / staff   any request
 */
require_once __DIR__ . '/../../config/config.php';
field_mode_enter(true); // a subcontractor uses this through the field portal
require_login(true);
sr_require_phase5();

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    json_error('Invalid service request id.', 422);
}

$role = current_role();
if (!in_array($role, ['client', 'technician', 'admin', 'manager', 'staff'], true)) {
    json_error('You are not authorized to view service requests.', 403);
}

$pdo = db();
$stmt = $pdo->prepare(
    "SELECT sr.*,
            c.client_code, c.address AS client_address, c.barangay AS client_barangay, c.city AS client_city,
            c.province AS client_province, c.postal_code AS client_postal_code, c.lat AS client_lat, c.lng AS client_lng,
            u.full_name AS client_name, u.phone AS client_phone, u.email AS client_email, u.status AS client_status,
            t.technician_code, tu.full_name AS technician_name, tu.phone AS technician_phone,
            j.job_code, j.stage AS job_stage, j.progress AS job_progress, j.job_type, j.scheduled_date AS job_scheduled_date,
            j.geofence_radius_m AS job_geofence_radius_m,
            cb.full_name AS created_by_name
     FROM service_requests sr
     JOIN clients c ON c.id = sr.client_id
     JOIN users u ON u.id = c.user_id
     LEFT JOIN technicians t ON t.id = sr.assigned_technician_id
     LEFT JOIN users tu ON tu.id = t.user_id
     LEFT JOIN jobs j ON j.id = sr.job_id
     LEFT JOIN users cb ON cb.id = sr.created_by
     WHERE sr.id = :id"
);
$stmt->execute([':id' => $id]);
$sr = $stmt->fetch();

// Same answer for "not yours" as for "does not exist", so ids cannot be probed.
if (!$sr
    || ($role === 'client' && (int)$sr['client_id'] !== (int)current_profile_id())
    || ($role === 'technician' && !sr_field_visible($sr))) {
    json_error('Service request not found.', 404);
}

$historySql = "SELECT h.id, h.action, h.old_status, h.new_status, h.remarks, h.created_at,
                      hu.full_name AS user_name, r.role_key AS user_role
               FROM service_request_history h
               LEFT JOIN users hu ON hu.id = h.user_id
               LEFT JOIN roles r ON r.id = hu.role_id
               WHERE h.service_request_id = :id";
// Internal notes stay internal: a client sees the status story, not the staff chatter.
if ($role === 'client') {
    $historySql .= " AND h.action NOT IN ('NOTE_ADDED','TECH_NOTE')";
}
$historySql .= ' ORDER BY h.id ASC';
$h = $pdo->prepare($historySql);
$h->execute([':id' => $id]);
$history = $h->fetchAll();

$lat = $sr['location_lat'] ?? $sr['client_lat'];
$lng = $sr['location_lng'] ?? $sr['client_lng'];

$result = [
    'request' => [
        'id' => (int)$sr['id'], 'request_code' => $sr['request_code'], 'service_type' => $sr['request_type'],
        'subject' => $sr['subject'], 'description' => $sr['description'], 'priority' => $sr['priority'],
        'status' => $sr['status'], 'date_requested' => $sr['date_requested'], 'scheduled_date' => $sr['scheduled_date'],
        'completion_date' => $sr['completion_date'], 'resolution' => $sr['resolution'],
        'technician_notes' => $sr['technician_notes'],
        'site_address' => $sr['site_address'], 'lat' => $lat, 'lng' => $lng,
        'created_by_name' => $sr['created_by_name'], 'created_at' => $sr['created_at'], 'updated_at' => $sr['updated_at'],
        'is_closed' => in_array($sr['status'], sr_closed_statuses(), true),
    ],
    'client' => [
        'id' => (int)$sr['client_id'], 'client_code' => $sr['client_code'], 'name' => $sr['client_name'],
        'phone' => $sr['client_phone'], 'email' => $sr['client_email'], 'status' => $sr['client_status'],
        'address' => $sr['client_address'], 'barangay' => $sr['client_barangay'], 'city' => $sr['client_city'],
        'province' => $sr['client_province'], 'postal_code' => $sr['client_postal_code'],
        'lat' => $sr['client_lat'], 'lng' => $sr['client_lng'],
    ],
    'technician' => $sr['assigned_technician_id'] ? [
        'id' => (int)$sr['assigned_technician_id'], 'technician_code' => $sr['technician_code'],
        'name' => $sr['technician_name'], 'phone' => $sr['technician_phone'],
    ] : null,
    'job' => $sr['job_id'] ? [
        'id' => (int)$sr['job_id'], 'job_code' => $sr['job_code'], 'stage' => $sr['job_stage'],
        'progress' => (int)$sr['job_progress'], 'job_type' => $sr['job_type'],
        'scheduled_date' => $sr['job_scheduled_date'], 'geofence_radius_m' => (int)$sr['job_geofence_radius_m'],
        'allowed_next' => $role === 'technician' ? tech_allowed_next((string)$sr['job_stage']) : [],
    ] : null,
    'history' => $history,
];

// The job's service checklist (phase 21): steps, items, proof photos and the
// approval state — Management approves it here to complete the request.
$result['checklist'] = null;
$result['checklist_type'] = srcl_ready() ? (srcl_template_for($sr['request_type']) !== null ? $sr['request_type'] : null) : null;
if ($sr['job_id'] && srcl_ready() && in_array($role, ['admin', 'manager', 'staff', 'technician'], true)) {
    $jr = db()->prepare('SELECT * FROM jobs WHERE id = :j');
    $jr->execute([':j' => $sr['job_id']]);
    if (($jobRow = $jr->fetch()) && ($cl = srcl_for_job(db(), $jobRow, false))) {
        $result['checklist'] = srcl_payload(db(), $jobRow, $cl);
    }
}
$result['can_review'] = in_array($role, ['manager', 'staff'], true);

if ($role === 'client') {
    unset($result['request']['technician_notes'], $result['request']['created_by_name']);
    $result['client']['status'] = null;
}

json_success($result);
