<?php
/**
 * POST /api/service_requests/create.php
 *
 * Who may create a request:
 *   client         for themselves only — client_id always comes from the
 *                  session, never from the browser. Starts PENDING.
 *   manager/staff  for any client (client_id required). A request Management
 *                  opens itself starts APPROVED: there is nobody else to
 *                  approve it.
 *   admin          no — Admin is view/export only.
 *
 * Nobody can pick a technician here; assignment is a separate Management step
 * (service_requests/assign.php), so a client can never assign themselves one.
 *
 * Body:
 *   service_type  one of sr_service_types()      required ('request_type' accepted for older pages)
 *   subject       ≤150 chars                     required
 *   description   ≤5000 chars                    required
 *   priority      LOW | NORMAL | HIGH | URGENT   optional, default NORMAL
 *   client_id     int                            Management only, required there
 */
require_once __DIR__ . '/../../config/config.php';
require_role(['client', 'manager', 'staff'], true);
sr_require_phase5();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);

$role = current_role();
$isClient = $role === 'client';

$serviceType = trim((string)($input['service_type'] ?? $input['request_type'] ?? ''));
$subject     = trim((string)($input['subject'] ?? ''));
$description = trim((string)($input['description'] ?? ''));
$priority    = strtoupper(trim((string)($input['priority'] ?? 'NORMAL')));

// Older client pages sent a free-text request_type with no subject: keep that
// text as the subject and file it as "Other" rather than rejecting it.
if (!in_array($serviceType, sr_service_types(), true)) {
    if ($serviceType !== '' && $subject === '') {
        $subject = $serviceType;
    }
    $serviceType = $serviceType === '' ? '' : 'Other';
}
if ($serviceType === '') {
    json_error('Please choose a service type.', 422);
}
if ($subject === '') {
    json_error('Please enter a subject.', 422);
}
if (str_len($subject) > 150) {
    json_error('The subject must be 150 characters or fewer.', 422);
}
if ($description === '') {
    json_error('Please describe the issue.', 422);
}
if (str_len($description) > 5000) {
    json_error('The description must be 5000 characters or fewer.', 422);
}
if (!in_array($priority, sr_priorities(), true)) {
    json_error('Invalid priority value.', 422);
}

$pdo = db();

if ($isClient) {
    $clientId = (int)current_profile_id();
    if (!$clientId) {
        json_error('Client profile not found.', 404);
    }
} else {
    $clientId = (int)($input['client_id'] ?? 0);
    if ($clientId <= 0) {
        json_error('Please choose the client this request is for.', 422);
    }
}

$clientStmt = $pdo->prepare(
    'SELECT c.id, c.client_code, c.address, c.barangay, c.city, c.province, c.lat, c.lng, u.full_name, u.status
     FROM clients c JOIN users u ON u.id = c.user_id WHERE c.id = :id'
);
$clientStmt->execute([':id' => $clientId]);
$client = $clientStmt->fetch();
if (!$client) {
    json_error('Client not found.', 404);
}

// Service location starts at the client's plotted site.
$siteAddress = implode(', ', array_filter(
    [$client['address'], $client['barangay'], $client['city'], $client['province']],
    fn($v) => trim((string)$v) !== ''
));

// Attach the client's most recent solar system, if any.
$sysStmt = $pdo->prepare('SELECT id FROM solar_systems WHERE client_id = :c ORDER BY id DESC LIMIT 1');
$sysStmt->execute([':c' => $clientId]);
$systemId = $sysStmt->fetchColumn() ?: null;

$status = $isClient ? 'PENDING' : 'APPROVED';

$stmt = $pdo->prepare(
    'INSERT INTO service_requests
        (request_code, client_id, created_by, solar_system_id, request_type, subject, description,
         site_address, location_lat, location_lng, priority, status)
     VALUES (:code, :client_id, :created_by, :system_id, :type, :subject, :desc,
             :addr, :lat, :lng, :priority, :status)'
);

$pdo->beginTransaction();
try {
    // Collision-safe sequential code (see with_unique_code() in helpers.php).
    $code = with_unique_code('service_requests', 'request_code', 'SR-' . date('Y') . '-', function (string $code) use ($stmt, $clientId, $systemId, $serviceType, $subject, $description, $siteAddress, $client, $priority, $status) {
        $stmt->execute([
            ':code'       => $code,
            ':client_id'  => $clientId,
            ':created_by' => current_user_id(),
            ':system_id'  => $systemId,
            ':type'       => $serviceType,
            ':subject'    => $subject,
            ':desc'       => $description,
            ':addr'       => $siteAddress !== '' ? str_cut($siteAddress, 0, 255) : null,
            ':lat'        => $client['lat'],
            ':lng'        => $client['lng'],
            ':priority'   => $priority,
            ':status'     => $status,
        ]);
        return $code;
    });
    $newId = (int)$pdo->lastInsertId();

    sr_log($newId, 'CREATED', null, 'PENDING', $isClient ? 'Submitted by the client.' : 'Opened by Management.');
    if (!$isClient) {
        sr_log($newId, 'APPROVED', 'PENDING', 'APPROVED', 'Opened by Management, so approved on creation.');
    }

    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    throw $e;
}

audit_log('CREATE', 'service_requests', $code);

$sr = ['id' => $newId, 'client_id' => $clientId, 'request_code' => $code, 'subject' => $subject, 'request_type' => $serviceType];
if ($isClient) {
    // Notify all admin/manager/staff users of the new request.
    $staffUsers = $pdo->query(
        "SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id
         WHERE r.role_key IN ('admin','manager','staff') AND u.status = 'ACTIVE'"
    )->fetchAll();
    foreach ($staffUsers as $u) {
        notify((int)$u['id'], 'SERVICE_REQUEST', "New service request $code from {$client['full_name']}: $subject ($serviceType, $priority)", 'service_requests', $newId);
    }
} else {
    sr_notify_client($sr, "A service request " . sr_label($sr) . " was opened for you by our team.");
}

json_success(['id' => $newId, 'request_code' => $code, 'status' => $status], 'Service request ' . $code . ' submitted.');
