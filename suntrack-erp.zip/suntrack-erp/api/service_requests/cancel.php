<?php
/**
 * POST /api/service_requests/cancel.php
 * Client only: withdraw one of their OWN requests while it is still PENDING or
 * APPROVED — i.e. before a technician has been sent. After that the client
 * contacts the office, and Management cancels it (service_requests/update.php),
 * because a technician may already be on the way.
 *
 * Body: { id, reason? }
 */
require_once __DIR__ . '/../../middleware/client.php';
sr_require_phase5();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['id']);

$id = (int)$input['id'];
$reason = trim((string)($input['reason'] ?? ''));
if (str_len($reason) > 500) {
    json_error('The reason must be 500 characters or fewer.', 422);
}

$pdo = db();
$pdo->beginTransaction();
try {
    $sr = sr_lock($id);
    if (!$sr || (int)$sr['client_id'] !== (int)current_profile_id()) {
        $pdo->rollBack();
        json_error('Service request not found.', 404);
    }
    if (!in_array($sr['status'], ['PENDING', 'APPROVED'], true) || !empty($sr['job_id'])) {
        $pdo->rollBack();
        json_error('A technician has already been arranged for this request. Please contact our office to cancel it.', 422);
    }

    $pdo->prepare('UPDATE service_requests SET status = "CANCELLED" WHERE id = :id')->execute([':id' => $id]);
    sr_log($id, 'CANCELLED', $sr['status'], 'CANCELLED', $reason !== '' ? "Cancelled by the client: $reason" : 'Cancelled by the client.');

    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    json_error('Failed to cancel the request.', 500);
}

audit_log('CANCEL', 'service_requests', $sr['request_code']);
sr_notify_management(($_SESSION['full_name'] ?? 'A client') . ' cancelled service request ' . sr_label($sr) . '.' . ($reason !== '' ? " Reason: $reason" : ''), (int)$sr['id']);

json_success(['id' => (int)$sr['id'], 'status' => 'CANCELLED'], 'Request cancelled.');
