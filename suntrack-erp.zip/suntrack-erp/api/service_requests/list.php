<?php
/**
 * GET /api/service_requests/list.php
 *
 * Scoped by role, server-side:
 *   client       only their own requests (technician notes are not included)
 *   technician   only requests assigned to them
 *   admin / manager / staff   every request
 *
 * Filters: status, priority, service_type, technician_id, client_id,
 *          unassigned=1, open=1 (not completed/cancelled/rejected),
 *          search, date_from / date_to (requested date)
 */
require_once __DIR__ . '/../../config/config.php';
field_mode_enter(true); // a subcontractor uses this through the field portal
require_login(true);

$pdo = db();
[$pageLimit, $pageOffset] = list_page(500);
$role = current_role();
$phase5 = sr_phase5_ready();

$where = [];
$params = [];

if ($role === 'client') {
    $where[] = 'sr.client_id = :client_id';
    $params[':client_id'] = (int)current_profile_id();
} elseif ($role === 'technician') {
    // A subcontractor (field mode) sees the requests behind the jobs its company works.
    $where[] = field_subcontractor()
        ? 'sr.job_id IN (SELECT id FROM jobs WHERE technician_id = :tech_id)'
        : 'sr.assigned_technician_id = :tech_id';
    $params[':tech_id'] = (int)current_profile_id();
} elseif (!in_array($role, ['admin', 'manager', 'staff'], true)) {
    json_error('You are not authorized to view service requests.', 403);
}

// Optional filters (admin/staff use these most).
if (!empty($_GET['status'])) {
    if (!in_array($_GET['status'], sr_statuses(), true)) {
        json_error('Invalid status filter.', 422);
    }
    $where[] = 'sr.status = :status';
    $params[':status'] = $_GET['status'];
}
if (!empty($_GET['priority'])) {
    if (!in_array($_GET['priority'], sr_priorities(), true)) {
        json_error('Invalid priority filter.', 422);
    }
    $where[] = 'sr.priority = :priority';
    $params[':priority'] = $_GET['priority'];
}
if (!empty($_GET['service_type'])) {
    $where[] = 'sr.request_type = :stype';
    $params[':stype'] = (string)$_GET['service_type'];
}
if (!empty($_GET['open'])) {
    $where[] = "sr.status NOT IN ('COMPLETED','CANCELLED','REJECTED')";
}
if (in_array($role, ['admin', 'manager', 'staff'], true)) {
    if (!empty($_GET['technician_id'])) {
        $where[] = 'sr.assigned_technician_id = :f_tech';
        $params[':f_tech'] = (int)$_GET['technician_id'];
    }
    if (!empty($_GET['client_id'])) {
        $where[] = 'sr.client_id = :f_client';
        $params[':f_client'] = (int)$_GET['client_id'];
    }
}
$searchCols = search_columns('service_requests');
if ($phase5) {
    $searchCols[] = 'sr.subject';
}
if ($clause = search_clause($_GET['search'] ?? '', $searchCols, $params)) {
    $where[] = $clause;
}
if (!empty($_GET['unassigned'])) {
    $where[] = 'sr.assigned_technician_id IS NULL';
}
apply_date_range('sr.date_requested', $where, $params);

$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$extra = $phase5
    ? 'c.barangay, COALESCE(sr.location_lat, c.lat) AS map_lat, COALESCE(sr.location_lng, c.lng) AS map_lng,'
    : 'NULL AS barangay, c.lat AS map_lat, c.lng AS map_lng,';

$sql = "SELECT sr.*, c.client_code, u.full_name AS client_name, u.phone AS client_phone, u.email AS client_email,
               c.address AS client_address, c.city AS client_city, c.province AS client_province,
               $extra
               t.technician_code, tu.full_name AS technician_name, tu.phone AS technician_phone,
               j.job_code, j.stage AS job_stage, j.progress AS job_progress, " . (srcl_ready() ? 'srcl.status AS checklist_status' : 'NULL AS checklist_status') . "
        FROM service_requests sr
        JOIN clients c ON c.id = sr.client_id
        JOIN users u ON u.id = c.user_id
        LEFT JOIN technicians t ON t.id = sr.assigned_technician_id
        LEFT JOIN users tu ON tu.id = t.user_id
        LEFT JOIN jobs j ON j.id = sr.job_id
        " . (srcl_ready() ? 'LEFT JOIN sr_checklists srcl ON srcl.job_id = sr.job_id' : '') . "
        $whereSql
        ORDER BY sr.date_requested DESC, sr.id DESC
        " . list_page_sql($pageLimit, $pageOffset);

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = list_page_finish($stmt->fetchAll(), $pageLimit, $pageOffset);

// Technician working notes are internal; the client sees the resolution instead.
if ($role === 'client') {
    foreach ($rows as &$r) {
        unset($r['technician_notes'], $r['created_by']);
    }
    unset($r);
}

json_success($rows);
