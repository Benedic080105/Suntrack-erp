<?php
/**
 * POST /api/service_requests/update.php
 * Management only (Admin is view/export only). Every change is made under a
 * row lock, written to service_request_history, and announced to whoever it
 * affects.
 *
 * Body: { id, action, ... }
 *
 *   APPROVE       PENDING -> APPROVED
 *   REJECT        PENDING / APPROVED -> REJECTED                 remarks optional
 *   SET_PRIORITY  any open request                               priority required
 *   SCHEDULE      set / change the service date                  scheduled_date (YYYY-MM-DD) required
 *                 ASSIGNED -> SCHEDULED; other open statuses keep their status.
 *                 The linked job's date moves with it.
 *   HOLD          ASSIGNED / SCHEDULED / IN_PROGRESS -> ON_HOLD  remarks optional
 *   RESUME        ON_HOLD -> back to where the work actually is
 *   CANCEL        any open request -> CANCELLED                  remarks optional
 *                 Cancels the linked job too, if it is still open.
 *   COMPLETE      close a request that has no open linked job    resolution optional
 *                 (a request with an open job is completed by the technician
 *                 finishing that job, so its GPS / report gates still apply)
 *   NOTE          add a Management note to the history          remarks required
 */
require_once __DIR__ . '/../../config/config.php';
require_management(); // Admin role is view/export only; only Management (manager/staff) may mutate.
sr_require_phase5();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['id', 'action']);

$id      = (int)$input['id'];
$action  = strtoupper(trim((string)$input['action']));
$remarks = trim((string)($input['remarks'] ?? ''));
if (str_len($remarks) > 1000) {
    json_error('Remarks must be 1000 characters or fewer.', 422);
}

$known = ['APPROVE', 'REJECT', 'SET_PRIORITY', 'SCHEDULE', 'HOLD', 'RESUME', 'CANCEL', 'COMPLETE', 'NOTE'];
if (!in_array($action, $known, true)) {
    json_error('Unknown action.', 422);
}
if ($action === 'NOTE' && $remarks === '') {
    json_error('Please type the note to add.', 422);
}

$pdo = db();
$pdo->beginTransaction();

$sr = null;
$newStatus = null;
$message = 'Service request updated.';
$after = [];   // notifications to send once the transaction has committed

try {
    $sr = sr_lock($id);
    if (!$sr) {
        $pdo->rollBack();
        json_error('Service request not found.', 404);
    }

    $old    = $sr['status'];
    $closed = in_array($old, sr_closed_statuses(), true);
    $label  = sr_label($sr);
    $techId = $sr['assigned_technician_id'] ? (int)$sr['assigned_technician_id'] : null;

    // The linked job, when there is one.
    $job = null;
    if (!empty($sr['job_id'])) {
        $jobStmt = $pdo->prepare('SELECT id, job_code, stage, technician_id FROM jobs WHERE id = :id FOR UPDATE');
        $jobStmt->execute([':id' => $sr['job_id']]);
        $job = $jobStmt->fetch() ?: null;
    }
    $jobOpen = $job && !tech_stage_is_closed($job['stage']);

    if ($closed && !in_array($action, ['NOTE'], true)) {
        $pdo->rollBack();
        json_error('This request is already ' . strtolower($old) . ' and can no longer be changed.', 422);
    }

    switch ($action) {
        case 'APPROVE':
            if ($old !== 'PENDING') {
                $pdo->rollBack();
                json_error('Only pending requests can be approved.', 422);
            }
            $newStatus = 'APPROVED';
            $pdo->prepare('UPDATE service_requests SET status = "APPROVED" WHERE id = :id')->execute([':id' => $id]);
            sr_log($id, 'APPROVED', $old, $newStatus, $remarks);
            $after[] = ['client', "Your request $label was approved. A technician will be assigned shortly."];
            $message = 'Request approved.';
            break;

        case 'REJECT':
            if (!in_array($old, ['PENDING', 'APPROVED'], true)) {
                $pdo->rollBack();
                json_error('This request can no longer be rejected. Cancel it instead.', 422);
            }
            $newStatus = 'REJECTED';
            $pdo->prepare('UPDATE service_requests SET status = "REJECTED" WHERE id = :id')->execute([':id' => $id]);
            sr_log($id, 'REJECTED', $old, $newStatus, $remarks);
            $after[] = ['client', "Your request $label was rejected." . ($remarks !== '' ? " Reason: $remarks" : '')];
            $message = 'Request rejected.';
            break;

        case 'SET_PRIORITY':
            require_fields($input, ['priority']);
            $priority = strtoupper((string)$input['priority']);
            if (!in_array($priority, sr_priorities(), true)) {
                $pdo->rollBack();
                json_error('Invalid priority value.', 422);
            }
            if ($priority === $sr['priority']) {
                $pdo->rollBack();
                json_error('The request already has that priority.', 422);
            }
            $pdo->prepare('UPDATE service_requests SET priority = :p WHERE id = :id')->execute([':p' => $priority, ':id' => $id]);
            if ($jobOpen) {
                $pdo->prepare('UPDATE jobs SET priority = :p WHERE id = :id')->execute([':p' => $priority, ':id' => $job['id']]);
            }
            sr_log($id, 'PRIORITY_CHANGED', $old, $old, "Priority {$sr['priority']} → $priority" . ($remarks !== '' ? " — $remarks" : ''));
            if ($techId) {
                $after[] = ['tech', "Priority of $label changed to $priority."];
            }
            $message = 'Priority updated.';
            break;

        case 'SCHEDULE':
            require_fields($input, ['scheduled_date']);
            $date = sr_parse_date($input['scheduled_date'], 'Scheduled date');
            if ($date < date('Y-m-d')) {
                $pdo->rollBack();
                json_error('The scheduled date cannot be in the past.', 422);
            }
            if (!in_array($old, ['APPROVED', 'ASSIGNED', 'SCHEDULED', 'IN_PROGRESS', 'ON_HOLD'], true)) {
                $pdo->rollBack();
                json_error('Approve the request before scheduling it.', 422);
            }
            // SCHEDULED means "technician + date"; an APPROVED request without a
            // technician keeps its status and simply carries the date forward.
            $newStatus = $old === 'ASSIGNED' ? 'SCHEDULED' : $old;
            $pdo->prepare('UPDATE service_requests SET scheduled_date = :d, status = :s WHERE id = :id')
                ->execute([':d' => $date, ':s' => $newStatus, ':id' => $id]);
            if ($jobOpen) {
                $pdo->prepare('UPDATE jobs SET scheduled_date = :d WHERE id = :id')->execute([':d' => $date, ':id' => $job['id']]);
            }
            $verb = $sr['scheduled_date'] ? 'RESCHEDULED' : 'SCHEDULED';
            sr_log($id, $verb, $old, $newStatus, ($sr['scheduled_date'] ? "From {$sr['scheduled_date']} to $date" : "Service date set to $date") . ($remarks !== '' ? " — $remarks" : ''));
            $after[] = ['client', "Your request $label is scheduled for $date."];
            if ($techId) {
                $after[] = ['tech', "$label is scheduled for $date" . ($job ? " (job {$job['job_code']})." : '.')];
            }
            $message = 'Service date ' . ($verb === 'RESCHEDULED' ? 'changed' : 'set') . " to $date.";
            break;

        case 'HOLD':
            if (!in_array($old, ['ASSIGNED', 'SCHEDULED', 'IN_PROGRESS'], true)) {
                $pdo->rollBack();
                json_error('Only assigned, scheduled or in-progress requests can be put on hold.', 422);
            }
            $newStatus = 'ON_HOLD';
            $pdo->prepare('UPDATE service_requests SET status = "ON_HOLD" WHERE id = :id')->execute([':id' => $id]);
            sr_log($id, 'PUT_ON_HOLD', $old, $newStatus, $remarks !== '' ? $remarks : 'Put on hold by Management.');
            $after[] = ['client', "Your request $label has been put on hold." . ($remarks !== '' ? " $remarks" : '')];
            if ($techId) {
                $after[] = ['tech', "$label has been put on hold by Management." . ($remarks !== '' ? " $remarks" : '')];
            }
            $message = 'Request put on hold.';
            break;

        case 'RESUME':
            if ($old !== 'ON_HOLD') {
                $pdo->rollBack();
                json_error('Only requests on hold can be resumed.', 422);
            }
            if ($jobOpen && in_array($job['stage'], tech_field_stages(), true)) {
                // The technician is already out on it; a paused job is resumed from the field app.
                $newStatus = 'IN_PROGRESS';
            } elseif ($techId) {
                $newStatus = $sr['scheduled_date'] ? 'SCHEDULED' : 'ASSIGNED';
            } else {
                $newStatus = 'APPROVED';
            }
            $pdo->prepare('UPDATE service_requests SET status = :s WHERE id = :id')->execute([':s' => $newStatus, ':id' => $id]);
            sr_log($id, 'RESUMED', $old, $newStatus, $remarks !== '' ? $remarks : 'Resumed by Management.');
            $after[] = ['client', "Work on your request $label has resumed."];
            if ($techId) {
                $after[] = ['tech', "$label is active again — it is no longer on hold."];
            }
            $message = 'Request resumed.';
            break;

        case 'CANCEL':
            $newStatus = 'CANCELLED';
            $pdo->prepare('UPDATE service_requests SET status = "CANCELLED" WHERE id = :id')->execute([':id' => $id]);
            if ($jobOpen) {
                $pdo->prepare('UPDATE jobs SET stage = "CANCELLED" WHERE id = :id')->execute([':id' => $job['id']]);
                $pdo->prepare(
                    'INSERT INTO job_status_history (job_id, from_stage, to_stage, changed_by, note)
                     VALUES (:j, :from, "CANCELLED", :u, :note)'
                )->execute([
                    ':j' => $job['id'], ':from' => $job['stage'], ':u' => current_user_id(),
                    ':note' => str_cut('Service request ' . $sr['request_code'] . ' cancelled by Management' . ($remarks !== '' ? ': ' . $remarks : ''), 0, 255),
                ]);
                // A technician freed from their only field job is available again.
                if ($job['technician_id'] && !tech_active_field_jobs((int)$job['technician_id'], (int)$job['id'])
                    && tech_availability((int)$job['technician_id']) === 'BUSY') {
                    tech_set_availability((int)$job['technician_id'], 'AVAILABLE');
                }
            }
            sr_log($id, 'CANCELLED', $old, $newStatus, ($remarks !== '' ? $remarks : 'Cancelled by Management.') . ($jobOpen ? " Job {$job['job_code']} cancelled with it." : ''));
            $after[] = ['client', "Your request $label was cancelled." . ($remarks !== '' ? " Reason: $remarks" : '')];
            if ($techId) {
                $after[] = ['tech', "$label was cancelled by Management" . ($jobOpen ? " — job {$job['job_code']} is closed." : '.')];
            }
            $message = 'Request cancelled.';
            break;

        case 'COMPLETE':
            if ($jobOpen) {
                $pdo->rollBack();
                json_error(
                    "Job {$job['job_code']} is still " . tech_stage_label($job['stage']) . '. The technician completes it from the field app '
                    . '(GPS Time In, work report, Time Out), which closes this request automatically. Cancel the request instead if the work is no longer needed.',
                    422
                );
            }
            if (!in_array($old, ['APPROVED', 'ASSIGNED', 'SCHEDULED', 'IN_PROGRESS', 'ON_HOLD'], true)) {
                $pdo->rollBack();
                json_error('Approve the request before completing it.', 422);
            }
            $resolution = trim((string)($input['resolution'] ?? ''));
            if (str_len($resolution) > 5000) {
                $pdo->rollBack();
                json_error('The resolution must be 5000 characters or fewer.', 422);
            }
            $newStatus = 'COMPLETED';
            $pdo->prepare(
                'UPDATE service_requests SET status = "COMPLETED", completion_date = NOW(),
                        resolution = COALESCE(NULLIF(:r, ""), resolution) WHERE id = :id'
            )->execute([':r' => $resolution, ':id' => $id]);
            sr_log($id, 'COMPLETED', $old, $newStatus, $resolution !== '' ? "Resolution: $resolution" : 'Closed by Management.');
            $after[] = ['client', "Your service request $label has been completed."];
            if ($techId) {
                $after[] = ['tech', "$label was closed by Management."];
            }
            $message = 'Request marked completed.';
            break;

        case 'NOTE':
            sr_log($id, 'NOTE_ADDED', $old, $old, $remarks);
            // Touch the row so every open screen picks the note up via the sync feed.
            $pdo->prepare('UPDATE service_requests SET updated_at = CURRENT_TIMESTAMP WHERE id = :id')->execute([':id' => $id]);
            if ($techId) {
                $after[] = ['tech', "Management added a note to $label: " . str_cut($remarks, 0, 120)];
            }
            $message = 'Note added.';
            break;
    }

    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    throw $e;
}

audit_log($action, 'service_requests', $sr['request_code']);

foreach ($after as [$who, $text]) {
    if ($who === 'client') {
        sr_notify_client($sr, $text);
    } elseif ($who === 'tech') {
        sr_notify_technician($sr['assigned_technician_id'] ? (int)$sr['assigned_technician_id'] : null, $text, (int)$sr['id']);
    }
}

json_success(['id' => (int)$sr['id'], 'status' => $newStatus ?? $sr['status']], $message);
