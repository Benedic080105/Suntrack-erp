<?php
/**
 * GET /api/technician/job_details.php?job_id=N
 *
 * Everything the technician needs about one of *their own* jobs. Ownership is
 * re-verified server-side through tech_job_or_fail() — a job_id typed into the
 * URL bar or injected by JavaScript is worthless without the assignment.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed.', 405);
}

$jobId  = (int)($_GET['job_id'] ?? 0);
$techId = (int)current_profile_id();
$job    = tech_job_or_fail($jobId);
$pdo    = db();

// --- Status timeline (real history, never hardcoded) -----------------------
$historyStmt = $pdo->prepare(
    'SELECT h.id, h.from_stage, h.to_stage, h.note, h.created_at, u.full_name AS changed_by_name
     FROM job_status_history h
     LEFT JOIN users u ON u.id = h.changed_by
     WHERE h.job_id = :j ORDER BY h.id ASC'
);
$historyStmt->execute([':j' => $jobId]);

// --- Attendance ------------------------------------------------------------
$attStmt = $pdo->prepare(
    'SELECT id, time_in, time_out, distance_in_m, distance_out_m, geofence_status
     FROM attendance WHERE job_id = :j AND technician_id = :t ORDER BY id DESC'
);
$attStmt->execute([':j' => $jobId, ':t' => $techId]);
$attendance = $attStmt->fetchAll();

// --- Installation ----------------------------------------------------------
$installation = null;
$checklist = tech_checklist_for_job($jobId);
if ($checklist) {
    $installation = tech_checklist_counts((int)$checklist['id']);
    $installation['checklist_id'] = (int)$checklist['id'];
}

// --- Maintenance -----------------------------------------------------------
$maintenance = null;
$record = tech_maintenance_record_for_job($job, false);
if ($record) {
    $maintenance = [
        'id'                 => (int)$record['id'],
        'status'             => $record['status'],
        'panel_condition'    => $record['panel_condition'],
        'battery_condition'  => $record['battery_condition'],
        'inverter_condition' => $record['inverter_condition'],
        'completion_date'    => $record['completion_date'],
        'counts'             => tech_maintenance_counts((int)$record['id']),
    ];
}

// --- Work report -----------------------------------------------------------
$reportStmt = $pdo->prepare(
    'SELECT id, report_code, status, submitted_date FROM work_reports WHERE job_id = :j AND technician_id = :t LIMIT 1'
);
$reportStmt->execute([':j' => $jobId, ':t' => $techId]);
$report = $reportStmt->fetch() ?: null;

// --- Solar system at this site --------------------------------------------
$sysStmt = $pdo->prepare(
    'SELECT system_code, panel_brand, inverter_brand, battery_brand, capacity_kw, installation_date, warranty_info, status
     FROM solar_systems WHERE client_id = :c ORDER BY id DESC LIMIT 1'
);
$sysStmt->execute([':c' => $job['client_id']]);
$system = $sysStmt->fetch() ?: null;

json_success([
    'job' => [
        'id'                => (int)$job['id'],
        'job_code'          => $job['job_code'],
        'job_type'          => $job['job_type'],
        'stage'             => $job['stage'],
        'progress'          => (int)$job['progress'],
        'priority'          => $job['priority'],
        'scheduled_date'    => $job['scheduled_date'],
        'description'       => $job['description'],
        'site_address'      => $job['site_address'],
        'site_lat'          => $job['site_lat'] !== null ? (float)$job['site_lat'] : null,
        'site_lng'          => $job['site_lng'] !== null ? (float)$job['site_lng'] : null,
        'geofence_radius_m' => tech_geofence_radius($job),
        'created_at'        => $job['created_at'],
        'updated_at'        => $job['updated_at'],
        'allowed_next'      => tech_allowed_next($job['stage']),
        'is_closed'         => tech_stage_is_closed($job['stage']),
    ],
    // Contact details are released only because this technician is the one
    // assigned to attend the site.
    'client' => [
        'name'        => $job['client_name'],
        'client_code' => $job['client_code'],
        'phone'       => $job['client_phone'],
        'email'       => $job['client_email'],
        'address'     => $job['client_address'],
        'city'        => $job['city'],
        'province'    => $job['province'],
    ],
    'project' => $job['project_code'] ? [
        'project_code' => $job['project_code'],
        'site_name'    => $job['site_name'],
        'progress'     => (int)$job['project_progress'],
    ] : null,
    'solar_system' => $system,
    'history'      => $historyStmt->fetchAll(),
    'attendance'   => $attendance,
    'installation' => $installation,
    'maintenance'  => $maintenance,
    'work_report'  => $report,
    // Subcontractor (field mode): the company's assignment on this job.
    'subcontract'  => field_subcontractor() ? (field_assignment_info($pdo, [(int)$job['id']])[(int)$job['id']] ?? null) : null,
]);
