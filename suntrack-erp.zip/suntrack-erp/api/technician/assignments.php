<?php
/**
 * GET /api/technician/assignments.php
 *
 * The technician's open assignments, plus the KPI numbers the dashboard shows.
 * Optional ?lat= &lng= — when the browser supplies a GPS fix, every job comes
 * back with a live distance and INSIDE/OUTSIDE geofence flag.
 *
 * Scope: the session's technician only. No job_id is accepted from the client.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed.', 405);
}

$techId = current_profile_id();
if (!$techId) {
    json_error('Technician profile not found.', 404);
}

$pdo = db();

$hasFix = isset($_GET['lat'], $_GET['lng']) && is_numeric($_GET['lat']) && is_numeric($_GET['lng']);
$lat = $hasFix ? (float)$_GET['lat'] : null;
$lng = $hasFix ? (float)$_GET['lng'] : null;

$stmt = $pdo->prepare(
    "SELECT j.id, j.job_code, j.job_type, j.stage, j.progress, j.priority, j.scheduled_date, j.technician_id, j.project_id,
            j.description, j.site_address, j.site_lat, j.site_lng, j.geofence_radius_m, j.updated_at,
            c.client_code, cu.full_name AS client_name,
            p.project_code,
            ic.progress AS checklist_progress,
            (SELECT COUNT(*) FROM installation_items ii WHERE ii.checklist_id = ic.id) AS checklist_total,
            (SELECT COUNT(*) FROM installation_items ii2 WHERE ii2.checklist_id = ic.id AND ii2.status = 'PENDING') AS checklist_pending,
            a.id   AS attendance_id,
            a.time_in, a.time_out, a.distance_in_m, a.distance_out_m,
            (SELECT wr.report_code FROM work_reports wr WHERE wr.job_id = j.id LIMIT 1) AS report_code
     FROM jobs j
     JOIN clients c ON c.id = j.client_id
     JOIN users cu  ON cu.id = c.user_id
     LEFT JOIN projects p ON p.id = j.project_id
     LEFT JOIN installation_checklists ic ON ic.job_id = j.id
     LEFT JOIN attendance a ON a.id = (
        SELECT a2.id FROM attendance a2
        WHERE a2.job_id = j.id AND a2.technician_id = :t2
        ORDER BY a2.id DESC LIMIT 1
     )
     WHERE " . crew_job_condition('j', ':t') . " AND j.stage NOT IN ('COMPLETED','CANCELLED')
     ORDER BY FIELD(j.priority,'URGENT','HIGH','NORMAL','LOW'), j.scheduled_date ASC, j.id ASC"
);
// Jobs this technician leads, plus installations where they are on the crew.
$stmt->execute([':t' => $techId, ':t2' => $techId] + (crew_available() ? [':tc' => $techId] : []));
$rows = $stmt->fetchAll();

$assignments = [];
foreach ($rows as $r) {
    $radius   = tech_geofence_radius($r);
    $distance = null;
    $inside   = null;

    if ($hasFix && $r['site_lat'] !== null && $r['site_lng'] !== null) {
        $distance = round(distance_meters((float)$r['site_lat'], (float)$r['site_lng'], $lat, $lng));
        $inside   = $distance <= $radius;
    }

    $timedIn = $r['time_in'] !== null && $r['time_out'] === null;
    $isLead  = (int)$r['technician_id'] === (int)$techId;

    $assignments[] = [
        'id'                 => (int)$r['id'],
        'job_code'           => $r['job_code'],
        'job_type'           => $r['job_type'],
        'client_name'        => $r['client_name'],
        'client_code'        => $r['client_code'],
        'project_code'       => $r['project_code'],
        'site_address'       => $r['site_address'],
        'site_lat'           => $r['site_lat'] !== null ? (float)$r['site_lat'] : null,
        'site_lng'           => $r['site_lng'] !== null ? (float)$r['site_lng'] : null,
        'scheduled_date'     => $r['scheduled_date'],
        'priority'           => $r['priority'],
        'description'        => $r['description'],
        'stage'              => $r['stage'],
        'progress'           => (int)$r['progress'],
        'geofence_radius_m'  => $radius,
        'distance_m'         => $distance,
        'inside_geofence'    => $inside,
        'has_coordinates'    => $r['site_lat'] !== null && $r['site_lng'] !== null,
        'timed_in'           => $timedIn,
        'time_in'            => $r['time_in'],
        'time_out'           => $r['time_out'],
        'distance_in_m'      => $r['distance_in_m'] !== null ? (float)$r['distance_in_m'] : null,
        'distance_out_m'     => $r['distance_out_m'] !== null ? (float)$r['distance_out_m'] : null,
        'checklist_progress' => $r['checklist_progress'] !== null ? (int)$r['checklist_progress'] : null,
        'checklist_total'    => (int)$r['checklist_total'],
        'checklist_pending'  => (int)$r['checklist_pending'],
        // Helpers on a crew do not move the job's stage — the lead does.
        'allowed_next'       => $isLead ? tech_allowed_next($r['stage']) : [],
        'report_code'        => $r['report_code'],
        // Installation: which stage is booked, and whether it can be worked on today.
        'plan'               => $r['job_type'] === 'INSTALLATION' ? install_plan_summary_for_job((int)$r['id']) : null,
        'is_lead'            => $isLead,
        // Everyone on the installation crew (lead first), so each knows who they work with.
        'crew'               => ($r['project_id'] && $r['job_type'] === 'INSTALLATION' && crew_available())
                                ? array_map(fn($m) => ['name' => $m['name'], 'code' => $m['code'], 'phone' => $m['phone'], 'is_lead' => $m['is_lead']], crew_list((int)$r['project_id']))
                                : [],
    ];
}

// Service-request jobs carry a checklist (phase 21): its state for the
// "Open Checklist" button. They are completed by Management approving the
// checklist, so "Complete Job" is not offered on them.
if (srcl_ready() && $assignments) {
    $ids = implode(',', array_map(fn($a) => (int)$a['id'], $assignments)); // integers
    $srRows = $pdo->query(
        "SELECT sr.job_id, sr.request_code, sr.request_type, c.status AS cl_status,
                (SELECT ROUND(100 * SUM(i.status <> 'PENDING') / COUNT(*)) FROM sr_checklist_items i WHERE i.checklist_id = c.id) AS cl_progress
         FROM service_requests sr LEFT JOIN sr_checklists c ON c.job_id = sr.job_id
         WHERE sr.job_id IN ($ids) ORDER BY sr.id"
    )->fetchAll();
    $byJob = array_column($srRows, null, 'job_id');
    foreach ($assignments as &$as) {
        $r = $byJob[$as['id']] ?? null;
        if (!$r || srcl_template_for($r['request_type']) === null || in_array($as['job_type'], ['MAINTENANCE', 'INSTALLATION'], true)) {
            continue;
        }
        $as['sr_checklist'] = ['request_code' => $r['request_code'], 'request_type' => $r['request_type'],
                               'status' => $r['cl_status'] ?? 'OPEN', 'progress' => (int)($r['cl_progress'] ?? 0)];
        $as['allowed_next'] = array_values(array_diff($as['allowed_next'], ['COMPLETED']));
    }
    unset($as);
}

// Subcontractor (field mode): the company's assignment on each job — scope,
// due date, SunTrack's review note. While SunTrack inspects, no stage moves.
if (field_subcontractor()) {
    $info = field_assignment_info($pdo, array_column($assignments, 'id'));
    foreach ($assignments as &$as) {
        $as['subcontract'] = $info[$as['id']] ?? null;
        if (($as['subcontract']['status'] ?? '') === 'AWAITING_INSPECTION') {
            $as['allowed_next'] = [];
        }
    }
    unset($as);
}

$completedToday = $pdo->prepare(
    "SELECT COUNT(*) FROM jobs WHERE technician_id = :t AND stage = 'COMPLETED' AND DATE(updated_at) = CURDATE()"
);
$completedToday->execute([':t' => $techId]);

$completedTotal = $pdo->prepare("SELECT COUNT(*) FROM jobs WHERE technician_id = :t AND stage = 'COMPLETED'");
$completedTotal->execute([':t' => $techId]);

$pendingReports = $pdo->prepare(
    "SELECT COUNT(*) FROM jobs j
     WHERE j.technician_id = :t AND j.stage = 'COMPLETED'
       AND NOT EXISTS (SELECT 1 FROM work_reports wr WHERE wr.job_id = j.id)"
);
$pendingReports->execute([':t' => $techId]);

// Completed jobs still awaiting (or already carrying) a work report — the
// dashboard's "Recently Completed" strip.
$recent = $pdo->prepare(
    "SELECT j.id, j.job_code, j.job_type, j.updated_at, j.progress,
            cu.full_name AS client_name, c.client_code,
            wr.id AS existing_report_id, wr.report_code
     FROM jobs j
     JOIN clients c ON c.id = j.client_id
     JOIN users cu  ON cu.id = c.user_id
     LEFT JOIN work_reports wr ON wr.job_id = j.id
     WHERE j.technician_id = :t AND j.stage = 'COMPLETED'
     ORDER BY j.updated_at DESC LIMIT 8"
);
$recent->execute([':t' => $techId]);
$recentRows = $recent->fetchAll();

// Which of those the client has already signed off. Separate, guarded query:
// an install that has not imported phase 7 keeps a working screen.
$signed = [];
if ($recentRows) {
    try {
        $ids = implode(',', array_map(fn($r) => (int)$r['id'], $recentRows)); // integers from the DB
        $signed = array_flip(array_map('intval', $pdo->query("SELECT job_id FROM job_confirmations WHERE job_id IN ($ids)")->fetchAll(PDO::FETCH_COLUMN)));
    } catch (PDOException $e) {
        $signed = [];
    }
}
foreach ($recentRows as &$rr) {
    $rr['confirmed'] = isset($signed[(int)$rr['id']]);
}
unset($rr);

json_success([
    'technician_id'    => (int)$techId,
    'availability'     => tech_availability((int)$techId),
    'assignments'      => $assignments,
    'open_count'       => count($assignments),
    'completed_today'  => (int)$completedToday->fetchColumn(),
    'completed_total'  => (int)$completedTotal->fetchColumn(),
    'pending_reports'  => (int)$pendingReports->fetchColumn(),
    'recent_completed' => $recentRows,
    'server_time'      => date('Y-m-d H:i:s'),
]);
