<?php
/**
 * GET  /api/technician/availability.php → current status + history context
 * POST /api/technician/availability.php → change own status
 *
 * A technician can only ever read or write their own row in
 * technician_availability — the technician_id is taken from the session, never
 * from the request body.
 */
require_once __DIR__ . '/../../middleware/technician.php';

$techId = (int)current_profile_id();
if (!$techId) {
    json_error('Technician profile not found.', 404);
}

$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $activeJobs = tech_active_field_jobs($techId);
    $openCount = $pdo->prepare(
        "SELECT COUNT(*) FROM jobs WHERE technician_id = :t AND stage NOT IN ('COMPLETED','CANCELLED')"
    );
    $openCount->execute([':t' => $techId]);

    $updatedStmt = $pdo->prepare('SELECT updated_at FROM technician_availability WHERE technician_id = :t');
    $updatedStmt->execute([':t' => $techId]);

    json_success([
        'status'       => tech_availability($techId),
        'options'      => tech_availability_values(),
        'updated_at'   => $updatedStmt->fetchColumn() ?: null,
        'active_jobs'  => $activeJobs,
        'open_jobs'    => (int)$openCount->fetchColumn(),
    ]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['status']);

$status = strtoupper(trim((string)$input['status']));
if (!in_array($status, tech_availability_values(), true)) {
    json_error('Invalid availability value.', 422);
}

$current = tech_availability($techId);
if ($current === $status) {
    json_success(['status' => $status], 'Availability is already ' . tech_stage_label($status) . '.');
}

// Conflict check — you cannot go off duty while a job is open in the field.
if (in_array($status, ['OFF_DUTY', 'ON_LEAVE'], true)) {
    $active = tech_active_field_jobs($techId);
    if ($active) {
        $codes = implode(', ', array_column($active, 'job_code'));
        json_error(
            'You still have active field work (' . $codes . '). Complete or pause those jobs before going ' .
            strtolower(str_replace('_', ' ', $status)) . '.',
            422,
            ['active_jobs' => $active]
        );
    }
}

tech_set_availability($techId, $status);
audit_log('UPDATE_AVAILABILITY:' . $current . '->' . $status, 'technician_availability', (string)$techId);

json_success(['status' => $status, 'previous' => $current], 'Availability set to ' . tech_stage_label($status) . '.');
