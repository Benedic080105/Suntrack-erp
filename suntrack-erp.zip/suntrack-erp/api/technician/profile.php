<?php
/**
 * GET  /api/technician/profile.php → own profile (never a password hash)
 * POST /api/technician/profile.php → update own safe fields only
 *
 * Writable: users.full_name, users.phone, users.email.
 * Never writable here: role_id, status, technicians.id, technician_code,
 * specialization, geofence_enabled, or anyone else's record. The target user
 * id comes from the session, so there is no id to tamper with.
 */
require_once __DIR__ . '/../../middleware/technician.php';

$techId = (int)current_profile_id();
$userId = (int)current_user_id();
if (!$techId || !$userId) {
    json_error('Technician profile not found.', 404);
}

$pdo = db();

function tech_profile_payload(PDO $pdo, int $techId, int $userId): array
{
    $stmt = $pdo->prepare(
        'SELECT u.full_name, u.email, u.phone, u.status, u.last_login, u.created_at,
                t.technician_code, t.specialization, t.geofence_enabled
         FROM technicians t JOIN users u ON u.id = t.user_id
         WHERE t.id = :t AND u.id = :u'
    );
    $stmt->execute([':t' => $techId, ':u' => $userId]);
    $row = $stmt->fetch();
    if (!$row) {
        json_error('Technician profile not found.', 404);
    }
    return [
        // Editable
        'full_name'        => $row['full_name'],
        'email'            => $row['email'],
        'phone'            => $row['phone'],
        // Read-only — shown so the technician knows their own identifiers,
        // but rejected if sent back in a POST.
        'technician_code'  => $row['technician_code'],
        'specialization'   => $row['specialization'],
        'geofence_enabled' => (int)$row['geofence_enabled'] === 1,
        'account_status'   => $row['status'],
        'last_login'       => $row['last_login'],
        'member_since'     => $row['created_at'],
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    json_success(tech_profile_payload($pdo, $techId, $userId));
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);

$fullName = trim((string)($input['full_name'] ?? ''));
$phone    = trim((string)($input['phone'] ?? ''));
$email    = trim((string)($input['email'] ?? ''));

if ($fullName === '' || str_len($fullName) < 3) {
    json_error('Please enter your full name (at least 3 characters).', 422);
}
if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_error('Please enter a valid email address.', 422);
}
if ($phone !== '' && !preg_match('/^[0-9+()\-\s]{7,20}$/', $phone)) {
    json_error('Please enter a valid phone number.', 422);
}

// Email must stay unique across all accounts.
$dupe = $pdo->prepare('SELECT id FROM users WHERE email = :e AND id <> :u LIMIT 1');
$dupe->execute([':e' => $email, ':u' => $userId]);
if ($dupe->fetch()) {
    json_error('That email address is already in use by another account.', 409);
}

$pdo->prepare('UPDATE users SET full_name = :n, phone = :p, email = :e WHERE id = :u')
    ->execute([':n' => $fullName, ':p' => $phone !== '' ? $phone : null, ':e' => $email, ':u' => $userId]);

$_SESSION['full_name'] = $fullName;

audit_log('UPDATE_PROFILE', 'technicians', (string)$techId);

json_success(tech_profile_payload($pdo, $techId, $userId), 'Profile updated.');
