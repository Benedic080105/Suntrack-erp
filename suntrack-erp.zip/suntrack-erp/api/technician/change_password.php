<?php
/**
 * POST /api/technician/change_password.php
 *
 * Uses the same password_hash()/password_verify() scheme as attempt_login(),
 * so it sits on top of the existing auth architecture rather than beside it.
 * The current password is always required, and only the session's own account
 * can ever be changed.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['current_password', 'new_password', 'confirm_password']);

$userId  = (int)current_user_id();
$current = (string)$input['current_password'];
$new     = (string)$input['new_password'];
$confirm = (string)$input['confirm_password'];

if ($new !== $confirm) {
    json_error('The new password and its confirmation do not match.', 422);
}
if (str_len($new) < PASSWORD_MIN_LENGTH) {
    json_error('New password must be at least ' . PASSWORD_MIN_LENGTH . ' characters.', 422);
}
if ($new === $current) {
    json_error('Please choose a password different from your current one.', 422);
}

$pdo = db();
$stmt = $pdo->prepare('SELECT password_hash FROM users WHERE id = :u');
$stmt->execute([':u' => $userId]);
$hash = $stmt->fetchColumn();

if (!$hash || !password_verify($current, $hash)) {
    // Deliberately vague and slow-ish: do not confirm which half was wrong.
    json_error('Your current password is incorrect.', 403);
}

$pdo->prepare('UPDATE users SET password_hash = :h WHERE id = :u')
    ->execute([':h' => password_hash($new, PASSWORD_DEFAULT), ':u' => $userId]);

audit_log('CHANGE_PASSWORD', 'users', (string)$userId);

json_success([], 'Password changed. Use your new password the next time you sign in.');
