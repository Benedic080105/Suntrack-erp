<?php
/**
 * GET /api/technician/history.php            → closed jobs for this technician
 * GET /api/technician/history.php?job_id=N   → that job's real status timeline
 *
 * Built from jobs + job_status_history + attendance + work_reports. Nothing is
 * hardcoded, and the scope is always the session's own technician id.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed.', 405);
}

$techId = (int)current_profile_id();
$pdo    = db();
[$pageLimit, $pageOffset] = list_page(200);

// ---- Single job timeline --------------------------------------------------
if (!empty($_GET['job_id'])) {
    $job = tech_job_or_fail((int)$_GET['job_id']);

    $hStmt = $pdo->prepare(
        'SELECT h.from_stage, h.to_stage, h.note, h.created_at, u.full_name AS changed_by_name
         FROM job_status_history h
         LEFT JOIN users u ON u.id = h.changed_by
         WHERE h.job_id = :j ORDER BY h.id ASC'
    );
    $hStmt->execute([':j' => $job['id']]);

    $aStmt = $pdo->prepare(
        'SELECT time_in, time_out, distance_in_m, distance_out_m, geofence_status
         FROM attendance WHERE job_id = :j AND technician_id = :t ORDER BY id ASC'
    );
    $aStmt->execute([':j' => $job['id'], ':t' => $techId]);

    $rStmt = $pdo->prepare(
        'SELECT report_code, work_type, remarks, materials_used, issues_found, duration_text, duration_minutes, status, submitted_date
         FROM work_reports WHERE job_id = :j AND technician_id = :t LIMIT 1'
    );
    $rStmt->execute([':j' => $job['id'], ':t' => $techId]);

    json_success([
        'job' => [
            'id'             => (int)$job['id'],
            'job_code'       => $job['job_code'],
            'job_type'       => $job['job_type'],
            'stage'          => $job['stage'],
            'progress'       => (int)$job['progress'],
            'priority'       => $job['priority'],
            'client_name'    => $job['client_name'],
            'client_code'    => $job['client_code'],
            'site_address'   => $job['site_address'],
            'scheduled_date' => $job['scheduled_date'],
            'updated_at'     => $job['updated_at'],
        ],
        'timeline'    => $hStmt->fetchAll(),
        'attendance'  => $aStmt->fetchAll(),
        'work_report' => $rStmt->fetch() ?: null,
    ]);
}

// ---- Closed-job list ------------------------------------------------------
$where  = ["j.technician_id = :t", "j.stage IN ('COMPLETED','CANCELLED')"];
$params = [':t' => $techId];

if ($clause = search_clause($_GET['search'] ?? '', search_columns('tech_history'), $params)) {
    $where[] = $clause;
}
if (!empty($_GET['stage']) && in_array($_GET['stage'], ['COMPLETED', 'CANCELLED'], true)) {
    $where[] = 'j.stage = :stage';
    $params[':stage'] = $_GET['stage'];
}

$sql = "SELECT j.id, j.job_code, j.job_type, j.stage, j.progress, j.priority,
               j.scheduled_date, j.site_address, j.updated_at,
               c.client_code, cu.full_name AS client_name,
               a.time_in, a.time_out,
               TIMESTAMPDIFF(MINUTE, a.time_in, a.time_out) AS duration_minutes,
               wr.report_code, wr.status AS report_status
        FROM jobs j
        JOIN clients c ON c.id = j.client_id
        JOIN users cu  ON cu.id = c.user_id
        LEFT JOIN attendance a ON a.id = (
            SELECT a2.id FROM attendance a2
            WHERE a2.job_id = j.id AND a2.technician_id = :t2 ORDER BY a2.id DESC LIMIT 1
        )
        LEFT JOIN work_reports wr ON wr.job_id = j.id AND wr.technician_id = :t3
        WHERE " . implode(' AND ', $where) . "
        ORDER BY j.updated_at DESC, j.id DESC
        " . list_page_sql($pageLimit, $pageOffset);

$params[':t2'] = $techId;
$params[':t3'] = $techId;

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = list_page_finish($stmt->fetchAll(), $pageLimit, $pageOffset);

$countStmt = $pdo->prepare(
    "SELECT
        SUM(stage = 'COMPLETED') AS completed,
        SUM(stage = 'CANCELLED') AS cancelled
     FROM jobs WHERE technician_id = :t"
);
$countStmt->execute([':t' => $techId]);
$counts = $countStmt->fetch() ?: [];

json_success([
    'rows'  => $rows,
    'stats' => [
        'completed' => (int)($counts['completed'] ?? 0),
        'cancelled' => (int)($counts['cancelled'] ?? 0),
    ],
]);
