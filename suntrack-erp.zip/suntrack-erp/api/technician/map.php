<?php
/**
 * GET /api/technician/map.php
 *
 * Map payload for the technician's Site Map tab: their own open jobs that have
 * coordinates, plus the most recent recorded position for the active job.
 *
 * Only the signed-in technician's own jobs and own location trail are ever
 * returned — a technician's live position is never exposed to anyone else
 * through this endpoint.
 */
require_once __DIR__ . '/../../middleware/technician.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed.', 405);
}

$techId = (int)current_profile_id();
if (!$techId) {
    json_error('Technician profile not found.', 404);
}

$pdo = db();

$stmt = $pdo->prepare(
    "SELECT j.id, j.job_code, j.job_type, j.stage, j.priority, j.progress,
            j.site_address, j.site_lat, j.site_lng, j.geofence_radius_m, j.scheduled_date,
            c.client_code, cu.full_name AS client_name
     FROM jobs j
     JOIN clients c ON c.id = j.client_id
     JOIN users cu  ON cu.id = c.user_id
     WHERE " . crew_job_condition('j', ':t') . " AND j.stage NOT IN ('COMPLETED','CANCELLED')
     ORDER BY FIELD(j.stage,'IN_PROGRESS','ARRIVED','EN_ROUTE','PAUSED','ASSIGNED','SUBMITTED'),
              FIELD(j.priority,'URGENT','HIGH','NORMAL','LOW'), j.scheduled_date ASC"
);
$stmt->execute([':t' => $techId] + (crew_available() ? [':tc' => $techId] : []));
$rows = $stmt->fetchAll();

$jobs = [];
$activeJobId = null;
foreach ($rows as $r) {
    if ($activeJobId === null && in_array($r['stage'], tech_field_stages(), true)) {
        $activeJobId = (int)$r['id'];
    }
    $jobs[] = [
        'id'                => (int)$r['id'],
        'job_code'          => $r['job_code'],
        'job_type'          => $r['job_type'],
        'stage'             => $r['stage'],
        'priority'          => $r['priority'],
        'progress'          => (int)$r['progress'],
        'client_name'       => $r['client_name'],
        'client_code'       => $r['client_code'],
        'site_address'      => $r['site_address'],
        'scheduled_date'    => $r['scheduled_date'],
        'site_lat'          => $r['site_lat'] !== null ? (float)$r['site_lat'] : null,
        'site_lng'          => $r['site_lng'] !== null ? (float)$r['site_lng'] : null,
        'geofence_radius_m' => tech_geofence_radius($r),
        'has_coordinates'   => $r['site_lat'] !== null && $r['site_lng'] !== null,
    ];
}

// Last recorded position for this technician (their own trail only).
$lastStmt = $pdo->prepare(
    'SELECT job_id, lat, lng, distance_m, status, recorded_at
     FROM geofence_records WHERE technician_id = :t ORDER BY id DESC LIMIT 1'
);
$lastStmt->execute([':t' => $techId]);
$last = $lastStmt->fetch() ?: null;

json_success([
    'jobs'          => $jobs,
    'active_job_id' => $activeJobId,
    'last_position' => $last ? [
        'job_id'      => (int)$last['job_id'],
        'lat'         => (float)$last['lat'],
        'lng'         => (float)$last['lng'],
        'distance_m'  => (float)$last['distance_m'],
        'status'      => $last['status'],
        'recorded_at' => $last['recorded_at'],
    ] : null,
    'default_radius_m' => DEFAULT_GEOFENCE_RADIUS_M,
]);
