<?php
/**
 * Maintenance — client-scoped monitoring endpoint.
 * Read-only: lets a client see the maintenance schedule for their own
 * project(s) — last visit, next due date, and status.
 */
require_once __DIR__ . '/../../middleware/client.php';

$clientId = current_profile_id();
if (!$clientId) {
    json_error('Client profile not found.', 404);
}

maintenance_refresh_statuses(); // keep DUE/OVERDUE current as days pass
$pdo = db();
$stmt = $pdo->prepare(
    "SELECT ms.id, p.project_code, p.site_name, ms.last_maintenance, ms.next_maintenance,
            ms.status, ms.client_notified, ms.notified_at
     FROM maintenance_schedules ms
     JOIN projects p ON p.id = ms.project_id
     WHERE p.client_id = :c
     ORDER BY ms.next_maintenance ASC"
);
$stmt->execute([':c' => $clientId]);

json_success(['rows' => $stmt->fetchAll()]);
