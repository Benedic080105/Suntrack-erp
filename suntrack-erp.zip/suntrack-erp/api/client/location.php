<?php
/**
 * /api/client/location.php — the signed-in client's own site location.
 *
 *   GET   their saved pin (lat, lng) and address
 *   POST  { lat, lng, accuracy?, csrf_token } — save the pin from their phone's
 *         GPS while standing at the site
 *
 * The pin is the geofence centre for the client's jobs. Saving it also moves
 * the geofence of jobs the technician has not set off for yet (SUBMITTED /
 * ASSIGNED); work already under way keeps the location it is being judged
 * against. Management is notified so a wrong pin can be caught.
 */
require_once __DIR__ . '/../../middleware/client.php';

$clientId = (int)current_profile_id();
if (!$clientId) {
    json_error('Client profile not found.', 404);
}
$pdo = db();

$read = function () use ($pdo, $clientId) {
    $s = $pdo->prepare('SELECT client_code, lat, lng, address, city, province FROM clients WHERE id = :id');
    $s->execute([':id' => $clientId]);
    $c = $s->fetch();
    return [
        'lat'     => $c['lat'] !== null ? (float)$c['lat'] : null,
        'lng'     => $c['lng'] !== null ? (float)$c['lng'] : null,
        'address' => implode(', ', array_filter([$c['address'], $c['city'], $c['province']])),
        'client_code' => $c['client_code'],
    ];
};

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    json_success($read());
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['lat', 'lng']);
[$lat, $lng] = parse_coordinates($input['lat'], $input['lng']);
if ($lat === null || $lng === null) {
    json_error('No location was received. Please try again.', 422);
}
$accuracy = isset($input['accuracy']) && is_numeric($input['accuracy']) ? (int)round((float)$input['accuracy']) : null;
if ($accuracy !== null && $accuracy > 500) {
    json_error("Your phone's location is only accurate to about {$accuracy} m right now. Step outside or turn on GPS / high-accuracy mode, then try again.", 422);
}

$pdo->beginTransaction();
$pdo->prepare('UPDATE clients SET lat = :lat, lng = :lng WHERE id = :id')->execute([':lat' => $lat, ':lng' => $lng, ':id' => $clientId]);
$jobs = $pdo->prepare(
    "UPDATE jobs SET site_lat = :lat, site_lng = :lng
     WHERE client_id = :cid AND stage IN ('SUBMITTED','ASSIGNED')"
);
$jobs->execute([':lat' => $lat, ':lng' => $lng, ':cid' => $clientId]);
$moved = $jobs->rowCount();
$pdo->commit();

$me = $read();
audit_log('UPDATE_LOCATION', 'clients', $me['client_code']);
$name = (string)($_SESSION['full_name'] ?? $me['client_code']);
foreach (install_plan_manager_ids() as $uid) {
    notify($uid, 'CLIENT_LOCATION', "{$name} ({$me['client_code']}) set their site location from their phone"
        . ($accuracy !== null ? " (accurate to about {$accuracy} m)" : '') . '.', 'clients', $clientId);
}

json_success($me + ['jobs_updated' => $moved],
    'Your site location is saved.' . ($moved ? " Your upcoming visit" . ($moved === 1 ? '' : 's') . ' will use it.' : ''));
