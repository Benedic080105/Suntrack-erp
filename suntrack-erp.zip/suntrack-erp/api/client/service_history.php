<?php
/**
 * Service History — client-scoped monitoring endpoint.
 * Read-only: a timeline of the client's jobs plus the technician work
 * reports filed against them, so the client can see what was done, when,
 * and by whom.
 */
require_once __DIR__ . '/../../middleware/client.php';

$clientId = current_profile_id();
if (!$clientId) {
    json_error('Client profile not found.', 404);
}

$pdo = db();

$jobsStmt = $pdo->prepare(
    "SELECT j.id, j.job_code, j.job_type, j.stage, j.scheduled_date, j.updated_at,
            tu.full_name AS technician_name
     FROM jobs j
     LEFT JOIN technicians t ON t.id = j.technician_id
     LEFT JOIN users tu ON tu.id = t.user_id
     WHERE j.client_id = :c
     ORDER BY j.updated_at DESC
     LIMIT 100"
);
$jobsStmt->execute([':c' => $clientId]);
$jobs = $jobsStmt->fetchAll();

// Sign-off and photo count per job (guarded: works before phase 7 is imported).
foreach ($jobs as &$j) {
    $conf = job_confirmation((int)$j['id']);
    $counts = job_photo_counts((int)$j['id']);
    $j['confirmed'] = $conf !== null;
    $j['rating'] = $conf['rating'] ?? null;
    $j['photo_count'] = $counts['BEFORE'] + $counts['AFTER'];
    $j['can_confirm'] = $j['stage'] === 'COMPLETED' && $conf === null;
}
unset($j);

$reportsStmt = $pdo->prepare(
    "SELECT wr.report_code, wr.job_id, wr.work_type, wr.submitted_date, wr.duration_text, wr.duration_minutes, wr.remarks,
            tu.full_name AS technician_name
     FROM work_reports wr
     JOIN technicians t ON t.id = wr.technician_id
     JOIN users tu ON tu.id = t.user_id
     WHERE wr.client_id = :c
     ORDER BY wr.submitted_date DESC
     LIMIT 100"
);
$reportsStmt->execute([':c' => $clientId]);
$reports = $reportsStmt->fetchAll();

json_success(['jobs' => $jobs, 'reports' => $reports]);
