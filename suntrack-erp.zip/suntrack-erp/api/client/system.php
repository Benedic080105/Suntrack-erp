<?php
/**
 * My Solar System — client-scoped endpoint.
 * Returns the client's system + project details, plus any recorded GPS
 * coordinates for their site(s) (sourced from geofenced job visits) so the
 * "My Solar System" tab can render a small map — the panel's requested
 * client-side geomapping module.
 */
require_once __DIR__ . '/../../middleware/client.php';

$clientId = current_profile_id();
if (!$clientId) {
    json_error('Client profile not found.', 404);
}

$pdo = db();

$systems = $pdo->prepare("SELECT * FROM solar_systems WHERE client_id = :c ORDER BY id DESC");
$systems->execute([':c' => $clientId]);
$systems = $systems->fetchAll();
foreach ($systems as &$s) {
    $s['summary'] = system_client_summary($s);
}
unset($s);

$projects = $pdo->prepare("SELECT * FROM projects WHERE client_id = :c ORDER BY id DESC");
$projects->execute([':c' => $clientId]);
$projects = $projects->fetchAll();

// Any job tied to this client that has a recorded GPS pin — this is how a
// site's location becomes known (populated by a technician's geofenced
// time-in/out, not by hand), so client-side geomapping stays consistent
// with the rest of the system.
$sitesStmt = $pdo->prepare(
    "SELECT j.job_code, j.site_address, j.site_lat, j.site_lng, j.stage, j.job_type, p.project_code, p.site_name
     FROM jobs j LEFT JOIN projects p ON p.id = j.project_id
     WHERE j.client_id = :c AND j.site_lat IS NOT NULL AND j.site_lng IS NOT NULL
     ORDER BY j.updated_at DESC LIMIT 20"
);
$sitesStmt->execute([':c' => $clientId]);
$sites = $sitesStmt->fetchAll();

json_success([
    'systems' => $systems,
    'projects' => $projects,
    'sites' => $sites, // GPS-plottable locations, most recent first
]);
