<?php
/**
 * GET /api/client/invoices.php — the signed-in client's own invoices, with
 * what has been paid and what is left. Read-only.
 *
 *   invoices    each invoice; one for a project also carries `materials`:
 *               every item installed for it, its unit price and line total
 *   uninvoiced  installations with materials on record but no invoice yet,
 *               so the client can see the cost of what was installed
 */
require_once __DIR__ . '/../../middleware/client.php';

$clientId = (int)current_profile_id();
billing_refresh_overdue(); // PENDING past its due date -> OVERDUE
$pdo = db();
$stmt = $pdo->prepare(
    "SELECT i.id, i.invoice_code, i.amount, i.due_date, i.payment_status, i.payment_date, i.created_at,
            i.project_id, p.project_code, p.site_name,
            COALESCE((SELECT SUM(py.amount) FROM payments py WHERE py.invoice_id = i.id AND " . billing_valid_payment('py') . "), 0) AS amount_paid
     FROM invoices i
     LEFT JOIN projects p ON p.id = i.project_id
     WHERE i.client_id = :c AND i.payment_status <> 'CANCELLED'
     ORDER BY i.id DESC
     LIMIT 200"
);
$stmt->execute([':c' => $clientId]);
$rows = $stmt->fetchAll();

$costs = [];
$costFor = function (int $projectId) use (&$costs): array {
    return $costs[$projectId] ??= project_material_costs($projectId);
};
foreach ($rows as &$r) {
    $r['balance'] = max(0, (float)$r['amount'] - (float)$r['amount_paid']);
    $r['url'] = APP_BASE_URL . '/invoice.php?id=' . (int)$r['id'];
    // Its own frozen lines (an invoice for released materials), else the project's materials.
    $lines = invoice_lines((int)$r['id']);
    $r['materials'] = $lines
        ? ['items' => $lines, 'total' => round(array_sum(array_column($lines, 'line_total')), 2), 'count' => array_sum(array_column($lines, 'quantity'))]
        : ($r['project_id'] ? $costFor((int)$r['project_id']) : null);
    $r['from_materials'] = (bool)$lines;
}
unset($r);

// Installations that are under way or done but not billed yet.
$invoiced = array_filter(array_map(fn($r) => (int)$r['project_id'], $rows));
$proj = $pdo->prepare(
    "SELECT id, project_code, site_name, status FROM projects
     WHERE client_id = :c AND status IN ('IN_PROGRESS','COMPLETED','MAINTENANCE') ORDER BY id DESC"
);
$proj->execute([':c' => $clientId]);
$uninvoiced = [];
foreach ($proj->fetchAll() as $p) {
    if (in_array((int)$p['id'], $invoiced, true)) {
        continue;
    }
    $m = $costFor((int)$p['id']);
    if ($m['items']) {
        $uninvoiced[] = $p + ['materials' => $m];
    }
}

json_success(['invoices' => $rows, 'uninvoiced' => $uninvoiced]);
