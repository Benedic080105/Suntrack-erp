<?php
/**
 * GET /api/warehouse/reports.php
 *
 * Warehouse reporting: stock movements and inventory state, filtered.
 *
 * Read-only by design. Warehouse staff, Management and Admin may all read
 * this (Admin is a monitoring role, and reporting is exactly what monitoring
 * means); nobody can mutate anything through it.
 *
 * Parameters — every one optional, so an unfiltered call returns recent
 * activity rather than an error:
 *   report         movements | inventory | low_stock | out_of_stock
 *                  | issued | received | returned | orders  (default: movements)
 *   date_from      YYYY-MM-DD
 *   date_to        YYYY-MM-DD   (inclusive — see the interval note below)
 *   category       inventory_categories.id
 *   movement_type  RECEIVE | ISSUE | RETURN | ADJUST | TRANSFER
 *   inventory_id   inventory.id
 *   job_id         jobs.id
 *   limit          1..1000 (default 300)
 *
 * Returns { summary, rows, report, filters_applied }.
 */
require_once __DIR__ . '/../../middleware/warehouse.php';

$pdo = db();

// ---------------------------------------------------------------------------
// Input. Everything is whitelisted or bound — no user string ever reaches SQL.
// ---------------------------------------------------------------------------
$validReports = ['movements', 'inventory', 'low_stock', 'out_of_stock', 'issued', 'received', 'returned', 'orders'];
$report = $_GET['report'] ?? 'movements';
if (!in_array($report, $validReports, true)) {
    json_error('Unknown report type.', 422);
}

/** Accept a date only in YYYY-MM-DD form, and only if it is a real date. */
function report_date(?string $value): ?string
{
    if ($value === null || trim($value) === '') {
        return null;
    }
    $value = trim($value);
    $d = DateTime::createFromFormat('Y-m-d', $value);
    if (!$d || $d->format('Y-m-d') !== $value) {
        json_error('Dates must be in YYYY-MM-DD format.', 422);
    }
    return $value;
}

$dateFrom = report_date($_GET['date_from'] ?? null);
$dateTo   = report_date($_GET['date_to'] ?? null);

if ($dateFrom !== null && $dateTo !== null && $dateFrom > $dateTo) {
    json_error('The "from" date cannot be later than the "to" date.', 422);
}

$categoryId  = isset($_GET['category']) && $_GET['category'] !== ''      ? (int)$_GET['category'] : null;
$inventoryId = isset($_GET['inventory_id']) && $_GET['inventory_id'] !== '' ? (int)$_GET['inventory_id'] : null;
$jobId       = isset($_GET['job_id']) && $_GET['job_id'] !== ''          ? (int)$_GET['job_id'] : null;

$movementType = null;
if (!empty($_GET['movement_type'])) {
    $mt = strtoupper(trim((string)$_GET['movement_type']));
    if (!in_array($mt, ['RECEIVE', 'ISSUE', 'RETURN', 'ADJUST', 'TRANSFER'], true)) {
        json_error('Unknown movement type.', 422);
    }
    $movementType = $mt;
}

// The report choice can itself imply a movement type.
$impliedType = ['issued' => 'ISSUE', 'received' => 'RECEIVE', 'returned' => 'RETURN'][$report] ?? null;
if ($impliedType !== null) {
    $movementType = $impliedType;
}

$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 300;
$limit = max(1, min(1000, $limit)); // hard ceiling: a report must never be able to pull the whole table

// ---------------------------------------------------------------------------
// Shared WHERE builder for movement-based reports.
// ---------------------------------------------------------------------------
$where  = [];
$params = [];

if ($dateFrom !== null) {
    $where[] = 'sm.created_at >= :date_from';
    $params[':date_from'] = $dateFrom . ' 00:00:00';
}
if ($dateTo !== null) {
    // Half-open interval rather than BETWEEN … 23:59:59, which silently drops
    // anything recorded in the final second of the day.
    $where[] = 'sm.created_at < :date_to';
    $params[':date_to'] = date('Y-m-d', strtotime($dateTo . ' +1 day')) . ' 00:00:00';
}
if ($movementType !== null) {
    $where[] = 'sm.movement_type = :mtype';
    $params[':mtype'] = $movementType;
}
if ($categoryId !== null) {
    $where[] = 'i.category_id = :cat';
    $params[':cat'] = $categoryId;
}
if ($inventoryId !== null) {
    $where[] = 'sm.inventory_id = :inv';
    $params[':inv'] = $inventoryId;
}
if ($jobId !== null) {
    $where[] = 'sm.job_id = :job';
    $params[':job'] = $jobId;
}

$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$rows = [];

if (in_array($report, ['movements', 'issued', 'received', 'returned'], true)) {
    // No password_hash, no email, no user id — a warehouse report names the
    // person who recorded a movement and nothing else about them.
    //
    // Items scanned out for a client order may have no job yet, so the client
    // comes from the job when there is one and from the order otherwise.
    $movementSql = function (bool $withOrders) use ($whereSql, $limit): string {
        return "SELECT sm.created_at, sm.movement_code, sm.movement_type, sm.quantity, sm.reference,
                       i.id AS inventory_id, i.item_name, i.sku,
                       ic.category_name,
                       j.job_code,
                       " . ($withOrders ? 'mr.request_code' : 'NULL') . " AS request_code,
                       cu.full_name AS client_name,
                       u.full_name  AS recorded_by_name
                FROM stock_movements sm
                JOIN inventory i                ON i.id = sm.inventory_id
                LEFT JOIN inventory_categories ic ON ic.id = i.category_id
                LEFT JOIN jobs j                ON j.id = sm.job_id
                " . ($withOrders
                    ? 'LEFT JOIN material_requests mr ON mr.id = sm.material_request_id
                       LEFT JOIN clients c ON c.id = COALESCE(j.client_id, mr.client_id)'
                    : 'LEFT JOIN clients c ON c.id = j.client_id') . "
                LEFT JOIN users cu              ON cu.id = c.user_id
                LEFT JOIN users u               ON u.id = sm.recorded_by
                $whereSql
                ORDER BY sm.created_at DESC, sm.id DESC
                LIMIT $limit";   // $limit is an int clamped above, never a user string
    };

    try {
        $stmt = $pdo->prepare($movementSql(true));
        $stmt->execute($params);
    } catch (PDOException $e) {
        // Phase 5 not migrated: material_request_id does not exist yet.
        $stmt = $pdo->prepare($movementSql(false));
        $stmt->execute($params);
    }
    $rows = $stmt->fetchAll();

} elseif ($report === 'orders') {
    // Client orders: what Management asked for, what the warehouse prepared,
    // and who released it to whom — the paper trail for each client.
    $oWhere  = [];
    $oParams = [];
    if ($dateFrom !== null) {
        $oWhere[] = 'mr.created_at >= :date_from';
        $oParams[':date_from'] = $params[':date_from'];
    }
    if ($dateTo !== null) {
        $oWhere[] = 'mr.created_at < :date_to';
        $oParams[':date_to'] = $params[':date_to'];
    }
    if ($jobId !== null) {
        $oWhere[] = 'mr.job_id = :job';
        $oParams[':job'] = $jobId;
    }
    $oWhereSql = $oWhere ? 'WHERE ' . implode(' AND ', $oWhere) : '';

    $line = fn(string $cat, string $col) =>
        "COALESCE(SUM(CASE WHEN ic.category_name = '$cat' THEN mri.$col END), 0)";

    try {
        $stmt = $pdo->prepare(
            "SELECT mr.created_at, mr.request_code, mr.status, mr.needed_by, mr.ready_at, mr.released_at, mr.released_to,
                    c.client_code, cu.full_name AS client_name, p.project_code, j.job_code,
                    ru.full_name AS requested_by_name, rl.full_name AS released_by_name,
                    {$line('Solar Panel', 'qty_required')} AS panels_required,
                    {$line('Solar Panel', 'qty_prepared')} AS panels_prepared,
                    {$line('Inverter', 'qty_required')}    AS inverters_required,
                    {$line('Inverter', 'qty_prepared')}    AS inverters_prepared,
                    {$line('Battery', 'qty_required')}     AS batteries_required,
                    {$line('Battery', 'qty_prepared')}     AS batteries_prepared
             FROM material_requests mr
             JOIN clients c ON c.id = mr.client_id
             JOIN users cu  ON cu.id = c.user_id
             LEFT JOIN projects p ON p.id = mr.project_id
             LEFT JOIN jobs j     ON j.id = mr.job_id
             LEFT JOIN users ru   ON ru.id = mr.requested_by
             LEFT JOIN users rl   ON rl.id = mr.released_by
             LEFT JOIN material_request_items mri ON mri.request_id = mr.id
             LEFT JOIN inventory_categories ic    ON ic.id = mri.category_id
             $oWhereSql
             GROUP BY mr.id
             ORDER BY mr.id DESC
             LIMIT $limit"
        );
        $stmt->execute($oParams);
        $rows = $stmt->fetchAll();
    } catch (PDOException $e) {
        json_error('Client orders are not set up yet. Run database/phase5_material_requests.sql.', 503);
    }

} else {
    // Inventory-state reports. These describe stock as it stands now, so the
    // movement date filters do not apply to them.
    $invWhere  = [];
    $invParams = [];

    if ($report === 'low_stock') {
        $invWhere[] = "i.status = 'LOW_STOCK'";
    } elseif ($report === 'out_of_stock') {
        $invWhere[] = "i.status = 'OUT_OF_STOCK'";
    } else {
        $invWhere[] = "i.status <> 'DISCONTINUED'";
    }

    if ($categoryId !== null) {
        $invWhere[] = 'i.category_id = :cat';
        $invParams[':cat'] = $categoryId;
    }
    if ($inventoryId !== null) {
        $invWhere[] = 'i.id = :inv';
        $invParams[':inv'] = $inventoryId;
    }

    $sql = "SELECT i.id AS inventory_id, i.item_name, i.sku, i.brand, i.model,
                   i.quantity, i.reorder_level, i.unit_cost, i.warehouse_location, i.status,
                   ic.category_name,
                   (i.quantity * i.unit_cost) AS stock_value
            FROM inventory i
            LEFT JOIN inventory_categories ic ON ic.id = i.category_id
            WHERE " . implode(' AND ', $invWhere) . "
            ORDER BY i.quantity ASC, i.item_name ASC
            LIMIT $limit";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($invParams);
    $rows = $stmt->fetchAll();
}

// ---------------------------------------------------------------------------
// Summary.
//
// Movement totals honour the same filters as the rows, minus the movement-type
// one — otherwise "Total Received" would read zero whenever the user filtered
// to ISSUE, which reads as a bug rather than a filter.
// ---------------------------------------------------------------------------
$sumWhere  = [];
$sumParams = [];
foreach ($where as $clause) {
    if (str_contains($clause, 'sm.movement_type')) {
        continue;
    }
    $sumWhere[] = $clause;
}
foreach ($params as $k => $v) {
    if ($k !== ':mtype') {
        $sumParams[$k] = $v;
    }
}
$sumWhereSql = $sumWhere ? ('WHERE ' . implode(' AND ', $sumWhere)) : '';

$sumStmt = $pdo->prepare(
    "SELECT sm.movement_type, COALESCE(SUM(sm.quantity),0) AS units, COUNT(*) AS moves
     FROM stock_movements sm
     JOIN inventory i ON i.id = sm.inventory_id
     $sumWhereSql
     GROUP BY sm.movement_type"
);
$sumStmt->execute($sumParams);

$summary = [
    'total_received'  => 0,
    'total_issued'    => 0,
    'total_returned'  => 0,
    'total_movements' => 0,
];
foreach ($sumStmt->fetchAll() as $r) {
    $units = (int)$r['units'];
    $summary['total_movements'] += (int)$r['moves'];
    if ($r['movement_type'] === 'RECEIVE')    $summary['total_received'] += $units;
    elseif ($r['movement_type'] === 'ISSUE')  $summary['total_issued']   += $units;
    elseif ($r['movement_type'] === 'RETURN') $summary['total_returned'] += $units;
}

// Current stock position is a snapshot and ignores the date filters.
$stockStmt = $pdo->query(
    "SELECT COALESCE(SUM(quantity),0) AS current_stock,
            SUM(status = 'LOW_STOCK')    AS low_stock_items,
            SUM(status = 'OUT_OF_STOCK') AS out_of_stock_items,
            SUM(status <> 'DISCONTINUED') AS active_skus
     FROM inventory"
);
$stock = $stockStmt->fetch();

$summary['current_stock']       = (int)$stock['current_stock'];
$summary['low_stock_items']     = (int)$stock['low_stock_items'];
$summary['out_of_stock_items']  = (int)$stock['out_of_stock_items'];
$summary['active_skus']         = (int)$stock['active_skus'];
$summary['rows_returned']       = count($rows);
$summary['row_limit']           = $limit;
$summary['truncated']           = count($rows) >= $limit;

json_success([
    'report'  => $report,
    'summary' => $summary,
    'rows'    => $rows,
    'filters_applied' => [
        'date_from'     => $dateFrom,
        'date_to'       => $dateTo,
        'category'      => $categoryId,
        'movement_type' => $movementType,
        'inventory_id'  => $inventoryId,
        'job_id'        => $jobId,
    ],
]);
