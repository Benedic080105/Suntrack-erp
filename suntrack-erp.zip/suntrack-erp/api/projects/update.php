<?php
require_once __DIR__ . '/../../config/config.php';
require_management(); // Admin role is view/export only; only Management (manager/staff) may mutate.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['id']);

$id = (int)$input['id'];
$pdo = db();

$prjStmt = $pdo->prepare('SELECT * FROM projects WHERE id = :id');
$prjStmt->execute([':id' => $id]);
$prj = $prjStmt->fetch();
if (!$prj) {
    json_error('Project not found.', 404);
}

$validStatuses = ['PLANNED', 'SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'MAINTENANCE', 'CANCELLED'];
$fields = [];
$params = [':id' => $id];

if (isset($input['site_name'])) {
    if (trim($input['site_name']) === '') json_error('Site name cannot be blank.', 422);
    $fields[] = 'site_name = :site_name';
    $params[':site_name'] = trim($input['site_name']);
}
if (isset($input['address'])) { $fields[] = 'address = :address'; $params[':address'] = trim($input['address']) ?: null; }
if (isset($input['system_type'])) { $fields[] = 'system_type = :system_type'; $params[':system_type'] = trim($input['system_type']) ?: null; }
if (isset($input['capacity_kw'])) { $fields[] = 'capacity_kw = :capacity'; $params[':capacity'] = $input['capacity_kw'] !== '' ? (float)$input['capacity_kw'] : null; }
if (isset($input['installation_date'])) { $fields[] = 'installation_date = :install_date'; $params[':install_date'] = trim($input['installation_date']) ?: null; }
if (isset($input['notes'])) { $fields[] = 'notes = :notes'; $params[':notes'] = trim($input['notes']) ?: null; }
if (isset($input['progress'])) {
    $progress = (int)$input['progress'];
    if ($progress < 0 || $progress > 100) json_error('Progress must be between 0 and 100.', 422);
    $fields[] = 'progress = :progress';
    $params[':progress'] = $progress;
}
// Size, crew size and crew. When the form sends the crew, the lead comes from it.
$crew = null;
if (crew_available()) {
    $capacity = array_key_exists('capacity_kw', $input) ? ($input['capacity_kw'] !== '' ? (float)$input['capacity_kw'] : null)
              : ($prj['capacity_kw'] !== null ? (float)$prj['capacity_kw'] : null);
    $date = trim((string)($input['installation_date'] ?? $prj['installation_date'] ?? '')) ?: null;
    $crew = crew_read_input($input, $capacity, $date, $id);
    $fields[] = 'site_size = :site_size';
    $params[':site_size'] = $crew['site_size'];
    $fields[] = 'crew_size = :crew_size';
    $params[':crew_size'] = $crew['crew_size'];
    if ($crew['present']) {
        $input['assigned_technician_id'] = $crew['lead'] ?: '';
    }
}
if (array_key_exists('assigned_technician_id', $input)) {
    if (empty($input['assigned_technician_id'])) {
        $fields[] = 'assigned_technician_id = NULL';
    } else {
        $techId = (int)$input['assigned_technician_id'];
        $techCheck = $pdo->prepare('SELECT id FROM ' . tech_staff_table() . ' t WHERE id = :id');
        $techCheck->execute([':id' => $techId]);
        if (!$techCheck->fetch()) json_error('Selected technician was not found.', 422);
        $fields[] = 'assigned_technician_id = :tech_id';
        $params[':tech_id'] = $techId;
    }
}
if (isset($input['client_id'])) {
    $clientId = (int)$input['client_id'];
    $clientCheck = $pdo->prepare('SELECT id FROM clients WHERE id = :id');
    $clientCheck->execute([':id' => $clientId]);
    if (!$clientCheck->fetch()) json_error('Selected client was not found.', 422);
    $fields[] = 'client_id = :client_id';
    $params[':client_id'] = $clientId;
}
if (!empty($input['status'])) {
    if (!in_array($input['status'], $validStatuses, true)) json_error('Invalid status.', 422);
    $fields[] = 'status = :status';
    $params[':status'] = $input['status'];
    if ($input['status'] === 'COMPLETED') {
        $fields[] = 'progress = 100';
    }
}

$jobNotes = [];
if ($fields) {
    $pdo->beginTransaction();
    try {
        $pdo->prepare('UPDATE projects SET ' . implode(', ', $fields) . ' WHERE id = :id')->execute($params);
        // The linked solar system follows the project's status, capacity and address
        // (and is created for older projects that never had one).
        project_sync_solar_system($id);
        // Marking an installation COMPLETED by hand opens its maintenance schedule,
        // the same as a technician completing the installation job.
        if (($input['status'] ?? null) === 'COMPLETED' && $prj['status'] !== 'COMPLETED') {
            project_record_installed_equipment($id);
            project_schedule_next_maintenance($id, null, date('Y-m-d'));
        }
        // The crew's helpers (the lead is assigned_technician_id).
        $newHelpers = ($crew && $crew['present']) ? crew_set_members($id, $crew['lead'], $crew['members']) : [];
        // The installation job follows the project's technician, date, address and status.
        $jobNotes = project_sync_installation_job($id);
        $pdo->commit();
    } catch (DomainException $e) {
        $pdo->rollBack();
        json_error($e->getMessage(), 422);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('SunTrack project update: ' . $e);
        json_error('Failed to update project.', 500);
    }
}

audit_log('UPDATE', 'projects', $prj['project_code']);
project_send_job_notifications($jobNotes);
if (function_exists('sub_auto_sweep')) {
    sub_auto_sweep(db()); // a job left without a technician may go to a subcontractor
}
crew_notify_added($id, $newHelpers ?? []);

$message = 'Project updated.';
if ($crew && $crew['present'] && $crew['lead']) {
    $n = 1 + count($crew['members']);
    $message .= " Crew of {$n}" . ($crew['auto'] ? ' picked automatically' : '') . '.'
        . ($n < $crew['crew_size'] ? " This size needs {$crew['crew_size']} technicians." : '');
}
json_success([], $message);
