<?php
/**
 * Projects — list + stats for the Admin/Management view.
 * Create/update are in create.php and update.php.
 */
require_once __DIR__ . '/../../middleware/admin.php';

$pdo = db();
[$pageLimit, $pageOffset] = list_page(500);
$where = [];
$params = [];

if ($clause = search_clause($_GET['search'] ?? '', search_columns('projects'), $params)) {
    $where[] = $clause;
}
if (!empty($_GET['status'])) {
    $where[] = 'p.status = :status';
    $params[':status'] = $_GET['status'];
}
if (!empty($_GET['technician_id'])) {
    // Lead or helper on the crew.
    $where[] = crew_available()
        ? '(p.assigned_technician_id = :tech_id OR p.id IN (SELECT project_id FROM project_crew WHERE technician_id = :tech_id2))'
        : 'p.assigned_technician_id = :tech_id';
    $params[':tech_id'] = (int)$_GET['technician_id'];
    if (crew_available()) {
        $params[':tech_id2'] = (int)$_GET['technician_id'];
    }
}
if (!empty($_GET['site_size']) && in_array($_GET['site_size'], CREW_SIZES, true) && crew_available()) {
    $where[] = 'p.site_size = :site_size';
    $params[':site_size'] = $_GET['site_size'];
}
apply_date_range('p.installation_date', $where, $params);
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$sql = "SELECT p.id, p.project_code, p.site_name, p.address, p.capacity_kw, p.status, p.progress,
               p.installation_date, p.last_maintenance, p.system_type, p.notes,
               p.client_id, p.assigned_technician_id,
               cu.full_name AS client_name, tu.full_name AS technician_name,
               (SELECT j.id FROM jobs j WHERE j.project_id = p.id AND j.job_type = 'INSTALLATION'
                ORDER BY j.id DESC LIMIT 1) AS installation_job_id
        FROM projects p
        JOIN clients c ON c.id = p.client_id
        JOIN users cu ON cu.id = c.user_id
        LEFT JOIN technicians t ON t.id = p.assigned_technician_id
        LEFT JOIN users tu ON tu.id = t.user_id
        $whereSql
        ORDER BY p.id DESC
        " . list_page_sql($pageLimit, $pageOffset);
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = list_page_finish($stmt->fetchAll(), $pageLimit, $pageOffset);

// Site size, the crew it needs, and who is on it (lead + helpers).
foreach ($rows as &$r) {
    if (crew_available()) {
        $sz = $pdo->prepare('SELECT site_size, crew_size FROM projects WHERE id = :id');
        $sz->execute([':id' => $r['id']]);
        $s = $sz->fetch() ?: [];
        $r['site_size'] = $s['site_size'] ?? crew_site_size($r['capacity_kw'] !== null ? (float)$r['capacity_kw'] : null);
        $r['crew_size'] = $s['crew_size'] !== null ? (int)$s['crew_size'] : crew_recommended($r['site_size']);
        $r['crew'] = array_map(fn($m) => ['id' => $m['id'], 'name' => $m['name'], 'is_lead' => $m['is_lead']], crew_list((int)$r['id']));
    } else {
        $r['site_size'] = null; $r['crew_size'] = null; $r['crew'] = [];
    }
}
unset($r);

$total       = (int)$pdo->query("SELECT COUNT(*) FROM projects")->fetchColumn();
$inProgress  = (int)$pdo->query("SELECT COUNT(*) FROM projects WHERE status='IN_PROGRESS'")->fetchColumn();
$completed   = (int)$pdo->query("SELECT COUNT(*) FROM projects WHERE status='COMPLETED'")->fetchColumn();
$planned     = (int)$pdo->query("SELECT COUNT(*) FROM projects WHERE status IN ('PLANNED','SCHEDULED')")->fetchColumn();

$byStatus = $pdo->query(
    "SELECT status AS label, COUNT(*) AS total FROM projects GROUP BY status ORDER BY total DESC"
)->fetchAll();

json_success([
    'rows' => $rows,
    'stats' => [
        'total' => $total,
        'in_progress' => $inProgress,
        'completed' => $completed,
        'planned' => $planned,
    ],
    'chart' => [
        'labels' => array_map(fn($r) => $r['label'], $byStatus),
        'values' => array_map(fn($r) => (int)$r['total'], $byStatus),
    ],
]);
