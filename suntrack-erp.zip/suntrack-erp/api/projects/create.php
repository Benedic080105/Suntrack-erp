<?php
require_once __DIR__ . '/../../config/config.php';
require_management(); // Admin role is view/export only; only Management (manager/staff) may mutate.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['client_id', 'site_name']);

$clientId = (int)$input['client_id'];
$siteName = trim($input['site_name']);
if ($siteName === '') {
    json_error('Site name is required.', 422);
}

$validStatuses = ['PLANNED', 'SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'MAINTENANCE', 'CANCELLED'];
$status = $input['status'] ?? 'PLANNED';
if (!in_array($status, $validStatuses, true)) {
    json_error('Invalid status.', 422);
}

$pdo = db();

$clientCheck = $pdo->prepare('SELECT id FROM clients WHERE id = :id');
$clientCheck->execute([':id' => $clientId]);
if (!$clientCheck->fetch()) {
    json_error('Selected client was not found.', 422);
}

$capacity = ($input['capacity_kw'] ?? '') !== '' ? (float)$input['capacity_kw'] : null;
$installDate = trim($input['installation_date'] ?? '') ?: null;

// Site size (from kW unless chosen), crew size, and the crew — picked by hand,
// or by the system when "auto_crew" is on (best free technicians that day).
$crew = crew_available() ? crew_read_input($input, $capacity, $installDate) : null;
$techId = $crew ? $crew['lead'] : (!empty($input['assigned_technician_id']) ? (int)$input['assigned_technician_id'] : null);
if ($techId) {
    $techCheck = $pdo->prepare('SELECT id FROM ' . tech_staff_table() . ' t WHERE id = :id');
    $techCheck->execute([':id' => $techId]);
    if (!$techCheck->fetch()) {
        json_error('Selected technician was not found.', 422);
    }
}

// Optional materials for the warehouse (mr_panels / mr_inverters / mr_batteries).
// Validated before anything is written, so a bad quantity creates nothing.
$materialLines = mr_parse_quantities($input, 'mr_');
if ($materialLines) {
    mr_require_schema(); // a plain project still works on an install without phase 5
}

$pdo->beginTransaction();
try {
    // MAX()+1 with retry rather than COUNT()+801, which reused a code as soon
    // as any project was deleted. Numbering still starts at SITE-801.
    $code = with_unique_code('projects', 'project_code', 'SITE-', function (string $code) use ($pdo, $clientId, $siteName, $input, $capacity, $installDate, $techId, $status) {
        $pdo->prepare(
            'INSERT INTO projects (project_code, client_id, site_name, address, system_type, capacity_kw,
                installation_date, assigned_technician_id, status, progress, notes)
             VALUES (:code, :client_id, :site_name, :address, :system_type, :capacity, :install_date, :tech_id, :status, 0, :notes)'
        )->execute([
            ':code' => $code,
            ':client_id' => $clientId,
            ':site_name' => $siteName,
            ':address' => trim($input['address'] ?? '') ?: null,
            ':system_type' => trim($input['system_type'] ?? '') ?: null,
            ':capacity' => $capacity,
            ':install_date' => $installDate,
            ':tech_id' => $techId,
            ':status' => $status,
            ':notes' => trim($input['notes'] ?? '') ?: null,
        ]);
        return $code;
    }, floor: 800);
    $projectId = (int)$pdo->lastInsertId();

    $newHelpers = [];
    if ($crew) {
        $pdo->prepare('UPDATE projects SET site_size = :s, crew_size = :c WHERE id = :id')
            ->execute([':s' => $crew['site_size'], ':c' => $crew['crew_size'], ':id' => $projectId]);
        $newHelpers = crew_set_members($projectId, $techId, $crew['members']);
    }

    // The client's solar system (what they see under "My Solar System"),
    // linked to the project and kept in step with it from now on.
    if ($status !== 'CANCELLED') {
        project_sync_solar_system($projectId);
    }

    $mrId = $mrCode = null;
    if ($materialLines) {
        [$mrId, $mrCode] = mr_create($pdo, $clientId, $materialLines, $projectId, null, $installDate, "For project {$code} — {$siteName}");
    }

    // The installation job is what the assigned technician actually sees; it is
    // created after the material request so the request gets linked to it.
    $jobNotes = project_sync_installation_job($projectId);
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('SunTrack project create: ' . $e);
    json_error('Failed to create project.', 500);
}

audit_log('CREATE', 'projects', $code);
project_send_job_notifications($jobNotes);
crew_notify_added($projectId, $newHelpers);
$jobCode = null;
if ($techId) {
    $jc = $pdo->prepare("SELECT job_code FROM jobs WHERE project_id = :p AND job_type = 'INSTALLATION' AND stage NOT IN ('COMPLETED','CANCELLED') ORDER BY id DESC LIMIT 1");
    $jc->execute([':p' => $projectId]);
    $jobCode = $jc->fetchColumn() ?: null;
    if ($jobCode) {
        audit_log('CREATE', 'jobs', $jobCode);
    }
}

if ($mrId) {
    audit_log('CREATE', 'material_requests', $mrCode);
    mr_notify_warehouse(
        "New client order {$mrCode} for project {$code} ({$siteName}): " . mr_lines_summary($materialLines)
            . ($installDate ? ", needed by {$installDate}" : '') . '.',
        $mrId
    );
}

// An installation job left without a crew goes to a subcontractor when the team is near full.
if (!$techId && function_exists('sub_auto_sweep')) {
    sub_auto_sweep(db());
}

$crewCount = $techId ? 1 + count($crew['members'] ?? []) : 0;
$message = 'Project created.'
    . ($crew && $crew['site_size'] ? ' ' . crew_rules()['labels'][$crew['site_size']] . ' site.' : '')
    . ($jobCode ? " Installation job {$jobCode} assigned to a crew of {$crewCount}" . ($crew && $crew['auto'] ? ' (picked automatically)' : '') . '.' : '')
    . ($crew && $techId && $crewCount < $crew['crew_size'] ? " Note: this size needs {$crew['crew_size']} technicians." : '')
    . ($mrCode ? " Material request {$mrCode} sent to the warehouse." : '');
json_success(
    ['project_code' => $code, 'material_request_code' => $mrCode, 'installation_job_code' => $jobCode],
    $message
);
