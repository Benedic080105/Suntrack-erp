<?php
/**
 * GET /api/projects/detail.php?id=N — Admin (view) / Management.
 *
 * Everything about one project on one screen (Management > Projects, click a
 * row): the project, the client and how to reach them, the solar system and
 * its equipment, the crew, every job with its stage, the installation stages
 * and proof photos, maintenance (schedule and past visits), billing (invoices,
 * paid, balance), warehouse orders, service requests and work reports.
 * Read-only. Each block is independent: a module not installed yet comes back
 * empty instead of failing the whole view.
 */
require_once __DIR__ . '/../../middleware/admin.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed.', 405);
}
$id = (int)($_GET['id'] ?? 0);
$pdo = db();

$p = $pdo->prepare(
    "SELECT p.*, c.client_code, c.address AS client_address, c.barangay, c.city, c.province, c.postal_code, c.lat, c.lng,
            c.date_registered, cu.full_name AS client_name, cu.email AS client_email, cu.phone AS client_phone,
            cu.status AS client_account_status, cu.last_login AS client_last_login
     FROM projects p JOIN clients c ON c.id = p.client_id JOIN users cu ON cu.id = c.user_id
     WHERE p.id = :id"
);
$p->execute([':id' => $id]);
$project = $p->fetch();
if (!$project) {
    json_error('Project not found.', 404);
}
$clientId = (int)$project['client_id'];

/** Run one block; on a missing table / column give its empty value. */
$block = function (callable $fn, $empty) {
    try {
        return $fn();
    } catch (PDOException $e) {
        return $empty;
    }
};

// Solar system: the project's own, else the client's latest.
$system = $block(function () use ($pdo, $project, $clientId) {
    $s = $pdo->prepare($project['solar_system_id']
        ? 'SELECT * FROM solar_systems WHERE id = :x'
        : 'SELECT * FROM solar_systems WHERE client_id = :x ORDER BY id DESC LIMIT 1');
    $s->execute([':x' => $project['solar_system_id'] ?: $clientId]);
    return $s->fetch() ?: null;
}, null);

$crew = $block(fn() => crew_available() ? crew_list($id) : [], []);
if (!$crew && $project['assigned_technician_id']) {
    $crew = $block(function () use ($pdo, $project) {
        $t = $pdo->prepare('SELECT t.id, t.technician_code AS code, u.full_name AS name, u.phone FROM technicians t JOIN users u ON u.id = t.user_id WHERE t.id = :t');
        $t->execute([':t' => $project['assigned_technician_id']]);
        $r = $t->fetch();
        return $r ? [$r + ['is_lead' => true]] : [];
    }, []);
}

// Jobs on this project, newest first, with who does them.
$jobs = $block(function () use ($pdo, $id) {
    $j = $pdo->prepare(
        "SELECT j.id, j.job_code, j.job_type, j.stage, j.progress, j.priority, j.scheduled_date, j.created_at, j.updated_at,
                tu.full_name AS technician_name,
                (SELECT wr.report_code FROM work_reports wr WHERE wr.job_id = j.id LIMIT 1) AS report_code
         FROM jobs j LEFT JOIN technicians t ON t.id = j.technician_id LEFT JOIN users tu ON tu.id = t.user_id
         WHERE j.project_id = :p ORDER BY j.id DESC"
    );
    $j->execute([':p' => $id]);
    return $j->fetchAll();
}, []);

// Installation: the stage plan and proof photos of the installation job.
$installation = $block(function () use ($jobs) {
    foreach ($jobs as $j) {
        if ($j['job_type'] !== 'INSTALLATION') {
            continue;
        }
        $cl = tech_checklist_for_job((int)$j['id']);
        if (!$cl) {
            return null;
        }
        $plan = install_plan_available() ? install_plan((int)$cl['id'], (int)$j['id']) : [];
        return [
            'job_id' => (int)$j['id'], 'job_code' => $j['job_code'], 'progress' => (int)($cl['progress'] ?? 0),
            'plan' => array_map(fn($r) => ['stage' => $r['stage'], 'status' => $r['status'], 'scheduled_date' => $r['scheduled_date'],
                                           'reviewed_at' => $r['reviewed_at'] ?? null], $plan),
            'summary' => install_plan_summary($plan),
            'photos' => installation_photos_list((int)$cl['id']),
        ];
    }
    return null;
}, null);

$maintenance = [
    'schedule' => $block(function () use ($pdo, $id) {
        $s = $pdo->prepare('SELECT last_maintenance, next_maintenance, status, client_notified, notified_at FROM maintenance_schedules WHERE project_id = :p LIMIT 1');
        $s->execute([':p' => $id]);
        return $s->fetch() ?: null;
    }, null),
    'visits' => $block(function () use ($pdo, $id) {
        $v = $pdo->prepare(
            "SELECT j.id AS job_id, j.job_code, j.stage, mr.status, mr.completion_date, mr.panel_condition, mr.battery_condition,
                    mr.inverter_condition, mr.issues_found, tu.full_name AS technician_name"
            . (maint_review_ready() ? ', mr.review_status' : '') . "
             FROM jobs j LEFT JOIN maintenance_records mr ON mr.job_id = j.id
             LEFT JOIN technicians t ON t.id = j.technician_id LEFT JOIN users tu ON tu.id = t.user_id
             WHERE j.project_id = :p AND j.job_type = 'MAINTENANCE' ORDER BY j.id DESC LIMIT 20"
        );
        $v->execute([':p' => $id]);
        return $v->fetchAll();
    }, []),
];

// Billing: this project's invoices (or the client's when none are linked), paid and balance.
$billing = $block(function () use ($pdo, $id, $clientId) {
    $sql = "SELECT i.id, i.invoice_code, i.amount, i.due_date, i.payment_status, i.created_at, i.project_id,
                   COALESCE(pay.paid, 0) AS paid
            FROM invoices i LEFT JOIN (" . billing_paid_subquery() . ") pay ON pay.invoice_id = i.id
            WHERE %s ORDER BY i.id DESC LIMIT 30";
    $s = $pdo->prepare(sprintf($sql, 'i.project_id = :x'));
    $s->execute([':x' => $id]);
    $rows = $s->fetchAll();
    $scope = 'project';
    if (!$rows) {
        $s = $pdo->prepare(sprintf($sql, 'i.client_id = :x'));
        $s->execute([':x' => $clientId]);
        $rows = $s->fetchAll();
        $scope = 'client';
    }
    $today = date('Y-m-d');
    $billed = $paid = 0.0;
    foreach ($rows as &$r) {
        $r['amount'] = (float)$r['amount'];
        $r['paid'] = (float)$r['paid'];
        $r['balance'] = $r['payment_status'] === 'CANCELLED' ? 0.0 : max(0.0, round($r['amount'] - $r['paid'], 2));
        $r['overdue'] = $r['balance'] > 0 && $r['due_date'] && $r['due_date'] < $today;
        if ($r['payment_status'] !== 'CANCELLED') {
            $billed += $r['amount'];
            $paid += min($r['paid'], $r['amount']);
        }
    }
    unset($r);
    return ['scope' => $scope, 'invoices' => $rows, 'billed' => round($billed, 2), 'paid' => round($paid, 2),
            'balance' => round(max(0, $billed - $paid), 2)];
}, ['scope' => 'project', 'invoices' => [], 'billed' => 0, 'paid' => 0, 'balance' => 0]);

$materials = $block(function () use ($pdo, $id) {
    $m = $pdo->prepare('SELECT id, request_code, status, needed_by, created_at, released_at FROM material_requests WHERE project_id = :p ORDER BY id DESC LIMIT 20');
    $m->execute([':p' => $id]);
    return $m->fetchAll();
}, []);

$requests = $block(function () use ($pdo, $clientId, $project) {
    $s = $pdo->prepare(
        'SELECT id, request_code, request_type, subject, status, priority, date_requested FROM service_requests
         WHERE client_id = :c' . ($project['solar_system_id'] ? ' AND (solar_system_id = :s OR solar_system_id IS NULL)' : '') . '
         ORDER BY id DESC LIMIT 20'
    );
    $s->execute([':c' => $clientId] + ($project['solar_system_id'] ? [':s' => $project['solar_system_id']] : []));
    return $s->fetchAll();
}, []);

$reports = $block(function () use ($pdo, $id) {
    $r = $pdo->prepare(
        'SELECT wr.report_code, wr.work_type, wr.status, wr.submitted_date, wr.remarks, j.job_code, tu.full_name AS technician_name
         FROM work_reports wr JOIN jobs j ON j.id = wr.job_id
         LEFT JOIN technicians t ON t.id = wr.technician_id LEFT JOIN users tu ON tu.id = t.user_id
         WHERE j.project_id = :p ORDER BY wr.id DESC LIMIT 20'
    );
    $r->execute([':p' => $id]);
    return $r->fetchAll();
}, []);

$client = [
    'id' => $clientId, 'name' => $project['client_name'], 'client_code' => $project['client_code'],
    'email' => $project['client_email'], 'phone' => $project['client_phone'],
    'address' => trim(implode(', ', array_filter([$project['client_address'], $project['barangay'], $project['city'], $project['province'], $project['postal_code']])), ', '),
    'lat' => $project['lat'] !== null ? (float)$project['lat'] : null, 'lng' => $project['lng'] !== null ? (float)$project['lng'] : null,
    'registered' => $project['date_registered'], 'account_status' => $project['client_account_status'], 'last_login' => $project['client_last_login'],
];
foreach (['client_code', 'client_address', 'barangay', 'city', 'province', 'postal_code', 'lat', 'lng', 'date_registered',
          'client_name', 'client_email', 'client_phone', 'client_account_status', 'client_last_login'] as $k) {
    unset($project[$k]);
}

json_success([
    'project'      => $project,
    'client'       => $client,
    'system'       => $system,
    'crew'         => $crew,
    'jobs'         => $jobs,
    'installation' => $installation,
    'maintenance'  => $maintenance,
    'billing'      => $billing,
    'materials'    => $materials,
    'requests'     => $requests,
    'reports'      => $reports,
    'can_manage'   => in_array(current_role(), ['manager', 'staff'], true),
]);
