<?php
/**
 * GET /api/projects/crew_options.php?capacity_kw=&date=&project_id=&site_size=
 * Management only. What the project form's crew picker needs:
 *
 *   site_size / recommended   the size for that kW and how many technicians it needs
 *   rules                     the kW thresholds and crew sizes (for the hint text)
 *   candidates                every active technician, best first, with availability,
 *                             open jobs and whether they already work that day
 *   crew                      the project's current crew (lead + helpers), when editing
 *   suggested                 the ids auto-pick would choose
 */
require_once __DIR__ . '/../../config/config.php';
require_management();

if (!crew_available()) {
    json_error('Crews are not set up yet. Run database/phase14_project_crew.sql.', 503);
}

$capacity = isset($_GET['capacity_kw']) && is_numeric($_GET['capacity_kw']) ? (float)$_GET['capacity_kw'] : null;
$date = query_date('date');
$projectId = !empty($_GET['project_id']) ? (int)$_GET['project_id'] : null;

$size = strtoupper(trim((string)($_GET['site_size'] ?? '')));
$size = in_array($size, CREW_SIZES, true) ? $size : crew_site_size($capacity);
$crewSize = isset($_GET['crew_size']) && ctype_digit((string)$_GET['crew_size']) && (int)$_GET['crew_size'] > 0
    ? min(10, (int)$_GET['crew_size']) : crew_recommended($size);

$current = [];
if ($projectId) {
    foreach (crew_list($projectId) as $m) {
        $current[] = ['id' => $m['id'], 'is_lead' => $m['is_lead']];
    }
}

json_success([
    'site_size'   => $size,
    'size_label'  => $size ? crew_rules()['labels'][$size] : null,
    'recommended' => crew_recommended($size),
    'crew_size'   => $crewSize,
    'rules'       => crew_rules(),
    'date'        => $date,
    'candidates'  => crew_candidates($date, $projectId),
    'crew'        => $current,
    'suggested'   => crew_auto_pick($crewSize, $date, $projectId),
]);
