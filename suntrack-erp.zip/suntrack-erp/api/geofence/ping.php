<?php
/**
 * POST /api/geofence/ping.php
 *
 * Periodic location capture while the technician is on an active field job.
 * Writes to the existing geofence_records table — deliberately no second
 * location table.
 *
 * Guards:
 *   - technician session + CSRF
 *   - job must be assigned to this technician
 *   - job must be in a field stage (EN_ROUTE / ARRIVED / IN_PROGRESS / PAUSED);
 *     technicians are NOT tracked when they have no active field assignment
 *   - a throttle stops a runaway timer from flooding the table
 */
require_once __DIR__ . '/../../middleware/technician.php';

/** Minimum seconds between stored pings for the same job. */
const GEOFENCE_MIN_INTERVAL_SECONDS = 10;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['job_id', 'latitude', 'longitude']);

if (!is_numeric($input['latitude']) || !is_numeric($input['longitude'])) {
    json_error('Invalid coordinates.', 422);
}

$lat = (float)$input['latitude'];
$lng = (float)$input['longitude'];
if ($lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) {
    json_error('Coordinates out of range.', 422);
}

$techId = (int)current_profile_id();
$job    = tech_job_or_fail((int)$input['job_id']);

if (!in_array($job['stage'], tech_field_stages(), true)) {
    json_error('Location tracking only runs while a job is active in the field.', 422, [
        'tracking' => false,
        'stage'    => $job['stage'],
    ]);
}

$radius   = tech_geofence_radius($job);
$distance = tech_distance_to_site($job, $lat, $lng);

if ($distance === null) {
    json_success([
        'recorded'          => false,
        'distance_m'        => null,
        'inside'            => null,
        'geofence_radius_m' => $radius,
    ], 'This job has no site coordinates, so distance cannot be calculated.');
}

$status = $distance <= $radius ? 'INSIDE' : 'OUTSIDE';

// Throttle: skip the insert if we already stored a ping moments ago.
$pdo = db();
// The age is computed by MySQL against its own NOW(), not by comparing a
// MySQL timestamp to PHP's time(): PHP runs on Asia/Manila while the MySQL
// server may be on UTC, and mixing the two clocks makes the throttle
// meaningless in one direction and permanently blocking in the other.
$lastStmt = $pdo->prepare(
    'SELECT TIMESTAMPDIFF(SECOND, recorded_at, NOW()) AS age_seconds
     FROM geofence_records
     WHERE job_id = :j AND technician_id = :t ORDER BY id DESC LIMIT 1'
);
$lastStmt->execute([':j' => $job['id'], ':t' => $techId]);
$lastAge = $lastStmt->fetchColumn();

$accuracy = isset($input['accuracy']) && is_numeric($input['accuracy']) ? (float)$input['accuracy'] : null;

$recorded = false;
if ($lastAge === false || (int)$lastAge >= GEOFENCE_MIN_INTERVAL_SECONDS) {
    // Flag (never refuse) a reading the technician could not physically
    // have reached in time — Management gets an alert.
    $jump = tech_gps_jump($techId, $lat, $lng, $accuracy);
    tech_record_geofence((int)$job['id'], $techId, $lat, $lng, $distance, $status, $accuracy, $jump ? 'IMPOSSIBLE_JUMP' : null);
    tech_report_gps_jump($job, $techId, $jump);
    $recorded = true;
}

json_success([
    'recorded'          => $recorded,
    'job_id'            => (int)$job['id'],
    'job_code'          => $job['job_code'],
    'stage'             => $job['stage'],
    'distance_m'        => round($distance),
    'inside'            => $status === 'INSIDE',
    'status'            => $status,
    'geofence_radius_m' => $radius,
    'site_lat'          => (float)$job['site_lat'],
    'site_lng'          => (float)$job['site_lng'],
], $status === 'INSIDE' ? 'Inside the job geofence.' : 'Outside the job geofence.');
