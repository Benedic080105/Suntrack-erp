<?php
/**
 * POST /api/subcontractor/upload.php (multipart) — evidence for the company's
 * own open assignment. Fields: csrf_token, assignment_id, category, file.
 *   COMPLETION_PHOTO     photo only (JPG / PNG / WebP, re-encoded, EXIF removed)
 *   INSPECTION_EVIDENCE  photo or PDF
 *   SUPPORTING_DOCUMENT  photo or PDF
 * Max 10 MB. Not while awaiting inspection, nor once closed.
 */
require_once __DIR__ . '/../../middleware/subcontractor.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
if (empty($_POST) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    json_error('That file is too large (max 10 MB).', 413);
}
require_csrf($_POST);
require_fields($_POST, ['assignment_id', 'category']);

$sub = sub_portal_current(true);
$category = strtoupper((string)$_POST['category']);
if (!in_array($category, ['COMPLETION_PHOTO', 'INSPECTION_EVIDENCE', 'SUPPORTING_DOCUMENT'], true)) {
    json_error('Unknown file category.', 422);
}
$pdo = db();
$a = sub_portal_assignment($pdo, (int)$_POST['assignment_id'], (int)$sub['id']);
if (!in_array($a['status'], ['ACCEPTED', 'SCHEDULED', 'IN_PROGRESS', 'REVISION_REQUIRED'], true)) {
    json_error('Files cannot be added while the work is ' . strtolower(SA_LABELS[$a['status']]) . '.', 422);
}
if ($category === 'COMPLETION_PHOTO') {
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($_FILES['file']['tmp_name'] ?? '') ?: '';
    if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) {
        json_error('A completion photo must be a JPG, PNG or WebP image.', 422);
    }
}
$saved = sub_save_upload($pdo, $a, $category, $_FILES['file'] ?? []);
audit_log('SUBCON_UPLOAD', 'subcontractor_assignments', $a['assignment_code']);
json_success($saved, 'File uploaded.');
