<?php
/**
 * GET /api/subcontractor/dashboard.php — the signed-in subcontractor's own
 * dashboard: NEW job offers waiting for an answer (with the time left), jobs
 * by status, upcoming deadlines and unread notifications. Nothing about other
 * companies.
 */
require_once __DIR__ . '/../../middleware/subcontractor.php';

$sub = sub_portal_current();
$pdo = db();
$sid = (int)$sub['id'];

// Offers that ran out of time move on (to the next subcontractor) before we show anything.
sub_auto_sweep($pdo, false, []);

$counts = array_fill_keys(array_keys(SA_LABELS), 0);
$s = $pdo->prepare('SELECT status, COUNT(*) AS n FROM subcontractor_assignments WHERE subcontractor_id = :s GROUP BY status');
$s->execute([':s' => $sid]);
foreach ($s->fetchAll() as $r) {
    $counts[$r['status']] = (int)$r['n'];
}

$o = $pdo->prepare(
    "SELECT a.id, a.assignment_code, a.assigned_at, a.offer_expires_at, a.expected_completion, a.contract_amount, a.scope,
            j.job_code, j.job_type, j.priority, j.site_address, j.scheduled_date, cu.full_name AS client_name, c.city
     FROM subcontractor_assignments a JOIN jobs j ON j.id = a.job_id JOIN clients c ON c.id = j.client_id JOIN users cu ON cu.id = c.user_id
     WHERE a.subcontractor_id = :s AND a.status = 'AWAITING_ACCEPTANCE' ORDER BY a.offer_expires_at IS NULL, a.offer_expires_at, a.id"
);
$o->execute([':s' => $sid]);
$offers = array_map(function ($r) {
    $r['seconds_left'] = $r['offer_expires_at'] ? max(0, strtotime($r['offer_expires_at']) - time()) : null;
    return $r;
}, $o->fetchAll());

$d = $pdo->prepare(
    "SELECT a.id, a.assignment_code, a.status, a.expected_completion, a.scheduled_date, j.job_code, j.job_type, j.site_address
     FROM subcontractor_assignments a JOIN jobs j ON j.id = a.job_id
     WHERE a.subcontractor_id = :s AND a.status IN ('ACCEPTED','SCHEDULED','IN_PROGRESS','REVISION_REQUIRED')
     ORDER BY COALESCE(a.scheduled_date, a.expected_completion) IS NULL, COALESCE(a.scheduled_date, a.expected_completion) LIMIT 10"
);
$d->execute([':s' => $sid]);
$active = array_map(function ($r) {
    $r['status_label'] = SA_LABELS[$r['status']];
    $r['overdue'] = $r['expected_completion'] && $r['expected_completion'] < date('Y-m-d');
    return $r;
}, $d->fetchAll());

$n = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = :u AND is_read = 0');
$n->execute([':u' => current_user_id()]);

json_success([
    'subcontractor' => ['subcon_code' => $sub['subcon_code'], 'name' => $sub['name'], 'status' => $sub['status'],
                        'max_active_jobs' => (int)$sub['max_active_jobs'], 'contract_end' => $sub['contract_end']],
    'can_act' => $sub['status'] === 'APPROVED',
    'counts'  => $counts,
    'offers'  => $offers,
    'active'  => $active,
    'unread'  => (int)$n->fetchColumn(),
]);
