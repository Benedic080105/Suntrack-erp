<?php
/**
 * GET /api/subcontractor/jobs.php — the signed-in company's own assignments.
 * Filters: status (or "open"), search (assignment / job code, client, address).
 */
require_once __DIR__ . '/../../middleware/subcontractor.php';

$sub = sub_portal_current();
$pdo = db();
[$pageLimit, $pageOffset] = list_page(200);
$where = ['a.subcontractor_id = :sid'];
$params = [':sid' => (int)$sub['id']];
$status = $_GET['status'] ?? '';
if ($status === 'open') {
    $where[] = "a.status IN ('" . implode("','", SA_OPEN) . "')";
} elseif ($status !== '' && isset(SA_LABELS[$status])) {
    $where[] = 'a.status = :st';
    $params[':st'] = $status;
}
if ($clause = search_clause($_GET['search'] ?? '', ['a.assignment_code', 'j.job_code', 'cu.full_name', 'j.site_address'], $params)) {
    $where[] = $clause;
}
$stmt = $pdo->prepare(
    "SELECT a.id, a.assignment_code, a.status, a.expected_completion, a.scheduled_date, a.offer_expires_at, a.contract_amount,
            a.assigned_at, a.revision_count, j.job_code, j.job_type, j.site_address, cu.full_name AS client_name
     FROM subcontractor_assignments a
     JOIN jobs j ON j.id = a.job_id JOIN clients c ON c.id = j.client_id JOIN users cu ON cu.id = c.user_id
     WHERE " . implode(' AND ', $where) . "
     ORDER BY FIELD(a.status, 'AWAITING_ACCEPTANCE','REVISION_REQUIRED','IN_PROGRESS','SCHEDULED','ACCEPTED','AWAITING_INSPECTION','APPROVED','COMPLETED','DECLINED','CANCELLED'), a.id DESC
     " . list_page_sql($pageLimit, $pageOffset)
);
$stmt->execute($params);
$rows = list_page_finish($stmt->fetchAll(), $pageLimit, $pageOffset);
foreach ($rows as &$r) {
    $r['status_label'] = SA_LABELS[$r['status']];
    $r['overdue'] = $r['expected_completion'] && $r['expected_completion'] < date('Y-m-d')
        && in_array($r['status'], ['ACCEPTED', 'SCHEDULED', 'IN_PROGRESS', 'REVISION_REQUIRED'], true);
}
unset($r);
json_success($rows);
