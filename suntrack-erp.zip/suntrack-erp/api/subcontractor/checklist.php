<?php
/**
 * POST /api/subcontractor/checklist.php — tick an item on the job's existing
 * checklist (the same rows Management and the technician portal use).
 * Body: assignment_id, item_id, status (COMPLETED | NOT_APPLICABLE | PENDING), remarks.
 * Only while the assignment is IN_PROGRESS or REVISION_REQUIRED.
 */
require_once __DIR__ . '/../../middleware/subcontractor.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
$input = json_input();
require_csrf($input);
require_fields($input, ['assignment_id', 'item_id', 'status']);

$sub = sub_portal_current(true);
// Checklists are ticked in the field portal (Installation / Maintenance tabs),
// under the same rules as a technician.
json_error('Tick the checklist in the Installation or Maintenance tab of your portal.', 409);
$status = strtoupper((string)$input['status']);
if (!in_array($status, ['COMPLETED', 'NOT_APPLICABLE', 'PENDING'], true)) {
    json_error('Status must be Done, N/A or Pending.', 422);
}
$remarks = mb_substr(trim((string)($input['remarks'] ?? '')), 0, 255) ?: null;
if ($status === 'NOT_APPLICABLE' && $remarks === null) {
    json_error('Say why this item is not applicable.', 422);
}

$pdo = db();
$pdo->beginTransaction();
try {
    $a = sub_lock_assignment($pdo, (int)$input['assignment_id'], (int)$sub['id']);
    if (!in_array($a['status'], ['IN_PROGRESS', 'REVISION_REQUIRED'], true)) {
        sub_fail('The checklist can be updated only while the work is in progress or being revised.', 409);
    }
    $cl = sub_checklist($pdo, $a, true);
    if (!$cl['type']) {
        sub_fail('This job type has no checklist. Upload photos and documents as evidence instead.');
    }
    $itemId = (int)$input['item_id'];
    $desc = null;
    foreach ($cl['items'] as $it) {
        if ((int)$it['id'] === $itemId) {
            $desc = $it['description'];
        }
    }
    if ($desc === null) {
        sub_fail('Checklist item not found on this job.', 404); // never another job's item
    }
    $table = $cl['type'] === 'installation' ? 'installation_items' : 'maintenance_items';
    $pdo->prepare("UPDATE $table SET status = :s, remarks = :r WHERE id = :id")->execute([':s' => $status, ':r' => $remarks, ':id' => $itemId]);
    if ($cl['type'] === 'installation') {
        tech_recalc_installation($cl['id'], (int)$a['job_id']);
    }
    sub_event($pdo, (int)$a['id'], (int)$sub['id'], 'CHECKLIST', null, null, "$desc: " . strtolower(str_replace('_', ' ', $status)));
    $pending = sub_checklist($pdo, $a, false)['pending'];
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('subcontractor/checklist failed: ' . $e->getMessage());
    json_error('Could not update the checklist. Nothing was changed.', 500);
}
json_success(['pending' => $pending], $pending ? "Saved. $pending item(s) left." : 'Saved. Every checklist item is done.');
