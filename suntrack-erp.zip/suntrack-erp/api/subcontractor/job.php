<?php
/**
 * GET /api/subcontractor/job.php?id=N — one of the signed-in company's
 * assignments (anyone else's id is a 404): site, schedule, scope, materials,
 * the job's checklist, files, history and the next allowed steps. SunTrack
 * staff appear as "SunTrack"; the internal reason for choosing them is not shown.
 */
require_once __DIR__ . '/../../middleware/subcontractor.php';

$sub = sub_portal_current();
$pdo = db();
$a = sub_portal_assignment($pdo, (int)($_GET['id'] ?? 0), (int)$sub['id']);

$open = in_array($a['status'], ['ACCEPTED', 'SCHEDULED', 'IN_PROGRESS', 'REVISION_REQUIRED'], true);
$canAct = $sub['status'] === 'APPROVED';
$moves = array_keys(array_filter(SA_MOVES[$a['status']] ?? [], fn($w) => $w === 'sub'));
$events = array_map(function ($e) {
    $e['actor'] = $e['actor_role'] === 'subcontractor' ? ($e['actor_name'] ?? 'You') : ($e['actor_role'] === 'system' ? 'SunTrack (automatic)' : 'SunTrack');
    if ($e['action'] === 'AUTO_ASSIGNED') {
        $e['note'] = 'Offered to you automatically';
    }
    unset($e['actor_name'], $e['actor_role']);
    return $e;
}, sub_events($pdo, (int)$a['id']));
$files = array_map(function ($f) {
    unset($f['uploaded_by_name']);
    return $f;
}, sub_files($pdo, (int)$a['id']));

json_success([
    'job' => [
        'id' => (int)$a['id'], 'assignment_code' => $a['assignment_code'], 'status' => $a['status'], 'status_label' => SA_LABELS[$a['status']],
        'job_code' => $a['job_code'], 'job_type' => $a['job_type'], 'priority' => $a['priority'], 'client_name' => $a['client_name'],
        'client_phone' => $a['client_phone'], 'site_address' => $a['site_address'], 'site_lat' => $a['site_lat'], 'site_lng' => $a['site_lng'],
        'job_description' => $a['job_description'], 'scope' => $a['scope'], 'instructions' => $a['instructions'],
        'materials_note' => $a['materials_note'], 'contract_amount' => (float)$a['contract_amount'], 'assigned_at' => $a['assigned_at'],
        'offer_expires_at' => $a['offer_expires_at'], 'expected_completion' => $a['expected_completion'], 'scheduled_date' => $a['scheduled_date'],
        'decline_reason' => $a['decline_reason'], 'review_note' => $a['review_note'], 'revision_count' => (int)$a['revision_count'],
        'submitted_at' => $a['submitted_at'], 'completed_at' => $a['completed_at'],
    ],
    'checklist'  => sub_checklist($pdo, $a, $open),
    'files'      => $files,
    'events'     => $events,
    'can_act'    => $canAct,
    'moves'      => $canAct ? $moves : [],
    'can_upload' => $canAct && $open,
    'can_tick'   => $canAct && in_array($a['status'], ['IN_PROGRESS', 'REVISION_REQUIRED'], true),
    'submit_blocker' => in_array('AWAITING_INSPECTION', $moves, true) ? sub_submission_blocker($pdo, $a) : null,
]);
