<?php
/**
 * POST /api/subcontractor/act.php — the subcontractor moves its own assignment.
 * Body: assignment_id, action, and
 *   accept                      AWAITING_ACCEPTANCE → ACCEPTED (job ASSIGNED)
 *   decline   reason required   → DECLINED; the job is offered automatically to
 *                               the next-best subcontractor, or returns to Management
 *   schedule  date (≥ today)    → SCHEDULED (again to reschedule)
 *   start                       → IN_PROGRESS (job IN_PROGRESS)
 *   submit    note optional     IN_PROGRESS / REVISION_REQUIRED → AWAITING_INSPECTION
 */
require_once __DIR__ . '/../../middleware/subcontractor.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
$input = json_input();
require_csrf($input);
require_fields($input, ['assignment_id', 'action']);

$sub = sub_portal_current(true);
$action = (string)$input['action'];
// The work itself (start, checklist, completion) goes through the field portal,
// with its GPS Time In and completion rules: api/jobs/status.php.
if (in_array($action, ['start', 'submit'], true)) {
    json_error('Use Start Work / Submit for Inspection on the job in your portal (GPS Time In and the checklist are required).', 409);
}
$note = trim((string)($input['reason'] ?? $input['note'] ?? ''));
if (mb_strlen($note) > 500) {
    json_error('Note is too long (500 characters max).', 422);
}

$pdo = db();
$pdo->beginTransaction();
try {
    $a = sub_lock_assignment($pdo, (int)$input['assignment_id'], (int)$sub['id']);
    $toMgmt = null;
    switch ($action) {
        case 'accept':
            if ($a['status'] === 'AWAITING_ACCEPTANCE' && $a['offer_expires_at'] && strtotime($a['offer_expires_at']) < time()) {
                sub_fail('This offer has expired and was passed on. Watch your dashboard for new jobs.', 409);
            }
            $a = sub_move($pdo, $a, 'ACCEPTED', 'sub', $note ?: 'Accepted', ['responded_at' => date('Y-m-d H:i:s'), 'responded_by' => current_user_id()]);
            $message = "You accepted {$a['job_code']}. Set a schedule date when you know it.";
            $toMgmt = "{$sub['name']} accepted {$a['job_code']} ({$a['assignment_code']}).";
            break;
        case 'decline':
            if (mb_strlen($note) < 5) {
                sub_fail('Tell SunTrack why you are declining (at least 5 characters).');
            }
            $a = sub_move($pdo, $a, 'DECLINED', 'sub', $note, ['responded_at' => date('Y-m-d H:i:s'), 'responded_by' => current_user_id(), 'decline_reason' => $note]);
            $message = "You declined {$a['job_code']}. SunTrack will pass it to someone else.";
            $toMgmt = "{$sub['name']} declined {$a['job_code']} ({$a['assignment_code']}): $note";
            break;
        case 'schedule':
            $date = trim((string)($input['date'] ?? ''));
            $d = DateTime::createFromFormat('!Y-m-d', $date);
            if (!$d || $d->format('Y-m-d') !== $date || $date < date('Y-m-d')) {
                sub_fail('Choose a valid schedule date, today or later.');
            }
            $a = sub_move($pdo, $a, 'SCHEDULED', 'sub', "Scheduled for $date", ['scheduled_date' => $date]);
            $pdo->prepare('UPDATE jobs SET scheduled_date = :d WHERE id = :id')->execute([':d' => $date, ':id' => $a['job_id']]);
            $message = "{$a['job_code']} scheduled for $date.";
            $toMgmt = "{$sub['name']} scheduled {$a['job_code']} for $date.";
            break;
        case 'start':
            $a = sub_move($pdo, $a, 'IN_PROGRESS', 'sub', 'Work started', ['started_at' => date('Y-m-d H:i:s')]);
            $message = "{$a['job_code']} is in progress. Tick the checklist and upload completion photos as you go.";
            break;
        case 'submit':
            if (!isset(SA_MOVES[$a['status']]['AWAITING_INSPECTION'])) {
                sub_fail('This job is ' . SA_LABELS[$a['status']] . ' — it can be submitted only while the work is in progress or being revised.', 409);
            }
            if ($why = sub_submission_blocker($pdo, $a)) {
                sub_fail($why);
            }
            $a = sub_move($pdo, $a, 'AWAITING_INSPECTION', 'sub', $note ?: 'Submitted for inspection',
                ['submitted_at' => date('Y-m-d H:i:s'), 'submission_round' => ['raw' => 'submission_round + 1']]);
            $message = "{$a['job_code']} submitted for inspection. SunTrack will review it.";
            $toMgmt = "{$sub['name']} submitted {$a['job_code']} ({$a['assignment_code']}) for inspection.";
            break;
        default:
            sub_fail('Unknown action.');
    }
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('subcontractor/act failed: ' . $e->getMessage());
    json_error('Could not save that. Nothing was changed.', 500);
}

audit_log('SUBCON_' . strtoupper($action), 'subcontractor_assignments', $a['assignment_code']);
if ($toMgmt) {
    sub_notify_management($toMgmt, (int)$a['id']);
}
if ($action === 'decline') {
    // Pass it straight on to the next-best subcontractor.
    sub_auto_sweep($pdo, false, [(int)$a['job_id']]);
}
json_success(['status' => $a['status'], 'status_label' => SA_LABELS[$a['status']]], $message);
