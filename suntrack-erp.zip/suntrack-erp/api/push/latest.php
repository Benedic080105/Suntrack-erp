<?php
/**
 * GET /api/push/latest.php — what the service worker shows when a push
 * arrives: the signed-in user's newest unread notification. The push itself
 * carries no data, so the text only ever travels over the user's session.
 */
require_once __DIR__ . '/../../config/config.php';
require_login(true);

$stmt = db()->prepare(
    'SELECT id, type, message, created_at FROM notifications
     WHERE user_id = :u AND is_read = 0
     ORDER BY id DESC LIMIT 1'
);
$stmt->execute([':u' => (int)current_user_id()]);
$n = $stmt->fetch();

header('Cache-Control: no-store');
json_success([
    'notification' => $n ? [
        'id'      => (int)$n['id'],
        'title'   => ucwords(strtolower(str_replace('_', ' ', (string)$n['type']))),
        'message' => (string)$n['message'],
    ] : null,
    'url' => redirect_path_for_role(current_role()),
]);
