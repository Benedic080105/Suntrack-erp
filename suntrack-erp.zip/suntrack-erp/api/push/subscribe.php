<?php
/**
 * /api/push/subscribe.php — phone notifications for the signed-in user.
 *
 *   GET                                   { available, public_key }
 *   POST action=subscribe   {endpoint}    saves this phone / browser
 *   POST action=unsubscribe {endpoint}    removes it
 *
 * The endpoint must be a known push service (see PUSH_ALLOWED_HOSTS), so the
 * server can never be pointed at another address.
 */
require_once __DIR__ . '/../../config/config.php';
require_login(true);

$userId = (int)current_user_id();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $keys = push_vapid_keys();
    $ready = true;
    try {
        db()->query('SELECT 1 FROM push_subscriptions LIMIT 0');
    } catch (PDOException $e) {
        $ready = false;
    }
    json_success(['available' => $ready && $keys !== null, 'public_key' => $keys['public'] ?? null]);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
$action = (string)($input['action'] ?? '');
$endpoint = trim((string)($input['endpoint'] ?? ''));

if (!push_endpoint_allowed($endpoint)) {
    json_error('This browser\'s push service is not supported.', 422);
}
$hash = hash('sha256', $endpoint);

try {
    if ($action === 'subscribe') {
        $keys = is_array($input['keys'] ?? null) ? $input['keys'] : [];
        $p256 = substr(preg_replace('/[^A-Za-z0-9_\-=]/', '', (string)($keys['p256dh'] ?? '')), 0, 255);
        $auth = substr(preg_replace('/[^A-Za-z0-9_\-=]/', '', (string)($keys['auth'] ?? '')), 0, 255);
        // One device = one row. Signing in as someone else on the same phone
        // moves the device to that account.
        db()->prepare(
            'INSERT INTO push_subscriptions (user_id, endpoint, endpoint_hash, p256dh, auth, created_at)
             VALUES (:u, :e, :h, :p, :a, NOW())
             ON DUPLICATE KEY UPDATE user_id = VALUES(user_id), p256dh = VALUES(p256dh), auth = VALUES(auth)'
        )->execute([':u' => $userId, ':e' => $endpoint, ':h' => $hash, ':p' => $p256 ?: null, ':a' => $auth ?: null]);
        // A user rarely has more than a few devices; keep the newest 10.
        db()->prepare(
            'DELETE FROM push_subscriptions WHERE user_id = :u AND id NOT IN
               (SELECT id FROM (SELECT id FROM push_subscriptions WHERE user_id = :u2 ORDER BY id DESC LIMIT 10) keep)'
        )->execute([':u' => $userId, ':u2' => $userId]);
        json_success([], 'Phone notifications are on for this device.');
    }
    if ($action === 'unsubscribe') {
        db()->prepare('DELETE FROM push_subscriptions WHERE endpoint_hash = :h AND user_id = :u')
            ->execute([':h' => $hash, ':u' => $userId]);
        json_success([], 'Phone notifications are off for this device.');
    }
} catch (PDOException $e) {
    json_error('Phone notifications are not set up yet. Import database/phase7_beta_features.sql.', 503);
}

json_error('Unknown action.', 422);
