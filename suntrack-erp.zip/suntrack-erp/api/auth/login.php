<?php
require_once __DIR__ . '/../../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['email', 'password']);

$email    = trim(strtolower($input['email']));
$password = (string)$input['password'];

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_error('Please enter a valid email address.', 422);
}

// Brute-force guard. Checked BEFORE the password is verified, so a locked
// account costs an attacker a rejection rather than a bcrypt comparison.
login_guard_or_fail($email);

$user = verify_credentials($email, $password);

if (!$user) {
    login_record_attempt($email, false);
    login_prune_attempts();

    // Tell the user how much room is left before lockout — a legitimate person
    // who is mistyping needs the warning, and an attacker already knows the
    // limit from probing. The account's existence is still not revealed.
    $fails     = login_recent_failures($email);
    $remaining = max(0, LOGIN_MAX_ATTEMPTS_EMAIL - $fails['email']);

    $message = 'Invalid email or password, or the account is inactive.';
    if ($remaining > 0 && $remaining <= 2) {
        $message .= sprintf(' %d attempt%s remaining before a temporary lockout.', $remaining, $remaining === 1 ? '' : 's');
    }

    json_error($message, 401, ['attempts_remaining' => $remaining]);
}

// Two-step login: the password was right, but the person is NOT signed in
// until the authenticator code checks out (api/auth/verify_2fa.php). Only the
// user id waits in the session, for 5 minutes. The success is not recorded
// yet, so the password lockout still counts until the code is right.
if (in_array($user['role_key'], TOTP_ROLES, true) && totp_enabled_for((int)$user['id'])) {
    session_regenerate_id(true);
    $_SESSION['pending_2fa'] = ['user_id' => (int)$user['id'], 'email' => $email, 'at' => time(), 'tries' => 0];
    json_success(['requires_2fa' => true], 'Enter the 6-digit code from your authenticator app.');
}

complete_login($user);
login_record_attempt($email, true);

json_success([
    'role'            => $user['role_key'],
    'name'            => $user['full_name'],
    'redirect'        => redirect_path_for_role($user['role_key']),
    // The portals use this to decide whether to show the privacy re-consent
    // modal immediately after landing.
    'privacy_current' => consent_privacy_current((int)$user['id']),
], 'Login successful');
