<?php
require_once __DIR__ . '/../../config/config.php';
require_login(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

// CSRF-protect the API logout endpoint itself: without this, another site
// could log a signed-in user out with a simple cross-site request (e.g. an
// auto-submitting form or <img> pointed here).
require_csrf(json_input());

do_logout();
json_success([], 'Logged out successfully');
