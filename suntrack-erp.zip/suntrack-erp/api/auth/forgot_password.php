<?php
/**
 * POST /api/auth/forgot_password.php
 *
 * Emails a password reset link to a client or technician account.
 *
 * Body: email
 *
 * The reply is the same whether or not the email belongs to an account, so the
 * form cannot be used to find out who is a SunTrack customer. Limits: 3 links
 * per account and 10 per IP address per hour.
 *
 * If the server cannot send email, Management gets an in-app notification to
 * reset the password by hand, so the person is never simply stuck.
 */
require_once __DIR__ . '/../../config/config.php';
require_once ROOT_PATH . '/includes/password_reset_lib.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['email']);

$email = strtolower(trim((string)$input['email']));
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_error('Please enter a valid email address.', 422);
}

password_reset_require_schema();
$pdo = db();
$now = date('Y-m-d H:i:s');
$hourAgo = date('Y-m-d H:i:s', time() - 3600);
$ip = client_ip();

$generic = 'If that email belongs to a client or technician account, a reset link is on its way. '
    . 'It works once and expires in ' . PASSWORD_RESET_TTL_MINUTES . ' minutes. Check your spam folder too.';

$stmt = $pdo->prepare('SELECT COUNT(*) FROM password_resets WHERE requested_ip = :ip AND created_at > :t');
$stmt->execute([':ip' => $ip, ':t' => $hourAgo]);
if ((int)$stmt->fetchColumn() >= PASSWORD_RESET_MAX_PER_IP) {
    json_error('Too many reset requests from this network. Please try again in an hour.', 429);
}

$stmt = $pdo->prepare(
    "SELECT u.id, u.email, u.full_name, r.role_key,
            COALESCE(c.client_code, t.technician_code) AS code
     FROM users u
     JOIN roles r ON r.id = u.role_id
     LEFT JOIN clients c ON c.user_id = u.id
     LEFT JOIN technicians t ON t.user_id = u.id
     WHERE u.email = :e AND u.status = 'ACTIVE'"
);
$stmt->execute([':e' => $email]);
$user = $stmt->fetch();

// Unknown, inactive, or a staff account: same answer, nothing sent.
if (!$user || !in_array($user['role_key'], PASSWORD_RESET_ROLES, true)) {
    json_success([], $generic);
}

$stmt = $pdo->prepare('SELECT COUNT(*) FROM password_resets WHERE user_id = :u AND created_at > :t');
$stmt->execute([':u' => $user['id'], ':t' => $hourAgo]);
if ((int)$stmt->fetchColumn() >= PASSWORD_RESET_MAX_PER_USER) {
    // Still the generic reply: a limit message here would confirm the account exists.
    json_success([], $generic);
}

$token = bin2hex(random_bytes(32));
$pdo->beginTransaction();
// Only the newest link works — requesting again voids the older ones.
$pdo->prepare('UPDATE password_resets SET used_at = :now WHERE user_id = :u AND used_at IS NULL')
    ->execute([':now' => $now, ':u' => $user['id']]);
$pdo->prepare(
    'INSERT INTO password_resets (user_id, token_hash, expires_at, requested_ip, created_at)
     VALUES (:u, :h, :exp, :ip, :now)'
)->execute([
    ':u'   => $user['id'],
    ':h'   => hash('sha256', $token),
    ':exp' => date('Y-m-d H:i:s', time() + PASSWORD_RESET_TTL_MINUTES * 60),
    ':ip'  => $ip,
    ':now' => $now,
]);
$pdo->commit();

$base = password_reset_base_url();
$link = $base !== null ? $base . '/reset_password.php?token=' . $token : null;

$sent = false;
if ($link !== null) {
    $ttl = PASSWORD_RESET_TTL_MINUTES;
    $sent = send_mail(
        $user['email'],
        APP_NAME . ' — reset your password',
        "Hello {$user['full_name']},\n\n"
        . "Someone (hopefully you) asked to reset the password for your SunTrack account.\n\n"
        . "Open this link to choose a new password:\n$link\n\n"
        . "The link works once and expires in $ttl minutes.\n"
        . "If you did not ask for this, ignore this email — your password stays the same.\n\n"
        . "— " . APP_NAME . "\n",
        password_reset_email_html(
            'Reset your password',
            [
                "Hello {$user['full_name']},",
                'Someone (hopefully you) asked to reset the password for your SunTrack account. Tap the button to choose a new one.',
                "The link works once and expires in $ttl minutes. If you did not ask for this, ignore this email — your password stays the same.",
            ],
            $link,
            'Choose a new password'
        )
    );
} else {
    error_log('SunTrack: SUNTRACK_APP_URL is not set, so password reset links cannot be emailed.');
}

if (!$sent) {
    // The person is not left stuck: Management sees the request and can reset it.
    $who = "{$user['full_name']} ({$user['code']}, {$user['role_key']})";
    $mgmt = $pdo->query(
        "SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id
         WHERE u.status = 'ACTIVE' AND r.role_key IN ('manager', 'staff')"
    )->fetchAll(PDO::FETCH_COLUMN);
    foreach ($mgmt as $uid) {
        notify((int)$uid, 'PASSWORD_RESET',
            "$who asked to reset their password but the email could not be sent. Reset it from their Edit screen and tell them the new one.",
            'users', (int)$user['id']);
    }
}

audit_log('PASSWORD_RESET_REQUEST', 'users', $user['code'] ?? (string)$user['id']);

// On a local XAMPP there is no mail server, so development mode hands the link
// back for testing. Never in production.
$data = (APP_ENV === 'development' && $link !== null) ? ['dev_reset_link' => $link, 'email_sent' => $sent] : [];
json_success($data, $generic);
