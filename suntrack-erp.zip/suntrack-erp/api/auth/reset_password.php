<?php
/**
 * POST /api/auth/reset_password.php
 *
 * Sets a new password using an emailed reset link.
 *
 * Body: token, password, confirm_password
 *
 * The token is checked and consumed under a row lock, so a link can never be
 * used twice even if the form is submitted twice at once.
 */
require_once __DIR__ . '/../../config/config.php';
require_once ROOT_PATH . '/includes/password_reset_lib.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['token', 'password', 'confirm_password']);

$password = (string)$input['password'];
if (str_len($password) < PASSWORD_MIN_LENGTH) {
    json_error('Your new password must be at least ' . PASSWORD_MIN_LENGTH . ' characters.', 422);
}
if ($password !== (string)$input['confirm_password']) {
    json_error('The two passwords do not match.', 422);
}

password_reset_require_schema();
$pdo = db();
$now = date('Y-m-d H:i:s');

$pdo->beginTransaction();
$reset = password_reset_find(trim((string)$input['token']), true);
if (!$reset) {
    $pdo->rollBack();
    json_error('This reset link is invalid, already used, or expired. Please request a new one.', 422);
}

$pdo->prepare('UPDATE users SET password_hash = :h WHERE id = :u')
    ->execute([':h' => password_hash($password, PASSWORD_DEFAULT), ':u' => $reset['user_id']]);
// Consume this link and any other outstanding ones for the account.
$pdo->prepare('UPDATE password_resets SET used_at = :now WHERE user_id = :u AND used_at IS NULL')
    ->execute([':now' => $now, ':u' => $reset['user_id']]);
$pdo->commit();

// Lockout counts failures since the last success; proving ownership of the
// mailbox counts as one, so someone who was locked out can sign in right away.
// Marked in user_agent so the audit trail shows it was a reset, not a login.
try {
    $pdo->prepare('INSERT INTO login_attempts (email, ip_address, successful, user_agent) VALUES (:e, :ip, 1, :ua)')
        ->execute([':e' => $reset['email'], ':ip' => client_ip(), ':ua' => 'password reset']);
} catch (Throwable $e) {
    // Bookkeeping only.
}

notify((int)$reset['user_id'], 'SECURITY', 'Your password was changed using a reset link. If this was not you, contact SunTrack right away.');
audit_log('PASSWORD_RESET', 'users', (string)$reset['user_id']);

// Confirmation email — the password is already saved, so a mail failure is
// only logged; it never turns a successful reset into an error.
$when = date('F j, Y g:i A');
$ip = client_ip() ?? 'unknown';
$confirmed = send_mail(
    $reset['email'],
    APP_NAME . ' — your password was changed',
    "Hello {$reset['full_name']},\n\n"
    . "This confirms that the password for your SunTrack account was changed on $when (Philippine time) from IP address $ip.\n\n"
    . "If you made this change, no action is needed.\n"
    . "If you did NOT, request a new reset link right away and contact SunTrack.\n\n"
    . "— " . APP_NAME . "\n",
    password_reset_email_html(
        'Your password was changed',
        [
            "Hello {$reset['full_name']},",
            "This confirms that the password for your SunTrack account was changed on $when (Philippine time) from IP address $ip.",
            'If you made this change, no action is needed. If you did NOT, request a new reset link right away and contact SunTrack.',
        ]
    )
);

json_success(['confirmation_email_sent' => $confirmed], 'Your password has been changed. You can sign in now.');
