<?php
/** Returns the current session's user info — used by the frontend on page load
 *  to populate name/role in the header without re-querying every module API. */
require_once __DIR__ . '/../../config/config.php';
require_login(true);

$stmt = db()->prepare(
    'SELECT u.id, u.email, u.full_name, u.phone, u.status, u.last_login, r.role_key
     FROM users u JOIN roles r ON r.id = u.role_id
     WHERE u.id = :id'
);
$stmt->execute([':id' => current_user_id()]);
$user = $stmt->fetch();

if (!$user) {
    json_error('Session user not found.', 404);
}

$user['profile_id'] = current_profile_id();
json_success($user);
