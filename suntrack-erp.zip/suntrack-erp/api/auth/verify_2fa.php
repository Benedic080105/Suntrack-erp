<?php
/**
 * POST /api/auth/verify_2fa.php  { code }
 *
 * Second step of login for staff with two-step login on. Accepts the
 * 6-digit authenticator code or a one-time backup code. The password step
 * must have happened in this same session within the last 5 minutes; after 5
 * wrong codes the person has to enter their password again, and every wrong
 * code also counts toward the normal login lockout.
 */
require_once __DIR__ . '/../../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
$input = json_input();
require_csrf($input);
require_fields($input, ['code']);

$pending = $_SESSION['pending_2fa'] ?? null;
if (!$pending || (time() - (int)$pending['at']) > TOTP_PENDING_TTL) {
    unset($_SESSION['pending_2fa']);
    json_error('Your sign-in expired. Please enter your email and password again.', 401, ['restart' => true]);
}
login_guard_or_fail($pending['email']);

$stmt = db()->prepare(
    'SELECT u.email, u.status, r.role_key FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = :id'
);
$stmt->execute([':id' => $pending['user_id']]);
$row = $stmt->fetch();
if (!$row || $row['status'] !== 'ACTIVE') {
    unset($_SESSION['pending_2fa']);
    json_error('This account cannot sign in.', 401, ['restart' => true]);
}

if (!totp_verify_user((int)$pending['user_id'], (string)$input['code'])) {
    login_record_attempt($pending['email'], false);
    $_SESSION['pending_2fa']['tries'] = (int)$pending['tries'] + 1;
    if ($_SESSION['pending_2fa']['tries'] >= TOTP_MAX_TRIES) {
        unset($_SESSION['pending_2fa']);
        json_error('Too many wrong codes. Please sign in again.', 401, ['restart' => true]);
    }
    json_error('That code is not right. Check the app and try again.', 401,
        ['attempts_remaining' => TOTP_MAX_TRIES - $_SESSION['pending_2fa']['tries']]);
}

// Code accepted: finish the sign-in exactly as a normal login does.
$user = verify_credentials_by_id((int)$pending['user_id']);
if (!$user) {
    unset($_SESSION['pending_2fa']);
    json_error('This account cannot sign in.', 401, ['restart' => true]);
}
complete_login($user);
login_record_attempt($pending['email'], true);

json_success([
    'role'            => $user['role_key'],
    'name'            => $user['full_name'],
    'redirect'        => redirect_path_for_role($user['role_key']),
    'privacy_current' => consent_privacy_current((int)$user['id']),
], 'Login successful');
