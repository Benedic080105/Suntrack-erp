<?php
/**
 * Self-service registration. Only the 'client' role can self-register;
 * admin/staff/technician/warehouse accounts are created by an admin (see api/clients, api/technicians, api/staff).
 */
require_once __DIR__ . '/../../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['full_name', 'email', 'password', 'phone', 'address', 'city']);

$fullName = trim($input['full_name']);
$email    = trim(strtolower($input['email']));
$password = (string)$input['password'];
$phone    = trim($input['phone']);
$address  = trim($input['address']);
$city     = trim($input['city']);
$province = trim($input['province'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_error('Please enter a valid email address.', 422);
}
if (str_len($password) < PASSWORD_MIN_LENGTH) {
    json_error('Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters.', 422);
}

// The privacy policy covers location tracking and job records, so acceptance
// is a precondition for an account rather than a checkbox we note and ignore.
// Enforced server-side: a client-side checkbox is a courtesy, not a control.
if (empty($input['accept_privacy'])) {
    json_error('You must accept the Privacy Policy to create an account.', 422);
}

$pdo = db();

$check = $pdo->prepare('SELECT id FROM users WHERE email = :email');
$check->execute([':email' => $email]);
if ($check->fetch()) {
    json_error('An account with this email already exists.', 409);
}

$pdo->beginTransaction();
try {
    $roleStmt = $pdo->prepare("SELECT id FROM roles WHERE role_key = 'client'");
    $roleStmt->execute();
    $roleId = $roleStmt->fetchColumn();

    $userStmt = $pdo->prepare(
        'INSERT INTO users (role_id, email, password_hash, full_name, phone, status)
         VALUES (:role_id, :email, :hash, :full_name, :phone, :status)'
    );
    $userStmt->execute([
        ':role_id'   => $roleId,
        ':email'     => $email,
        ':hash'      => password_hash($password, PASSWORD_DEFAULT),
        ':full_name' => $fullName,
        ':phone'     => $phone,
        ':status'    => 'ACTIVE',
    ]);
    $userId = (int)$pdo->lastInsertId();

    // Next sequential CLIENT-### code, derived from the highest number in use
    // rather than a row count — deleting a client used to make the next
    // registration collide on an existing code. Retried if two people
    // register at the same moment and draw the same number.
    $clientStmt = $pdo->prepare(
        'INSERT INTO clients (user_id, client_code, address, city, province, date_registered)
         VALUES (:user_id, :code, :address, :city, :province, CURDATE())'
    );
    $clientCode = with_unique_code('clients', 'client_code', 'CLIENT-', function (string $code) use ($clientStmt, $userId, $address, $city, $province) {
        $clientStmt->execute([
            ':user_id'  => $userId,
            ':code'     => $code,
            ':address'  => $address,
            ':city'     => $city,
            ':province' => $province,
        ]);
        return $code;
    });

    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
    json_error('Registration failed. Please try again.', 500);
}

audit_log('REGISTER', 'clients', $clientCode);

// Record acceptance against the new account, with version, IP and timestamp.
consent_record($userId, 'PRIVACY', 'ACCEPTED');

json_success(['client_code' => $clientCode], 'Account created. You can now log in.');
