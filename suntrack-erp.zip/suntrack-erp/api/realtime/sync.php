<?php
/**
 * GET /api/realtime/sync.php
 *
 * The heartbeat behind every live-updating screen in SunTrack.
 *
 * Each portal polls this endpoint every few seconds and compares the returned
 * per-channel "version" against the one it last saw. When a version changes,
 * the portal reloads just that section — so a warehouse clerk issuing stock,
 * a technician timing in, or Management approving a request all surface on the
 * Admin dashboard within one poll interval, with no page refresh.
 *
 * Why fingerprints rather than a change-feed table:
 *   A change feed would mean writing a row on every mutation, which means
 *   touching all ~45 write endpoints and risking a missed call site. A
 *   fingerprint is derived from data that already exists — COUNT(*), MAX(id)
 *   and MAX(updated_at) — so a channel is correct by construction and no
 *   endpoint has to remember to announce itself.
 *
 * Cost control:
 *   - Every channel query is a single indexed aggregate.
 *   - A client only ever receives the channels its role may see, so a client
 *     portal poll never touches the inventory or audit tables at all.
 *   - `?channels=inventory,jobs` narrows it further to what the open tab needs.
 *
 * Query parameters:
 *   channels  optional, comma-separated subset of the role's channels
 *   since     optional, the previous response's `token`; when it matches the
 *             current state the response is a tiny "no changes" payload
 */
require_once __DIR__ . '/../../config/config.php';
require_login(true);

/**
 * Channel definitions.
 *
 * `table`  the table to fingerprint
 * `time`   the timestamp column that moves when a row changes; insert-only
 *          tables use created_at
 * `fallback_time`  optional column to use when `time` does not exist yet —
 *          attendance and service_requests only gained updated_at in the
 *          phase 4 migration, and an install that has not run it must keep
 *          working (with the old, less precise fingerprint) rather than
 *          reporting the channel as unavailable forever
 * `roles`  who is allowed to subscribe
 */
$CHANNELS = [
    'inventory' => [
        'table' => 'inventory', 'time' => 'updated_at',
        'roles' => ['admin', 'manager', 'staff', 'warehouse'],
    ],
    'stock_movements' => [
        'table' => 'stock_movements', 'time' => 'created_at',
        'roles' => ['admin', 'manager', 'staff', 'warehouse'],
    ],
    'jobs' => [
        'table' => 'jobs', 'time' => 'updated_at',
        'roles' => ['admin', 'manager', 'staff', 'technician', 'warehouse'],
    ],
    'projects' => [
        'table' => 'projects', 'time' => 'updated_at',
        'roles' => ['admin', 'manager', 'staff'],
    ],
    'clients' => [
        'table' => 'clients', 'time' => 'updated_at',
        'roles' => ['admin', 'manager', 'staff'],
    ],
    'technicians' => [
        'table' => 'technicians', 'time' => 'updated_at',
        'roles' => ['admin', 'manager', 'staff'],
    ],
    'staff' => [
        'table' => 'staff', 'time' => 'updated_at',
        'roles' => ['admin', 'manager'],
    ],
    'service_requests' => [
        'table' => 'service_requests', 'time' => 'updated_at', 'fallback_time' => 'date_requested',
        'roles' => ['admin', 'manager', 'staff', 'client', 'technician'],
    ],
    'attendance' => [
        'table' => 'attendance', 'time' => 'updated_at', 'fallback_time' => 'created_at',
        'roles' => ['admin', 'manager', 'staff', 'technician'],
    ],
    'geofence' => [
        'table' => 'geofence_records', 'time' => 'recorded_at',
        'roles' => ['admin', 'manager', 'staff'],
    ],
    'maintenance' => [
        'table' => 'maintenance_records', 'time' => 'updated_at',
        'roles' => ['admin', 'manager', 'staff', 'client'],
    ],
    'billing' => [
        'table' => 'invoices', 'time' => 'updated_at',
        'roles' => ['admin', 'manager', 'staff', 'client'],
    ],
    'work_reports' => [
        'table' => 'work_reports', 'time' => 'created_at',
        'roles' => ['admin', 'manager', 'staff'],
    ],
    'subcontractors' => [
        'table' => 'subcontractors', 'time' => 'updated_at',
        'roles' => ['admin', 'manager', 'staff'],
    ],
    // Phase 19. Not offered to the subcontractor role: a table-wide fingerprint
    // would hint at other companies' activity (the portal refreshes itself).
    'subcon_assignments' => [
        'table' => 'subcontractor_assignments', 'time' => 'updated_at',
        'roles' => ['admin', 'manager', 'staff'],
    ],
    // Phase 5. Reports "unavailable" on an install that has not run the migration.
    'material_requests' => [
        'table' => 'material_requests', 'time' => 'updated_at',
        'roles' => ['admin', 'manager', 'staff', 'warehouse'],
    ],
    'audit_logs' => [
        'table' => 'audit_logs', 'time' => 'created_at',
        'roles' => ['admin'],
    ],
    // Phase 13: stage submitted / approved / returned / scheduled.
    'installation_plan' => [
        'table' => 'installation_stage_plan', 'time' => 'updated_at',
        'roles' => ['admin', 'manager', 'staff', 'technician', 'client'],
    ],
];

$role   = current_role();
$userId = (int)current_user_id();
$pdo    = db();

// Which channels this role may see.
$allowed = [];
foreach ($CHANNELS as $name => $def) {
    if (in_array($role, $def['roles'], true)) {
        $allowed[$name] = $def;
    }
}

// Optional narrowing to the channels the open tab actually renders.
if (!empty($_GET['channels'])) {
    $requested = array_filter(array_map('trim', explode(',', (string)$_GET['channels'])));
    $narrowed  = [];
    foreach ($requested as $name) {
        if (isset($allowed[$name])) {
            $narrowed[$name] = $allowed[$name];
        }
    }
    if ($narrowed) {
        $allowed = $narrowed;
    }
}

/**
 * Fingerprint one table.
 *
 * COUNT(*) alone misses an in-place edit; MAX(updated_at) alone misses a
 * delete (the max can stay put while a row disappears); MAX(id) alone misses
 * both. Together the three catch insert, update and delete.
 *
 * MySQL's DATETIME has one-second resolution, so two edits inside the same
 * second could share a timestamp — but COUNT and MAX(id) still move on an
 * insert or delete, and for a same-second double-edit the next poll (seconds
 * later) picks it up. Good enough for a dashboard, and far cheaper than
 * row-level versioning.
 */
function channel_fingerprint(PDO $pdo, string $table, string $timeCol, ?string $fallbackTimeCol = null): array
{
    try {
        $sql = "SELECT COUNT(*) AS c,
                       COALESCE(MAX(id), 0) AS max_id,
                       COALESCE(UNIX_TIMESTAMP(MAX(`$timeCol`)), 0) AS max_ts
                FROM `$table`";
        $row = $pdo->query($sql)->fetch();

        return [
            'count'   => (int)$row['c'],
            'version' => $row['c'] . '-' . $row['max_id'] . '-' . $row['max_ts'],
        ];
    } catch (Throwable $e) {
        // The preferred timestamp column may not exist yet (migration not run).
        if ($fallbackTimeCol !== null) {
            return channel_fingerprint($pdo, $table, $fallbackTimeCol);
        }
        // A table that does not exist in this installation must not break the
        // whole poll — the channel simply reports as unavailable.
        return ['count' => 0, 'version' => 'unavailable'];
    }
}

$channels = [];
foreach ($allowed as $name => $def) {
    $channels[$name] = channel_fingerprint($pdo, $def['table'], $def['time'], $def['fallback_time'] ?? null);
}

// ---------------------------------------------------------------------------
// Live counters worth pushing on every poll. These are what turn a badge from
// a number you refresh into a number that just changes.
// ---------------------------------------------------------------------------
$counters = [];

// Unread notifications — every role has these, always scoped to this user.
try {
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = :u AND is_read = 0');
    $stmt->execute([':u' => $userId]);
    $counters['unread_notifications'] = (int)$stmt->fetchColumn();
} catch (Throwable $e) {
    $counters['unread_notifications'] = 0;
}

if (in_array($role, ['admin', 'manager', 'staff', 'warehouse'], true)) {
    // Stock health, the headline number on the warehouse and admin dashboards.
    try {
        $row = $pdo->query(
            "SELECT
                COUNT(*) AS total_items,
                COALESCE(SUM(quantity), 0) AS total_units,
                SUM(quantity <= 0) AS out_of_stock,
                SUM(quantity > 0 AND quantity < " . INVENTORY_LOW_STOCK_BELOW . ") AS low_stock
             FROM inventory
             WHERE status <> 'DISCONTINUED'"
        )->fetch();

        $counters['inventory'] = [
            'total_items'  => (int)$row['total_items'],
            'total_units'  => (int)$row['total_units'],
            'out_of_stock' => (int)$row['out_of_stock'],
            'low_stock'    => (int)$row['low_stock'],
        ];
    } catch (Throwable $e) {
        // Leave the counter out rather than failing the poll.
    }

    // Client orders still waiting on the warehouse — the Client Orders badge.
    try {
        $counters['open_material_requests'] = (int)$pdo->query(
            "SELECT COUNT(*) FROM material_requests WHERE status IN ('PENDING','PREPARING','READY')"
        )->fetchColumn();
    } catch (Throwable $e) {
        // Table not there yet (phase 5 not run) — no badge rather than a failed poll.
    }
}

if (in_array($role, ['admin', 'manager', 'staff'], true)) {
    try {
        $counters['pending_requests'] = (int)$pdo->query(
            "SELECT COUNT(*) FROM service_requests WHERE status = 'PENDING'"
        )->fetchColumn();

        $counters['active_jobs'] = (int)$pdo->query(
            "SELECT COUNT(*) FROM jobs
             WHERE stage IN ('EN_ROUTE','ARRIVED','IN_PROGRESS','PAUSED')"
        )->fetchColumn();

        // Technicians currently clocked in — the live "who is on site" number.
        $counters['technicians_on_site'] = (int)$pdo->query(
            'SELECT COUNT(DISTINCT technician_id) FROM attendance WHERE time_out IS NULL'
        )->fetchColumn();
    } catch (Throwable $e) {
        // Counters are best-effort.
    }
}

// A single token summarising every channel, so the client can short-circuit
// the comparison when nothing at all has moved.
$token = substr(hash('sha256', json_encode($channels) . '|' . json_encode($counters)), 0, 32);

$changed = true;
if (!empty($_GET['since']) && hash_equals($token, (string)$_GET['since'])) {
    $changed = false;
}

json_success([
    'token'         => $token,
    'changed'       => $changed,
    'channels'      => $changed ? $channels : new stdClass(),
    'counters'      => $changed ? $counters : new stdClass(),
    'role'          => $role,
    'server_time'   => date('Y-m-d H:i:s'),
    'poll_seconds'  => max(3, setting_int('realtime_poll_seconds', 10)),
], $changed ? 'State updated.' : 'No changes.');
