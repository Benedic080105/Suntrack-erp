<?php
/**
 * GET /api/sitemap/list.php
 * Site Map — READ-ONLY live geofence view for the Admin (and Management) map.
 *
 * Four layers, so the map shows the geofence as it is actually enforced:
 *
 *   clients      every plotted client pin and its geofence radius — the
 *                location new jobs inherit.
 *   jobs         open jobs (not completed/cancelled) at their site
 *                coordinates, with the radius Time In is judged against.
 *   technicians  each technician's latest location ping on a job that is
 *                currently in the field, with distance, INSIDE/OUTSIDE, how
 *                old the ping is, and a short trail of recent pings.
 *   field_without_location
 *                jobs in the field whose technician has not sent a location
 *                yet — so "nobody on the map" is not mistaken for "nobody
 *                working".
 *
 * Query parameters:
 *   search   optional — filters every layer by code / name / address / city
 */
require_once __DIR__ . '/../../middleware/admin.php';

/** Pings older than this are only kept as history, not a live position. */
const SITEMAP_LIVE_WINDOW_HOURS = 12;

/** How many recent pings to draw as each technician's trail. */
const SITEMAP_TRAIL_POINTS = 40;

$pdo = db();
$search = trim((string)($_GET['search'] ?? ''));
$term = '%' . $search . '%';

// A ping every geofence_ping_seconds is normal; several missed in a row means
// the phone locked, lost signal, or the app was closed.
$staleAfterSeconds = max(120, 3 * setting_int('geofence_ping_seconds', 20));

$fieldStages = "'EN_ROUTE','ARRIVED','IN_PROGRESS','PAUSED'";

// ---------------------------------------------------------------------------
// Clients — pins and geofences
// ---------------------------------------------------------------------------
// Every plotted client, whatever their account status — the map is a picture
// of the whole customer base. Phase 5 adds the barangay and request details
// shown in each pin's popup; without the migration those come back empty.
$srOpen = "sr.status NOT IN ('COMPLETED','CANCELLED','REJECTED')";
$clientSql = "SELECT c.id, c.client_code, u.full_name AS name, u.phone, u.email, u.status AS client_status,
                     c.address, " . (sr_phase5_ready() ? 'c.barangay' : 'NULL AS barangay') . ", c.city, c.province,
                     c.lat, c.lng, c.geofence_radius_m,
                     (SELECT COUNT(*) FROM jobs j
                      WHERE j.client_id = c.id AND j.stage NOT IN ('COMPLETED','CANCELLED')) AS open_jobs,
                     (SELECT COUNT(*) FROM service_requests sr WHERE sr.client_id = c.id) AS total_requests,
                     (SELECT COUNT(*) FROM service_requests sr WHERE sr.client_id = c.id AND $srOpen) AS open_requests,
                     (SELECT CONCAT(sr.request_code, '|', sr.status) FROM service_requests sr
                      WHERE sr.client_id = c.id AND $srOpen
                      ORDER BY FIELD(sr.priority, 'LOW', 'NORMAL', 'HIGH', 'URGENT') DESC, sr.id DESC LIMIT 1) AS top_open_request,
                     (SELECT tu.full_name FROM service_requests sr
                      JOIN technicians t ON t.id = sr.assigned_technician_id
                      JOIN users tu ON tu.id = t.user_id
                      WHERE sr.client_id = c.id AND $srOpen
                      ORDER BY sr.id DESC LIMIT 1) AS assigned_technician,
                     (SELECT MAX(sr.completion_date) FROM service_requests sr
                      WHERE sr.client_id = c.id AND sr.status = 'COMPLETED') AS last_request_completed,
                     (SELECT MAX(j.updated_at) FROM jobs j
                      WHERE j.client_id = c.id AND j.stage = 'COMPLETED') AS last_job_completed
              FROM clients c
              JOIN users u ON u.id = c.user_id
              WHERE c.lat IS NOT NULL AND c.lng IS NOT NULL";
$clientParams = [];
if ($search !== '') {
    $clientSql .= ' AND (c.client_code LIKE :s1 OR u.full_name LIKE :s2 OR c.city LIKE :s3 OR c.address LIKE :s4 OR u.phone LIKE :s5)';
    $clientParams = [':s1' => $term, ':s2' => $term, ':s3' => $term, ':s4' => $term, ':s5' => $term];
}
$clientSql .= ' ORDER BY c.client_code LIMIT 1000';
$stmt = $pdo->prepare($clientSql);
$stmt->execute($clientParams);
$clients = $stmt->fetchAll();

foreach ($clients as &$c) {
    // "Last service" = the most recent completed request or completed job.
    $dates = array_filter([$c['last_request_completed'], $c['last_job_completed']]);
    $c['last_service'] = $dates ? substr((string)max($dates), 0, 10) : null;
    unset($c['last_request_completed'], $c['last_job_completed']);
}
unset($c);

// ---------------------------------------------------------------------------
// Open jobs — the geofences Time In is actually judged against
// ---------------------------------------------------------------------------
$jobSql = "SELECT j.id, j.job_code, j.job_type, j.stage, j.site_address, j.site_lat, j.site_lng,
                  j.geofence_radius_m, j.scheduled_date, j.technician_id,
                  p.project_code, cu.full_name AS client_name, tu.full_name AS technician_name
           FROM jobs j
           JOIN clients c ON c.id = j.client_id
           JOIN users cu ON cu.id = c.user_id
           LEFT JOIN projects p ON p.id = j.project_id
           LEFT JOIN technicians t ON t.id = j.technician_id
           LEFT JOIN users tu ON tu.id = t.user_id
           WHERE j.site_lat IS NOT NULL AND j.site_lng IS NOT NULL
             AND j.stage NOT IN ('COMPLETED','CANCELLED')";
$jobParams = [];
if ($search !== '') {
    $jobSql .= ' AND (j.job_code LIKE :s1 OR j.site_address LIKE :s2 OR cu.full_name LIKE :s3
                      OR tu.full_name LIKE :s4 OR p.project_code LIKE :s5)';
    $jobParams = [':s1' => $term, ':s2' => $term, ':s3' => $term, ':s4' => $term, ':s5' => $term];
}
$jobSql .= ' ORDER BY j.updated_at DESC LIMIT 500';
$stmt = $pdo->prepare($jobSql);
$stmt->execute($jobParams);
$jobs = $stmt->fetchAll();

foreach ($jobs as &$job) {
    $job['geofence_radius_m'] = tech_geofence_radius($job);
    $job['in_field'] = in_array($job['stage'], ['EN_ROUTE', 'ARRIVED', 'IN_PROGRESS', 'PAUSED'], true);
}
unset($job);

// ---------------------------------------------------------------------------
// Technicians — latest ping per technician, on a job that is in the field
// ---------------------------------------------------------------------------
// Ages are computed by MySQL against its own NOW(): PHP runs on Asia/Manila
// while the MySQL server may be on UTC (see api/geofence/ping.php).
$techSql = "SELECT g.technician_id, g.job_id, g.lat, g.lng, g.distance_m, g.status, g.recorded_at,
                   TIMESTAMPDIFF(SECOND, g.recorded_at, NOW()) AS age_seconds,
                   j.job_code, j.job_type, j.stage, j.site_lat, j.site_lng, j.geofence_radius_m,
                   t.technician_code, tu.full_name AS technician_name, tu.phone AS technician_phone,
                   cu.full_name AS client_name,
                   (SELECT a.time_in FROM attendance a
                    WHERE a.job_id = g.job_id AND a.technician_id = g.technician_id AND a.time_out IS NULL
                    ORDER BY a.id DESC LIMIT 1) AS timed_in_at
            FROM geofence_records g
            JOIN (SELECT technician_id, MAX(id) AS max_id
                  FROM geofence_records
                  WHERE recorded_at > DATE_SUB(NOW(), INTERVAL " . SITEMAP_LIVE_WINDOW_HOURS . " HOUR)
                  GROUP BY technician_id) latest ON latest.max_id = g.id
            JOIN jobs j ON j.id = g.job_id
            JOIN technicians t ON t.id = g.technician_id
            JOIN users tu ON tu.id = t.user_id
            JOIN clients c ON c.id = j.client_id
            JOIN users cu ON cu.id = c.user_id
            WHERE j.stage IN ($fieldStages)
            ORDER BY tu.full_name";
$technicians = $pdo->query($techSql)->fetchAll();

if ($search !== '') {
    $technicians = array_values(array_filter($technicians, function ($t) use ($search) {
        foreach (['technician_name', 'technician_code', 'job_code', 'client_name'] as $f) {
            if (stripos((string)$t[$f], $search) !== false) {
                return true;
            }
        }
        return false;
    }));
}

$trailStmt = $pdo->prepare(
    'SELECT lat, lng FROM geofence_records
     WHERE job_id = :j AND technician_id = :t
     ORDER BY id DESC LIMIT ' . SITEMAP_TRAIL_POINTS
);

// Readings flagged as impossible jumps on this job (possible fake GPS).
// Guarded: databases without phase7 have no flag column.
try {
    $jumpStmt = $pdo->prepare(
        "SELECT COUNT(*) FROM geofence_records
         WHERE job_id = :j AND technician_id = :t AND flag = 'IMPOSSIBLE_JUMP'"
    );
} catch (PDOException $e) {
    $jumpStmt = null;
}

$trackedJobIds = [];
$inside = $outside = $stale = 0;
foreach ($technicians as &$t) {
    $t['geofence_radius_m'] = tech_geofence_radius($t);
    $t['age_seconds'] = (int)$t['age_seconds'];
    $t['stale'] = $t['age_seconds'] > $staleAfterSeconds;

    $t['gps_jumps'] = 0;
    if ($jumpStmt) {
        try {
            $jumpStmt->execute([':j' => $t['job_id'], ':t' => $t['technician_id']]);
            $t['gps_jumps'] = (int)$jumpStmt->fetchColumn();
        } catch (PDOException $e) {
            $jumpStmt = null;
        }
    }

    $trailStmt->execute([':j' => $t['job_id'], ':t' => $t['technician_id']]);
    $t['trail'] = array_reverse(array_map(
        fn($p) => [(float)$p['lat'], (float)$p['lng']],
        $trailStmt->fetchAll()
    ));

    $trackedJobIds[(int)$t['job_id']] = true;
    if ($t['stale']) {
        $stale++;
    } elseif ($t['status'] === 'INSIDE') {
        $inside++;
    } else {
        $outside++;
    }
}
unset($t);

// ---------------------------------------------------------------------------
// Field jobs with no live location yet
// ---------------------------------------------------------------------------
$noLocation = $pdo->query(
    "SELECT j.id, j.job_code, j.stage, tu.full_name AS technician_name, cu.full_name AS client_name,
            (SELECT a.time_in FROM attendance a
             WHERE a.job_id = j.id AND a.technician_id = j.technician_id AND a.time_out IS NULL
             ORDER BY a.id DESC LIMIT 1) AS timed_in_at
     FROM jobs j
     JOIN clients c ON c.id = j.client_id
     JOIN users cu ON cu.id = c.user_id
     LEFT JOIN technicians t ON t.id = j.technician_id
     LEFT JOIN users tu ON tu.id = t.user_id
     WHERE j.stage IN ($fieldStages)
     ORDER BY j.updated_at DESC"
)->fetchAll();
$noLocation = array_values(array_filter($noLocation, fn($j) => !isset($trackedJobIds[(int)$j['id']])));

// ---------------------------------------------------------------------------
$clientTotals = $pdo->query(
    'SELECT COUNT(*) AS total, SUM(lat IS NOT NULL AND lng IS NOT NULL) AS pinned FROM clients'
)->fetch();

json_success([
    'clients'                => $clients,
    'jobs'                   => $jobs,
    'technicians'            => $technicians,
    'field_without_location' => $noLocation,
    'stats' => [
        'clients_total'  => (int)$clientTotals['total'],
        'clients_pinned' => (int)$clientTotals['pinned'],
        'open_jobs'      => count($jobs),
        'techs_tracked'  => count($technicians),
        'inside'         => $inside,
        'outside'        => $outside,
        'stale'          => $stale,
    ],
    'stale_after_seconds' => $staleAfterSeconds,
]);
