<?php
/**
 * POST /api/consent/save.php
 *
 * Records a cookie-banner or privacy-policy decision.
 *
 * Deliberately does NOT require a login: the banner appears on the login and
 * registration pages too, and a decision made there still has to be honoured
 * and logged. When a session does exist the row is attributed to that user.
 *
 * Body:
 *   type      PRIVACY | COOKIES | TERMS
 *   decision  ACCEPTED | REJECTED | ESSENTIAL_ONLY
 */
require_once __DIR__ . '/../../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = json_input();
require_csrf($input);
require_fields($input, ['type', 'decision']);

$type     = strtoupper(trim((string)$input['type']));
$decision = strtoupper(trim((string)$input['decision']));

if (!in_array($type, ['PRIVACY', 'COOKIES', 'TERMS'], true)) {
    json_error('Unknown consent type.', 422);
}
if (!in_array($decision, ['ACCEPTED', 'REJECTED', 'ESSENTIAL_ONLY'], true)) {
    json_error('Unknown consent decision.', 422);
}

// Refusing the privacy policy is not a silent no-op: the account cannot be
// used, because field tracking and job records are the product. Say so
// plainly rather than accepting and behaving as if nothing happened.
if ($type === 'PRIVACY' && $decision === 'REJECTED' && is_logged_in()) {
    consent_record(current_user_id(), 'PRIVACY', 'REJECTED');
    do_logout();
    json_success(
        ['signed_out' => true, 'redirect' => APP_BASE_URL . '/login.php?declined=1'],
        'You have declined the privacy policy and been signed out. Contact your administrator if this was a mistake.'
    );
}

consent_record(current_user_id(), $type, $decision);

if ($type === 'COOKIES') {
    consent_set_cookie($decision === 'ACCEPTED' ? 'accepted' : 'essential');
}

json_success([
    'type'     => $type,
    'decision' => $decision,
    'version'  => privacy_policy_version(),
], 'Your preference has been saved.');
