<?php
/**
 * GET /api/confirmations/signature.php?job_id=N — the signature image, for
 * anyone allowed to see the job (its client, its technician, Management, Admin).
 */
require_once __DIR__ . '/../../config/config.php';
require_login(true);

$job = job_access_or_fail((int)($_GET['job_id'] ?? 0));
$stmt = db()->prepare('SELECT signature_file FROM job_confirmations WHERE job_id = :j');
$stmt->execute([':j' => $job['id']]);
$file = $stmt->fetchColumn();
if (!$file) {
    json_error('This job has not been signed yet.', 404);
}
storage_send('signatures', $file, 'image/png');
