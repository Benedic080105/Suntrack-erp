<?php
/**
 * POST /api/confirmations/create.php
 *
 * The client signs off a completed job: a drawn signature, their name, and an
 * optional 1–5 rating and comment. Either the client does it from their own
 * portal, or the technician hands their phone to the client on site.
 *
 * Body: job_id, signer_name, signature (data:image/png;base64,...), rating?, comment?
 * One sign-off per job (unique index); it cannot be changed afterwards.
 */
require_once __DIR__ . '/../../config/config.php';
field_mode_enter(true); // a subcontractor uses this through the field portal
require_role(['client', 'technician'], true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}
$input = json_input();
require_csrf($input);
require_fields($input, ['job_id', 'signer_name', 'signature']);

$job = job_access_or_fail((int)$input['job_id']); // client: own job; technician: own job
if ($job['stage'] !== 'COMPLETED') {
    json_error('Only a completed job can be confirmed.', 422);
}
if (job_confirmation((int)$job['id'])) {
    json_error('This job has already been confirmed.', 409);
}

$name = trim((string)$input['signer_name']);
if (str_len($name) < 2 || str_len($name) > 150) {
    json_error('Please type the name of the person signing.', 422);
}
$rating = null;
if (isset($input['rating']) && $input['rating'] !== '' && $input['rating'] !== null) {
    $rating = filter_var($input['rating'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 5]]);
    if ($rating === false) {
        json_error('Rating must be from 1 to 5 stars.', 422);
    }
}
$comment = trim((string)($input['comment'] ?? ''));
if (str_len($comment) > 500) {
    json_error('Please keep the comment under 500 characters.', 422);
}

$file = store_signature_png((string)$input['signature']);
$method = current_role() === 'client' ? 'CLIENT_PORTAL' : 'ON_SITE';

try {
    db()->prepare(
        'INSERT INTO job_confirmations (job_id, confirmed_by, method, signer_name, signature_file, rating, comment, ip_address, created_at)
         VALUES (:j, :u, :m, :n, :f, :r, :c, :ip, :t)'
    )->execute([
        ':j' => $job['id'], ':u' => current_user_id(), ':m' => $method, ':n' => $name, ':f' => $file,
        ':r' => $rating, ':c' => $comment !== '' ? $comment : null, ':ip' => client_ip(), ':t' => date('Y-m-d H:i:s'),
    ]);
} catch (PDOException $e) {
    storage_delete('signatures', $file);
    if ($e->getCode() === '23000') {
        json_error('This job has already been confirmed.', 409);
    }
    json_error('The confirmation could not be saved. Please try again.', 500);
}

audit_log('CONFIRM', 'jobs', $job['job_code']);

$stars = $rating ? ' — ' . $rating . '/5 stars' : '';
$msg = "Client signed off {$job['job_code']} ({$job['client_name']})$stars.";
$staff = db()->query(
    "SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id WHERE u.status = 'ACTIVE' AND r.role_key IN ('manager','staff')"
)->fetchAll(PDO::FETCH_COLUMN);
foreach ($staff as $uid) {
    notify((int)$uid, 'JOB_CONFIRMED', $msg, 'jobs', (int)$job['id']);
}
if ($method === 'CLIENT_PORTAL' && $job['technician_id']) {
    $t = db()->prepare('SELECT user_id FROM technicians WHERE id = :id');
    $t->execute([':id' => $job['technician_id']]);
    if ($techUser = $t->fetchColumn()) {
        notify((int)$techUser, 'JOB_CONFIRMED', "The client confirmed your job {$job['job_code']}$stars.", 'jobs', (int)$job['id']);
    }
}

json_success(['confirmation' => job_confirmation((int)$job['id'])], 'Thank you — the job is confirmed.');
