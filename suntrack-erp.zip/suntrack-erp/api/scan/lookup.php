<?php
/**
 * QR / Code Scanner — lookup endpoint.
 * Given a scanned or manually-entered code, checks it against every
 * entity code format used in the system (job, inventory SKU, client,
 * technician, staff, project, sub-contractor) and returns the first
 * match with a small detail payload. Every successful match is written
 * to audit_logs so scans are traceable.
 */
require_once __DIR__ . '/../../config/config.php';

$__is_api = true;
require_role(['admin', 'manager', 'staff', 'warehouse'], $__is_api); // Warehouse staff scan from the warehouse portal on their phones.

$pdo = db();
$code = trim($_GET['code'] ?? '');

if ($code === '') {
    json_error('No code provided.', 422);
}

$result = null;

// Job code, e.g. JOB-2026-1001
$stmt = $pdo->prepare(
    "SELECT j.job_code AS code, j.job_type, j.stage, j.site_address, j.scheduled_date,
            u.full_name AS client_name, tu.full_name AS technician_name, p.project_code
     FROM jobs j
     JOIN clients c ON c.id = j.client_id
     JOIN users u ON u.id = c.user_id
     LEFT JOIN technicians t ON t.id = j.technician_id
     LEFT JOIN users tu ON tu.id = t.user_id
     LEFT JOIN projects p ON p.id = j.project_id
     WHERE j.job_code = :code"
);
$stmt->execute([':code' => $code]);
if ($row = $stmt->fetch()) {
    $result = ['type' => 'Job', 'module' => 'jobs', 'record_id' => $row['code'], 'fields' => [
        'Job Code' => $row['code'], 'Type' => $row['job_type'], 'Stage' => $row['stage'],
        'Client' => $row['client_name'], 'Technician' => $row['technician_name'] ?? 'Unassigned',
        'Project' => $row['project_code'] ?? '—', 'Site Address' => $row['site_address'] ?? '—',
        'Scheduled' => $row['scheduled_date'] ?? '—',
    ]];
}

// Material request (client order) code, e.g. MR-2026-0001 — printed on the
// pick slip so scanning it opens the order in Prepare mode.
if (!$result && str_starts_with($code, 'MR-')) {
    try {
        $stmt = $pdo->prepare(
            "SELECT mr.id, mr.request_code AS code, mr.status, mr.needed_by, c.client_code, u.full_name AS client_name,
                    p.project_code
             FROM material_requests mr
             JOIN clients c ON c.id = mr.client_id
             JOIN users u ON u.id = c.user_id
             LEFT JOIN projects p ON p.id = mr.project_id
             WHERE mr.request_code = :code"
        );
        $stmt->execute([':code' => $code]);
        if ($row = $stmt->fetch()) {
            $result = ['type' => 'Client Order', 'module' => 'material_requests', 'record_id' => $row['code'],
                'id' => (int)$row['id'], 'fields' => [
                'Order' => $row['code'], 'Client' => $row['client_name'] . ' (' . $row['client_code'] . ')',
                'Project' => $row['project_code'] ?? '—', 'Status' => $row['status'],
                'Needed By' => $row['needed_by'] ?? '—',
            ]];
        }
    } catch (PDOException $e) {
        // Phase 5 not migrated yet — fall through to the other code types.
    }
}

// Inventory: a unit label (UNIT-9007-0001), a unit's manufacturer serial,
// or a product SKU / QR identifier (ST-INV-9923, QR-ST-INV-9923).
if (!$result && ($hit = inv_resolve_code($pdo, $code))) {
    $row = $hit['item'];
    $unit = $hit['unit'];
    $tracking = $row['tracking_mode'] ?? 'PRODUCT';
    $brandModel = trim(($row['brand'] ?? '') . ' ' . ($row['model'] ?? '')) ?: '—';
    $statusLabel = ucwords(strtolower(str_replace('_', ' ', $row['status'])));
    // `id` lets the scanner act on the item without a second lookup call.
    $base = ['module' => 'inventory', 'id' => (int)$row['id'], 'name' => $row['item_name'],
             'category' => $row['category_name'], 'sku' => $row['sku'], 'tracking' => $tracking,
             'quantity' => (int)$row['quantity'], 'quarantine_qty' => (int)($row['quarantine_qty'] ?? 0),
             'item_status' => $row['status'], 'can_write' => inv_can_write()];

    if ($unit) {
        $where = '—';
        if ($unit['job_id']) {
            $j = $pdo->prepare('SELECT job_code FROM jobs WHERE id = :id');
            $j->execute([':id' => $unit['job_id']]);
            $where = 'On ' . ($j->fetchColumn() ?: 'a job');
        } elseif ($unit['material_request_id']) {
            $m = $pdo->prepare('SELECT request_code FROM material_requests WHERE id = :id');
            $m->execute([':id' => $unit['material_request_id']]);
            $where = 'On ' . ($m->fetchColumn() ?: 'a client order');
        }
        $unitStatus = ['IN_STOCK' => 'In stock', 'ISSUED' => 'Issued', 'QUARANTINE' => 'Quarantine', 'WRITTEN_OFF' => 'Written off'][$unit['status']];
        $result = $base + ['type' => 'Equipment Unit', 'record_id' => $unit['unit_code'],
            'unit' => ['id' => (int)$unit['id'], 'code' => $unit['unit_code'], 'serial' => $unit['serial_number'],
                       'status' => $unit['status'], 'condition' => $unit['item_condition']],
            'fields' => [
                'Unit' => $unit['unit_code'], 'Serial No.' => $unit['serial_number'], 'Item' => $row['item_name'],
                'SKU' => $row['sku'], 'Category' => $row['category_name'], 'Brand / Model' => $brandModel,
                'Unit Status' => $unitStatus, 'Condition' => INV_CONDITION_LABELS[$unit['item_condition']] ?? $unit['item_condition'],
                'Location' => $unit['status'] === 'IN_STOCK' || $unit['status'] === 'QUARANTINE'
                    ? ($unit['warehouse_location'] ?: ($row['warehouse_location'] ?: '—')) : $where,
            ]];
    } else {
        $fields = [
            'SKU' => $row['sku'], 'Item' => $row['item_name'], 'Category' => $row['category_name'],
            'Brand / Model' => $brandModel,
            'Tracking' => $tracking === 'SERIAL' ? 'Each unit has its own QR' : 'One QR for the product',
            'Available' => (int)$row['quantity'],
        ];
        if ((int)($row['quarantine_qty'] ?? 0) > 0) {
            $fields['In Quarantine'] = (int)$row['quarantine_qty'] . ' (not available)';
        }
        if (!empty($row['serial_number'])) {
            $fields['Lot / Serial'] = $row['serial_number'];
        }
        $fields['Location'] = $row['warehouse_location'] ?: '—';
        $fields['Status'] = $statusLabel;
        $result = $base + ['type' => 'Inventory Item', 'record_id' => $row['sku'], 'fields' => $fields];
    }
}

// Client code, e.g. CLIENT-001
if (!$result) {
    $stmt = $pdo->prepare(
        "SELECT c.client_code AS code, u.full_name, u.email, u.phone, u.status, c.city, c.province
         FROM clients c JOIN users u ON u.id = c.user_id WHERE c.client_code = :code"
    );
    $stmt->execute([':code' => $code]);
    if ($row = $stmt->fetch()) {
        $result = ['type' => 'Client', 'module' => 'clients', 'record_id' => $row['code'], 'fields' => [
            'Code' => $row['code'], 'Name' => $row['full_name'], 'Email' => $row['email'],
            'Phone' => $row['phone'] ?? '—', 'Location' => trim(($row['city'] ?? '') . ' ' . ($row['province'] ?? '')) ?: '—',
            'Status' => $row['status'],
        ]];
    }
}

// Technician code, e.g. TECH-01
if (!$result) {
    $stmt = $pdo->prepare(
        "SELECT t.technician_code AS code, u.full_name, u.email, u.phone, t.specialization, ta.status AS availability
         FROM technicians t JOIN users u ON u.id = t.user_id
         LEFT JOIN technician_availability ta ON ta.technician_id = t.id
         WHERE t.technician_code = :code"
    );
    $stmt->execute([':code' => $code]);
    if ($row = $stmt->fetch()) {
        $result = ['type' => 'Technician', 'module' => 'technicians', 'record_id' => $row['code'], 'fields' => [
            'Code' => $row['code'], 'Name' => $row['full_name'], 'Specialization' => $row['specialization'] ?? '—',
            'Availability' => $row['availability'] ?? '—', 'Phone' => $row['phone'] ?? '—',
        ]];
    }
}

// Staff code, e.g. STF-101
if (!$result) {
    $stmt = $pdo->prepare(
        "SELECT s.staff_code AS code, u.full_name, u.email, s.department, s.position, s.status
         FROM staff s JOIN users u ON u.id = s.user_id WHERE s.staff_code = :code"
    );
    $stmt->execute([':code' => $code]);
    if ($row = $stmt->fetch()) {
        $result = ['type' => 'Staff', 'module' => 'staff', 'record_id' => $row['code'], 'fields' => [
            'Code' => $row['code'], 'Name' => $row['full_name'], 'Department' => $row['department'] ?? '—',
            'Position' => $row['position'] ?? '—', 'Status' => $row['status'],
        ]];
    }
}

// Project code, e.g. SITE-801
if (!$result) {
    $stmt = $pdo->prepare(
        "SELECT p.project_code AS code, p.site_name, p.status, p.progress, p.capacity_kw, u.full_name AS client_name
         FROM projects p JOIN clients c ON c.id = p.client_id JOIN users u ON u.id = c.user_id
         WHERE p.project_code = :code"
    );
    $stmt->execute([':code' => $code]);
    if ($row = $stmt->fetch()) {
        $result = ['type' => 'Project', 'module' => 'projects', 'record_id' => $row['code'], 'fields' => [
            'Code' => $row['code'], 'Site' => $row['site_name'], 'Client' => $row['client_name'],
            'Status' => $row['status'], 'Progress' => $row['progress'] . '%',
            'Capacity' => $row['capacity_kw'] ? $row['capacity_kw'] . ' kW' : '—',
        ]];
    }
}

// Sub-contractor code, e.g. SC-01
if (!$result) {
    $stmt = $pdo->prepare(
        "SELECT subcon_code AS code, name, specialization, area, phone, approved
         FROM subcontractors WHERE subcon_code = :code"
    );
    $stmt->execute([':code' => $code]);
    if ($row = $stmt->fetch()) {
        $result = ['type' => 'Sub-Contractor', 'module' => 'subcontractors', 'record_id' => $row['code'], 'fields' => [
            'Code' => $row['code'], 'Name' => $row['name'], 'Specialization' => $row['specialization'] ?? '—',
            'Area' => $row['area'] ?? '—', 'Phone' => $row['phone'] ?? '—',
            'Approved' => $row['approved'] ? 'Yes' : 'Pending',
        ]];
    }
}

if (!$result) {
    json_success(['found' => false, 'code' => mb_substr($code, 0, 100)],
        'This code is not registered in SunTrack. Check the label, or type the SKU (e.g. ST-INV-9001) instead.');
}

audit_log('SCAN', $result['module'], $result['record_id']);

json_success([
    'found' => true,
    'code' => $code,
    'result' => $result,
    'scanned_by' => $_SESSION['full_name'] ?? 'Unknown user',
    'scanned_at' => date('Y-m-d H:i:s'),
]);
