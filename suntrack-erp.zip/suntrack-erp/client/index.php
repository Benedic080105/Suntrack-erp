<?php
require_once __DIR__ . '/../middleware/client.php';
require_once __DIR__ . '/../includes/dark_sidebar.php';

$navItems = [
    ['key' => 'dashboard', 'label' => 'Dashboard', 'icon' => 'fa-gauge-high', 'wired' => true],
    ['key' => 'solar-system', 'label' => 'My Solar System', 'icon' => 'fa-solar-panel', 'wired' => true],
    ['key' => 'installation', 'label' => 'Installation', 'icon' => 'fa-screwdriver-wrench', 'wired' => true],
    ['key' => 'service-requests', 'label' => 'Service Requests', 'icon' => 'fa-ticket', 'wired' => true],
    ['key' => 'maintenance', 'label' => 'Maintenance', 'icon' => 'fa-wrench', 'wired' => true],
    ['key' => 'service-history', 'label' => 'Service History', 'icon' => 'fa-clock-rotate-left', 'wired' => true],
    ['key' => 'settings', 'label' => 'Settings', 'icon' => 'fa-gear', 'wired' => true],
];
$token = csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>SunTrack ERP — Client Portal</title>
<script src="<?= APP_BASE_URL ?>/assets/vendor/tailwind/tailwind.js"></script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/vendor/fontawesome/css/all.min.css">
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-password.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-logout.js"></script>
<link href="<?= APP_BASE_URL ?>/assets/vendor/inter/inter.css" rel="stylesheet">
<link rel="manifest" href="<?= APP_BASE_URL ?>/manifest.json">
<meta name="theme-color" content="#0b1329">
<link rel="apple-touch-icon" href="<?= APP_BASE_URL ?>/assets/img/app/apple-touch-icon.png">
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/vendor/leaflet/leaflet.min.css">
<script src="<?= APP_BASE_URL ?>/assets/vendor/leaflet/leaflet.min.js"></script>
<script>tailwind.config={theme:{extend:{colors:{suntrackDark:'#0b1329',suntrackNav:'#0f1934',suntrackOrange:'#f97316'},fontFamily:{sans:['Inter','sans-serif']}}}}</script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/css/suntrack-mobile.css">
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-mobile.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-tables.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-realtime.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-paging.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-pwa.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-signature.js"></script>
<style>body{font-family:'Inter',sans-serif;}
  .kpi-card{background:#fff;border-radius:1rem;padding:1.25rem;box-shadow:0 1px 3px rgba(0,0,0,.06);border:1px solid #eef0f4}
  .badge{font-size:11px;font-weight:700;padding:2px 8px;border-radius:999px}
  input,select,textarea{outline:none}
  .chart-box{position:relative;height:260px}
</style>
</head>
<body class="st-portal bg-slate-50 min-h-screen flex flex-col md:flex-row">

<?php render_dark_sidebar($navItems, 'dashboard', 'Client Portal'); ?>

<main class="flex-1 min-w-0 p-4 sm:p-6 md:p-8">
  <header class="st-page-head flex items-center justify-between mb-6">
    <div>
      <h1 id="page-title" class="text-2xl md:text-3xl font-extrabold text-slate-900">Welcome back, <?= h($_SESSION['full_name']) ?></h1>
      <p id="page-sub" class="text-slate-500 text-sm mt-1">Here's the latest on your solar system.</p>
    </div>
  </header>

  <!-- DASHBOARD -->
  <section id="tab-dashboard" class="tab-panel">
    <div id="dash-loading" class="text-slate-400 text-sm">Loading your dashboard...</div>
    <div id="dash-content" class="hidden space-y-6">
      <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div class="kpi-card"><p class="text-xs font-semibold text-slate-500 uppercase">System Status</p><p id="kpi-status" class="text-2xl font-extrabold text-slate-900 mt-2">—</p><p id="kpi-status-sub" class="text-xs text-slate-500 mt-1"></p></div>
        <div class="kpi-card"><p class="text-xs font-semibold text-slate-500 uppercase">Installation Age</p><p id="kpi-age" class="text-2xl font-extrabold text-slate-900 mt-2">—</p><p id="kpi-age-sub" class="text-xs text-slate-500 mt-1"></p></div>
        <div class="kpi-card"><p class="text-xs font-semibold text-slate-500 uppercase">Active Requests</p><p id="kpi-requests" class="text-2xl font-extrabold text-slate-900 mt-2">—</p></div>
        <div class="kpi-card"><p class="text-xs font-semibold text-slate-500 uppercase">Capacity</p><p id="kpi-capacity" class="text-2xl font-extrabold text-slate-900 mt-2">—</p></div>
      </div>
      <div class="grid md:grid-cols-2 gap-6">
        <div class="kpi-card"><h3 class="font-bold text-slate-900 mb-3">Solar System Details</h3><div id="system-details" class="text-sm text-slate-600"></div></div>
        <div class="kpi-card"><h3 class="font-bold text-slate-900 mb-3">Recent History</h3><div id="recent-history" class="text-sm text-slate-600 space-y-2"></div></div>
      </div>
      <div class="kpi-card"><h3 class="font-bold text-slate-900 mb-3">Notifications</h3><div id="notifications" class="text-sm text-slate-600 space-y-2"></div></div>
      <div class="kpi-card"><h3 class="font-bold text-slate-900 mb-3"><i class="fas fa-file-invoice text-suntrackOrange mr-1"></i> My Invoices</h3>
        <div id="my-invoices" class="text-sm text-slate-600 divide-y divide-slate-100"><p class="text-slate-400 py-2">Loading...</p></div></div>
    </div>
  </section>

  <!-- SERVICE REQUESTS -->
  <section id="tab-service-requests" class="tab-panel hidden">
    <div class="grid md:grid-cols-3 gap-6">
      <div class="kpi-card md:col-span-1 h-fit">
        <h3 class="font-bold text-slate-900 mb-3">New Service Request</h3>
        <div id="sr-error" class="hidden bg-red-50 border border-red-200 text-red-600 text-xs rounded-lg px-3 py-2 mb-3"></div>
        <div id="sr-ok" class="hidden bg-emerald-50 border border-emerald-200 text-emerald-600 text-xs rounded-lg px-3 py-2 mb-3"></div>
        <form id="sr-form" class="space-y-3">
          <div>
            <label class="block text-xs font-semibold text-slate-500 mb-1">Service Type</label>
            <select id="sr-type" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2">
              <?php foreach (sr_service_types() as $st): ?><option><?= h($st) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-500 mb-1">Subject</label>
            <input id="sr-subject" type="text" maxlength="150" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2" placeholder="e.g. Inverter shows a red light">
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-500 mb-1">Priority</label>
            <select id="sr-priority" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2">
              <option value="NORMAL">Normal</option>
              <option value="LOW">Low</option>
              <option value="HIGH">High</option>
              <option value="URGENT">Urgent</option>
            </select>
          </div>
          <div>
            <label class="block text-xs font-semibold text-slate-500 mb-1">Description</label>
            <textarea id="sr-desc" rows="4" maxlength="5000" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2" placeholder="Describe the issue: what you noticed, since when, anything you already tried..."></textarea>
          </div>
          <button type="submit" class="w-full bg-suntrackOrange hover:bg-orange-600 text-white font-bold text-sm py-2.5 rounded-lg">Submit Request</button>
          <p class="text-[11px] text-slate-400">Our team reviews every request and assigns a technician. You'll see each update here.</p>
        </form>
      </div>
      <div class="kpi-card md:col-span-2">
        <div class="flex items-center justify-between gap-3 mb-3 flex-wrap">
          <h3 class="font-bold text-slate-900">My Requests</h3>
          <select id="sr-filter" class="rounded-lg border border-slate-200 text-xs px-2 py-1.5">
            <option value="">All requests</option><option value="open">Open only</option>
          </select>
        </div>
        <div id="sr-list" class="divide-y divide-slate-100 text-sm"></div>
      </div>
    </div>
  </section>

  <!-- INSTALLATION -->
  <section id="tab-installation" class="tab-panel hidden">
    <div id="install-loading" class="kpi-card text-slate-400 text-sm py-4">Loading...</div>
    <!-- The same checklist the technician works through, read-only, with their proof photos. -->
    <div id="install-content" class="hidden"></div>
    <div id="install-empty" class="kpi-card hidden text-slate-400 text-sm py-4 text-center">No installation checklist found for your account yet.</div>
  </section>

  <!-- MY SOLAR SYSTEM (+ site geomapping) -->
  <section id="tab-solar-system" class="tab-panel hidden">
    <div id="sys-loading" class="text-slate-400 text-sm mb-4">Loading your system...</div>
    <div id="sys-content" class="hidden space-y-6">
      <div id="sys-cards" class="grid md:grid-cols-2 gap-4"></div>
      <div class="kpi-card" style="padding:0;overflow:hidden">
        <div class="p-4 pb-0"><h3 class="font-bold text-slate-900 text-sm">Site Location</h3></div>
        <div id="sys-map" style="height:360px;width:100%" class="mt-3"></div>
        <p id="sys-map-empty" class="hidden text-slate-400 text-sm py-8 text-center">Your site's exact location will appear here automatically once a technician's visit is geofenced on-site.</p>
      </div>
    </div>
    <div id="sys-empty" class="hidden kpi-card text-slate-400 text-sm py-6 text-center">No solar system on record yet.</div>
  </section>

  <!-- MAINTENANCE (monitoring) -->
  <section id="tab-maintenance" class="tab-panel hidden">
    <div class="kpi-card overflow-x-auto">
      <h3 class="font-bold text-slate-900 mb-3">Maintenance Schedule</h3>
      <table class="w-full text-sm data-table">
        <thead><tr class="text-left text-xs uppercase text-slate-400"><th class="pb-2">Site</th><th class="pb-2">Last Maintenance</th><th class="pb-2">Next Maintenance</th><th class="pb-2">Status</th><th class="pb-2">Notified</th></tr></thead>
        <tbody id="maint-table-body" class="divide-y divide-slate-100"></tbody>
      </table>
      <p id="maint-empty" class="hidden text-slate-400 text-sm py-6 text-center">No maintenance schedule on record yet.</p>
    </div>
  </section>

  <!-- SERVICE HISTORY (monitoring) -->
  <section id="tab-service-history" class="tab-panel hidden">
    <div class="grid md:grid-cols-2 gap-6">
      <div class="kpi-card">
        <h3 class="font-bold text-slate-900 mb-3">Job History</h3>
        <div id="hist-jobs" class="divide-y divide-slate-100 text-sm"></div>
        <p id="hist-jobs-empty" class="hidden text-slate-400 text-sm py-6 text-center">No job history yet.</p>
      </div>
      <div class="kpi-card">
        <h3 class="font-bold text-slate-900 mb-3">Technician Work Reports</h3>
        <div id="hist-reports" class="divide-y divide-slate-100 text-sm"></div>
        <p id="hist-reports-empty" class="hidden text-slate-400 text-sm py-6 text-center">No work reports filed yet.</p>
      </div>
    </div>
  </section>

  <!-- SETTINGS (own account, via api/account/profile.php) -->
  <section id="tab-settings" class="tab-panel hidden">
    <div class="grid md:grid-cols-2 gap-6">
      <div class="kpi-card">
        <h3 class="font-bold text-slate-900 mb-1">My Profile</h3>
        <p class="text-xs text-slate-400 mb-4">Your own account details. Only you can change these.</p>
        <div id="pf-msg" class="hidden text-xs rounded-lg px-3 py-2 mb-3"></div>
        <div class="space-y-3">
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Full Name</label>
            <input id="pf-name" type="text" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Email</label>
            <input id="pf-email" type="email" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Phone</label>
            <input id="pf-phone" type="tel" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
          <button id="pf-save" class="w-full rounded-lg bg-suntrackOrange hover:bg-orange-600 text-white text-sm font-bold px-4 py-2.5">Save Changes</button>
        </div>
      </div>
      <div class="kpi-card">
        <h3 class="font-bold text-slate-900 mb-1">Change Password</h3>
        <p class="text-xs text-slate-400 mb-4">You will stay signed in on this device.</p>
        <div id="pw-msg" class="hidden text-xs rounded-lg px-3 py-2 mb-3"></div>
        <div class="space-y-3">
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Current Password</label>
            <input id="pw-current" type="password" autocomplete="current-password" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">New Password</label>
            <input id="pw-new" type="password" autocomplete="new-password" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2">
            <p class="text-[11px] text-slate-400 mt-1">At least 8 characters.</p></div>
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Confirm New Password</label>
            <input id="pw-confirm" type="password" autocomplete="new-password" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
          <button id="pw-save" class="w-full rounded-lg bg-slate-800 hover:bg-slate-900 text-white text-sm font-bold px-4 py-2.5">Update Password</button>
        </div>
      </div>
    </div>
    <!-- My site location: saved from the client's phone while standing at the site. -->
    <div class="kpi-card mt-6">
      <div class="flex flex-wrap items-start justify-between gap-3">
        <div class="min-w-0">
          <h3 class="font-bold text-slate-900"><i class="fas fa-location-dot text-suntrackOrange mr-1"></i>My site location</h3>
          <p class="text-xs text-slate-400 mt-0.5">Stand at your installation site, then tap the button. Our technicians use this pin to find you and to check in on site.</p>
        </div>
        <span id="loc-status" class="badge bg-slate-100 text-slate-500">Loading…</span>
      </div>
      <div id="loc-map" class="w-full h-56 rounded-xl border border-slate-200 mt-4 z-0"></div>
      <p id="loc-coords" class="text-[11px] text-slate-400 mt-2"></p>
      <div id="loc-msg" class="hidden text-xs rounded-lg px-3 py-2 mt-3"></div>
      <button id="loc-save" type="button" class="w-full mt-3 rounded-lg bg-suntrackOrange hover:bg-orange-600 disabled:opacity-60 text-white text-sm font-bold px-4 py-2.5">
        <i class="fas fa-crosshairs mr-1"></i>Use my current location</button>
      <p class="text-[11px] text-slate-400 mt-2 text-center">Your phone will ask permission to share its location. It is only read when you tap the button.</p>
    </div>
    <div class="kpi-card mt-6" data-push-card></div>
    <div class="kpi-card mt-6">
      <a href="<?= APP_BASE_URL ?>/privacy.php" target="_blank" rel="noopener" class="text-xs font-semibold text-suntrackOrange hover:underline">
        <i class="fas fa-shield-halved mr-1"></i> Privacy Policy &amp; Cookie Notice
      </a>
    </div>
  </section>

  <section id="tab-fallback" class="tab-panel hidden">
    <div class="kpi-card text-slate-500 text-sm">This module's API + full UI wiring lands in the next build phase. The tab and navigation are already in place.</div>
  </section>
</main>

<script>
const CSRF_TOKEN = <?= json_encode($token) ?>;
const WIRED_TABS = ['dashboard','service-requests','installation','solar-system','maintenance','service-history','settings'];

// Escape text before it goes into innerHTML — descriptions, names and remarks
// are typed by people, and unescaped they would run as HTML/script.
function esc(v) {
  if (v === null || v === undefined) return '';
  return String(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

let CURRENT_TAB = 'dashboard';
const TAB_TEXT = {
  dashboard: [<?= json_encode('Welcome back, ' . ($_SESSION['full_name'] ?? '')) ?>, "Here's the latest on your solar system."],
  'solar-system': ['My Solar System', 'Your installed system, its equipment and where it is.'],
  installation: ['Installation', 'Each stage of your installation, with photos as the work is done.'],
  'service-requests': ['Service Requests', 'Ask for help and follow every update.'],
  maintenance: ['Maintenance', 'When your system was last serviced and when it is due next.'],
  'service-history': ['Service History', 'Past jobs, work reports and sign-offs.'],
  settings: ['Settings', 'Your account, password, site location and phone alerts.'],
};
document.querySelectorAll('.tab-link').forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    document.querySelectorAll('.tab-link').forEach(l => l.classList.remove('bg-suntrackOrange','text-white','shadow-md','shadow-orange-600/20'));
    link.classList.add('bg-suntrackOrange','text-white','shadow-md','shadow-orange-600/20');
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.add('hidden'));
    const key = link.dataset.tab;
    CURRENT_TAB = key;
    // Each tab names itself in the header (the welcome is for the dashboard).
    const head = TAB_TEXT[key] || TAB_TEXT.dashboard;
    document.getElementById('page-title').textContent = head[0];
    document.getElementById('page-sub').textContent = head[1];
    window.scrollTo(0, 0);
    if (WIRED_TABS.includes(key)) {
      document.getElementById('tab-' + key).classList.remove('hidden');
      if (key === 'service-requests') loadServiceRequests();
      if (key === 'installation') loadInstallation();
      if (key === 'solar-system') loadMySystem();
      if (key === 'maintenance') loadMaintenance();
      if (key === 'service-history') loadServiceHistory();
      if (key === 'settings') { loadProfile(); loadMyLocation(); }
    } else {
      document.getElementById('tab-fallback').classList.remove('hidden');
    }
  });
});

function fmtSysDate(ymd) {
  const d = new Date(String(ymd).slice(0, 10) + 'T00:00');
  return isNaN(d) ? String(ymd) : d.toLocaleDateString('en-PH', { year: 'numeric', month: 'short', day: 'numeric' });
}
// One equipment row: icon + label, then each item installed (name on its own
// line, SKU · model beneath, quantity on the right). Falls back to the text on
// file when the warehouse recorded nothing for that part.
function equipmentHtml(label, icon, eq) {
  const items = (eq && eq.items) || [];
  const body = items.length
    ? items.map(i => `
        <div class="flex items-start justify-between gap-3">
          <div class="min-w-0">
            <p class="font-semibold text-slate-800 leading-snug">${esc(i.item_name)}</p>
            <p class="text-xs text-slate-400 mt-0.5 break-words">${esc(i.sku)}${i.model ? ' · ' + esc(i.model) : ''}</p>
          </div>
          <span class="shrink-0 text-xs font-bold text-slate-600 bg-slate-100 rounded-full px-2 py-0.5">× ${Number(i.quantity)}</span>
        </div>`).join('<div class="h-2"></div>')
    : `<p class="${eq && eq.text ? 'font-semibold text-slate-800' : 'text-slate-400'} leading-snug">${esc(eq && eq.text ? eq.text : 'None installed')}</p>`;
  return `
    <div class="flex items-start gap-3 py-2.5">
      <span class="w-8 h-8 shrink-0 rounded-lg bg-orange-50 text-suntrackOrange flex items-center justify-center"><i class="fas ${icon} text-sm"></i></span>
      <div class="flex-1 min-w-0">
        <p class="text-[11px] font-semibold uppercase tracking-wide text-slate-400 mb-0.5">${label}</p>
        ${body}
      </div>
    </div>`;
}
// opts.showCode: include the system code (the dashboard card has no header for it)
// opts.warranty: add the warranty row (the My Solar System card)
function systemDetailsHtml(s, sum, opts = {}) {
  const row = (label, value) => `<dt class="text-slate-400">${label}</dt><dd class="text-slate-700 min-w-0 break-words">${value}</dd>`;
  const installed = sum.installed_on ? fmtSysDate(sum.installed_on)
    : (sum.planned_for ? 'Planned for ' + fmtSysDate(sum.planned_for) : 'Pending');
  return `
    ${opts.showCode ? `
      <div class="flex items-center justify-between gap-3 pb-3 mb-1 border-b border-slate-100">
        <span class="font-bold text-slate-800">${esc(s.system_code)}</span>
        ${s.capacity_kw ? `<span class="text-xs font-bold text-slate-600 bg-slate-100 rounded-full px-2.5 py-1">${esc(s.capacity_kw)} kW</span>` : ''}
      </div>` : ''}
    <div class="divide-y divide-slate-100">
      ${equipmentHtml('Panel', 'fa-solar-panel', sum.equipment.panel_brand)}
      ${equipmentHtml('Inverter', 'fa-bolt', sum.equipment.inverter_brand)}
      ${equipmentHtml('Battery', 'fa-car-battery', sum.equipment.battery_brand)}
    </div>
    <dl class="grid grid-cols-[5.5rem_1fr] gap-x-3 gap-y-2 pt-3 mt-1 border-t border-slate-100">
      ${row('Installed', installed)}
      ${row('Address', esc(s.installation_address ?? '—'))}
      ${opts.warranty ? row('Warranty', esc(s.warranty_info ?? '—')) : ''}
    </dl>`;
}

async function loadDashboard() {
  try {
    const res = await fetch('../api/dashboard/client.php');
    const json = await res.json();
    if (!json.success) { document.getElementById('dash-loading').textContent = json.message; return; }
    const d = json.data;
    const sum = d.system_summary;
    document.getElementById('kpi-status').textContent = d.system ? sum.status_label : 'No System Yet';
    document.getElementById('kpi-status-sub').textContent = d.system ? sum.status_detail : '';
    document.getElementById('kpi-age').textContent = d.system && sum.age_label ? sum.age_label : (d.system && sum.planned_for ? 'Not installed yet' : '—');
    document.getElementById('kpi-age-sub').textContent = !d.system ? ''
      : sum.installed_on ? 'Installed ' + fmtSysDate(sum.installed_on) + ' · ' + Number(sum.age_days).toLocaleString('en-PH') + ' day' + (sum.age_days === 1 ? '' : 's')
      : sum.planned_for ? 'Planned for ' + fmtSysDate(sum.planned_for) : '';
    document.getElementById('kpi-requests').textContent = d.active_service_requests;
    document.getElementById('kpi-capacity').textContent = d.system && d.system.capacity_kw ? d.system.capacity_kw + ' kW' : '—';

    const sysBox = document.getElementById('system-details');
    sysBox.innerHTML = d.system ? systemDetailsHtml(d.system, sum, { showCode: true })
      : '<p class="text-slate-400">No solar system on record yet.</p>';

    document.getElementById('recent-history').innerHTML = d.recent_history.length
      ? d.recent_history.map(j => `<div class="flex items-start justify-between gap-3"><div class="min-w-0"><p class="font-semibold text-slate-800">${esc(j.job_code)}</p><p class="text-xs text-slate-500">${esc(j.job_type)}</p></div><span class="text-xs font-bold text-suntrackOrange shrink-0 pt-0.5">${esc(j.stage)}</span></div>`).join('')
      : '<p class="text-slate-400">No job history yet.</p>';

    document.getElementById('notifications').innerHTML = d.notifications.length
      ? d.notifications.map(n => `<p>${esc(n.message)}</p>`).join('')
      : '<p class="text-slate-400">No notifications.</p>';

    document.getElementById('dash-loading').classList.add('hidden');
    document.getElementById('dash-content').classList.remove('hidden');
    loadMyInvoices();
  } catch (err) {
    document.getElementById('dash-loading').textContent = 'Failed to load dashboard.';
  }
}

// The client's own invoices, each opening the printable / PDF version.
async function loadMyInvoices() {
  const box = document.getElementById('my-invoices');
  try {
    const json = await (await fetch('../api/client/invoices.php')).json();
    if (!json.success) { box.innerHTML = `<p class="text-red-500 py-2">${esc(json.message)}</p>`; return; }
    const peso = (n) => '₱' + Number(n).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const color = { PAID: 'bg-emerald-100 text-emerald-700', OVERDUE: 'bg-red-100 text-red-700', PENDING: 'bg-amber-100 text-amber-700' };
    const invoices = Array.isArray(json.data) ? json.data : (json.data.invoices || []);
    const uninvoiced = Array.isArray(json.data) ? [] : (json.data.uninvoiced || []);
    const icon = { 'Solar Panel': 'fa-solar-panel', Inverter: 'fa-bolt', Battery: 'fa-car-battery' };

    // Every material installed: item, quantity × unit price = line total, then the total.
    const materialsTable = (m, open) => !m || !m.items.length ? '' : `
      <details class="mt-2 rounded-xl border border-slate-200 bg-slate-50/60" ${open ? 'open' : ''}>
        <summary class="cursor-pointer list-none flex items-center justify-between gap-2 px-3 py-2">
          <span class="text-xs font-bold text-slate-700"><i class="fas fa-boxes-stacked text-suntrackOrange mr-1"></i>Materials used · ${m.count} item${m.count === 1 ? '' : 's'}</span>
          <span class="text-xs font-bold text-slate-900">${peso(m.total)} <i class="fas fa-chevron-down text-slate-300 ml-1"></i></span>
        </summary>
        <div class="px-3 pb-3 overflow-x-auto">
          <table class="w-full text-xs">
            <thead><tr class="text-[10px] uppercase text-slate-400 border-b border-slate-200">
              <th class="text-left font-bold py-1.5">Item</th><th class="text-right font-bold py-1.5">Qty</th>
              <th class="text-right font-bold py-1.5">Unit price</th><th class="text-right font-bold py-1.5">Amount</th></tr></thead>
            <tbody>${m.items.map(it => `
              <tr class="border-b border-slate-100 align-top">
                <td class="py-2 pr-2"><span class="font-semibold text-slate-800"><i class="fas ${icon[it.category] || 'fa-box'} text-slate-300 mr-1"></i>${esc(it.item_name)}</span>
                  <span class="block text-[10px] text-slate-400">${esc(it.category)} · ${esc(it.sku)}${it.model ? ' · ' + esc(it.model) : ''}</span></td>
                <td class="py-2 text-right tabular-nums">${it.quantity}</td>
                <td class="py-2 text-right tabular-nums whitespace-nowrap">${peso(it.unit_price)}</td>
                <td class="py-2 text-right tabular-nums whitespace-nowrap font-semibold">${peso(it.line_total)}</td>
              </tr>`).join('')}
            </tbody>
            <tfoot><tr><td colspan="3" class="pt-2 text-right font-bold text-slate-700">Total materials</td>
              <td class="pt-2 text-right font-extrabold text-slate-900 whitespace-nowrap">${peso(m.total)}</td></tr></tfoot>
          </table>
        </div>
      </details>`;

    const invHtml = invoices.map(i => `
      <div class="py-3">
        <div class="flex items-center justify-between gap-3 flex-wrap">
          <div class="min-w-0">
            <p class="font-semibold text-slate-900">${esc(i.invoice_code)} <span class="badge ${color[i.payment_status] || 'bg-slate-100 text-slate-600'}">${esc(i.payment_status)}</span></p>
            <p class="text-xs text-slate-500">${i.project_code ? esc(i.project_code) + ' · ' : ''}${peso(i.amount)}${Number(i.balance) > 0 && i.payment_status !== 'PAID' ? ' · ' + peso(i.balance) + ' left' : ''}${i.due_date ? ' · due ' + esc(i.due_date) : ''}</p>
          </div>
          <a href="${esc(i.url)}" target="_blank" rel="noopener" class="text-xs font-bold text-white bg-suntrackOrange rounded-lg px-3 py-1.5"><i class="fas fa-file-pdf mr-1"></i>View / PDF</a>
        </div>
        ${i.from_materials ? '<p class="text-[11px] text-slate-400 mt-1"><i class="fas fa-dolly mr-1"></i>Issued automatically when the warehouse released your materials.</p>' : ''}
        ${materialsTable(i.materials, i.from_materials)}
      </div>`).join('');

    const pendingHtml = uninvoiced.map(p => `
      <div class="py-3">
        <p class="font-semibold text-slate-900">${esc(p.project_code)} — ${esc(p.site_name || 'Installation')}
          <span class="badge bg-slate-100 text-slate-600">Not invoiced yet</span></p>
        <p class="text-xs text-slate-500">Cost of the materials installed at your site. The invoice is issued separately by our office.</p>
        ${materialsTable(p.materials, true)}
      </div>`).join('');

    box.innerHTML = (invHtml + pendingHtml) || '<p class="text-slate-400 py-2">No invoices yet.</p>';
  } catch (e) {
    box.innerHTML = '<p class="text-slate-400 py-2">Could not load invoices.</p>';
  }
}

const srStatusColor = {
  PENDING:'bg-slate-100 text-slate-600', APPROVED:'bg-blue-100 text-blue-700', REJECTED:'bg-red-100 text-red-700',
  ASSIGNED:'bg-indigo-100 text-indigo-700', SCHEDULED:'bg-violet-100 text-violet-700', IN_PROGRESS:'bg-amber-100 text-amber-700',
  ON_HOLD:'bg-slate-200 text-slate-700', COMPLETED:'bg-emerald-100 text-emerald-700', CANCELLED:'bg-slate-100 text-slate-500'
};
// What each status means to the client, in plain words.
const srStatusHint = {
  PENDING: 'Waiting for our team to review.', APPROVED: 'Approved — a technician will be assigned soon.',
  ASSIGNED: 'A technician has been assigned.', SCHEDULED: 'Your visit is scheduled.',
  IN_PROGRESS: 'Your technician is working on it.', ON_HOLD: 'Temporarily on hold.',
  COMPLETED: 'Completed.', CANCELLED: 'Cancelled.', REJECTED: 'Not approved.'
};
const srNice = (s) => String(s ?? '').replace(/_/g, ' ');
const srOpenDetails = new Set(); // requests whose history panel is open, kept across live refreshes

async function loadServiceRequests() {
  const list = document.getElementById('sr-list');
  if (!list.children.length) list.innerHTML = '<p class="text-slate-400 py-4">Loading...</p>';
  try {
    const qs = document.getElementById('sr-filter').value === 'open' ? '?open=1' : '';
    const res = await stFetch('../api/service_requests/list.php' + qs);
    const json = await res.json();
    if (!json.success) { list.innerHTML = `<p class="text-red-500 py-4">${esc(json.message)}</p>`; return; }
    list.innerHTML = json.data.length ? json.data.map(sr => `
      <div class="py-3">
        <div class="flex items-start justify-between gap-3">
          <div class="min-w-0">
            <p class="font-semibold text-slate-900">${esc(sr.subject || sr.request_type)}</p>
            <p class="text-xs text-slate-400">${esc(sr.request_code)} · ${esc(sr.request_type)} · ${esc(sr.priority)} priority · requested ${esc(String(sr.date_requested ?? '').slice(0, 10))}</p>
          </div>
          <span class="badge shrink-0 ${srStatusColor[sr.status] ?? 'bg-slate-100 text-slate-600'}">${esc(srNice(sr.status))}</span>
        </div>
        <p class="text-xs text-slate-500 mt-1">${esc(srStatusHint[sr.status] ?? '')}</p>
        <div class="grid sm:grid-cols-3 gap-2 mt-2 text-xs">
          <p><span class="text-slate-400">Technician:</span> <span class="font-semibold text-slate-700">${sr.technician_name ? esc(sr.technician_name) : '—'}</span></p>
          <p><span class="text-slate-400">Scheduled:</span> <span class="font-semibold text-slate-700">${esc(sr.scheduled_date ?? '—')}</span></p>
          <p><span class="text-slate-400">Completed:</span> <span class="font-semibold text-slate-700">${esc(sr.completion_date ? String(sr.completion_date).slice(0, 16) : '—')}</span></p>
        </div>
        ${sr.resolution ? `<p class="text-xs text-emerald-700 bg-emerald-50 rounded-lg px-3 py-2 mt-2 whitespace-pre-line"><b>Resolution:</b> ${esc(sr.resolution)}</p>` : ''}
        <div class="flex gap-3 mt-2">
          <button class="sr-toggle text-xs font-bold text-suntrackOrange" data-id="${sr.id}">${srOpenDetails.has(String(sr.id)) ? 'Hide details' : 'Details & history'}</button>
          ${['PENDING', 'APPROVED'].includes(sr.status) && !sr.job_id ? `<button class="sr-cancel text-xs font-bold text-red-500" data-id="${sr.id}" data-code="${esc(sr.request_code)}">Cancel request</button>` : ''}
        </div>
        <div id="sr-detail-${sr.id}" class="${srOpenDetails.has(String(sr.id)) ? '' : 'hidden'} mt-2"></div>
      </div>`).join('') : '<p class="text-slate-400 py-4">No service requests yet.</p>';

    list.querySelectorAll('.sr-toggle').forEach(b => b.addEventListener('click', () => {
      const id = b.dataset.id;
      if (srOpenDetails.has(id)) { srOpenDetails.delete(id); } else { srOpenDetails.add(id); }
      loadServiceRequests();
    }));
    list.querySelectorAll('.sr-cancel').forEach(b => b.addEventListener('click', () => cancelMyRequest(b.dataset.id, b.dataset.code)));
    srOpenDetails.forEach(id => loadMyRequestDetail(id));
  } catch (err) {
    list.innerHTML = '<p class="text-red-500 py-4">Failed to load requests.</p>';
  }
}
document.getElementById('sr-filter').addEventListener('change', loadServiceRequests);

async function loadMyRequestDetail(id) {
  const box = document.getElementById('sr-detail-' + id);
  if (!box) return;
  try {
    const json = await (await fetch('../api/service_requests/detail.php?id=' + encodeURIComponent(id))).json();
    if (!json.success) { box.innerHTML = `<p class="text-xs text-red-500">${esc(json.message)}</p>`; return; }
    const { request: r, technician: t, history } = json.data;
    box.innerHTML = `
      <div class="bg-slate-50 rounded-xl p-3 text-xs space-y-2">
        <p class="text-slate-700 whitespace-pre-line">${esc(r.description)}</p>
        ${r.site_address ? `<p><span class="text-slate-400">Service address:</span> ${esc(r.site_address)}</p>` : ''}
        ${t ? `<p><span class="text-slate-400">Technician:</span> <b>${esc(t.name)}</b>${t.phone ? ' · ' + esc(t.phone) : ''}</p>` : ''}
        <div class="border-l-2 border-slate-200 ml-1 pl-3 space-y-2 pt-1">
          ${history.map(h => `
            <div>
              <p class="font-semibold text-slate-800">${esc(srNice(h.action))}${h.new_status && h.old_status !== h.new_status ? ' — ' + esc(srNice(h.new_status)) : ''}</p>
              <p class="text-[11px] text-slate-400">${esc(h.created_at)}</p>
              ${h.remarks ? `<p class="text-slate-600">${esc(h.remarks)}</p>` : ''}
            </div>`).join('')}
        </div>
      </div>`;
  } catch (e) {
    box.innerHTML = '<p class="text-xs text-red-500">Could not load details.</p>';
  }
}

async function cancelMyRequest(id, code) {
  const reason = prompt(`Cancel request ${code}? You can add a short reason (optional):`, '');
  if (reason === null) return;
  try {
    const json = await (await fetch('../api/service_requests/cancel.php', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: Number(id), reason: reason.trim(), csrf_token: CSRF_TOKEN })
    })).json();
    alert(json.message);
    loadServiceRequests();
  } catch (e) {
    alert('Network error. Please try again.');
  }
}

document.getElementById('sr-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errBox = document.getElementById('sr-error');
  const okBox = document.getElementById('sr-ok');
  errBox.classList.add('hidden'); okBox.classList.add('hidden');

  const desc = document.getElementById('sr-desc').value.trim();
  const subject = document.getElementById('sr-subject').value.trim();
  if (!subject) { errBox.textContent = 'Please enter a subject.'; errBox.classList.remove('hidden'); return; }
  if (!desc) { errBox.textContent = 'Please describe the issue.'; errBox.classList.remove('hidden'); return; }

  // Lock the button so a double-click cannot file the same request twice.
  const submitBtn = e.target.querySelector('button[type="submit"]');
  if (submitBtn.disabled) return;
  submitBtn.disabled = true;
  try {
    const res = await fetch('../api/service_requests/create.php', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        service_type: document.getElementById('sr-type').value,
        subject: subject,
        priority: document.getElementById('sr-priority').value,
        description: desc,
        csrf_token: CSRF_TOKEN
      })
    });
    const json = await res.json();
    if (!json.success) { errBox.textContent = json.message; errBox.classList.remove('hidden'); return; }
    okBox.textContent = `Request ${json.data.request_code} submitted.`;
    okBox.classList.remove('hidden');
    document.getElementById('sr-form').reset();
    loadServiceRequests();
  } catch (err) {
    errBox.textContent = 'Network error. Please try again.';
    errBox.classList.remove('hidden');
  } finally {
    submitBtn.disabled = false;
  }
});

const clItemStatusColor = { PENDING: 'bg-slate-100 text-slate-600', COMPLETED: 'bg-emerald-100 text-emerald-700', NOT_APPLICABLE: 'bg-slate-200 text-slate-500' };

// The installation checklist as the technician sees it — same stages, order,
// ticks and proof photos — but read-only for the client.
function installationHtml(d) {
  const groups = {};
  d.items.forEach(it => { (groups[it.category] = groups[it.category] || []).push(it); });
  const stages = d.stages || Object.keys(groups).map(name => ({ name, unlocked: true, done: false, needs_photo: false,
    total: groups[name].length, resolved: groups[name].filter(i => i.status !== 'PENDING').length }));
  const photosByStage = {};
  (d.photos || []).forEach(p => { (photosByStage[p.stage] = photosByStage[p.stage] || []).push(p); });
  const firstOpen = stages.find(s => !s.done);
  const counts = d.counts || { progress: d.checklist.progress, resolved: 0, total: d.items.length };
  const doneStages = stages.filter(s => s.done).length;
  const when = v => v ? String(v).replace('T', ' ').slice(0, 16) : '';

  const header = `
    <div class="kpi-card mb-4">
      <div class="flex items-start justify-between gap-3 flex-wrap mb-3">
        <div>
          <p class="font-extrabold text-slate-900">${esc(d.job.job_code)}</p>
          <p class="text-xs text-slate-500">${esc(d.job.client_name || '')}${d.job.site_address ? ' · ' + esc(d.job.site_address) : ''}</p>
        </div>
        <span class="badge bg-amber-100 text-amber-700">${esc(String(d.job.stage || '').replace(/_/g, ' '))}</span>
      </div>
      <div class="flex items-center justify-between text-xs mb-1">
        <span class="text-slate-500 font-semibold">Overall progress</span>
        <span class="font-bold text-slate-800">${counts.progress}% · ${counts.resolved}/${counts.total} items</span>
      </div>
      <div class="w-full bg-slate-100 rounded-full h-2"><div class="bg-suntrackOrange h-2 rounded-full transition-all" style="width:${counts.progress}%"></div></div>
      <p class="text-xs mt-3 ${doneStages === stages.length ? 'text-emerald-600' : 'text-slate-500'}">
        ${doneStages === stages.length
          ? '<i class="fas fa-circle-check mr-1"></i>All installation stages are finished, with proof photos.'
          : `<i class="fas fa-circle-info mr-1"></i>${doneStages} of ${stages.length} stages finished. Our technician completes each stage in order and adds photos as proof of the work.`}
      </p>
    </div>`;

  const cards = stages.map((st, si) => {
    const items = groups[st.name] || [];
    const photos = photosByStage[st.name] || [];
    const notStarted = !st.unlocked;
    const current = firstOpen && firstOpen.name === st.name;
    const badge = st.done
      ? '<span class="badge bg-emerald-100 text-emerald-700"><i class="fas fa-circle-check mr-1"></i>Done</span>'
      : notStarted
        ? '<span class="badge bg-slate-200 text-slate-500"><i class="fas fa-hourglass-start mr-1"></i>Not started</span>'
        : '<span class="badge bg-amber-100 text-amber-700"><i class="fas fa-person-digging mr-1"></i>In progress</span>';
    return `
    <div class="kpi-card mb-4 ${notStarted ? 'opacity-60' : ''} ${current ? 'ring-2 ring-suntrackOrange/40' : ''}">
      <div class="flex items-center justify-between gap-3 mb-3">
        <div class="flex items-center gap-2 min-w-0">
          <span class="w-7 h-7 shrink-0 rounded-full flex items-center justify-center text-xs font-extrabold ${st.done ? 'bg-emerald-500 text-white' : notStarted ? 'bg-slate-200 text-slate-500' : 'bg-suntrackOrange text-white'}">${st.done ? '<i class="fas fa-check"></i>' : si + 1}</span>
          <div class="min-w-0">
            <p class="text-sm font-extrabold text-slate-800">${esc(st.name)}</p>
            <p class="text-[11px] text-slate-400">${st.resolved}/${st.total} done</p>
          </div>
        </div>
        ${badge}
      </div>
      <div class="space-y-2">
        ${items.map(it => {
          const ticked = it.status !== 'PENDING';
          return `
          <div class="rounded-xl border ${ticked ? 'border-emerald-200 bg-emerald-50/60' : 'border-slate-200 bg-white'} px-3 py-2.5">
            <div class="flex items-start gap-3">
              <span class="mt-0.5 w-6 h-6 shrink-0 rounded-md border-2 flex items-center justify-center
                           ${ticked ? 'bg-emerald-500 border-emerald-500 text-white' : 'bg-white border-slate-300 text-transparent'}"
                    role="img" aria-label="${ticked ? 'Done' : 'Not done yet'}">
                <i class="fas ${it.status === 'NOT_APPLICABLE' ? 'fa-minus' : 'fa-check'} text-xs"></i>
              </span>
              <span class="min-w-0">
                <span class="block text-sm font-semibold ${ticked ? 'text-slate-500 line-through decoration-emerald-400' : 'text-slate-800'}">${esc(it.description)}</span>
                <span class="block text-[11px] text-slate-400">
                  ${it.status === 'NOT_APPLICABLE' ? '<span class="font-semibold text-slate-500">Not applicable</span>' + (it.completed_date ? ' · ' : '') : ''}${esc(when(it.completed_date))}${it.completed_by_name ? ' · ' + esc(it.completed_by_name) : ''}
                </span>
              </span>
            </div>
            ${it.remarks ? `<p class="mt-2 text-xs text-slate-600 bg-white/70 border border-slate-100 rounded-lg px-2.5 py-1.5"><i class="fas fa-comment-dots text-slate-300 mr-1"></i>${esc(it.remarks)}</p>` : ''}
          </div>`;
        }).join('')}
      </div>
      <div class="mt-3 pt-3 border-t border-slate-100">
        <p class="text-xs font-bold text-slate-600 mb-2"><i class="fas fa-camera text-suntrackOrange mr-1"></i>Proof photos
          <span class="font-normal text-slate-400">· ${photos.length ? photos.length + ' photo' + (photos.length === 1 ? '' : 's') : 'none yet'}</span></p>
        ${photos.length ? `<div class="grid grid-cols-4 sm:grid-cols-6 gap-2">${photos.map(p => `
          <a href="${esc(p.url)}" target="_blank" rel="noopener" title="${esc((p.uploaded_by_name || '') + ' · ' + when(p.created_at))}">
            <img src="${esc(p.url)}" alt="${esc(st.name)} photo" loading="lazy" class="w-full aspect-square object-cover rounded-lg border border-slate-200 hover:opacity-90">
          </a>`).join('')}</div>`
          : `<p class="text-[11px] text-slate-400">${notStarted ? 'Photos are added when this stage is worked on.' : 'The technician has not added a photo for this stage yet.'}</p>`}
      </div>
    </div>`;
  }).join('');

  return header + cards;
}

async function loadInstallation() {
  document.getElementById('install-loading').classList.remove('hidden');
  document.getElementById('install-content').classList.add('hidden');
  document.getElementById('install-empty').classList.add('hidden');
  try {
    const res = await fetch('../api/installation/get.php');
    const json = await res.json();
    document.getElementById('install-loading').classList.add('hidden');
    if (!json.success || !json.data.checklist) {
      document.getElementById('install-empty').classList.remove('hidden');
      return;
    }
    document.getElementById('install-content').innerHTML = installationHtml(json.data);
    document.getElementById('install-content').classList.remove('hidden');
  } catch (err) {
    document.getElementById('install-loading').classList.add('hidden');
    document.getElementById('install-empty').classList.remove('hidden');
  }
}

loadDashboard();

// ---------------------------------------------------------------------------
// Real-time updates
//
// A client's view is read-only, but the things it reports on are moving:
// Management approves a service request, a technician marks an installation
// step complete, an invoice is settled. Without this, a client watching the
// page after raising a request sees nothing change until they refresh.
// ---------------------------------------------------------------------------
const CLIENT_TAB_LOADERS = {
  'dashboard':       loadDashboard,
  'service-requests': loadServiceRequests,
  'installation':    loadInstallation,
  'solar-system':    loadMySystem,
  'maintenance':     loadMaintenance,
  'service-history': loadServiceHistory,
};

const CLIENT_CHANNEL_TABS = {
  service_requests: ['dashboard', 'service-requests', 'service-history'],
  jobs:             ['dashboard', 'installation', 'service-history', 'solar-system'],
  installation_plan:['installation'],
  maintenance:      ['dashboard', 'maintenance'],
  billing:          ['dashboard'],
};

SunTrackRealtime.start({
  endpoint: '../api/realtime/sync.php',
  on: {
    '*': (changed) => {
      const affected = new Set();
      changed.forEach(ch => (CLIENT_CHANNEL_TABS[ch] || []).forEach(t => affected.add(t)));
      if (!affected.has(CURRENT_TAB)) return;
      const loader = CLIENT_TAB_LOADERS[CURRENT_TAB];
      if (loader) loader();
    },
    sessionExpired: () => { window.location.href = '<?= APP_BASE_URL ?>/login.php?expired=1'; },
  }
});

// ---- MY SOLAR SYSTEM (+ site geomapping) ----
let mySystemMap = null;
let mySystemMarkers = [];
async function loadMySystem() {
  document.getElementById('sys-loading').classList.remove('hidden');
  document.getElementById('sys-content').classList.add('hidden');
  document.getElementById('sys-empty').classList.add('hidden');
  try {
    const res = await fetch('../api/client/system.php');
    const json = await res.json();
    document.getElementById('sys-loading').classList.add('hidden');
    if (!json.success) { document.getElementById('sys-empty').textContent = json.message; document.getElementById('sys-empty').classList.remove('hidden'); return; }
    const { systems, sites } = json.data;
    if (!systems.length) { document.getElementById('sys-empty').classList.remove('hidden'); return; }

    const statusColor = { PLANNED:'bg-slate-100 text-slate-600', INSTALLING:'bg-amber-100 text-amber-700', ACTIVE:'bg-emerald-100 text-emerald-700', FAULT:'bg-red-100 text-red-700', DECOMMISSIONED:'bg-slate-100 text-slate-400' };
    document.getElementById('sys-cards').innerHTML = systems.map(s => `
      <div class="kpi-card">
        <div class="flex flex-wrap items-start justify-between gap-2">
          <div class="min-w-0">
            <h3 class="font-bold text-slate-900">${esc(s.system_code)}${s.capacity_kw ? ` <span class="text-slate-400 font-semibold">· ${esc(s.capacity_kw)} kW</span>` : ''}</h3>
            <p class="text-xs text-slate-500 mt-0.5">${esc(s.summary.status_detail)}${s.summary.age_days ? ' · In service ' + esc(s.summary.age_label) : ''}</p>
          </div>
          <span class="badge shrink-0 ${statusColor[s.status] || 'bg-slate-100 text-slate-600'}">${esc(s.summary.status_label)}</span>
        </div>
        <div class="text-sm text-slate-600 mt-2">
          ${systemDetailsHtml(s, s.summary, { warranty: true })}
        </div>
      </div>`).join('');

    // Site map — plots any GPS pin recorded from a technician's geofenced visit
    if (!mySystemMap) {
      mySystemMap = L.map('sys-map').setView([12.8797, 121.7740], 6);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19, attribution: '&copy; OpenStreetMap contributors'
      }).addTo(mySystemMap);
    }
    mySystemMarkers.forEach(m => mySystemMap.removeLayer(m));
    mySystemMarkers = [];
    document.getElementById('sys-map-empty').classList.toggle('hidden', sites.length > 0);
    sites.forEach(s => {
      const marker = L.marker([s.site_lat, s.site_lng]).addTo(mySystemMap);
      marker.bindPopup(`<div style="font-family:Inter,sans-serif;font-size:12px"><b>${esc(s.site_name ?? s.job_code)}</b><br>${esc(s.site_address)}<br>Stage: ${esc(s.stage)}</div>`);
      mySystemMarkers.push(marker);
    });
    if (mySystemMarkers.length) {
      const group = L.featureGroup(mySystemMarkers);
      mySystemMap.fitBounds(group.getBounds().pad(0.5));
    }
    setTimeout(() => mySystemMap && mySystemMap.invalidateSize(), 200);
    document.getElementById('sys-content').classList.remove('hidden');
  } catch (err) {
    document.getElementById('sys-loading').classList.add('hidden');
    document.getElementById('sys-empty').textContent = 'Failed to load your solar system.';
    document.getElementById('sys-empty').classList.remove('hidden');
  }
}

// ---- MAINTENANCE (monitoring) ----
async function loadMaintenance() {
  const tbody = document.getElementById('maint-table-body');
  tbody.innerHTML = `<tr><td colspan="5" class="text-slate-400 text-center py-6">Loading...</td></tr>`;
  try {
    const res = await fetch('../api/client/maintenance.php');
    const json = await res.json();
    if (!json.success) { tbody.innerHTML = `<tr><td colspan="5" class="text-red-500 py-6 text-center">${esc(json.message)}</td></tr>`; return; }
    const rows = json.data.rows;
    document.getElementById('maint-empty').classList.toggle('hidden', rows.length > 0);
    const statusColor = { UPCOMING:'bg-sky-100 text-sky-700', DUE:'bg-amber-100 text-amber-700', OVERDUE:'bg-red-100 text-red-700' };
    tbody.innerHTML = rows.map(r => `
      <tr>
        <td class="py-2 font-semibold">${esc(r.site_name)}<div class="text-xs text-slate-400 font-normal">${esc(r.project_code)}</div></td>
        <td class="text-xs">${r.last_maintenance ?? '—'}</td>
        <td class="text-xs">${r.next_maintenance ?? '—'}</td>
        <td><span class="badge ${statusColor[r.status] || 'bg-slate-100 text-slate-500'}">${r.status}</span></td>
        <td>${Number(r.client_notified) ? '<span class="text-emerald-600 text-xs font-semibold">Yes</span>' : '<span class="text-slate-400 text-xs">No</span>'}</td>
      </tr>`).join('');
  } catch (err) { tbody.innerHTML = `<tr><td colspan="5" class="text-red-500 py-6 text-center">Failed to load maintenance schedule.</td></tr>`; }
}

// ---- SERVICE HISTORY (monitoring) ----
async function loadServiceHistory() {
  const jobsBox = document.getElementById('hist-jobs');
  const reportsBox = document.getElementById('hist-reports');
  jobsBox.innerHTML = '<p class="text-slate-400 py-4">Loading...</p>';
  reportsBox.innerHTML = '<p class="text-slate-400 py-4">Loading...</p>';
  try {
    const res = await fetch('../api/client/service_history.php');
    const json = await res.json();
    if (!json.success) { jobsBox.innerHTML = `<p class="text-red-500 py-4">${esc(json.message)}</p>`; reportsBox.innerHTML = ''; return; }
    const { jobs, reports } = json.data;
    document.getElementById('hist-jobs-empty').classList.toggle('hidden', jobs.length > 0);
    jobsBox.innerHTML = jobs.map(j => `
      <div class="py-3">
        <div class="flex items-center justify-between"><p class="font-semibold text-slate-900">${esc(j.job_code)}</p><span class="badge bg-slate-100 text-slate-600">${esc(j.stage)}</span></div>
        <p class="text-xs text-slate-500 mt-1">${esc(j.job_type)} ${j.technician_name ? '· ' + esc(j.technician_name) : ''}</p>
        <p class="text-xs text-slate-400">${esc(j.updated_at)}</p>
        <div class="flex flex-wrap items-center gap-2 mt-2">
          ${Number(j.photo_count) > 0 ? `<button type="button" class="js-job-photos text-xs font-bold text-slate-600 border border-slate-200 rounded-lg px-2.5 py-1" data-job="${j.id}" data-code="${esc(j.job_code)}"><i class="fas fa-images mr-1"></i>Photos (${Number(j.photo_count)})</button>` : ''}
          ${j.can_confirm ? `<button type="button" class="js-confirm-job text-xs font-bold text-white bg-suntrackOrange rounded-lg px-2.5 py-1" data-job="${j.id}" data-code="${esc(j.job_code)}"><i class="fas fa-signature mr-1"></i>Confirm &amp; sign</button>` : ''}
          ${j.confirmed ? `<span class="badge bg-emerald-100 text-emerald-700"><i class="fas fa-check mr-1"></i>Signed${j.rating ? ' · ' + '★'.repeat(Number(j.rating)) : ''}</span>` : ''}
        </div>
      </div>`).join('');
    jobsBox.querySelectorAll('.js-confirm-job').forEach(b => b.addEventListener('click', () => confirmJob(b.dataset.job, b.dataset.code)));
    jobsBox.querySelectorAll('.js-job-photos').forEach(b => b.addEventListener('click', () => showJobPhotos(b.dataset.job, b.dataset.code)));
    document.getElementById('hist-reports-empty').classList.toggle('hidden', reports.length > 0);
    reportsBox.innerHTML = reports.map(r => `
      <div class="py-3">
        <div class="flex items-center justify-between"><p class="font-semibold text-slate-900">${r.report_code}</p><span class="text-xs text-slate-400">${r.submitted_date}</span></div>
        <p class="text-xs text-slate-500 mt-1">${esc(r.work_type)} · ${esc(r.technician_name)} · ${esc(r.duration_text || (r.duration_minutes != null ? r.duration_minutes + ' min' : '—'))}</p>
        ${r.remarks ? `<p class="text-xs text-slate-400 mt-1">${esc(r.remarks)}</p>` : ''}
      </div>`).join('');
  } catch (err) {
    jobsBox.innerHTML = '<p class="text-red-500 py-4">Failed to load service history.</p>';
    reportsBox.innerHTML = '';
  }
}

// Client sign-off: signature, name, optional rating and comment.
function confirmJob(jobId, jobCode) {
  SunTrackSignature.open({
    title: 'Confirm job ' + jobCode,
    name: <?= json_encode($_SESSION['full_name'] ?? '', JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>,
    onSubmit: async (d) => {
      try {
        const res = await fetch('../api/confirmations/create.php', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...d, job_id: Number(jobId), csrf_token: CSRF_TOKEN })
        });
        const json = await res.json();
        if (json.success) loadServiceHistory();
        return json;
      } catch (e) { return { success: false, message: 'Network error. Please try again.' }; }
    }
  });
}

// Before/after photos of a job, in a simple viewer.
async function showJobPhotos(jobId, jobCode) {
  let box = document.getElementById('photo-viewer');
  if (!box) {
    box = document.createElement('div');
    box.id = 'photo-viewer';
    box.className = 'fixed inset-0 bg-black/60 z-[1300] flex items-center justify-center p-4';
    box.addEventListener('click', (e) => { if (e.target === box) box.remove(); });
    document.body.appendChild(box);
  }
  box.innerHTML = '<div class="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto p-5"><p class="text-slate-400 text-sm">Loading photos...</p></div>';
  let json;
  try { json = await (await fetch('../api/job_photos/list.php?job_id=' + encodeURIComponent(jobId))).json(); }
  catch (e) { json = { success: false, message: 'Network error.' }; }
  const section = (kind) => {
    const list = json.success ? json.data.photos.filter(p => p.kind === kind) : [];
    return `<p class="text-xs font-bold text-slate-600 mt-3 mb-1">${kind === 'BEFORE' ? 'Before' : 'After'}</p>` + (list.length
      ? `<div class="grid grid-cols-3 gap-2">${list.map(p => `<a href="${esc(p.url)}" target="_blank" rel="noopener"><img src="${esc(p.url)}" alt="" loading="lazy" class="w-full aspect-square object-cover rounded-lg border border-slate-200"></a>`).join('')}</div>`
      : '<p class="text-xs text-slate-400">None</p>');
  };
  box.firstElementChild.innerHTML = `
    <div class="flex items-center justify-between"><h3 class="font-bold text-slate-900">Photos — ${esc(jobCode)}</h3>
      <button type="button" class="js-close text-slate-400 hover:text-slate-700 text-lg"><i class="fas fa-xmark"></i></button></div>
    ${json.success ? section('BEFORE') + section('AFTER') : `<p class="text-red-500 text-sm mt-3">${esc(json.message)}</p>`}`;
  box.querySelector('.js-close').addEventListener('click', () => box.remove());
}

// ---- SETTINGS (own account) ----
function showMsg(box, text, ok) {
  box.textContent = text;
  box.className = 'text-xs rounded-lg px-3 py-2 mb-3 border ' + (ok
    ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
    : 'bg-red-50 border-red-200 text-red-600');
}

async function postProfile(btn, busyLabel, body) {
  const label = btn.textContent;
  btn.disabled = true; btn.textContent = busyLabel;
  try {
    const res = await fetch('../api/account/profile.php', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...body, csrf_token: CSRF_TOKEN })
    });
    return await res.json();
  } catch (err) {
    return { success: false, message: 'Network error. Please try again.' };
  } finally {
    btn.disabled = false; btn.textContent = label;
  }
}

// ---- My site location (set from the phone while at the site) ----
let locMap = null, locMarker = null;
function drawMyLocation(lat, lng, address) {
  const has = lat !== null && lng !== null;
  const status = document.getElementById('loc-status');
  status.className = 'badge ' + (has ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700');
  status.innerHTML = has ? '<i class="fas fa-circle-check mr-1"></i>Location saved' : '<i class="fas fa-triangle-exclamation mr-1"></i>Not set yet';
  document.getElementById('loc-coords').textContent = has
    ? 'Pinned at ' + lat.toFixed(6) + ', ' + lng.toFixed(6) + (address ? ' · ' + address : '')
    : (address ? 'Address on file: ' + address + '. ' : '') + 'No map pin yet — tap the button below while at your site.';
  if (typeof L === 'undefined') return;
  const center = has ? [lat, lng] : [10.6765, 122.9509]; // Bacolod when nothing is pinned yet
  if (!locMap) {
    locMap = L.map('loc-map', { zoomControl: true, attributionControl: true }).setView(center, has ? 17 : 11);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap contributors' }).addTo(locMap);
  } else {
    locMap.setView(center, has ? 17 : 11);
  }
  if (locMarker) { locMap.removeLayer(locMarker); locMarker = null; }
  if (has) locMarker = L.marker([lat, lng]).addTo(locMap).bindPopup('Your site');
  setTimeout(() => locMap.invalidateSize(), 50); // the tab was hidden while the map was built
}

async function loadMyLocation() {
  try {
    const json = await (await fetch('../api/client/location.php')).json();
    if (json.success) drawMyLocation(json.data.lat, json.data.lng, json.data.address);
  } catch (err) { /* the card stays as it is */ }
}

document.getElementById('loc-save').addEventListener('click', (e) => {
  const btn = e.currentTarget, msg = document.getElementById('loc-msg');
  if (!navigator.geolocation) { showMsg(msg, 'This browser cannot read your location.', false); return; }
  const label = btn.innerHTML;
  btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-1"></i>Finding your location…';
  navigator.geolocation.getCurrentPosition(async (pos) => {
    const lat = pos.coords.latitude, lng = pos.coords.longitude, acc = Math.round(pos.coords.accuracy || 0);
    if (!confirm('Save this as your site location?\n\n' + lat.toFixed(6) + ', ' + lng.toFixed(6)
      + (acc ? '\nAccurate to about ' + acc + ' m.' : '') + '\n\nOnly do this while you are at your installation site.')) {
      btn.disabled = false; btn.innerHTML = label; return;
    }
    try {
      const res = await fetch('../api/client/location.php', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lat, lng, accuracy: acc, csrf_token: CSRF_TOKEN })
      });
      const json = await res.json();
      showMsg(msg, json.message, json.success);
      if (json.success) drawMyLocation(json.data.lat, json.data.lng, json.data.address);
    } catch (err) {
      showMsg(msg, 'Network error. Please try again.', false);
    }
    btn.disabled = false; btn.innerHTML = label;
  }, (err) => {
    const why = err.code === 1 ? 'Location permission was denied. Allow location for this site in your browser settings, then try again.'
      : err.code === 3 ? 'Finding your location took too long. Step outside or turn on GPS, then try again.'
      : 'Your location could not be read. Turn on GPS / location services, then try again.';
    showMsg(msg, why + (location.protocol !== 'https:' && location.hostname !== 'localhost' ? ' (Phones only share location on a secure https:// site.)' : ''), false);
    btn.disabled = false; btn.innerHTML = label;
  }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 });
});

async function loadProfile() {
  try {
    const json = await (await fetch('../api/account/profile.php')).json();
    if (!json.success) return;
    document.getElementById('pf-name').value  = json.data.full_name || '';
    document.getElementById('pf-email').value = json.data.email || '';
    document.getElementById('pf-phone').value = json.data.phone || '';
  } catch (err) {
    showMsg(document.getElementById('pf-msg'), 'Could not load your profile.', false);
  }
}

document.getElementById('pf-save').addEventListener('click', async (e) => {
  const json = await postProfile(e.currentTarget, 'Saving…', {
    action: 'update_profile',
    full_name: document.getElementById('pf-name').value.trim(),
    email: document.getElementById('pf-email').value.trim(),
    phone: document.getElementById('pf-phone').value.trim(),
  });
  showMsg(document.getElementById('pf-msg'), json.message, json.success);
});

document.getElementById('pw-save').addEventListener('click', async (e) => {
  const msg = document.getElementById('pw-msg');
  const cur = document.getElementById('pw-current').value;
  const nw  = document.getElementById('pw-new').value;
  const cf  = document.getElementById('pw-confirm').value;
  if (!cur || !nw || !cf) { showMsg(msg, 'Please fill in all three password fields.', false); return; }
  if (nw !== cf)          { showMsg(msg, 'The new passwords do not match.', false); return; }
  if (nw.length < 8)      { showMsg(msg, 'Your new password must be at least 8 characters.', false); return; }

  const json = await postProfile(e.currentTarget, 'Updating…', {
    action: 'change_password', current_password: cur, new_password: nw, confirm_password: cf,
  });
  showMsg(msg, json.message, json.success);
  if (json.success) ['pw-current','pw-new','pw-confirm'].forEach(id => document.getElementById(id).value = '');
});
</script>

<?php include ROOT_PATH . '/includes/consent_banner.php'; ?>
</body>
</html>
