<?php
/**
 * SunTrack ERP — self-service password reset (clients and technicians).
 *
 * Staff, managers, warehouse and admin accounts are deliberately excluded:
 * Management resets those, so a stolen staff mailbox is not a way into the
 * back office.
 *
 * All times are PHP times (Asia/Manila) passed in as parameters — never
 * MySQL's NOW(), which may run on UTC and would shift the 30-minute window.
 */
require_once __DIR__ . '/mailer.php';

/** Roles that may reset their own password by email. */
const PASSWORD_RESET_ROLES = ['client', 'technician'];

/** How long a reset link works. */
const PASSWORD_RESET_TTL_MINUTES = 30;

/** Per-account and per-IP limits on reset emails, per hour. */
const PASSWORD_RESET_MAX_PER_USER = 3;
const PASSWORD_RESET_MAX_PER_IP = 10;

/** Fail with a clear message if phase 6 has not been imported. */
function password_reset_require_schema(): void
{
    try {
        db()->query('SELECT 1 FROM password_resets LIMIT 0');
    } catch (PDOException $e) {
        json_error('Password reset is not set up yet. Import database/phase6_password_resets.sql.', 503);
    }
}

/**
 * The public address of the site, used to build the emailed link.
 *
 * In production it must come from SUNTRACK_APP_URL. Building it from the
 * request's Host header would let anyone who can send a request with a forged
 * Host make the site email a reset link pointing at THEIR server — the
 * classic password-reset poisoning attack. Development falls back to the
 * request so local testing needs no setup.
 */
function password_reset_base_url(): ?string
{
    $configured = app_env('SUNTRACK_APP_URL');
    if ($configured !== null) {
        return rtrim($configured, '/');
    }
    if (APP_ENV !== 'development') {
        return null;
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    return ($https ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . APP_BASE_URL;
}

/**
 * Look up a token without consuming it. Returns the reset row joined with the
 * user, or null when the link is unknown, used, expired, or the account can
 * no longer use self-service reset. $lock takes a row lock (inside a transaction).
 */
function password_reset_find(string $token, bool $lock = false): ?array
{
    if (!preg_match('/^[a-f0-9]{64}$/', $token)) {
        return null;
    }
    $stmt = db()->prepare(
        'SELECT pr.id, pr.user_id, pr.expires_at, pr.used_at, u.email, u.full_name, u.status, r.role_key
         FROM password_resets pr
         JOIN users u ON u.id = pr.user_id
         JOIN roles r ON r.id = u.role_id
         WHERE pr.token_hash = :h' . ($lock ? ' FOR UPDATE' : '')
    );
    $stmt->execute([':h' => hash('sha256', $token)]);
    $row = $stmt->fetch();

    if (!$row
        || $row['used_at'] !== null
        || $row['expires_at'] < date('Y-m-d H:i:s')
        || $row['status'] !== 'ACTIVE'
        || !in_array($row['role_key'], PASSWORD_RESET_ROLES, true)) {
        return null;
    }
    return $row;
}

/**
 * A simple branded HTML email: heading, paragraphs, optional button. Every
 * dynamic value is escaped here, so callers pass plain text.
 */
function password_reset_email_html(string $heading, array $paragraphs, ?string $buttonUrl = null, ?string $buttonText = null): string
{
    $e = fn(string $s) => htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
    $body = '';
    foreach ($paragraphs as $p) {
        $body .= '<p style="margin:0 0 14px;font-size:15px;line-height:1.55;color:#334155">' . $e($p) . '</p>';
    }
    if ($buttonUrl !== null) {
        $body .= '<p style="margin:22px 0"><a href="' . $e($buttonUrl) . '" style="display:inline-block;background:#f97316;color:#ffffff;'
            . 'text-decoration:none;font-weight:bold;font-size:15px;padding:12px 22px;border-radius:10px">' . $e((string)$buttonText) . '</a></p>'
            . '<p style="margin:0 0 14px;font-size:12px;color:#64748b">Button not working? Copy this link into your browser:<br>'
            . '<span style="word-break:break-all;color:#0f172a">' . $e($buttonUrl) . '</span></p>';
    }
    return '<!DOCTYPE html><html><body style="margin:0;background:#f1f5f9;font-family:Arial,Helvetica,sans-serif">'
        . '<div style="max-width:520px;margin:0 auto;padding:24px 16px">'
        . '<div style="background:#0b1329;color:#ffffff;font-weight:bold;font-size:18px;padding:16px 22px;border-radius:14px 14px 0 0">'
        . $e(APP_NAME) . '</div>'
        . '<div style="background:#ffffff;padding:24px 22px;border-radius:0 0 14px 14px">'
        . '<h1 style="margin:0 0 16px;font-size:20px;color:#0f172a">' . $e($heading) . '</h1>' . $body
        . '</div><p style="text-align:center;font-size:11px;color:#94a3b8;margin-top:14px">This is an automatic message from '
        . $e(APP_NAME) . '. Please do not reply.</p></div></body></html>';
}
