<?php
/**
 * SunTrack ERP — Service request checklists (phase 21).
 *
 * Every service type except Maintenance (which has the maintenance inspection
 * checklist) gets a 2–3 step checklist for the technician on its job. Each
 * step has items to tick and needs at least one proof photo. The technician
 * opens it from the job ("Open Checklist" pop-up), finishes it and submits it;
 * Management is notified on the service request and approves it — which
 * completes the job and marks the request COMPLETED — or returns it with a
 * note to fix.
 *
 * Tables: sr_checklists, sr_checklist_items, sr_checklist_photos
 * (database/phase21_service_checklists.sql).
 */

const SRCL_PHOTO_MAX_PER_STEP = 10;

function srcl_ready(): bool
{
    static $ok = null;
    if ($ok === null) {
        try {
            db()->query('SELECT 1 FROM sr_checklists LIMIT 0');
            db()->query('SELECT 1 FROM sr_checklist_items LIMIT 0');
            db()->query('SELECT 1 FROM sr_checklist_photos LIMIT 0');
            $ok = true;
        } catch (PDOException $e) {
            $ok = false;
        }
    }
    return $ok;
}

/**
 * The steps and items of each service type, in working order. Every step
 * needs at least one proof photo. Change the wording here; new checklists use
 * it (ones already started keep their items).
 */
function srcl_templates(): array
{
    return [
        'Repair' => [
            'Diagnose' => ['Inspect the reported fault on site', 'Find the cause of the fault', 'Make the system safe before working (isolate DC / AC)'],
            'Repair'   => ['Repair or replace the faulty part', 'Re-secure connections, covers and housings'],
            'Test & handover' => ['Power up and test the system', 'Confirm the fault no longer occurs', 'Explain the repair to the client'],
        ],
        'Inspection' => [
            'Visual inspection' => ['Panels, frames and mounting', 'DC / AC wiring, conduits and connectors', 'Inverter and battery area (clearance, ventilation)'],
            'Electrical checks' => ['Measure string voltage and current', 'Check grounding, breakers and surge protection'],
            'Findings'          => ['Record what was found', 'Explain the findings and recommendations to the client'],
        ],
        'Replacement' => [
            'Remove old part' => ['Shut down and isolate the system', 'Remove the old component', 'Note the serial number of the removed part (remarks)'],
            'Install new part' => ['Install the replacement', 'Note the serial number of the new part (remarks)', 'Connect and secure all wiring'],
            'Commission'      => ['Power up and configure', 'Verify output and monitoring', 'Take the old part back for return / disposal'],
        ],
        'Installation Support' => [
            'Assess' => ['Review the existing installation', 'Agree with the client what support is needed'],
            'Support work' => ['Carry out the adjustments / additional work', 'Secure, label and tidy the work area'],
            'Verify' => ['Test the system after the work', 'Walk the client through what changed'],
        ],
        'Panel Issue' => [
            'Panel check' => ['Inspect panels for cracks, hot spots, soiling or shading', 'Check panel connectors and cables'],
            'Fix'         => ['Clean, repair or replace the affected panel(s)', 'Re-secure the mounting and clamps'],
            'Test'        => ['Measure string voltage after the fix', 'Confirm production is back to normal'],
        ],
        'Battery Issue' => [
            'Battery check' => ['Read the BMS status and error codes', 'Inspect terminals and cables', 'Check temperature and ventilation'],
            'Fix'           => ['Reset, repair or replace the battery / module', 'Clean and tighten the terminals'],
            'Test'          => ['Run a charge / discharge test', 'Confirm the monitoring readings are normal'],
        ],
        'Inverter Issue' => [
            'Diagnose' => ['Read the inverter error codes and logs', 'Check the DC input and AC output', 'Check cooling fans and airflow'],
            'Fix'      => ['Reset, update firmware, repair or replace the inverter', 'Secure all wiring and covers'],
            'Test'     => ['Restart and watch the output', 'Confirm grid sync and monitoring are working'],
        ],
        'Other' => [
            'Assess'  => ['Inspect what the client reported', 'Make the work area safe'],
            'Resolve' => ['Carry out the work needed (describe it in the remarks)'],
            'Confirm' => ['Test and confirm the issue is resolved with the client'],
        ],
    ];
}

/** The template for a service type; Maintenance has none (its own checklist). */
function srcl_template_for(?string $type): ?array
{
    if ($type === null || strcasecmp($type, 'Maintenance') === 0) {
        return null;
    }
    $all = srcl_templates();
    return $all[$type] ?? $all['Other'];
}

/** The open (or latest) service request behind a job, or null. */
function srcl_request_for_job(int $jobId): ?array
{
    if (!sr_phase5_ready()) {
        return null;
    }
    $s = db()->prepare(
        'SELECT id, request_code, client_id, assigned_technician_id, subject, request_type, status
         FROM service_requests WHERE job_id = :j ORDER BY id DESC LIMIT 1'
    );
    $s->execute([':j' => $jobId]);
    return $s->fetch() ?: null;
}

/** Does this job carry a service-request checklist? */
function srcl_applies(array $job): bool
{
    if (!srcl_ready() || in_array($job['job_type'] ?? '', ['MAINTENANCE', 'INSTALLATION'], true)) {
        return false;
    }
    $sr = srcl_request_for_job((int)$job['id']);
    return $sr && srcl_template_for($sr['request_type']) !== null;
}

/**
 * The job's checklist row; created with its template's items on first use
 * ($create). Null when the job has no service-request checklist.
 */
function srcl_for_job(PDO $pdo, array $job, bool $create = true): ?array
{
    if (!srcl_ready()) {
        return null;
    }
    $s = $pdo->prepare('SELECT * FROM sr_checklists WHERE job_id = :j');
    $s->execute([':j' => $job['id']]);
    if ($row = $s->fetch()) {
        return $row;
    }
    if (!$create || !srcl_applies($job)) {
        return null;
    }
    $sr = srcl_request_for_job((int)$job['id']);
    $template = srcl_template_for($sr['request_type']);
    try {
        $pdo->prepare('INSERT INTO sr_checklists (service_request_id, job_id, request_type, status, created_at) VALUES (:sr, :j, :t, "OPEN", NOW())')
            ->execute([':sr' => $sr['id'], ':j' => $job['id'], ':t' => $sr['request_type']]);
        $id = (int)$pdo->lastInsertId();
        $ins = $pdo->prepare('INSERT INTO sr_checklist_items (checklist_id, step, position, description) VALUES (:c, :s, :p, :d)');
        $pos = 0;
        foreach ($template as $step => $items) {
            foreach ($items as $desc) {
                $ins->execute([':c' => $id, ':s' => $step, ':p' => ++$pos, ':d' => $desc]);
            }
        }
    } catch (PDOException $e) {
        if (($e->errorInfo[1] ?? null) !== 1062) { // another request created it a moment ago
            throw $e;
        }
    }
    $s->execute([':j' => $job['id']]);
    return $s->fetch() ?: null;
}

function srcl_items(PDO $pdo, int $checklistId): array
{
    $s = $pdo->prepare(
        'SELECT i.id, i.step, i.position, i.description, i.status, i.remarks, i.completed_at, u.full_name AS completed_by_name
         FROM sr_checklist_items i LEFT JOIN users u ON u.id = i.completed_by
         WHERE i.checklist_id = :c ORDER BY i.position, i.id'
    );
    $s->execute([':c' => $checklistId]);
    return $s->fetchAll();
}

function srcl_photos(PDO $pdo, int $checklistId): array
{
    $s = $pdo->prepare(
        'SELECT p.id, p.step, p.width, p.height, p.created_at, u.full_name AS uploaded_by_name
         FROM sr_checklist_photos p LEFT JOIN users u ON u.id = p.uploaded_by
         WHERE p.checklist_id = :c ORDER BY p.id'
    );
    $s->execute([':c' => $checklistId]);
    return array_map(function ($p) {
        $p['url'] = APP_BASE_URL . '/api/sr_checklist/photo_view.php?id=' . (int)$p['id'];
        return $p;
    }, $s->fetchAll());
}

/** Steps in order: [['name', 'total', 'resolved', 'photos', 'done'], ...] */
function srcl_steps(array $items, array $photos): array
{
    $steps = [];
    foreach ($items as $i) {
        $steps[$i['step']] ??= ['name' => $i['step'], 'total' => 0, 'resolved' => 0, 'photos' => 0, 'done' => false];
        $steps[$i['step']]['total']++;
        if ($i['status'] !== 'PENDING') {
            $steps[$i['step']]['resolved']++;
        }
    }
    foreach ($photos as $p) {
        if (isset($steps[$p['step']])) {
            $steps[$p['step']]['photos']++;
        }
    }
    foreach ($steps as &$st) {
        $st['done'] = $st['resolved'] === $st['total'] && $st['photos'] > 0;
    }
    unset($st);
    return array_values($steps);
}

function srcl_progress(array $items): int
{
    $total = count($items);
    $done = count(array_filter($items, fn($i) => $i['status'] !== 'PENDING'));
    return $total ? (int)round($done * 100 / $total) : 0;
}

/** Why the technician may not change the checklist now, or null. */
function srcl_edit_blocker(array $cl): ?string
{
    return match ($cl['status'] ?? 'OPEN') {
        'SUBMITTED' => 'This checklist was submitted — Management is reviewing it. It opens again if it is returned.',
        'APPROVED'  => 'This checklist was approved by Management and is locked.',
        default     => null,
    };
}

/** Why the checklist cannot be submitted yet, or null. */
function srcl_submit_blocker(array $steps, array $job): ?string
{
    foreach ($steps as $st) {
        if ($st['resolved'] < $st['total']) {
            $left = $st['total'] - $st['resolved'];
            return "Tick the remaining {$left} item" . ($left === 1 ? '' : 's') . " of {$st['name']} (or mark them N/A) first.";
        }
        if ($st['photos'] < 1) {
            return "Add at least one proof photo for {$st['name']} first.";
        }
    }
    if (!empty($job['technician_id']) && tech_open_attendance((int)$job['id'], (int)$job['technician_id'])) {
        return 'Record your GPS Time Out at the site before submitting.';
    }
    return null;
}

/** The job's checklist as the screens need it (technician pop-up, Management review). */
function srcl_payload(PDO $pdo, array $job, array $cl): array
{
    $items = srcl_items($pdo, (int)$cl['id']);
    $photos = srcl_photos($pdo, (int)$cl['id']);
    $steps = srcl_steps($items, $photos);
    $names = $pdo->prepare('SELECT full_name FROM users WHERE id = :id');
    $nameOf = function ($id) use ($names) {
        if (!$id) {
            return null;
        }
        $names->execute([':id' => $id]);
        return $names->fetchColumn() ?: null;
    };
    $sr = srcl_request_for_job((int)$job['id']);
    return [
        'id' => (int)$cl['id'], 'request_type' => $cl['request_type'], 'status' => $cl['status'],
        'service_request' => $sr ? ['id' => (int)$sr['id'], 'request_code' => $sr['request_code'], 'subject' => $sr['subject'], 'status' => $sr['status']] : null,
        'submitted_at' => $cl['submitted_at'], 'submitted_by_name' => $nameOf($cl['submitted_by']), 'submit_note' => $cl['submit_note'],
        'reviewed_at' => $cl['reviewed_at'], 'reviewed_by_name' => $nameOf($cl['reviewed_by']), 'review_note' => $cl['review_note'],
        'steps' => $steps, 'items' => $items, 'photos' => $photos, 'progress' => srcl_progress($items),
        'photo_max_per_step' => SRCL_PHOTO_MAX_PER_STEP,
        'locked' => srcl_edit_blocker($cl),
        'submit_blocker' => in_array($cl['status'], ['OPEN', 'RETURNED'], true) ? srcl_submit_blocker($steps, $job) : null,
    ];
}

/** For tech_completion_blocker(): a checklist job is completed by Management's approval. */
function srcl_completion_blocker(array $job): ?string
{
    if (!srcl_applies($job)) {
        return null;
    }
    $cl = srcl_for_job(db(), $job, false);
    if ($cl && $cl['status'] === 'SUBMITTED') {
        return 'The service checklist is waiting for Management approval — the request is completed when it is approved.';
    }
    return 'Open the checklist, finish every step with its proof photos and submit it. Management approves it to complete this request.';
}

/**
 * Management approved the checklist: the job becomes COMPLETED with everything
 * a completion sets off (history, the service request, project hooks,
 * availability), as in api/jobs/status.php. Call inside the caller's
 * transaction, job row locked. Returns the service-request changes to announce
 * after commit.
 */
function srcl_complete_job(PDO $pdo, array $job, string $note): array
{
    if (in_array($job['stage'], ['COMPLETED', 'CANCELLED'], true)) {
        return [];
    }
    $pdo->prepare("UPDATE jobs SET stage = 'COMPLETED', progress = 100 WHERE id = :id")->execute([':id' => $job['id']]);
    $pdo->prepare('INSERT INTO job_status_history (job_id, from_stage, to_stage, changed_by, note) VALUES (:j, :f, "COMPLETED", :u, :n)')
        ->execute([':j' => $job['id'], ':f' => $job['stage'], ':u' => current_user_id(), ':n' => mb_substr($note, 0, 255)]);
    $changed = sr_sync_from_job((int)$job['id'], 'COMPLETED', $note);
    project_on_job_stage($job, 'COMPLETED');
    // A subcontractor's assignment on this job closes with it.
    if (function_exists('sub_ready') && sub_ready()) {
        $a = $pdo->prepare('SELECT id, subcontractor_id, status FROM subcontractor_assignments WHERE active_job_id = :j');
        $a->execute([':j' => $job['id']]);
        if ($as = $a->fetch()) {
            $pdo->prepare("UPDATE subcontractor_assignments SET status = 'COMPLETED', completed_at = NOW(), completed_by = :u WHERE id = :id")
                ->execute([':u' => current_user_id(), ':id' => $as['id']]);
            sub_event($pdo, (int)$as['id'], (int)$as['subcontractor_id'], 'STATUS', $as['status'], 'COMPLETED', 'Service checklist approved by Management');
        }
    }
    if ($job['technician_id'] && !tech_active_field_jobs((int)$job['technician_id'], (int)$job['id'])
        && tech_availability((int)$job['technician_id']) === 'BUSY') {
        tech_set_availability((int)$job['technician_id'], 'AVAILABLE');
    }
    return $changed;
}
