<?php
/**
 * SunTrack ERP — two-step login (TOTP, RFC 6238).
 *
 * The standard used by Google Authenticator, Microsoft Authenticator, Authy
 * and 1Password: a shared secret, and a 6-digit code that changes every 30
 * seconds. Codes are accepted one step either side of "now" to allow for a
 * phone clock a little off, and each step can be used only once (replay
 * protection via users.totp_last_step).
 */

/** Roles that may (and are encouraged to) turn two-step login on. */
const TOTP_ROLES = ['admin', 'manager', 'staff', 'warehouse'];
const TOTP_PERIOD = 30;
const TOTP_DIGITS = 6;
/** Seconds a password-verified login may wait for its code. */
const TOTP_PENDING_TTL = 300;
/** Wrong codes allowed per pending login before the password is needed again. */
const TOTP_MAX_TRIES = 5;

function totp_base32_encode(string $bin): string
{
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $bits = '';
    foreach (str_split($bin) as $c) {
        $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
    }
    $out = '';
    foreach (str_split($bits, 5) as $chunk) {
        $out .= $alphabet[bindec(str_pad($chunk, 5, '0'))];
    }
    return $out;
}

function totp_base32_decode(string $b32): string
{
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $b32 = strtoupper(preg_replace('/[^A-Za-z2-7]/', '', $b32));
    $bits = '';
    foreach (str_split($b32) as $c) {
        $bits .= str_pad(decbin(strpos($alphabet, $c)), 5, '0', STR_PAD_LEFT);
    }
    $out = '';
    foreach (str_split($bits, 8) as $byte) {
        if (strlen($byte) === 8) {
            $out .= chr(bindec($byte));
        }
    }
    return $out;
}

/** A new random secret (160 bits, the RFC-recommended size), base32. */
function totp_new_secret(): string
{
    return totp_base32_encode(random_bytes(20));
}

/** The code for a given time step. */
function totp_code(string $secret, int $step): string
{
    $key = totp_base32_decode($secret);
    $msg = pack('N2', ($step >> 32) & 0xFFFFFFFF, $step & 0xFFFFFFFF);
    $hash = hash_hmac('sha1', $msg, $key, true);
    $offset = ord($hash[19]) & 0x0F;
    $value = ((ord($hash[$offset]) & 0x7F) << 24) | (ord($hash[$offset + 1]) << 16)
        | (ord($hash[$offset + 2]) << 8) | ord($hash[$offset + 3]);
    return str_pad((string)($value % (10 ** TOTP_DIGITS)), TOTP_DIGITS, '0', STR_PAD_LEFT);
}

/**
 * The time step a code matches (current ±1), or null. Steps at or before
 * $lastStep are refused, so an observed code cannot be replayed.
 */
function totp_match(string $secret, string $code, ?int $lastStep = null, ?int $now = null): ?int
{
    $code = preg_replace('/\s+/', '', $code);
    if (!preg_match('/^\d{' . TOTP_DIGITS . '}$/', $code)) {
        return null;
    }
    $current = intdiv($now ?? time(), TOTP_PERIOD);
    foreach ([0, -1, 1] as $drift) {
        $step = $current + $drift;
        if ($lastStep !== null && $step <= $lastStep) {
            continue;
        }
        if (hash_equals(totp_code($secret, $step), $code)) {
            return $step;
        }
    }
    return null;
}

/** otpauth:// link the authenticator app reads from the QR code. */
function totp_uri(string $secret, string $account): string
{
    $issuer = APP_NAME;
    return 'otpauth://totp/' . rawurlencode($issuer . ':' . $account)
        . '?secret=' . $secret . '&issuer=' . rawurlencode($issuer) . '&period=' . TOTP_PERIOD . '&digits=' . TOTP_DIGITS;
}

/** Whether a user has two-step login on. False if phase 7 is not imported. */
function totp_enabled_for(int $userId): bool
{
    try {
        $stmt = db()->prepare('SELECT totp_enabled FROM users WHERE id = :id');
        $stmt->execute([':id' => $userId]);
        return (bool)$stmt->fetchColumn();
    } catch (PDOException $e) {
        return false;
    }
}

/** Eight one-time backup codes like "k7p2-9xqm", returned in plain text once. */
function totp_new_recovery_codes(int $userId): array
{
    $alphabet = 'abcdefghjkmnpqrstuvwxyz23456789';
    $codes = [];
    $pdo = db();
    $pdo->prepare('DELETE FROM user_recovery_codes WHERE user_id = :u')->execute([':u' => $userId]);
    $ins = $pdo->prepare('INSERT INTO user_recovery_codes (user_id, code_hash, created_at) VALUES (:u, :h, :t)');
    for ($i = 0; $i < 8; $i++) {
        $c = '';
        for ($j = 0; $j < 8; $j++) {
            $c .= $alphabet[random_int(0, strlen($alphabet) - 1)];
        }
        $c = substr($c, 0, 4) . '-' . substr($c, 4);
        $codes[] = $c;
        $ins->execute([':u' => $userId, ':h' => password_hash($c, PASSWORD_DEFAULT), ':t' => date('Y-m-d H:i:s')]);
    }
    return $codes;
}

/** Use up a backup code. True if it was valid and unused. */
function totp_use_recovery_code(int $userId, string $code): bool
{
    $code = strtolower(trim($code));
    if (!preg_match('/^[a-z0-9]{4}-?[a-z0-9]{4}$/', $code)) {
        return false;
    }
    if (strlen($code) === 8) {
        $code = substr($code, 0, 4) . '-' . substr($code, 4);
    }
    $stmt = db()->prepare('SELECT id, code_hash FROM user_recovery_codes WHERE user_id = :u AND used_at IS NULL');
    $stmt->execute([':u' => $userId]);
    foreach ($stmt->fetchAll() as $row) {
        if (password_verify($code, $row['code_hash'])) {
            db()->prepare('UPDATE user_recovery_codes SET used_at = :t WHERE id = :id')
                ->execute([':t' => date('Y-m-d H:i:s'), ':id' => $row['id']]);
            return true;
        }
    }
    return false;
}

/**
 * Check a code for a user with two-step login on: an authenticator code
 * (with replay protection) or a backup code. True on success.
 */
function totp_verify_user(int $userId, string $code): bool
{
    $stmt = db()->prepare('SELECT totp_secret, totp_last_step FROM users WHERE id = :id AND totp_enabled = 1');
    $stmt->execute([':id' => $userId]);
    $row = $stmt->fetch();
    if (!$row || !$row['totp_secret']) {
        return false;
    }
    $step = totp_match($row['totp_secret'], $code, $row['totp_last_step'] !== null ? (int)$row['totp_last_step'] : null);
    if ($step !== null) {
        db()->prepare('UPDATE users SET totp_last_step = :s WHERE id = :id')->execute([':s' => $step, ':id' => $userId]);
        return true;
    }
    return totp_use_recovery_code($userId, $code);
}
