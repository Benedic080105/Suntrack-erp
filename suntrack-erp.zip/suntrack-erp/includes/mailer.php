<?php
/**
 * SunTrack ERP — outgoing email.
 *
 * One function, send_mail(), used by every feature that emails someone.
 * Returns true/false and NEVER throws, so a mail problem can never break the
 * request that triggered it — callers decide what to do on false.
 *
 * Transport (config/env.php or environment variables):
 *
 *   SMTP — recommended, and required for Gmail to accept the message:
 *     SUNTRACK_SMTP_HOST     smtp.gmail.com
 *     SUNTRACK_SMTP_PORT     587            (465 for SSL)
 *     SUNTRACK_SMTP_SECURE   tls            (STARTTLS on 587) | ssl (465)
 *     SUNTRACK_SMTP_USER     yourname@gmail.com
 *     SUNTRACK_SMTP_PASS     the 16-letter Google *App Password* (not your normal password)
 *     SUNTRACK_MAIL_FROM     yourname@gmail.com   (Gmail requires From = the login)
 *     SUNTRACK_MAIL_FROM_NAME  SunTrack ERP      (optional)
 *
 *   PHP mail() — used only when no SMTP host is set. Works on some hosts but
 *   Gmail often rejects or spam-folders it, because it is not authenticated.
 *
 * The SMTP client below is deliberately small: STARTTLS / SSL, AUTH LOGIN,
 * one recipient, text + HTML. It verifies the server's TLS certificate, has a
 * hard timeout so a dead mail server cannot hang a page, and never writes the
 * password to any log.
 */

/** How long to wait on the mail server before giving up, in seconds. */
const MAIL_TIMEOUT_SECONDS = 12;

/**
 * Send one email. $html is optional; the plain-text version is always sent
 * too, so every mail app can read it.
 */
function send_mail(string $to, string $subject, string $text, ?string $html = null): bool
{
    try {
        $to = trim($to);
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            error_log("SunTrack mail: invalid recipient address");
            return false;
        }

        $host = app_env('SUNTRACK_SMTP_HOST');
        $from = mail_from_address();
        $fromName = mail_header_safe(app_env('SUNTRACK_MAIL_FROM_NAME', APP_NAME));
        $subject = mail_header_safe($subject);

        $message = mail_build_message($from, $fromName, $to, $subject, $text, $html);

        if ($host !== null) {
            return smtp_send($host, $from, $to, $message);
        }

        // Fallback: PHP mail(). Headers and body are split back apart for it.
        [$headers, $body] = explode("\r\n\r\n", $message, 2);
        $headers = preg_replace('/^(To|Subject): .*\r\n/mi', '', $headers . "\r\n");
        $ok = @mail($to, mail_encode_header($subject), $body, rtrim($headers));
        if (!$ok) {
            error_log('SunTrack mail: PHP mail() could not send "' . $subject . '". Configure SUNTRACK_SMTP_* for reliable delivery.');
        }
        return (bool)$ok;
    } catch (Throwable $e) {
        error_log('SunTrack mail: ' . $e->getMessage());
        return false;
    }
}

/** Whether an outgoing mail server is configured at all. */
function mail_is_configured(): bool
{
    return app_env('SUNTRACK_SMTP_HOST') !== null;
}

/** The From address: configured, else the SMTP login, else no-reply@<site>. */
function mail_from_address(): string
{
    $from = app_env('SUNTRACK_MAIL_FROM') ?? app_env('SUNTRACK_SMTP_USER');
    if ($from === null || !filter_var($from, FILTER_VALIDATE_EMAIL)) {
        $site = app_env('SUNTRACK_APP_URL');
        $host = $site ? parse_url($site, PHP_URL_HOST) : null;
        $from = 'no-reply@' . preg_replace('/^www\./', '', $host ?: 'localhost.localdomain');
    }
    return mail_header_safe($from);
}

/** Strip anything that could break out of a header line (header injection). */
function mail_header_safe(string $value): string
{
    return trim(str_replace(["\r", "\n", "\0"], ' ', $value));
}

/** RFC 2047-encode a header value when it is not plain ASCII (e.g. "—", "ñ"). */
function mail_encode_header(string $value): string
{
    return preg_match('/[^\x20-\x7E]/', $value) ? '=?UTF-8?B?' . base64_encode($value) . '?=' : $value;
}

/** A complete RFC 5322 message (headers + body) with CRLF line endings. */
function mail_build_message(string $from, string $fromName, string $to, string $subject, string $text, ?string $html): string
{
    $domain = substr(strrchr($from, '@'), 1) ?: 'localhost';
    $headers = [
        'Date: ' . date(DATE_RFC2822),
        'From: ' . mail_encode_header($fromName) . ' <' . $from . '>',
        'To: <' . $to . '>',
        'Subject: ' . mail_encode_header($subject),
        'Message-ID: <' . bin2hex(random_bytes(12)) . '@' . $domain . '>',
        'MIME-Version: 1.0',
        'X-Mailer: SunTrack ERP',
        'Auto-Submitted: auto-generated',
    ];

    $b64 = fn(string $s) => rtrim(chunk_split(base64_encode($s), 76, "\r\n"));
    $text = str_replace(["\r\n", "\r"], "\n", $text);

    if ($html === null) {
        $headers[] = 'Content-Type: text/plain; charset=UTF-8';
        $headers[] = 'Content-Transfer-Encoding: base64';
        $body = $b64($text);
    } else {
        $boundary = 'st_' . bin2hex(random_bytes(10));
        $headers[] = 'Content-Type: multipart/alternative; boundary="' . $boundary . '"';
        $body = "--$boundary\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"
            . $b64($text) . "\r\n"
            . "--$boundary\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"
            . $b64($html) . "\r\n"
            . "--$boundary--";
    }

    return implode("\r\n", $headers) . "\r\n\r\n" . $body . "\r\n";
}

/**
 * Deliver $message over SMTP. Every step checks the server's reply code; any
 * failure is logged (without secrets) and returns false.
 */
function smtp_send(string $host, string $from, string $to, string $message): bool
{
    $port   = (int)app_env('SUNTRACK_SMTP_PORT', '587');
    $secure = strtolower((string)app_env('SUNTRACK_SMTP_SECURE', $port === 465 ? 'ssl' : 'tls'));
    $user   = app_env('SUNTRACK_SMTP_USER');
    $pass   = app_env('SUNTRACK_SMTP_PASS');
    if ($pass !== null) {
        $pass = str_replace(' ', '', $pass); // Google shows App Passwords as "abcd efgh ijkl mnop"
    }

    // "none" (no encryption) is only for a mail catcher on this same machine,
    // e.g. Mailpit during development — never to send a password across a network.
    if ($secure === 'none' && !in_array(strtolower($host), ['localhost', '127.0.0.1', '::1'], true)) {
        error_log('SunTrack mail: SUNTRACK_SMTP_SECURE=none is only allowed for localhost; refusing to send unencrypted.');
        return false;
    }
    if (!in_array($secure, ['tls', 'ssl', 'none'], true)) {
        error_log("SunTrack mail: SUNTRACK_SMTP_SECURE must be tls, ssl or none (got '$secure').");
        return false;
    }

    $tls = ['ssl' => ['verify_peer' => true, 'verify_peer_name' => true, 'peer_name' => $host, 'SNI_enabled' => true]];
    // Windows PHP builds (XAMPP) often ship without a CA bundle, so certificate
    // checks fail. Point SUNTRACK_SMTP_CAFILE at a cacert.pem instead of
    // turning verification off.
    $caFile = app_env('SUNTRACK_SMTP_CAFILE');
    if ($caFile !== null && is_file($caFile)) {
        $tls['ssl']['cafile'] = $caFile;
    }
    $ctx = stream_context_create($tls);
    $remote = ($secure === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port;

    $errno = 0; $errstr = '';
    $fp = @stream_socket_client($remote, $errno, $errstr, MAIL_TIMEOUT_SECONDS, STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) {
        error_log("SunTrack mail: cannot connect to $host:$port ($errstr)");
        return false;
    }
    stream_set_timeout($fp, MAIL_TIMEOUT_SECONDS);

    $step = 'greeting';
    try {
        smtp_expect($fp, [220], $step);
        $ehloName = preg_replace('/[^A-Za-z0-9.\-]/', '', (string)($_SERVER['SERVER_NAME'] ?? gethostname() ?: 'localhost')) ?: 'localhost';

        $step = 'EHLO';
        $caps = smtp_cmd($fp, "EHLO $ehloName", [250], $step);

        if ($secure === 'tls') {
            $step = 'STARTTLS';
            if (stripos($caps, 'STARTTLS') === false) {
                throw new RuntimeException('server does not offer STARTTLS; refusing to send the password in clear text');
            }
            smtp_cmd($fp, 'STARTTLS', [220], $step);
            $method = STREAM_CRYPTO_METHOD_TLS_CLIENT;
            if (defined('STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT')) {
                $method |= STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT;
            }
            if (defined('STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT')) {
                $method |= STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT;
            }
            if (!@stream_socket_enable_crypto($fp, true, $method)) {
                throw new RuntimeException('TLS handshake failed (check the server certificate / PHP openssl)');
            }
            $step = 'EHLO after TLS';
            smtp_cmd($fp, "EHLO $ehloName", [250], $step);
        }

        if ($user !== null && $pass !== null) {
            $step = 'AUTH';
            smtp_cmd($fp, 'AUTH LOGIN', [334], $step);
            smtp_cmd($fp, base64_encode($user), [334], $step);
            smtp_cmd($fp, base64_encode($pass), [235], $step);
        }

        $step = 'MAIL FROM';
        smtp_cmd($fp, "MAIL FROM:<$from>", [250], $step);
        $step = 'RCPT TO';
        smtp_cmd($fp, "RCPT TO:<$to>", [250, 251], $step);
        $step = 'DATA';
        smtp_cmd($fp, 'DATA', [354], $step);

        // Dot-stuffing: a line starting with "." must be doubled.
        $data = preg_replace('/^\./m', '..', $message);
        fwrite($fp, $data . "\r\n.\r\n");
        $step = 'message body';
        smtp_expect($fp, [250], $step);

        // The message is accepted at this point; a clean goodbye is courtesy,
        // so any problem here no longer changes the result.
        try {
            smtp_cmd($fp, 'QUIT', [221], 'QUIT');
        } catch (Throwable $e) {
            // ignore
        }
        @fclose($fp);
        return true;
    } catch (Throwable $e) {
        error_log("SunTrack mail: SMTP failed at $step on $host:$port — " . $e->getMessage());
        @fwrite($fp, "QUIT\r\n");
        @fclose($fp);
        return false;
    }
}

/**
 * Send one SMTP command and require one of $codes. The command itself is never
 * logged, so the base64 login and password cannot end up in an error log.
 */
function smtp_cmd($fp, string $line, array $codes, string $step): string
{
    if (@fwrite($fp, $line . "\r\n") === false) {
        throw new RuntimeException('connection closed');
    }
    return smtp_expect($fp, $codes, $step);
}

/** Read a (possibly multi-line) reply and check its code. */
function smtp_expect($fp, array $codes, string $step): string
{
    $reply = '';
    while (($line = fgets($fp, 1024)) !== false) {
        $reply .= $line;
        // "250-..." continues, "250 ..." ends the reply.
        if (strlen($line) < 4 || $line[3] === ' ') {
            break;
        }
    }
    $meta = stream_get_meta_data($fp);
    if (!empty($meta['timed_out'])) {
        throw new RuntimeException('timed out waiting for the server');
    }
    $code = (int)substr($reply, 0, 3);
    if (!in_array($code, $codes, true)) {
        // Replies can echo what we sent, but never the password: AUTH replies
        // are fixed server text. Trim to keep logs short.
        throw new RuntimeException("unexpected reply at $step: " . trim(substr($reply, 0, 200)));
    }
    return $reply;
}
