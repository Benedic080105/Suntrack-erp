<?php
/**
 * SunTrack ERP — site size and installation crews.
 *
 *   Site size   worked out from the system's kW:
 *                 SMALL   below 5 kW        -> 1 technician
 *                 MEDIUM  5 to below 10 kW  -> 2 technicians
 *                 LARGE   10 kW and up      -> 4 technicians
 *               (thresholds and crew sizes are settings: crew_small_max_kw,
 *               crew_medium_max_kw, crew_size_small / _medium / _large)
 *
 *   Crew        the lead technician is projects.assigned_technician_id (and
 *               the installation job's technician_id). Helpers are rows in
 *               project_crew. Every crew member sees the job, times in and out,
 *               ticks the checklist and adds photos; only the lead moves the
 *               job's stage, submits a stage for review and files the report.
 *
 *   Auto-pick   ranks active technicians for a date: not on leave / off duty,
 *               free that day (no other job or installation visit booked), then
 *               the fewest open jobs — and takes the top N.
 *
 * Degrades safely before database/phase14_project_crew.sql is run.
 */

const CREW_SIZES = ['SMALL', 'MEDIUM', 'LARGE'];

function crew_available(): bool
{
    static $ok = null;
    if ($ok === null) {
        try {
            db()->query('SELECT 1 FROM project_crew LIMIT 0');
            db()->query('SELECT site_size, crew_size FROM projects LIMIT 0');
            $ok = true;
        } catch (PDOException $e) {
            $ok = false;
        }
    }
    return $ok;
}

/** The size rules, from settings with sensible defaults. */
function crew_rules(): array
{
    return [
        'small_max_kw'  => (float)setting('crew_small_max_kw', 5),
        'medium_max_kw' => (float)setting('crew_medium_max_kw', 10),
        'crew'          => [
            'SMALL'  => max(1, setting_int('crew_size_small', 1)),
            'MEDIUM' => max(1, setting_int('crew_size_medium', 2)),
            'LARGE'  => max(1, setting_int('crew_size_large', 4)),
        ],
        'labels'        => ['SMALL' => 'Small', 'MEDIUM' => 'Medium', 'LARGE' => 'Large'],
    ];
}

/** SMALL / MEDIUM / LARGE for a capacity in kW, or null when unknown. */
function crew_site_size(?float $kw): ?string
{
    if ($kw === null || $kw <= 0) {
        return null;
    }
    $r = crew_rules();
    return $kw < $r['small_max_kw'] ? 'SMALL' : ($kw < $r['medium_max_kw'] ? 'MEDIUM' : 'LARGE');
}

/** Recommended number of technicians for a size (1 when the size is unknown). */
function crew_recommended(?string $size): int
{
    return $size ? (crew_rules()['crew'][$size] ?? 1) : 1;
}

/** Helper technician ids on a project (the lead is not included). */
function crew_members(int $projectId): array
{
    if (!crew_available()) {
        return [];
    }
    $stmt = db()->prepare('SELECT technician_id FROM project_crew WHERE project_id = :p ORDER BY created_at, technician_id');
    $stmt->execute([':p' => $projectId]);
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}

/**
 * Everyone on a project's crew: [['id', 'code', 'name', 'is_lead'], ...], lead first.
 */
function crew_list(int $projectId): array
{
    $stmt = db()->prepare('SELECT assigned_technician_id FROM projects WHERE id = :p');
    $stmt->execute([':p' => $projectId]);
    $lead = (int)$stmt->fetchColumn();
    $ids = array_values(array_unique(array_filter(array_merge([$lead], crew_members($projectId)))));
    if (!$ids) {
        return [];
    }
    $in = implode(',', array_map('intval', $ids)); // integers from the DB
    $rows = db()->query(
        "SELECT t.id, t.technician_code AS code, u.full_name AS name, u.phone
         FROM technicians t JOIN users u ON u.id = t.user_id WHERE t.id IN ($in)"
    )->fetchAll();
    $byId = array_column($rows, null, 'id');
    $out = [];
    foreach ($ids as $id) {
        if (isset($byId[$id])) {
            $out[] = $byId[$id] + ['is_lead' => $id === $lead];
            $out[count($out) - 1]['id'] = (int)$id;
        }
    }
    return $out;
}

/**
 * Replace a project's helpers. The lead is never stored as a helper.
 * Call inside the caller's transaction. Returns the ids newly added.
 */
function crew_set_members(int $projectId, ?int $leadId, array $memberIds): array
{
    if (!crew_available()) {
        return [];
    }
    $pdo = db();
    $want = array_values(array_unique(array_filter(array_map('intval', $memberIds), fn($id) => $id > 0 && $id !== $leadId)));
    if ($want) {
        $in = implode(',', $want);
        $found = array_map('intval', $pdo->query("SELECT id FROM " . tech_staff_table() . " t WHERE id IN ($in)")->fetchAll(PDO::FETCH_COLUMN));
        if (count($found) !== count($want)) {
            json_error('One of the selected technicians was not found.', 422);
        }
    }
    $before = crew_members($projectId);
    $pdo->prepare('DELETE FROM project_crew WHERE project_id = :p')->execute([':p' => $projectId]);
    $ins = $pdo->prepare('INSERT INTO project_crew (project_id, technician_id, added_by) VALUES (:p, :t, :u)');
    foreach ($want as $t) {
        $ins->execute([':p' => $projectId, ':t' => $t, ':u' => current_user_id()]);
    }
    return array_values(array_diff($want, $before));
}

/**
 * Every active technician with what Management needs to choose a crew:
 * availability, open jobs, and whether they already have work booked on $date.
 * Sorted best first (the order auto-pick uses).
 */
function crew_candidates(?string $date, ?int $exceptProjectId = null): array
{
    $pdo = db();
    $rows = $pdo->query(
        "SELECT t.id, t.technician_code AS code, u.full_name AS name, t.specialization,
                COALESCE(ta.status, 'AVAILABLE') AS availability,
                (SELECT COUNT(*) FROM jobs j WHERE j.technician_id = t.id AND j.stage NOT IN ('COMPLETED','CANCELLED')) AS open_jobs
         FROM " . tech_staff_table() . " t
         JOIN users u ON u.id = t.user_id
         LEFT JOIN technician_availability ta ON ta.technician_id = t.id
         WHERE u.status = 'ACTIVE'"
    )->fetchAll();

    $booked = $date ? crew_booked_on($date, $exceptProjectId) : [];
    foreach ($rows as &$r) {
        $r['id'] = (int)$r['id'];
        $r['open_jobs'] = (int)$r['open_jobs'];
        $r['booked'] = $booked[$r['id']] ?? null;       // e.g. "JOB-2026-1004" — already working that day
        $r['away'] = in_array($r['availability'], ['ON_LEAVE', 'OFF_DUTY'], true);
        $r['eligible'] = !$r['away'] && $r['booked'] === null;
    }
    unset($r);
    // Free first, then AVAILABLE before BUSY, then the lightest workload, then by name.
    $rank = fn($r) => [$r['eligible'] ? 0 : 1, $r['availability'] === 'AVAILABLE' ? 0 : 1, $r['open_jobs'], $r['name']];
    usort($rows, fn($a, $b) => $rank($a) <=> $rank($b));
    return $rows;
}

/**
 * Technicians who already have work on $date: [technician_id => job code].
 * Counts jobs scheduled that day and installation stage visits booked that day,
 * for leads and helpers alike.
 */
function crew_booked_on(string $date, ?int $exceptProjectId = null): array
{
    $pdo = db();
    $out = [];
    $add = function (array $rows) use (&$out) {
        foreach ($rows as $r) {
            $out[(int)$r['tech']] ??= $r['code'];
        }
    };
    $params = [':d' => $date, ':x' => (int)$exceptProjectId];
    $notThis = '(j.project_id IS NULL OR j.project_id <> :x)';

    $s = $pdo->prepare("SELECT j.technician_id AS tech, j.job_code AS code FROM jobs j
                        WHERE j.technician_id IS NOT NULL AND j.stage NOT IN ('COMPLETED','CANCELLED') AND j.scheduled_date = :d AND $notThis");
    $s->execute($params);
    $add($s->fetchAll());

    if (install_plan_available()) {
        $s = $pdo->prepare("SELECT j.technician_id AS tech, j.job_code AS code FROM installation_stage_plan sp JOIN jobs j ON j.id = sp.job_id
                            WHERE sp.status IN ('SCHEDULED','RETURNED') AND sp.scheduled_date = :d AND j.technician_id IS NOT NULL AND $notThis");
        $s->execute($params);
        $add($s->fetchAll());
    }
    if (crew_available()) {
        // Helpers are booked whenever their project's job is.
        $s = $pdo->prepare("SELECT pc.technician_id AS tech, j.job_code AS code FROM project_crew pc
                            JOIN jobs j ON j.project_id = pc.project_id AND j.job_type = 'INSTALLATION' AND j.stage NOT IN ('COMPLETED','CANCELLED')
                            LEFT JOIN installation_stage_plan sp ON sp.job_id = j.id AND sp.status IN ('SCHEDULED','RETURNED') AND sp.scheduled_date = :d2
                            WHERE (j.scheduled_date = :d OR sp.id IS NOT NULL) AND $notThis");
        $s->execute($params + [':d2' => $date]);
        $add($s->fetchAll());
    }
    return $out;
}

/** The $n best free technicians for $date (ids, best first). May return fewer when not enough are free. */
function crew_auto_pick(int $n, ?string $date, ?int $exceptProjectId = null): array
{
    $ids = [];
    foreach (crew_candidates($date, $exceptProjectId) as $c) {
        if (count($ids) >= $n) {
            break;
        }
        if ($c['eligible']) {
            $ids[] = $c['id'];
        }
    }
    return $ids;
}

/**
 * The next day (from $from, Sundays skipped) on which every technician in
 * $techIds is free. Looks up to 30 days ahead; falls back to $from.
 */
function crew_next_free_day(array $techIds, string $from, ?int $exceptProjectId = null): string
{
    $techIds = array_map('intval', $techIds);
    $day = $from;
    for ($i = 0; $i < 30; $i++) {
        if (date('w', strtotime($day)) !== '0') {
            $booked = crew_booked_on($day, $exceptProjectId);
            if (!array_intersect($techIds, array_keys($booked))) {
                return $day;
            }
        }
        $day = date('Y-m-d', strtotime($day . ' +1 day'));
    }
    return $from;
}

/**
 * Read the size and crew parts of the project form (create and update share it).
 *
 *   site_size        SMALL / MEDIUM / LARGE, or blank = work it out from kW
 *   crew_size        1–10, or blank = the size's recommendation
 *   crew_ids[]       the technicians picked (any order)
 *   assigned_technician_id  the lead; must be one of crew_ids (default: the first)
 *   auto_crew        true = let the system pick the best free crew for the date
 *
 * Returns ['present' => bool (the form sent crew fields at all), 'site_size',
 * 'crew_size', 'lead', 'members' (helpers, lead excluded), 'auto' (picked by the system)].
 */
function crew_read_input(array $input, ?float $capacity, ?string $date, ?int $projectId = null): array
{
    $size = strtoupper(trim((string)($input['site_size'] ?? '')));
    if ($size !== '' && !in_array($size, CREW_SIZES, true)) {
        json_error('Site size must be Small, Medium or Large.', 422);
    }
    $size = $size !== '' ? $size : crew_site_size($capacity);

    $crewSize = trim((string)($input['crew_size'] ?? ''));
    if ($crewSize !== '' && (!ctype_digit($crewSize) || (int)$crewSize < 1 || (int)$crewSize > 10)) {
        json_error('Crew size must be between 1 and 10 technicians.', 422);
    }
    $crewSize = $crewSize !== '' ? (int)$crewSize : crew_recommended($size);

    $present = array_key_exists('crew_ids', $input) || !empty($input['auto_crew']);
    $ids = array_values(array_unique(array_filter(array_map('intval', (array)($input['crew_ids'] ?? [])))));
    $auto = false;
    if (!empty($input['auto_crew']) && !$ids) {
        $ids = crew_auto_pick($crewSize, $date, $projectId);
        $auto = true;
        if (!$ids) {
            json_error('No technician is free' . ($date ? ' on ' . date('M j, Y', strtotime($date)) : '') . '. Pick a crew by hand or choose another date.', 422);
        }
    }
    if (count($ids) > 10) {
        json_error('A crew can have at most 10 technicians.', 422);
    }

    $lead = !empty($input['assigned_technician_id']) ? (int)$input['assigned_technician_id'] : ($ids[0] ?? null);
    if ($lead && $ids && !in_array($lead, $ids, true)) {
        array_unshift($ids, $lead); // the lead is always on the crew
    }
    return [
        'present'   => $present,
        'site_size' => $size,
        'crew_size' => $crewSize,
        'lead'      => $lead,
        'members'   => array_values(array_filter($ids, fn($id) => $id !== $lead)),
        'auto'      => $auto,
    ];
}

/** Tell newly added helpers they are on an installation crew. */
function crew_notify_added(int $projectId, array $techIds): void
{
    if (!$techIds) {
        return;
    }
    $p = db()->prepare(
        "SELECT p.project_code, p.site_name, p.installation_date, lu.full_name AS lead_name,
                (SELECT j.id FROM jobs j WHERE j.project_id = p.id AND j.job_type = 'INSTALLATION' AND j.stage NOT IN ('COMPLETED','CANCELLED') ORDER BY j.id DESC LIMIT 1) AS job_id
         FROM projects p LEFT JOIN technicians lt ON lt.id = p.assigned_technician_id LEFT JOIN users lu ON lu.id = lt.user_id
         WHERE p.id = :p"
    );
    $p->execute([':p' => $projectId]);
    $p = $p->fetch();
    if (!$p) {
        return;
    }
    $in = implode(',', array_map('intval', $techIds));
    $msg = "You've been added to the installation crew for {$p['project_code']} — {$p['site_name']}"
         . ($p['lead_name'] ? " (lead: {$p['lead_name']})" : '')
         . ($p['installation_date'] ? ', starting ' . date('M j, Y', strtotime($p['installation_date'])) : '') . '.';
    foreach (db()->query("SELECT user_id FROM technicians WHERE id IN ($in)")->fetchAll(PDO::FETCH_COLUMN) as $uid) {
        notify((int)$uid, 'JOB_STATUS', str_cut($msg, 0, 250), $p['job_id'] ? 'jobs' : 'projects', (int)($p['job_id'] ?: $projectId));
    }
}

/** SQL condition: job :alias is one this technician works on (lead, or helper on its installation). */
function crew_job_condition(string $alias, string $param): string
{
    if (!crew_available()) {
        return "$alias.technician_id = $param";
    }
    return "($alias.technician_id = $param OR ($alias.job_type = 'INSTALLATION' AND $alias.project_id IN "
         . "(SELECT pcx.project_id FROM project_crew pcx WHERE pcx.technician_id = {$param}c)))";
}

/** True when $techId is a helper (not the lead) on the job's installation crew. */
function crew_is_helper(array $job, int $techId): bool
{
    if ((int)($job['technician_id'] ?? 0) === $techId || empty($job['project_id']) || ($job['job_type'] ?? '') !== 'INSTALLATION') {
        return false;
    }
    return in_array($techId, crew_members((int)$job['project_id']), true);
}

/** users.id of every crew member on a job (lead + helpers), for notifications. */
function crew_user_ids_for_job(array $job): array
{
    $techIds = array_filter([(int)($job['technician_id'] ?? 0)]);
    if (!empty($job['project_id']) && ($job['job_type'] ?? '') === 'INSTALLATION') {
        $techIds = array_merge($techIds, crew_members((int)$job['project_id']));
    }
    $techIds = array_values(array_unique($techIds));
    if (!$techIds) {
        return [];
    }
    $in = implode(',', array_map('intval', $techIds));
    return array_map('intval', db()->query("SELECT user_id FROM technicians WHERE id IN ($in)")->fetchAll(PDO::FETCH_COLUMN));
}
