<?php
/**
 * SunTrack ERP — Service Requests (Phase 5) shared logic.
 *
 * One place for the rules every service-request endpoint shares: the allowed
 * service types / statuses / priorities, the history trail, who gets notified,
 * and how a request follows its linked job.
 *
 * The request itself lives in the existing `service_requests` table. Assigning
 * a technician creates (or reuses) a row in `jobs`, and from then on the
 * technician works the JOB — GPS Time In, checklist / inspection, work report,
 * Time Out — exactly as before. sr_sync_from_job() keeps the request's status
 * in step with that job, so the geofence and completion gates are never
 * bypassed by a second, parallel workflow.
 */

/** Service types offered on every "new request" form. Stored in request_type. */
function sr_service_types(): array
{
    return [
        'Maintenance', 'Repair', 'Inspection', 'Replacement', 'Installation Support',
        'Panel Issue', 'Battery Issue', 'Inverter Issue', 'Other',
    ];
}

/** Every status a request can hold, in workflow order. */
function sr_statuses(): array
{
    return ['PENDING', 'APPROVED', 'ASSIGNED', 'SCHEDULED', 'IN_PROGRESS', 'ON_HOLD', 'COMPLETED', 'CANCELLED', 'REJECTED'];
}

/** Statuses after which a request can no longer move. */
function sr_closed_statuses(): array
{
    return ['COMPLETED', 'CANCELLED', 'REJECTED'];
}

function sr_priorities(): array
{
    return ['LOW', 'NORMAL', 'HIGH', 'URGENT'];
}

/**
 * The jobs.job_type a request becomes when a technician is assigned.
 * MAINTENANCE and INSPECTION reuse the existing inspection flow; everything
 * else is field repair work. INSTALLATION is deliberately never produced here:
 * that type carries the 17-item installation checklist, which a service visit
 * does not have.
 */
function sr_job_type_for(string $serviceType): string
{
    return match ($serviceType) {
        'Maintenance' => 'MAINTENANCE',
        'Inspection'  => 'INSPECTION',
        default       => 'REPAIR',
    };
}

/**
 * True once database/phase5_service_requests.sql has been imported.
 * Cached for the request. Endpoints written for Phase 5 call
 * sr_require_phase5(); shared code (job status, maps) uses this to keep
 * working on a database that has not been migrated yet.
 */
function sr_phase5_ready(): bool
{
    static $ready = null;
    if ($ready !== null) {
        return $ready;
    }
    try {
        $n = (int)db()->query(
            "SELECT COUNT(*) FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()
               AND ((TABLE_NAME = 'service_requests' AND COLUMN_NAME IN ('subject', 'scheduled_date', 'resolution'))
                 OR (TABLE_NAME = 'service_request_history' AND COLUMN_NAME = 'service_request_id')
                 OR (TABLE_NAME = 'clients' AND COLUMN_NAME = 'barangay'))"
        )->fetchColumn();
        $ready = $n === 5;
    } catch (Throwable $e) {
        $ready = false;
    }
    return $ready;
}

/** Stop with a clear 503 when the Phase 5 migration has not been imported. */
function sr_require_phase5(): void
{
    if (!sr_phase5_ready()) {
        json_error('Service Requests (Phase 5) are not set up yet. Import database/phase5_service_requests.sql.', 503);
    }
}

/**
 * Append one row to the request's history.
 *
 * Never throws: a history row is an audit nicety, and it must not be the
 * reason a technician's job update or a Management assignment fails.
 */
function sr_log(int $srId, string $action, ?string $oldStatus, ?string $newStatus, ?string $remarks = null, ?int $userId = null): void
{
    if (!sr_phase5_ready()) {
        return;
    }
    try {
        db()->prepare(
            'INSERT INTO service_request_history (service_request_id, user_id, action, old_status, new_status, remarks)
             VALUES (:sr, :u, :a, :o, :n, :r)'
        )->execute([
            ':sr' => $srId,
            ':u'  => $userId ?? current_user_id(),
            ':a'  => str_cut($action, 0, 40),
            ':o'  => $oldStatus,
            ':n'  => $newStatus,
            ':r'  => ($remarks !== null && trim($remarks) !== '') ? str_cut(trim($remarks), 0, 1000) : null,
        ]);
    } catch (Throwable $e) {
        error_log('SunTrack service request history: ' . $e->getMessage());
    }
}

/** users.id of every active Management account (manager / staff). */
function sr_management_user_ids(): array
{
    $rows = db()->query(
        "SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id
         WHERE r.role_key IN ('manager','staff') AND u.status = 'ACTIVE'"
    )->fetchAll();
    return array_map(fn($r) => (int)$r['id'], $rows);
}

/** Notify every Management account about a request. */
function sr_notify_management(string $message, int $srId): void
{
    foreach (sr_management_user_ids() as $uid) {
        notify($uid, 'SERVICE_REQUEST', $message, 'service_requests', $srId);
    }
}

/** users.id behind a clients.id, or null. */
function sr_client_user_id(int $clientId): ?int
{
    $stmt = db()->prepare('SELECT user_id FROM clients WHERE id = :id');
    $stmt->execute([':id' => $clientId]);
    $id = $stmt->fetchColumn();
    return $id ? (int)$id : null;
}

/** users.id behind a technicians.id, or null. */
function sr_technician_user_id(?int $techId): ?int
{
    if (!$techId) {
        return null;
    }
    $stmt = db()->prepare('SELECT user_id FROM technicians WHERE id = :id');
    $stmt->execute([':id' => $techId]);
    $id = $stmt->fetchColumn();
    return $id ? (int)$id : null;
}

/** Notify the client who owns a request. */
function sr_notify_client(array $sr, string $message): void
{
    $uid = sr_client_user_id((int)$sr['client_id']);
    if ($uid) {
        notify($uid, 'SERVICE_REQUEST', $message, 'service_requests', (int)$sr['id']);
    }
}

/** Notify the technician assigned to a request (if any). */
function sr_notify_technician(?int $techId, string $message, int $srId): void
{
    $uid = sr_technician_user_id($techId);
    if ($uid) {
        notify($uid, 'SERVICE_REQUEST', $message, 'service_requests', $srId);
    }
}

/** Display name for a request in messages: "SR-2026-004 (Inverter Issue)". */
function sr_label(array $sr): string
{
    $what = trim((string)($sr['subject'] ?? '')) !== '' ? $sr['subject'] : ($sr['request_type'] ?? '');
    return $sr['request_code'] . ($what !== '' ? ' (' . $what . ')' : '');
}

/** Lock and return one request row, or null. Caller must be in a transaction. */
function sr_lock(int $srId): ?array
{
    $stmt = db()->prepare('SELECT * FROM service_requests WHERE id = :id FOR UPDATE');
    $stmt->execute([':id' => $srId]);
    return $stmt->fetch() ?: null;
}

/**
 * The request status that matches a job stage.
 *
 * ASSIGNED/SUBMITTED fall back to SCHEDULED when a date is set, so undoing a
 * technician's "Start Travel" puts the request back where it was.
 */
function sr_status_for_job_stage(string $stage, ?string $scheduledDate): string
{
    return match ($stage) {
        'SUBMITTED', 'ASSIGNED'               => $scheduledDate ? 'SCHEDULED' : 'ASSIGNED',
        'EN_ROUTE', 'ARRIVED', 'IN_PROGRESS'  => 'IN_PROGRESS',
        'PAUSED'                              => sr_phase5_ready() ? 'ON_HOLD' : 'IN_PROGRESS',
        'COMPLETED'                           => 'COMPLETED',
        'CANCELLED'                           => 'CANCELLED',
        default                               => 'IN_PROGRESS',
    };
}

/**
 * Bring every open request linked to $jobId in line with the job's new stage.
 * Call inside the same transaction that changed jobs.stage.
 *
 * On COMPLETED the completion date is stamped and, when the technician has not
 * written a resolution yet, the work report's remarks become the resolution —
 * so the client always sees what was actually done.
 *
 * @return array<int, array{id:int, request_code:string, client_id:int, assigned_technician_id:?int, subject:?string, request_type:?string, old:string, new:string}>
 *         the requests whose status changed (for notifications after commit)
 */
function sr_sync_from_job(int $jobId, string $stage, ?string $note = null): array
{
    $pdo = db();
    $select = sr_phase5_ready()
        ? 'SELECT id, request_code, client_id, assigned_technician_id, subject, request_type, status, scheduled_date, resolution'
        : 'SELECT id, request_code, client_id, assigned_technician_id, NULL AS subject, request_type, status, NULL AS scheduled_date, NULL AS resolution';
    $stmt = $pdo->prepare(
        $select . " FROM service_requests
         WHERE job_id = :j AND status NOT IN ('COMPLETED','CANCELLED','REJECTED') FOR UPDATE"
    );
    $stmt->execute([':j' => $jobId]);

    $changed = [];
    foreach ($stmt->fetchAll() as $sr) {
        $new = sr_status_for_job_stage($stage, $sr['scheduled_date']);
        if ($new === $sr['status']) {
            continue;
        }

        if ($new === 'COMPLETED') {
            $resolution = $sr['resolution'];
            if (sr_phase5_ready() && trim((string)$resolution) === '') {
                $wr = $pdo->prepare('SELECT remarks FROM work_reports WHERE job_id = :j ORDER BY id DESC LIMIT 1');
                $wr->execute([':j' => $jobId]);
                $resolution = $wr->fetchColumn() ?: null;
            }
            if (sr_phase5_ready()) {
                $pdo->prepare('UPDATE service_requests SET status = "COMPLETED", completion_date = NOW(), resolution = :r WHERE id = :id')
                    ->execute([':r' => $resolution, ':id' => $sr['id']]);
            } else {
                $pdo->prepare('UPDATE service_requests SET status = "COMPLETED", completion_date = NOW() WHERE id = :id')
                    ->execute([':id' => $sr['id']]);
            }
        } else {
            $pdo->prepare('UPDATE service_requests SET status = :s WHERE id = :id')
                ->execute([':s' => $new, ':id' => $sr['id']]);
        }

        $action = match ($new) {
            'IN_PROGRESS' => $sr['status'] === 'ON_HOLD' ? 'WORK_RESUMED' : 'WORK_STARTED',
            'ON_HOLD'     => 'PUT_ON_HOLD',
            'COMPLETED'   => 'WORK_COMPLETED',
            'CANCELLED'   => 'CANCELLED',
            default       => 'STATUS_CHANGED',
        };
        $remark = 'Job stage: ' . tech_stage_label($stage) . ($note !== null && trim($note) !== '' ? ' — ' . trim($note) : '');
        sr_log((int)$sr['id'], $action, $sr['status'], $new, $remark);

        $changed[] = [
            'id' => (int)$sr['id'], 'request_code' => $sr['request_code'], 'client_id' => (int)$sr['client_id'],
            'assigned_technician_id' => $sr['assigned_technician_id'] ? (int)$sr['assigned_technician_id'] : null,
            'subject' => $sr['subject'], 'request_type' => $sr['request_type'],
            'old' => $sr['status'], 'new' => $new,
        ];
    }
    return $changed;
}

/**
 * Notifications for requests whose status sr_sync_from_job() just moved.
 * Call after the transaction commits. The client already receives the job's
 * own stage notification, so the client is only told separately on completion.
 */
function sr_notify_job_sync(array $changed, string $actorName): void
{
    foreach ($changed as $sr) {
        $label = sr_label($sr);
        switch ($sr['new']) {
            case 'IN_PROGRESS':
                if ($sr['old'] === 'ON_HOLD') {
                    sr_notify_management("$actorName resumed work on service request $label.", $sr['id']);
                } else {
                    sr_notify_management("$actorName started service request $label.", $sr['id']);
                }
                break;
            case 'ON_HOLD':
                sr_notify_management("$actorName put service request $label on hold.", $sr['id']);
                break;
            case 'COMPLETED':
                sr_notify_management("$actorName completed service request $label.", $sr['id']);
                sr_notify_client($sr, "Your service request $label has been completed.");
                break;
        }
    }
}

/** A YYYY-MM-DD date from input, or a 422. */
function sr_parse_date($value, string $field = 'Date'): string
{
    $value = trim((string)$value);
    $d = DateTime::createFromFormat('Y-m-d', $value);
    if (!$d || $d->format('Y-m-d') !== $value) {
        json_error("$field must be in YYYY-MM-DD format.", 422);
    }
    return $value;
}
