<?php
/**
 * Phone / browser push notifications for the installed app (Web Push).
 *
 * How it works, in short:
 *   - Every notify() also queues a push for that user. The pushes are sent
 *     once, at the end of the request, all in parallel with short timeouts,
 *     so a slow push service cannot hold up the page.
 *   - The push carries NO data. It only wakes the app's service worker
 *     (sw.js), which then asks api/push/latest.php for the newest
 *     notification over the user's own signed-in session. Nothing private
 *     ever passes through Google / Mozilla / Apple / Microsoft.
 *   - Requests are signed with this server's own VAPID key pair. It is
 *     created on first use and kept in storage/push/vapid.json (the storage
 *     folder is not reachable from the web). Keep that file when moving
 *     servers, or every phone has to turn notifications on again.
 *
 * Everything here fails quietly: a missing table, missing OpenSSL or an
 * unreachable push service must never break the action that caused it.
 */

/** Push services a subscription may point to. Anything else is refused, so
 *  the server can never be used to send requests to arbitrary addresses. */
const PUSH_ALLOWED_HOSTS = [
    'fcm.googleapis.com',               // Chrome, Edge (Android), Samsung, Opera
    'updates.push.services.mozilla.com', // Firefox
    '.notify.windows.com',              // Edge on Windows
    '.push.apple.com',                  // Safari / iPhone home-screen apps
];

/** How long a push service keeps trying to deliver (seconds). */
const PUSH_TTL = 86400;

function push_b64url(string $bin): string
{
    return rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
}

/** True when $url is https on one of PUSH_ALLOWED_HOSTS. */
function push_endpoint_allowed(string $url): bool
{
    if (strlen($url) > 1000 || !filter_var($url, FILTER_VALIDATE_URL)) {
        return false;
    }
    $p = parse_url($url);
    if (($p['scheme'] ?? '') !== 'https' || isset($p['user']) || isset($p['port'])) {
        return false;
    }
    $host = strtolower((string)($p['host'] ?? ''));
    foreach (PUSH_ALLOWED_HOSTS as $allowed) {
        if ($allowed[0] === '.' ? str_ends_with($host, $allowed) : $host === $allowed) {
            return true;
        }
    }
    return false;
}

/** OpenSSL options; XAMPP on Windows often cannot find openssl.cnf by itself. */
function push_openssl_configs(): array
{
    $list = [null];
    foreach ([getenv('OPENSSL_CONF') ?: null,
              dirname(PHP_BINARY) . '/extras/ssl/openssl.cnf',
              dirname(PHP_BINARY, 2) . '/php/extras/ssl/openssl.cnf',
              dirname(PHP_BINARY, 2) . '/apache/conf/openssl.cnf'] as $c) {
        if ($c && is_file($c)) {
            $list[] = $c;
        }
    }
    return $list;
}

/**
 * This server's VAPID keys: ['public' => base64url raw point, 'pem' => private key].
 * Created on first call. Null when OpenSSL cannot make EC keys here.
 */
function push_vapid_keys(): ?array
{
    static $keys = false;
    if ($keys !== false) {
        return $keys;
    }
    $keys = null;
    try {
        $file = storage_dir('push') . '/vapid.json';
    } catch (Throwable $e) {
        return null;
    }
    if (is_file($file)) {
        $data = json_decode((string)file_get_contents($file), true);
        if (!empty($data['public']) && !empty($data['pem'])) {
            return $keys = ['public' => $data['public'], 'pem' => $data['pem']];
        }
    }
    if (!function_exists('openssl_pkey_new')) {
        return null;
    }
    foreach (push_openssl_configs() as $conf) {
        $opts = ['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC] + ($conf ? ['config' => $conf] : []);
        $key = @openssl_pkey_new($opts);
        if (!$key || !@openssl_pkey_export($key, $pem, null, $conf ? ['config' => $conf] : [])) {
            continue;
        }
        $d = openssl_pkey_get_details($key);
        $x = str_pad($d['ec']['x'] ?? '', 32, "\0", STR_PAD_LEFT);
        $y = str_pad($d['ec']['y'] ?? '', 32, "\0", STR_PAD_LEFT);
        $public = push_b64url("\x04" . $x . $y);
        // Written once; a concurrent first call simply writes the same kind of file.
        if (@file_put_contents($file, json_encode(['public' => $public, 'pem' => $pem, 'created' => date('c')]), LOCK_EX) === false) {
            return null;
        }
        while (openssl_error_string() !== false) {
            // clear OpenSSL's error queue left by failed attempts
        }
        return $keys = ['public' => $public, 'pem' => $pem];
    }
    return null;
}

/** ES256 JWT that proves to the push service the push comes from this server. */
function push_vapid_jwt(string $endpoint, array $keys): ?string
{
    $p = parse_url($endpoint);
    $aud = $p['scheme'] . '://' . $p['host'];
    $subject = (string)(app_env('SUNTRACK_VAPID_SUBJECT') ?: ('mailto:' . (app_env('SUNTRACK_MAIL_FROM') ?: app_env('SUNTRACK_SMTP_USER') ?: 'admin@example.com')));
    if (!preg_match('#^(mailto:|https://)#', $subject)) {
        $subject = 'mailto:' . $subject;
    }
    $unsigned = push_b64url(json_encode(['typ' => 'JWT', 'alg' => 'ES256']))
        . '.' . push_b64url(json_encode(['aud' => $aud, 'exp' => time() + 12 * 3600, 'sub' => $subject]));
    $priv = openssl_pkey_get_private($keys['pem']);
    if (!$priv || !openssl_sign($unsigned, $der, $priv, OPENSSL_ALGO_SHA256)) {
        return null;
    }
    // OpenSSL returns a DER sequence of two integers; JWT wants r || s (32 bytes each).
    $raw = push_der_to_raw($der);
    return $raw === null ? null : $unsigned . '.' . push_b64url($raw);
}

function push_der_to_raw(string $der): ?string
{
    $pos = 2;
    if (ord($der[1]) & 0x80) {
        $pos += ord($der[1]) & 0x7f;
    }
    $out = '';
    for ($i = 0; $i < 2; $i++) {
        if (!isset($der[$pos]) || ord($der[$pos]) !== 0x02) {
            return null;
        }
        $len = ord($der[$pos + 1]);
        $int = ltrim(substr($der, $pos + 2, $len), "\0");
        if (strlen($int) > 32) {
            return null;
        }
        $out .= str_pad($int, 32, "\0", STR_PAD_LEFT);
        $pos += 2 + $len;
    }
    return $out;
}

/** Queue a push for a user; sent once when the request ends. */
function push_queue(int $userId): void
{
    static $registered = false;
    $GLOBALS['__suntrack_push_users'][$userId] = true;
    if (!$registered) {
        $registered = true;
        register_shutdown_function('push_flush');
    }
}

/** Sends the queued pushes. Runs at the end of the request. */
function push_flush(): void
{
    $users = array_keys($GLOBALS['__suntrack_push_users'] ?? []);
    $GLOBALS['__suntrack_push_users'] = [];
    if (!$users || !function_exists('curl_multi_init')) {
        return;
    }
    try {
        $in = implode(',', array_map('intval', $users));
        $subs = db()->query("SELECT id, endpoint FROM push_subscriptions WHERE user_id IN ($in)")->fetchAll();
    } catch (Throwable $e) {
        return; // phase7 not applied
    }
    if (!$subs || !($keys = push_vapid_keys())) {
        return;
    }
    push_finish_response();
    push_send($subs, $keys);
}

/** Hands the finished page to the browser before the pushes go out. */
function push_finish_response(): void
{
    ignore_user_abort(true);
    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request(); // PHP-FPM (most Linux hosting)
        return;
    }
    // Apache mod_php: tell the browser the exact length so it does not wait.
    // Only with a single output buffer, whose length is the whole body.
    if (!headers_sent() && ob_get_level() === 1 && !ini_get('zlib.output_compression')) {
        header('Content-Length: ' . ob_get_length());
        header('Connection: close');
        ob_end_flush();
        flush();
    }
}

/**
 * Sends an empty push to each subscription in parallel.
 * Returns [subscription id => HTTP status] (0 = could not connect).
 */
function push_send(array $subs, array $keys): array
{
    $mh = curl_multi_init();
    $handles = [];
    foreach ($subs as $s) {
        if (!push_endpoint_allowed($s['endpoint']) || !($jwt = push_vapid_jwt($s['endpoint'], $keys))) {
            continue;
        }
        $ch = curl_init($s['endpoint']);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => '',
            CURLOPT_HTTPHEADER => [
                'TTL: ' . PUSH_TTL,
                'Urgency: high',
                'Content-Length: 0',
                'Authorization: vapid t=' . $jwt . ', k=' . $keys['public'],
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_TIMEOUT => 5,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
        ]);
        $cafile = app_env('SUNTRACK_SMTP_CAFILE');
        if ($cafile && is_file($cafile)) {
            curl_setopt($ch, CURLOPT_CAINFO, $cafile);
        } elseif (PHP_OS_FAMILY === 'Windows' && defined('CURLSSLOPT_NATIVE_CA')) {
            // XAMPP's bundled certificate list is years old; trust Windows' own.
            curl_setopt($ch, CURLOPT_SSL_OPTIONS, CURLSSLOPT_NATIVE_CA);
        }
        curl_multi_add_handle($mh, $ch);
        $handles[(int)$s['id']] = $ch;
    }
    do {
        $status = curl_multi_exec($mh, $running);
        if ($running) {
            curl_multi_select($mh, 1.0);
        }
    } while ($running && $status === CURLM_OK);

    $result = [];
    $gone = [];
    $sent = [];
    foreach ($handles as $id => $ch) {
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $result[$id] = $code;
        if ($code === 0) {
            $GLOBALS['__suntrack_push_errors'][$id] = curl_error($ch); // for diagnostics
        }
        if ($code === 404 || $code === 410) {
            $gone[] = $id; // the phone unsubscribed or the app was removed
        } elseif ($code >= 200 && $code < 300) {
            $sent[] = $id;
        }
        curl_multi_remove_handle($mh, $ch);
    }
    curl_multi_close($mh);
    try {
        if ($gone) {
            db()->exec('DELETE FROM push_subscriptions WHERE id IN (' . implode(',', $gone) . ')');
        }
        if ($sent) {
            db()->exec('UPDATE push_subscriptions SET last_sent_at = NOW() WHERE id IN (' . implode(',', $sent) . ')');
        }
    } catch (Throwable $e) {
    }
    return $result;
}
