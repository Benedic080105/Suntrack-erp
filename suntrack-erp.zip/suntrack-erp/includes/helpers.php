<?php
/**
 * SunTrack ERP — Shared helper functions
 */

/** Send a JSON success response and stop execution. */
function json_success($data = [], string $message = 'Operation completed successfully'): void
{
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'message' => $message, 'data' => $data]);
    exit;
}

/** Send a JSON error response and stop execution. */
function json_error(string $message = 'Unable to complete operation', int $httpCode = 400, $data = []): void
{
    http_response_code($httpCode);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => $message, 'data' => $data]);
    exit;
}

/** Read the JSON body of the current request as an associative array. */
function json_input(): array
{
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

/** Require the given keys to be present (and non-empty) in an array; errors out otherwise. */
function require_fields(array $input, array $fields): void
{
    $missing = [];
    foreach ($fields as $field) {
        if (!isset($input[$field]) || $input[$field] === '') {
            $missing[] = $field;
        }
    }
    if (!empty($missing)) {
        json_error('Missing required field(s): ' . implode(', ', $missing), 422);
    }
}

/** Generate a sequential, zero-padded code, e.g. code_with_prefix('CLIENT-', 1) -> 'CLIENT-001'. */
function pad_code(string $prefix, int $number, int $length = 3): string
{
    return $prefix . str_pad((string)$number, $length, '0', STR_PAD_LEFT);
}

/** Haversine distance in meters between two lat/lng points. */
function distance_meters(float $lat1, float $lng1, float $lat2, float $lng2): float
{
    $earthRadius = 6371000; // meters
    $dLat = deg2rad($lat2 - $lat1);
    $dLng = deg2rad($lng2 - $lng1);
    $a = sin($dLat / 2) ** 2
        + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;
    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
    return $earthRadius * $c;
}

/** CSRF: generate (or reuse) a token for the current session. */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** CSRF: verify a token sent by the client against the session's token. */
function csrf_verify(?string $token): bool
{
    return $token !== null && !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/** Require a valid CSRF token on state-changing requests; errors out otherwise. */
function require_csrf(array $input): void
{
    $token = $input['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? null);
    if (!csrf_verify($token)) {
        // 403, not Laravel-style 419: Apache does not know 419 and rewrites it
        // to a 500, which made an expired login page look like a server crash.
        json_error('Invalid or missing security token. Please refresh and try again.', 403);
    }
}

/**
 * Write a row to audit_logs. Call this after any create/update/delete/assign/approve action.
 */
function audit_log(string $action, string $module, ?string $recordId = null): void
{
    $userId  = $_SESSION['user_id'] ?? null;
    $roleKey = $_SESSION['role_key'] ?? null;
    $ip      = $_SERVER['REMOTE_ADDR'] ?? null;

    $stmt = db()->prepare(
        'INSERT INTO audit_logs (user_id, role_key, action, module, record_id, ip_address)
         VALUES (:user_id, :role_key, :action, :module, :record_id, :ip)'
    );
    $stmt->execute([
        ':user_id'   => $userId,
        ':role_key'  => $roleKey,
        ':action'    => $action,
        ':module'    => $module,
        ':record_id' => $recordId,
        ':ip'        => $ip,
    ]);
}

/**
 * Which audit-log rows a view shows (Logs & Audit table and its CSV export).
 * Nothing is ever deleted — views only hide noise.
 *   team (default)  the people doing the work: manager, staff, technician,
 *                   warehouse — without sign-ins / sign-outs
 *   <role>          one of those roles, without sign-ins
 *   signins         sign-ins and sign-outs only (staff side)
 *   all             everything, admin and client work included
 * Client and technician log-ins / log-outs are hidden in every view — they
 * are routine (technicians sign in on site all day) and drown out the rest.
 * Failed log-in attempts are still shown.
 */
const AUDIT_HIDDEN_SIGNIN_ROLES = ['client', 'technician'];
const AUDIT_TEAM_ROLES = ['manager', 'staff', 'technician', 'warehouse'];
const AUDIT_SIGNIN_ACTIONS = ['LOGIN', 'LOGOUT', 'LOGIN_FAILED'];

/**
 * A search looks through everything: typing a person's name finds all their
 * activity (sign-ins included), not just the default "team work" view. A view
 * picked on purpose (a role, sign-ins only) still narrows it.
 */
function audit_view_for_search(?string $view, ?string $search): string
{
    $view = $view ?: 'team';
    return ($view === 'team' && trim((string)$search) !== '') ? 'all' : $view;
}

function audit_view_filter(?string $view, array &$where, array &$params): void
{
    $view = $view ?: 'team';
    $signins = "'" . implode("','", AUDIT_SIGNIN_ACTIONS) . "'";
    $where[] = "(COALESCE(al.role_key, '') NOT IN ('" . implode("','", AUDIT_HIDDEN_SIGNIN_ROLES) . "') OR al.action NOT IN ('LOGIN','LOGOUT'))";
    if ($view === 'all') {
        return;
    }
    if ($view === 'signins') {
        $where[] = "al.action IN ($signins)";
        return;
    }
    if (in_array($view, AUDIT_TEAM_ROLES, true)) {
        $where[] = 'al.role_key = :view_role';
        $params[':view_role'] = $view;
    } else {
        $where[] = "al.role_key IN ('" . implode("','", AUDIT_TEAM_ROLES) . "')";
    }
    $where[] = "al.action NOT IN ($signins)";
}

/** Create a notification for a given user. */
function notify(int $userId, string $type, string $message, ?string $relatedTable = null, ?int $relatedId = null): void
{
    $stmt = db()->prepare(
        'INSERT INTO notifications (user_id, type, message, related_table, related_id)
         VALUES (:user_id, :type, :message, :related_table, :related_id)'
    );
    $stmt->execute([
        ':user_id'       => $userId,
        ':type'          => $type,
        ':message'       => $message,
        ':related_table' => $relatedTable,
        ':related_id'    => $relatedId,
    ]);
    // Phone notification for the installed app (sent at the end of the request).
    if (function_exists('push_queue')) {
        push_queue($userId);
    }
}

/** Escape output for safe HTML display. */
function h(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * First character of a name, for avatar initials. Works even when the
 * mbstring extension isn't installed (a Fatal error: Call to undefined
 * function mb_substr() otherwise) — falls back to plain substr(), which is
 * safe here since we only ever display a single glyph, not manipulate text.
 */
function initial(?string $name): string
{
    $name = trim((string)$name);
    if ($name === '') {
        return '?';
    }
    return function_exists('mb_substr') ? mb_substr($name, 0, 1) : substr($name, 0, 1);
}

/**
 * Character count that works whether or not the mbstring extension is
 * installed. Same reasoning as initial() above: a stock XAMPP build ships
 * mbstring, but a trimmed-down PHP may not, and a Fatal error on a length
 * check would take down the whole endpoint.
 */
function str_len(?string $value): int
{
    $value = (string)$value;
    return function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
}

/** Substring that degrades gracefully when mbstring is unavailable. */
function str_cut(?string $value, int $start, ?int $length = null): string
{
    $value = (string)$value;
    return function_exists('mb_substr')
        ? mb_substr($value, $start, $length)
        : substr($value, $start, $length ?? PHP_INT_MAX);
}

/**
 * Neutralize CSV formula injection. A cell that starts with =, +, - or @
 * is executed as a formula by Excel/Google Sheets/LibreOffice when the
 * file is opened, so a stored value like "=cmd|'/c calc'!A1" in a name or
 * remarks field could run on whoever opens the export. Prefixing with a
 * single quote/tab forces spreadsheet apps to treat it as plain text
 * without changing what the human reader sees.
 */
function csv_safe_cell($value): string
{
    $value = (string)$value;
    if ($value !== '' && in_array($value[0], ['=', '+', '-', '@', "\t", "\r"], true)) {
        return "'" . $value;
    }
    return $value;
}

/**
 * Next sequential record code, e.g. next_sequential_code('clients', 'client_code', 'CLIENT-').
 *
 * Replaces the old `COUNT(*) + 1` pattern, which was wrong twice over:
 * deleting CLIENT-002 out of three rows made the next insert collide on
 * CLIENT-003, and two simultaneous creates both read the same count and
 * produced the same code. This reads the highest number actually in use,
 * so gaps are skipped rather than reused.
 *
 * The UNIQUE index on the code column remains the real guarantee — callers
 * should retry on a duplicate-key error (see with_unique_code() below).
 *
 * $floor is the number to count up from when no code with this prefix exists
 * yet — job codes start each year at 1001, e.g. JOB-2026-1001.
 */
function next_sequential_code(string $table, string $column, string $prefix, int $pad = 3, int $floor = 0): string
{
    return $prefix . str_pad((string)next_sequential_number($table, $column, $prefix, $floor), $pad, '0', STR_PAD_LEFT);
}

/** The numeric part of next_sequential_code(). */
function next_sequential_number(string $table, string $column, string $prefix, int $floor = 0): int
{
    $sql = "SELECT COALESCE(MAX(CAST(SUBSTRING(`$column`, :len) AS UNSIGNED)), 0)
            FROM `$table`
            WHERE `$column` LIKE :prefix";

    $stmt = db()->prepare($sql);
    $stmt->execute([
        ':len'    => str_len($prefix) + 1,
        ':prefix' => $prefix . '%',
    ]);

    return max((int)$stmt->fetchColumn(), $floor) + 1;
}

/**
 * Run $callback with a freshly generated code, retrying when the database
 * rejects it as a duplicate.
 *
 * Even a correct MAX()+1 can lose a race: two requests read the same maximum
 * microseconds apart and both try the same code. Rather than locking the
 * table on every insert, we let the UNIQUE index referee it and try again —
 * the loser simply takes the next number.
 *
 * The retry counts up from the first candidate instead of re-reading MAX().
 * Inside a transaction, InnoDB's REPEATABLE READ snapshot hides the winner's
 * row, so a re-read returns the same stale maximum and collides every time.
 * Counting up needs no visibility of the winner at all.
 *
 * Only a duplicate on the code column itself is retried. Any other constraint
 * failure — a foreign key, or a different UNIQUE index such as "one work
 * report per job" — is rethrown at once, because a new code cannot fix it.
 *
 * Safe inside a transaction: InnoDB rolls back only the failed statement, not
 * the transaction, so the retry continues within it. Keep the callback to the
 * single INSERT that uses the code.
 *
 * @param callable(string):mixed $callback receives the candidate code
 */
function with_unique_code(string $table, string $column, string $prefix, callable $callback, int $pad = 3, int $attempts = 10, int $floor = 0)
{
    $number = next_sequential_number($table, $column, $prefix, $floor);

    for ($i = 0; $i < $attempts; $i++, $number++) {
        $code = $prefix . str_pad((string)$number, $pad, '0', STR_PAD_LEFT);
        try {
            return $callback($code);
        } catch (PDOException $e) {
            // 1062 = duplicate entry; the message names the key, which for these
            // tables is the code column ("for key 'job_code'" on MariaDB,
            // "for key 'jobs.job_code'" on MySQL 8).
            $isCodeCollision = ($e->errorInfo[1] ?? null) === 1062
                && str_contains($e->getMessage(), $column);
            if (!$isCodeCollision || $i === $attempts - 1) {
                throw $e;
            }
        }
    }

    throw new RuntimeException('Could not allocate a unique code for ' . $table);
}

/**
 * Insert a job under a collision-safe JOB-YYYY-#### code (first of the year is
 * JOB-YYYY-1001). $insert receives the candidate code, runs the jobs INSERT,
 * and nothing else — it may be called more than once.
 *
 * @param callable(string):void $insert
 * @return array{0:int, 1:string} [job id, job code]
 */
function insert_job_with_code(callable $insert): array
{
    $code = with_unique_code('jobs', 'job_code', 'JOB-' . date('Y') . '-', function (string $code) use ($insert) {
        $insert($code);
        return $code;
    }, pad: 4, floor: 1000);

    return [(int)db()->lastInsertId(), $code];
}

/**
 * The client's plotted site as [lat, lng, geofence radius] for a new job.
 *
 * Every path that creates a job must copy this onto the job: the technician
 * geofence reads only jobs.site_lat/site_lng, so under geofence_strict a job
 * created without them can never be timed in to — and therefore never started
 * or completed. Lat/lng are null when the client has not been plotted yet.
 *
 * @return array{0:?float, 1:?float, 2:int}
 */
function client_site_location(int $clientId): array
{
    $stmt = db()->prepare('SELECT lat, lng, geofence_radius_m FROM clients WHERE id = :id');
    $stmt->execute([':id' => $clientId]);
    $row = $stmt->fetch() ?: [];

    $plotted = isset($row['lat'], $row['lng']);
    $radius  = !empty($row['geofence_radius_m']) ? (int)$row['geofence_radius_m'] : geofence_default_radius();

    return [$plotted ? (float)$row['lat'] : null, $plotted ? (float)$row['lng'] : null, $radius];
}

/**
 * Validate a latitude/longitude pair supplied by a client.
 *
 * Returns [lat, lng] as floats, or [null, null] when both are blank (which is
 * a legitimate "not plotted yet"). Errors out on a half-filled or out-of-range
 * pair — a record with a latitude and no longitude is worse than no
 * coordinates at all, because it looks plotted.
 */
function parse_coordinates($lat, $lng): array
{
    $latBlank = ($lat === null || $lat === '');
    $lngBlank = ($lng === null || $lng === '');

    if ($latBlank && $lngBlank) {
        return [null, null];
    }
    if ($latBlank !== $lngBlank) {
        json_error('Please provide both latitude and longitude, or leave both blank.', 422);
    }
    if (!is_numeric($lat) || !is_numeric($lng)) {
        json_error('Latitude and longitude must be numbers.', 422);
    }

    $lat = (float)$lat;
    $lng = (float)$lng;

    if ($lat < -90 || $lat > 90) {
        json_error('Latitude must be between -90 and 90.', 422);
    }
    if ($lng < -180 || $lng > 180) {
        json_error('Longitude must be between -180 and 180.', 422);
    }
    // 0,0 is in the Gulf of Guinea — almost always an empty form, not a site.
    if ($lat === 0.0 && $lng === 0.0) {
        json_error('0, 0 is not a valid site location. Please pick the site on the map.', 422);
    }

    return [round($lat, 7), round($lng, 7)];
}

/**
 * What each list's search box looks through. One map shared by the list
 * endpoints and api/export/csv.php, so an export always matches the screen.
 * Column names use the table aliases both queries already share.
 */
function search_columns(string $entity): array
{
    static $map = [
        'clients'          => ['c.client_code', 'u.full_name', 'u.email', 'u.phone', 'c.address', 'c.city', 'c.province'],
        'service_requests' => ['sr.request_code', 'sr.request_type', 'sr.description', 'u.full_name', 'c.client_code', 'c.city', 'tu.full_name', 't.technician_code'],
        'jobs'             => ['j.job_code', 'j.site_address', 'j.description', 'cu.full_name', 'c.client_code', 'c.city', 'tu.full_name', 't.technician_code', 'p.project_code'],
        'installation'     => ['j.job_code', 'j.site_address', 'cu.full_name', 'c.client_code', 'tu.full_name', 't.technician_code', 'p.project_code', 'p.site_name'],
        'maintenance'      => ['p.project_code', 'p.site_name', 'p.address', 'cu.full_name', 'c.client_code', 'c.city'],
        'projects'         => ['p.project_code', 'p.site_name', 'p.address', 'p.system_type', 'cu.full_name', 'c.client_code', 'tu.full_name'],
        'technicians'      => ['t.technician_code', 'u.full_name', 'u.email', 'u.phone', 't.specialization'],
        'staff'            => ['s.staff_code', 'u.full_name', 'u.email', 'u.phone', 's.department', 's.position'],
        'subcontractors'   => ['subcon_code', 'name', 'contact_person', 'specialization', 'specialties', 'phone', 'email', 'area'],
        'inventory'        => ['i.sku', 'i.item_name', 'i.brand', 'i.model', 'i.serial_number', 'i.warehouse_location', 'i.qr_code', 'ic.category_name'],
        'attendance'       => ['t.technician_code', 'u.full_name', 'j.job_code', 'j.site_address'],
        'work_reports'     => ['wr.report_code', 'wr.work_type', 'j.job_code', 'j.site_address', 'cu.full_name', 'c.client_code', 'tu.full_name'],
        'billing'          => ['i.invoice_code', 'i.payment_reference', 'u.full_name', 'c.client_code', 'p.project_code'],
        'logs'             => ['al.action', 'al.module', 'al.record_id', 'al.ip_address', 'al.role_key', 'u.full_name', 'u.email'],
        'tech_history'     => ['j.job_code', 'j.job_type', 'j.site_address', 'cu.full_name', 'c.client_code'],
        'material_requests'=> ['mr.request_code', 'mr.notes', 'cu.full_name', 'c.client_code', 'c.city', 'p.project_code', 'p.site_name', 'j.job_code'],
    ];
    if (!isset($map[$entity])) {
        throw new InvalidArgumentException("No search columns for $entity");
    }
    return $map[$entity];
}

/**
 * Word-by-word search: every word typed must appear in at least one of
 * $columns, in any order. "maria bacolod" finds Maria Santos of Bacolod City,
 * which a single LIKE '%maria bacolod%' never could.
 *
 * % and _ are escaped, so "100%" searches for those characters instead of
 * matching everything. Matching is case-insensitive through the column
 * collation. Returns the SQL fragment (params added to $params with unique
 * names), or null when the search is blank.
 */
function search_clause(?string $search, array $columns, array &$params, string $prefix = 'q'): ?string
{
    $search = trim((string)$search);
    if ($search === '') {
        return null;
    }

    $words = preg_split('/\s+/u', $search, -1, PREG_SPLIT_NO_EMPTY) ?: [];
    $words = array_slice(array_values(array_unique($words)), 0, 6); // bound the query size

    $groups = [];
    foreach ($words as $wi => $word) {
        $like = '%' . strtr(str_cut($word, 0, 100), ['!' => '!!', '%' => '!%', '_' => '!_']) . '%';
        $ors = [];
        foreach ($columns as $ci => $column) {
            $key = ":{$prefix}{$wi}_{$ci}";
            $ors[] = "$column LIKE $key ESCAPE '!'";
            $params[$key] = $like;
        }
        $groups[] = '(' . implode(' OR ', $ors) . ')';
    }

    return $groups ? '(' . implode(' AND ', $groups) . ')' : null;
}

/**
 * Paging for list endpoints: ?limit (1..$max, default $max) and ?offset.
 *
 * The query asks for one row more than the page; if it arrives, there is a
 * next page and list_page_finish() says so in an X-Next-Offset header. A
 * header rather than a new JSON field keeps every existing response shape
 * unchanged, so callers that ignore paging behave exactly as before.
 *
 * @return array{0:int, 1:int} [limit, offset]
 */
function list_page(int $max = 500): array
{
    // Anything that is not a positive whole number falls back to the defaults.
    $l = filter_var($_GET['limit'] ?? null, FILTER_VALIDATE_INT);
    $o = filter_var($_GET['offset'] ?? null, FILTER_VALIDATE_INT);
    $limit  = ($l === false || $l === null || $l < 1) ? $max : min($max, $l);
    $offset = ($o === false || $o === null || $o < 0) ? 0 : min(10000000, $o);
    return [$limit, $offset];
}

/** "LIMIT n+1 OFFSET m" — integers only, never user text. */
function list_page_sql(int $limit, int $offset): string
{
    return 'LIMIT ' . ($limit + 1) . ' OFFSET ' . $offset;
}

/** Drop the look-ahead row and announce the next page, if there is one. */
function list_page_finish(array $rows, int $limit, int $offset): array
{
    if (count($rows) > $limit) {
        array_pop($rows);
        if (!headers_sent()) {
            header('X-Next-Offset: ' . ($offset + $limit));
        }
    }
    return $rows;
}

/** An optional YYYY-MM-DD query parameter; 422 on anything else. */
function query_date(string $key): ?string
{
    $value = trim((string)($_GET[$key] ?? ''));
    if ($value === '') {
        return null;
    }
    $d = DateTime::createFromFormat('Y-m-d', $value);
    if (!$d || $d->format('Y-m-d') !== $value) {
        json_error('Dates must be in YYYY-MM-DD format.', 422);
    }
    return $value;
}

/**
 * Add ?date_from / ?date_to (both optional, inclusive) on $column.
 *
 * Half-open at the top — `< the day after` — so it is correct for DATE and
 * DATETIME columns alike and never drops the last second of the day.
 */
function apply_date_range(string $column, array &$where, array &$params): void
{
    $from = query_date('date_from');
    $to   = query_date('date_to');
    if ($from !== null && $to !== null && $from > $to) {
        json_error('The "from" date cannot be later than the "to" date.', 422);
    }
    if ($from !== null) {
        $where[] = "$column >= :range_from";
        $params[':range_from'] = $from;
    }
    if ($to !== null) {
        $where[] = "$column < :range_to";
        $params[':range_to'] = date('Y-m-d', strtotime($to . ' +1 day'));
    }
}

/**
 * Keep maintenance_schedules.status true as the calendar moves.
 *
 * Status used to be computed only when a schedule was saved, so an UPCOMING
 * visit stayed UPCOMING forever — the "Overdue" counts and client reminders
 * went stale day by day. This re-applies the same rule as
 * api/maintenance/schedule.php (past = OVERDUE, within 14 days = DUE) at most
 * once a day, on the first request that reads maintenance, so no cron job is
 * needed. Today is PHP's date (Asia/Manila), matching schedule.php, not
 * MySQL's CURDATE(), which may run on UTC.
 */
function maintenance_refresh_statuses(): void
{
    $today = date('Y-m-d');
    if (setting('maintenance_status_refreshed_on') === $today) {
        return;
    }
    try {
        $due = date('Y-m-d', strtotime($today . ' +14 days'));
        db()->prepare(
            "UPDATE maintenance_schedules
             SET status = CASE
                 WHEN next_maintenance < :t1 THEN 'OVERDUE'
                 WHEN next_maintenance <= :d1 THEN 'DUE'
                 ELSE 'UPCOMING' END
             WHERE next_maintenance IS NOT NULL
               AND status <> CASE
                 WHEN next_maintenance < :t2 THEN 'OVERDUE'
                 WHEN next_maintenance <= :d2 THEN 'DUE'
                 ELSE 'UPCOMING' END"
        )->execute([':t1' => $today, ':d1' => $due, ':t2' => $today, ':d2' => $due]);
        setting_set('maintenance_status_refreshed_on', $today);
    } catch (Throwable $e) {
        // Never block a page over this; the next request tries again.
        error_log('SunTrack maintenance status refresh: ' . $e->getMessage());
    }
}

/**
 * Keep invoices.payment_status true as the calendar moves: a PENDING invoice
 * whose due date has passed is OVERDUE. Nothing else ever set OVERDUE, so the
 * "Overdue" totals stayed at zero no matter how late a client was. Runs at
 * most once a day (same pattern as maintenance_refresh_statuses()). Payments
 * treat OVERDUE exactly like PENDING, so this never blocks one.
 */
function billing_refresh_overdue(): void
{
    $today = date('Y-m-d');
    if (setting('billing_overdue_refreshed_on') === $today) {
        return;
    }
    try {
        db()->prepare(
            "UPDATE invoices SET payment_status = 'OVERDUE'
             WHERE payment_status = 'PENDING' AND due_date IS NOT NULL AND due_date < :t"
        )->execute([':t' => $today]);
        setting_set('billing_overdue_refreshed_on', $today);
    } catch (Throwable $e) {
        error_log('SunTrack billing overdue refresh: ' . $e->getMessage());
    }
}

/**
 * Minutes from a duration typed in any form, for totals and averages; null when
 * it cannot be read as a time (the text itself is always kept as typed).
 *   "500" -> 500 (a bare number is minutes)      "2:30" -> 150
 *   "2 hours 30 mins" / "2h30m" / "2 hrs 30" -> 150   "1.5 hrs" -> 90
 *   "1 day" -> 1440                               "half day" / "whole morning" -> null
 */
function work_duration_minutes(?string $text): ?int
{
    $t = strtolower(trim((string)$text));
    if ($t === '') {
        return null;
    }
    if (preg_match('/^\d+(\.\d+)?$/', $t)) {
        return (int)round((float)$t);
    }
    if (preg_match('/^(\d+):([0-5]\d)$/', $t, $m)) {
        return (int)$m[1] * 60 + (int)$m[2];
    }
    $unit = ['d' => 1440, 'day' => 1440, 'days' => 1440,
             'h' => 60, 'hr' => 60, 'hrs' => 60, 'hour' => 60, 'hours' => 60,
             'm' => 1, 'min' => 1, 'mins' => 1, 'minute' => 1, 'minutes' => 1];
    if (!preg_match_all('/(\d+(?:\.\d+)?)\s*([a-z]+)?/', $t, $parts, PREG_SET_ORDER)) {
        return null;
    }
    // Every word must be a unit or a filler ("and"); anything else means the
    // text is not a plain duration, so no number is guessed.
    $rest = trim(preg_replace('/(\d+(?:\.\d+)?)\s*([a-z]+)?|\band\b|[,&+]/', ' ', $t));
    if ($rest !== '') {
        return null;
    }
    $total = 0.0;
    $last = null;
    foreach ($parts as $p) {
        $u = $p[2] ?? '';
        if ($u === '') {
            // "2 hrs 30" — a bare number after hours means minutes.
            if ($last !== 60) {
                return null;
            }
            $u = 'm';
        }
        if (!isset($unit[$u])) {
            return null;
        }
        $total += (float)$p[1] * $unit[$u];
        $last = $unit[$u];
    }
    return $total <= 1000000 ? (int)round($total) : null;
}

/**
 * The single authority on inventory status.
 *
 * Previously this expression was copy-pasted into five endpoints, and the
 * copies had already drifted apart. Two bugs came with that:
 *
 *   1. DISCONTINUED was never considered, so receiving stock against a
 *      retired item silently resurrected it as ACTIVE and it reappeared in
 *      pickers. There was no way to retire an item and have it stay retired.
 *   2. The zero test was `== 0`, so a quantity of -1 fell through to
 *      LOW_STOCK instead of OUT_OF_STOCK.
 *
 * Pass the row's existing status as $current so a deliberate DISCONTINUED is
 * preserved across stock movements. Only an explicit edit should clear it.
 *
 * The rule is one company-wide threshold, not each item's reorder level:
 *   0 or less                        OUT_OF_STOCK
 *   below INVENTORY_LOW_STOCK_BELOW  LOW_STOCK
 *   at or above it                   ACTIVE
 * api/realtime/sync.php counts low stock with the same constant.
 */
const INVENTORY_LOW_STOCK_BELOW = 50;

function inventory_status(int $quantity, ?string $current = null): string
{
    if ($current === 'DISCONTINUED') {
        return 'DISCONTINUED';
    }
    if ($quantity <= 0) {
        return 'OUT_OF_STOCK';
    }
    if ($quantity < INVENTORY_LOW_STOCK_BELOW) {
        return 'LOW_STOCK';
    }
    return 'ACTIVE';
}
