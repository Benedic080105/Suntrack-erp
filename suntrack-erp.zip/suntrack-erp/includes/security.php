<?php
/**
 * SunTrack ERP — Security hardening.
 *
 * Three concerns live here:
 *   1. Brute-force protection on the login endpoint.
 *   2. Session lifetime limits (idle + absolute).
 *   3. Response security headers.
 */

// ---- Passwords -------------------------------------------------------------

/**
 * Minimum password length, for every path that sets a password: registration,
 * self-service changes, and Management creating or resetting an account. It
 * lives in one place because the copies had drifted — some endpoints still
 * accepted 6 characters after the policy moved to 8.
 */
const PASSWORD_MIN_LENGTH = 8;

// ---- Login throttling ------------------------------------------------------

/** Failed attempts allowed before an email is locked out. */
const LOGIN_MAX_ATTEMPTS_EMAIL = 5;

/** Failed attempts allowed from one IP across all accounts. */
const LOGIN_MAX_ATTEMPTS_IP = 20;

/** Sliding window, in minutes, that the counts above are measured over. */
const LOGIN_WINDOW_MINUTES = 15;

/** The client's IP, as far as we can determine it. */
function client_ip(): ?string
{
    return $_SERVER['REMOTE_ADDR'] ?? null;
}

/** Truncated user agent, for the attempt/consent audit trail. */
function client_user_agent(): ?string
{
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? null;
    return $ua === null ? null : substr($ua, 0, 255);
}

/**
 * Record one login attempt.
 *
 * Every attempt is written, successful or not: the successful rows are what
 * let an investigator tell "attacker guessed it" from "attacker gave up".
 */
function login_record_attempt(string $email, bool $successful): void
{
    try {
        db()->prepare(
            'INSERT INTO login_attempts (email, ip_address, successful, user_agent)
             VALUES (:e, :ip, :ok, :ua)'
        )->execute([
            ':e'  => substr(strtolower($email), 0, 150),
            ':ip' => client_ip(),
            ':ok' => $successful ? 1 : 0,
            ':ua' => client_user_agent(),
        ]);
    } catch (Throwable $e) {
        // Never let audit bookkeeping break a login.
    }
}

/**
 * How many failures have happened in the current window.
 *
 * Failures are counted only since the last SUCCESSFUL login for that email —
 * otherwise a user who mistypes their password four times, logs in fine, then
 * mistypes it once more tomorrow would be locked out by yesterday's history.
 *
 * @return array{email:int, ip:int}
 */
function login_recent_failures(string $email): array
{
    $email = strtolower($email);

    try {
        $pdo = db();

        $byEmail = $pdo->prepare(
            'SELECT COUNT(*) FROM login_attempts
             WHERE email = :e
               AND successful = 0
               AND created_at > DATE_SUB(NOW(), INTERVAL :mins MINUTE)
               AND created_at > COALESCE((
                     SELECT MAX(created_at) FROM login_attempts la2
                     WHERE la2.email = :e2 AND la2.successful = 1
                 ), "1970-01-01")'
        );
        $byEmail->execute([':e' => $email, ':e2' => $email, ':mins' => LOGIN_WINDOW_MINUTES]);

        $byIp = $pdo->prepare(
            'SELECT COUNT(*) FROM login_attempts
             WHERE ip_address = :ip
               AND successful = 0
               AND created_at > DATE_SUB(NOW(), INTERVAL :mins MINUTE)'
        );
        $byIp->execute([':ip' => client_ip(), ':mins' => LOGIN_WINDOW_MINUTES]);

        return [
            'email' => (int)$byEmail->fetchColumn(),
            'ip'    => (int)$byIp->fetchColumn(),
        ];
    } catch (Throwable $e) {
        return ['email' => 0, 'ip' => 0];
    }
}

/**
 * Stop the request with a 429 when this email or IP is over the limit.
 * Called by the login endpoint BEFORE any password is verified, so a locked
 * account costs an attacker a rejection rather than a hash comparison.
 */
function login_guard_or_fail(string $email): void
{
    $fails = login_recent_failures($email);

    if ($fails['email'] >= LOGIN_MAX_ATTEMPTS_EMAIL || $fails['ip'] >= LOGIN_MAX_ATTEMPTS_IP) {
        // Deliberately does not reveal whether the account exists.
        json_error(
            'Too many failed sign-in attempts. Please wait '
            . LOGIN_WINDOW_MINUTES . ' minutes and try again.',
            429,
            ['locked' => true, 'retry_after_minutes' => LOGIN_WINDOW_MINUTES]
        );
    }
}

/** Housekeeping: drop attempt rows older than a day. Cheap, runs occasionally. */
function login_prune_attempts(): void
{
    try {
        if (random_int(1, 50) === 1) {
            db()->exec('DELETE FROM login_attempts WHERE created_at < DATE_SUB(NOW(), INTERVAL 1 DAY)');
        }
    } catch (Throwable $e) {
        // Housekeeping only.
    }
}

// ---- Session lifetime ------------------------------------------------------

/** Log the user out after this many minutes with no requests. */
const SESSION_IDLE_TIMEOUT_MINUTES = 60;

/** Force a fresh login after this many hours, however active the session is. */
const SESSION_ABSOLUTE_TIMEOUT_HOURS = 12;

/**
 * Enforce idle and absolute session limits.
 *
 * Runs on every request via config.php. A shared office terminal left signed
 * in is the realistic threat here: without this, a session cookie with
 * lifetime 0 still survives for as long as the browser stays open.
 *
 * @return bool true when the session was expired and cleared
 */
function session_enforce_timeouts(): bool
{
    if (!isset($_SESSION['user_id'])) {
        return false;
    }

    $now = time();

    $startedAt = $_SESSION['session_started_at'] ?? null;
    if ($startedAt === null) {
        $_SESSION['session_started_at'] = $now;
        $startedAt = $now;
    }

    $lastSeen = $_SESSION['last_activity_at'] ?? $now;

    $idleExpired = ($now - $lastSeen) > (SESSION_IDLE_TIMEOUT_MINUTES * 60);
    $absExpired  = ($now - $startedAt) > (SESSION_ABSOLUTE_TIMEOUT_HOURS * 3600);

    if ($idleExpired || $absExpired) {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
        return true;
    }

    $_SESSION['last_activity_at'] = $now;
    return false;
}

// ---- Response headers ------------------------------------------------------

/**
 * Send security headers.
 *
 * The root .htaccess already sets three of these for Apache, but that file is
 * ignored by nginx, by PHP's built-in server, and whenever AllowOverride is
 * off — so the guarantee is made here, in PHP, where it holds everywhere.
 *
 * Every library (Tailwind, Font Awesome, Inter, Leaflet, Chart.js,
 * html5-qrcode) is served from assets/vendor/ on this server, so scripts,
 * styles and fonts are allowed from 'self' only: a compromised public CDN can
 * no longer inject code into SunTrack. The one outside source left is the
 * OpenStreetMap map tiles, which are images.
 */
function send_security_headers(bool $isApi = false): void
{
    if (headers_sent()) {
        return;
    }

    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(self), camera=(self), microphone=()');

    // HSTS: once a browser has seen the site over HTTPS, it refuses plain http
    // for 180 days — this blocks "downgrade to http" tricks on public Wi-Fi.
    // Only sent over HTTPS, so local http://localhost development is unaffected.
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    if ($isHttps) {
        header('Strict-Transport-Security: max-age=15552000');
    }

    if ($isApi) {
        // API responses are per-user and must never be cached by a proxy.
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        header('Pragma: no-cache');
        return;
    }

    header(
        "Content-Security-Policy: "
        . "default-src 'self'; "
        . "script-src 'self' 'unsafe-inline'; "
        . "style-src 'self' 'unsafe-inline'; "
        . "font-src 'self' data:; "
        . "img-src 'self' data: blob: https://*.tile.openstreetmap.org; "
        . "connect-src 'self'; "
        . "worker-src 'self'; "
        . "manifest-src 'self'; "
        . "object-src 'none'; "
        . "base-uri 'self'; "
        // Forms may only submit back to this site, even if one were injected.
        . "form-action 'self'; "
        . "frame-ancestors 'self'"
    );
}

/**
 * True when the current request targets an /api/ endpoint. Used to pick
 * between a JSON 401 and an HTML redirect, and between header sets above.
 */
function request_is_api(): bool
{
    return str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/');
}
