<?php
/**
 * SunTrack ERP — inventory QR identifiers, serialized units and safe stock
 * transactions (Phase 16, database/phase16_inventory_qr.sql).
 *
 * Two ways to track an item, set per product (inventory.tracking_mode):
 *
 *   PRODUCT  one QR label per SKU (inventory.qr_code, e.g. QR-ST-INV-9001).
 *            The clerk scans it and types the quantity.
 *   SERIAL   every physical unit has its own row in inventory_units with its
 *            own QR identifier (UNIT-9007-0001) and manufacturer serial.
 *            inventory.quantity is then always the number of IN_STOCK units.
 *
 * Stock that comes back damaged or needing inspection goes to
 * inventory.quarantine_qty (units: status QUARANTINE), never straight back
 * into available stock; Inspection (api/inventory/quarantine.php) restocks it
 * or writes it off.
 *
 * Every endpoint that moves stock: begins a transaction, claims the form's
 * request key (inv_request_key_begin), locks the inventory row first and the
 * unit rows second (one lock order everywhere, so two clerks cannot
 * deadlock), writes stock_movements, and commits — or changes nothing.
 * QR payloads are identifiers only: no quantities, prices or client details.
 */

const INV_CONDITIONS = ['GOOD', 'DAMAGED', 'NEEDS_INSPECTION'];
const INV_CONDITION_LABELS = ['GOOD' => 'Good', 'DAMAGED' => 'Damaged', 'NEEDS_INSPECTION' => 'Needs inspection'];
const INV_MAX_QTY = 100000; // one transaction; stops a typo like 10000000 from posting

function inv_qr_ready(): bool
{
    static $ok = null;
    if ($ok === null) {
        try {
            db()->query('SELECT tracking_mode, quarantine_qty FROM inventory LIMIT 0');
            db()->query('SELECT unit_id, item_condition, original_movement_id FROM stock_movements LIMIT 0');
            db()->query('SELECT 1 FROM inventory_units LIMIT 0');
            db()->query('SELECT 1 FROM stock_request_keys LIMIT 0');
            $ok = true;
        } catch (PDOException $e) {
            $ok = false;
        }
    }
    return $ok;
}

function inv_require_qr_schema(): void
{
    if (!inv_qr_ready()) {
        json_error('QR stock tracking is not set up yet. Import database/phase16_inventory_qr.sql.', 503);
    }
}

/** Roll back whatever is open, then answer with an error. */
function inv_fail(string $message, int $code = 422): never
{
    $pdo = db();
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    json_error($message, $code);
}

/** The item row, locked for the rest of the transaction. */
function inv_lock_item(PDO $pdo, int $id): array
{
    $stmt = $pdo->prepare(
        'SELECT i.*, ic.category_name FROM inventory i
         JOIN inventory_categories ic ON ic.id = i.category_id
         WHERE i.id = :id FOR UPDATE'
    );
    $stmt->execute([':id' => $id]);
    $item = $stmt->fetch();
    if (!$item) {
        inv_fail('Inventory item not found.', 404);
    }
    return $item;
}

/** Write the new available / quarantined counts; returns the new status. */
function inv_set_stock(PDO $pdo, array $item, int $quantity, int $quarantine): string
{
    if ($quantity < 0 || $quarantine < 0) {
        inv_fail("Not enough stock of {$item['item_name']}.", 409);
    }
    $status = inventory_status($quantity, $item['status']);
    $pdo->prepare('UPDATE inventory SET quantity = :q, quarantine_qty = :h, status = :s WHERE id = :id')
        ->execute([':q' => $quantity, ':h' => $quarantine, ':s' => $status, ':id' => $item['id']]);
    return $status;
}

/**
 * Insert one stock_movements row. $m keys: inventory_id, type, quantity, and
 * optionally job_id, material_request_id, technician_id, unit_id, condition,
 * original_movement_id, reference. Returns [id, movement_code].
 */
function inv_add_movement(PDO $pdo, array $m): array
{
    $letter = ['RECEIVE' => 'R', 'ISSUE' => 'I', 'RETURN' => 'T', 'ADJUST' => 'A', 'TRANSFER' => 'X'][$m['type']];
    $stmt = $pdo->prepare(
        'INSERT INTO stock_movements (movement_code, inventory_id, movement_type, quantity, job_id, material_request_id,
                                      unit_id, item_condition, original_movement_id, technician_id, reference, recorded_by)
         VALUES (:code, :inv, :type, :qty, :job, :mr, :unit, :cond, :orig, :tech, :ref, :user)'
    );
    for ($attempt = 0; ; $attempt++) {
        $code = 'MV-' . date('ymdHis') . '-' . $letter . $m['inventory_id'] . '-' . random_int(1000, 9999);
        try {
            $stmt->execute([
                ':code' => $code,
                ':inv'  => $m['inventory_id'],
                ':type' => $m['type'],
                ':qty'  => $m['quantity'],
                ':job'  => $m['job_id'] ?? null,
                ':mr'   => $m['material_request_id'] ?? null,
                ':unit' => $m['unit_id'] ?? null,
                ':cond' => $m['condition'] ?? null,
                ':orig' => $m['original_movement_id'] ?? null,
                ':tech' => $m['technician_id'] ?? null,
                ':ref'  => mb_substr((string)($m['reference'] ?? ''), 0, 50) ?: null,
                ':user' => current_user_id(),
            ]);
            return [(int)$pdo->lastInsertId(), $code];
        } catch (PDOException $e) {
            $collision = ($e->errorInfo[1] ?? null) === 1062 && str_contains($e->getMessage(), 'movement_code');
            if (!$collision || $attempt >= 4) {
                throw $e;
            }
        }
    }
}

/**
 * Give an item its QR identifier if it has none. Never replaces an existing
 * one: labels already stuck on the shelf must keep working. QR-<SKU> is the
 * normal value; if it is somehow taken, a random suffix keeps it unique (the
 * UNIQUE index on inventory.qr_code is the final referee).
 *
 * @return array{qr_code:string, created:bool}
 */
function inv_assign_qr(PDO $pdo, int $id): array
{
    $stmt = $pdo->prepare('SELECT sku, qr_code FROM inventory WHERE id = :id FOR UPDATE');
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch();
    if (!$row) {
        inv_fail('Inventory item not found.', 404);
    }
    if ($row['qr_code'] !== null && $row['qr_code'] !== '') {
        return ['qr_code' => $row['qr_code'], 'created' => false];
    }

    $upd = $pdo->prepare('UPDATE inventory SET qr_code = :qr WHERE id = :id AND (qr_code IS NULL OR qr_code = \'\')');
    for ($attempt = 0; $attempt < 5; $attempt++) {
        $qr = 'QR-' . $row['sku'] . ($attempt === 0 ? '' : '-' . strtoupper(bin2hex(random_bytes(2))));
        try {
            $upd->execute([':qr' => $qr, ':id' => $id]);
            return ['qr_code' => $qr, 'created' => true];
        } catch (PDOException $e) {
            if (($e->errorInfo[1] ?? null) !== 1062) {
                throw $e;
            }
        }
    }
    throw new RuntimeException('Could not allocate a unique QR identifier.');
}

/**
 * What a scanned or typed code points at: a unit label, a manufacturer serial
 * that matches exactly one unit, or a product SKU / QR identifier.
 * With $lock the item row (then the unit row) is locked FOR UPDATE.
 *
 * @return array{item:array, unit:?array}|null
 */
function inv_resolve_code(PDO $pdo, string $code, bool $lock = false): ?array
{
    $code = trim($code);
    if ($code === '' || mb_strlen($code) > 100) {
        return null;
    }
    $for = $lock ? ' FOR UPDATE' : '';

    $unit = null;
    if (inv_qr_ready()) {
        $u = $pdo->prepare('SELECT * FROM inventory_units WHERE unit_code = :c');
        $u->execute([':c' => $code]);
        $unit = $u->fetch() ?: null;
        if (!$unit) {
            $u = $pdo->prepare('SELECT * FROM inventory_units WHERE serial_number = :c LIMIT 2');
            $u->execute([':c' => $code]);
            $matches = $u->fetchAll();
            $unit = count($matches) === 1 ? $matches[0] : null; // the same serial on two products is ambiguous
        }
    }

    if ($unit) {
        $i = $pdo->prepare('SELECT i.*, ic.category_name FROM inventory i JOIN inventory_categories ic ON ic.id = i.category_id WHERE i.id = :id' . $for);
        $i->execute([':id' => $unit['inventory_id']]);
        $item = $i->fetch();
        if ($lock) {
            $u = $pdo->prepare('SELECT * FROM inventory_units WHERE id = :id FOR UPDATE');
            $u->execute([':id' => $unit['id']]);
            $unit = $u->fetch();
        }
        return $item ? ['item' => $item, 'unit' => $unit] : null;
    }

    $i = $pdo->prepare(
        'SELECT i.*, ic.category_name FROM inventory i JOIN inventory_categories ic ON ic.id = i.category_id
         WHERE i.sku = :c1 OR i.qr_code = :c2 LIMIT 1' . $for
    );
    $i->execute([':c1' => $code, ':c2' => $code]);
    $item = $i->fetch();
    return $item ? ['item' => $item, 'unit' => null] : null;
}

/**
 * Serial numbers from a form: an array or one-per-line text. Trimmed, each
 * 1–100 characters, no repeats within the list.
 */
function inv_clean_serials($raw): array
{
    if (is_string($raw)) {
        $raw = preg_split('/[\r\n,;]+/', $raw);
    }
    if (!is_array($raw)) {
        inv_fail('Serial numbers must be a list.');
    }
    $out = [];
    $seen = [];
    foreach ($raw as $s) {
        $s = trim((string)$s);
        if ($s === '') {
            continue;
        }
        if (mb_strlen($s) > 100) {
            inv_fail("Serial number \"" . mb_substr($s, 0, 30) . "…\" is too long (100 characters max).");
        }
        $k = mb_strtoupper($s);
        if (isset($seen[$k])) {
            inv_fail("Serial number {$s} is listed twice.");
        }
        $seen[$k] = true;
        $out[] = $s;
    }
    if (count($out) > 500) {
        inv_fail('Register at most 500 units at a time.');
    }
    return $out;
}

/**
 * Create IN_STOCK units for $item. Rejects serials this product already has.
 * Call inside the transaction, with the item locked.
 *
 * @return array<int, array{id:int, unit_code:string, serial_number:string}>
 */
function inv_create_units(PDO $pdo, array $item, array $serials, ?string $location): array
{
    if (!$serials) {
        return [];
    }
    $in = implode(',', array_fill(0, count($serials), '?'));
    $dup = $pdo->prepare("SELECT serial_number FROM inventory_units WHERE inventory_id = ? AND serial_number IN ($in) LIMIT 1");
    $dup->execute(array_merge([$item['id']], $serials));
    if ($taken = $dup->fetchColumn()) {
        inv_fail("Serial number {$taken} is already registered for {$item['item_name']}.", 409);
    }

    $digits = preg_replace('/\D+/', '', (string)$item['sku']);
    $prefix = 'UNIT-' . ($digits !== '' ? $digits : $item['id']) . '-';
    $ins = $pdo->prepare(
        'INSERT INTO inventory_units (inventory_id, unit_code, serial_number, status, item_condition, warehouse_location)
         VALUES (:inv, :code, :serial, "IN_STOCK", "GOOD", :loc)'
    );
    $units = [];
    foreach ($serials as $serial) {
        $code = with_unique_code('inventory_units', 'unit_code', $prefix, function (string $code) use ($ins, $item, $serial, $location) {
            $ins->execute([':inv' => $item['id'], ':code' => $code, ':serial' => $serial, ':loc' => $location ?: null]);
            return $code;
        }, pad: 4);
        $units[] = ['id' => (int)$pdo->lastInsertId(), 'unit_code' => $code, 'serial_number' => $serial];
    }
    return $units;
}

/**
 * Lock the units named in $refs (unit ids, unit codes or serials) that
 * belong to $item. Fails if one is unknown, belongs to another product, or
 * appears twice — a unit scanned twice in one form is a mistake, not two units.
 */
function inv_lock_units(PDO $pdo, array $item, $refs): array
{
    if (!is_array($refs) || !$refs) {
        inv_fail("{$item['item_name']} is tracked by unit. Scan or choose each unit's own label.");
    }
    $sel = $pdo->prepare(
        'SELECT * FROM inventory_units
         WHERE inventory_id = :inv AND (id = :id OR unit_code = :code OR serial_number = :serial)
         FOR UPDATE'
    );
    $units = [];
    foreach ($refs as $ref) {
        // JSON numbers are unit ids; strings are unit codes or serials (a
        // serial like "123" must never be read as unit id 123).
        $byId = is_int($ref);
        $ref = trim((string)$ref);
        if ($ref === '') {
            continue;
        }
        $sel->execute([':inv' => $item['id'], ':id' => $byId ? (int)$ref : 0, ':code' => $byId ? '' : $ref, ':serial' => $byId ? '' : $ref]);
        $unit = $sel->fetch();
        if (!$unit) {
            inv_fail("{$ref} is not a unit of {$item['item_name']}.", 404);
        }
        if (isset($units[$unit['id']])) {
            inv_fail("{$unit['unit_code']} was scanned twice. Each unit counts once.", 409);
        }
        $units[$unit['id']] = $unit;
    }
    if (!$units) {
        inv_fail("{$item['item_name']} is tracked by unit. Scan or choose each unit's own label.");
    }
    if (count($units) > 500) {
        inv_fail('Move at most 500 units at a time.');
    }
    return array_values($units);
}

/**
 * Claim this form submission's request key inside the open transaction. The
 * same key sent again (double tap, flaky network retry) gets the first
 * answer back instead of moving stock a second time. A concurrent duplicate
 * waits on the first one's row lock, then sees it here.
 * Returns the key, or null when the caller sent none.
 */
function inv_request_key_begin(PDO $pdo, array $input, string $endpoint): ?string
{
    $key = trim((string)($input['request_key'] ?? ''));
    if ($key === '') {
        return null;
    }
    if (!preg_match('/^[A-Za-z0-9_-]{8,64}$/', $key)) {
        inv_fail('Invalid request key.');
    }
    // A retried form arrives within seconds; old keys only take up space.
    if (random_int(1, 50) === 1) {
        $pdo->exec('DELETE FROM stock_request_keys WHERE created_at < NOW() - INTERVAL 7 DAY');
    }
    try {
        $pdo->prepare('INSERT INTO stock_request_keys (request_key, endpoint, user_id) VALUES (:k, :e, :u)')
            ->execute([':k' => $key, ':e' => $endpoint, ':u' => current_user_id()]);
        return $key;
    } catch (PDOException $e) {
        if (($e->errorInfo[1] ?? null) !== 1062) {
            throw $e;
        }
    }
    $pdo->rollBack();
    $stmt = $pdo->prepare('SELECT endpoint, user_id, response_json FROM stock_request_keys WHERE request_key = :k');
    $stmt->execute([':k' => $key]);
    $prior = $stmt->fetch();
    if ($prior && $prior['response_json'] !== null && (int)$prior['user_id'] === (int)current_user_id() && $prior['endpoint'] === $endpoint) {
        $saved = json_decode($prior['response_json'], true) ?: [];
        json_success(array_merge($saved['data'] ?? [], ['duplicate' => true]),
            'Already saved — this was recorded once. Nothing was added twice.');
    }
    json_error('This submission was already sent. Refresh to see the current stock.', 409);
}

/** Store the answer for a claimed key, still inside the transaction. */
function inv_request_key_finish(PDO $pdo, ?string $key, array $data, string $message): void
{
    if ($key === null) {
        return;
    }
    $pdo->prepare('UPDATE stock_request_keys SET response_json = :r WHERE request_key = :k')
        ->execute([':r' => json_encode(['data' => $data, 'message' => $message]), ':k' => $key]);
}

/** The job, or a 404. Cancelled jobs take no stock. */
function inv_job(PDO $pdo, int $jobId, bool $forIssue = false): array
{
    $stmt = $pdo->prepare('SELECT id, job_code, technician_id, stage FROM jobs WHERE id = :id');
    $stmt->execute([':id' => $jobId]);
    $job = $stmt->fetch();
    if (!$job) {
        inv_fail('Job not found.', 404);
    }
    if ($forIssue && $job['stage'] === 'CANCELLED') {
        inv_fail("{$job['job_code']} is cancelled, so no stock can be issued to it.", 409);
    }
    return $job;
}

/**
 * How many of an item a job still holds (issued minus returned) and the
 * latest issue it came from. Read under the item lock, so it cannot race.
 *
 * @return array{0:int, 1:?int}
 */
function inv_outstanding(PDO $pdo, int $inventoryId, int $jobId): array
{
    $stmt = $pdo->prepare(
        "SELECT COALESCE(SUM(CASE movement_type WHEN 'ISSUE' THEN quantity WHEN 'RETURN' THEN -quantity ELSE 0 END), 0) AS net,
                MAX(CASE WHEN movement_type = 'ISSUE' THEN id END) AS last_issue
         FROM stock_movements WHERE inventory_id = :i AND job_id = :j"
    );
    $stmt->execute([':i' => $inventoryId, ':j' => $jobId]);
    $r = $stmt->fetch();
    return [max(0, (int)$r['net']), $r['last_issue'] ? (int)$r['last_issue'] : null];
}

/** The ISSUE movement that sent this unit out most recently. */
function inv_unit_last_issue(PDO $pdo, int $unitId): ?array
{
    $stmt = $pdo->prepare(
        "SELECT id, job_id, material_request_id FROM stock_movements
         WHERE unit_id = :u AND movement_type = 'ISSUE' ORDER BY id DESC LIMIT 1"
    );
    $stmt->execute([':u' => $unitId]);
    return $stmt->fetch() ?: null;
}

/** True when the signed-in role may change stock (Admin is view / export only). */
function inv_can_write(): bool
{
    return in_array(current_role(), ['warehouse', 'manager', 'staff'], true);
}

/**
 * Everything the QR panel and the label need for one item. Labels carry
 * identifiers and descriptions only — never quantities, costs or clients.
 */
function inv_item_payload(PDO $pdo, int $id): ?array
{
    $stmt = $pdo->prepare(
        'SELECT i.id, i.sku, i.item_name, i.brand, i.model, i.serial_number, i.quantity, i.quarantine_qty, i.status,
                i.warehouse_location, i.qr_code, i.tracking_mode, ic.category_name
         FROM inventory i JOIN inventory_categories ic ON ic.id = i.category_id WHERE i.id = :id'
    );
    $stmt->execute([':id' => $id]);
    $item = $stmt->fetch();
    if (!$item) {
        return null;
    }
    $item['id'] = (int)$item['id'];
    $item['quantity'] = (int)$item['quantity'];
    $item['quarantine_qty'] = (int)$item['quarantine_qty'];

    $units = [];
    if ($item['tracking_mode'] === 'SERIAL') {
        $u = $pdo->prepare(
            "SELECT u.id, u.unit_code, u.serial_number, u.status, u.item_condition, u.warehouse_location, u.updated_at,
                    j.job_code, mr.request_code
             FROM inventory_units u
             LEFT JOIN jobs j ON j.id = u.job_id
             LEFT JOIN material_requests mr ON mr.id = u.material_request_id
             WHERE u.inventory_id = :id
             ORDER BY FIELD(u.status, 'IN_STOCK', 'ISSUED', 'QUARANTINE', 'WRITTEN_OFF'), u.unit_code"
        );
        $u->execute([':id' => $id]);
        $units = $u->fetchAll();
    }
    return ['item' => $item, 'units' => $units, 'can_write' => inv_can_write()];
}
