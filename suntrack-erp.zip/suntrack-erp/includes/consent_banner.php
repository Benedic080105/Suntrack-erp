<?php
/**
 * SunTrack ERP — Cookie consent banner.
 *
 * Include once, just before </body>, on every page a visitor can reach:
 *     <?php include ROOT_PATH . '/includes/consent_banner.php'; ?>
 *
 * It renders nothing when the visitor has already chosen, so including it
 * unconditionally is safe.
 *
 * The two options are "Accept all" and "Essential only" rather than
 * accept/reject, because SunTrack genuinely sets only one cookie that matters
 * — the session — and that one is strictly necessary. Offering a "reject"
 * button that cannot actually be honoured would be worse than not asking.
 */

if (!function_exists('consent_banner_needed') || !consent_banner_needed()) {
    return;
}

$consentCsrf = csrf_token();
$privacyUrl  = APP_BASE_URL . '/privacy.php';
$cookiesUrl  = APP_BASE_URL . '/privacy.php#cookies';
?>
<div id="suntrack-cookie-banner"
     role="dialog"
     aria-live="polite"
     aria-label="Cookie notice"
     style="position:fixed;left:0;right:0;bottom:0;z-index:9999;padding:16px;
            background:#0f1934;color:#e2e8f0;border-top:2px solid #f97316;
            box-shadow:0 -8px 24px rgba(0,0,0,.35);font-family:Inter,system-ui,sans-serif">
  <div style="max-width:1100px;margin:0 auto;display:flex;flex-wrap:wrap;
              align-items:center;gap:16px;justify-content:space-between">
    <div style="flex:1 1 420px;min-width:280px">
      <p style="margin:0 0 4px;font-weight:700;font-size:14px;color:#fff">
        <span aria-hidden="true">&#127850;</span> Cookies &amp; your privacy
      </p>
      <p style="margin:0;font-size:12.5px;line-height:1.55;color:#94a3b8">
        SunTrack uses one strictly necessary cookie to keep you signed in. We do not
        use advertising or third-party tracking cookies. Field technicians' location is
        recorded only while a job is active — see the
        <a href="<?= h($privacyUrl) ?>" style="color:#f97316;font-weight:600">Privacy Policy</a>
        and <a href="<?= h($cookiesUrl) ?>" style="color:#f97316;font-weight:600">Cookie Notice</a>.
      </p>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button type="button" id="suntrack-consent-essential"
              style="background:transparent;color:#cbd5e1;border:1px solid #475569;
                     font-size:13px;font-weight:600;padding:10px 16px;border-radius:10px;cursor:pointer">
        Essential only
      </button>
      <button type="button" id="suntrack-consent-accept"
              style="background:#f97316;color:#fff;border:0;font-size:13px;font-weight:700;
                     padding:10px 20px;border-radius:10px;cursor:pointer">
        Accept all
      </button>
    </div>
  </div>
</div>

<script>
(function () {
  var banner = document.getElementById('suntrack-cookie-banner');
  if (!banner) return;

  var CSRF = <?= json_encode($consentCsrf) ?>;
  var ENDPOINT = <?= json_encode(APP_BASE_URL . '/api/consent/save.php') ?>;

  function choose(decision) {
    // Hide immediately. The decision is the user's, and a slow network must
    // not make the banner feel stuck — the cookie below is what the next page
    // load reads anyway.
    banner.style.display = 'none';

    // Client-side cookie first, so the choice survives even if the request
    // fails (offline, server restarting). The server sets the authoritative
    // one when it responds.
    try {
      var maxAge = 60 * 60 * 24 * 180;
      document.cookie = 'suntrack_consent=' + (decision === 'ACCEPTED' ? 'accepted' : 'essential')
        + ';path=/;max-age=' + maxAge + ';samesite=Lax'
        + (location.protocol === 'https:' ? ';secure' : '');
    } catch (e) { /* cookies disabled — the banner simply reappears next visit */ }

    fetch(ENDPOINT, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'COOKIES', decision: decision, csrf_token: CSRF })
    }).catch(function () { /* the cookie above already carries the choice */ });
  }

  document.getElementById('suntrack-consent-accept')
    .addEventListener('click', function () { choose('ACCEPTED'); });
  document.getElementById('suntrack-consent-essential')
    .addEventListener('click', function () { choose('ESSENTIAL_ONLY'); });
})();
</script>
