<?php
/**
 * SunTrack ERP — project lifecycle: solar system + maintenance schedule.
 *
 * A project is the installation of one solar system for a client. These
 * helpers keep the three related records in step, so nothing has to be typed
 * in twice:
 *
 *   projects            the job site / installation project
 *   solar_systems       the equipment the client sees in "My Solar System"
 *   maintenance_schedules   when the next service visit is due
 *
 *   project created / edited   -> installation job created for, or moved to,
 *                                 the assigned technician (project_sync_installation_job)
 *   project created            -> solar system created (PLANNED) and linked
 *   project edited             -> system status / capacity / address follow
 *   installation job started   -> system INSTALLING
 *   installation job completed -> system ACTIVE (installation date set), its
 *                                 panel / inverter / battery set to the exact
 *                                 stock items issued for it, and a maintenance
 *                                 schedule opened
 *   maintenance job completed  -> last / next maintenance moved forward
 *
 * Every function is safe to call repeatedly and changes only what is behind.
 */

/** OVERDUE when past, DUE within 14 days, else UPCOMING (same rule as maintenance/schedule.php). */
function maintenance_schedule_status(string $nextDate): string
{
    $days = (strtotime($nextDate) - strtotime(date('Y-m-d'))) / 86400;
    if ($days < 0) {
        return 'OVERDUE';
    }
    return $days <= 14 ? 'DUE' : 'UPCOMING';
}

/** The next maintenance date after $fromDate, from the maintenance_interval_years setting. */
function maintenance_next_date(string $fromDate): string
{
    $years = max(1, setting_int('maintenance_interval_years', 1));
    return date('Y-m-d', strtotime($fromDate . " +$years years"));
}

/** Solar system status that matches a project status, or null to leave it alone. */
function project_system_status(string $projectStatus, string $currentSystemStatus): ?string
{
    return match ($projectStatus) {
        'PLANNED', 'SCHEDULED'     => in_array($currentSystemStatus, ['PLANNED', 'INSTALLING'], true) ? 'PLANNED' : null,
        'IN_PROGRESS'              => in_array($currentSystemStatus, ['PLANNED', 'INSTALLING'], true) ? 'INSTALLING' : null,
        'COMPLETED', 'MAINTENANCE' => in_array($currentSystemStatus, ['PLANNED', 'INSTALLING'], true) ? 'ACTIVE' : null,
        'CANCELLED'                => $currentSystemStatus === 'ACTIVE' ? null : 'DECOMMISSIONED',
        default                    => null,
    };
}

/**
 * Make sure a project has its solar system, and that the system matches the
 * project (status, capacity, address, installation date). Creates the system
 * when the project has none. Returns solar_systems.id.
 */
function project_sync_solar_system(int $projectId): ?int
{
    $pdo = db();
    $stmt = $pdo->prepare('SELECT * FROM projects WHERE id = :id');
    $stmt->execute([':id' => $projectId]);
    $p = $stmt->fetch();
    if (!$p) {
        return null;
    }

    $systemId = $p['solar_system_id'] ? (int)$p['solar_system_id'] : null;
    $system = null;
    if ($systemId) {
        $s = $pdo->prepare('SELECT * FROM solar_systems WHERE id = :id');
        $s->execute([':id' => $systemId]);
        $system = $s->fetch() ?: null;
    }

    if (!$system) {
        $initial = match ($p['status']) {
            'IN_PROGRESS'              => 'INSTALLING',
            'COMPLETED', 'MAINTENANCE' => 'ACTIVE',
            'CANCELLED'                => 'DECOMMISSIONED',
            default                    => 'PLANNED',
        };
        $insert = $pdo->prepare(
            'INSERT INTO solar_systems (system_code, client_id, capacity_kw, installation_date, installation_address, status)
             VALUES (:code, :client, :cap, :date, :addr, :status)'
        );
        with_unique_code('solar_systems', 'system_code', 'ST-SYS-' . date('Y') . '-', function (string $code) use ($insert, $p, $initial) {
            $insert->execute([
                ':code'   => $code,
                ':client' => $p['client_id'],
                ':cap'    => $p['capacity_kw'],
                ':date'   => $initial === 'ACTIVE' ? ($p['installation_date'] ?: date('Y-m-d')) : null,
                ':addr'   => $p['address'],
                ':status' => $initial,
            ]);
            return $code;
        });
        $systemId = (int)$pdo->lastInsertId();
        $pdo->prepare('UPDATE projects SET solar_system_id = :s WHERE id = :id')->execute([':s' => $systemId, ':id' => $projectId]);
        return $systemId;
    }

    $newStatus = project_system_status($p['status'], $system['status']);
    $pdo->prepare(
        'UPDATE solar_systems
         SET status = COALESCE(:status, status),
             client_id = :client,
             capacity_kw = COALESCE(:cap, capacity_kw),
             installation_address = COALESCE(:addr, installation_address),
             installation_date = CASE WHEN COALESCE(:status2, status) = "ACTIVE"
                                      THEN COALESCE(installation_date, :date, CURDATE())
                                      ELSE installation_date END
         WHERE id = :id'
    )->execute([
        ':status' => $newStatus, ':status2' => $newStatus, ':client' => $p['client_id'], ':cap' => $p['capacity_kw'],
        ':addr' => $p['address'], ':date' => $p['installation_date'], ':id' => $systemId,
    ]);
    return $systemId;
}

/**
 * Keep the project's installation job in step with the project.
 *
 * Technicians only ever see jobs (api/technician/assignments.php reads
 * jobs.technician_id), so assigning a technician on the project alone left the
 * installation invisible to them. This is the bridge:
 *
 *   technician set, no installation job yet    -> job created (ASSIGNED), with the
 *                                                 17-item checklist and the client's
 *                                                 geofence, and the project's open
 *                                                 material request linked to it
 *   technician changed                         -> the open job moves to the new one
 *   technician removed                         -> job back to SUBMITTED (only before
 *                                                 the technician has set off)
 *   date / address changed                     -> copied onto a job not yet started
 *   project cancelled                          -> open installation job cancelled
 *   project COMPLETED / MAINTENANCE            -> left alone (already installed)
 *
 * Call inside the caller's transaction, after the project row is written.
 * Throws DomainException with a user-facing message when the change is not
 * allowed. Returns the notifications to send once the transaction commits:
 * list of [user_id, message, job_id].
 */
function project_sync_installation_job(int $projectId): array
{
    $pdo = db();
    $stmt = $pdo->prepare('SELECT * FROM projects WHERE id = :id FOR UPDATE');
    $stmt->execute([':id' => $projectId]);
    $p = $stmt->fetch();
    if (!$p) {
        return [];
    }

    $jobsStmt = $pdo->prepare("SELECT * FROM jobs WHERE project_id = :p AND job_type = 'INSTALLATION' ORDER BY id DESC FOR UPDATE");
    $jobsStmt->execute([':p' => $projectId]);
    $jobs = $jobsStmt->fetchAll();
    $open = null;
    $installed = false;
    foreach ($jobs as $j) {
        if ($j['stage'] === 'COMPLETED') {
            $installed = true;
        } elseif ($j['stage'] !== 'CANCELLED' && !$open) {
            $open = $j;
        }
    }

    // A subcontractor holds the open installation job: project technician
    // settings must not take it back. Management cancels the assignment first.
    if ($open && function_exists('sub_active_assignment_for_job') && ($subA = sub_active_assignment_for_job($pdo, (int)$open['id']))) {
        return ["Installation job {$open['job_code']} is with subcontractor {$subA['subcon_code']} ({$subA['assignment_code']}) — its technician was not changed."];
    }

    $tech = $p['assigned_technician_id'] ? (int)$p['assigned_technician_id'] : null;
    $userOf = function (?int $techId) use ($pdo): ?int {
        if (!$techId) {
            return null;
        }
        $s = $pdo->prepare('SELECT user_id FROM technicians WHERE id = :id');
        $s->execute([':id' => $techId]);
        return ($u = $s->fetchColumn()) ? (int)$u : null;
    };
    $history = $pdo->prepare(
        'INSERT INTO job_status_history (job_id, from_stage, to_stage, changed_by, note) VALUES (:j, :from, :to, :u, :note)'
    );
    $site = $p['project_code'] . ' — ' . $p['site_name'];
    $notes = [];

    // --- Cancelled project: its installation will not happen -------------------
    if ($p['status'] === 'CANCELLED') {
        if ($open) {
            $pdo->prepare("UPDATE jobs SET stage = 'CANCELLED' WHERE id = :id")->execute([':id' => $open['id']]);
            $history->execute([':j' => $open['id'], ':from' => $open['stage'], ':to' => 'CANCELLED',
                               ':u' => current_user_id(), ':note' => 'Project cancelled by Management']);
            $oldTech = $open['technician_id'] ? (int)$open['technician_id'] : null;
            if ($oldTech) {
                // Free the technician if this was the job keeping them busy.
                if (tech_availability($oldTech) === 'BUSY' && !tech_active_field_jobs($oldTech, (int)$open['id'])) {
                    tech_set_availability($oldTech, 'AVAILABLE');
                }
                if ($u = $userOf($oldTech)) {
                    $notes[] = [$u, "Installation job {$open['job_code']} ({$site}) was cancelled.", (int)$open['id']];
                }
            }
        }
        return $notes;
    }

    // --- Already installed: nothing left for a technician to do ------------------
    if (in_array($p['status'], ['COMPLETED', 'MAINTENANCE'], true) || ($installed && !$open)) {
        return $notes;
    }

    // --- No installation job yet: create it for the assigned technician ------------
    if (!$open) {
        if (!$tech) {
            return $notes; // created as soon as a technician is assigned
        }
        [$lat, $lng, $radius] = client_site_location((int)$p['client_id']);
        if (!$p['address']) {
            $a = $pdo->prepare("SELECT CONCAT_WS(', ', NULLIF(address, ''), NULLIF(city, ''), NULLIF(province, '')) FROM clients WHERE id = :id");
            $a->execute([':id' => $p['client_id']]);
            $address = $a->fetchColumn() ?: null;
        } else {
            $address = $p['address'];
        }
        $description = 'Installation at ' . $p['site_name']
            . ($p['capacity_kw'] ? ' — ' . rtrim(rtrim((string)$p['capacity_kw'], '0'), '.') . ' kW' : '')
            . ($p['system_type'] ? ' ' . $p['system_type'] : '')
            . ($p['notes'] ? '. ' . $p['notes'] : '');

        $insert = $pdo->prepare(
            'INSERT INTO jobs (job_code, project_id, client_id, technician_id, job_type, site_address,
                               site_lat, site_lng, geofence_radius_m, scheduled_date, priority, description, stage, progress)
             VALUES (:code, :project_id, :client_id, :tech_id, "INSTALLATION", :addr,
                     :lat, :lng, :radius, :sched, "NORMAL", :desc, "ASSIGNED", 0)'
        );
        [$jobId, $jobCode] = insert_job_with_code(fn(string $code) => $insert->execute([
            ':code' => $code, ':project_id' => $projectId, ':client_id' => $p['client_id'], ':tech_id' => $tech,
            ':addr' => $address, ':lat' => $lat, ':lng' => $lng, ':radius' => $radius,
            ':sched' => $p['installation_date'], ':desc' => str_cut($description, 0, 1000),
        ]));
        $history->execute([':j' => $jobId, ':from' => null, ':to' => 'ASSIGNED', ':u' => current_user_id(),
                           ':note' => "Created from project {$p['project_code']}"]);
        tech_ensure_installation_checklist($jobId);

        // The warehouse order for this project now shows (and tags its picks with) this job.
        try {
            $pdo->prepare("UPDATE material_requests SET job_id = :j WHERE project_id = :p AND job_id IS NULL AND status <> 'CANCELLED'")
                ->execute([':j' => $jobId, ':p' => $projectId]);
        } catch (PDOException $e) {
            // material_requests not installed (phase 5 is optional)
        }

        if ($u = $userOf($tech)) {
            $when = $p['installation_date'] ? ' on ' . date('M j, Y', strtotime($p['installation_date'])) : '';
            $notes[] = [$u, "New installation job assigned to you: {$jobCode} ({$site}){$when}.", $jobId];
        }
        return $notes;
    }

    // --- Open job: keep it matching the project -------------------------------------
    $notStarted = in_array($open['stage'], ['SUBMITTED', 'ASSIGNED'], true);
    $current = $open['technician_id'] ? (int)$open['technician_id'] : null;

    if ($notStarted) {
        $pdo->prepare('UPDATE jobs SET scheduled_date = :d, site_address = COALESCE(:a, site_address) WHERE id = :id')
            ->execute([':d' => $p['installation_date'], ':a' => $p['address'], ':id' => $open['id']]);
        // The first visit (inspection) follows the project's installation date until work starts.
        if ($p['installation_date'] && install_plan_available()) {
            $pdo->prepare("UPDATE installation_stage_plan SET scheduled_date = :d WHERE job_id = :j AND position = 1 AND status = 'SCHEDULED'")
                ->execute([':d' => $p['installation_date'], ':j' => $open['id']]);
        }
        // Project moved to another client: the job (and its geofence) follows.
        if ((int)$open['client_id'] !== (int)$p['client_id']) {
            [$lat, $lng, $radius] = client_site_location((int)$p['client_id']);
            $pdo->prepare('UPDATE jobs SET client_id = :c, site_lat = :lat, site_lng = :lng, geofence_radius_m = :r WHERE id = :id')
                ->execute([':c' => $p['client_id'], ':lat' => $lat, ':lng' => $lng, ':r' => $radius, ':id' => $open['id']]);
        }
    }

    if ($current === $tech) {
        return $notes;
    }
    if ($tech === null && !$notStarted) {
        throw new DomainException(
            "The technician is already working on installation job {$open['job_code']} (" . tech_stage_label($open['stage'])
            . '). Choose another technician to hand it over instead of leaving it unassigned.'
        );
    }

    $newStage = $tech === null ? 'SUBMITTED' : ($open['stage'] === 'SUBMITTED' ? 'ASSIGNED' : $open['stage']);
    $pdo->prepare('UPDATE jobs SET technician_id = :t, stage = :s WHERE id = :id')
        ->execute([':t' => $tech, ':s' => $newStage, ':id' => $open['id']]);
    $history->execute([':j' => $open['id'], ':from' => $open['stage'], ':to' => $newStage, ':u' => current_user_id(),
                       ':note' => $tech ? "Reassigned from project {$p['project_code']}" : "Technician removed from project {$p['project_code']}"]);

    if ($tech && ($u = $userOf($tech))) {
        $notes[] = [$u, "You've been assigned installation job {$open['job_code']} ({$site}).", (int)$open['id']];
    }
    if ($current && ($u = $userOf($current))) {
        $notes[] = [$u, "Installation job {$open['job_code']} ({$site}) has been " . ($tech ? 'reassigned to another technician' : 'unassigned from you') . '.', (int)$open['id']];
    }
    return $notes;
}

/** Send what project_sync_installation_job() returned, after the commit. */
function project_send_job_notifications(array $notes): void
{
    foreach ($notes as [$userId, $message, $jobId]) {
        notify($userId, 'JOB_STATUS', $message, 'jobs', $jobId);
    }
}

/** inventory_categories.category_name -> the solar_systems column it fills. */
const SYSTEM_EQUIPMENT_COLUMNS = [
    'Solar Panel' => 'panel_brand',
    'Inverter'    => 'inverter_brand',
    'Battery'     => 'battery_brand',
];

/**
 * The stock items actually installed on a project: everything issued to its
 * installation jobs (directly, or picked onto one of the project's client
 * orders) minus anything returned. Grouped by category, e.g.
 *   ['Solar Panel' => [['sku' => 'ST-INV-9002', 'item_name' => 'LONGi Hi-MO 6 545W Panel',
 *                       'brand' => 'LONGi', 'model' => 'LR5-72HTH-545M', 'quantity' => 15]], ...]
 * Categories with nothing installed are left out.
 */
function project_installed_equipment(int $projectId): array
{
    $pdo = db();
    $params = [':p1' => $projectId];
    $sources = 'm.job_id IN (SELECT id FROM jobs WHERE project_id = :p1 AND job_type = "INSTALLATION")';
    // Client orders ship in their own migration; without it only direct issues count.
    try {
        $pdo->query('SELECT 1 FROM material_requests LIMIT 0');
        $sources .= ' OR m.material_request_id IN (SELECT id FROM material_requests WHERE project_id = :p2)';
        $params[':p2'] = $projectId;
    } catch (PDOException $e) {
        // material_requests not installed
    }

    $stmt = $pdo->prepare(
        "SELECT ic.category_name, i.sku, i.item_name, i.brand, i.model, i.unit_cost,
                SUM(CASE m.movement_type WHEN 'ISSUE' THEN m.quantity ELSE -m.quantity END) AS quantity
         FROM stock_movements m
         JOIN inventory i ON i.id = m.inventory_id
         JOIN inventory_categories ic ON ic.id = i.category_id
         WHERE m.movement_type IN ('ISSUE','RETURN') AND ($sources)
         GROUP BY ic.category_name, i.id, i.sku, i.item_name, i.brand, i.model, i.unit_cost
         HAVING quantity > 0
         ORDER BY ic.category_name, quantity DESC, i.item_name"
    );
    $stmt->execute($params);

    $out = [];
    foreach ($stmt->fetchAll() as $r) {
        $cat = $r['category_name'];
        unset($r['category_name']);
        $r['quantity'] = (int)$r['quantity'];
        $out[$cat][] = $r;
    }
    return $out;
}

/**
 * The materials actually used on a project, priced: every item issued for its
 * installation (net of returns) × the item's unit price in the inventory.
 *   ['items' => [[category, item_name, sku, model, quantity, unit_price, line_total], …],
 *    'total' => float, 'count' => int units]
 */
function project_material_costs(int $projectId): array
{
    $items = [];
    $total = 0.0;
    $units = 0;
    foreach (project_installed_equipment($projectId) as $category => $rows) {
        foreach ($rows as $r) {
            $price = round((float)$r['unit_cost'], 2);
            $line = round($price * (int)$r['quantity'], 2);
            $items[] = [
                'category'   => $category,
                'item_name'  => $r['item_name'],
                'sku'        => $r['sku'],
                'model'      => $r['model'],
                'quantity'   => (int)$r['quantity'],
                'unit_price' => $price,
                'line_total' => $line,
            ];
            $total += $line;
            $units += (int)$r['quantity'];
        }
    }
    return ['items' => $items, 'total' => round($total, 2), 'count' => $units];
}

/** "LONGi Hi-MO 6 545W Panel (ST-INV-9002) × 15; …", cut to fit the 255-character column. */
function system_equipment_text(array $items): string
{
    $text = implode('; ', array_map(fn($i) => $i['item_name'] . ' (' . $i['sku'] . ') × ' . $i['quantity'], $items));
    return mb_strlen($text) > 255 ? mb_substr($text, 0, 254) . '…' : $text;
}

/**
 * Write what was actually installed into the project's solar system. A
 * category with no issued stock keeps what was typed in (the planned design),
 * so recording nothing in the warehouse never blanks a field.
 */
function project_record_installed_equipment(int $projectId): void
{
    $pdo = db();
    $stmt = $pdo->prepare('SELECT solar_system_id FROM projects WHERE id = :id');
    $stmt->execute([':id' => $projectId]);
    $systemId = (int)$stmt->fetchColumn();
    if (!$systemId) {
        return;
    }

    $sets = [];
    $params = [':id' => $systemId];
    foreach (project_installed_equipment($projectId) as $category => $items) {
        if (isset(SYSTEM_EQUIPMENT_COLUMNS[$category])) {
            $col = SYSTEM_EQUIPMENT_COLUMNS[$category];
            $sets[] = "$col = :$col";
            $params[":$col"] = system_equipment_text($items);
        }
    }
    if (!$sets) {
        return;
    }
    // Never let this block an installation from completing (e.g. the columns
    // are still 100 characters because phase9 has not been run yet).
    try {
        $pdo->prepare('UPDATE solar_systems SET ' . implode(', ', $sets) . ' WHERE id = :id')->execute($params);
    } catch (PDOException $e) {
        error_log('SunTrack installed equipment, project ' . $projectId . ': ' . $e->getMessage());
    }
}

/**
 * Everything the client's "Solar System Details" needs about one system, worked
 * out from the records rather than taken at face value:
 *   equipment        exact items installed (falls back to the typed text when the
 *                    warehouse recorded nothing for a category)
 *   installed_on     installation date; for an installed system with none stored,
 *                    the day its installation job was completed
 *   age_days / age_label   time since installed_on, e.g. "1 year, 3 months"
 *   status_label / status_detail   plain-language system status, taking open
 *                    repairs and overdue maintenance into account
 */
function system_client_summary(array $system): array
{
    $pdo = db();
    $p = $pdo->prepare('SELECT id, status, installation_date FROM projects WHERE solar_system_id = :s ORDER BY id DESC LIMIT 1');
    $p->execute([':s' => $system['id']]);
    $project = $p->fetch() ?: null;

    $installed = $project ? project_installed_equipment((int)$project['id']) : [];
    $equipment = [];
    foreach (SYSTEM_EQUIPMENT_COLUMNS as $category => $col) {
        $equipment[$col] = [
            'items' => $installed[$category] ?? [],
            'text'  => $system[$col] ?? null,
        ];
    }

    $isInstalled = in_array($system['status'], ['ACTIVE', 'FAULT', 'DECOMMISSIONED'], true);
    // Not installed yet: the project's installation date is the planned one.
    $installedOn = $isInstalled ? $system['installation_date'] : ($project['installation_date'] ?? null);
    if (!$installedOn && $isInstalled && $project) {
        $d = $pdo->prepare(
            "SELECT DATE(MIN(h.created_at)) FROM job_status_history h JOIN jobs j ON j.id = h.job_id
             WHERE j.project_id = :p AND j.job_type = 'INSTALLATION' AND h.to_stage = 'COMPLETED'"
        );
        $d->execute([':p' => $project['id']]);
        $installedOn = $d->fetchColumn() ?: $project['installation_date'];
    }

    $ageDays = $ageLabel = null;
    if ($isInstalled && $installedOn && $installedOn <= date('Y-m-d')) {
        $diff = (new DateTime($installedOn))->diff(new DateTime(date('Y-m-d')));
        $ageDays = $diff->days;
        $parts = [];
        if ($diff->y) { $parts[] = $diff->y . ' year' . ($diff->y === 1 ? '' : 's'); }
        if ($diff->m) { $parts[] = $diff->m . ' month' . ($diff->m === 1 ? '' : 's'); }
        if (!$diff->y && !$diff->m) { $parts[] = $diff->d . ' day' . ($diff->d === 1 ? '' : 's'); }
        $ageLabel = $ageDays === 0 ? 'Installed today' : implode(', ', $parts);
    }

    // Status: the system record first, then anything open against it.
    $openRepair = 0;
    $maint = null;
    if ($project) {
        $r = $pdo->prepare(
            "SELECT COUNT(*) FROM jobs WHERE project_id = :p AND job_type IN ('REPAIR','MAINTENANCE','INSPECTION')
             AND stage IN ('ASSIGNED','EN_ROUTE','ARRIVED','IN_PROGRESS','PAUSED')"
        );
        $r->execute([':p' => $project['id']]);
        $openRepair = (int)$r->fetchColumn();
        $m = $pdo->prepare('SELECT status, next_maintenance FROM maintenance_schedules WHERE project_id = :p');
        $m->execute([':p' => $project['id']]);
        $maint = $m->fetch() ?: null;
    }

    [$label, $detail] = match ($system['status']) {
        'PLANNED'        => ['Planned', $installedOn ? 'Installation scheduled for ' . date('M j, Y', strtotime($installedOn)) . '.' : 'Installation not yet scheduled.'],
        'INSTALLING'     => ['Installing', 'Our technicians are installing your system.'],
        'FAULT'          => ['Fault reported', $openRepair ? 'A technician is assigned to fix it.' : 'We are arranging a technician.'],
        'DECOMMISSIONED' => ['Decommissioned', 'This system is no longer in service.'],
        default          => ['Active', 'Operating normally.'],
    };
    if ($system['status'] === 'ACTIVE') {
        if ($openRepair) {
            [$label, $detail] = ['Active — service in progress', 'A technician is working on your system.'];
        } elseif ($maint && $maint['status'] === 'OVERDUE') {
            [$label, $detail] = ['Active — maintenance overdue', 'Maintenance was due on ' . date('M j, Y', strtotime($maint['next_maintenance'])) . '.'];
        } elseif ($maint && $maint['status'] === 'DUE') {
            [$label, $detail] = ['Active — maintenance due', 'Next maintenance on ' . date('M j, Y', strtotime($maint['next_maintenance'])) . '.'];
        }
    }

    return [
        'equipment'     => $equipment,
        'installed_on'  => $isInstalled ? $installedOn : null,
        'planned_for'   => $isInstalled ? null : $installedOn,
        'age_days'      => $ageDays,
        'age_label'     => $ageLabel,
        'status_label'  => $label,
        'status_detail' => $detail,
    ];
}

/**
 * Open (or keep) the project's maintenance schedule. $lastDate is the visit
 * that just happened (null right after installation).
 */
function project_schedule_next_maintenance(int $projectId, ?string $lastDate, string $fromDate): void
{
    $pdo = db();
    $next = maintenance_next_date($fromDate);

    // Row lock: the UNIQUE key on project_id (phase 2) is the real guarantee,
    // this just keeps two completions from racing each other's read.
    $stmt = $pdo->prepare('SELECT id, next_maintenance FROM maintenance_schedules WHERE project_id = :p FOR UPDATE');
    $stmt->execute([':p' => $projectId]);
    $row = $stmt->fetch();

    if (!$row) {
        $pdo->prepare(
            'INSERT INTO maintenance_schedules (project_id, last_maintenance, next_maintenance, status, client_notified)
             VALUES (:p, :last, :next, :status, 0)'
        )->execute([':p' => $projectId, ':last' => $lastDate, ':next' => $next, ':status' => maintenance_schedule_status($next)]);
        return;
    }

    // Right after an installation (no visit yet) an existing plan is kept as it is.
    if ($lastDate === null && $row['next_maintenance'] !== null) {
        return;
    }

    $pdo->prepare(
        'UPDATE maintenance_schedules
         SET last_maintenance = COALESCE(:last, last_maintenance), next_maintenance = :next, status = :status,
             client_notified = 0, notified_at = NULL
         WHERE id = :id'
    )->execute([':last' => $lastDate, ':next' => $next, ':status' => maintenance_schedule_status($next), ':id' => $row['id']]);
}

/**
 * Called by api/jobs/status.php inside its transaction, after jobs.stage moved.
 * Only jobs that belong to a project are affected.
 */
function project_on_job_stage(array $job, string $stage): void
{
    if (empty($job['project_id'])) {
        return;
    }
    $projectId = (int)$job['project_id'];
    $pdo = db();
    $today = date('Y-m-d');

    if ($job['job_type'] === 'INSTALLATION') {
        if ($stage === 'COMPLETED') {
            $pdo->prepare('UPDATE projects SET installation_date = COALESCE(installation_date, :d) WHERE id = :id')
                ->execute([':d' => $today, ':id' => $projectId]);
            // The system was installed today, whatever date the project had planned.
            $pdo->prepare(
                'UPDATE solar_systems SET installation_date = :d
                 WHERE id = (SELECT solar_system_id FROM projects WHERE id = :id) AND installation_date IS NULL'
            )->execute([':d' => $today, ':id' => $projectId]);
            project_sync_solar_system($projectId); // project is COMPLETED by now -> system ACTIVE
            project_record_installed_equipment($projectId);
            project_schedule_next_maintenance($projectId, null, $today);
        } elseif ($stage === 'IN_PROGRESS') {
            project_sync_solar_system($projectId); // project IN_PROGRESS -> system INSTALLING
        }
        return;
    }

    if ($job['job_type'] === 'MAINTENANCE' && $stage === 'COMPLETED') {
        $pdo->prepare('UPDATE projects SET last_maintenance = :d WHERE id = :id')->execute([':d' => $today, ':id' => $projectId]);
        project_schedule_next_maintenance($projectId, $today, $today);
    }
}
