<?php
/**
 * SunTrack ERP — the Reports tab (Management).
 *
 * Every report is defined once here and used by both
 *   api/reports/get_report.php   on-screen preview (JSON)
 *   api/reports/export.php       CSV download
 * so a download always contains exactly what the preview showed.
 *
 * Filters, all optional, read from the query string:
 *   search                 word-by-word, same columns as the module's own list
 *   status                 must be one of the report's own status values
 *   date_from / date_to    YYYY-MM-DD, inclusive, applied to the report's date field
 *
 * Column types tell the page how to display a value (the CSV keeps it raw):
 *   text | number | money | percent | date | datetime | status
 */

function report_definitions(): array
{
    $jobStages = ['SUBMITTED' => 'Submitted', 'ASSIGNED' => 'Assigned', 'EN_ROUTE' => 'En route', 'ARRIVED' => 'Arrived',
                  'IN_PROGRESS' => 'In progress', 'PAUSED' => 'Paused', 'COMPLETED' => 'Completed', 'CANCELLED' => 'Cancelled'];
    return [
        'job_report' => [
            'label' => 'Job Report', 'status_label' => 'Stage', 'statuses' => $jobStages,
            'date_label' => 'Scheduled date', 'search_hint' => 'Job code, client, technician, address…',
        ],
        'technician_performance' => [
            'label' => 'Technician Performance', 'status_label' => 'Availability',
            'statuses' => ['AVAILABLE' => 'Available', 'BUSY' => 'Busy', 'OFF_DUTY' => 'Off duty', 'ON_LEAVE' => 'On leave'],
            'date_label' => 'Work done between', 'search_hint' => 'Name, code, specialization…',
        ],
        'work_reports' => [
            'label' => 'Work Reports', 'status_label' => 'Status',
            'statuses' => ['DRAFT' => 'Draft', 'SUBMITTED' => 'Submitted', 'REVIEWED' => 'Reviewed'],
            'date_label' => 'Submitted date', 'search_hint' => 'Report or job code, client, technician…',
        ],
        'installation_progress' => [
            'label' => 'Projects / Installation Progress', 'status_label' => 'Status',
            'statuses' => ['PLANNED' => 'Planned', 'SCHEDULED' => 'Scheduled', 'IN_PROGRESS' => 'In progress',
                           'MAINTENANCE' => 'Maintenance', 'COMPLETED' => 'Completed', 'CANCELLED' => 'Cancelled'],
            'date_label' => 'Installation date', 'search_hint' => 'Project code, site, client, system type…',
        ],
        'maintenance_report' => [
            'label' => 'Maintenance Report', 'status_label' => 'Status',
            'statuses' => ['UPCOMING' => 'Upcoming', 'DUE' => 'Due', 'OVERDUE' => 'Overdue'],
            'date_label' => 'Next maintenance', 'search_hint' => 'Project code, site, client, city…',
        ],
        'inventory_report' => [
            'label' => 'Inventory Report', 'status_label' => 'Stock status',
            'statuses' => ['ACTIVE' => 'In stock', 'LOW_STOCK' => 'Low stock', 'OUT_OF_STOCK' => 'Out of stock', 'DISCONTINUED' => 'Discontinued'],
            'date_label' => null, 'search_hint' => 'SKU, item name, brand, category…',
        ],
        'service_request_report' => [
            'label' => 'Service Request Report', 'status_label' => 'Status',
            'statuses' => ['PENDING' => 'Pending', 'APPROVED' => 'Approved', 'ASSIGNED' => 'Assigned', 'SCHEDULED' => 'Scheduled',
                           'IN_PROGRESS' => 'In progress', 'ON_HOLD' => 'On hold', 'COMPLETED' => 'Completed',
                           'CANCELLED' => 'Cancelled', 'REJECTED' => 'Rejected'],
            'date_label' => 'Date requested', 'search_hint' => 'Request code, client, type, technician…',
        ],
    ];
}

/** "col >= :from AND col < :to+1" for the requested range; distinct param names per call. */
function report_range(string $column, string $prefix, array &$params): string
{
    $from = query_date('date_from');
    $to   = query_date('date_to');
    $sql  = '';
    if ($from !== null) {
        $sql .= " AND $column >= :{$prefix}_from";
        $params[":{$prefix}_from"] = $from;
    }
    if ($to !== null) {
        $sql .= " AND $column < :{$prefix}_to";
        $params[":{$prefix}_to"] = date('Y-m-d', strtotime($to . ' +1 day'));
    }
    return $sql;
}

/**
 * Run one report. $limit caps the rows returned (null = no cap);
 * 'total' is always the full number of matching rows.
 *
 * @return array{type:string,label:string,columns:array,rows:array,total:int}
 */
function report_build(PDO $pdo, string $type, ?int $limit = null): array
{
    $defs = report_definitions();
    if (!isset($defs[$type])) {
        json_error('Unknown report type.', 422);
    }
    $def = $defs[$type];

    $from = query_date('date_from');
    $to   = query_date('date_to');
    if ($from !== null && $to !== null && $from > $to) {
        json_error('The "from" date cannot be later than the "to" date.', 422);
    }

    $status = trim((string)($_GET['status'] ?? ''));
    if ($status !== '' && !isset($def['statuses'][$status])) {
        json_error('That status does not apply to the ' . $def['label'] . '.', 422);
    }
    $search = $_GET['search'] ?? '';

    $where  = [];
    $params = [];

    switch ($type) {
        case 'job_report':
            if ($c = search_clause($search, search_columns('jobs'), $params)) { $where[] = $c; }
            if ($status !== '') { $where[] = 'j.stage = :status'; $params[':status'] = $status; }
            apply_date_range('j.scheduled_date', $where, $params);
            $sql = "SELECT j.job_code, j.job_type, cu.full_name AS client_name, tu.full_name AS technician_name,
                           j.priority, j.stage, j.progress, j.scheduled_date, j.created_at
                    FROM jobs j
                    JOIN clients c ON c.id = j.client_id JOIN users cu ON cu.id = c.user_id
                    LEFT JOIN technicians t ON t.id = j.technician_id LEFT JOIN users tu ON tu.id = t.user_id
                    LEFT JOIN projects p ON p.id = j.project_id
                    %WHERE% ORDER BY j.created_at DESC, j.id DESC";
            $columns = [
                ['job_code', 'Job', 'text'], ['job_type', 'Type', 'status'], ['client_name', 'Client', 'text'],
                ['technician_name', 'Technician', 'text'], ['priority', 'Priority', 'status'], ['stage', 'Stage', 'status'],
                ['progress', 'Progress', 'percent'], ['scheduled_date', 'Scheduled', 'date'], ['created_at', 'Created', 'datetime'],
            ];
            break;

        case 'technician_performance':
            // The date range limits the work counted, not which technicians are listed.
            $where[] = "u.status = 'ACTIVE'";
            if ($c = search_clause($search, search_columns('technicians'), $params)) { $where[] = $c; }
            if ($status !== '') { $where[] = "COALESCE(ta.status, 'AVAILABLE') = :status"; $params[':status'] = $status; }
            $hRange  = report_range('h.created_at', 'h', $params);
            $wrRange = report_range('wr.submitted_date', 'wr', $params);
            $wdRange = report_range('wd.submitted_date', 'wd', $params);
            $aRange  = report_range('a.time_in', 'a', $params);
            $sql = "SELECT t.technician_code, u.full_name AS technician_name, t.specialization,
                           COALESCE(ta.status, 'AVAILABLE') AS availability,
                           (SELECT COUNT(*) FROM jobs oj WHERE oj.technician_id = t.id AND oj.stage NOT IN ('COMPLETED','CANCELLED')) AS open_jobs,
                           (SELECT COUNT(DISTINCT h.job_id) FROM job_status_history h JOIN jobs hj ON hj.id = h.job_id
                             WHERE hj.technician_id = t.id AND h.to_stage = 'COMPLETED' $hRange) AS jobs_completed,
                           (SELECT COUNT(*) FROM work_reports wr WHERE wr.technician_id = t.id $wrRange) AS reports_filed,
                           (SELECT ROUND(AVG(wd.duration_minutes)) FROM work_reports wd
                             WHERE wd.technician_id = t.id AND wd.duration_minutes IS NOT NULL $wdRange) AS avg_duration_min,
                           (SELECT COUNT(*) FROM attendance a WHERE a.technician_id = t.id AND a.geofence_status = 'OUTSIDE' $aRange) AS outside_geofence
                    FROM " . tech_staff_table() . " t
                    JOIN users u ON u.id = t.user_id
                    LEFT JOIN technician_availability ta ON ta.technician_id = t.id
                    %WHERE% ORDER BY jobs_completed DESC, u.full_name ASC";
            $columns = [
                ['technician_code', 'Code', 'text'], ['technician_name', 'Technician', 'text'], ['specialization', 'Specialization', 'text'],
                ['availability', 'Availability', 'status'], ['open_jobs', 'Open jobs', 'number'], ['jobs_completed', 'Jobs completed', 'number'],
                ['reports_filed', 'Reports filed', 'number'], ['avg_duration_min', 'Avg. duration (min)', 'number'],
                ['outside_geofence', 'Time-ins outside geofence', 'number'],
            ];
            break;

        case 'work_reports':
            if ($c = search_clause($search, search_columns('work_reports'), $params)) { $where[] = $c; }
            if ($status !== '') { $where[] = 'wr.status = :status'; $params[':status'] = $status; }
            apply_date_range('wr.submitted_date', $where, $params);
            $sql = "SELECT wr.report_code, j.job_code, tu.full_name AS technician_name, cu.full_name AS client_name,
                           wr.work_type, wr.status, wr.submitted_date, COALESCE(wr.duration_text, wr.duration_minutes) AS duration_text, wr.remarks
                    FROM work_reports wr
                    JOIN jobs j ON j.id = wr.job_id
                    JOIN technicians t ON t.id = wr.technician_id JOIN users tu ON tu.id = t.user_id
                    JOIN clients c ON c.id = wr.client_id JOIN users cu ON cu.id = c.user_id
                    %WHERE% ORDER BY wr.submitted_date DESC, wr.id DESC";
            $columns = [
                ['report_code', 'Report', 'text'], ['job_code', 'Job', 'text'], ['technician_name', 'Technician', 'text'],
                ['client_name', 'Client', 'text'], ['work_type', 'Type', 'text'], ['status', 'Status', 'status'],
                ['submitted_date', 'Submitted', 'datetime'], ['duration_text', 'Duration', 'text'], ['remarks', 'Remarks', 'text'],
            ];
            break;

        case 'installation_progress':
            if ($c = search_clause($search, search_columns('projects'), $params)) { $where[] = $c; }
            if ($status !== '') { $where[] = 'p.status = :status'; $params[':status'] = $status; }
            apply_date_range('p.installation_date', $where, $params);
            // Checklist items done (completed or not applicable) out of all items, across the project's installation jobs.
            $sql = "SELECT p.project_code, p.site_name, cu.full_name AS client_name, p.system_type, p.capacity_kw,
                           tu.full_name AS technician_name, p.status, p.progress, p.installation_date,
                           (SELECT CONCAT(SUM(ii.status IN ('COMPLETED','NOT_APPLICABLE')), ' / ', COUNT(*))
                              FROM installation_items ii
                              JOIN installation_checklists ck ON ck.id = ii.checklist_id
                              JOIN jobs ij ON ij.id = ck.job_id
                             WHERE ij.project_id = p.id AND ij.job_type = 'INSTALLATION') AS checklist
                    FROM projects p
                    JOIN clients c ON c.id = p.client_id JOIN users cu ON cu.id = c.user_id
                    LEFT JOIN technicians t ON t.id = p.assigned_technician_id LEFT JOIN users tu ON tu.id = t.user_id
                    %WHERE% ORDER BY p.id DESC";
            $columns = [
                ['project_code', 'Project', 'text'], ['site_name', 'Site', 'text'], ['client_name', 'Client', 'text'],
                ['system_type', 'System type', 'text'], ['capacity_kw', 'Capacity (kW)', 'number'], ['technician_name', 'Technician', 'text'],
                ['status', 'Status', 'status'], ['progress', 'Progress', 'percent'], ['checklist', 'Checklist items done', 'text'],
                ['installation_date', 'Installation date', 'date'],
            ];
            break;

        case 'maintenance_report':
            maintenance_refresh_statuses();
            if ($c = search_clause($search, search_columns('maintenance'), $params)) { $where[] = $c; }
            if ($status !== '') { $where[] = 'ms.status = :status'; $params[':status'] = $status; }
            apply_date_range('ms.next_maintenance', $where, $params);
            $sql = "SELECT p.project_code, p.site_name, cu.full_name AS client_name, c.city,
                           ms.last_maintenance, ms.next_maintenance, ms.status,
                           IF(ms.client_notified = 1, 'Yes', 'No') AS client_notified,
                           (SELECT COUNT(*) FROM maintenance_records mr JOIN jobs mj ON mj.id = mr.job_id
                             WHERE mj.project_id = p.id AND mr.status = 'COMPLETED') AS inspections_done
                    FROM maintenance_schedules ms
                    JOIN projects p ON p.id = ms.project_id
                    JOIN clients c ON c.id = p.client_id JOIN users cu ON cu.id = c.user_id
                    %WHERE% ORDER BY ms.next_maintenance ASC, p.id ASC";
            $columns = [
                ['project_code', 'Project', 'text'], ['site_name', 'Site', 'text'], ['client_name', 'Client', 'text'],
                ['city', 'City', 'text'], ['last_maintenance', 'Last maintenance', 'date'], ['next_maintenance', 'Next maintenance', 'date'],
                ['status', 'Status', 'status'], ['client_notified', 'Client notified', 'text'], ['inspections_done', 'Inspections done', 'number'],
            ];
            break;

        case 'inventory_report':
            if ($c = search_clause($search, search_columns('inventory'), $params)) { $where[] = $c; }
            if ($status !== '') { $where[] = 'i.status = :status'; $params[':status'] = $status; }
            $sql = "SELECT i.sku, i.item_name, ic.category_name, i.brand, i.model, i.quantity,
                           i.unit_cost, ROUND(i.quantity * i.unit_cost, 2) AS stock_value, i.warehouse_location, i.status
                    FROM inventory i
                    JOIN inventory_categories ic ON ic.id = i.category_id
                    %WHERE% ORDER BY ic.category_name ASC, i.item_name ASC";
            $columns = [
                ['sku', 'SKU', 'text'], ['item_name', 'Item', 'text'], ['category_name', 'Category', 'text'],
                ['brand', 'Brand', 'text'], ['model', 'Model', 'text'], ['quantity', 'In stock', 'number'],
                ['unit_cost', 'Unit cost', 'money'], ['stock_value', 'Stock value', 'money'],
                ['warehouse_location', 'Location', 'text'], ['status', 'Status', 'status'],
            ];
            break;

        case 'service_request_report':
            if ($c = search_clause($search, search_columns('service_requests'), $params)) { $where[] = $c; }
            if ($status !== '') { $where[] = 'sr.status = :status'; $params[':status'] = $status; }
            apply_date_range('sr.date_requested', $where, $params);
            $sql = "SELECT sr.request_code, u.full_name AS client_name, sr.request_type, sr.priority, sr.status,
                           tu.full_name AS technician_name, sr.date_requested, sr.completion_date
                    FROM service_requests sr
                    JOIN clients c ON c.id = sr.client_id JOIN users u ON u.id = c.user_id
                    LEFT JOIN technicians t ON t.id = sr.assigned_technician_id LEFT JOIN users tu ON tu.id = t.user_id
                    %WHERE% ORDER BY sr.date_requested DESC, sr.id DESC";
            $columns = [
                ['request_code', 'Request', 'text'], ['client_name', 'Client', 'text'], ['request_type', 'Type', 'text'],
                ['priority', 'Priority', 'status'], ['status', 'Status', 'status'], ['technician_name', 'Technician', 'text'],
                ['date_requested', 'Requested', 'datetime'], ['completion_date', 'Completed', 'datetime'],
            ];
            break;
    }

    $sql = str_replace('%WHERE%', $where ? 'WHERE ' . implode(' AND ', $where) : '', $sql);

    $count = $pdo->prepare("SELECT COUNT(*) FROM ($sql) report_rows");
    $count->execute($params);
    $total = (int)$count->fetchColumn();

    $stmt = $pdo->prepare($limit !== null ? $sql . ' LIMIT ' . max(1, $limit) : $sql);
    $stmt->execute($params);

    return [
        'type'    => $type,
        'label'   => $def['label'],
        'columns' => array_map(fn($c) => ['key' => $c[0], 'label' => $c[1], 'type' => $c[2]], $columns),
        'rows'    => $stmt->fetchAll(),
        'total'   => $total,
    ];
}
