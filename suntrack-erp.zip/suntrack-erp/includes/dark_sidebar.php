<?php
/**
 * Renders the sidebar nav for the suntrackDark-themed portals (client/technician/warehouse).
 * $items = [ ['key'=>'dashboard','label'=>'Dashboard','icon'=>'fa-gauge-high','wired'=>true], ... ]
 * Optional 'badge_id' renders a hidden count pill with that id for the page's JS to fill in.
 */
function render_dark_sidebar(array $items, string $activeKey, string $portalTitle): void
{
    $name = h($_SESSION['full_name'] ?? '');
    ?>
    <!-- Mobile top bar: replaces the full sidebar on phones so it doesn't eat the screen above the content -->
    <div class="md:hidden sticky top-0 z-30 bg-suntrackDark border-b border-slate-800/60 px-3 py-3 flex items-center justify-between">
      <button id="mobile-menu-btn" type="button" aria-label="Open menu" aria-controls="app-sidebar" aria-expanded="false"
              class="text-slate-300 hover:text-white p-2 -ml-2 rounded-lg active:bg-slate-800/60">
        <i class="fas fa-bars text-lg"></i>
      </button>
      <div class="flex items-center gap-2">
        <div class="bg-suntrackOrange p-1.5 rounded-lg text-white"><i class="fas fa-solar-panel text-sm"></i></div>
        <span class="text-white font-extrabold text-sm"><?= h($portalTitle) ?></span>
      </div>
      <a href="<?= APP_BASE_URL ?>/logout.php" title="Logout" class="text-slate-400 hover:text-suntrackOrange p-2 -mr-2"><i class="fas fa-right-from-bracket"></i></a>
    </div>
    <!-- Backdrop shown behind the drawer while open on mobile; tap to close -->
    <div id="sidebar-backdrop" class="hidden md:hidden fixed inset-0 bg-black/50 z-40"></div>
    <aside id="app-sidebar" class="w-64 max-w-[85vw] bg-suntrackDark text-slate-400 flex flex-col justify-between p-4 border-r border-slate-800/40 shrink-0 fixed inset-y-0 left-0 z-50 -translate-x-full transition-transform duration-300 ease-in-out shadow-2xl md:shadow-none md:translate-x-0 md:z-auto md:h-screen md:sticky md:top-0">
      <div>
        <div class="flex items-center gap-2 px-2 mb-6">
          <div class="bg-suntrackOrange p-2 rounded-xl text-white shadow-lg shadow-orange-600/20"><i class="fas fa-solar-panel text-lg"></i></div>
          <div>
            <p class="text-white font-extrabold text-sm leading-tight">SunTrack</p>
            <p class="text-[10px] text-slate-500 leading-tight"><?= h($portalTitle) ?></p>
          </div>
        </div>
        <nav class="space-y-1">
          <?php foreach ($items as $item): $active = $item['key'] === $activeKey; ?>
            <a href="#" data-tab="<?= h($item['key']) ?>"
               class="tab-link flex items-center justify-between gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition <?= $active ? 'bg-suntrackOrange text-white shadow-md shadow-orange-600/20' : 'hover:bg-slate-800/60 text-slate-300' ?>">
              <span class="flex items-center gap-3"><i class="fas <?= h($item['icon']) ?> w-4"></i><?= h($item['label']) ?></span>
              <?php if (empty($item['wired'])): ?><span class="text-[9px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded-md">soon</span><?php endif; ?>
              <?php if (!empty($item['badge_id'])): ?><span id="<?= h($item['badge_id']) ?>" class="hidden text-[10px] bg-red-500 text-white px-1.5 py-0.5 rounded-full font-bold"></span><?php endif; ?>
            </a>
          <?php endforeach; ?>
        </nav>
      </div>
      <div class="bg-suntrackNav border border-slate-800/60 rounded-2xl p-3 mt-6 flex items-center gap-3 shadow-inner">
        <div class="h-9 w-9 rounded-xl bg-suntrackOrange flex items-center justify-center text-white text-sm font-bold shadow-md shadow-orange-500/20">
          <?= h(initial($name)) ?>
        </div>
        <div class="flex-1 min-w-0">
          <p class="text-white text-xs font-bold truncate"><?= $name ?></p>
          <p class="text-[10px] text-slate-500"><?= h(current_role()) ?></p>
        </div>
        <a href="<?= APP_BASE_URL ?>/logout.php" title="Logout" class="text-slate-400 hover:text-suntrackOrange"><i class="fas fa-right-from-bracket"></i></a>
      </div>
    </aside>
    <script>
    (function () {
      var btn = document.getElementById('mobile-menu-btn');
      var aside = document.getElementById('app-sidebar');
      var backdrop = document.getElementById('sidebar-backdrop');
      if (!btn || !aside || !backdrop) return;
      function isOpen() { return !aside.classList.contains('-translate-x-full'); }
      function openMenu() {
        aside.classList.remove('-translate-x-full');
        backdrop.classList.remove('hidden');
        btn.setAttribute('aria-expanded', 'true');
      }
      function closeMenu() {
        aside.classList.add('-translate-x-full');
        backdrop.classList.add('hidden');
        btn.setAttribute('aria-expanded', 'false');
      }
      btn.addEventListener('click', function () { isOpen() ? closeMenu() : openMenu(); });
      backdrop.addEventListener('click', closeMenu);
      // Auto-close after picking a nav item on mobile, so the drawer doesn't stay over the content.
      document.addEventListener('click', function (e) {
        if (e.target.closest('.tab-link') && isOpen()) closeMenu();
      });
      // If the viewport is resized up to desktop while open, drop the mobile-only state.
      window.addEventListener('resize', function () {
        if (window.innerWidth >= 768) closeMenu();
      });
    })();
    </script>
    <?php
}
