<?php
/**
 * SunTrack ERP — subcontractors and automatic assignment
 * (database/phase19_subcontractors.sql).
 *
 * A job is done by an internal technician (jobs.technician_id) OR by ONE
 * subcontractor (subcontractor_assignments; a unique index allows only one
 * open assignment per job).
 *
 * Automatic assignment (sub_auto_sweep):
 *   When the technicians are almost full — used slots ≥ the capacity
 *   threshold, or nobody has a free slot — new unassigned jobs are offered to
 *   the best-matching approved subcontractor (service area, specialty,
 *   workload, track record). The offer reaches their phone (push) and their
 *   portal dashboard. A decline, or no answer before offer_expires_at, moves
 *   the offer to the next-best subcontractor; when nobody is left, Management
 *   is told. Settings: subcon_auto_mode (auto | suggest | off),
 *   tech_max_open_jobs, subcon_capacity_threshold (%), subcon_offer_hours.
 *
 * Statuses kept apart:
 *   job stage        jobs.stage — synced from the assignment
 *   assignment       AWAITING_ACCEPTANCE → ACCEPTED → SCHEDULED → IN_PROGRESS →
 *                    AWAITING_INSPECTION → APPROVED | REVISION_REQUIRED → COMPLETED
 *                    (+ DECLINED, CANCELLED)
 * Checklists are the job's existing installation / maintenance checklists.
 * Every action goes to subcontractor_events with who and when.
 */

const SUB_STATUSES = ['PENDING', 'APPROVED', 'SUSPENDED', 'INACTIVE'];
const SA_OPEN = ['AWAITING_ACCEPTANCE', 'ACCEPTED', 'SCHEDULED', 'IN_PROGRESS', 'AWAITING_INSPECTION', 'REVISION_REQUIRED', 'APPROVED'];
const SA_LABELS = [
    'AWAITING_ACCEPTANCE' => 'Awaiting Acceptance', 'ACCEPTED' => 'Accepted', 'DECLINED' => 'Declined',
    'SCHEDULED' => 'Scheduled', 'IN_PROGRESS' => 'In Progress', 'AWAITING_INSPECTION' => 'Awaiting Inspection',
    'REVISION_REQUIRED' => 'Revision Required', 'APPROVED' => 'Approved', 'COMPLETED' => 'Completed', 'CANCELLED' => 'Cancelled',
];
/** Allowed moves and who may make them: sub = the assigned subcontractor, mgmt = manager / staff, system = automatic. */
const SA_MOVES = [
    'AWAITING_ACCEPTANCE' => ['ACCEPTED' => 'sub', 'DECLINED' => 'sub', 'CANCELLED' => 'mgmt'],
    'ACCEPTED'            => ['SCHEDULED' => 'sub', 'IN_PROGRESS' => 'sub', 'CANCELLED' => 'mgmt'],
    'SCHEDULED'           => ['SCHEDULED' => 'sub', 'IN_PROGRESS' => 'sub', 'CANCELLED' => 'mgmt'],
    'IN_PROGRESS'         => ['AWAITING_INSPECTION' => 'sub', 'CANCELLED' => 'mgmt'],
    'AWAITING_INSPECTION' => ['APPROVED' => 'mgmt', 'REVISION_REQUIRED' => 'mgmt'],
    'REVISION_REQUIRED'   => ['AWAITING_INSPECTION' => 'sub', 'CANCELLED' => 'mgmt'],
    'APPROVED'            => ['COMPLETED' => 'mgmt'],
];
const SUB_FILE_MAX_BYTES = 10 * 1024 * 1024;

function sub_ready(): bool
{
    static $ok = null;
    if ($ok === null) {
        try {
            db()->query('SELECT status, user_id, max_active_jobs FROM subcontractors LIMIT 0');
            db()->query('SELECT active_job_id, auto_assigned, offer_expires_at FROM subcontractor_assignments LIMIT 0');
            db()->query('SELECT 1 FROM subcontractor_events LIMIT 0');
            $ok = true;
        } catch (PDOException $e) {
            $ok = false;
        }
    }
    return $ok;
}

function sub_require_schema(): void
{
    if (!sub_ready()) {
        json_error('Subcontractor management is not set up yet. Import database/phase19_subcontractors.sql.', 503);
    }
}

/** Roll back an open transaction, then answer with an error. */
function sub_fail(string $message, int $code = 422): never
{
    $pdo = db();
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    json_error($message, $code);
}

/** Manager / staff may manage subcontractors; Admin is view-only. */
function sub_is_management(): bool
{
    return in_array(current_role(), ['manager', 'staff'], true);
}

function sub_get(PDO $pdo, int $id, bool $lock = false): ?array
{
    $s = $pdo->prepare('SELECT * FROM subcontractors WHERE id = :id' . ($lock ? ' FOR UPDATE' : ''));
    $s->execute([':id' => $id]);
    return $s->fetch() ?: null;
}

/**
 * The signed-in subcontractor (portal), checked on every request: right role,
 * linked to this company, login still active. $forWrite: changes need an
 * APPROVED company; a suspended / inactive one may only look.
 */
function sub_portal_current(bool $forWrite = false): array
{
    // The session itself (not field mode's acting role / profile).
    if (($_SESSION['role_key'] ?? null) !== 'subcontractor') {
        json_error('You are not authorized to access this resource.', 403);
    }
    $sub = sub_get(db(), (int)($_SESSION['profile_id'] ?? 0));
    if (!$sub || (int)$sub['user_id'] !== (int)current_user_id()) {
        json_error('Your login is not linked to a subcontractor. Contact SunTrack management.', 403);
    }
    $u = db()->prepare('SELECT status FROM users WHERE id = :id');
    $u->execute([':id' => current_user_id()]);
    if ($u->fetchColumn() !== 'ACTIVE') {
        json_error('Your portal login has been disabled. Contact SunTrack management.', 403);
    }
    if ($forWrite && $sub['status'] !== 'APPROVED') {
        json_error('Your subcontractor account is ' . strtolower($sub['status']) . '. You can view your records but not make changes.', 403);
    }
    return $sub;
}

// ---------------------------------------------------------------------------
// Field mode — the company works its accepted jobs in the technician portal
// ---------------------------------------------------------------------------

/** Has phase 19's field-profile column been imported? */
function sub_field_ready(): bool
{
    static $ok = null;
    if ($ok === null) {
        try {
            db()->query('SELECT subcontractor_id FROM technicians LIMIT 0');
            $ok = true;
        } catch (PDOException $e) {
            $ok = false;
        }
    }
    return $ok;
}

/**
 * The company's own technicians as a FROM source: field profiles (rows linked
 * to a subcontractor) are left out of lists, counts, slots and dropdowns, and
 * cannot be picked as a technician. Plain table before phase 19 is imported.
 */
function tech_staff_table(): string
{
    return sub_field_ready() ? '(SELECT * FROM technicians WHERE subcontractor_id IS NULL)' : 'technicians';
}

/**
 * The company's field profile (a technicians row linked by subcontractor_id),
 * created on first use, following the company's current portal login.
 * Null when the company has no login yet.
 */
function sub_field_tech_id(PDO $pdo, ?array $sub): ?int
{
    if (!$sub || empty($sub['user_id']) || !sub_field_ready()) {
        return null;
    }
    $s = $pdo->prepare('SELECT id, user_id FROM technicians WHERE subcontractor_id = :s');
    $s->execute([':s' => $sub['id']]);
    if ($row = $s->fetch()) {
        if ((int)$row['user_id'] !== (int)$sub['user_id']) {
            $pdo->prepare('UPDATE technicians SET user_id = :u WHERE id = :id')->execute([':u' => $sub['user_id'], ':id' => $row['id']]);
        }
        return (int)$row['id'];
    }
    $pdo->prepare(
        'INSERT INTO technicians (user_id, subcontractor_id, technician_code, specialization, geofence_enabled)
         VALUES (:u, :s, :c, :sp, 1)'
    )->execute([':u' => $sub['user_id'], ':s' => $sub['id'], ':c' => mb_substr($sub['subcon_code'], 0, 20),
                ':sp' => mb_substr((string)($sub['specialties'] ?: $sub['specialization']), 0, 100) ?: null]);
    $id = (int)$pdo->lastInsertId();
    $pdo->prepare("INSERT IGNORE INTO technician_availability (technician_id, status) VALUES (:t, 'AVAILABLE')")->execute([':t' => $id]);
    return $id;
}

/**
 * Called by the technician-portal endpoints (middleware/technician.php and the
 * shared ones). For a subcontractor session it switches this request into
 * field mode: current_role() reads 'technician' and current_profile_id() the
 * company's field profile, so every technician rule (own jobs only, GPS Time
 * In, checklist, completion gate) applies unchanged. A company that is not
 * APPROVED can look but not change anything. Other roles: no effect.
 */
function field_mode_enter(bool $isApi): void
{
    if (($_SESSION['role_key'] ?? null) !== 'subcontractor' || !empty($GLOBALS['__field_sub'])) {
        return;
    }
    require_login($isApi);
    if (!sub_ready() || !sub_field_ready()) {
        return; // require_role() then refuses — the migration is not imported
    }
    $deny = function (string $msg) use ($isApi): never {
        if ($isApi) {
            json_error($msg, 403);
        }
        http_response_code(403);
        die('403 Forbidden — ' . htmlspecialchars($msg));
    };
    $pdo = db();
    $sub = sub_get($pdo, (int)($_SESSION['profile_id'] ?? 0));
    $u = $pdo->prepare('SELECT status FROM users WHERE id = :id');
    $u->execute([':id' => current_user_id()]);
    if (!$sub || (int)$sub['user_id'] !== (int)current_user_id() || $u->fetchColumn() !== 'ACTIVE') {
        $deny('Your login is not linked to an active subcontractor. Contact SunTrack management.');
    }
    if ($isApi && ($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET' && $sub['status'] !== 'APPROVED') {
        $deny('Your subcontractor account is ' . strtolower($sub['status']) . '. You can view your jobs but not make changes.');
    }
    $GLOBALS['__field_tech_id'] = sub_field_tech_id($pdo, $sub);
    $GLOBALS['__field_sub'] = $sub;
}

/**
 * Is this service request the current field user's? A technician: assigned to
 * them. A subcontractor (field mode): its job is worked by the company.
 */
function sr_field_visible(array $sr): bool
{
    $me = (int)current_profile_id();
    if (!field_subcontractor()) {
        return (int)$sr['assigned_technician_id'] === $me;
    }
    if (empty($sr['job_id'])) {
        return false;
    }
    $s = db()->prepare('SELECT technician_id FROM jobs WHERE id = :j');
    $s->execute([':j' => $sr['job_id']]);
    return (int)$s->fetchColumn() === $me;
}

/** The company's open assignment on a job (locked when $lock), or null. */
function sub_field_assignment(PDO $pdo, int $jobId, int $subId, bool $lock = false): ?array
{
    $s = $pdo->prepare('SELECT id FROM subcontractor_assignments WHERE active_job_id = :j AND subcontractor_id = :s');
    $s->execute([':j' => $jobId, ':s' => $subId]);
    $id = $s->fetchColumn();
    if (!$id) {
        return null;
    }
    return $lock ? sub_lock_assignment($pdo, (int)$id, $subId) : sub_assignment($pdo, (int)$id);
}

/**
 * What the field portal shows about the company's assignment on each job:
 * [job_id => [code, status, label, scope, instructions, materials, amount,
 * due, review note]]. Field mode only.
 */
function field_assignment_info(PDO $pdo, array $jobIds): array
{
    $sub = field_subcontractor();
    $jobIds = array_values(array_filter(array_map('intval', $jobIds)));
    if (!$sub || !$jobIds) {
        return [];
    }
    $s = $pdo->prepare(
        'SELECT job_id, id, assignment_code, status, scope, instructions, materials_note, contract_amount, expected_completion, review_note, revision_count
         FROM subcontractor_assignments WHERE subcontractor_id = ? AND job_id IN (' . implode(',', $jobIds) . ')
         ORDER BY id'
    );
    $s->execute([$sub['id']]);
    $out = [];
    foreach ($s->fetchAll() as $r) { // latest assignment per job wins
        $out[(int)$r['job_id']] = [
            'assignment_id' => (int)$r['id'], 'assignment_code' => $r['assignment_code'], 'status' => $r['status'],
            'status_label' => SA_LABELS[$r['status']], 'scope' => $r['scope'], 'instructions' => $r['instructions'],
            'materials_note' => $r['materials_note'], 'contract_amount' => (float)$r['contract_amount'],
            'expected_completion' => $r['expected_completion'], 'review_note' => $r['review_note'], 'revision_count' => (int)$r['revision_count'],
        ];
    }
    return $out;
}

/**
 * Everything a completed job sets off — the same as a technician completing
 * one in api/jobs/status.php: project, maintenance record, solar system and
 * next maintenance, the linked service request, and the field profile's
 * availability. The service-request changes are kept for the caller to
 * announce after commit ($GLOBALS['__sub_sr_changed']).
 */
function sub_job_completed_effects(PDO $pdo, int $jobId): void
{
    $s = $pdo->prepare('SELECT * FROM jobs WHERE id = :id');
    $s->execute([':id' => $jobId]);
    $job = $s->fetch();
    if (!$job) {
        return;
    }
    if ($job['project_id']) {
        $pdo->prepare('UPDATE projects SET status = "COMPLETED", progress = 100 WHERE id = :p')->execute([':p' => $job['project_id']]);
    }
    if ($job['job_type'] === 'MAINTENANCE') {
        $pdo->prepare('UPDATE maintenance_records SET status = "COMPLETED", completion_date = NOW() WHERE job_id = :j AND status <> "COMPLETED"')
            ->execute([':j' => $jobId]);
    }
    project_on_job_stage($job, 'COMPLETED');
    $GLOBALS['__sub_sr_changed'] = sr_sync_from_job($jobId, 'COMPLETED', 'Completed by subcontractor — approved by Management');
    if ($job['technician_id'] && !tech_active_field_jobs((int)$job['technician_id'], $jobId) && tech_availability((int)$job['technician_id']) === 'BUSY') {
        tech_set_availability((int)$job['technician_id'], 'AVAILABLE');
    }
}

function sub_assignment_sql(): string
{
    return "SELECT a.*, j.job_code, j.job_type, j.stage AS job_stage, j.site_address, j.site_lat, j.site_lng,
                   j.scheduled_date AS job_scheduled_date, j.priority, j.description AS job_description, j.client_id, j.project_id,
                   c.client_code, c.city AS client_city, cu.full_name AS client_name, cu.phone AS client_phone,
                   s.subcon_code, s.name AS subcontractor_name, s.status AS subcontractor_status
            FROM subcontractor_assignments a
            JOIN jobs j ON j.id = a.job_id
            JOIN clients c ON c.id = j.client_id
            JOIN users cu ON cu.id = c.user_id
            JOIN subcontractors s ON s.id = a.subcontractor_id";
}

function sub_assignment(PDO $pdo, int $id): ?array
{
    $s = $pdo->prepare(sub_assignment_sql() . ' WHERE a.id = :id');
    $s->execute([':id' => $id]);
    return $s->fetch() ?: null;
}

/**
 * Lock the job row, then the assignment row (always this order — no
 * deadlocks) and return the fresh assignment. Portal callers pass their own
 * subcontractor id: anyone else's assignment is a 404, never revealed.
 */
function sub_lock_assignment(PDO $pdo, int $id, ?int $subId = null): array
{
    $j = $pdo->prepare('SELECT job_id, subcontractor_id FROM subcontractor_assignments WHERE id = :id');
    $j->execute([':id' => $id]);
    $row = $j->fetch();
    if (!$row || ($subId !== null && (int)$row['subcontractor_id'] !== $subId)) {
        sub_fail('Assignment not found.', 404);
    }
    $pdo->prepare('SELECT id FROM jobs WHERE id = :id FOR UPDATE')->execute([':id' => $row['job_id']]);
    $pdo->prepare('SELECT id FROM subcontractor_assignments WHERE id = :id FOR UPDATE')->execute([':id' => $id]);
    return sub_assignment($pdo, $id);
}

function sub_portal_assignment(PDO $pdo, int $id, int $subId): array
{
    $a = sub_assignment($pdo, $id);
    if (!$a || (int)$a['subcontractor_id'] !== $subId) {
        json_error('Assignment not found.', 404);
    }
    return $a;
}

function sub_active_assignment_for_job(PDO $pdo, int $jobId): ?array
{
    if (!sub_ready()) {
        return null;
    }
    $s = $pdo->prepare(sub_assignment_sql() . ' WHERE a.active_job_id = :j');
    $s->execute([':j' => $jobId]);
    return $s->fetch() ?: null;
}

function sub_event(PDO $pdo, ?int $assignmentId, int $subId, string $action, ?string $from, ?string $to, ?string $note = null, bool $system = false): void
{
    $pdo->prepare(
        'INSERT INTO subcontractor_events (assignment_id, subcontractor_id, action, from_status, to_status, note, actor_user_id, actor_role, created_at)
         VALUES (:a, :s, :act, :f, :t, :n, :u, :r, :at)'
    )->execute([
        ':a' => $assignmentId, ':s' => $subId, ':act' => $action, ':f' => $from, ':t' => $to,
        ':n' => $note !== null ? mb_substr($note, 0, 500) : null,
        ':u' => $system ? null : current_user_id(), ':r' => $system ? 'system' : current_role(),
        ':at' => date('Y-m-d H:i:s'),
    ]);
}

/** Move the job to $stage (with job_status_history) unless it is already there. */
function sub_job_stage(PDO $pdo, array $a, string $stage, string $note): void
{
    $cur = $pdo->prepare('SELECT stage FROM jobs WHERE id = :id');
    $cur->execute([':id' => $a['job_id']]);
    $from = $cur->fetchColumn();
    if ($from === $stage) {
        $pdo->prepare('UPDATE jobs SET updated_at = CURRENT_TIMESTAMP WHERE id = :id')->execute([':id' => $a['job_id']]);
        return;
    }
    $pdo->prepare('UPDATE jobs SET stage = :s' . ($stage === 'COMPLETED' ? ', progress = 100' : '') . ' WHERE id = :id')
        ->execute([':s' => $stage, ':id' => $a['job_id']]);
    $pdo->prepare('INSERT INTO job_status_history (job_id, from_stage, to_stage, changed_by, note) VALUES (:j, :f, :t, :u, :n)')
        ->execute([':j' => $a['job_id'], ':f' => $from, ':t' => $stage, ':u' => current_user_id(), ':n' => mb_substr($note, 0, 255)]);
}

/**
 * Move a locked assignment to $to. $actor must match SA_MOVES ('sub' / 'mgmt'),
 * or be 'system' for automatic moves (offer expiry). $extra: column => value;
 * ['raw' => 'col + 1'] for a counter (fixed in code — user input is a string).
 */
function sub_move(PDO $pdo, array $a, string $to, string $actor, ?string $note = null, array $extra = []): array
{
    $from = $a['status'];
    $who = SA_MOVES[$from][$to] ?? null;
    if ($who === null || ($actor === 'system' && !($from === 'AWAITING_ACCEPTANCE' && $to === 'DECLINED'))) {
        sub_fail('This assignment is ' . SA_LABELS[$from] . ' — it cannot be moved to ' . (SA_LABELS[$to] ?? $to) . '.', 409);
    }
    if ($actor !== 'system' && $who !== $actor) {
        sub_fail('You are not allowed to make this change.', 403);
    }
    $set = ['status = :st'];
    $params = [':st' => $to, ':id' => $a['id']];
    foreach ($extra as $col => $val) {
        if (!preg_match('/^[a-z_]+$/', $col)) {
            throw new InvalidArgumentException('bad column');
        }
        if (is_array($val)) {
            if (!isset($val['raw']) || !preg_match('/^[a-z_]+ \+ 1$/', $val['raw'])) {
                throw new InvalidArgumentException('bad raw fragment');
            }
            $set[] = "$col = " . $val['raw'];
            continue;
        }
        $set[] = "$col = :x_$col";
        $params[":x_$col"] = $val;
    }
    $pdo->prepare('UPDATE subcontractor_assignments SET ' . implode(', ', $set) . ' WHERE id = :id')->execute($params);
    sub_event($pdo, (int)$a['id'], (int)$a['subcontractor_id'], 'STATUS', $from, $to, $note, $actor === 'system');

    $tag = $a['subcon_code'] . ' ' . $a['assignment_code'];
    switch ($to) {
        case 'ACCEPTED':
            sub_job_stage($pdo, $a, 'ASSIGNED', "Accepted by subcontractor $tag");
            // The company now works the job in the field portal as its field profile.
            if ($techId = sub_field_tech_id($pdo, sub_get($pdo, (int)$a['subcontractor_id']))) {
                $pdo->prepare('UPDATE jobs SET technician_id = :t WHERE id = :j')->execute([':t' => $techId, ':j' => $a['job_id']]);
            }
            break;
        case 'IN_PROGRESS':
            sub_job_stage($pdo, $a, 'IN_PROGRESS', "Work started by subcontractor $tag");
            break;
        case 'COMPLETED':
            sub_job_stage($pdo, $a, 'COMPLETED', "Completed by subcontractor $tag — approved by Management");
            sub_job_completed_effects($pdo, (int)$a['job_id']);
            break;
        case 'DECLINED':
        case 'CANCELLED':
            sub_job_stage($pdo, $a, 'SUBMITTED', ($to === 'DECLINED' ? 'Declined' : 'Assignment cancelled') . " — $tag" . ($note ? ": $note" : ''));
            // Off the company's field profile (a real technician on the job is left alone).
            $pdo->prepare('UPDATE jobs j JOIN technicians t ON t.id = j.technician_id AND t.subcontractor_id = :s
                           SET j.technician_id = NULL WHERE j.id = :j')
                ->execute([':s' => $a['subcontractor_id'], ':j' => $a['job_id']]);
            break;
        default:
            sub_job_stage($pdo, $a, $a['job_stage'] === 'SUBMITTED' ? 'ASSIGNED' : $a['job_stage'], "Subcontractor $tag: " . SA_LABELS[$to]);
    }
    return sub_assignment($pdo, (int)$a['id']);
}

/**
 * The job's existing checklist: installation items (INSTALLATION) or the
 * maintenance inspection items (MAINTENANCE), created on first use with the
 * same templates the technician portal uses. Repairs / inspections have none.
 */
function sub_checklist(PDO $pdo, array $a, bool $create = true): array
{
    if ($a['job_type'] === 'INSTALLATION') {
        $cl = $create ? tech_ensure_installation_checklist((int)$a['job_id']) : tech_checklist_for_job((int)$a['job_id']);
        if (!$cl) {
            return ['type' => null, 'items' => [], 'pending' => 0];
        }
        $s = $pdo->prepare('SELECT id, category, description, status, remarks FROM installation_items WHERE checklist_id = :c ORDER BY id');
        $s->execute([':c' => $cl['id']]);
        $items = $s->fetchAll();
        return ['type' => 'installation', 'id' => (int)$cl['id'], 'items' => $items,
                'pending' => count(array_filter($items, fn($i) => $i['status'] === 'PENDING'))];
    }
    if ($a['job_type'] === 'MAINTENANCE') {
        $rec = tech_maintenance_record_for_job(['id' => $a['job_id'], 'client_id' => $a['client_id'], 'technician_id' => null], $create);
        if (!$rec) {
            return ['type' => null, 'items' => [], 'pending' => 0];
        }
        $s = $pdo->prepare('SELECT id, item_key, description, status, remarks FROM maintenance_items WHERE maintenance_id = :m ORDER BY id');
        $s->execute([':m' => $rec['id']]);
        $items = array_map(function ($i) {
            $i['category'] = tech_maintenance_category($i['item_key'], $i['description']);
            return $i;
        }, $s->fetchAll());
        return ['type' => 'maintenance', 'id' => (int)$rec['id'], 'items' => $items,
                'pending' => count(array_filter($items, fn($i) => $i['status'] === 'PENDING'))];
    }
    return ['type' => null, 'items' => [], 'pending' => 0];
}

/** Why the work cannot be submitted for inspection yet, or null. */
function sub_submission_blocker(PDO $pdo, array $a): ?string
{
    $cl = sub_checklist($pdo, $a, true);
    if ($cl['pending'] > 0) {
        return $cl['pending'] . ' checklist item(s) are still pending. Mark each one Done or N/A first.';
    }
    $s = $pdo->prepare("SELECT COUNT(*) FROM subcontractor_files WHERE assignment_id = :a AND category = 'COMPLETION_PHOTO' AND submission_round = :r");
    $s->execute([':a' => $a['id'], ':r' => $a['revision_count']]);
    if ((int)$s->fetchColumn() === 0) {
        return (int)$a['revision_count'] > 0
            ? 'Upload at least one new completion photo showing the corrected work.'
            : 'Upload at least one completion photo before submitting for inspection.';
    }
    return null;
}

// ---------------------------------------------------------------------------
// Files
// ---------------------------------------------------------------------------

/** A photo (JPG / PNG / WebP, re-encoded, EXIF removed) or a PDF. Returns [name, mime, size]. */
function sub_store_file(array $file): array
{
    $err = $file['error'] ?? UPLOAD_ERR_NO_FILE;
    if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE) {
        json_error('That file is too large (max 10 MB).', 422);
    }
    if ($err !== UPLOAD_ERR_OK || empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        json_error('No file was received. Please try again.', 422);
    }
    $size = (int)filesize($file['tmp_name']);
    if ($size <= 0 || $size > SUB_FILE_MAX_BYTES) {
        json_error('That file is too large (max 10 MB).', 422);
    }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if ($mime === 'application/pdf') {
        if ((string)file_get_contents($file['tmp_name'], false, null, 0, 5) !== '%PDF-') {
            json_error('That PDF could not be read.', 422);
        }
        $name = bin2hex(random_bytes(16)) . '.pdf';
        if (!move_uploaded_file($file['tmp_name'], storage_dir('subcontractor_files') . '/' . $name)) {
            json_error('The file could not be saved. Please try again.', 500);
        }
        return [$name, 'application/pdf', $size];
    }
    if (in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) {
        [$name, $m, $sz] = store_uploaded_image($file, 'subcontractor_files');
        return [$name, $m, $sz];
    }
    json_error('Upload a photo (JPG, PNG, WebP) or a PDF document.', 422);
}

/** Save one upload against an assignment, tagged with the current work round. */
function sub_save_upload(PDO $pdo, array $a, string $category, array $file): array
{
    $c = $pdo->prepare('SELECT COUNT(*) FROM subcontractor_files WHERE assignment_id = :a');
    $c->execute([':a' => $a['id']]);
    if ((int)$c->fetchColumn() >= 40) {
        json_error('This assignment already has the maximum of 40 files.', 422);
    }
    $original = mb_substr(preg_replace('/[^\w .()-]+/u', '_', basename((string)($file['name'] ?? 'file'))), 0, 150) ?: 'file';
    [$name, $mime, $size] = sub_store_file($file);
    try {
        $pdo->prepare(
            'INSERT INTO subcontractor_files (assignment_id, category, submission_round, file_name, original_name, mime, size_bytes, uploaded_by, created_at)
             VALUES (:a, :c, :r, :f, :o, :m, :s, :u, :t)'
        )->execute([':a' => $a['id'], ':c' => $category, ':r' => $a['revision_count'], ':f' => $name, ':o' => $original,
                    ':m' => $mime, ':s' => $size, ':u' => current_user_id(), ':t' => date('Y-m-d H:i:s')]);
    } catch (PDOException $e) {
        @unlink(storage_dir('subcontractor_files') . '/' . $name);
        json_error('The file could not be saved. Please try again.', 500);
    }
    sub_event($pdo, (int)$a['id'], (int)$a['subcontractor_id'], 'FILE_UPLOADED', null, null, str_replace('_', ' ', strtolower($category)) . ": $original");
    return ['id' => (int)$pdo->lastInsertId(), 'original_name' => $original, 'mime' => $mime];
}

function sub_file_name_ok(string $name): bool
{
    return (bool)preg_match('/^[a-f0-9]{32}\.(jpg|png|webp|pdf)$/', $name);
}

function sub_files(PDO $pdo, int $assignmentId): array
{
    $s = $pdo->prepare(
        'SELECT f.*, u.full_name AS uploaded_by_name FROM subcontractor_files f LEFT JOIN users u ON u.id = f.uploaded_by
         WHERE f.assignment_id = :a ORDER BY f.id'
    );
    $s->execute([':a' => $assignmentId]);
    return array_map(fn($f) => [
        'id' => (int)$f['id'], 'category' => $f['category'], 'round' => (int)$f['submission_round'],
        'original_name' => $f['original_name'], 'mime' => $f['mime'], 'size' => (int)$f['size_bytes'],
        'uploaded_by_name' => $f['uploaded_by_name'], 'created_at' => $f['created_at'],
        'url' => APP_BASE_URL . '/api/subcontractors/file.php?id=' . (int)$f['id'],
    ], $s->fetchAll());
}

function sub_events(PDO $pdo, int $assignmentId): array
{
    $s = $pdo->prepare(
        'SELECT e.action, e.from_status, e.to_status, e.note, e.actor_role, e.created_at, u.full_name AS actor_name
         FROM subcontractor_events e LEFT JOIN users u ON u.id = e.actor_user_id
         WHERE e.assignment_id = :a ORDER BY e.id'
    );
    $s->execute([':a' => $assignmentId]);
    return $s->fetchAll();
}

// ---------------------------------------------------------------------------
// Notifications (in-app + phone push through notify())
// ---------------------------------------------------------------------------

function sub_notify_management(string $message, ?int $assignmentId = null): void
{
    foreach (mr_user_ids_for_roles(['manager', 'staff']) as $uid) {
        notify((int)$uid, 'SUBCONTRACTOR', $message, 'subcontractor_assignments', $assignmentId);
    }
}

function sub_notify_subcontractor(int $subId, string $message, ?int $assignmentId = null): void
{
    $s = db()->prepare("SELECT s.user_id FROM subcontractors s JOIN users u ON u.id = s.user_id AND u.status = 'ACTIVE' WHERE s.id = :id");
    $s->execute([':id' => $subId]);
    if ($uid = $s->fetchColumn()) {
        notify((int)$uid, 'NEW_ASSIGNMENT', $message, 'subcontractor_assignments', $assignmentId);
    }
}

// ---------------------------------------------------------------------------
// Profile fields
// ---------------------------------------------------------------------------

/** Validated profile fields from a create / edit form. $partial: only keys present. */
function sub_profile_fields(array $in, bool $partial): array
{
    $text = [
        'name' => 150, 'contact_person' => 150, 'specialization' => 150, 'specialties' => 255, 'phone' => 30,
        'email' => 150, 'area' => 100, 'address' => 255, 'rate_notes' => 255, 'qualifications' => 2000,
        'insurance_ref' => 100, 'permit_ref' => 100, 'contract_doc_ref' => 150, 'notes' => 2000,
    ];
    $out = [];
    foreach ($text as $k => $max) {
        if (!array_key_exists($k, $in)) {
            continue;
        }
        $v = is_scalar($in[$k]) ? trim((string)$in[$k]) : '';
        if (mb_strlen($v) > $max) {
            json_error(ucfirst(str_replace('_', ' ', $k)) . " is too long ($max characters max).", 422);
        }
        $out[$k] = $v === '' ? null : $v;
    }
    if ((!$partial || array_key_exists('name', $out)) && empty($out['name'])) {
        json_error('Company / contractor name is required.', 422);
    }
    if (!empty($out['email']) && !filter_var($out['email'], FILTER_VALIDATE_EMAIL)) {
        json_error('Please enter a valid email address.', 422);
    }
    if (array_key_exists('rate_type', $in)) {
        $rt = strtoupper(trim((string)$in['rate_type']));
        if ($rt !== '' && !in_array($rt, ['PER_JOB', 'PER_DAY', 'PER_KW', 'OTHER'], true)) {
            json_error('Rate type must be per job, per day, per kW or other.', 422);
        }
        $out['rate_type'] = $rt ?: null;
    }
    if (array_key_exists('default_rate', $in)) {
        $r = $in['default_rate'];
        if ($r === '' || $r === null) {
            $out['default_rate'] = null;
        } elseif (!is_numeric($r) || (float)$r < 0) {
            json_error('Agreed rate must be zero or more.', 422);
        } else {
            $out['default_rate'] = round((float)$r, 2);
        }
    }
    if (array_key_exists('max_active_jobs', $in)) {
        $m = (int)$in['max_active_jobs'];
        if ($m < 1 || $m > 50) {
            json_error('Jobs at a time must be between 1 and 50.', 422);
        }
        $out['max_active_jobs'] = $m;
    }
    foreach (['contract_start', 'contract_end', 'insurance_expiry'] as $d) {
        if (!array_key_exists($d, $in)) {
            continue;
        }
        $v = trim((string)$in[$d]);
        if ($v === '') {
            $out[$d] = null;
            continue;
        }
        $dt = DateTime::createFromFormat('!Y-m-d', $v);
        if (!$dt || $dt->format('Y-m-d') !== $v) {
            json_error(ucfirst(str_replace('_', ' ', $d)) . ' must be a valid date.', 422);
        }
        $out[$d] = $v;
    }
    $start = $out['contract_start'] ?? ($in['__current_start'] ?? null);
    $end = $out['contract_end'] ?? ($in['__current_end'] ?? null);
    if ($start && $end && $end < $start) {
        json_error('Contract end date cannot be before the start date.', 422);
    }
    return $out;
}

// ---------------------------------------------------------------------------
// Automatic assignment
// ---------------------------------------------------------------------------

function sub_auto_settings(): array
{
    $mode = (string)setting('subcon_auto_mode', 'auto');
    return [
        'mode'        => in_array($mode, ['auto', 'suggest', 'off'], true) ? $mode : 'auto',
        'tech_max'    => max(1, setting_int('tech_max_open_jobs', 4)),
        'threshold'   => min(100, max(10, setting_int('subcon_capacity_threshold', 85))),
        'offer_hours' => min(168, max(1, setting_int('subcon_offer_hours', 24))),
        'since'       => setting('subcon_auto_since') ?: null,
    ];
}

/**
 * The technicians' load right now. Each active technician who is not off
 * duty / on leave has tech_max slots; every open job they lead uses one.
 *   ['technicians' => [...], 'slots' => n, 'used' => n, 'pct' => n, 'free_technicians' => n, 'near_full' => bool]
 */
function sub_team_capacity(PDO $pdo): array
{
    $cfg = sub_auto_settings();
    $rows = $pdo->query(
        "SELECT t.id, t.technician_code, u.full_name, COALESCE(ta.status, 'AVAILABLE') AS availability,
                (SELECT COUNT(*) FROM jobs j WHERE j.technician_id = t.id AND j.stage NOT IN ('COMPLETED','CANCELLED')) AS open_jobs
         FROM technicians t JOIN users u ON u.id = t.user_id
         LEFT JOIN technician_availability ta ON ta.technician_id = t.id
         WHERE u.status = 'ACTIVE'" . (sub_field_ready() ? ' AND t.subcontractor_id IS NULL' : '') . " ORDER BY open_jobs DESC, u.full_name"
    )->fetchAll();
    $slots = 0;
    $used = 0;
    $free = 0;
    foreach ($rows as &$r) {
        $r['open_jobs'] = (int)$r['open_jobs'];
        $r['on_duty'] = !in_array($r['availability'], ['OFF_DUTY', 'ON_LEAVE'], true);
        $r['slots'] = $r['on_duty'] ? $cfg['tech_max'] : 0;
        $r['free'] = max(0, $r['slots'] - $r['open_jobs']);
        $slots += $r['slots'];
        $used += min($r['open_jobs'], $r['slots']);
        $free += $r['free'] > 0 ? 1 : 0;
    }
    unset($r);
    $pct = $slots ? (int)round($used * 100 / $slots) : 100;
    return ['technicians' => $rows, 'slots' => $slots, 'used' => $used, 'pct' => $pct, 'free_technicians' => $free,
            'threshold' => $cfg['threshold'], 'tech_max' => $cfg['tech_max'],
            'near_full' => $free === 0 || $pct >= $cfg['threshold']];
}

/** Words that tie a specialty to a job type. */
function sub_type_keywords(string $jobType): array
{
    return [
        'INSTALLATION' => ['install', 'pv', 'solar', 'mount', 'roof'],
        'MAINTENANCE'  => ['mainten', 'clean', 'service', 'wash'],
        'REPAIR'       => ['repair', 'electric', 'inverter', 'troubleshoot'],
        'INSPECTION'   => ['inspect', 'electric', 'permit', 'audit'],
    ][$jobType] ?? [];
}

/**
 * Approved subcontractors who could take this job, best first, each with a
 * score and the reasons. Only companies with an active portal login (so the
 * offer reaches them), a current contract and insurance, room under their own
 * job limit, and who have not already declined / been taken off this job.
 */
function sub_rank_candidates(PDO $pdo, array $job): array
{
    $s = $pdo->prepare(
        "SELECT s.*,
            (SELECT COUNT(*) FROM subcontractor_assignments a WHERE a.subcontractor_id = s.id AND a.status IN ('" . implode("','", SA_OPEN) . "')) AS open_jobs,
            (SELECT COUNT(*) FROM subcontractor_assignments a WHERE a.subcontractor_id = s.id AND a.status = 'COMPLETED') AS completed_jobs,
            (SELECT COALESCE(SUM(a.revision_count),0) FROM subcontractor_assignments a WHERE a.subcontractor_id = s.id) AS revisions
         FROM subcontractors s JOIN users u ON u.id = s.user_id AND u.status = 'ACTIVE'
         WHERE s.status = 'APPROVED'
           AND (s.contract_end IS NULL OR s.contract_end >= CURDATE())
           AND (s.insurance_expiry IS NULL OR s.insurance_expiry >= CURDATE())"
           // Off duty / on leave in their portal's Availability tab: no offers.
           . (sub_field_ready() ? " AND NOT EXISTS (SELECT 1 FROM technicians ft JOIN technician_availability fa ON fa.technician_id = ft.id
                                  WHERE ft.subcontractor_id = s.id AND fa.status IN ('OFF_DUTY','ON_LEAVE'))" : '') . "
           AND NOT EXISTS (SELECT 1 FROM subcontractor_assignments x WHERE x.job_id = :j AND x.subcontractor_id = s.id AND x.status IN ('DECLINED','CANCELLED'))"
    );
    $s->execute([':j' => $job['id']]);
    $site = strtolower(($job['site_address'] ?? '') . ' ' . ($job['client_city'] ?? '') . ' ' . ($job['client_province'] ?? ''));
    $words = sub_type_keywords((string)$job['job_type']);
    $out = [];
    foreach ($s->fetchAll() as $c) {
        if ((int)$c['open_jobs'] >= (int)$c['max_active_jobs']) {
            continue;
        }
        $score = 0;
        $why = [];
        $areaHit = null;
        foreach (preg_split('/[\/,&;]+|\band\b/i', strtolower((string)$c['area'] . ' / ' . (string)$c['address'])) as $tok) {
            $tok = trim(preg_replace('/\b(city|province|region|western|of)\b/', '', $tok));
            if (mb_strlen($tok) >= 4 && str_contains($site, $tok)) {
                $areaHit = $tok;
                break;
            }
        }
        if ($areaHit) {
            $score += 30;
            $why[] = 'serves ' . ucwords($areaHit);
        }
        $spec = strtolower($c['specialization'] . ' ' . $c['specialties']);
        foreach ($words as $w) {
            if (str_contains($spec, $w)) {
                $score += 20;
                $why[] = 'does ' . strtolower((string)$job['job_type']) . ' work';
                break;
            }
        }
        $score += 10 * ((int)$c['max_active_jobs'] - (int)$c['open_jobs']); // spare room
        $score += min(10, (int)$c['completed_jobs']);                       // track record
        $score -= 3 * (int)$c['revisions'];
        $why[] = (int)$c['open_jobs'] . ' of ' . (int)$c['max_active_jobs'] . ' jobs in hand';
        $out[] = ['id' => (int)$c['id'], 'subcon_code' => $c['subcon_code'], 'name' => $c['name'], 'score' => $score,
                  'open_jobs' => (int)$c['open_jobs'], 'max_active_jobs' => (int)$c['max_active_jobs'], 'reasons' => $why];
    }
    usort($out, fn($x, $y) => [$y['score'], $x['open_jobs'], $x['id']] <=> [$x['score'], $y['open_jobs'], $y['id']]);
    return $out;
}

/**
 * Create the offer (inside the caller's transaction, job row locked).
 * Returns [assignment id, assignment code].
 */
function sub_create_offer(PDO $pdo, array $job, array $sub, array $o): array
{
    $hours = sub_auto_settings()['offer_hours'];
    $ins = $pdo->prepare(
        "INSERT INTO subcontractor_assignments (assignment_code, job_id, subcontractor_id, status, scope, instructions, materials_note,
                                               contract_amount, assigned_at, assigned_by, auto_assigned, assignment_reason, offer_expires_at, expected_completion)
         VALUES (:code, :j, :s, 'AWAITING_ACCEPTANCE', :scope, :ins, :mat, :amt, NOW(), :u, :auto, :why, NOW() + INTERVAL $hours HOUR, :exp)"
    );
    try {
        $code = with_unique_code('subcontractor_assignments', 'assignment_code', 'SA-' . date('Y') . '-', function (string $code) use ($ins, $job, $sub, $o) {
            $ins->execute([':code' => $code, ':j' => $job['id'], ':s' => $sub['id'], ':scope' => $o['scope'], ':ins' => $o['instructions'] ?? null,
                           ':mat' => $o['materials_note'] ?? null, ':amt' => $o['contract_amount'] ?? 0, ':u' => $o['auto'] ? null : current_user_id(),
                           ':auto' => $o['auto'] ? 1 : 0, ':why' => mb_substr((string)($o['reason'] ?? ''), 0, 255) ?: null,
                           ':exp' => $o['expected_completion'] ?? null]);
            return $code;
        }, pad: 4);
    } catch (PDOException $e) {
        if (($e->errorInfo[1] ?? null) === 1062 && str_contains($e->getMessage(), 'uq_sa_active_job')) {
            // Thrown, not answered: this also runs inside background sweeps.
            throw new DomainException("{$job['job_code']} already has an open subcontractor assignment.");
        }
        throw $e;
    }
    $id = (int)$pdo->lastInsertId();
    sub_event($pdo, $id, (int)$sub['id'], $o['auto'] ? 'AUTO_ASSIGNED' : 'ASSIGNED', null, 'AWAITING_ACCEPTANCE',
        ($o['auto'] ? 'Automatic: ' : '') . ($o['reason'] ?? "Offered {$job['job_code']}"), (bool)$o['auto']);
    $pdo->prepare('UPDATE jobs SET updated_at = CURRENT_TIMESTAMP WHERE id = :id')->execute([':id' => $job['id']]);
    return [$id, $code];
}

/** The scope text the system writes for an automatic offer. */
function sub_auto_scope(array $job): string
{
    $type = strtolower((string)$job['job_type']);
    return ucfirst($type) . " job {$job['job_code']} for {$job['client_name']}" . ($job['site_address'] ? " at {$job['site_address']}" : '') . '.'
        . ($job['description'] ? "\n" . $job['description'] : '');
}

/**
 * Try to give one job to the best subcontractor. Own transaction; call with
 * no transaction open. Returns ['status' => assigned | suggested | skipped, ...].
 *   $force: run even when the technicians still have room (Management button).
 */
function sub_auto_assign_job(PDO $pdo, int $jobId, string $trigger, bool $force = false): array
{
    $cfg = sub_auto_settings();
    if ($cfg['mode'] === 'off' && !$force) {
        return ['status' => 'skipped', 'reason' => 'Automatic assignment is off.'];
    }
    $pdo->beginTransaction();
    try {
        $s = $pdo->prepare(
            "SELECT j.*, c.city AS client_city, c.province AS client_province, cu.full_name AS client_name
             FROM jobs j JOIN clients c ON c.id = j.client_id JOIN users cu ON cu.id = c.user_id WHERE j.id = :id FOR UPDATE"
        );
        $s->execute([':id' => $jobId]);
        $job = $s->fetch();
        if (!$job || $job['technician_id'] || in_array($job['stage'], ['COMPLETED', 'CANCELLED'], true)) {
            $pdo->rollBack();
            return ['status' => 'skipped', 'reason' => 'Job is assigned or closed.'];
        }
        if (sub_active_assignment_for_job($pdo, $jobId)) {
            $pdo->rollBack();
            return ['status' => 'skipped', 'reason' => 'Already with a subcontractor.'];
        }
        $cap = sub_team_capacity($pdo);
        if (!$cap['near_full'] && !$force) {
            $pdo->rollBack();
            return ['status' => 'skipped', 'reason' => "Technicians have room ({$cap['pct']}% of slots used)."];
        }
        $cands = sub_rank_candidates($pdo, $job);
        if (!$cands) {
            $pdo->rollBack();
            return ['status' => 'none', 'job_code' => $job['job_code'], 'reason' => 'No approved subcontractor with a login and free capacity.'];
        }
        $best = $cands[0];
        $why = "Technicians at {$cap['pct']}% capacity ({$cap['used']}/{$cap['slots']} slots, {$cap['free_technicians']} free). "
             . "Best match {$best['subcon_code']}: " . implode(', ', $best['reasons']) . '.';
        if ($cfg['mode'] === 'suggest' && !$force) {
            $pdo->rollBack();
            return ['status' => 'suggested', 'job_code' => $job['job_code'], 'job_id' => $jobId, 'subcontractor' => $best, 'reason' => $why];
        }
        [$aid, $code] = sub_create_offer($pdo, $job, $best, ['auto' => true, 'reason' => $why, 'scope' => sub_auto_scope($job)]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log("sub_auto_assign_job($jobId, $trigger) failed: " . $e->getMessage());
        return ['status' => 'error', 'reason' => 'Could not assign automatically.'];
    }
    audit_log('AUTO_ASSIGN', 'subcontractor_assignments', $code);
    $place = $job['site_address'] ? " at {$job['site_address']}" : '';
    sub_notify_subcontractor($best['id'], "New job for you: {$job['job_code']} (" . strtolower($job['job_type']) . ")$place. "
        . "Open SunTrack to accept within {$cfg['offer_hours']} hours.", $aid);
    sub_notify_management("{$job['job_code']} was offered automatically to {$best['name']} ({$code}) — technicians are at {$cap['pct']}% capacity.", $aid);
    return ['status' => 'assigned', 'job_code' => $job['job_code'], 'assignment_id' => $aid, 'assignment_code' => $code,
            'subcontractor' => $best, 'reason' => $why];
}

/**
 * Expire unanswered offers (they count as declined) and pass each job on.
 * Returns the jobs that need a new offer.
 */
function sub_expire_offers(PDO $pdo): array
{
    $jobs = [];
    $ids = $pdo->query("SELECT id FROM subcontractor_assignments WHERE status = 'AWAITING_ACCEPTANCE' AND offer_expires_at IS NOT NULL AND offer_expires_at < NOW()")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($ids as $id) {
        $pdo->beginTransaction();
        try {
            $a = sub_lock_assignment($pdo, (int)$id);
            if ($a['status'] !== 'AWAITING_ACCEPTANCE') {
                $pdo->rollBack();
                continue;
            }
            sub_move($pdo, $a, 'DECLINED', 'system', 'No answer before the offer expired', ['decline_reason' => 'Offer expired — no answer in time']);
            $pdo->commit();
            sub_notify_subcontractor((int)$a['subcontractor_id'], "The offer for {$a['job_code']} expired and was passed to another subcontractor.", (int)$a['id']);
            $jobs[] = (int)$a['job_id'];
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('sub_expire_offers: ' . $e->getMessage());
        }
    }
    return $jobs;
}

/**
 * The automatic-assignment sweep. Runs after jobs are created, when an offer
 * is declined, and whenever Management opens the Sub-contractors tab or the
 * dashboard (so expired offers move on without a cron job).
 *   1. expired offers → declined → offered to the next subcontractor
 *   2. new unassigned jobs (created since auto-assign was switched on, or all
 *      when $includeOlder) → offered while the technicians are near full
 * Returns what happened, for the "Run now" button.
 */
function sub_auto_sweep(PDO $pdo, bool $includeOlder = false, ?array $onlyJobs = null): array
{
    if (!sub_ready() || $pdo->inTransaction()) {
        return [];
    }
    $cfg = sub_auto_settings();
    $retry = sub_expire_offers($pdo);
    if ($cfg['mode'] === 'off') {
        return [];
    }
    if (!$cfg['since']) {
        setting_set('subcon_auto_since', date('Y-m-d H:i:s'));
        $cfg['since'] = date('Y-m-d H:i:s');
    }
    $where = "j.technician_id IS NULL AND j.stage IN ('SUBMITTED','ASSIGNED')
              AND NOT EXISTS (SELECT 1 FROM subcontractor_assignments a WHERE a.active_job_id = j.id)";
    $params = [];
    if ($onlyJobs !== null) {
        $onlyJobs = array_values(array_unique(array_map('intval', array_merge($onlyJobs, $retry))));
        if (!$onlyJobs) {
            return [];
        }
        $where .= ' AND j.id IN (' . implode(',', $onlyJobs) . ')';
    } elseif (!$includeOlder) {
        $where .= ' AND (j.created_at >= :since' . ($retry ? ' OR j.id IN (' . implode(',', array_map('intval', $retry)) . ')' : '') . ')';
        $params[':since'] = $cfg['since'];
    }
    $s = $pdo->prepare("SELECT j.id FROM jobs j WHERE $where ORDER BY FIELD(j.priority,'URGENT','HIGH','NORMAL','LOW'), j.id LIMIT 25");
    $s->execute($params);
    $results = [];
    $none = [];
    foreach ($s->fetchAll(PDO::FETCH_COLUMN) as $jobId) {
        $r = sub_auto_assign_job($pdo, (int)$jobId, 'sweep');
        if ($r['status'] === 'none') {
            $none[] = $r['job_code'];
        }
        if ($r['status'] !== 'skipped') {
            $results[] = $r;
        }
    }
    // Tell Management once when a job could not be placed with anyone.
    foreach ($none as $code) {
        $k = 'subcon_none_' . md5($code);
        if (setting($k) !== date('Y-m-d')) {
            setting_set($k, date('Y-m-d'));
            sub_notify_management("$code could not be placed: technicians are near full and no subcontractor is available. Please assign it manually.");
        }
    }
    return $results;
}

/** Counts for the dashboard's Needs Attention. */
function sub_dashboard_counts(PDO $pdo): array
{
    $z = ['active_subcontractors' => 0, 'awaiting_acceptance' => 0, 'overdue' => 0, 'awaiting_inspection' => 0];
    if (!sub_ready()) {
        return $z;
    }
    $r = $pdo->query(
        "SELECT
            (SELECT COUNT(*) FROM subcontractors WHERE status = 'APPROVED') AS active_subcontractors,
            (SELECT COUNT(*) FROM subcontractor_assignments WHERE status = 'AWAITING_ACCEPTANCE') AS awaiting_acceptance,
            (SELECT COUNT(*) FROM subcontractor_assignments WHERE status IN ('ACCEPTED','SCHEDULED','IN_PROGRESS','REVISION_REQUIRED')
                AND expected_completion IS NOT NULL AND expected_completion < CURDATE()) AS overdue,
            (SELECT COUNT(*) FROM subcontractor_assignments WHERE status = 'AWAITING_INSPECTION') AS awaiting_inspection"
    )->fetch();
    return array_map('intval', $r);
}
