<?php
/**
 * SunTrack ERP — Technician / Field Operations shared library (Phase 1).
 *
 * Every technician API endpoint funnels its ownership checks, stage rules and
 * progress recalculation through this file so the logic exists exactly once.
 * Nothing here duplicates authentication — middleware/technician.php still
 * does that; these helpers assume a technician session is already established.
 */

// ---------------------------------------------------------------------------
// Stage machine
// ---------------------------------------------------------------------------

/**
 * The only transitions a technician is allowed to perform.
 * Anything not listed here is rejected server-side, no matter what the
 * browser sends.
 */
function tech_stage_flow(): array
{
    return [
        'SUBMITTED'   => ['EN_ROUTE'],
        'ASSIGNED'    => ['EN_ROUTE'],
        'EN_ROUTE'    => ['ARRIVED'],
        'ARRIVED'     => ['IN_PROGRESS'],
        'IN_PROGRESS' => ['PAUSED', 'COMPLETED'],
        'PAUSED'      => ['IN_PROGRESS', 'COMPLETED'],
        'COMPLETED'   => [],
        'CANCELLED'   => [],
    ];
}

/** Stages a technician may move to from $stage. */
function tech_allowed_next(string $stage): array
{
    return tech_stage_flow()[$stage] ?? [];
}

/** True when the job is closed and must never be modified again. */
function tech_stage_is_closed(string $stage): bool
{
    return in_array($stage, ['COMPLETED', 'CANCELLED'], true);
}

/** Stages that count as "the technician is out in the field on this job". */
function tech_field_stages(): array
{
    return ['EN_ROUTE', 'ARRIVED', 'IN_PROGRESS', 'PAUSED'];
}

/** Human label for a stage (used for notifications and history text). */
function tech_stage_label(string $stage): string
{
    return ucwords(strtolower(str_replace('_', ' ', $stage)));
}

// ---------------------------------------------------------------------------
// Ownership
// ---------------------------------------------------------------------------

/**
 * Fetch a job and prove the current technician session owns it.
 * Errors out with JSON (404 / 403) instead of returning, so callers can never
 * accidentally continue with an unowned job.
 *
 * @param bool $lock  Wrap in SELECT ... FOR UPDATE (caller must be in a transaction).
 */
function tech_job_or_fail(int $jobId, bool $lock = false): array
{
    if ($jobId <= 0) {
        json_error('Invalid job id.', 422);
    }

    $techId = current_profile_id();
    if (!$techId) {
        json_error('Technician profile not found.', 404);
    }

    $sql = 'SELECT j.*, c.client_code, c.address AS client_address, c.city, c.province,
                   cu.full_name AS client_name, cu.phone AS client_phone, cu.email AS client_email,
                   p.project_code, p.site_name, p.progress AS project_progress
            FROM jobs j
            JOIN clients c   ON c.id = j.client_id
            JOIN users cu    ON cu.id = c.user_id
            LEFT JOIN projects p ON p.id = j.project_id
            WHERE j.id = :id';
    if ($lock) {
        $sql .= ' FOR UPDATE';
    }

    $stmt = db()->prepare($sql);
    $stmt->execute([':id' => $jobId]);
    $job = $stmt->fetch();

    if (!$job) {
        json_error('Job not found.', 404);
    }
    // Same message for "belongs to someone else" as for "does not exist" would be
    // friendlier to attackers-guessing-ids; we still 403 here because the job id
    // space is not sensitive and a clear message helps real technicians.
    // The lead (jobs.technician_id) or, on an installation, a helper on its crew.
    $job['is_lead'] = (int)$job['technician_id'] === (int)$techId;
    if (!$job['is_lead'] && !(function_exists('crew_is_helper') && crew_is_helper($job, (int)$techId))) {
        json_error('This job is not assigned to you.', 403);
    }

    return $job;
}

/**
 * For actions that drive the job itself (moving its stage, undo, submitting a
 * stage for review, filing the work report): only the lead technician.
 */
function tech_require_lead(array $job): void
{
    if (empty($job['is_lead'])) {
        json_error('Only the lead technician on this job can do that. You can still time in, tick the checklist and add photos.', 403);
    }
}

// ---------------------------------------------------------------------------
// Attendance / geofence
// ---------------------------------------------------------------------------

/** The technician's currently open (timed-in, not timed-out) attendance row for a job, or null. */
function tech_open_attendance(int $jobId, int $techId): ?array
{
    $stmt = db()->prepare(
        'SELECT * FROM attendance
         WHERE job_id = :j AND technician_id = :t AND time_in IS NOT NULL AND time_out IS NULL
         ORDER BY id DESC LIMIT 1'
    );
    $stmt->execute([':j' => $jobId, ':t' => $techId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/** The most recent attendance row for a job (open or closed), or null. */
function tech_latest_attendance(int $jobId, int $techId): ?array
{
    $stmt = db()->prepare(
        'SELECT * FROM attendance WHERE job_id = :j AND technician_id = :t ORDER BY id DESC LIMIT 1'
    );
    $stmt->execute([':j' => $jobId, ':t' => $techId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/** Effective geofence radius for a job (job value, else the global default). */
function tech_geofence_radius(array $job): int
{
    $r = (int)($job['geofence_radius_m'] ?? 0);
    // Falls back to the administrator-configurable default in `settings`
    // rather than the compile-time constant, so changing the site radius no
    // longer requires editing PHP. The constant remains the last resort.
    return $r > 0 ? $r : geofence_default_radius();
}

/**
 * Distance in metres between a coordinate and the job site, or null when the
 * job has no recorded coordinates.
 */
function tech_distance_to_site(array $job, float $lat, float $lng): ?float
{
    if ($job['site_lat'] === null || $job['site_lng'] === null) {
        return null;
    }
    return distance_meters((float)$job['site_lat'], (float)$job['site_lng'], $lat, $lng);
}

/**
 * Write one row to geofence_records. Used by Time In / Time Out and by the
 * periodic location ping — deliberately the same table, no duplicate
 * location-tracking table.
 */
function tech_record_geofence(int $jobId, int $techId, float $lat, float $lng, float $distance, string $status,
                              ?float $accuracy = null, ?string $flag = null): void
{
    $params = [
        ':j' => $jobId, ':t' => $techId,
        ':lat' => round($lat, 7), ':lng' => round($lng, 7),
        ':d' => round($distance, 2), ':s' => $status,
    ];
    try {
        db()->prepare(
            'INSERT INTO geofence_records (job_id, technician_id, lat, lng, distance_m, status, accuracy_m, flag)
             VALUES (:j, :t, :lat, :lng, :d, :s, :acc, :flag)'
        )->execute($params + [
            ':acc' => $accuracy !== null ? round(min(max($accuracy, 0), 9999999), 1) : null,
            ':flag' => $flag,
        ]);
    } catch (PDOException $e) {
        // Database without phase7 (no accuracy_m / flag columns yet).
        db()->prepare(
            'INSERT INTO geofence_records (job_id, technician_id, lat, lng, distance_m, status)
             VALUES (:j, :t, :lat, :lng, :d, :s)'
        )->execute($params);
    }
}

// ---------------------------------------------------------------------------
// Fake-GPS / impossible-jump detection
// ---------------------------------------------------------------------------

/** Faster than this between two readings is not a person driving (km/h). */
const GPS_JUMP_MAX_KMH = 250;

/** Jumps shorter than this are GPS noise or Wi-Fi location, never flagged (m). */
const GPS_JUMP_MIN_METERS = 2000;

/** Only compare against a previous reading this recent (hours). */
const GPS_JUMP_LOOKBACK_HOURS = 12;

/**
 * Compares a new reading with this technician's previous stored reading.
 * Returns details when the technician would have had to travel faster than
 * GPS_JUMP_MAX_KMH to get here — the typical sign of a fake-GPS app being
 * switched on or off. Returns null when the move is believable.
 *
 * Both readings' own accuracy is subtracted first, so a rough reading on
 * Wi-Fi location does not count as a jump.
 */
function tech_gps_jump(int $techId, float $lat, float $lng, ?float $accuracy): ?array
{
    try {
        $stmt = db()->prepare(
            'SELECT lat, lng, accuracy_m, TIMESTAMPDIFF(SECOND, recorded_at, NOW()) AS age_s
             FROM geofence_records
             WHERE technician_id = :t AND recorded_at >= NOW() - INTERVAL ' . GPS_JUMP_LOOKBACK_HOURS . ' HOUR
             ORDER BY id DESC LIMIT 1'
        );
        $stmt->execute([':t' => $techId]);
        $prev = $stmt->fetch();
    } catch (PDOException $e) {
        return null; // phase7 not applied: no detection, never block work
    }
    if (!$prev) {
        return null;
    }
    $meters = distance_meters((float)$prev['lat'], (float)$prev['lng'], $lat, $lng);
    $slack = min(1000.0, (float)($prev['accuracy_m'] ?? 0)) + min(1000.0, max(0.0, (float)($accuracy ?? 0)));
    $effective = $meters - $slack;
    if ($effective < GPS_JUMP_MIN_METERS) {
        return null;
    }
    $seconds = max(1, (int)$prev['age_s']);
    $kmh = ($effective / $seconds) * 3.6;
    if ($kmh <= GPS_JUMP_MAX_KMH) {
        return null;
    }
    return ['meters' => (int)round($meters), 'seconds' => $seconds, 'kmh' => (int)round($kmh)];
}

/**
 * Tells Management about an impossible jump. At most one alert per job per
 * hour, so a fake-GPS app left running does not flood the bell.
 */
function tech_report_gps_jump(array $job, int $techId, ?array $jump): void
{
    if ($jump === null) {
        return;
    }
    try {
        $recent = db()->prepare(
            "SELECT COUNT(*) FROM geofence_records
             WHERE job_id = :j AND technician_id = :t AND flag = 'IMPOSSIBLE_JUMP'
               AND recorded_at >= NOW() - INTERVAL 1 HOUR"
        );
        $recent->execute([':j' => $job['id'], ':t' => $techId]);
        if ((int)$recent->fetchColumn() > 1) {
            return; // the reading just stored is one; an earlier one already alerted
        }
        $name = db()->prepare('SELECT u.full_name FROM technicians t JOIN users u ON u.id = t.user_id WHERE t.id = :t');
        $name->execute([':t' => $techId]);
        $techName = (string)($name->fetchColumn() ?: 'A technician');

        $msg = mb_substr(sprintf(
            '%s\'s location jumped %.1f km in %s on %s (about %d km/h) — possible fake-GPS app. Please check.',
            $techName, $jump['meters'] / 1000,
            $jump['seconds'] < 120 ? $jump['seconds'] . ' s' : round($jump['seconds'] / 60) . ' min',
            $job['job_code'], $jump['kmh']
        ), 0, 255);
        $staff = db()->query(
            "SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id WHERE u.status = 'ACTIVE' AND r.role_key IN ('admin','manager','staff')"
        )->fetchAll(PDO::FETCH_COLUMN);
        foreach ($staff as $uid) {
            notify((int)$uid, 'GPS_ALERT', $msg, 'jobs', (int)$job['id']);
        }
        audit_log('GPS_JUMP', 'geofence', $job['job_code']);
    } catch (Throwable $e) {
        // An alert failing must never stop the technician's work.
    }
}

// ---------------------------------------------------------------------------
// Installation checklist
// ---------------------------------------------------------------------------

/** Installation checklist row for a job, or null. */
function tech_checklist_for_job(int $jobId): ?array
{
    $stmt = db()->prepare('SELECT * FROM installation_checklists WHERE job_id = :j');
    $stmt->execute([':j' => $jobId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/**
 * The 17-item installation checklist (5 categories), from the prototype:
 * Site Preparation, Mounting, Electrical, Testing, Finalization.
 * [item_key, category, description]
 */
function tech_installation_item_template(): array
{
    return [
        ['sp1', 'Site Preparation', 'Site survey and roof assessment completed'],
        ['sp2', 'Site Preparation', 'Safety equipment and work area barricades set up'],
        ['sp3', 'Site Preparation', 'Materials checked against the bill of materials'],
        ['mo1', 'Mounting',         'Roof anchors / footings installed'],
        ['mo2', 'Mounting',         'Mounting rails installed and leveled'],
        ['mo3', 'Mounting',         'Solar panels mounted and clamped'],
        ['mo4', 'Mounting',         'Roof penetrations sealed and waterproofed'],
        ['el1', 'Electrical',       'DC string wiring and MC4 connections'],
        ['el2', 'Electrical',       'Combiner box / DC isolator installed'],
        ['el3', 'Electrical',       'Inverter mounted and connected'],
        ['el4', 'Electrical',       'AC wiring, breaker and grounding completed'],
        ['te1', 'Testing',          'Open-circuit voltage and polarity checked'],
        ['te2', 'Testing',          'Insulation resistance test passed'],
        ['te3', 'Testing',          'System powered up and output verified'],
        ['fi1', 'Finalization',     'Monitoring app configured for the client'],
        ['fi2', 'Finalization',     'Site cleaned and system labels applied'],
        ['fi3', 'Finalization',     'Client walkthrough and handover completed'],
    ];
}

/** The installation stages in the order they must be done (from the template). */
function tech_installation_stages(): array
{
    return array_values(array_unique(array_column(tech_installation_item_template(), 1)));
}

/** Most proof photos one stage may hold. */
const INSTALLATION_PHOTO_MAX_PER_STAGE = 10;

/**
 * Proof photos per stage for a checklist: ['Site Preparation' => 2, ...].
 * Null when the installation_photos table is not installed yet (phase 12) —
 * callers then treat photos as not required, so nothing locks up.
 */
function installation_photo_counts(int $checklistId): ?array
{
    try {
        $stmt = db()->prepare('SELECT stage, COUNT(*) AS n FROM installation_photos WHERE checklist_id = :c GROUP BY stage');
        $stmt->execute([':c' => $checklistId]);
    } catch (PDOException $e) {
        return null;
    }
    $counts = [];
    foreach ($stmt->fetchAll() as $r) {
        $counts[$r['stage']] = (int)$r['n'];
    }
    return $counts;
}

/** Every proof photo of a checklist, oldest first, each with the URL that streams it. */
function installation_photos_list(int $checklistId): array
{
    try {
        $stmt = db()->prepare(
            'SELECT ip.id, ip.stage, ip.width, ip.height, ip.created_at, u.full_name AS uploaded_by_name
             FROM installation_photos ip LEFT JOIN users u ON u.id = ip.uploaded_by
             WHERE ip.checklist_id = :c ORDER BY ip.id ASC'
        );
        $stmt->execute([':c' => $checklistId]);
    } catch (PDOException $e) {
        return [];
    }
    return array_map(function ($p) {
        $p['url'] = APP_BASE_URL . '/api/installation/photo_view.php?id=' . (int)$p['id'];
        return $p;
    }, $stmt->fetchAll());
}

/**
 * The checklist's stages in order, each with its items' progress and whether
 * the technician may work on it yet:
 *   [['name' => 'Site Preparation', 'total' => 3, 'resolved' => 3, 'photos' => 1,
 *     'needs_photo' => false, 'done' => true, 'unlocked' => true], ...]
 * A stage is done once every item is Completed or N/A and — when $photoCounts
 * is given — it has at least one proof photo. A stage is unlocked once every
 * stage before it is done. A category not in the template sorts last.
 */
function tech_installation_stage_status(array $items, ?array $photoCounts = null): array
{
    $order = array_flip(tech_installation_stages());
    $stages = [];
    foreach ($items as $it) {
        $name = $it['category'];
        $stages[$name] ??= ['name' => $name, 'total' => 0, 'resolved' => 0, 'rank' => $order[$name] ?? count($order)];
        $stages[$name]['total']++;
        if ($it['status'] !== 'PENDING') {
            $stages[$name]['resolved']++;
        }
    }
    usort($stages, fn($a, $b) => $a['rank'] <=> $b['rank']);

    $unlocked = true;
    foreach ($stages as &$s) {
        $s['photos'] = (int)($photoCounts[$s['name']] ?? 0);
        // All items ticked, but the proof photo is still missing.
        $s['needs_photo'] = $photoCounts !== null && $s['photos'] === 0;
        $s['done'] = $s['resolved'] === $s['total'] && !$s['needs_photo'];
        $s['unlocked'] = $unlocked;
        $unlocked = $unlocked && $s['done'];
        unset($s['rank']);
    }
    unset($s);
    return $stages;
}

/**
 * Why this item may not be set to $newStatus, or null when it may. Stages are
 * done one after the other:
 *   ticking (Completed / N/A)  only once every earlier stage is done
 *   unticking (Pending)        only while no later stage has anything ticked,
 *                              so a finished stage cannot be reopened under work
 *                              that depends on it
 * Within a stage, items may be ticked in any order.
 */
function tech_installation_step_blocker(int $checklistId, int $itemId, string $newStatus): ?string
{
    $stmt = db()->prepare('SELECT id, category, status FROM installation_items WHERE checklist_id = :c');
    $stmt->execute([':c' => $checklistId]);
    $items = $stmt->fetchAll();

    $stages = tech_installation_stage_status($items, installation_photo_counts($checklistId));
    $names = array_column($stages, 'name');
    $category = null;
    foreach ($items as $it) {
        if ((int)$it['id'] === $itemId) {
            $category = $it['category'];
        }
    }
    $pos = array_search($category, $names, true);
    if ($pos === false) {
        return null;
    }

    // Stages booked for the same day are one visit: they neither wait for nor
    // block each other.
    $visit = [$category];
    if (function_exists('install_plan_visit_stages') && install_plan_available()) {
        $jobId = (int)db()->query('SELECT job_id FROM installation_checklists WHERE id = ' . (int)$checklistId)->fetchColumn();
        $visit = install_plan_visit_stages($checklistId, $jobId, $category) ?: [$category];
    }

    if ($newStatus !== 'PENDING') {
        if (!$stages[$pos]['unlocked']) {
            foreach ($stages as $s) {
                if (in_array($s['name'], $visit, true)) {
                    continue; // same visit: fine to work on together
                }
                if (array_search($s['name'], $names, true) >= $pos) {
                    break;
                }
                if (!$s['done']) {
                    $left = $s['total'] - $s['resolved'];
                    if ($left === 0) {
                        return "Add a proof photo for {$s['name']} first before starting {$category}.";
                    }
                    return "Finish {$s['name']} first ({$left} item" . ($left === 1 ? '' : 's') . " left"
                        . ($s['needs_photo'] ? ', plus a proof photo' : '') . ") before starting {$category}.";
                }
            }
        }
        return null;
    }

    for ($i = count($stages) - 1; $i > $pos; $i--) {
        if ($stages[$i]['resolved'] > 0 && !in_array($stages[$i]['name'], $visit, true)) {
            return "Untick the {$stages[$i]['name']} items first — {$category} can only be reopened while the stages after it are untouched.";
        }
    }
    return null;
}

/**
 * Create the installation checklist (+ its 17 items) for an INSTALLATION job
 * if it does not have one yet, and return it. Safe to call repeatedly: the
 * UNIQUE key on installation_checklists.job_id means a concurrent second call
 * finds the first one's row instead of creating another.
 */
function tech_ensure_installation_checklist(int $jobId): ?array
{
    $existing = tech_checklist_for_job($jobId);
    if ($existing) {
        return $existing;
    }

    $pdo = db();
    try {
        $pdo->prepare('INSERT INTO installation_checklists (job_id, progress) VALUES (:j, 0)')->execute([':j' => $jobId]);
    } catch (PDOException $e) {
        if (($e->errorInfo[1] ?? null) === 1062) {
            return tech_checklist_for_job($jobId); // created by a concurrent request
        }
        throw $e;
    }
    $checklistId = (int)$pdo->lastInsertId();

    $item = $pdo->prepare(
        'INSERT INTO installation_items (checklist_id, item_key, category, description, status)
         VALUES (:c, :k, :cat, :d, "PENDING")'
    );
    foreach (tech_installation_item_template() as [$key, $category, $description]) {
        $item->execute([':c' => $checklistId, ':k' => $key, ':cat' => $category, ':d' => $description]);
    }

    return tech_checklist_for_job($jobId);
}

/**
 * Checklist counters: total / resolved (COMPLETED or NOT_APPLICABLE) /
 * completed / pending / percent.
 */
function tech_checklist_counts(int $checklistId): array
{
    $stmt = db()->prepare(
        "SELECT
            COUNT(*) AS total,
            SUM(status = 'COMPLETED') AS completed,
            SUM(status = 'NOT_APPLICABLE') AS not_applicable,
            SUM(status = 'PENDING') AS pending
         FROM installation_items WHERE checklist_id = :c"
    );
    $stmt->execute([':c' => $checklistId]);
    $row = $stmt->fetch() ?: [];

    $total    = (int)($row['total'] ?? 0);
    $done     = (int)($row['completed'] ?? 0) + (int)($row['not_applicable'] ?? 0);
    $progress = $total > 0 ? (int)round(($done / $total) * 100) : 0;

    return [
        'total'          => $total,
        'completed'      => (int)($row['completed'] ?? 0),
        'not_applicable' => (int)($row['not_applicable'] ?? 0),
        'pending'        => (int)($row['pending'] ?? 0),
        'resolved'       => $done,
        'progress'       => $progress,
    ];
}

/**
 * Recalculate checklist progress and cascade it to jobs.progress and, where
 * present, the parent project's progress. Returns the new percentage.
 * Never lowers a COMPLETED job below 100.
 */
function tech_recalc_installation(int $checklistId, int $jobId): int
{
    $pdo = db();
    $counts = tech_checklist_counts($checklistId);
    $progress = $counts['progress'];

    $pdo->prepare('UPDATE installation_checklists SET progress = :p WHERE id = :id')
        ->execute([':p' => $progress, ':id' => $checklistId]);

    $stageStmt = $pdo->prepare('SELECT stage, project_id FROM jobs WHERE id = :j');
    $stageStmt->execute([':j' => $jobId]);
    $jobRow = $stageStmt->fetch();

    $jobProgress = ($jobRow && $jobRow['stage'] === 'COMPLETED') ? 100 : $progress;

    $pdo->prepare('UPDATE jobs SET progress = :p WHERE id = :j')
        ->execute([':p' => $jobProgress, ':j' => $jobId]);

    if ($jobRow && $jobRow['project_id']) {
        $pdo->prepare('UPDATE projects SET progress = :p WHERE id = :pid')
            ->execute([':p' => $jobProgress, ':pid' => (int)$jobRow['project_id']]);
    }

    return $progress;
}

// ---------------------------------------------------------------------------
// Maintenance
// ---------------------------------------------------------------------------

/** The six inspection items seeded for every maintenance record. */
function tech_maintenance_item_template(): array
{
    return [
        ['mnt1', 'Panel inspection',      'Solar Panels'],
        ['mnt2', 'Cable inspection',      'Solar Panels'],
        ['mnt3', 'Inverter inspection',   'Inverter'],
        ['mnt4', 'Battery inspection',    'Battery'],
        ['mnt5', 'Mounting inspection',   'Solar Panels'],
        ['mnt6', 'Performance testing',   'Inverter'],
    ];
}

/** Map an item_key to its inspection category, for grouping in the UI. */
function tech_maintenance_category(string $itemKey, string $description): string
{
    foreach (tech_maintenance_item_template() as [$key, , $category]) {
        if ($key === $itemKey) {
            return $category;
        }
    }
    $d = strtolower($description);
    if (str_contains($d, 'batter')) return 'Battery';
    if (str_contains($d, 'inverter') || str_contains($d, 'performance')) return 'Inverter';
    return 'Solar Panels';
}

/**
 * Fetch the maintenance record for a job, creating it (plus its six inspection
 * items) the first time the technician opens the job. Uses the existing
 * maintenance_records / maintenance_items tables — no new tables.
 */
function tech_maintenance_record_for_job(array $job, bool $createIfMissing = true): ?array
{
    $pdo = db();

    $stmt = $pdo->prepare('SELECT * FROM maintenance_records WHERE job_id = :j ORDER BY id DESC LIMIT 1');
    $stmt->execute([':j' => $job['id']]);
    $record = $stmt->fetch();

    if ($record) {
        return $record;
    }
    if (!$createIfMissing) {
        return null;
    }

    // Resolve the client's solar system so the record links to real equipment.
    $sysStmt = $pdo->prepare('SELECT id FROM solar_systems WHERE client_id = :c ORDER BY id DESC LIMIT 1');
    $sysStmt->execute([':c' => $job['client_id']]);
    $systemId = $sysStmt->fetchColumn() ?: null;

    $pdo->prepare(
        'INSERT INTO maintenance_records (job_id, client_id, solar_system_id, technician_id, status)
         VALUES (:j, :c, :s, :t, "PENDING")'
    )->execute([
        ':j' => $job['id'], ':c' => $job['client_id'],
        ':s' => $systemId, ':t' => $job['technician_id'],
    ]);
    $recordId = (int)$pdo->lastInsertId();

    $itemStmt = $pdo->prepare(
        'INSERT INTO maintenance_items (maintenance_id, item_key, description, status)
         VALUES (:m, :k, :d, "PENDING")'
    );
    foreach (tech_maintenance_item_template() as [$key, $desc]) {
        $itemStmt->execute([':m' => $recordId, ':k' => $key, ':d' => $desc]);
    }

    $stmt->execute([':j' => $job['id']]);
    return $stmt->fetch() ?: null;
}

/** Maintenance item counters + percentage. */
function tech_maintenance_counts(int $recordId): array
{
    $stmt = db()->prepare(
        "SELECT COUNT(*) AS total,
                SUM(status = 'COMPLETED') AS completed,
                SUM(status = 'NOT_APPLICABLE') AS not_applicable,
                SUM(status = 'PENDING') AS pending
         FROM maintenance_items WHERE maintenance_id = :m"
    );
    $stmt->execute([':m' => $recordId]);
    $row = $stmt->fetch() ?: [];

    $total = (int)($row['total'] ?? 0);
    $done  = (int)($row['completed'] ?? 0) + (int)($row['not_applicable'] ?? 0);

    return [
        'total'     => $total,
        'completed' => (int)($row['completed'] ?? 0),
        'pending'   => (int)($row['pending'] ?? 0),
        'resolved'  => $done,
        'progress'  => $total > 0 ? (int)round(($done / $total) * 100) : 0,
    ];
}

/**
 * Is this maintenance job ready to be marked COMPLETED?
 * Returns null when it is, or a human-readable reason when it is not.
 */
function tech_maintenance_blocker(array $job): ?string
{
    $record = tech_maintenance_record_for_job($job, false);
    if (!$record) {
        return 'Open the Maintenance tab and record the inspection before completing this job.';
    }
    foreach (['panel_condition' => 'solar panels', 'battery_condition' => 'battery', 'inverter_condition' => 'inverter'] as $field => $label) {
        if (empty($record[$field])) {
            return 'Record the ' . $label . ' condition before completing this maintenance job.';
        }
    }
    $counts = tech_maintenance_counts((int)$record['id']);
    if ($counts['pending'] > 0) {
        return sprintf('%d inspection item(s) still pending. Mark every item Completed or N/A first.', $counts['pending']);
    }
    // Phase 20: proof photos per section, and Management's approval — the same
    // process as an installation stage.
    if (maint_review_ready()) {
        $photos = maint_photo_counts((int)$record['id']) ?? [];
        foreach (array_keys(tech_maintenance_sections()) as $section) {
            if (empty($photos[$section])) {
                return "Add a proof photo for {$section} in the Maintenance tab before completing this job.";
            }
        }
        if ($record['review_status'] === 'SUBMITTED') {
            return 'Management has not approved the maintenance inspection yet. You will be notified when it is reviewed.';
        }
        if ($record['review_status'] !== 'APPROVED') {
            return 'Submit the maintenance inspection for Management review (Maintenance tab) before completing this job.';
        }
    }
    return null;
}

// ---------------------------------------------------------------------------
// Maintenance checklist: sections, proof photos, review (phase 20)
// ---------------------------------------------------------------------------

const MAINTENANCE_PHOTO_MAX_PER_SECTION = 10;

/** The inspection's sections in working order, each with its condition field. */
function tech_maintenance_sections(): array
{
    return ['Solar Panels' => 'panel_condition', 'Battery' => 'battery_condition', 'Inverter' => 'inverter_condition'];
}

/** Has database/phase20_maintenance_checklist.sql been imported? */
function maint_review_ready(): bool
{
    static $ok = null;
    if ($ok === null) {
        try {
            db()->query('SELECT review_status FROM maintenance_records LIMIT 0');
            db()->query('SELECT section FROM maintenance_photos LIMIT 0');
            db()->query('SELECT completed_at FROM maintenance_items LIMIT 0');
            $ok = true;
        } catch (PDOException $e) {
            $ok = false;
        }
    }
    return $ok;
}

/** Proof photos per section: ['Solar Panels' => 2, ...]; null before phase 20. */
function maint_photo_counts(int $recordId): ?array
{
    if (!maint_review_ready()) {
        return null;
    }
    $stmt = db()->prepare('SELECT section, COUNT(*) AS n FROM maintenance_photos WHERE maintenance_id = :m GROUP BY section');
    $stmt->execute([':m' => $recordId]);
    return array_map('intval', array_column($stmt->fetchAll(), 'n', 'section'));
}

/** Every proof photo of an inspection, oldest first, with the URL that streams it. */
function maint_photos_list(int $recordId): array
{
    if (!maint_review_ready()) {
        return [];
    }
    $stmt = db()->prepare(
        'SELECT mp.id, mp.section, mp.width, mp.height, mp.created_at, u.full_name AS uploaded_by_name
         FROM maintenance_photos mp LEFT JOIN users u ON u.id = mp.uploaded_by
         WHERE mp.maintenance_id = :m ORDER BY mp.id ASC'
    );
    $stmt->execute([':m' => $recordId]);
    return array_map(function ($p) {
        $p['url'] = APP_BASE_URL . '/api/maintenance/photo_view.php?id=' . (int)$p['id'];
        return $p;
    }, $stmt->fetchAll());
}

/**
 * Each section's progress: [['name', 'condition_field', 'condition', 'total',
 * 'resolved', 'photos', 'done'], ...]. $items carry 'category' and 'status'.
 */
function maint_section_status(array $record, array $items, array $photoCounts): array
{
    $out = [];
    foreach (tech_maintenance_sections() as $name => $field) {
        $mine = array_filter($items, fn($i) => $i['category'] === $name);
        $resolved = count(array_filter($mine, fn($i) => $i['status'] !== 'PENDING'));
        $photos = (int)($photoCounts[$name] ?? 0);
        $out[] = [
            'name' => $name, 'condition_field' => $field, 'condition' => $record[$field] ?? null,
            'total' => count($mine), 'resolved' => $resolved, 'photos' => $photos,
            'done' => $resolved === count($mine) && $photos > 0 && !empty($record[$field]),
        ];
    }
    return $out;
}

/**
 * Why the technician may not change the inspection now (submitted for review,
 * or approved and locked), or null when it can be edited.
 */
function maint_edit_blocker(array $record): ?string
{
    if (!maint_review_ready()) {
        return null;
    }
    return match ($record['review_status'] ?? 'OPEN') {
        'SUBMITTED' => 'This inspection was submitted — Management is reviewing it. It opens again if it is returned.',
        'APPROVED'  => 'This inspection was approved by Management and is locked.',
        default     => null,
    };
}

/** Why the inspection cannot be submitted for review yet, or null. */
function maint_submit_blocker(array $record, array $sections): ?string
{
    foreach ($sections as $s) {
        if ($s['resolved'] < $s['total']) {
            $left = $s['total'] - $s['resolved'];
            return "Tick the remaining {$left} item" . ($left === 1 ? '' : 's') . " of {$s['name']} (or mark them N/A) first.";
        }
        if (empty($s['condition'])) {
            return "Record the {$s['name']} condition (Good, Fair or Poor) first.";
        }
        if ($s['photos'] < 1) {
            return "Add at least one proof photo for {$s['name']} first.";
        }
    }
    return null;
}

// ---------------------------------------------------------------------------
// Availability
// ---------------------------------------------------------------------------

function tech_availability_values(): array
{
    return ['AVAILABLE', 'BUSY', 'OFF_DUTY', 'ON_LEAVE'];
}

/** Current availability for a technician (defaults to AVAILABLE when no row exists). */
function tech_availability(int $techId): string
{
    $stmt = db()->prepare('SELECT status FROM technician_availability WHERE technician_id = :t');
    $stmt->execute([':t' => $techId]);
    return $stmt->fetchColumn() ?: 'AVAILABLE';
}

/** Write availability through the single upsert used everywhere. */
function tech_set_availability(int $techId, string $status): void
{
    db()->prepare(
        'INSERT INTO technician_availability (technician_id, status) VALUES (:t, :s)
         ON DUPLICATE KEY UPDATE status = :s2'
    )->execute([':t' => $techId, ':s' => $status, ':s2' => $status]);
}

/** Jobs currently in a field stage for this technician (optionally excluding one job). */
function tech_active_field_jobs(int $techId, ?int $excludeJobId = null): array
{
    $sql = "SELECT id, job_code, stage FROM jobs
            WHERE technician_id = :t AND stage IN ('EN_ROUTE','ARRIVED','IN_PROGRESS','PAUSED')";
    $params = [':t' => $techId];
    if ($excludeJobId) {
        $sql .= ' AND id <> :x';
        $params[':x'] = $excludeJobId;
    }
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

// ---------------------------------------------------------------------------
// Completion gate
// ---------------------------------------------------------------------------

/** Completion blocker text when the work report is missing (status.php keys on it). */
const TECH_REPORT_REQUIRED = 'Submit the work report for this job before completing it.';

/**
 * Everything that must be true before a technician may mark a job COMPLETED.
 * Returns null when the job may be completed, or a reason string when it may not.
 */
function tech_completion_blocker(array $job): ?string
{
    $jobId  = (int)$job['id'];
    $techId = (int)$job['technician_id'];

    // 0. A service request's checklist job is completed by Management approving
    //    the checklist (includes/sr_checklist_lib.php), not by this button.
    if (function_exists('srcl_completion_blocker') && ($why = srcl_completion_blocker($job)) !== null) {
        return $why;
    }

    // 1. Installation jobs need a 100% checklist.
    if ($job['job_type'] === 'INSTALLATION') {
        $checklist = tech_checklist_for_job($jobId);
        if ($checklist) {
            $counts = tech_checklist_counts((int)$checklist['id']);
            if ($counts['pending'] > 0) {
                return sprintf(
                    'Installation checklist is %d%% complete — %d item(s) still pending. Finish the checklist before completing this job.',
                    $counts['progress'],
                    $counts['pending']
                );
            }
            // Every stage needs its proof photo.
            $photoCounts = installation_photo_counts((int)$checklist['id']);
            if ($photoCounts !== null) {
                $missing = array_values(array_filter(tech_installation_stages(), fn($st) => empty($photoCounts[$st])));
                if ($missing) {
                    return 'Add a proof photo for ' . implode(', ', $missing) . ' before completing this job.';
                }
            }
            // Every stage must have been reviewed and approved by Management.
            $plan = install_plan((int)$checklist['id'], $jobId);
            $waiting = array_column(array_filter($plan, fn($r) => $r['status'] !== 'APPROVED'), 'stage');
            if ($waiting) {
                return 'Management has not approved ' . implode(', ', $waiting) . ' yet. Each stage must be approved before the job can be completed.';
            }
        }
    }

    // 2. Maintenance jobs need a recorded inspection.
    if ($job['job_type'] === 'MAINTENANCE') {
        $reason = tech_maintenance_blocker($job);
        if ($reason !== null) {
            return $reason;
        }
    }

    // 3. A work report must be filed first.
    if (!job_has_report($jobId)) {
        return TECH_REPORT_REQUIRED;
    }

    // 4. If the technician timed in for this job, they must time out first so
    //    the GPS exit point is recorded.
    if (tech_open_attendance($jobId, $techId)) {
        return 'You are still timed in for this job. Record your GPS Time Out before completing it.';
    }

    return null;
}

/**
 * Progress value that matches a stage. Installation jobs keep their checklist
 * percentage instead of a flat per-stage number (except on completion).
 */
function tech_progress_for_stage(array $job, string $stage): int
{
    if ($stage === 'COMPLETED') {
        return 100;
    }

    if ($job['job_type'] === 'INSTALLATION') {
        $checklist = tech_checklist_for_job((int)$job['id']);
        if ($checklist) {
            return (int)$checklist['progress'];
        }
    }

    $map = ['EN_ROUTE' => 10, 'ARRIVED' => 25, 'IN_PROGRESS' => 60];
    if (isset($map[$stage])) {
        return max($map[$stage], (int)$job['progress']);
    }
    // PAUSED keeps whatever progress was already reached.
    return (int)$job['progress'];
}
