<?php
/**
 * SunTrack ERP — billing figures, defined once (Phase 18,
 * database/phase18_billing_integrity.sql).
 *
 *   valid payment   a payments row that has not been voided. Voided rows stay
 *                   in the history but never count as money received.
 *   valid invoice   any invoice except CANCELLED (shown as "Voided").
 *   paid            sum of an invoice's valid payments
 *   balance         max(amount − paid, 0) for a valid invoice; 0 when cancelled
 *   overdue         a valid invoice with a balance whose due date has passed
 *                   (worked out from the due date, not only the stored status)
 *
 * There is no credit-note table in SunTrack, so no credits are applied.
 * A completed job is never a payment, and an issued invoice is never cash:
 * only rows in `payments` count as money received.
 */

/** True once phase 18 is imported (payments can be voided, invoices carry job_id). */
function billing_void_ready(): bool
{
    static $ok = null;
    if ($ok === null) {
        try {
            db()->query('SELECT voided_at, request_key FROM payments LIMIT 0');
            db()->query('SELECT job_id FROM invoices LIMIT 0');
            $ok = true;
        } catch (PDOException $e) {
            $ok = false;
        }
    }
    return $ok;
}

function billing_require_schema(): void
{
    if (!billing_void_ready()) {
        json_error('Billing corrections are not set up yet. Import database/phase18_billing_integrity.sql.', 503);
    }
}

/** SQL condition for a valid (not voided) payment row, for the given alias. */
function billing_valid_payment(string $alias = 'p'): string
{
    return billing_void_ready() ? "$alias.voided_at IS NULL" : '1=1';
}

/** Derived table: invoice_id, paid (valid payments only). Join it as `pay`. */
function billing_paid_subquery(): string
{
    return 'SELECT p.invoice_id, SUM(p.amount) AS paid FROM payments p WHERE ' . billing_valid_payment('p') . ' GROUP BY p.invoice_id';
}

/** What has validly been paid on one invoice, in centavos. */
function billing_paid_cents(PDO $pdo, int $invoiceId): int
{
    $s = $pdo->prepare('SELECT COALESCE(SUM(p.amount), 0) FROM payments p WHERE p.invoice_id = :id AND ' . billing_valid_payment('p'));
    $s->execute([':id' => $invoiceId]);
    return (int)round((float)$s->fetchColumn() * 100);
}

/**
 * Put an open / paid invoice's status back in line with its valid payments
 * (after a payment is voided). CANCELLED is never touched. Call inside the
 * transaction that holds the invoice row lock.
 */
function billing_sync_status(PDO $pdo, array $invoice): string
{
    if ($invoice['payment_status'] === 'CANCELLED') {
        return 'CANCELLED';
    }
    $balance = (int)round((float)$invoice['amount'] * 100) - billing_paid_cents($pdo, (int)$invoice['id']);
    if ($balance <= 0) {
        $status = 'PAID';
    } else {
        $status = ($invoice['due_date'] && $invoice['due_date'] < date('Y-m-d')) ? 'OVERDUE' : 'PENDING';
    }
    if ($status !== $invoice['payment_status']) {
        $pdo->prepare('UPDATE invoices SET payment_status = :s, payment_date = ' . ($status === 'PAID' ? 'COALESCE(payment_date, CURDATE())' : 'NULL') . ' WHERE id = :id')
            ->execute([':s' => $status, ':id' => $invoice['id']]);
    }
    return $status;
}

/**
 * The Admin dashboard's Billing Overview, in one query.
 *   payments_received  valid payments with paid_at on/after $start (any invoice:
 *                      cash received is cash received)
 *   outstanding        total balance of valid invoices
 *   overdue            valid invoices with a balance, due date before today
 *   pending            valid invoices with a balance, not yet due (or no due date)
 * outstanding = overdue amount + pending amount, so nothing is counted twice.
 */
function billing_overview(PDO $pdo, string $start): array
{
    $valid = billing_valid_payment('p');
    $sql = "SELECT
        (SELECT COUNT(*) FROM invoices) AS invoices_total,
        (SELECT COALESCE(SUM(p.amount), 0) FROM payments p WHERE $valid AND p.paid_at >= :start) AS received_amount,
        (SELECT COUNT(*) FROM payments p WHERE $valid AND p.paid_at >= :start2) AS received_count,
        COALESCE(SUM(b.balance), 0) AS outstanding_amount,
        COALESCE(SUM(b.balance > 0), 0) AS outstanding_count,
        COALESCE(SUM(CASE WHEN b.balance > 0 AND b.due_date < CURDATE() THEN b.balance END), 0) AS overdue_amount,
        COALESCE(SUM(b.balance > 0 AND b.due_date < CURDATE()), 0) AS overdue_count,
        COALESCE(SUM(CASE WHEN b.balance > 0 AND (b.due_date IS NULL OR b.due_date >= CURDATE()) THEN b.balance END), 0) AS pending_amount,
        COALESCE(SUM(b.balance > 0 AND (b.due_date IS NULL OR b.due_date >= CURDATE())), 0) AS pending_count,
        COALESCE(SUM(b.balance > 0 AND b.paid > 0), 0) AS partial_count
      FROM (SELECT i.id, i.due_date, COALESCE(pay.paid, 0) AS paid,
                   GREATEST(i.amount - COALESCE(pay.paid, 0), 0) AS balance
            FROM invoices i
            LEFT JOIN (" . billing_paid_subquery() . ") pay ON pay.invoice_id = i.id
            WHERE i.payment_status <> 'CANCELLED') b";
    $s = $pdo->prepare($sql);
    $s->execute([':start' => $start, ':start2' => $start]);
    $r = $s->fetch();
    return [
        'has_data'           => (int)$r['invoices_total'] > 0,
        'payments_received'  => round((float)$r['received_amount'], 2),
        'payments_count'     => (int)$r['received_count'],
        'outstanding_amount' => round((float)$r['outstanding_amount'], 2),
        'outstanding_count'  => (int)$r['outstanding_count'],
        'overdue_count'      => (int)$r['overdue_count'],
        'overdue_amount'     => round((float)$r['overdue_amount'], 2),
        'pending_count'      => (int)$r['pending_count'],
        'pending_amount'     => round((float)$r['pending_amount'], 2),
        'partial_count'      => (int)$r['partial_count'],
    ];
}
