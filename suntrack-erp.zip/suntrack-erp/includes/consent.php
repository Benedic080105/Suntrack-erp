<?php
/**
 * SunTrack ERP — Privacy & cookie consent.
 *
 * SunTrack records employee location during field work, which makes consent a
 * substantive requirement rather than a banner for show. Two things are
 * tracked separately:
 *
 *   PRIVACY  — agreement to the policy itself, including GPS tracking during
 *              an active job. Captured at registration and re-prompted when
 *              the policy version changes.
 *   COOKIES  — the banner choice. SunTrack sets only one cookie that matters
 *              (the session), which is strictly necessary, so the banner
 *              offers "Accept" and "Essential only" rather than pretending
 *              there is advertising to opt out of.
 */

/** Name of the cookie that remembers the banner choice. */
const CONSENT_COOKIE_NAME = 'suntrack_consent';

/** How long the banner choice is remembered, in days. */
const CONSENT_COOKIE_DAYS = 180;

/**
 * Persist a consent decision.
 *
 * $userId is null for a decision made before signing in — the row is still
 * written, because "this IP accepted at this time" is the evidence that
 * matters if the decision is ever questioned.
 */
function consent_record(?int $userId, string $type, string $decision, ?string $version = null): void
{
    $type     = in_array($type, ['PRIVACY', 'COOKIES', 'TERMS'], true) ? $type : 'PRIVACY';
    $decision = in_array($decision, ['ACCEPTED', 'REJECTED', 'ESSENTIAL_ONLY'], true) ? $decision : 'ACCEPTED';
    $version  = $version ?? privacy_policy_version();

    try {
        db()->prepare(
            'INSERT INTO consent_logs (user_id, consent_type, decision, policy_version, ip_address, user_agent)
             VALUES (:uid, :type, :decision, :ver, :ip, :ua)'
        )->execute([
            ':uid'      => $userId,
            ':type'     => $type,
            ':decision' => $decision,
            ':ver'      => $version,
            ':ip'       => client_ip(),
            ':ua'       => client_user_agent(),
        ]);

        // Mirror the latest decision onto the user row so that checking
        // "has this person accepted the current policy?" is a single read.
        if ($userId !== null) {
            if ($type === 'PRIVACY' && $decision === 'ACCEPTED') {
                db()->prepare(
                    'UPDATE users SET privacy_accepted_at = NOW(), privacy_version = :v WHERE id = :id'
                )->execute([':v' => $version, ':id' => $userId]);
            } elseif ($type === 'COOKIES') {
                db()->prepare('UPDATE users SET cookie_consent_at = NOW() WHERE id = :id')
                    ->execute([':id' => $userId]);
            }
        }
    } catch (Throwable $e) {
        // Consent logging must never break the page it is attached to.
    }
}

/**
 * Write the banner cookie.
 *
 * Deliberately NOT httponly: the banner script reads it to decide whether to
 * render. It carries no secret — only the word "accepted" or "essential".
 */
function consent_set_cookie(string $decision): void
{
    if (headers_sent()) {
        return;
    }

    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');

    setcookie(CONSENT_COOKIE_NAME, $decision, [
        'expires'  => time() + (CONSENT_COOKIE_DAYS * 86400),
        'path'     => '/',
        'httponly' => false,
        'samesite' => 'Lax',
        'secure'   => $isHttps,
    ]);
}

/** The visitor's stored banner choice, or null if they have not chosen yet. */
function consent_cookie_choice(): ?string
{
    return $_COOKIE[CONSENT_COOKIE_NAME] ?? null;
}

/** True when the banner still needs to be shown. */
function consent_banner_needed(): bool
{
    return consent_cookie_choice() === null;
}

/**
 * True when the signed-in user has accepted the CURRENT privacy policy.
 * A version bump flips this back to false and re-prompts.
 */
function consent_privacy_current(?int $userId = null): bool
{
    $userId = $userId ?? current_user_id();
    if ($userId === null) {
        return false;
    }

    try {
        $stmt = db()->prepare('SELECT privacy_accepted_at, privacy_version FROM users WHERE id = :id');
        $stmt->execute([':id' => $userId]);
        $row = $stmt->fetch();

        if (!$row || empty($row['privacy_accepted_at'])) {
            return false;
        }
        return (string)$row['privacy_version'] === privacy_policy_version();
    } catch (Throwable $e) {
        // On error, do not lock anyone out of the system.
        return true;
    }
}
