<?php
/**
 * SunTrack ERP — installation done as scheduled, approved stages.
 *
 * Each stage of the installation checklist is its own visit:
 *
 *   1. Management schedules the stage for a day (the first one — Site
 *      Preparation, the inspection — gets the job's scheduled date).
 *   2. On that day the technician ticks the stage's items and adds proof
 *      photos, then submits it for review. Nothing else is open to them.
 *   3. Management reviews: Approve (and schedule the next stage, and after the
 *      inspection send the material request to the warehouse) or Return it
 *      with a note for the technician to fix.
 *   4. When every stage is approved, the technician completes the job.
 *
 * Statuses: PLANNED -> SCHEDULED -> SUBMITTED -> APPROVED, with SUBMITTED ->
 * RETURNED -> SUBMITTED when Management sends it back.
 *
 * Plan rows are created the first time a checklist is opened. Stages already
 * finished at that moment (items + proof photo) are recorded as APPROVED so
 * work done before this feature is never thrown away.
 *
 * Everything degrades safely when database/phase13_installation_stage_plan.sql
 * has not been run: install_plan_available() is false and the checklist works
 * as before.
 */

const INSTALL_PLAN_LABELS = [
    'PLANNED'   => 'Not scheduled yet',
    'SCHEDULED' => 'Scheduled',
    'SUBMITTED' => 'Waiting for review',
    'APPROVED'  => 'Approved',
    'RETURNED'  => 'Returned for fixes',
];

function install_plan_available(): bool
{
    static $ok = null;
    if ($ok === null) {
        try {
            db()->query('SELECT 1 FROM installation_stage_plan LIMIT 0');
            $ok = true;
        } catch (PDOException $e) {
            $ok = false;
        }
    }
    return $ok;
}

/** "Oct 9, 2026" */
function install_plan_date(?string $ymd): string
{
    return $ymd ? date('M j, Y', strtotime($ymd)) : '';
}

/**
 * The plan for a checklist, in stage order, created on first use.
 * Each row: stage, position, status, status_label, scheduled_date, notes,
 * submitter / reviewer names. Empty array when phase 13 is not installed.
 */
function install_plan(int $checklistId, int $jobId): array
{
    if (!install_plan_available()) {
        return [];
    }
    $pdo = db();
    $load = function () use ($pdo, $checklistId) {
        $stmt = $pdo->prepare(
            'SELECT sp.*, su.full_name AS submitted_by_name, ru.full_name AS reviewed_by_name
             FROM installation_stage_plan sp
             LEFT JOIN users su ON su.id = sp.submitted_by
             LEFT JOIN users ru ON ru.id = sp.reviewed_by
             WHERE sp.checklist_id = :c ORDER BY sp.position ASC'
        );
        $stmt->execute([':c' => $checklistId]);
        return $stmt->fetchAll();
    };

    $rows = $load();
    if (!$rows) {
        install_plan_create($checklistId, $jobId);
        $rows = $load();
    }
    foreach ($rows as &$r) {
        $r['status_label'] = INSTALL_PLAN_LABELS[$r['status']] ?? $r['status'];
        $r['position'] = (int)$r['position'];
    }
    unset($r);
    return $rows;
}

/** First-time plan: finished stages APPROVED, the next one SCHEDULED, the rest PLANNED. */
function install_plan_create(int $checklistId, int $jobId): void
{
    $pdo = db();
    $job = $pdo->prepare('SELECT stage, scheduled_date FROM jobs WHERE id = :id');
    $job->execute([':id' => $jobId]);
    $job = $job->fetch() ?: ['stage' => 'ASSIGNED', 'scheduled_date' => null];

    $items = $pdo->prepare('SELECT category, status FROM installation_items WHERE checklist_id = :c');
    $items->execute([':c' => $checklistId]);
    $stages = tech_installation_stage_status($items->fetchAll(), installation_photo_counts($checklistId));

    $jobDone = $job['stage'] === 'COMPLETED';
    $firstOpen = true;
    $insert = $pdo->prepare(
        'INSERT IGNORE INTO installation_stage_plan (checklist_id, job_id, stage, position, status, scheduled_date, review_note, reviewed_at)
         VALUES (:c, :j, :s, :p, :st, :d, :note, :rat)'
    );
    foreach ($stages as $i => $s) {
        if ($jobDone || $s['done']) {
            $status = 'APPROVED';
            $date = null;
            $note = 'Finished before stage approvals were introduced.';
        } elseif ($firstOpen) {
            $status = 'SCHEDULED';
            $date = $job['scheduled_date'] ?: date('Y-m-d');
            $note = null;
            $firstOpen = false;
        } else {
            $status = 'PLANNED';
            $date = null;
            $note = null;
        }
        $insert->execute([
            ':c' => $checklistId, ':j' => $jobId, ':s' => $s['name'], ':p' => $i + 1, ':st' => $status, ':d' => $date,
            ':note' => $note, ':rat' => $status === 'APPROVED' ? date('Y-m-d H:i:s') : null,
        ]);
    }
}

/** The plan row for one stage, or null. */
function install_plan_stage(array $plan, string $stage): ?array
{
    foreach ($plan as $row) {
        if ($row['stage'] === $stage) {
            return $row;
        }
    }
    return null;
}

/**
 * Why the technician may not change items / photos of $stage right now, or
 * null when they may. Only the stage scheduled for today (or earlier) that is
 * still open — SCHEDULED or RETURNED — can be worked on.
 */
/** Two stages booked for the same day are one visit (worked together). */
function install_plan_same_visit(array $a, array $b): bool
{
    return !empty($a['scheduled_date']) && $a['scheduled_date'] === ($b['scheduled_date'] ?? null)
        && $a['status'] !== 'PLANNED' && ($b['status'] ?? '') !== 'PLANNED';
}

/**
 * The stage names in the same visit as $stage (itself included), from the
 * plan for that checklist. [] when there is no plan.
 */
function install_plan_visit_stages(int $checklistId, int $jobId, string $stage): array
{
    $plan = install_plan($checklistId, $jobId);
    $row = install_plan_stage($plan, $stage);
    if (!$row) {
        return [];
    }
    return array_values(array_map(fn($r) => $r['stage'], array_filter($plan,
        fn($r) => $r['stage'] === $stage || install_plan_same_visit($r, $row))));
}

function install_plan_edit_blocker(int $checklistId, int $jobId, string $stage): ?string
{
    $plan = install_plan($checklistId, $jobId);
    $row = install_plan_stage($plan, $stage);
    if (!$row) {
        return null; // phase 13 not installed, or a stage outside the plan
    }
    // Stages are worked in order — except that stages booked for the same day
    // are one visit and may be worked together, before any of them is approved.
    if (!in_array($row['status'], ['APPROVED', 'SUBMITTED'], true)) {
        foreach ($plan as $r) {
            if ($r['position'] < $row['position'] && $r['status'] !== 'APPROVED' && !install_plan_same_visit($r, $row)) {
                return "{$stage} opens once {$r['stage']} is approved"
                    . ($row['scheduled_date'] ? ' (it is booked for ' . install_plan_date($row['scheduled_date']) . ')' : '') . '.';
            }
        }
    }
    switch ($row['status']) {
        case 'APPROVED':
            return "{$stage} is approved and closed.";
        case 'SUBMITTED':
            return "{$stage} was submitted for review — it is locked while Management checks it.";
        case 'PLANNED':
            return "{$stage} is not scheduled yet. Management schedules it after approving the stage before it.";
    }
    if ($row['scheduled_date'] && $row['scheduled_date'] > date('Y-m-d')) {
        return "{$stage} is scheduled for " . install_plan_date($row['scheduled_date']) . ' — you can start it on that day.';
    }
    return null;
}

/**
 * One-line state of an installation for lists and cards:
 *   current      the stage that needs attention (null when all approved)
 *   status       its plan status
 *   label        e.g. "Mounting · Scheduled for Oct 9, 2026"
 *   workable     true when the technician can work on it today
 *   approved     how many stages are approved, of total
 *   all_approved true when the job is ready to be completed
 */
function install_plan_summary(array $plan): ?array
{
    if (!$plan) {
        return null;
    }
    $approved = count(array_filter($plan, fn($r) => $r['status'] === 'APPROVED'));
    $current = null;
    foreach ($plan as $r) {
        if ($r['status'] !== 'APPROVED') {
            $current = $r;
            break;
        }
    }
    $base = ['approved' => $approved, 'total' => count($plan), 'all_approved' => $current === null];
    if (!$current) {
        return $base + ['current' => null, 'status' => 'APPROVED', 'scheduled_date' => null, 'workable' => false,
                        'label' => 'All stages approved — ready to complete'];
    }
    $today = date('Y-m-d');
    // Stages open right now: booked for today or earlier, every earlier stage
    // approved or booked for the same day (one visit, worked together).
    $open = array_values(array_filter($plan, function ($r) use ($plan, $today) {
        if (!in_array($r['status'], ['SCHEDULED', 'RETURNED'], true) || ($r['scheduled_date'] && $r['scheduled_date'] > $today)) {
            return false;
        }
        foreach ($plan as $e) {
            if ($e['position'] < $r['position'] && $e['status'] !== 'APPROVED' && !install_plan_same_visit($e, $r)) {
                return false;
            }
        }
        return true;
    }));
    if ($open) {
        $first = $open[0];
        $names = implode(' + ', array_column($open, 'stage'));
        $returned = in_array('RETURNED', array_column($open, 'status'), true);
        $date = $first['scheduled_date'];
        $label = $returned ? 'Returned for fixes'
            : (!$date || $date === $today ? 'Scheduled for today' : 'Due — was scheduled for ' . install_plan_date($date));
        return $base + ['current' => $names, 'status' => $returned ? 'RETURNED' : 'SCHEDULED', 'scheduled_date' => $date,
                        'workable' => true, 'visit' => array_column($open, 'stage'), 'label' => $names . ' · ' . $label];
    }
    $date = $current['scheduled_date'];
    $workable = in_array($current['status'], ['SCHEDULED', 'RETURNED'], true) && (!$date || $date <= $today);
    $label = match ($current['status']) {
        'SCHEDULED' => $workable ? ($date === $today ? 'Scheduled for today' : 'Due — was scheduled for ' . install_plan_date($date))
                                 : 'Scheduled for ' . install_plan_date($date),
        'RETURNED'  => 'Returned for fixes',
        'SUBMITTED' => 'Waiting for Management review',
        default     => 'Waiting to be scheduled',
    };
    return $base + ['current' => $current['stage'], 'status' => $current['status'], 'scheduled_date' => $date,
                    'workable' => $workable, 'label' => $current['stage'] . ' · ' . $label];
}

/** Summary for a job id (loads the checklist and plan). Null for non-installation jobs. */
function install_plan_summary_for_job(int $jobId): ?array
{
    if (!install_plan_available()) {
        return null;
    }
    $checklist = tech_checklist_for_job($jobId);
    return $checklist ? install_plan_summary(install_plan((int)$checklist['id'], $jobId)) : null;
}

/** User ids of active Management (manager / staff). */
function install_plan_manager_ids(): array
{
    $stmt = db()->query(
        "SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id
         WHERE u.status = 'ACTIVE' AND r.role_key IN ('manager','staff')"
    );
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}

/** users.id of the job's technician, or null. */
function install_plan_tech_user(array $job): ?int
{
    if (empty($job['technician_id'])) {
        return null;
    }
    $stmt = db()->prepare('SELECT user_id FROM technicians WHERE id = :id');
    $stmt->execute([':id' => $job['technician_id']]);
    return ($u = $stmt->fetchColumn()) ? (int)$u : null;
}
