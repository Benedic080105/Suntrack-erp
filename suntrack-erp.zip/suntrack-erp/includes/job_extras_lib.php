<?php
/**
 * SunTrack ERP — job photos, client sign-off, and the files behind them.
 *
 * Files live in storage/ (blocked from the web by storage/.htaccess) under
 * random names, and are only ever handed out by PHP after job_access_or_fail()
 * has checked who is asking. An uploaded file is never trusted by its name or
 * its browser-reported type: it must parse as a real image, and when GD is
 * available it is re-encoded, which also strips GPS/EXIF metadata and anything
 * hidden inside the file.
 */

/** Photos per kind (BEFORE / AFTER) per job. */
const JOB_PHOTO_MAX_PER_KIND = 10;
/** Largest upload accepted, before any resizing. */
const JOB_PHOTO_MAX_BYTES = 8 * 1024 * 1024;
/** Longest side kept after resizing (when GD is available). */
const JOB_PHOTO_MAX_SIDE = 1600;
/** A drawn signature is a small PNG. */
const SIGNATURE_MAX_BYTES = 400 * 1024;

/** Absolute path of a storage bucket, created on first use. */
function storage_dir(string $bucket): string
{
    if (!preg_match('/^[a-z_]+$/', $bucket)) {
        throw new InvalidArgumentException('bad bucket');
    }
    $dir = ROOT_PATH . '/storage/' . $bucket;
    if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
        throw new RuntimeException('cannot create storage/' . $bucket);
    }
    return $dir;
}

/** Only names this library generated can be opened — no path tricks. */
function storage_name_ok(string $name): bool
{
    return (bool)preg_match('/^[a-f0-9]{32}\.(jpg|png|webp)$/', $name);
}

/**
 * The job, if the signed-in user may see it; otherwise a 403/404 JSON error.
 * Technicians: their own jobs. Clients: their own jobs. Management and Admin: all.
 */
function job_access_or_fail(int $jobId): array
{
    $stmt = db()->prepare(
        'SELECT j.*, c.user_id AS client_user_id, cu.full_name AS client_name, c.client_code
         FROM jobs j JOIN clients c ON c.id = j.client_id JOIN users cu ON cu.id = c.user_id
         WHERE j.id = :id'
    );
    $stmt->execute([':id' => $jobId]);
    $job = $stmt->fetch();
    if (!$job) {
        json_error('Job not found.', 404);
    }
    $role = current_role();
    $ok = in_array($role, ['admin', 'manager', 'staff'], true)
        || ($role === 'technician' && (int)$job['technician_id'] === (int)current_profile_id())
        || ($role === 'client' && (int)$job['client_id'] === (int)current_profile_id());
    if (!$ok) {
        json_error('You do not have access to this job.', 403);
    }
    return $job;
}

/** True when the job already has a work report. */
function job_has_report(int $jobId): bool
{
    $stmt = db()->prepare('SELECT 1 FROM work_reports WHERE job_id = :j LIMIT 1');
    $stmt->execute([':j' => $jobId]);
    return (bool)$stmt->fetchColumn();
}

/** ['BEFORE' => n, 'AFTER' => n] */
function job_photo_counts(int $jobId): array
{
    $counts = ['BEFORE' => 0, 'AFTER' => 0];
    try {
        $stmt = db()->prepare('SELECT kind, COUNT(*) AS n FROM job_photos WHERE job_id = :j GROUP BY kind');
        $stmt->execute([':j' => $jobId]);
        foreach ($stmt->fetchAll() as $r) {
            $counts[$r['kind']] = (int)$r['n'];
        }
    } catch (PDOException $e) {
        // Phase 7 not imported yet: behave as "no photos".
    }
    return $counts;
}

/** Whether a work report must carry before/after photos (setting, default on). */
function work_report_requires_photos(): bool
{
    return setting_bool('work_report_require_photos', true);
}

/** Photos for a job, with the URL that streams each one. */
function job_photos_list(int $jobId): array
{
    try {
        $stmt = db()->prepare(
            'SELECT id, kind, width, height, created_at FROM job_photos WHERE job_id = :j ORDER BY kind DESC, id ASC'
        );
        $stmt->execute([':j' => $jobId]);
    } catch (PDOException $e) {
        return [];
    }
    return array_map(function ($p) {
        $p['url'] = APP_BASE_URL . '/api/job_photos/view.php?id=' . (int)$p['id'];
        return $p;
    }, $stmt->fetchAll());
}

/**
 * Validate an uploaded image and store it. Returns
 * [file_name, mime, size_bytes, width, height] or fails with a clear 422.
 */
function store_uploaded_image(array $file, string $bucket): array
{
    $err = $file['error'] ?? UPLOAD_ERR_NO_FILE;
    if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE) {
        json_error('That photo is too large (max 8 MB).', 422);
    }
    if ($err !== UPLOAD_ERR_OK || empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        json_error('No photo was received. Please try again.', 422);
    }
    $size = (int)filesize($file['tmp_name']);
    if ($size <= 0 || $size > JOB_PHOTO_MAX_BYTES) {
        json_error('That photo is too large (max 8 MB).', 422);
    }

    $info = @getimagesize($file['tmp_name']);
    $types = [IMAGETYPE_JPEG => ['jpg', 'image/jpeg'], IMAGETYPE_PNG => ['png', 'image/png'], IMAGETYPE_WEBP => ['webp', 'image/webp']];
    if (!$info || !isset($types[$info[2]])) {
        json_error('Please upload a JPG, PNG or WebP photo.', 422);
    }
    [$w, $h] = [(int)$info[0], (int)$info[1]];
    if ($w < 32 || $h < 32 || $w > 12000 || $h > 12000) {
        json_error('That image has unusual dimensions and was not accepted.', 422);
    }
    // The bytes must agree with the header, not just the browser's claim.
    $sniffed = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if ($sniffed !== $types[$info[2]][1]) {
        json_error('Please upload a JPG, PNG or WebP photo.', 422);
    }

    $dir  = storage_dir($bucket);
    $base = bin2hex(random_bytes(16));

    // Preferred: re-encode with GD. Drops EXIF (incl. GPS) and any payload
    // hidden in the file, and shrinks huge phone photos.
    $loader = [IMAGETYPE_JPEG => 'imagecreatefromjpeg', IMAGETYPE_PNG => 'imagecreatefrompng', IMAGETYPE_WEBP => 'imagecreatefromwebp'][$info[2]];
    if (function_exists($loader) && function_exists('imagejpeg')) {
        $src = @$loader($file['tmp_name']);
        if (!$src) {
            json_error('That photo could not be read. Please take it again.', 422);
        }
        $scale = min(1, JOB_PHOTO_MAX_SIDE / max($w, $h));
        $nw = max(1, (int)round($w * $scale));
        $nh = max(1, (int)round($h * $scale));
        $dst = imagecreatetruecolor($nw, $nh);
        imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255)); // flatten PNG transparency
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
        $name = $base . '.jpg';
        imagejpeg($dst, $dir . '/' . $name, 82);
        imagedestroy($src);
        imagedestroy($dst);
        return [$name, 'image/jpeg', (int)filesize($dir . '/' . $name), $nw, $nh];
    }

    // Without GD: keep the verified original under a random name and a
    // extension chosen from its real type (never from the uploaded name).
    $name = $base . '.' . $types[$info[2]][0];
    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) {
        json_error('The photo could not be saved. Please try again.', 500);
    }
    return [$name, $types[$info[2]][1], $size, $w, $h];
}

/** Save a drawn signature sent as a data:image/png;base64 URL. Returns the file name. */
function store_signature_png(string $dataUrl): string
{
    if (!str_starts_with($dataUrl, 'data:image/png;base64,')) {
        json_error('Please sign in the box before confirming.', 422);
    }
    $bin = base64_decode(substr($dataUrl, 22), true);
    if ($bin === false || strlen($bin) < 100 || strlen($bin) > SIGNATURE_MAX_BYTES) {
        json_error('The signature could not be read. Please sign again.', 422);
    }
    $info = @getimagesizefromstring($bin);
    if (!$info || $info[2] !== IMAGETYPE_PNG || $info[0] > 3000 || $info[1] > 3000) {
        json_error('The signature could not be read. Please sign again.', 422);
    }
    $name = bin2hex(random_bytes(16)) . '.png';
    if (file_put_contents(storage_dir('signatures') . '/' . $name, $bin) === false) {
        json_error('The signature could not be saved. Please try again.', 500);
    }
    return $name;
}

/** Stream a stored file to the browser and stop. */
function storage_send(string $bucket, string $name, string $mime): void
{
    $path = storage_dir($bucket) . '/' . $name;
    if (!storage_name_ok($name) || !is_file($path)) {
        http_response_code(404);
        exit;
    }
    header_remove('Pragma');
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . filesize($path));
    header('Content-Disposition: inline');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, max-age=86400');
    readfile($path);
    exit;
}

/** Delete a stored file (after its row is gone). Silent if already missing. */
function storage_delete(string $bucket, string $name): void
{
    if (storage_name_ok($name)) {
        $path = storage_dir($bucket) . '/' . $name;
        if (is_file($path)) {
            @unlink($path);
        }
    }
}

/** The client's sign-off for a job, or null. */
function job_confirmation(int $jobId): ?array
{
    try {
        $stmt = db()->prepare(
            'SELECT id, method, signer_name, rating, comment, created_at FROM job_confirmations WHERE job_id = :j'
        );
        $stmt->execute([':j' => $jobId]);
        $row = $stmt->fetch();
    } catch (PDOException $e) {
        return null;
    }
    if (!$row) {
        return null;
    }
    $row['signature_url'] = APP_BASE_URL . '/api/confirmations/signature.php?job_id=' . $jobId;
    return $row;
}
