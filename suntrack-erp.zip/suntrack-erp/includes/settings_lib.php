<?php
/**
 * SunTrack ERP — Runtime settings.
 *
 * Values live in the `settings` table so an administrator can change policy
 * (geofence radius, strictness, poll interval) without editing PHP. Every
 * lookup in a request is served from one cached query — the real-time sync
 * endpoint is polled every few seconds, so a settings read must never cost a
 * round trip of its own.
 */

/** Load the whole settings table once per request. */
function settings_all(): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }

    $cache = [];
    try {
        $rows = db()->query('SELECT setting_key, setting_value FROM settings')->fetchAll();
        foreach ($rows as $row) {
            $cache[$row['setting_key']] = $row['setting_value'];
        }
    } catch (Throwable $e) {
        // A missing settings table must not take down the whole app — every
        // caller below supplies a sane default.
        $cache = [];
    }

    return $cache;
}

/** Read a single setting, falling back to $default when unset. */
function setting(string $key, $default = null)
{
    $all = settings_all();
    return array_key_exists($key, $all) && $all[$key] !== '' ? $all[$key] : $default;
}

/** Read a setting as an integer. */
function setting_int(string $key, int $default = 0): int
{
    $value = setting($key, null);
    return $value === null ? $default : (int)$value;
}

/** Read a setting as a boolean ('1', 'true', 'yes', 'on' are all true). */
function setting_bool(string $key, bool $default = false): bool
{
    $value = setting($key, null);
    if ($value === null) {
        return $default;
    }
    return in_array(strtolower((string)$value), ['1', 'true', 'yes', 'on'], true);
}

/**
 * Write a setting. Used by the admin settings screen.
 * Upsert, so a key that was never seeded is created on first write.
 */
function setting_set(string $key, string $value): void
{
    db()->prepare(
        'INSERT INTO settings (setting_key, setting_value) VALUES (:k, :v)
         ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)'
    )->execute([':k' => $key, ':v' => $value]);
}

/** The configured default geofence radius, in metres. */
function geofence_default_radius(): int
{
    $r = setting_int('geofence_default_radius_m', DEFAULT_GEOFENCE_RADIUS_M);
    return $r > 0 ? $r : DEFAULT_GEOFENCE_RADIUS_M;
}

/**
 * Whether a job with no site coordinates blocks Time In.
 *
 * With this off, "no coordinates" silently means "no geofence", and a
 * technician can time in from anywhere — which defeats the purpose of the
 * feature. Defaults to ON.
 */
function geofence_is_strict(): bool
{
    return setting_bool('geofence_strict', true);
}

/** Current privacy policy version, used to re-prompt when the policy changes. */
function privacy_policy_version(): string
{
    return (string)setting('privacy_policy_version', '1.0');
}
