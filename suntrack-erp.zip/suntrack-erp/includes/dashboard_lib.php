<?php
/**
 * SunTrack ERP — per-module dashboard figures (Clients, Technicians, Warehouse).
 *
 * Shared by api/dashboard/overview.php (what the Admin and Management
 * dashboards draw) and api/dashboard/admin.php, so both always agree.
 *
 * Every module is built independently: if one fails (a table from a later
 * migration is missing, for example) that module comes back as
 * ['available' => false] and the others still load. An empty table simply
 * gives zeros — the UI shows an empty state, never invented numbers.
 * Sample figures exist only through dashboard_modules_demo(), which callers
 * must opt into explicitly and which is flagged 'is_demo' => true.
 */

/** The last $count calendar months, oldest first: ['2026-05' => 'May 2026', ...]. */
function dashboard_months(int $count = 6): array
{
    $months = [];
    for ($i = $count - 1; $i >= 0; $i--) {
        $ts = strtotime(date('Y-m-01') . " -$i months");
        $months[date('Y-m', $ts)] = date('M Y', $ts);
    }
    return $months;
}

function dashboard_table_exists(PDO $pdo, string $table): bool
{
    try {
        $pdo->query('SELECT 1 FROM `' . str_replace('`', '', $table) . '` LIMIT 0');
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

function dashboard_modules(PDO $pdo): array
{
    $num = function (string $sql, array $p = []) use ($pdo) {
        $s = $pdo->prepare($sql);
        $s->execute($p);
        return $s->fetchColumn();
    };
    $rows = function (string $sql, array $p = []) use ($pdo): array {
        $s = $pdo->prepare($sql);
        $s->execute($p);
        return $s->fetchAll();
    };
    $safe = function (callable $build): array {
        try {
            return ['available' => true] + $build();
        } catch (PDOException $e) {
            error_log('SunTrack dashboard module: ' . $e->getMessage());
            return ['available' => false];
        }
    };

    $today      = date('Y-m-d');
    $tomorrow   = date('Y-m-d', strtotime('+1 day'));
    $monthStart = date('Y-m-01');
    $prevStart  = date('Y-m-01', strtotime($monthStart . ' -1 month'));
    $ago30      = date('Y-m-d H:i:s', strtotime('-30 days'));
    $ago90      = date('Y-m-d H:i:s', strtotime('-90 days'));
    $months     = dashboard_months(6);
    $since      = array_key_first($months) . '-01';
    $fieldStage = "('EN_ROUTE','ARRIVED','IN_PROGRESS','PAUSED')";

    // -----------------------------------------------------------------------
    // Clients
    // -----------------------------------------------------------------------
    $clients = $safe(function () use ($num, $rows, $months, $since, $monthStart, $prevStart) {
        // A client counts from date_registered when set, otherwise from when the record was created.
        $joined = 'COALESCE(date_registered, DATE(created_at))';

        $newByMonth = [];
        foreach ($rows("SELECT DATE_FORMAT($joined, '%Y-%m') AS ym, COUNT(*) AS n FROM clients WHERE $joined >= :s GROUP BY ym", [':s' => $since]) as $r) {
            $newByMonth[$r['ym']] = (int)$r['n'];
        }
        $running = (int)$num("SELECT COUNT(*) FROM clients WHERE $joined < :s", [':s' => $since]);
        $new = $total = [];
        foreach (array_keys($months) as $ym) {
            $new[]   = $newByMonth[$ym] ?? 0;
            $running += $newByMonth[$ym] ?? 0;
            $total[] = $running;
        }

        // Grid-tie / Hybrid / Off-grid ... as typed on each project. Cancelled projects never got a system.
        $types = array_map(fn($r) => ['key' => $r['k'], 'count' => (int)$r['n']], $rows(
            "SELECT COALESCE(NULLIF(TRIM(system_type), ''), 'Not specified') AS k, COUNT(*) AS n
             FROM projects WHERE status <> 'CANCELLED' GROUP BY k ORDER BY n DESC, k ASC"
        ));

        return [
            'kpis' => [
                'total'             => (int)$num('SELECT COUNT(*) FROM clients'),
                'active'            => (int)$num("SELECT COUNT(*) FROM clients c JOIN users u ON u.id = c.user_id WHERE u.status = 'ACTIVE'"),
                'new_this_month'    => (int)$num("SELECT COUNT(*) FROM clients WHERE $joined >= :m", [':m' => $monthStart]),
                'new_last_month'    => (int)$num("SELECT COUNT(*) FROM clients WHERE $joined >= :a AND $joined < :b", [':a' => $prevStart, ':b' => $monthStart]),
                'pending_enquiries' => (int)$num("SELECT COUNT(*) FROM service_requests WHERE status = 'PENDING'"),
            ],
            'acquisition'  => ['labels' => array_values($months), 'new' => $new, 'total' => $total],
            'system_types' => $types,
        ];
    });

    // -----------------------------------------------------------------------
    // Technicians
    // -----------------------------------------------------------------------
    $technicians = $safe(function () use ($num, $rows, $today, $tomorrow, $ago30, $fieldStage) {
        $activeTech = "FROM " . tech_staff_table() . " t JOIN users u ON u.id = t.user_id
                       LEFT JOIN technician_availability ta ON ta.technician_id = t.id
                       WHERE u.status = 'ACTIVE'";
        // No availability row yet means AVAILABLE (the same default the rest of the app uses).
        $onDuty = (int)$num("SELECT COUNT(*) $activeTech AND COALESCE(ta.status, 'AVAILABLE') IN ('AVAILABLE','BUSY')");
        $busy   = (int)$num("SELECT COUNT(*) $activeTech AND ta.status = 'BUSY'");

        $workload = $rows(
            "SELECT u.full_name AS name, t.technician_code AS code,
                    SUM(j.stage IN $fieldStage) AS in_progress,
                    SUM(j.stage IN ('SUBMITTED','ASSIGNED')) AS pending
             FROM " . tech_staff_table() . " t
             JOIN users u ON u.id = t.user_id
             JOIN jobs j ON j.technician_id = t.id AND j.stage NOT IN ('COMPLETED','CANCELLED')
             WHERE u.status = 'ACTIVE'
             GROUP BY t.id, u.full_name, t.technician_code
             ORDER BY COUNT(*) DESC, u.full_name ASC
             LIMIT 10"
        );
        foreach ($workload as &$w) {
            $w['in_progress'] = (int)$w['in_progress'];
            $w['pending']     = (int)$w['pending'];
        }
        unset($w);

        return [
            'kpis' => [
                'total'           => (int)$num("SELECT COUNT(*) $activeTech"),
                'on_field'        => (int)$num("SELECT COUNT(DISTINCT j.technician_id) FROM jobs j JOIN " . tech_staff_table() . " t ON t.id = j.technician_id
                                                JOIN users u ON u.id = t.user_id WHERE u.status = 'ACTIVE' AND j.stage IN $fieldStage"),
                'assigned_jobs'   => (int)$num("SELECT COUNT(*) FROM jobs WHERE technician_id IS NOT NULL AND stage NOT IN ('COMPLETED','CANCELLED')"),
                'unassigned_jobs' => (int)$num("SELECT COUNT(*) FROM jobs WHERE technician_id IS NULL AND stage NOT IN ('COMPLETED','CANCELLED')"),
                'completed_today' => (int)$num("SELECT COUNT(DISTINCT job_id) FROM job_status_history WHERE to_stage = 'COMPLETED' AND created_at >= :a AND created_at < :b",
                                               [':a' => $today, ':b' => $tomorrow]),
                'on_duty'         => $onDuty,
                'busy'            => $busy,
                // Share of on-duty technicians currently busy on a job.
                'utilization_pct' => $onDuty > 0 ? (int)round($busy * 100 / $onDuty) : 0,
            ],
            'job_status' => [
                'pending'       => (int)$num("SELECT COUNT(*) FROM jobs WHERE stage IN ('SUBMITTED','ASSIGNED')"),
                'in_progress'   => (int)$num("SELECT COUNT(*) FROM jobs WHERE stage IN $fieldStage"),
                'completed_30d' => (int)$num("SELECT COUNT(DISTINCT job_id) FROM job_status_history WHERE to_stage = 'COMPLETED' AND created_at >= :d", [':d' => $ago30]),
            ],
            'workload' => $workload,
        ];
    });

    // -----------------------------------------------------------------------
    // Warehouse & inventory
    // -----------------------------------------------------------------------
    $warehouse = $safe(function () use ($pdo, $num, $rows, $today, $tomorrow, $ago90) {
        $hasOrders = dashboard_table_exists($pdo, 'material_requests');
        $orders = ['PENDING' => 0, 'PREPARING' => 0, 'READY' => 0];
        if ($hasOrders) {
            foreach ($rows("SELECT status AS k, COUNT(*) AS n FROM material_requests WHERE status IN ('PENDING','PREPARING','READY') GROUP BY status") as $r) {
                $orders[$r['k']] = (int)$r['n'];
            }
        }

        $topItems = array_map(fn($r) => ['label' => $r['item_name'], 'sku' => $r['sku'], 'units' => (int)$r['units']], $rows(
            "SELECT i.item_name, i.sku, SUM(m.quantity) AS units
             FROM stock_movements m JOIN inventory i ON i.id = m.inventory_id
             WHERE m.movement_type = 'ISSUE' AND m.created_at >= :d
             GROUP BY i.id, i.item_name, i.sku
             ORDER BY units DESC, i.item_name ASC
             LIMIT 8",
            [':d' => $ago90]
        ));

        $byCategory = array_map(fn($r) => ['category' => $r['category'], 'value' => round((float)$r['value'], 2), 'units' => (int)$r['units']], $rows(
            "SELECT ic.category_name AS category,
                    COALESCE(SUM(i.quantity * i.unit_cost), 0) AS value,
                    COALESCE(SUM(i.quantity), 0) AS units
             FROM inventory_categories ic
             LEFT JOIN inventory i ON i.category_id = ic.id AND i.status <> 'DISCONTINUED'
             GROUP BY ic.id, ic.category_name
             ORDER BY ic.id"
        ));

        $issuedToday = $rows(
            "SELECT COALESCE(SUM(quantity), 0) AS units, COUNT(*) AS n FROM stock_movements
             WHERE movement_type = 'ISSUE' AND created_at >= :a AND created_at < :b",
            [':a' => $today, ':b' => $tomorrow]
        )[0];

        return [
            'kpis' => [
                'stock_value'         => (float)$num("SELECT COALESCE(SUM(quantity * unit_cost), 0) FROM inventory WHERE status <> 'DISCONTINUED'"),
                'low_stock'           => (int)$num("SELECT COUNT(*) FROM inventory WHERE status = 'LOW_STOCK'"),
                'out_of_stock'        => (int)$num("SELECT COUNT(*) FROM inventory WHERE status = 'OUT_OF_STOCK'"),
                'orders_tracked'      => $hasOrders,
                'pending_requests'    => array_sum($orders),
                'requests_by_status'  => $orders,
                'issued_today_units'  => (int)$issuedToday['units'],
                'issued_today_moves'  => (int)$issuedToday['n'],
            ],
            'top_issued'        => $topItems,
            'stock_by_category' => $byCategory,
        ];
    });

    return [
        'is_demo'     => false,
        'clients'     => $clients,
        'technicians' => $technicians,
        'warehouse'   => $warehouse,
    ];
}

/**
 * Sample figures in exactly the shape dashboard_modules() returns, for
 * front-end testing against an empty database. Never mixed with real data:
 * the whole block is flagged 'is_demo' => true and the UI labels it.
 */
function dashboard_modules_demo(): array
{
    $months = array_values(dashboard_months(6));
    return [
        'is_demo' => true,
        'clients' => [
            'available' => true,
            'kpis' => ['total' => 48, 'active' => 44, 'new_this_month' => 5, 'new_last_month' => 7, 'pending_enquiries' => 6],
            'acquisition' => ['labels' => $months, 'new' => [4, 6, 3, 8, 7, 5], 'total' => [23, 29, 32, 40, 47, 52]],
            'system_types' => [['key' => 'Hybrid (grid-tie + battery)', 'count' => 22], ['key' => 'Grid-tie', 'count' => 14], ['key' => 'Off-grid', 'count' => 4]],
        ],
        'technicians' => [
            'available' => true,
            'kpis' => ['total' => 10, 'on_field' => 4, 'assigned_jobs' => 17, 'unassigned_jobs' => 2, 'completed_today' => 3,
                       'on_duty' => 9, 'busy' => 4, 'utilization_pct' => 44],
            'job_status' => ['pending' => 11, 'in_progress' => 6, 'completed_30d' => 21],
            'workload' => [
                ['name' => 'Sample Technician A', 'code' => 'TECH-01', 'in_progress' => 2, 'pending' => 3],
                ['name' => 'Sample Technician B', 'code' => 'TECH-02', 'in_progress' => 1, 'pending' => 3],
                ['name' => 'Sample Technician C', 'code' => 'TECH-03', 'in_progress' => 2, 'pending' => 1],
                ['name' => 'Sample Technician D', 'code' => 'TECH-04', 'in_progress' => 1, 'pending' => 2],
            ],
        ],
        'warehouse' => [
            'available' => true,
            'kpis' => ['stock_value' => 1850000, 'low_stock' => 3, 'out_of_stock' => 1, 'orders_tracked' => true, 'pending_requests' => 5,
                       'requests_by_status' => ['PENDING' => 2, 'PREPARING' => 2, 'READY' => 1], 'issued_today_units' => 14, 'issued_today_moves' => 3],
            'top_issued' => [
                ['label' => 'Sample 550W Mono Panel', 'sku' => 'DEMO-1', 'units' => 96],
                ['label' => 'Sample 5kW Hybrid Inverter', 'sku' => 'DEMO-2', 'units' => 12],
                ['label' => 'Sample 5kWh LFP Battery', 'sku' => 'DEMO-3', 'units' => 9],
            ],
            'stock_by_category' => [
                ['category' => 'Solar Panel', 'value' => 820000, 'units' => 140],
                ['category' => 'Inverter', 'value' => 560000, 'units' => 18],
                ['category' => 'Battery', 'value' => 470000, 'units' => 15],
            ],
        ],
    ];
}
