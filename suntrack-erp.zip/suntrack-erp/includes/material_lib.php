<?php
/**
 * SunTrack ERP — Material requests ("client orders").
 *
 * Management says how many panels, inverters and batteries a client needs;
 * the Warehouse scans items out against that order until every line is
 * filled, then releases it. Each scanned unit is a normal ISSUE row in
 * stock_movements tagged with material_request_id, so stock levels, the
 * movement history and the reports all stay the single source of truth.
 *
 * Lock order, everywhere: material_requests row -> inventory row ->
 * material_request_items row. Keeping one order is what stops two clerks
 * scanning into the same order from deadlocking each other.
 */

/** Statuses in which the warehouse can still scan items in or out. */
const MR_OPEN_STATUSES = ['PENDING', 'PREPARING', 'READY'];

/** The request fields Management fills in, keyed by the category they count. */
const MR_QTY_FIELDS = [
    'panels'    => 'Solar Panel',
    'inverters' => 'Inverter',
    'batteries' => 'Battery',
];

/** Upper bound on one line, so a typo like 1000000 panels is rejected outright. */
const MR_MAX_QTY = 10000;

/**
 * Fail with a clear message when the phase 5 tables are missing, instead of
 * the generic 500 an unknown-table error would produce. LIMIT 0 reads no rows.
 */
function mr_require_schema(): void
{
    try {
        db()->query('SELECT 1 FROM material_requests LIMIT 0');
    } catch (PDOException $e) {
        json_error('Client orders are not set up yet. Import database/phase5_material_requests.sql.', 503);
    }
}

/** category_name => id for the three stock categories, read once per request. */
function mr_category_ids(): array
{
    static $map = null;
    if ($map === null) {
        $map = [];
        foreach (db()->query('SELECT id, category_name FROM inventory_categories') as $row) {
            $map[$row['category_name']] = (int)$row['id'];
        }
    }
    return $map;
}

/**
 * Read the panels / inverters / batteries quantities from a request body.
 *
 * $prefix lets the project form send them as mr_panels, mr_inverters, ...
 * Blank means zero. Returns [category_id => qty] containing only the lines
 * that are actually needed, so an all-zero form returns [].
 */
function mr_parse_quantities(array $input, string $prefix = ''): array
{
    $categories = mr_category_ids();
    $lines = [];

    foreach (MR_QTY_FIELDS as $field => $categoryName) {
        $raw = $input[$prefix . $field] ?? '';
        if ($raw === '' || $raw === null) {
            continue;
        }
        if (!is_numeric($raw) || (int)$raw != $raw || (int)$raw < 0) {
            json_error("Quantity for {$categoryName} must be a whole number of zero or more.", 422);
        }
        $qty = (int)$raw;
        if ($qty > MR_MAX_QTY) {
            json_error("Quantity for {$categoryName} cannot exceed " . MR_MAX_QTY . '.', 422);
        }
        if ($qty > 0) {
            if (!isset($categories[$categoryName])) {
                json_error("Inventory category {$categoryName} is missing.", 500);
            }
            $lines[$categories[$categoryName]] = $qty;
        }
    }

    return $lines;
}

/** Validate an optional YYYY-MM-DD "needed by" date; returns null when blank. */
function mr_parse_date($value): ?string
{
    $value = trim((string)($value ?? ''));
    if ($value === '') {
        return null;
    }
    $d = DateTime::createFromFormat('Y-m-d', $value);
    if (!$d || $d->format('Y-m-d') !== $value) {
        json_error('The needed-by date must be a valid date.', 422);
    }
    return $value;
}

/**
 * Insert a material request and its lines. Call inside the caller's
 * transaction so the order and whatever created it commit together.
 *
 * @param array<int,int> $lines category_id => qty_required (non-empty)
 * @return array{0:int, 1:string} [request id, request code]
 */
function mr_create(PDO $pdo, int $clientId, array $lines, ?int $projectId, ?int $jobId, ?string $neededBy, ?string $notes): array
{
    $code = with_unique_code('material_requests', 'request_code', 'MR-' . date('Y') . '-', function (string $code) use ($pdo, $clientId, $projectId, $jobId, $neededBy, $notes) {
        $pdo->prepare(
            'INSERT INTO material_requests (request_code, client_id, project_id, job_id, needed_by, notes, requested_by)
             VALUES (:code, :client, :project, :job, :needed, :notes, :user)'
        )->execute([
            ':code'    => $code,
            ':client'  => $clientId,
            ':project' => $projectId,
            ':job'     => $jobId,
            ':needed'  => $neededBy,
            ':notes'   => $notes !== null && $notes !== '' ? str_cut($notes, 0, 255) : null,
            ':user'    => current_user_id(),
        ]);
        return $code;
    }, pad: 4);

    $requestId = (int)$pdo->lastInsertId();

    $line = $pdo->prepare(
        'INSERT INTO material_request_items (request_id, category_id, qty_required) VALUES (:r, :c, :q)'
    );
    foreach ($lines as $categoryId => $qty) {
        $line->execute([':r' => $requestId, ':c' => $categoryId, ':q' => $qty]);
    }

    return [$requestId, $code];
}

/** "10 Solar Panel, 1 Inverter" — for notification text. */
function mr_lines_summary(array $lines): string
{
    $names = array_flip(mr_category_ids());
    $parts = [];
    foreach ($lines as $categoryId => $qty) {
        $parts[] = $qty . ' ' . ($names[$categoryId] ?? 'item');
    }
    return implode(', ', $parts);
}

/** Lock and return a request row, or fail with 404. */
function mr_lock(PDO $pdo, int $requestId): array
{
    $stmt = $pdo->prepare('SELECT * FROM material_requests WHERE id = :id FOR UPDATE');
    $stmt->execute([':id' => $requestId]);
    $row = $stmt->fetch();
    if (!$row) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        json_error('Material request not found.', 404);
    }
    return $row;
}

/**
 * Recompute PENDING / PREPARING / READY from the item counts. Terminal
 * statuses are left alone. Always touches updated_at so the realtime
 * fingerprint moves even when the status itself did not change.
 *
 * @return string the new status
 */
function mr_recalc(PDO $pdo, array $request): string
{
    if (!in_array($request['status'], MR_OPEN_STATUSES, true)) {
        return $request['status'];
    }

    $stmt = $pdo->prepare(
        'SELECT COALESCE(SUM(qty_required), 0) AS req, COALESCE(SUM(LEAST(qty_prepared, qty_required)), 0) AS prep
         FROM material_request_items WHERE request_id = :id'
    );
    $stmt->execute([':id' => $request['id']]);
    $t = $stmt->fetch();

    $status = 'PENDING';
    if ((int)$t['req'] > 0 && (int)$t['prep'] >= (int)$t['req']) {
        $status = 'READY';
    } elseif ((int)$t['prep'] > 0) {
        $status = 'PREPARING';
    }

    // ready_at records the moment it first became complete; stepping back out
    // of READY (an item unpicked) clears it so the timestamp is never stale.
    $pdo->prepare(
        "UPDATE material_requests
         SET status = :s,
             ready_at = CASE WHEN :s2 = 'READY' THEN COALESCE(ready_at, NOW()) ELSE NULL END,
             updated_at = CURRENT_TIMESTAMP
         WHERE id = :id"
    )->execute([':s' => $status, ':s2' => $status, ':id' => $request['id']]);

    return $status;
}

/** Active users holding any of $roles. */
function mr_user_ids_for_roles(array $roles): array
{
    $in = implode(',', array_fill(0, count($roles), '?'));
    $stmt = db()->prepare(
        "SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id
         WHERE u.status = 'ACTIVE' AND r.role_key IN ($in)"
    );
    $stmt->execute(array_values($roles));
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}

/** Notify every active warehouse user about an order. */
function mr_notify_warehouse(string $message, int $requestId): void
{
    foreach (mr_user_ids_for_roles(['warehouse']) as $uid) {
        notify($uid, 'MATERIAL_REQUEST', $message, 'material_requests', $requestId);
    }
}

/**
 * Notify Management about an order: the person who raised it plus every
 * manager, and the technician who will install it when there is one.
 */
function mr_notify_management(string $message, array $request, bool $includeTechnician = false): void
{
    $recipients = mr_user_ids_for_roles(['manager']);
    if (!empty($request['requested_by'])) {
        $recipients[] = (int)$request['requested_by'];
    }
    if ($includeTechnician) {
        $tech = mr_technician_user_id($request);
        if ($tech) {
            $recipients[] = $tech;
        }
    }
    foreach (array_unique($recipients) as $uid) {
        notify($uid, 'MATERIAL_REQUEST', $message, 'material_requests', (int)$request['id']);
    }
}

/** Whether phase 15 (invoices for released requests) is installed. */
function mr_invoicing_available(): bool
{
    static $ok = null;
    if ($ok === null) {
        try {
            db()->query('SELECT material_request_id FROM invoices LIMIT 0');
            db()->query('SELECT 1 FROM invoice_items LIMIT 0');
            $ok = true;
        } catch (PDOException $e) {
            $ok = false;
        }
    }
    return $ok;
}

/**
 * What a request actually took out of the warehouse, priced: each item's net
 * quantity (scanned out minus put back) × its unit price.
 *   ['items' => [[inventory_id, category, item_name, sku, model, quantity, unit_price, line_total], …], 'total' => float]
 */
function mr_issued_costs(PDO $pdo, int $requestId): array
{
    $stmt = $pdo->prepare(
        "SELECT i.id AS inventory_id, ic.category_name AS category, i.item_name, i.sku, i.model, i.unit_cost,
                SUM(CASE m.movement_type WHEN 'ISSUE' THEN m.quantity ELSE -m.quantity END) AS quantity
         FROM stock_movements m
         JOIN inventory i ON i.id = m.inventory_id
         JOIN inventory_categories ic ON ic.id = i.category_id
         WHERE m.material_request_id = :r AND m.movement_type IN ('ISSUE','RETURN')
         GROUP BY i.id, ic.category_name, i.item_name, i.sku, i.model, i.unit_cost
         HAVING quantity > 0
         ORDER BY ic.id, i.item_name"
    );
    $stmt->execute([':r' => $requestId]);
    $items = [];
    $total = 0.0;
    foreach ($stmt->fetchAll() as $r) {
        $price = round((float)$r['unit_cost'], 2);
        $line = round($price * (int)$r['quantity'], 2);
        $items[] = [
            'inventory_id' => (int)$r['inventory_id'], 'category' => $r['category'], 'item_name' => $r['item_name'],
            'sku' => $r['sku'], 'model' => $r['model'], 'quantity' => (int)$r['quantity'],
            'unit_price' => $price, 'line_total' => $line,
        ];
        $total += $line;
    }
    return ['items' => $items, 'total' => round($total, 2)];
}

/**
 * Bill a released request: one PENDING invoice for the materials issued on it,
 * with its lines frozen in invoice_items. Call inside the release transaction.
 * Does nothing (returns null) when invoicing is not installed, the request was
 * already billed, or nothing was issued. Returns [invoice id, code, amount].
 */
function mr_create_invoice(PDO $pdo, array $request): ?array
{
    if (!mr_invoicing_available()) {
        return null;
    }
    $exists = $pdo->prepare('SELECT id FROM invoices WHERE material_request_id = :r');
    $exists->execute([':r' => $request['id']]);
    if ($exists->fetchColumn()) {
        return null;
    }
    $costs = mr_issued_costs($pdo, (int)$request['id']);
    if (!$costs['items'] || $costs['total'] <= 0) {
        return null;
    }

    $due = date('Y-m-d', strtotime('+' . max(1, setting_int('billing_due_days', 15)) . ' days'));
    $notes = "Materials released from {$request['request_code']}";
    // job_id (phase 18): the job order the released materials were for.
    $withJob = billing_void_ready();
    $ins = $pdo->prepare($withJob
        ? "INSERT INTO invoices (invoice_code, client_id, project_id, job_id, material_request_id, amount, due_date, payment_status, notes)
           VALUES (:code, :c, :p, :j, :r, :a, :d, 'PENDING', :n)"
        : "INSERT INTO invoices (invoice_code, client_id, project_id, material_request_id, amount, due_date, payment_status, notes)
           VALUES (:code, :c, :p, :r, :a, :d, 'PENDING', :n)"
    );
    $code = with_unique_code('invoices', 'invoice_code', 'INV-' . date('Y') . '-', function (string $code) use ($ins, $request, $costs, $due, $notes, $withJob) {
        $ins->execute(array_merge($withJob ? [':j' => $request['job_id'] ?: null] : [], [
            ':code' => $code, ':c' => $request['client_id'], ':p' => $request['project_id'] ?: null,
            ':r' => $request['id'], ':a' => $costs['total'], ':d' => $due, ':n' => $notes,
        ]));
        return $code;
    }, pad: 4);
    $invoiceId = (int)$pdo->lastInsertId();

    $line = $pdo->prepare(
        'INSERT INTO invoice_items (invoice_id, inventory_id, category, description, sku, model, quantity, unit_price, line_total)
         VALUES (:i, :inv, :cat, :d, :sku, :m, :q, :u, :t)'
    );
    foreach ($costs['items'] as $it) {
        $line->execute([
            ':i' => $invoiceId, ':inv' => $it['inventory_id'], ':cat' => $it['category'], ':d' => str_cut($it['item_name'], 0, 200),
            ':sku' => $it['sku'], ':m' => $it['model'], ':q' => $it['quantity'], ':u' => $it['unit_price'], ':t' => $it['line_total'],
        ]);
    }
    return [$invoiceId, $code, $costs['total']];
}

/** The frozen lines of an invoice ([] when it has none, or phase 15 is not installed). */
function invoice_lines(int $invoiceId): array
{
    if (!mr_invoicing_available()) {
        return [];
    }
    $stmt = db()->prepare(
        'SELECT category, description AS item_name, sku, model, quantity, unit_price, line_total
         FROM invoice_items WHERE invoice_id = :i ORDER BY id'
    );
    $stmt->execute([':i' => $invoiceId]);
    return array_map(function ($r) {
        $r['quantity'] = (int)$r['quantity'];
        $r['unit_price'] = (float)$r['unit_price'];
        $r['line_total'] = (float)$r['line_total'];
        return $r;
    }, $stmt->fetchAll());
}

/** users.id of the technician on the order's job (or else its project), if any. */
function mr_technician_user_id(array $request): ?int
{
    $stmt = db()->prepare(
        'SELECT t.user_id FROM technicians t
         WHERE t.id = COALESCE(
             (SELECT j.technician_id FROM jobs j WHERE j.id = :job),
             (SELECT p.assigned_technician_id FROM projects p WHERE p.id = :project)
         )'
    );
    $stmt->execute([':job' => $request['job_id'], ':project' => $request['project_id']]);
    $id = $stmt->fetchColumn();
    return $id ? (int)$id : null;
}

/**
 * Full detail for one order: header, lines, and the net quantity of each
 * inventory item currently scanned out for it (ISSUE minus RETURN).
 */
function mr_detail(PDO $pdo, int $requestId): ?array
{
    $stmt = $pdo->prepare(
        "SELECT mr.*, c.client_code, cu.full_name AS client_name, cu.phone AS client_phone,
                c.address AS client_address, c.city AS client_city, c.province AS client_province,
                c.lat AS client_lat, c.lng AS client_lng,
                p.project_code, p.site_name, j.job_code,
                COALESCE(jtu.full_name, ptu.full_name) AS technician_name,
                ru.full_name AS requested_by_name, rl.full_name AS released_by_name
         FROM material_requests mr
         JOIN clients c   ON c.id = mr.client_id
         JOIN users cu    ON cu.id = c.user_id
         LEFT JOIN projects p     ON p.id = mr.project_id
         LEFT JOIN jobs j         ON j.id = mr.job_id
         LEFT JOIN technicians jt ON jt.id = j.technician_id
         LEFT JOIN users jtu      ON jtu.id = jt.user_id
         LEFT JOIN technicians pt ON pt.id = p.assigned_technician_id
         LEFT JOIN users ptu      ON ptu.id = pt.user_id
         LEFT JOIN users ru       ON ru.id = mr.requested_by
         LEFT JOIN users rl       ON rl.id = mr.released_by
         WHERE mr.id = :id"
    );
    $stmt->execute([':id' => $requestId]);
    $request = $stmt->fetch();
    if (!$request) {
        return null;
    }

    $lines = $pdo->prepare(
        'SELECT mri.category_id, ic.category_name, mri.qty_required, mri.qty_prepared
         FROM material_request_items mri
         JOIN inventory_categories ic ON ic.id = mri.category_id
         WHERE mri.request_id = :id
         ORDER BY ic.id'
    );
    $lines->execute([':id' => $requestId]);

    $picked = $pdo->prepare(
        "SELECT i.id AS inventory_id, i.sku, i.item_name, i.brand, i.model, ic.category_name,
                SUM(CASE sm.movement_type WHEN 'ISSUE' THEN sm.quantity WHEN 'RETURN' THEN -sm.quantity ELSE 0 END) AS quantity,
                MAX(sm.created_at) AS last_scanned_at
         FROM stock_movements sm
         JOIN inventory i ON i.id = sm.inventory_id
         JOIN inventory_categories ic ON ic.id = i.category_id
         WHERE sm.material_request_id = :id
         GROUP BY i.id, i.sku, i.item_name, i.brand, i.model, ic.category_name
         HAVING quantity > 0
         ORDER BY ic.category_name, i.item_name"
    );
    $picked->execute([':id' => $requestId]);

    $history = $pdo->prepare(
        'SELECT sm.movement_code, sm.movement_type, sm.quantity, sm.created_at, i.sku, i.item_name, u.full_name AS recorded_by_name
         FROM stock_movements sm
         JOIN inventory i ON i.id = sm.inventory_id
         LEFT JOIN users u ON u.id = sm.recorded_by
         WHERE sm.material_request_id = :id
         ORDER BY sm.id DESC
         LIMIT 100'
    );
    $history->execute([':id' => $requestId]);

    return [
        'request' => $request,
        'lines'   => $lines->fetchAll(),
        'picked'  => $picked->fetchAll(),
        'history' => $history->fetchAll(),
    ];
}

/**
 * Find a stock item by id, or by a scanned SKU / QR value. Returns the
 * locked row (caller must be in a transaction) or fails with 404.
 */
function mr_lock_inventory(PDO $pdo, ?int $inventoryId, ?string $code): array
{
    if ($inventoryId) {
        $stmt = $pdo->prepare('SELECT * FROM inventory WHERE id = :id FOR UPDATE');
        $stmt->execute([':id' => $inventoryId]);
    } else {
        $stmt = $pdo->prepare('SELECT * FROM inventory WHERE sku = :c1 OR qr_code = :c2 LIMIT 1 FOR UPDATE');
        $stmt->execute([':c1' => $code, ':c2' => $code]);
    }
    $item = $stmt->fetch();
    if (!$item) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        json_error($code !== null ? "No stock item matches code {$code}." : 'Inventory item not found.', 404);
    }
    return $item;
}
