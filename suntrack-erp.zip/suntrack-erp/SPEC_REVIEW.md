# Review of the Warehouse Spec — Checked Against Your Actual Code

I ran every checkable claim in the spec against the real codebase and a live
server. Below is what's already done, what's genuinely missing, and what the
spec gets wrong.

---

## 1. First: no ZIP arrived

The message references `suntrack-erp (2)(2).zip`, but only the spec text came
through. I checked against the Phase 3 codebase from our earlier session.

If your `(2)(2)` version has changes that aren't in Phase 3, re-upload it —
otherwise anything built now risks overwriting them.

---

## 2. Roughly 60% of this spec is already built

This is the single most important finding. The spec reads as though the
warehouse security layer needs writing. It doesn't. I verified these at
runtime, not by reading comments:

| Spec part | Claim | Reality |
|---|---|---|
| **16 — Client protection** | Clients must not touch warehouse | **Already enforced.** `receive` → 403, `movements` → 403 |
| **17 — Technician protection** | Technicians can't mutate stock | **Already enforced.** `receive` → 403 |
| **18 — Admin monitoring** | Admin must be blocked from mutations | **Already enforced.** Admin `receive` → 403 *"This action is managed by the Management team."* Admin `inventory/list` → 200. Exactly what the spec asks for |
| **19 — Security** | Auth, role, CSRF, prepared statements | **Already done.** All 5 stock endpoints carry `require_csrf` and `require_warehouse_write()` |
| **21 — Transaction safety** | `BEGIN`, row lock, commit/rollback | **Already done.** All three of receive/issue/return use `beginTransaction` **and** `SELECT … FOR UPDATE` |
| **14 — Real-time** | Preserve polling | **Already built** in Phase 3 |
| **2 — Categories** | Solar Panel, Inverter, Battery | **Exactly those three**, nothing else |

Warehouse `receive` returns `{"success":true,"message":"Stock received."}` —
the operation works end to end today.

**Implication:** treat Parts 16–21 as *verification* tasks, not build tasks.
Rewriting endpoints that already lock rows correctly is how working concurrency
code gets broken.

---

## 3. What's actually missing — the real scope

Only **three tabs and two APIs**:

| # | Item | Status |
|---|---|---|
| 7 | Warehouse module | Not built — falls through to the shared placeholder |
| 9 | Reports module | Not built |
| 10 | Settings module | Not built |
| 12 | `api/warehouse/reports.php` | Doesn't exist |
| 11 | `api/warehouse/profile.php` | Doesn't exist |
| 13 | `api/warehouse/summary.php` | **Probably unnecessary** — see below |

**Part 13 is likely redundant.** `api/dashboard/warehouse.php` already returns
totals, alerts, and recent activity. The spec itself says don't duplicate it.
Add a `?today=1` parameter to the existing endpoint instead of writing a new
one.

**Part 9 has a shortcut too.** `api/export/csv.php` already exists, so the CSV
requirement is a matter of reusing it, not building export from scratch.

Realistic scope: **3 UI modules + 2 APIs**, not 27 parts of work.

---

## 4. Two real bugs the spec correctly caught

### 4.1 `DISCONTINUED` is silently destroyed (Part 22)

This is the one I'd fix first. Every stock operation recomputes status as:

```php
$status = $newQty == 0 ? 'OUT_OF_STOCK'
        : ($newQty <= $locked['reorder_level'] ? 'LOW_STOCK' : 'ACTIVE');
```

`DISCONTINUED` appears nowhere in any of the five files. So receiving stock
against a discontinued item **silently resurrects it as ACTIVE**, and it
reappears in pickers as though it were current. There is no way to discontinue
an item and have it stay discontinued.

Two further problems in the same line:

- `== 0` should be `<= 0`. With `== 0`, a quantity of `-1` evaluates as
  `LOW_STOCK` rather than `OUT_OF_STOCK`. The row locks make negative stock
  unlikely, but the fallback is wrong.
- The logic is **copy-pasted across 5 files** (`receive`, `issue`, `return`,
  `create`, `update`). Five copies drift. `create.php` already differs from the
  others (`=== 0` with a different variable).

**Fix:** one helper in `includes/helpers.php`, called from all five:

```php
function inventory_status(int $qty, int $reorderLevel, ?string $current = null): string
{
    // An item taken out of service stays out of service. Receiving stock
    // against it must not quietly return it to circulation.
    if ($current === 'DISCONTINUED') return 'DISCONTINUED';
    if ($qty <= 0) return 'OUT_OF_STOCK';
    if ($qty <= $reorderLevel) return 'LOW_STOCK';
    return 'ACTIVE';
}
```

### 4.2 Double-submit protection is thin (Part 20)

Only one `disabled = true` in the whole warehouse UI. A clerk double-tapping
*Receive* on a phone — which is exactly how your warehouse is used — can post
twice. The row lock keeps the database consistent, but you get **two movement
records and double the stock**.

The spec is right that JavaScript alone isn't enough. Cheapest robust fix: a
client-generated idempotency key sent with each mutation, stored on
`stock_movements` with a UNIQUE index. A duplicate submit then collides
harmlessly instead of applying twice.

---

## 5. Where the spec is wrong or risky

### 5.1 Part 27 is cut off

The document ends mid-instruction:

```
### FILE: warehouse/index
```php
COMPLETE CODE
```

The file-format rule is incomplete. More importantly, **"always provide
complete code" is the wrong strategy here.** `warehouse/index.php` is ~600
lines and carries the Phase 3 real-time wiring, mobile assets, consent banner,
and secure-context warnings. Full-file regeneration on every change is how
those get silently dropped. Ask for targeted edits against the existing file.

### 5.2 "Remove the soon badge" needs the right fix

The badge is generated by `render_dark_sidebar()` from the `wired` flag:

```php
['key' => 'warehouse', 'label' => 'Warehouse', 'icon' => 'fa-warehouse'],  // no 'wired'
```

The spec correctly says don't hide it with CSS. The fix is adding
`'wired' => true` **once the module genuinely exists** — and removing the
shared placeholder `<div>` at `warehouse/index.php:145`. Note that div is
shared, so deleting it affects all three tabs at once; all three must land
together or you get a blank panel instead of a placeholder.

### 5.3 Part 10 — password change needs care

The spec says use `password_verify()` and `password_hash()`. Two things it
omits that matter:

- **Regenerate the session ID** after a password change, or an attacker with a
  stolen session keeps it.
- **Rate-limit it.** The current-password field is an oracle. Phase 3 already
  has `login_record_attempt()` / `login_guard_or_fail()` — reuse them rather
  than leaving this endpoint unthrottled.

### 5.4 Part 15 — notifications already have a pattern

Before writing new notification code, check how `issue.php` currently handles
the technician notify step. The spec describes it as new work; it may already
be there.

---

## 6. Suggested order

1. **Fix `inventory_status()`** — one helper, five call sites. Small, and it
   stops `DISCONTINUED` being destroyed. *(§4.1)*
2. **Build the Warehouse module (Part 7)** — mostly a new view over data the
   dashboard API already returns.
3. **Build `api/warehouse/reports.php` + Reports UI (Parts 9, 12)** — reuse
   `api/export/csv.php`.
4. **Build Settings + profile API (Parts 10, 11)** — smallest, but the password
   path needs the care in §5.3.
5. **Flip the three `wired` flags and delete the placeholder div (Part 26)** —
   last, once all three modules genuinely exist.
6. **Add idempotency keys (Part 20)** — separate change, own testing.

Parts 16–21: verify, don't rebuild.

---

## 7. What I'd tell whoever executes this

> Parts 16–21 are already implemented and runtime-verified — treat them as
> acceptance tests, not build tasks. Do not rewrite `api/inventory/*.php`;
> they already use `beginTransaction` with `SELECT … FOR UPDATE`.
>
> Real scope is three UI modules (Warehouse, Reports, Settings) and two APIs
> (`reports.php`, `profile.php`). Skip `summary.php` — extend
> `api/dashboard/warehouse.php` instead.
>
> Fix `inventory_status()` first: `DISCONTINUED` is currently destroyed by any
> stock movement, and the logic is duplicated across five files.
>
> Give targeted edits, not full-file rewrites — `warehouse/index.php` carries
> real-time, mobile, and consent wiring that full regeneration will drop.
