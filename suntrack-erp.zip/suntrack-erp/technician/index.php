<?php
/**
 * SunTrack ERP — Technician / Field Operations portal (Phase 1, complete).
 *
 * Every tab in the sidebar is now backed by a real, ownership-checked API.
 * Authorization is enforced server-side in middleware/technician.php and in
 * includes/technician_lib.php — nothing on this page is trusted by the API.
 */
require_once __DIR__ . '/../middleware/technician.php';
require_once __DIR__ . '/../includes/dark_sidebar.php';

$navItems = [
    ['key' => 'dashboard',    'label' => 'Dashboard',      'icon' => 'fa-gauge-high',        'wired' => true],
    ['key' => 'assignments',  'label' => 'My Assignments', 'icon' => 'fa-list-check',        'wired' => true],
    ['key' => 'service-requests', 'label' => 'Service Requests', 'icon' => 'fa-ticket',      'wired' => true],
    ['key' => 'job-details',  'label' => 'Job Details',    'icon' => 'fa-clipboard',         'wired' => true],
    ['key' => 'site-map',     'label' => 'Site Map',       'icon' => 'fa-map-location-dot',  'wired' => true],
    ['key' => 'installation', 'label' => 'Installation',   'icon' => 'fa-screwdriver-wrench','wired' => true],
    ['key' => 'maintenance',  'label' => 'Maintenance',    'icon' => 'fa-wrench',            'wired' => true],
    ['key' => 'work-reports', 'label' => 'Work Reports',   'icon' => 'fa-file-lines',        'wired' => true],
    ['key' => 'job-history',  'label' => 'Job History',    'icon' => 'fa-clock-rotate-left', 'wired' => true],
    ['key' => 'availability', 'label' => 'Availability',   'icon' => 'fa-toggle-on',         'wired' => true],
    ['key' => 'settings',     'label' => 'Settings',       'icon' => 'fa-gear',              'wired' => true],
];
$token = csrf_token();
// The same portal serves a subcontractor company (subcontractor/index.php, field
// mode): it works the jobs it accepted exactly as a technician does, plus its
// job offers on the dashboard; finished work goes to SunTrack for inspection.
$fieldSub = field_subcontractor();
$portalTitle = $fieldSub ? 'Subcontractor Portal' : 'Field Operations';
if ($fieldSub) {
    $navItems[0]['badge_id'] = 'nav-offers';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>SunTrack ERP — <?= h($portalTitle) ?></title>
<script src="<?= APP_BASE_URL ?>/assets/vendor/tailwind/tailwind.js"></script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/vendor/fontawesome/css/all.min.css">
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-password.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-logout.js"></script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/vendor/leaflet/leaflet.min.css">
<script src="<?= APP_BASE_URL ?>/assets/vendor/leaflet/leaflet.min.js"></script>
<link href="<?= APP_BASE_URL ?>/assets/vendor/inter/inter.css" rel="stylesheet">
<link rel="manifest" href="<?= APP_BASE_URL ?>/manifest.json">
<meta name="theme-color" content="#0b1329">
<link rel="apple-touch-icon" href="<?= APP_BASE_URL ?>/assets/img/app/apple-touch-icon.png">
<script>tailwind.config={theme:{extend:{colors:{suntrackDark:'#0b1329',suntrackNav:'#0f1934',suntrackOrange:'#f97316'},fontFamily:{sans:['Inter','sans-serif']}}}}</script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/css/suntrack-mobile.css">
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-mobile.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-tables.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-paging.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-search.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-pwa.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-signature.js"></script>
<style>
  body{font-family:'Inter',sans-serif;}
  .kpi-card{background:#fff;border-radius:1rem;padding:1.25rem;box-shadow:0 1px 3px rgba(0,0,0,.06);border:1px solid #eef0f4}
  .badge{font-size:11px;font-weight:700;padding:2px 8px;border-radius:999px;display:inline-block;white-space:nowrap}
  .stage-btn{font-size:12.5px;font-weight:700;padding:9px 14px;border-radius:10px;background:#f1f5f9;color:#334155;transition:.15s}
  .stage-btn:hover:not(:disabled){background:#f97316;color:#fff}
  .stage-btn:disabled{opacity:.45;cursor:not-allowed}
  .ghost-btn{font-size:12.5px;font-weight:700;padding:9px 14px;border-radius:10px;border:1px solid #e2e8f0;color:#475569;background:#fff}
  .ghost-btn:hover:not(:disabled){background:#f8fafc}
  .ghost-btn:disabled{opacity:.45;cursor:not-allowed}
  /* Work report: tap-to-choose answers. */
  .js-rt-chip,.js-ri-chip,.js-rd-chip{font-size:13px;font-weight:700;padding:10px 12px;border-radius:12px;border:2px solid #e2e8f0;color:#475569;background:#fff;text-align:center;transition:all .12s}
  .js-rd-chip{padding:8px 12px;font-size:12.5px}
  .js-rt-chip:hover,.js-ri-chip:hover,.js-rd-chip:hover{border-color:#fdba74}
  .chip-on{border-color:#f97316 !important;background:#fff7ed !important;color:#c2410c !important}
  .gps-btn{font-size:13px;font-weight:700;padding:10px 16px;border-radius:10px;transition:.15s}
  .gps-btn-in{background:#dcfce7;color:#15803d}
  .gps-btn-in:hover:not(:disabled){background:#16a34a;color:#fff}
  .gps-btn-out{background:#fee2e2;color:#b91c1c}
  .gps-btn-out:hover:not(:disabled){background:#dc2626;color:#fff}
  .gps-btn:disabled{opacity:.5;cursor:wait}
  .primary-btn{background:#f97316;color:#fff;font-size:13px;font-weight:700;padding:10px 16px;border-radius:10px}
  .primary-btn:hover:not(:disabled){background:#ea580c}
  .primary-btn:disabled{opacity:.5;cursor:wait}
  .field{width:100%;border:1px solid #e2e8f0;border-radius:.6rem;font-size:14px;padding:.55rem .75rem;background:#fff}
  .field:focus{outline:2px solid #fed7aa;border-color:#f97316}
  .lbl{display:block;font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.03em;margin-bottom:.3rem}
  .dl dt{font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.03em}
  .dl dd{font-size:14px;color:#0f172a;font-weight:600;margin-bottom:.75rem;word-break:break-word}
  #tech-map{height:440px;border-radius:1rem;z-index:0}
  .timeline-dot{width:10px;height:10px;border-radius:999px;background:#f97316;flex-shrink:0;margin-top:5px}
  .timeline-line{border-left:2px solid #e2e8f0;margin-left:4px;padding-left:16px}
</style>
</head>
<body class="st-portal bg-slate-50 min-h-screen flex flex-col md:flex-row">

<?php render_dark_sidebar($navItems, 'dashboard', $portalTitle); ?>

<main class="flex-1 p-4 md:p-8 min-w-0">
  <header class="st-page-head flex items-start justify-between gap-4 mb-5 flex-wrap">
    <div>
      <h1 class="text-2xl md:text-3xl font-extrabold text-slate-900">Hi, <?= h($_SESSION['full_name']) ?></h1>
      <p class="text-slate-500 text-sm mt-1" id="page-subtitle"><?= $fieldSub ? h($fieldSub['name'] . ' · ' . $fieldSub['subcon_code'] . ' — jobs SunTrack assigned to your company.') : 'Your live assignments, pulled straight from the database.' ?></p>
    </div>
    <div class="flex items-center gap-2">
      <span id="avail-pill" class="badge bg-slate-100 text-slate-600">—</span>
      <button id="refresh-btn" class="ghost-btn"><i class="fas fa-rotate mr-1"></i>Refresh</button>
    </div>
  </header>

  <div id="gps-strip" class="kpi-card mb-6 flex items-center justify-between gap-4 flex-wrap">
    <div class="flex items-start gap-3 min-w-0">
      <div id="gps-icon" class="h-9 w-9 rounded-xl bg-slate-100 text-slate-400 flex items-center justify-center shrink-0">
        <i class="fas fa-location-crosshairs"></i>
      </div>
      <div class="min-w-0">
        <p class="text-sm font-bold text-slate-900" id="gps-title">Location not shared yet</p>
        <p class="text-xs text-slate-500 mt-0.5" id="gps-detail">Enable GPS to time in, see your distance from site, and use the live map.</p>
      </div>
    </div>
    <button id="gps-enable" class="primary-btn shrink-0"><i class="fas fa-location-dot mr-1"></i>Enable GPS</button>
  </div>

  <section id="tab-dashboard" class="tab-panel space-y-6">
    <?php if ($fieldSub): ?>
    <?php if ($fieldSub['status'] !== 'APPROVED'): ?>
    <div class="kpi-card bg-amber-50 border-amber-200 text-amber-800 text-sm"><i class="fas fa-circle-info mr-1"></i>
      Your company is <b><?= h(strtolower($fieldSub['status'])) ?></b> with SunTrack, so jobs cannot be accepted or updated right now. Please contact SunTrack.</div>
    <?php endif; ?>
    <!-- Job offers from SunTrack (assets: api/subcontractor/dashboard.php, act.php) -->
    <div id="sub-offers-wrap" class="kpi-card hidden" style="border:2px solid #fdba74">
      <div class="flex items-center justify-between mb-3 gap-2 flex-wrap">
        <h3 class="font-bold text-slate-900"><i class="fas fa-bell text-suntrackOrange mr-1"></i>New job offers <span id="sub-offer-count" class="badge bg-orange-100 text-orange-700">0</span></h3>
        <span class="text-xs text-slate-400">Accept to add it to your assignments, or decline so SunTrack can offer it to someone else.</span>
      </div>
      <div id="sub-offers" class="grid lg:grid-cols-2 gap-4"></div>
    </div>
    <?php endif; ?>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
      <div class="kpi-card"><p class="text-xs font-semibold text-slate-500 uppercase">Availability</p><p id="kpi-avail" class="text-2xl font-extrabold text-slate-900 mt-2">—</p></div>
      <div class="kpi-card"><p class="text-xs font-semibold text-slate-500 uppercase">Open Assignments</p><p id="kpi-open" class="text-2xl font-extrabold text-slate-900 mt-2">—</p></div>
      <div class="kpi-card"><p class="text-xs font-semibold text-slate-500 uppercase">Completed Today</p><p id="kpi-today" class="text-2xl font-extrabold text-slate-900 mt-2">—</p></div>
      <div class="kpi-card"><p class="text-xs font-semibold text-slate-500 uppercase">Reports Pending</p><p id="kpi-reports" class="text-2xl font-extrabold text-slate-900 mt-2">—</p></div>
    </div>

    <div class="kpi-card">
      <div class="flex items-center justify-between mb-3 gap-2 flex-wrap">
        <h3 class="font-bold text-slate-900">Active Job</h3>
        <span class="text-xs text-slate-400">Auto-refreshes every 30 seconds</span>
      </div>
      <div id="active-job-card"><p class="text-slate-400 text-sm py-3">Loading...</p></div>
    </div>

    <div class="kpi-card">
      <h3 class="font-bold text-slate-900 mb-1">Today at a glance</h3>
      <p class="text-xs text-slate-400 mb-3">Time In requires GPS and must be within the job's geofence radius. Advancing a stage updates the client and admin dashboards immediately.</p>
      <div id="dash-assignments" class="divide-y divide-slate-100"></div>
    </div>

    <div class="kpi-card">
      <h3 class="font-bold text-slate-900 mb-3">Recently Completed — Work Reports</h3>
      <div id="completed-list" class="divide-y divide-slate-100"></div>
    </div>
  </section>

  <section id="tab-assignments" class="tab-panel hidden space-y-4">
    <div class="kpi-card flex items-center justify-between gap-3 flex-wrap">
      <div>
        <h3 class="font-bold text-slate-900">My Assignments</h3>
        <p class="text-xs text-slate-500 mt-0.5">Stages follow a fixed sequence. Invalid jumps are rejected by the server, not just hidden here.</p>
      </div>
      <div class="text-xs text-slate-500 flex items-center gap-2">
        <span class="badge bg-emerald-100 text-emerald-700">Inside geofence</span>
        <span class="badge bg-red-100 text-red-700">Outside geofence</span>
      </div>
    </div>
    <div id="assignments-list" class="space-y-4"><p class="text-slate-400 text-sm">Loading...</p></div>
  </section>

  <section id="tab-service-requests" class="tab-panel hidden space-y-4">
    <div class="kpi-card flex items-center justify-between gap-3 flex-wrap">
      <div>
        <h3 class="font-bold text-slate-900">My Service Requests</h3>
        <p class="text-xs text-slate-500 mt-0.5">Requests Management assigned to you. Start, pause and complete them with the job buttons — the same GPS Time In, work report and Time Out rules apply.</p>
      </div>
      <div class="flex gap-2">
        <select id="tsr-filter" class="field max-w-[160px]">
          <option value="open">Open</option>
          <option value="">All</option>
          <option value="COMPLETED">Completed</option>
        </select>
        <input id="tsr-search" class="field max-w-xs" placeholder="Search code, client, subject...">
      </div>
    </div>
    <div id="tsr-list" class="space-y-4"><p class="text-slate-400 text-sm">Loading...</p></div>
  </section>

  <section id="tab-job-details" class="tab-panel hidden space-y-4">
    <div class="kpi-card">
      <label class="lbl">Select one of your assigned jobs</label>
      <select id="jd-picker" class="field"></select>
    </div>
    <div id="jd-body"><p class="text-slate-400 text-sm">Pick a job above.</p></div>
  </section>

  <section id="tab-site-map" class="tab-panel hidden space-y-4">
    <div class="kpi-card">
      <div class="flex items-center justify-between gap-3 flex-wrap mb-3">
        <div>
          <h3 class="font-bold text-slate-900">Site Map</h3>
          <p class="text-xs text-slate-500 mt-0.5">OpenStreetMap via Leaflet — no paid map API needed.</p>
        </div>
        <select id="map-picker" class="field max-w-xs"></select>
      </div>
      <div id="map-warning" class="hidden bg-amber-50 border border-amber-200 text-amber-700 text-xs rounded-lg px-3 py-2 mb-3"></div>
      <div id="tech-map"></div>
      <div id="map-legend" class="text-xs text-slate-500 mt-3 flex flex-wrap gap-4"></div>
    </div>
  </section>

  <section id="tab-installation" class="tab-panel hidden space-y-4">
    <div class="kpi-card">
      <label class="lbl">Installation job</label>
      <select id="inst-picker" class="field"></select>
    </div>
    <div id="inst-body"><p class="text-slate-400 text-sm">Select an installation job.</p></div>
  </section>

  <section id="tab-maintenance" class="tab-panel hidden space-y-4">
    <div class="kpi-card">
      <label class="lbl">Maintenance job</label>
      <select id="maint-picker" class="field"></select>
    </div>
    <div id="maint-body"><p class="text-slate-400 text-sm">Select a maintenance job.</p></div>
  </section>

  <section id="tab-work-reports" class="tab-panel hidden space-y-4">
    <div class="kpi-card flex items-center justify-between gap-3 flex-wrap">
      <div>
        <h3 class="font-bold text-slate-900">My Work Reports</h3>
        <p class="text-xs text-slate-500 mt-0.5">Only your own reports are ever returned by the API.</p>
      </div>
      <input id="wr-search" class="field max-w-xs" placeholder="Search report or job code...">
    </div>
    <div id="wr-pending"></div>
    <div id="wr-list" class="space-y-3"><p class="text-slate-400 text-sm">Loading...</p></div>
  </section>

  <section id="tab-job-history" class="tab-panel hidden space-y-4">
    <div class="kpi-card flex items-center justify-between gap-3 flex-wrap">
      <div>
        <h3 class="font-bold text-slate-900">Job History</h3>
        <p class="text-xs text-slate-500 mt-0.5">Completed and cancelled jobs, with the real status timeline from the database.</p>
      </div>
      <div class="flex gap-2">
        <select id="hist-stage" class="field max-w-[160px]">
          <option value="">All</option>
          <option value="COMPLETED">Completed</option>
          <option value="CANCELLED">Cancelled</option>
        </select>
        <input id="hist-search" class="field max-w-xs" placeholder="Search job or client...">
      </div>
    </div>
    <div id="hist-list" class="space-y-3"><p class="text-slate-400 text-sm">Loading...</p></div>
  </section>

  <section id="tab-availability" class="tab-panel hidden space-y-4">
    <div class="kpi-card">
      <h3 class="font-bold text-slate-900 mb-1">My Availability</h3>
      <p class="text-xs text-slate-500 mb-4">This is what dispatch sees when assigning new work. You cannot go off duty while a job is still active in the field.</p>
      <div id="avail-body"><p class="text-slate-400 text-sm">Loading...</p></div>
    </div>
  </section>

  <section id="tab-settings" class="tab-panel hidden space-y-4">
    <div class="kpi-card">
      <h3 class="font-bold text-slate-900 mb-1">Profile</h3>
      <p class="text-xs text-slate-500 mb-4">You can update your own contact details. Your technician code, role and permissions are managed by the office.</p>
      <div id="profile-body"><p class="text-slate-400 text-sm">Loading...</p></div>
    </div>
    <div class="kpi-card">
      <h3 class="font-bold text-slate-900 mb-1">Change Password</h3>
      <p class="text-xs text-slate-500 mb-4">Your current password is always required.</p>
      <div class="grid md:grid-cols-3 gap-3">
        <div><label class="lbl">Current password</label><input id="pw-current" type="password" class="field" autocomplete="current-password"></div>
        <div><label class="lbl">New password</label><input id="pw-new" type="password" class="field" autocomplete="new-password"></div>
        <div><label class="lbl">Confirm new password</label><input id="pw-confirm" type="password" class="field" autocomplete="new-password"></div>
      </div>
      <button id="pw-save" class="primary-btn mt-4">Update Password</button>
    </div>
    <div class="kpi-card" data-push-card></div>
  </section>
</main>

<div id="report-modal" class="hidden fixed inset-0 bg-black/40 flex items-center justify-center z-[1000] p-4">
  <!-- Work report: five plain questions, big tap targets, errors shown at the field. -->
  <div class="bg-white rounded-2xl w-full max-w-md max-h-[90vh] flex flex-col overflow-hidden">
    <div class="px-6 pt-5 pb-3 border-b border-slate-100">
      <div class="flex items-start justify-between gap-3">
        <div>
          <h3 id="report-modal-title" class="font-extrabold text-slate-900">Work Report</h3>
          <p id="report-modal-sub" class="text-xs text-slate-500 mt-0.5">Takes about a minute. Fields marked * are required.</p>
        </div>
        <button type="button" id="report-close" class="text-slate-400 hover:text-slate-600 text-lg leading-none" aria-label="Close"><i class="fas fa-xmark"></i></button>
      </div>
    </div>

    <div class="px-6 py-4 overflow-y-auto space-y-5">
      <div id="report-modal-error" class="hidden bg-red-50 border border-red-200 text-red-600 text-xs rounded-lg px-3 py-2"></div>
      <input type="hidden" id="report-job-id">
      <input type="hidden" id="report-work-type" value="Installation">

      <div>
        <p class="lbl mb-1.5">1. Type of work</p>
        <div id="report-type-chips" class="grid grid-cols-2 gap-2">
          <button type="button" class="js-rt-chip" data-value="Installation"><i class="fas fa-solar-panel mr-1"></i>Installation</button>
          <button type="button" class="js-rt-chip" data-value="Maintenance"><i class="fas fa-wrench mr-1"></i>Maintenance</button>
          <button type="button" class="js-rt-chip" data-value="Repair"><i class="fas fa-screwdriver-wrench mr-1"></i>Repair</button>
          <button type="button" class="js-rt-chip" data-value="Inspection"><i class="fas fa-magnifying-glass mr-1"></i>Inspection</button>
        </div>
      </div>

      <div>
        <label for="report-remarks" class="lbl mb-1.5 block">2. What did you do? *</label>
        <textarea id="report-remarks" rows="3" maxlength="2000" class="field" placeholder="e.g. Installed 12 panels and the inverter, tested the output, walked the client through the app."></textarea>
        <div class="flex justify-between mt-1">
          <p id="report-remarks-err" class="text-[11px] text-red-600 hidden">Please write at least a short sentence (5+ characters).</p>
          <p id="report-remarks-count" class="text-[11px] text-slate-400 ml-auto">0 characters</p>
        </div>
      </div>

      <div>
        <label for="report-materials" class="lbl mb-1.5 block">3. Materials used <span class="font-normal text-slate-400">(optional)</span></label>
        <input id="report-materials" class="field" placeholder="e.g. 12 solar panels, 1 inverter, 2 batteries">
      </div>

      <div>
        <p class="lbl mb-1.5">4. Any problems found?</p>
        <div class="grid grid-cols-2 gap-2">
          <button type="button" class="js-ri-chip" data-value="no"><i class="fas fa-circle-check mr-1"></i>No problems</button>
          <button type="button" class="js-ri-chip" data-value="yes"><i class="fas fa-triangle-exclamation mr-1"></i>Yes, there were</button>
        </div>
        <input id="report-issues" class="field mt-2 hidden" maxlength="500" placeholder="Describe the problem — e.g. cracked tile on the east roof">
        <p id="report-issues-err" class="text-[11px] text-red-600 mt-1 hidden">Describe the problem, or choose "No problems".</p>
      </div>

      <div>
        <p class="lbl mb-1.5">5. How long did it take?</p>
        <div class="flex flex-wrap gap-2">
          <button type="button" class="js-rd-chip" data-value="30 mins">30 mins</button>
          <button type="button" class="js-rd-chip" data-value="1 hour">1 hour</button>
          <button type="button" class="js-rd-chip" data-value="2 hours">2 hours</button>
          <button type="button" class="js-rd-chip" data-value="half day">Half day</button>
          <button type="button" class="js-rd-chip" data-value="1 day">Full day</button>
        </div>
        <input id="report-duration" type="text" maxlength="100" class="field mt-2" placeholder="Or type it — e.g. 2 hours 30 mins">
      </div>
    </div>

    <div class="px-6 py-4 border-t border-slate-100 bg-white flex gap-2">
      <button id="report-cancel" class="ghost-btn flex-1">Cancel</button>
      <button id="report-save" class="primary-btn flex-[2]"><i class="fas fa-paper-plane mr-1"></i>Submit report</button>
    </div>
  </div>
</div>

<div id="confirm-modal" class="hidden fixed inset-0 bg-black/50 flex items-center justify-center z-[1100] p-4">
  <div class="bg-white rounded-2xl p-6 w-full max-w-sm">
    <h3 id="confirm-title" class="font-bold text-slate-900 mb-2">Are you sure?</h3>
    <p id="confirm-message" class="text-sm text-slate-600 mb-5"></p>
    <div class="flex gap-2">
      <button id="confirm-no" class="ghost-btn flex-1">Cancel</button>
      <button id="confirm-yes" class="primary-btn flex-1">Confirm</button>
    </div>
  </div>
</div>

<div id="toast-stack" class="fixed bottom-4 right-4 z-[1200] space-y-2 w-80 max-w-[90vw]"></div>

<script>
const CSRF_TOKEN = <?= json_encode($token) ?>;
const API = '../api/';
// A subcontractor company working through this portal (null for a technician).
const FIELD_SUB = <?= json_encode($fieldSub ? ['name' => $fieldSub['name'], 'code' => $fieldSub['subcon_code'], 'status' => $fieldSub['status']] : null) ?>;

function esc(v) {
  if (v === null || v === undefined) return '';
  return String(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function niceStage(s) { return String(s || '').replace(/_/g, ' '); }
function fmtDate(v) { return v ? String(v).replace('T', ' ').slice(0, 16) : '—'; }
function fmtDuration(mins) {
  if (mins === null || mins === undefined || mins === '') return '—';
  const m = parseInt(mins, 10);
  if (isNaN(m)) return '—';
  const h = Math.floor(m / 60);
  return h > 0 ? `${h}h ${m % 60}m` : `${m}m`;
}

function toast(message, type = 'info') {
  const colors = { success: 'bg-emerald-600', error: 'bg-red-600', info: 'bg-slate-800', warn: 'bg-amber-600' };
  // The same message already on screen is not stacked again.
  const stack = document.getElementById('toast-stack');
  if ([...stack.children].some(c => c.textContent === message && c.style.opacity !== '0')) return;
  const el = document.createElement('div');
  el.className = `${colors[type] || colors.info} text-white text-sm font-semibold rounded-xl px-4 py-3 shadow-lg`;
  el.textContent = message;
  document.getElementById('toast-stack').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .3s'; }, 4200);
  setTimeout(() => el.remove(), 4600);
}

function confirmDialog(title, message, confirmLabel = 'Confirm') {
  return new Promise(resolve => {
    const modal = document.getElementById('confirm-modal');
    document.getElementById('confirm-title').textContent = title;
    document.getElementById('confirm-message').textContent = message;
    const yes = document.getElementById('confirm-yes');
    const no = document.getElementById('confirm-no');
    yes.textContent = confirmLabel;
    modal.classList.remove('hidden');
    function done(result) {
      modal.classList.add('hidden');
      yes.removeEventListener('click', onYes);
      no.removeEventListener('click', onNo);
      resolve(result);
    }
    function onYes() { done(true); }
    function onNo() { done(false); }
    yes.addEventListener('click', onYes);
    no.addEventListener('click', onNo);
  });
}

async function lockBtn(btn, label, fn) {
  if (!btn || btn.disabled) return;
  const original = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = label;
  try { return await fn(); }
  finally { btn.disabled = false; btn.innerHTML = original; }
}

async function apiGet(path, params = {}) {
  const qs = new URLSearchParams(params).toString();
  const res = await stFetch(API + path + (qs ? '?' + qs : ''), { headers: { 'Accept': 'application/json' } }); // follows paged lists
  return await res.json().catch(() => ({ success: false, message: 'Unexpected server response.' }));
}

async function apiPost(path, payload) {
  const res = await fetch(API + path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF_TOKEN },
    body: JSON.stringify({ ...payload, csrf_token: CSRF_TOKEN })
  });
  return await res.json().catch(() => ({ success: false, message: 'Unexpected server response.' }));
}

const state = {
  tab: 'dashboard',
  assignments: [],
  availability: '—',
  position: null,
  gpsError: null,
  selected: { jd: null, inst: null, maint: null, map: null },
  map: null, mapLayers: {}, mapReady: false,
  pollTimer: null, pingTimer: null
};

const STAGE_COLORS = {
  SUBMITTED:'bg-slate-100 text-slate-600', ASSIGNED:'bg-blue-100 text-blue-700',
  EN_ROUTE:'bg-indigo-100 text-indigo-700', ARRIVED:'bg-purple-100 text-purple-700',
  IN_PROGRESS:'bg-amber-100 text-amber-700', PAUSED:'bg-slate-200 text-slate-600',
  COMPLETED:'bg-emerald-100 text-emerald-700', CANCELLED:'bg-red-100 text-red-700'
};
const PRIORITY_COLORS = {
  LOW:'bg-slate-100 text-slate-500', NORMAL:'bg-sky-100 text-sky-700',
  HIGH:'bg-orange-100 text-orange-700', URGENT:'bg-red-100 text-red-700'
};
const STAGE_LABELS = {
  EN_ROUTE:'Start Travel', ARRIVED:'Mark Arrived', IN_PROGRESS:'Start Work',
  PAUSED:'Pause Work', COMPLETED:'Complete Job'
};
// A subcontractor's finished work is inspected by SunTrack before the job closes.
if (FIELD_SUB) STAGE_LABELS.COMPLETED = 'Submit for Inspection';
const ITEM_COLORS = {
  PENDING:'bg-slate-100 text-slate-600', COMPLETED:'bg-emerald-100 text-emerald-700',
  NOT_APPLICABLE:'bg-slate-200 text-slate-500'
};
const FIELD_STAGES = ['EN_ROUTE','ARRIVED','IN_PROGRESS','PAUSED'];

function stageBadge(stage) {
  return `<span class="badge ${STAGE_COLORS[stage] || 'bg-slate-100 text-slate-600'}">${esc(niceStage(stage))}</span>`;
}
function progressBar(pct) {
  const p = Math.max(0, Math.min(100, parseInt(pct, 10) || 0));
  return `<div class="w-full bg-slate-100 rounded-full h-2"><div class="bg-suntrackOrange h-2 rounded-full transition-all" style="width:${p}%"></div></div>`;
}

function gpsSupported() { return 'geolocation' in navigator; }

function getPosition(options = {}) {
  return new Promise((resolve, reject) => {
    if (!gpsSupported()) { reject({ code: 0, message: 'This browser does not support geolocation.' }); return; }
    navigator.geolocation.getCurrentPosition(
      pos => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude, accuracy: Math.round(pos.coords.accuracy || 0), at: new Date() }),
      err => reject(err),
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 5000, ...options }
    );
  });
}

function gpsErrorText(err) {
  // Delegated to the shared mobile helper, which checks for an insecure origin
  // first. Over plain http:// the browser reports PERMISSION_DENIED even when
  // permission was granted, and the old message sent technicians into their
  // browser settings to fix something that was never the problem.
  if (window.SunTrackMobile) return SunTrackMobile.describeGpsError(err);
  if (!err) return 'Unknown GPS error.';
  switch (err.code) {
    case 1: return 'Location permission was denied. Allow location access in your browser settings to time in and use the map.';
    case 2: return 'Your position is unavailable right now. Move to a spot with a clearer sky view and try again.';
    case 3: return 'Getting your location timed out. Try again.';
    default: return err.message || 'Unable to read your location.';
  }
}

function renderGpsStrip() {
  const icon = document.getElementById('gps-icon');
  const title = document.getElementById('gps-title');
  const detail = document.getElementById('gps-detail');
  const btn = document.getElementById('gps-enable');

  if (!gpsSupported()) {
    icon.className = 'h-9 w-9 rounded-xl bg-red-100 text-red-500 flex items-center justify-center shrink-0';
    icon.innerHTML = '<i class="fas fa-triangle-exclamation"></i>';
    title.textContent = 'Geolocation not supported';
    detail.textContent = 'This browser cannot provide GPS. Time In/Out and the live map are unavailable.';
    btn.classList.add('hidden');
    return;
  }
  if (state.position) {
    // A rough fix (indoors / Wi-Fi only) is warned about up front, so the
    // technician steps outside BEFORE tapping Time In rather than after.
    const weak = state.position.accuracy > 150;
    icon.className = 'h-9 w-9 rounded-xl flex items-center justify-center shrink-0 '
      + (weak ? 'bg-amber-100 text-amber-600' : 'bg-emerald-100 text-emerald-600');
    icon.innerHTML = '<i class="fas fa-location-crosshairs"></i>';
    title.textContent = weak ? 'GPS signal weak — step outside for Time In' : 'GPS active';
    detail.textContent = `${state.position.lat.toFixed(5)}, ${state.position.lng.toFixed(5)} · ±${state.position.accuracy} m · updated ${state.position.at.toLocaleTimeString()}`;
    btn.innerHTML = '<i class="fas fa-rotate mr-1"></i>Update Location';
    btn.classList.remove('hidden');
    return;
  }
  if (state.gpsError) {
    icon.className = 'h-9 w-9 rounded-xl bg-red-100 text-red-500 flex items-center justify-center shrink-0';
    icon.innerHTML = '<i class="fas fa-location-dot"></i>';
    title.textContent = 'GPS unavailable';
    detail.textContent = gpsErrorText(state.gpsError);
  } else {
    icon.className = 'h-9 w-9 rounded-xl bg-slate-100 text-slate-400 flex items-center justify-center shrink-0';
    icon.innerHTML = '<i class="fas fa-location-crosshairs"></i>';
    title.textContent = 'Location not shared yet';
    detail.textContent = 'Enable GPS to time in, see your distance from site, and use the live map.';
  }
  btn.innerHTML = '<i class="fas fa-location-dot mr-1"></i>Enable GPS';
  btn.classList.remove('hidden');
}

async function refreshPosition(silent = false) {
  try {
    state.position = await getPosition();
    state.gpsError = null;
    renderGpsStrip();
    return state.position;
  } catch (err) {
    state.gpsError = err;
    state.position = null;
    renderGpsStrip();
    if (!silent) toast(gpsErrorText(err), 'error');
    return null;
  }
}

document.getElementById('gps-enable').addEventListener('click', async (e) => {
  await lockBtn(e.currentTarget, 'Locating...', async () => {
    const pos = await refreshPosition();
    if (pos) {
      await loadAssignments();
      if (state.tab === 'site-map') refreshMap();
      toast('Location updated.', 'success');
    }
  });
});

const TAB_LOADERS = {
  'dashboard':    () => loadAssignments(),
  'assignments':  () => loadAssignments(),
  'service-requests': () => loadAssignments().then(loadTechServiceRequests),
  'job-details':  () => { syncPickers(); return loadJobDetails(); },
  'site-map':     () => { syncPickers(); return refreshMap(); },
  'installation': () => { syncPickers(); return loadInstallation(); },
  'maintenance':  () => { syncPickers(); return loadMaintenance(); },
  'work-reports': () => loadWorkReports(),
  'job-history':  () => loadHistory(),
  'availability': () => loadAvailability(),
  'settings':     () => loadProfile()
};
const SUBTITLES = {
  'dashboard':'Your live assignments, pulled straight from the database.',
  'assignments':'Advance each job through its controlled stage sequence.',
  'service-requests':'Client requests assigned to you — details, location, notes and resolution.',
  'job-details':'Everything recorded against one of your assigned jobs.',
  'site-map':'Your position, your job site, and the geofence around it.',
  'installation':'One stage per visit: do today\'s stage, add photos, submit it for review.',
  'maintenance':'Inspect panels, battery and inverter, and record findings.',
  'work-reports':'Your submitted reports and the jobs still awaiting one.',
  'job-history':'Completed and cancelled work, with real status timelines.',
  'availability':'Tell dispatch whether you can take new work.',
  'settings':'Your contact details and password.'
};

function showTab(key) {
  state.tab = key;
  document.querySelectorAll('.tab-link').forEach(l => {
    const active = l.dataset.tab === key;
    l.classList.toggle('bg-suntrackOrange', active);
    l.classList.toggle('text-white', active);
    l.classList.toggle('shadow-md', active);
    l.classList.toggle('shadow-orange-600/20', active);
    l.classList.toggle('text-slate-300', !active);
  });
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.add('hidden'));
  const panel = document.getElementById('tab-' + key);
  if (panel) panel.classList.remove('hidden');
  document.getElementById('page-subtitle').textContent = SUBTITLES[key] || '';
  // Location only matters where jobs are worked; elsewhere the GPS card is noise.
  document.getElementById('gps-strip').classList.toggle('hidden', ['work-reports', 'job-history', 'availability', 'settings'].includes(key));
  window.scrollTo(0, 0);
  const loader = TAB_LOADERS[key];
  if (loader) loader();
}

document.querySelectorAll('.tab-link').forEach(link => {
  link.addEventListener('click', e => { e.preventDefault(); showTab(link.dataset.tab); });
});
document.getElementById('refresh-btn').addEventListener('click', e => {
  lockBtn(e.currentTarget, '<i class="fas fa-rotate fa-spin mr-1"></i>Refresh', async () => {
    await loadAssignments();
    const loader = TAB_LOADERS[state.tab];
    if (loader && state.tab !== 'dashboard' && state.tab !== 'assignments') await loader();
    toast('Refreshed from the database.', 'success');
  });
});

async function loadAssignments() {
  const params = {};
  if (state.position) { params.lat = state.position.lat; params.lng = state.position.lng; }

  const json = await apiGet('technician/assignments.php', params);
  if (!json.success) {
    document.getElementById('dash-assignments').innerHTML = `<p class="text-red-500 text-sm py-4">${esc(json.message)}</p>`;
    document.getElementById('assignments-list').innerHTML = `<p class="text-red-500 text-sm py-4">${esc(json.message)}</p>`;
    return;
  }
  const d = json.data;
  // Work that can be done today comes first; installations waiting for review or a later date go last.
  const rank = j => !j.plan ? 1 : (j.plan.workable || j.plan.all_approved) ? 0 : 2;
  state.assignments = d.assignments.map((j, i) => ({ j, i })).sort((a, b) => rank(a.j) - rank(b.j) || a.i - b.i).map(x => x.j);
  state.availability = d.availability;

  document.getElementById('kpi-avail').textContent = niceStage(d.availability);
  document.getElementById('kpi-open').textContent = d.open_count;
  document.getElementById('kpi-today').textContent = d.completed_today;
  document.getElementById('kpi-reports').textContent = d.pending_reports;
  const pill = document.getElementById('avail-pill');
  pill.textContent = niceStage(d.availability);
  pill.className = 'badge ' + (d.availability === 'AVAILABLE' ? 'bg-emerald-100 text-emerald-700'
    : d.availability === 'BUSY' ? 'bg-amber-100 text-amber-700' : 'bg-slate-200 text-slate-600');

  renderActiveJob();
  renderAssignments();
  renderCompleted(d.recent_completed);
  if (FIELD_SUB) loadOffers();
  syncPickers();
  scheduleGeofencePing();
}

function activeJob() {
  return state.assignments.find(j => FIELD_STAGES.includes(j.stage)) || null;
}

function geofenceChip(j) {
  if (!j.has_coordinates) return '<span class="badge bg-slate-100 text-slate-500">No site coordinates</span>';
  if (j.distance_m === null) return '<span class="badge bg-slate-100 text-slate-500">GPS off</span>';
  const cls = j.inside_geofence ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700';
  const word = j.inside_geofence ? 'Inside' : 'Outside';
  return `<span class="badge ${cls}">${word} · ${j.distance_m} m / ${j.geofence_radius_m} m</span>`;
}

function jobActionsHtml(j) {
  const buttons = [];
  (j.allowed_next || []).forEach(s => {
    buttons.push(`<button class="stage-btn js-stage" data-job="${j.id}" data-stage="${s}">${STAGE_LABELS[s] || niceStage(s)}</button>`);
  });
  if (j.timed_in) {
    buttons.push(`<button class="gps-btn gps-btn-out js-gps" data-job="${j.id}" data-mode="out">Time Out</button>`);
  } else {
    buttons.push(`<button class="gps-btn gps-btn-in js-gps" data-job="${j.id}" data-mode="in">Time In</button>`);
  }
  // The work report is filed during the job, before Completed. A staged
  // installation files it at the end, once Management has approved every stage.
  const reportDue = !(j.plan && !j.plan.all_approved) && j.is_lead !== false; // the lead files it
  if (['IN_PROGRESS', 'PAUSED'].includes(j.stage) && reportDue) {
    if (j.report_code) {
      buttons.push(`<span class="badge bg-emerald-100 text-emerald-700"><i class="fas fa-check mr-1"></i>Report ${esc(j.report_code)}</span>`);
    } else {
      buttons.push(`<button class="stage-btn js-report" data-job="${j.id}" data-code="${esc(j.job_code)}" data-type="${esc(j.job_type)}">Work Report</button>`);
    }
  }
  if (j.is_lead !== false) {
    buttons.push(`<button class="ghost-btn js-undo" data-job="${j.id}" title="Undo the last stage change"><i class="fas fa-rotate-left"></i></button>`);
  }
  buttons.push(`<button class="ghost-btn js-open-details" data-job="${j.id}">Details</button>`);
  // Service request jobs: the type's checklist, in a pop-up (submitted for Management approval).
  if (j.sr_checklist) {
    const cl = j.sr_checklist;
    buttons.push(`<button class="primary-btn js-open-srcl" data-job="${j.id}"><i class="fas fa-list-check mr-1"></i>Open Checklist`
      + (cl.status === 'SUBMITTED' ? ' · in review' : cl.status === 'RETURNED' ? ' · returned' : cl.status === 'APPROVED' ? ' · approved' : (cl.progress ? ` · ${cl.progress}%` : '')) + '</button>');
  }
  if (j.job_type === 'INSTALLATION') {
    buttons.push(j.plan && j.plan.workable
      ? `<button class="primary-btn js-open-inst" data-job="${j.id}"><i class="fas fa-list-check mr-1"></i>Open today's checklist</button>`
      : `<button class="ghost-btn js-open-inst" data-job="${j.id}">Checklist</button>`);
  }
  if (j.job_type === 'MAINTENANCE') {
    buttons.push(`<button class="ghost-btn js-open-maint" data-job="${j.id}">Inspection</button>`);
  }
  return buttons.join(' ');
}

// A staged installation's state in one plain sentence, coloured by what the technician should do.
function planBanner(j) {
  const p = j.plan;
  if (!p) return '';
  const look = p.all_approved ? ['bg-emerald-50 border-emerald-200 text-emerald-800', 'fa-circle-check']
    : p.workable ? (p.status === 'RETURNED' ? ['bg-red-50 border-red-200 text-red-800', 'fa-rotate-left'] : ['bg-orange-50 border-orange-200 text-orange-800', 'fa-calendar-day'])
    : p.status === 'SUBMITTED' ? ['bg-sky-50 border-sky-200 text-sky-800', 'fa-hourglass-half']
    : ['bg-slate-50 border-slate-200 text-slate-600', 'fa-calendar'];
  const lead = p.all_approved ? 'Ready to complete' : p.workable ? (p.status === 'RETURNED' ? 'Fix and resubmit' : 'Today') : p.status === 'SUBMITTED' ? 'In review' : 'Next';
  return `<div class="mb-3 flex flex-wrap items-center gap-x-2 gap-y-1 rounded-xl border px-3 py-2 text-sm ${look[0]}">
    <i class="fas ${look[1]}"></i><span class="flex-1 min-w-0"><b>${lead}:</b> ${esc(p.label)}</span>
    <span class="ml-auto text-xs opacity-70 whitespace-nowrap">${p.approved}/${p.total} stages approved</span></div>`;
}

// Who else is on this installation, and who leads it.
function crewLine(j) {
  const crew = j.crew || [];
  if (crew.length < 2) return '';
  const lead = crew.find(m => m.is_lead) || crew[0];
  const others = crew.filter(m => m !== lead);
  return `<div class="mb-3 flex flex-wrap items-center gap-1.5 text-xs">
    <span class="font-semibold text-slate-500"><i class="fas fa-users mr-1"></i>Crew of ${crew.length}:</span>
    <span class="badge bg-orange-100 text-orange-700">${esc(lead.name)} · lead${j.is_lead ? ' (you)' : ''}</span>
    ${others.map(m => `<span class="badge bg-slate-100 text-slate-600">${esc(m.name)}</span>`).join('')}
    ${j.is_lead ? '' : '<span class="text-slate-400">— you help on site; the lead moves the job forward.</span>'}
  </div>`;
}

function assignmentCard(j) {
  return `
  <div class="kpi-card" id="job-card-${j.id}">
    <div class="flex items-start justify-between gap-3 flex-wrap mb-3">
      <div class="min-w-0">
        <p class="font-extrabold text-slate-900">${esc(j.job_code)}
          <span class="text-slate-400 font-normal text-sm">— ${esc(j.job_type)}</span></p>
        <p class="text-sm text-slate-600 mt-0.5">${esc(j.client_name)} <span class="text-slate-400">(${esc(j.client_code)})</span></p>
        <p class="text-xs text-slate-500 mt-0.5"><i class="fas fa-location-dot mr-1"></i>${esc(j.site_address || 'No address recorded')}</p>
      </div>
      <div class="flex items-center gap-2 flex-wrap justify-end">
        ${stageBadge(j.stage)}
        <span class="badge ${PRIORITY_COLORS[j.priority] || 'bg-slate-100 text-slate-500'}">${esc(j.priority)}</span>
      </div>
    </div>
    ${planBanner(j)}
    ${subcontractBanner(j)}
    ${crewLine(j)}

    <div class="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs mb-3">
      <div><p class="text-slate-400 font-semibold uppercase">Scheduled</p><p class="text-slate-800 font-semibold">${esc(j.scheduled_date || '—')}</p></div>
      <div><p class="text-slate-400 font-semibold uppercase">Geofence</p><p class="text-slate-800 font-semibold">${j.geofence_radius_m} m</p></div>
      <div><p class="text-slate-400 font-semibold uppercase">Time In</p><p class="text-slate-800 font-semibold">${esc(fmtDate(j.time_in))}</p></div>
      <div><p class="text-slate-400 font-semibold uppercase">Time Out</p><p class="text-slate-800 font-semibold">${esc(fmtDate(j.time_out))}</p></div>
    </div>

    <div class="mb-3">
      <div class="flex items-center justify-between text-xs mb-1">
        <span class="text-slate-500 font-semibold">Progress</span>
        <span class="text-slate-800 font-bold">${j.progress}%${j.checklist_total ? ` · checklist ${j.checklist_total - j.checklist_pending}/${j.checklist_total}` : ''}</span>
      </div>
      ${progressBar(j.progress)}
    </div>

    <div class="flex items-center gap-2 flex-wrap mb-3">
      ${geofenceChip(j)}
      ${j.timed_in ? '<span class="badge bg-emerald-100 text-emerald-700"><i class="fas fa-clock mr-1"></i>Timed in</span>' : ''}
    </div>

    <p class="text-xs mb-2 js-feedback" id="feedback-${j.id}"></p>

    <div class="job-actions flex items-center gap-2 flex-wrap">${jobActionsHtml(j)}</div>
  </div>`;
}

function renderAssignments() {
  const list = document.getElementById('assignments-list');
  list.innerHTML = state.assignments.length
    ? state.assignments.map(assignmentCard).join('')
    : '<div class="kpi-card text-slate-400 text-sm">No open assignments right now.</div>';
  bindJobActions(list);

  const dash = document.getElementById('dash-assignments');
  dash.innerHTML = state.assignments.length
    ? state.assignments.map(j => `
      <div class="py-3 flex items-center justify-between gap-3 flex-wrap">
        <div class="min-w-0">
          <p class="font-semibold text-slate-900 text-sm">${esc(j.job_code)} <span class="text-slate-400 font-normal">— ${esc(j.job_type)}</span></p>
          <p class="text-xs text-slate-500">${esc(j.client_name)} · ${esc(j.site_address || '')}</p>
        </div>
        <div class="glance-meta flex items-center gap-2 flex-wrap justify-end">
          ${geofenceChip(j)}${stageBadge(j.stage)}
          <button class="ghost-btn js-open-details" data-job="${j.id}">Open</button>
        </div>
      </div>`).join('')
    : '<p class="text-slate-400 text-sm py-4">No open assignments right now.</p>';
  bindJobActions(dash);
}

// Subcontractor: the company's assignment on this job — what SunTrack agreed,
// the deadline, and where the inspection stands.
function subcontractBanner(j) {
  const s = j.subcontract;
  if (!s) return '';
  const look = s.status === 'AWAITING_INSPECTION' ? ['bg-violet-50 border-violet-200 text-violet-800', 'fa-magnifying-glass', 'SunTrack is inspecting your work — you will be notified of the result.']
    : s.status === 'REVISION_REQUIRED' ? ['bg-orange-50 border-orange-200 text-orange-800', 'fa-rotate-left', 'Corrections requested: ' + (s.review_note || '') + ' — fix them, then Submit for Inspection again.']
    : ['bg-slate-50 border-slate-200 text-slate-700', 'fa-file-signature', 'Finish the work, file the work report and Time Out, then Submit for Inspection.'];
  return `<div class="mb-3 rounded-xl border px-3 py-2 text-sm ${look[0]}">
    <div class="flex items-center gap-2 flex-wrap"><i class="fas ${look[1]}"></i><b>${esc(s.assignment_code)} · ${esc(s.status_label)}</b>
      <span class="ml-auto text-xs opacity-80 whitespace-nowrap">${s.expected_completion ? 'Due ' + esc(s.expected_completion) : ''}${s.contract_amount ? ' · ₱' + Number(s.contract_amount).toLocaleString('en-PH', { minimumFractionDigits: 2 }) : ''}</span></div>
    <p class="text-xs mt-1">${esc(look[2])}</p>
    <details class="mt-1 text-xs"><summary class="cursor-pointer font-semibold">Scope from SunTrack</summary>
      <p class="whitespace-pre-line mt-1">${esc(s.scope)}</p>
      ${s.instructions ? `<p class="whitespace-pre-line mt-1"><b>Instructions:</b> ${esc(s.instructions)}</p>` : ''}
      ${s.materials_note ? `<p class="mt-1"><b>Materials:</b> ${esc(s.materials_note)}</p>` : ''}</details>
  </div>`;
}

// ---- Subcontractor job offers (accept / decline before they run out) ----
function offerLeft(sec) {
  if (sec <= 0) return 'Expired';
  const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60);
  return h ? `${h}h ${m}m left to answer` : `${m}m ${sec % 60}s left to answer`;
}
async function loadOffers() {
  const json = await apiGet('subcontractor/dashboard.php');
  const wrap = document.getElementById('sub-offers-wrap');
  if (!json.success || !wrap) return;
  const offers = json.data.offers || [], can = json.data.can_act;
  wrap.classList.toggle('hidden', !offers.length);
  document.getElementById('sub-offer-count').textContent = offers.length;
  const nav = document.getElementById('nav-offers');
  if (nav) { nav.textContent = offers.length; nav.classList.toggle('hidden', !offers.length); }
  document.getElementById('sub-offers').innerHTML = offers.map(o => `
    <div class="rounded-2xl border border-orange-200 bg-orange-50/40 p-4">
      <div class="flex items-start justify-between gap-2"><div>
        <p class="text-[11px] font-bold uppercase text-orange-600">New assignment for your company</p>
        <p class="font-extrabold text-slate-900">${esc(o.job_code)} <span class="text-slate-400 font-normal text-sm">— ${esc(o.job_type)}</span></p></div>
        <span class="badge ${PRIORITY_COLORS[o.priority] || 'bg-slate-100 text-slate-500'}">${esc(o.priority)}</span></div>
      <p class="text-sm text-slate-600 mt-1">${esc(o.client_name)}</p>
      <p class="text-xs text-slate-500"><i class="fas fa-location-dot mr-1"></i>${esc(o.site_address || o.city || 'No address recorded')}</p>
      <p class="text-xs text-slate-500 mt-1">${[o.scheduled_date ? 'Scheduled ' + esc(o.scheduled_date) : '', o.expected_completion ? 'Finish by ' + esc(o.expected_completion) : '', Number(o.contract_amount) ? '₱' + Number(o.contract_amount).toLocaleString('en-PH', { minimumFractionDigits: 2 }) : ''].filter(Boolean).join(' · ')}</p>
      <p class="text-sm text-slate-700 mt-2 whitespace-pre-line">${esc(o.scope)}</p>
      ${o.seconds_left === null ? '' : `<p class="text-xs font-bold text-amber-700 mt-2"><i class="fas fa-hourglass-half mr-1"></i><span data-deadline="${Date.now() + o.seconds_left * 1000}">${offerLeft(o.seconds_left)}</span></p>`}
      <div class="flex gap-2 mt-3">
        <button class="ghost-btn flex-1 js-offer" data-id="${o.id}" data-act="decline" ${can ? '' : 'disabled'}>Decline</button>
        <button class="primary-btn flex-1 js-offer" data-id="${o.id}" data-act="accept" ${can ? '' : 'disabled'}><i class="fas fa-check mr-1"></i>Accept</button>
      </div>
    </div>`).join('');
  document.querySelectorAll('.js-offer').forEach(b => b.addEventListener('click', () => answerOffer(b)));
}
async function answerOffer(btn) {
  const body = { assignment_id: +btn.dataset.id, action: btn.dataset.act };
  if (body.action === 'decline') {
    const r = prompt('Why are you declining this job? SunTrack will offer it to another subcontractor.');
    if (r === null) return;
    if (r.trim().length < 5) { toast('Please give a short reason (at least 5 characters).', 'warn'); return; }
    body.reason = r.trim();
  }
  await lockBtn(btn, '<i class="fas fa-circle-notch fa-spin"></i>', async () => {
    const json = await apiPost('subcontractor/act.php', body);
    toast(json.message, json.success ? 'success' : 'error');
    if (json.success) await loadAssignments();
  });
}
setInterval(() => {
  document.querySelectorAll('[data-deadline]').forEach(el => {
    const sec = Math.max(0, Math.round((+el.dataset.deadline - Date.now()) / 1000));
    el.textContent = offerLeft(sec);
  });
}, 1000);

function renderActiveJob() {
  const box = document.getElementById('active-job-card');
  const j = activeJob();
  if (!j) {
    box.innerHTML = '<p class="text-slate-400 text-sm py-3">No job is active in the field. Start travel on an assignment to begin tracking.</p>';
    return;
  }
  box.innerHTML = assignmentCard(j);
  bindJobActions(box);
}

function renderCompleted(rows) {
  const box = document.getElementById('completed-list');
  box.innerHTML = rows.length
    ? rows.map(j => `
      <div class="py-3 flex items-center justify-between gap-3 flex-wrap">
        <div class="min-w-0">
          <p class="font-semibold text-slate-900 text-sm">${esc(j.job_code)} <span class="text-slate-400 font-normal">— ${esc(j.job_type)}</span></p>
          <p class="text-xs text-slate-500">${esc(j.client_name)} · completed ${esc(fmtDate(j.updated_at))}</p>
        </div>
        <div class="flex items-center gap-2 flex-wrap justify-end">
          ${j.existing_report_id
            ? `<span class="badge bg-emerald-100 text-emerald-700">${esc(j.report_code)}</span>`
            : `<button class="stage-btn js-report" data-job="${j.id}" data-code="${esc(j.job_code)}" data-type="${esc(j.job_type)}">Submit Report</button>`}
          ${j.confirmed
            ? '<span class="badge bg-emerald-100 text-emerald-700"><i class="fas fa-signature mr-1"></i>Signed</span>'
            : `<button class="ghost-btn js-sign" data-job="${j.id}" data-code="${esc(j.job_code)}" data-client="${esc(j.client_name)}"><i class="fas fa-signature mr-1"></i>Client sign-off</button>`}
        </div>
      </div>`).join('')
    : '<p class="text-slate-400 text-sm py-4">No completed jobs yet.</p>';
  bindJobActions(box);
  // On site: hand the phone to the client to sign.
  box.querySelectorAll('.js-sign').forEach(b => b.addEventListener('click', () => SunTrackSignature.open({
    title: 'Client sign-off — ' + b.dataset.code,
    name: b.dataset.client,
    onSubmit: async (d) => {
      const json = await apiPost('confirmations/create.php', { ...d, job_id: +b.dataset.job });
      if (json.success) { toast(json.message, 'success'); loadAssignments(); }
      return json;
    }
  })));
}

function bindJobActions(scope) {
  scope.querySelectorAll('.js-stage').forEach(btn => {
    btn.addEventListener('click', () => changeStage(btn, +btn.dataset.job, btn.dataset.stage));
  });
  scope.querySelectorAll('.js-gps').forEach(btn => {
    btn.addEventListener('click', () => handleGps(btn, +btn.dataset.job, btn.dataset.mode));
  });
  scope.querySelectorAll('.js-undo').forEach(btn => {
    btn.addEventListener('click', () => undoStage(btn, +btn.dataset.job));
  });
  scope.querySelectorAll('.js-open-details').forEach(btn => {
    btn.addEventListener('click', () => { state.selected.jd = +btn.dataset.job; showTab('job-details'); });
  });
  scope.querySelectorAll('.js-open-inst').forEach(btn => {
    btn.addEventListener('click', () => { state.selected.inst = +btn.dataset.job; showTab('installation'); });
  });
  scope.querySelectorAll('.js-open-maint').forEach(btn => {
    btn.addEventListener('click', () => { state.selected.maint = +btn.dataset.job; showTab('maintenance'); });
  });
  scope.querySelectorAll('.js-open-srcl').forEach(btn => {
    btn.addEventListener('click', () => openSrChecklist(+btn.dataset.job));
  });
  scope.querySelectorAll('.js-report').forEach(btn => {
    btn.addEventListener('click', () => openReportModal(btn.dataset.job, btn.dataset.code, btn.dataset.type));
  });
}

// ---- Service request checklist (pop-up) ------------------------------------------
// Each service type (except Maintenance) has 2–3 steps; every item is ticked
// (who / when recorded) and every step needs a proof photo. Submitted to
// Management, who approves it to complete the request, or returns it.
let SRCL_JOB = null, srclBusy = false;
function srclModal() {
  let m = document.getElementById('srcl-modal');
  if (!m) {
    m = document.createElement('div');
    m.id = 'srcl-modal';
    m.className = 'fixed inset-0 z-[60] hidden items-end sm:items-center justify-center bg-slate-900/50 p-0 sm:p-4';
    m.innerHTML = '<div class="bg-slate-50 w-full sm:max-w-2xl max-h-[94vh] overflow-y-auto rounded-t-2xl sm:rounded-2xl shadow-2xl">'
      + '<div class="sticky top-0 z-10 bg-white border-b border-slate-100 px-4 py-3 flex items-center justify-between gap-3">'
      + '<div class="min-w-0"><p id="srcl-title" class="font-extrabold text-slate-900 truncate">Checklist</p><p id="srcl-sub" class="text-xs text-slate-500 truncate"></p></div>'
      + '<button type="button" id="srcl-close" class="ghost-btn !px-3" aria-label="Close"><i class="fas fa-xmark"></i></button></div>'
      + '<div id="srcl-body" class="p-4"></div></div>';
    document.body.appendChild(m);
    m.addEventListener('click', e => { if (e.target === m) closeSrChecklist(); });
    m.querySelector('#srcl-close').addEventListener('click', closeSrChecklist);
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && !m.classList.contains('hidden')) closeSrChecklist(); });
  }
  return m;
}
function closeSrChecklist() {
  const m = document.getElementById('srcl-modal');
  if (m) { m.classList.add('hidden'); m.classList.remove('flex'); }
  SRCL_JOB = null;
  document.body.style.overflow = '';
  loadAssignments();
}
async function openSrChecklist(jobId) {
  SRCL_JOB = jobId;
  const m = srclModal();
  m.classList.remove('hidden'); m.classList.add('flex');
  document.body.style.overflow = 'hidden';
  document.getElementById('srcl-body').innerHTML = '<p class="text-sm text-slate-400 py-6 text-center"><i class="fas fa-spinner fa-spin mr-1"></i>Loading checklist...</p>';
  await renderSrChecklist();
}
async function renderSrChecklist() {
  const jobId = SRCL_JOB;
  if (!jobId) return;
  const body = document.getElementById('srcl-body');
  const scrollTop = body.parentElement.scrollTop;
  const json = await apiGet('sr_checklist/get.php', { job_id: jobId });
  if (jobId !== SRCL_JOB) return;
  if (!json.success) { body.innerHTML = `<p class="text-sm text-red-600">${esc(json.message)}</p>`; return; }
  const d = json.data, cl = d.checklist, j = d.job;
  const canWork = d.editable && !cl.locked;
  document.getElementById('srcl-title').textContent = `${cl.request_type} checklist`;
  document.getElementById('srcl-sub').textContent = `${j.job_code}${cl.service_request ? ' · ' + cl.service_request.request_code : ''} · ${j.client_name || ''}`;
  const itemsBy = {}, photosBy = {};
  cl.items.forEach(i => (itemsBy[i.step] = itemsBy[i.step] || []).push(i));
  cl.photos.forEach(p => (photosBy[p.step] = photosBy[p.step] || []).push(p));
  const resolved = cl.steps.reduce((n, s) => n + s.resolved, 0), total = cl.steps.reduce((n, s) => n + s.total, 0);
  const withPhoto = cl.steps.filter(s => s.photos > 0).length;
  const niceWhen = v => v ? new Date(String(v).replace(' ', 'T')).toLocaleString('en-PH', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : '';
  const stepLine = (n, text, ok) => `<li class="flex items-center gap-2 text-sm ${ok ? 'text-emerald-700' : 'text-slate-700'}">
      <span class="w-6 h-6 shrink-0 rounded-full flex items-center justify-center text-xs font-extrabold ${ok ? 'bg-emerald-500 text-white' : 'bg-slate-200 text-slate-600'}">${ok ? '<i class="fas fa-check"></i>' : n}</span><span class="min-w-0">${text}</span></li>`;

  // ---- State card -----------------------------------------------------------------
  let hero;
  if (cl.status === 'APPROVED') {
    hero = `<div class="kpi-card mb-3 border-2 border-emerald-200 bg-emerald-50/50">
      <p class="text-xs font-bold uppercase text-emerald-700 mb-1"><i class="fas fa-circle-check mr-1"></i>Approved${cl.reviewed_by_name ? ' by ' + esc(cl.reviewed_by_name) : ''}</p>
      <p class="font-extrabold text-slate-900">This request is completed.</p>
      ${cl.review_note ? `<p class="text-sm text-slate-600 mt-1">${esc(cl.review_note)}</p>` : ''}</div>`;
  } else if (cl.status === 'SUBMITTED') {
    hero = `<div class="kpi-card mb-3 border-2 border-sky-200 bg-sky-50/40">
      <p class="text-xs font-bold uppercase text-sky-700 mb-1"><i class="fas fa-hourglass-half mr-1"></i>Waiting for Management approval</p>
      <p class="font-extrabold text-slate-900">Submitted${cl.submitted_at ? ' ' + esc(niceWhen(cl.submitted_at)) : ''}</p>
      <p class="text-sm text-slate-600 mt-1">You will be notified when it is approved (the request is then completed) or returned.</p></div>`;
  } else {
    const returned = cl.status === 'RETURNED';
    const ready = !cl.submit_blocker;
    hero = `<div class="kpi-card mb-3 border-2 ${returned ? 'border-red-200' : 'border-suntrackOrange/40'}">
      <p class="text-xs font-bold uppercase ${returned ? 'text-red-600' : 'text-suntrackOrange'} mb-1">
        ${returned ? '<i class="fas fa-rotate-left mr-1"></i>Returned — please fix and submit again' : '<i class="fas fa-list-check mr-1"></i>' + esc(cl.request_type)}</p>
      ${d.description ? `<p class="text-sm text-slate-700 bg-slate-50 rounded-lg px-3 py-2 mb-2"><i class="fas fa-comment text-slate-300 mr-1"></i>${esc(d.description)}</p>` : ''}
      ${returned && cl.review_note ? `<p class="text-sm bg-red-50 border border-red-100 text-red-700 rounded-lg px-3 py-2 mb-2"><i class="fas fa-comment-dots mr-1"></i><b>Management:</b> ${esc(cl.review_note)}</p>` : ''}
      <ol class="space-y-2">
        ${stepLine(1, `Tick every item <span class="text-slate-400">(${resolved}/${total})</span>`, resolved === total)}
        ${stepLine(2, `Add a proof photo for each step <span class="text-slate-400">(${withPhoto} of ${cl.steps.length})</span>`, withPhoto === cl.steps.length)}
        ${stepLine(3, `Time Out at the site, then submit for Management approval`, false)}
      </ol>
      ${d.editable && j.is_lead !== false ? `
      <textarea id="srcl-note" rows="2" maxlength="1000" class="field mt-3 !text-sm" placeholder="What was done (optional) — e.g. replaced DC breaker, system back online"></textarea>
      <button type="button" id="srcl-submit" class="primary-btn w-full mt-2 ${ready ? '' : 'opacity-50'}" ${ready ? '' : 'disabled'}><i class="fas fa-paper-plane mr-1"></i>Submit for approval</button>
      ${ready ? '' : `<p class="text-[11px] text-slate-400 text-center mt-1">${esc(cl.submit_blocker)}</p>`}` : ''}
    </div>`;
  }

  // ---- Steps ----------------------------------------------------------------------
  const pills = `<div class="kpi-card mb-3"><div class="flex items-start gap-1">${cl.steps.map((s, i) => `<div class="flex-1 min-w-0 text-center">
      <span class="mx-auto w-8 h-8 rounded-full flex items-center justify-center text-xs font-extrabold ${s.done ? 'bg-emerald-500 text-white' : (s.resolved || s.photos) ? 'bg-suntrackOrange text-white' : 'bg-slate-200 text-slate-500'}">${s.done ? '<i class="fas fa-check"></i>' : i + 1}</span>
      <p class="mt-1 text-[11px] font-bold text-slate-700 truncate">${esc(s.name)}</p>
      <p class="text-[10px] text-slate-400 truncate">${s.resolved}/${s.total} · ${s.photos} photo${s.photos === 1 ? '' : 's'}</p></div>`).join('')}</div>
      <div class="mt-3">${progressBar(cl.progress)}</div></div>`;

  const steps = cl.steps.map((s, si) => {
    const photos = photosBy[s.name] || [];
    return `<div class="kpi-card mb-3 ${canWork ? 'ring-2 ring-suntrackOrange/30' : ''}">
      <div class="flex items-center justify-between gap-3 mb-3">
        <p class="text-sm font-extrabold text-slate-800">${si + 1}. ${esc(s.name)} <span class="font-semibold text-slate-400">· ${s.resolved}/${s.total}</span></p>
        ${s.done ? '<span class="badge bg-emerald-100 text-emerald-700"><i class="fas fa-check mr-1"></i>Done</span>' : ''}
      </div>
      <div class="space-y-2">${(itemsBy[s.name] || []).map(it => {
        const ticked = it.status !== 'PENDING';
        return `<div class="rounded-xl border ${ticked ? 'border-emerald-200 bg-emerald-50/60' : 'border-slate-200 bg-white'} px-3 py-2.5">
          <div class="flex items-start gap-3">
            <button type="button" role="checkbox" aria-checked="${ticked}" data-item="${it.id}" data-status="${it.status}"
                    class="js-srcl-check flex items-start gap-3 flex-1 min-w-0 text-left ${canWork ? 'cursor-pointer' : 'cursor-default'}" ${canWork ? '' : 'disabled'}>
              <span class="mt-0.5 w-6 h-6 shrink-0 rounded-md border-2 flex items-center justify-center ${ticked ? 'bg-emerald-500 border-emerald-500 text-white' : 'bg-white border-slate-300 text-transparent'}">
                <i class="fas ${it.status === 'NOT_APPLICABLE' ? 'fa-minus' : 'fa-check'} text-xs"></i></span>
              <span class="min-w-0">
                <span class="block text-sm font-semibold ${ticked ? 'text-slate-500 line-through decoration-emerald-400' : 'text-slate-800'}">${esc(it.description)}</span>
                <span class="block text-[11px] text-slate-400">${it.status === 'NOT_APPLICABLE' ? '<span class="font-semibold text-slate-500">Not applicable</span> · ' : ''}${it.completed_at ? esc(fmtDate(it.completed_at)) : ''}${it.completed_by_name ? ' · ' + esc(it.completed_by_name) : ''}</span>
              </span>
            </button>
            ${canWork && !ticked ? `<button type="button" class="js-srcl-na shrink-0 text-[11px] font-semibold text-slate-400 border border-slate-200 rounded-lg px-2 py-1" data-item="${it.id}">N/A</button>` : ''}
          </div>
          ${canWork || it.remarks ? `<input class="field js-srcl-remarks mt-2 !text-xs !py-1.5" data-item="${it.id}" data-status="${it.status}" placeholder="Remarks (optional)" value="${esc(it.remarks || '')}" ${canWork ? '' : 'disabled'}>` : ''}
        </div>`;
      }).join('')}</div>
      <div class="mt-3 pt-3 border-t border-slate-100">
        <div class="flex items-center justify-between gap-2 mb-2">
          <p class="text-xs font-bold text-slate-600"><i class="fas fa-camera text-suntrackOrange mr-1"></i>Proof photos
            <span class="font-normal ${photos.length || !canWork ? 'text-slate-400' : 'text-amber-600'}">· ${photos.length ? photos.length + ' added' : 'at least 1 required'}</span></p>
          ${canWork && photos.length < (cl.photo_max_per_step || 10) ? `<label class="primary-btn !py-2 !px-3 text-xs cursor-pointer"><i class="fas fa-camera mr-1"></i>Take photo
            <input type="file" accept="image/*" capture="environment" class="hidden js-srcl-photo" data-step="${esc(s.name)}"></label>` : ''}
        </div>
        ${photos.length ? `<div class="grid grid-cols-4 sm:grid-cols-6 gap-2">${photos.map(p => `<div class="relative">
            <a href="${esc(p.url)}" target="_blank" rel="noopener"><img src="${esc(p.url)}" alt="" loading="lazy" class="w-full aspect-square object-cover rounded-lg border border-slate-200"></a>
            ${canWork ? `<button type="button" class="js-srcl-photo-del absolute -top-1.5 -right-1.5 h-6 w-6 rounded-full bg-red-500 text-white text-xs" data-id="${p.id}" title="Remove"><i class="fas fa-xmark"></i></button>` : ''}</div>`).join('')}</div>`
          : '<p class="text-[11px] text-slate-400">No photos yet.</p>'}
        <p class="js-srcl-photo-status text-[11px] text-slate-400 mt-1" data-step="${esc(s.name)}"></p>
      </div></div>`;
  }).join('');

  body.innerHTML = hero + pills + steps;
  body.parentElement.scrollTop = scrollTop;

  body.querySelectorAll('.js-srcl-check').forEach(b => b.addEventListener('click', () => srclUpdate(b.dataset.item, b.dataset.status === 'PENDING' ? 'COMPLETED' : 'PENDING')));
  body.querySelectorAll('.js-srcl-na').forEach(b => b.addEventListener('click', () => srclUpdate(b.dataset.item, 'NOT_APPLICABLE')));
  body.querySelectorAll('.js-srcl-remarks').forEach(inp => inp.addEventListener('change', () => srclUpdate(inp.dataset.item, inp.dataset.status)));
  body.querySelectorAll('.js-srcl-photo').forEach(inp => inp.addEventListener('change', () => srclUpload(inp)));
  body.querySelectorAll('.js-srcl-photo-del').forEach(b => b.addEventListener('click', async () => {
    if (!confirm('Remove this photo?')) return;
    const res = await apiPost('sr_checklist/photo_delete.php', { photo_id: +b.dataset.id });
    toast(res.message, res.success ? 'success' : 'error');
    await renderSrChecklist();
  }));
  const sub = document.getElementById('srcl-submit');
  if (sub) sub.addEventListener('click', async () => {
    if (!confirm('Submit this checklist for Management approval?\n\nIt will be locked while they review it. The request is completed when they approve it.')) return;
    await lockBtn(sub, '<i class="fas fa-spinner fa-spin mr-1"></i>Submitting...', async () => {
      const res = await apiPost('sr_checklist/submit.php', { job_id: jobId, note: (document.getElementById('srcl-note') || {}).value || '' });
      toast(res.message, res.success ? 'success' : 'error');
    });
    await renderSrChecklist();
  });
}
async function srclUpdate(itemId, status) {
  if (srclBusy) return;
  srclBusy = true;
  const remarksEl = document.querySelector(`.js-srcl-remarks[data-item="${itemId}"]`);
  const res = await apiPost('sr_checklist/update_item.php', { item_id: itemId, status, remarks: remarksEl ? remarksEl.value : '' });
  srclBusy = false;
  toast(res.message, res.success ? 'success' : 'error');
  await renderSrChecklist();
}
async function srclUpload(input) {
  const file = input.files && input.files[0];
  input.value = '';
  if (!file) return;
  const step = input.dataset.step;
  const status = [...document.querySelectorAll('.js-srcl-photo-status')].find(el => el.dataset.step === step);
  if (status) status.textContent = 'Uploading photo...';
  const fd = new FormData();
  fd.append('csrf_token', CSRF_TOKEN);
  fd.append('job_id', SRCL_JOB);
  fd.append('step', step);
  fd.append('photo', await shrinkImage(file), 'photo.jpg');
  let json;
  try { json = await (await fetch(API + 'sr_checklist/photo_upload.php', { method: 'POST', body: fd })).json(); }
  catch (e) { json = { success: false, message: 'Upload failed — check your connection and try again.' }; }
  toast(json.message, json.success ? 'success' : 'error');
  if (!json.success && status) status.textContent = json.message;
  if (json.success) await renderSrChecklist();
}

async function changeStage(btn, jobId, stage) {
  const job = state.assignments.find(j => j.id === jobId);
  const code = job ? job.job_code : '#' + jobId;

  if (stage === 'COMPLETED') {
    const ok = await confirmDialog('Complete this job?',
      `${code} will be marked COMPLETED. This closes the job — it cannot be edited or reopened from the field afterwards.`,
      'Yes, complete it');
    if (!ok) return;
  }
  if (stage === 'PAUSED') {
    const ok = await confirmDialog('Pause this job?', `Work on ${code} will be paused. You can resume it later.`, 'Pause');
    if (!ok) return;
  }

  await lockBtn(btn, '<i class="fas fa-spinner fa-spin"></i>', async () => {
    const json = await apiPost('jobs/status.php', { job_id: jobId, stage });
    if (!json.success) {
      toast(json.message, 'error');
      // Completing without a report: open the report form right away.
      if (json.data && json.data.requires === 'WORK_REPORT' && job) {
        openReportModal(job.id, job.job_code, job.job_type);
        return;
      }
      const fb = document.getElementById('feedback-' + jobId);
      if (fb) fb.innerHTML = `<span class="text-red-500">${esc(json.message)}</span>`;
      await loadAssignments();
      return;
    }
    toast(json.message, 'success');
    await loadAssignments();
    if (state.tab === 'site-map') refreshMap();
    if (state.tab === 'service-requests') loadTechServiceRequests();
  });
}

async function undoStage(btn, jobId) {
  const ok = await confirmDialog('Undo the last change?',
    'This reverts the most recent stage change you made on this job. The reversal is recorded in the job history — nothing is deleted.',
    'Undo it');
  if (!ok) return;

  await lockBtn(btn, '<i class="fas fa-spinner fa-spin"></i>', async () => {
    const json = await apiPost('jobs/undo.php', { job_id: jobId });
    toast(json.message, json.success ? 'success' : 'error');
    if (json.success) await loadAssignments();
  });
}

async function handleGps(btn, jobId, mode) {
  const fb = document.getElementById('feedback-' + jobId);
  const say = (html) => { if (fb) fb.innerHTML = html; };

  if (!gpsSupported()) {
    say('<span class="text-red-500">This browser does not support geolocation.</span>');
    toast('Geolocation is not supported by this browser.', 'error');
    return;
  }

  await lockBtn(btn, 'Getting location...', async () => {
    say('<span class="text-slate-400">Requesting GPS permission...</span>');
    let pos;
    try {
      // Always a fresh fix for Time In/Out — never a cached one, which could
      // judge the technician on where they were a few seconds ago.
      pos = await getPosition({ maximumAge: 0 });
      state.position = pos;
      state.gpsError = null;
      renderGpsStrip();
    } catch (err) {
      state.gpsError = err;
      renderGpsStrip();
      say(`<span class="text-red-500">${esc(gpsErrorText(err))}</span>`);
      toast(gpsErrorText(err), 'error');
      return;
    }

    btn.innerHTML = mode === 'in' ? 'Timing in...' : 'Timing out...';
    const endpoint = mode === 'in' ? 'attendance/time_in.php' : 'attendance/time_out.php';
    // accuracy lets the server refuse a reading too rough to prove where you are.
    const json = await apiPost(endpoint, { job_id: jobId, latitude: pos.lat, longitude: pos.lng, accuracy: pos.accuracy });

    if (!json.success) {
      const d = json.data || {};
      const extra = (d.distance !== undefined && d.distance !== null) ? ` (${d.distance} m away, radius ${d.radius} m)` : '';
      say(`<span class="text-red-500">${esc(json.message + extra)}</span>`);
      toast(json.message, 'error');
      return;
    }

    const d = json.data;
    const distNote = d.distance !== null ? ` — ${d.distance} m from site` : ' — site coordinates not set for this job';
    say(mode === 'in'
      ? `<span class="text-emerald-600 font-semibold"><i class="fas fa-location-dot"></i> Timed in${esc(distNote)}</span>`
      : `<span class="text-slate-600">Timed out${esc(distNote)} · ${esc(fmtDuration(d.duration_minutes))} on site</span>`);
    toast(json.message, 'success');
    await loadAssignments();
    if (state.tab === 'service-requests') loadTechServiceRequests();
  });
}

function scheduleGeofencePing() {
  if (state.pingTimer) { clearInterval(state.pingTimer); state.pingTimer = null; }
  const j = activeJob();

  if (!j || !j.has_coordinates || !gpsSupported()) {
    // No live job — let the screen sleep normally and save the battery.
    if (window.SunTrackMobile) SunTrackMobile.releaseAwake();
    return;
  }

  // A locked phone stops the timer below, which leaves a gap in the location
  // trail that reads like the technician left the site. Hold the screen awake
  // for as long as the job is actually active.
  if (window.SunTrackMobile) SunTrackMobile.keepAwake();

  state.pingTimer = setInterval(sendGeofencePing, 20000);
}

async function sendGeofencePing() {
  const j = activeJob();
  if (!j || !j.has_coordinates) { scheduleGeofencePing(); return; }
  let pos;
  try { pos = await getPosition({ timeout: 8000 }); }
  catch (err) {
    state.gpsError = err;
    state.position = null;
    renderGpsStrip();
    return;
  }
  state.position = pos;
  state.gpsError = null;
  renderGpsStrip();

  const json = await apiPost('geofence/ping.php', { job_id: j.id, latitude: pos.lat, longitude: pos.lng, accuracy: pos.accuracy });
  if (json.success && json.data) {
    j.distance_m = json.data.distance_m;
    j.inside_geofence = json.data.inside;
    renderActiveJob();
    if (state.tab === 'assignments') renderAssignments();
    if (state.tab === 'site-map') drawMap();
  }
}

function fillPicker(selectId, jobs, selectedKey, emptyText) {
  const sel = document.getElementById(selectId);
  if (!sel) return;
  if (!jobs.length) {
    sel.innerHTML = `<option value="">${esc(emptyText)}</option>`;
    state.selected[selectedKey] = null;
    return;
  }
  if (!state.selected[selectedKey] || !jobs.some(j => j.id === state.selected[selectedKey])) {
    state.selected[selectedKey] = jobs[0].id;
  }
  sel.innerHTML = jobs.map(j =>
    `<option value="${j.id}" ${j.id === state.selected[selectedKey] ? 'selected' : ''}>${esc(j.job_code)} — ${esc(j.job_type)} — ${esc(j.client_name)}</option>`
  ).join('');
}

function syncPickers() {
  fillPicker('jd-picker', state.assignments, 'jd', 'No open assignments');
  fillPicker('map-picker', state.assignments.filter(j => j.has_coordinates), 'map', 'No job with coordinates');
  fillPicker('inst-picker', state.assignments.filter(j => j.job_type === 'INSTALLATION'), 'inst', 'No installation jobs assigned');
  fillPicker('maint-picker', state.assignments.filter(j => j.job_type === 'MAINTENANCE'), 'maint', 'No maintenance jobs assigned');
}

document.getElementById('jd-picker').addEventListener('change', e => { state.selected.jd = +e.target.value || null; loadJobDetails(); });
document.getElementById('inst-picker').addEventListener('change', e => { state.selected.inst = +e.target.value || null; loadInstallation(); });
document.getElementById('maint-picker').addEventListener('change', e => { state.selected.maint = +e.target.value || null; loadMaintenance(); });
document.getElementById('map-picker').addEventListener('change', e => { state.selected.map = +e.target.value || null; drawMap(true); });

async function loadJobDetails() {
  const box = document.getElementById('jd-body');
  const jobId = state.selected.jd;
  if (!jobId) { box.innerHTML = '<div class="kpi-card text-slate-400 text-sm">You have no open assignments.</div>'; return; }

  box.innerHTML = '<div class="kpi-card text-slate-400 text-sm">Loading...</div>';
  const json = await apiGet('technician/job_details.php', { job_id: jobId });
  if (!json.success) { box.innerHTML = `<div class="kpi-card text-red-500 text-sm">${esc(json.message)}</div>`; return; }

  const d = json.data, j = d.job, c = d.client;

  const timeline = d.history.length
    ? d.history.map(h => `
        <div class="flex gap-3">
          <div class="timeline-dot"></div>
          <div class="pb-4 min-w-0">
            <p class="text-sm font-bold text-slate-900">${esc(h.from_stage ? niceStage(h.from_stage) + ' → ' : '')}${esc(niceStage(h.to_stage))}</p>
            <p class="text-xs text-slate-500">${esc(fmtDate(h.created_at))}${h.changed_by_name ? ' · ' + esc(h.changed_by_name) : ''}</p>
            ${h.note ? `<p class="text-xs text-slate-500 italic mt-0.5">${esc(h.note)}</p>` : ''}
          </div>
        </div>`).join('')
    : '<p class="text-slate-400 text-sm">No status changes recorded yet.</p>';

  const attendance = d.attendance.length
    ? d.attendance.map(a => `
        <div class="text-xs text-slate-600 border border-slate-100 rounded-lg px-3 py-2 mb-2">
          <span class="font-semibold text-slate-800">In:</span> ${esc(fmtDate(a.time_in))}${a.distance_in_m !== null ? ` (${Math.round(a.distance_in_m)} m)` : ''}
          · <span class="font-semibold text-slate-800">Out:</span> ${esc(fmtDate(a.time_out))}${a.distance_out_m !== null ? ` (${Math.round(a.distance_out_m)} m)` : ''}
        </div>`).join('')
    : '<p class="text-slate-400 text-sm">No time in/out recorded for this job yet.</p>';

  box.innerHTML = `
    <div class="grid md:grid-cols-3 gap-4">
      <div class="kpi-card md:col-span-2">
        <div class="flex items-start justify-between gap-3 flex-wrap mb-4">
          <div>
            <p class="text-2xl font-extrabold text-slate-900">${esc(j.job_code)}</p>
            <p class="text-sm text-slate-500">${esc(j.job_type)}${d.project ? ' · ' + esc(d.project.project_code) : ''}</p>
          </div>
          <div class="flex gap-2 flex-wrap">${stageBadge(j.stage)}<span class="badge ${PRIORITY_COLORS[j.priority] || 'bg-slate-100'}">${esc(j.priority)}</span></div>
        </div>
        ${subcontractBanner({ subcontract: d.subcontract })}
        <div class="mb-4">
          <div class="flex items-center justify-between text-xs mb-1"><span class="text-slate-500 font-semibold">Progress</span><span class="font-bold text-slate-800">${j.progress}%</span></div>
          ${progressBar(j.progress)}
        </div>
        <dl class="dl grid grid-cols-2 md:grid-cols-3 gap-x-4">
          <div><dt>Scheduled</dt><dd>${esc(j.scheduled_date || '—')}</dd></div>
          <div><dt>Geofence radius</dt><dd>${j.geofence_radius_m} m</dd></div>
          <div><dt>Coordinates</dt><dd>${j.site_lat !== null ? esc(j.site_lat + ', ' + j.site_lng) : 'Not recorded'}</dd></div>
          <div class="col-span-2 md:col-span-3"><dt>Site address</dt><dd>${esc(j.site_address || '—')}</dd></div>
          <div class="col-span-2 md:col-span-3"><dt>Description</dt><dd>${esc(j.description || '—')}</dd></div>
        </dl>
      </div>

      <div class="kpi-card">
        <h4 class="font-bold text-slate-900 mb-3">Client</h4>
        <dl class="dl">
          <div><dt>Name</dt><dd>${esc(c.name)} <span class="text-slate-400 font-normal">(${esc(c.client_code)})</span></dd></div>
          <div><dt>Phone</dt><dd>${c.phone ? `<a class="text-suntrackOrange" href="tel:${esc(c.phone)}">${esc(c.phone)}</a>` : '—'}</dd></div>
          <div><dt>Email</dt><dd class="break-all">${esc(c.email || '—')}</dd></div>
          <div><dt>Address</dt><dd>${esc([c.address, c.city, c.province].filter(Boolean).join(', ') || '—')}</dd></div>
        </dl>
        ${d.solar_system ? `
          <h4 class="font-bold text-slate-900 mt-4 mb-2">Installed system</h4>
          <dl class="dl">
            <div><dt>System</dt><dd>${esc(d.solar_system.system_code)} · ${esc(d.solar_system.capacity_kw)} kW</dd></div>
            <div><dt>Panels / Inverter / Battery</dt><dd class="font-normal text-sm">${esc(d.solar_system.panel_brand)} · ${esc(d.solar_system.inverter_brand)} · ${esc(d.solar_system.battery_brand)}</dd></div>
          </dl>` : ''}
      </div>
    </div>

    <div class="grid md:grid-cols-3 gap-4 mt-4">
      <div class="kpi-card md:col-span-2">
        <h4 class="font-bold text-slate-900 mb-3">Status history</h4>
        <div class="timeline-line">${timeline}</div>
      </div>
      <div class="space-y-4">
        <div class="kpi-card">
          <h4 class="font-bold text-slate-900 mb-3">Attendance</h4>
          ${attendance}
        </div>
        <div class="kpi-card">
          <h4 class="font-bold text-slate-900 mb-3">Module status</h4>
          ${d.installation ? `<p class="text-sm text-slate-700 mb-2">Checklist: <span class="font-bold">${d.installation.progress}%</span> (${d.installation.resolved}/${d.installation.total} done, ${d.installation.pending} pending)</p>` : ''}
          ${d.maintenance ? `<p class="text-sm text-slate-700 mb-2">Inspection: <span class="font-bold">${d.maintenance.counts.progress}%</span> · ${esc(niceStage(d.maintenance.status))}</p>` : ''}
          ${(!d.installation && !d.maintenance) ? '<p class="text-sm text-slate-400 mb-2">No checklist or inspection attached to this job type.</p>' : ''}
          <p class="text-sm text-slate-700">Work report: ${d.work_report
            ? `<span class="badge bg-emerald-100 text-emerald-700">${esc(d.work_report.report_code)}</span>`
            : '<span class="badge bg-slate-100 text-slate-500">Not submitted</span>'}</p>
        </div>
      </div>
    </div>`;
}

function ensureMap() {
  if (state.mapReady) return true;
  if (typeof L === 'undefined') return false;
  state.map = L.map('tech-map', { scrollWheelZoom: true }).setView([10.6407, 122.9689], 13);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19, attribution: '&copy; OpenStreetMap contributors'
  }).addTo(state.map);
  state.mapReady = true;
  return true;
}

function clearMapLayers() {
  Object.values(state.mapLayers).forEach(layer => { if (layer) state.map.removeLayer(layer); });
  state.mapLayers = {};
}

async function refreshMap() {
  const warn = document.getElementById('map-warning');
  if (typeof L === 'undefined') {
    warn.textContent = 'The map library could not be loaded. Check your internet connection — Leaflet is served from a CDN.';
    warn.classList.remove('hidden');
    return;
  }
  if (!ensureMap()) return;
  setTimeout(() => state.map.invalidateSize(), 60);
  if (!state.position && gpsSupported() && !state.gpsError) await refreshPosition(true);
  drawMap(true);
}

function drawMap(fit = false) {
  if (!state.mapReady) return;
  const warn = document.getElementById('map-warning');
  const legend = document.getElementById('map-legend');
  clearMapLayers();

  const jobsWithCoords = state.assignments.filter(j => j.has_coordinates);
  const selected = jobsWithCoords.find(j => j.id === state.selected.map) || jobsWithCoords[0] || null;

  const notes = [];
  if (!gpsSupported()) notes.push('This browser does not support geolocation, so your own position cannot be shown.');
  else if (state.gpsError) notes.push(gpsErrorText(state.gpsError));
  else if (!state.position) notes.push('Enable GPS above to plot your current position and live distance.');
  if (!jobsWithCoords.length) notes.push('None of your open jobs have site coordinates recorded, so there is nothing to plot.');

  warn.innerHTML = notes.map(esc).join('<br>');
  warn.classList.toggle('hidden', notes.length === 0);

  const bounds = [];

  if (selected) {
    const siteIcon = L.divIcon({
      className: '',
      html: '<div style="background:#f97316;width:18px;height:18px;border-radius:999px;border:3px solid #fff;box-shadow:0 0 0 2px #f97316"></div>',
      iconSize: [18, 18], iconAnchor: [9, 9]
    });
    state.mapLayers.site = L.marker([selected.site_lat, selected.site_lng], { icon: siteIcon })
      .addTo(state.map)
      .bindPopup(`<strong>${esc(selected.job_code)}</strong><br>${esc(selected.job_type)} · ${esc(niceStage(selected.stage))}<br>${esc(selected.client_name)}<br>${esc(selected.site_address || '')}`);
    state.mapLayers.fence = L.circle([selected.site_lat, selected.site_lng], {
      radius: selected.geofence_radius_m, color: '#f97316', weight: 2, fillColor: '#f97316', fillOpacity: 0.08
    }).addTo(state.map);
    bounds.push([selected.site_lat, selected.site_lng]);
  }

  let distance = null, inside = null;
  if (state.position) {
    const meIcon = L.divIcon({
      className: '',
      html: '<div style="background:#2563eb;width:16px;height:16px;border-radius:999px;border:3px solid #fff;box-shadow:0 0 0 2px #2563eb"></div>',
      iconSize: [16, 16], iconAnchor: [8, 8]
    });
    state.mapLayers.me = L.marker([state.position.lat, state.position.lng], { icon: meIcon })
      .addTo(state.map).bindPopup('You are here');
    bounds.push([state.position.lat, state.position.lng]);

    if (selected) {
      distance = Math.round(state.map.distance([state.position.lat, state.position.lng], [selected.site_lat, selected.site_lng]));
      inside = distance <= selected.geofence_radius_m;
      state.mapLayers.line = L.polyline([
        [state.position.lat, state.position.lng],
        [selected.site_lat, selected.site_lng]
      ], { color: inside ? '#16a34a' : '#dc2626', weight: 2, dashArray: '6 6' }).addTo(state.map);
    }
  }

  if (fit && bounds.length) {
    if (bounds.length === 1) state.map.setView(bounds[0], 16);
    else state.map.fitBounds(bounds, { padding: [50, 50] });
  }

  legend.innerHTML = selected ? `
    <span><span class="inline-block w-3 h-3 rounded-full align-middle" style="background:#f97316"></span>
      <strong class="text-slate-700">${esc(selected.job_code)}</strong> — ${esc(niceStage(selected.stage))}</span>
    <span><span class="inline-block w-3 h-3 rounded-full align-middle" style="background:#2563eb"></span> Your position</span>
    <span>Geofence: <strong class="text-slate-700">${selected.geofence_radius_m} m</strong></span>
    <span>Distance: <strong class="text-slate-700">${distance !== null ? distance + ' m' : 'GPS off'}</strong></span>
    <span>${inside === null ? '' : (inside
      ? '<span class="badge bg-emerald-100 text-emerald-700">Inside geofence</span>'
      : '<span class="badge bg-red-100 text-red-700">Outside geofence</span>')}</span>
    <span class="text-slate-400">${esc(selected.site_address || '')}</span>` : '';
}

async function loadInstallation() {
  const box = document.getElementById('inst-body');
  const jobId = state.selected.inst;
  if (!jobId) { box.dataset.job = ''; box.innerHTML = '<div class="kpi-card text-slate-400 text-sm">You have no open installation jobs.</div>'; return; }

  // Refreshing the job already on screen (after a tick, or a live update) keeps
  // the list where it is: no "Loading" placeholder collapsing the page, and the
  // scroll position is put back after the redraw.
  const refreshing = box.dataset.job === String(jobId);
  const scrollY = window.scrollY;
  if (!refreshing) {
    box.innerHTML = '<div class="kpi-card text-slate-400 text-sm">Loading checklist...</div>';
  }
  const json = await apiGet('installation/get.php', { job_id: jobId });
  if (jobId !== state.selected.inst) return; // another job was picked meanwhile
  if (!json.success) { box.dataset.job = ''; box.innerHTML = `<div class="kpi-card text-red-500 text-sm">${esc(json.message)}</div>`; return; }
  box.dataset.job = String(jobId);
  if (refreshing) {
    requestAnimationFrame(() => window.scrollTo(0, scrollY));
  }

  const d = json.data;
  if (!d.checklist) {
    box.dataset.job = '';
    box.innerHTML = '<div class="kpi-card text-slate-400 text-sm">No installation checklist exists for this job.</div>';
    return;
  }

  const groups = {};
  d.items.forEach(it => { (groups[it.category] = groups[it.category] || []).push(it); });
  // Stages in working order (items + proof photos), and their schedule / review state.
  const stages = d.stages || Object.keys(groups).map(name => ({ name, unlocked: true, done: false, total: groups[name].length, resolved: 0, photos: 0 }));
  const planBy = {};
  (d.plan || []).forEach(p => { planBy[p.stage] = p; });
  const hasPlan = (d.plan || []).length > 0;
  const today = d.today || new Date().toISOString().slice(0, 10);
  const photosByStage = {};
  (d.photos || []).forEach(p => { (photosByStage[p.stage] = photosByStage[p.stage] || []).push(p); });
  const touchedAfter = stages.map((s, i) => stages.slice(i + 1).some(x => x.resolved > 0));
  const niceDate = v => v ? new Date(String(v).slice(0, 10) + 'T00:00').toLocaleDateString('en-PH', { weekday: 'short', month: 'short', day: 'numeric' }) : '';
  const niceWhen = v => v ? new Date(String(v).replace(' ', 'T')).toLocaleString('en-PH', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : '';

  // The one stage the technician may work on right now.
  // Same rule as the server (install_plan_edit_blocker): the stage is booked for
  // today or earlier, and every stage before it is approved — or booked for the
  // same day, since stages on one day are one visit and are worked together.
  const sameVisit = (a, b) => a && b && a.scheduled_date && a.scheduled_date === b.scheduled_date
    && a.status !== 'PLANNED' && b.status !== 'PLANNED';
  const isWorkable = st => {
    if (!d.editable) return false;
    if (!hasPlan) return st.unlocked && !st.done;
    const p = planBy[st.name];
    if (!p || !(p.status === 'SCHEDULED' || p.status === 'RETURNED') || (p.scheduled_date && p.scheduled_date > today)) return false;
    return (d.plan || []).every(r => r.position >= p.position || r.status === 'APPROVED' || sameVisit(r, p));
  };
  const current = stages.find(st => hasPlan ? (planBy[st.name] && planBy[st.name].status !== 'APPROVED') : !st.done) || null;
  const currentPlan = current ? planBy[current.name] : null;
  const visit = stages.filter(isWorkable); // what can be worked on right now (one visit)

  // ---- "Today's work" card: what to do now, in plain steps -------------------
  let hero;
  const stepLine = (n, text, ok) => `
    <li class="flex items-center gap-2 text-sm ${ok ? 'text-emerald-700' : 'text-slate-700'}">
      <span class="w-6 h-6 shrink-0 rounded-full flex items-center justify-center text-xs font-extrabold ${ok ? 'bg-emerald-500 text-white' : 'bg-slate-200 text-slate-600'}">${ok ? '<i class="fas fa-check"></i>' : n}</span><span class="min-w-0">${text}</span></li>`;
  if (!current) {
    hero = `<div class="kpi-card mb-4 border-2 border-emerald-200 bg-emerald-50/50">
      <p class="text-xs font-bold uppercase text-emerald-700 mb-1">All stages approved</p>
      <p class="text-lg font-extrabold text-slate-900">This installation is ready to be completed</p>
      <p class="text-sm text-slate-600 mt-1">${d.editable ? 'File the work report and press <b>Complete Job</b> in My Assignments.' : 'This job is closed.'}</p></div>`;
  } else if (visit.length) {
    // Today's visit: every stage that can be worked now (several when they are booked for the same day).
    const resolved = visit.reduce((n, s) => n + s.resolved, 0), total = visit.reduce((n, s) => n + s.total, 0);
    const withPhoto = visit.filter(s => (s.photos || 0) > 0).length;
    const itemsOk = resolved === total;
    const photosOk = withPhoto === visit.length;
    const returnedRows = visit.map(s => planBy[s.name]).filter(p => p && p.status === 'RETURNED');
    const returned = returnedRows.length > 0;
    const names = visit.map(s => s.name);
    const multi = visit.length > 1;
    const firstIdx = stages.indexOf(visit[0]);
    hero = `<div class="kpi-card mb-4 border-2 ${returned ? 'border-red-200' : 'border-suntrackOrange/40'}">
      <p class="text-xs font-bold uppercase ${returned ? 'text-red-600' : 'text-suntrackOrange'} mb-1">
        ${returned ? '<i class="fas fa-rotate-left mr-1"></i>Returned — please fix and submit again' : '<i class="fas fa-calendar-day mr-1"></i>Today\'s work'}
        · ${multi ? 'Stages ' + (firstIdx + 1) + '–' + (firstIdx + visit.length) : 'Stage ' + (firstIdx + 1)} of ${stages.length}</p>
      <p class="text-xl font-extrabold text-slate-900">${names.map(esc).join(' <span class="text-slate-300">+</span> ')}${firstIdx === 0 && !multi ? ' <span class="text-sm font-semibold text-slate-400">(inspection)</span>' : ''}</p>
      ${multi ? '<p class="text-xs text-slate-500 mt-1"><i class="fas fa-layer-group mr-1"></i>These stages are booked for the same day, so you can work on them together.</p>' : ''}
      ${returnedRows.filter(p => p.review_note).map(p => `<p class="mt-2 text-sm bg-red-50 border border-red-100 text-red-700 rounded-lg px-3 py-2"><i class="fas fa-comment-dots mr-1"></i><b>Management (${esc(p.stage)}):</b> ${esc(p.review_note)}</p>`).join('')}
      <ol class="mt-3 space-y-2">
        ${stepLine(1, `Tick every item below <span class="text-slate-400">(${resolved}/${total})</span>`, itemsOk)}
        ${stepLine(2, `Add at least one proof photo${multi ? ' for each stage' : ''} <span class="text-slate-400">(${multi ? withPhoto + ' of ' + visit.length + ' stages' : (visit[0].photos || 0) + ' added'})</span>`, photosOk)}
        ${stepLine(3, `Submit ${multi ? 'them' : 'it'} so Management can review ${multi ? 'them' : 'it'}`, false)}
      </ol>
      ${hasPlan && d.job.is_lead === false ? `
      <p class="mt-3 text-sm bg-sky-50 border border-sky-100 text-sky-800 rounded-lg px-3 py-2"><i class="fas fa-users mr-1"></i>
        You're on the crew for this stage. Tick items and add photos — your lead, <b>${esc(((d.job.crew || []).find(m => m.is_lead) || {}).name || 'the lead technician')}</b>, submits it for review.</p>` : ''}
      ${hasPlan && d.job.is_lead !== false ? `
      <textarea id="stage-submit-note" rows="2" maxlength="500" class="field mt-3 !text-sm" placeholder="Note for Management (optional) — e.g. roof is ready, need 2 more rails"></textarea>
      <button type="button" id="stage-submit-btn" data-stages="${esc(names.join('|'))}" class="primary-btn w-full mt-2 ${itemsOk && photosOk ? '' : 'opacity-50'}" ${itemsOk && photosOk ? '' : 'disabled'}>
        <i class="fas fa-paper-plane mr-1"></i>Submit ${multi ? 'today\'s ' + visit.length + ' stages' : esc(names[0])} for review</button>
      ${itemsOk && photosOk ? '' : '<p class="text-[11px] text-slate-400 text-center mt-1">Finish steps 1 and 2 to submit.</p>'}` : ''}
    </div>`;
  } else if (currentPlan && currentPlan.status === 'SUBMITTED') {
    hero = `<div class="kpi-card mb-4 border-2 border-sky-200 bg-sky-50/40">
      <p class="text-xs font-bold uppercase text-sky-700 mb-1"><i class="fas fa-hourglass-half mr-1"></i>Waiting for Management review</p>
      <p class="text-lg font-extrabold text-slate-900">${esc(current.name)} was submitted${currentPlan.submitted_at ? ' on ' + esc(niceWhen(currentPlan.submitted_at)) : ''}</p>
      <p class="text-sm text-slate-600 mt-1">Nothing to do here for now. You will be notified when it is approved and the next visit is scheduled.</p></div>`;
  } else if (currentPlan && currentPlan.status === 'SCHEDULED') {
    hero = `<div class="kpi-card mb-4 border-2 border-slate-200">
      <p class="text-xs font-bold uppercase text-slate-500 mb-1"><i class="fas fa-calendar mr-1"></i>Next visit</p>
      <p class="text-lg font-extrabold text-slate-900">${esc(current.name)} · ${esc(niceDate(currentPlan.scheduled_date))}</p>
      <p class="text-sm text-slate-600 mt-1">This stage opens on its scheduled day.</p></div>`;
  } else {
    hero = `<div class="kpi-card mb-4 border-2 border-slate-200">
      <p class="text-xs font-bold uppercase text-slate-500 mb-1"><i class="fas fa-clock mr-1"></i>Waiting to be scheduled</p>
      <p class="text-lg font-extrabold text-slate-900">${esc(current.name)}</p>
      <p class="text-sm text-slate-600 mt-1">Management will schedule this visit. You will be notified of the date.</p></div>`;
  }

  // ---- Progress across all stages (one row of steps) --------------------------
  const pill = (st, i) => {
    const p = planBy[st.name];
    const status = hasPlan && p ? p.status : (st.done ? 'APPROVED' : (st.unlocked ? 'SCHEDULED' : 'PLANNED'));
    const look = {
      APPROVED: ['bg-emerald-500 text-white', '<i class="fas fa-check"></i>', 'Approved'],
      SUBMITTED: ['bg-sky-500 text-white', '<i class="fas fa-hourglass-half"></i>', 'In review'],
      RETURNED: ['bg-red-500 text-white', '<i class="fas fa-rotate-left"></i>', 'Returned'],
      SCHEDULED: ['bg-suntrackOrange text-white', i + 1, p && p.scheduled_date ? niceDate(p.scheduled_date) : 'Open'],
      PLANNED: ['bg-slate-200 text-slate-500', i + 1, 'Not scheduled'],
    }[status] || ['bg-slate-200 text-slate-500', i + 1, ''];
    return `<div class="flex-1 min-w-0 text-center">
      <span class="mx-auto w-8 h-8 rounded-full flex items-center justify-center text-xs font-extrabold ${look[0]} ${current && current.name === st.name ? 'ring-4 ring-orange-100' : ''}">${look[1]}</span>
      <p class="mt-1 text-[11px] font-bold text-slate-700 leading-tight truncate">${esc(st.name)}</p>
      <p class="text-[10px] text-slate-400 leading-tight truncate">${esc(look[2])}</p></div>`;
  };
  const progressCard = `
    <div class="kpi-card mb-4">
      <div class="flex items-start justify-between gap-3 flex-wrap mb-3">
        <div>
          <p class="font-extrabold text-slate-900">${esc(d.job.job_code)}</p>
          <p class="text-xs text-slate-500">${esc(d.job.client_name)} · ${esc(d.job.site_address || '')}</p>
        </div>
        ${stageBadge(d.job.stage)}
      </div>
      <div class="flex items-start gap-1">${stages.map(pill).join('')}</div>
      ${!d.editable ? '<p class="text-xs text-slate-400 mt-3">This job is closed — the checklist is read-only.</p>' : ''}
    </div>`;

  // ---- One stage: items + photos. Only the stage being worked on is open. ----
  const stageBody = (st, si, canWork) => {
    const items = groups[st.name] || [];
    const stPhotos = photosByStage[st.name] || [];
    const canAddPhoto = canWork && stPhotos.length < (d.photo_max_per_stage || 10);
    return `
      <div class="space-y-2">
        ${items.map(it => {
          const ticked = it.status !== 'PENDING';
          const canToggle = canWork && (ticked ? !touchedAfter[si] : true);
          return `
          <div class="rounded-xl border ${ticked ? 'border-emerald-200 bg-emerald-50/60' : 'border-slate-200 bg-white'} px-3 py-2.5">
            <div class="flex items-start gap-3">
              <button type="button" role="checkbox" aria-checked="${ticked}" data-item="${it.id}" data-status="${it.status}"
                      class="js-inst-check flex items-start gap-3 flex-1 min-w-0 text-left ${canToggle ? 'cursor-pointer' : 'cursor-default'}" ${canToggle ? '' : 'disabled'}>
                <span class="mt-0.5 w-6 h-6 shrink-0 rounded-md border-2 flex items-center justify-center transition
                             ${ticked ? 'bg-emerald-500 border-emerald-500 text-white' : 'bg-white border-slate-300 text-transparent'}">
                  <i class="fas ${it.status === 'NOT_APPLICABLE' ? 'fa-minus' : 'fa-check'} text-xs"></i>
                </span>
                <span class="min-w-0">
                  <span class="block text-sm font-semibold ${ticked ? 'text-slate-500 line-through decoration-emerald-400' : 'text-slate-800'}">${esc(it.description)}</span>
                  <span class="block text-[11px] text-slate-400">
                    ${it.status === 'NOT_APPLICABLE' ? '<span class="font-semibold text-slate-500">Not applicable</span> · ' : ''}${it.completed_date ? esc(fmtDate(it.completed_date)) : ''}${it.completed_by_name ? ' · ' + esc(it.completed_by_name) : ''}
                  </span>
                </span>
              </button>
              ${canWork && !ticked ? `<button type="button" class="js-inst-na shrink-0 text-[11px] font-semibold text-slate-400 hover:text-slate-600 border border-slate-200 rounded-lg px-2 py-1" data-item="${it.id}" title="Mark as not applicable for this site">N/A</button>` : ''}
            </div>
            ${canWork || it.remarks ? `<input class="field js-inst-remarks mt-2 !text-xs !py-1.5" data-item="${it.id}" data-status="${it.status}"
                   placeholder="Remarks (optional)" value="${esc(it.remarks || '')}" ${canWork ? '' : 'disabled'}>` : ''}
          </div>`;
        }).join('')}
      </div>
      <div class="mt-3 pt-3 border-t border-slate-100">
        <div class="flex items-center justify-between gap-2 mb-2">
          <p class="text-xs font-bold text-slate-600"><i class="fas fa-camera text-suntrackOrange mr-1"></i>Proof photos
            <span class="font-normal ${stPhotos.length || !canWork ? 'text-slate-400' : 'text-amber-600'}">· ${stPhotos.length ? stPhotos.length + ' added' : 'at least 1 required'}</span></p>
          ${canAddPhoto ? `<label class="primary-btn !py-2 !px-3 text-xs cursor-pointer"><i class="fas fa-camera mr-1"></i>Take photo
              <input type="file" accept="image/*" capture="environment" class="hidden js-stage-photo" data-stage="${esc(st.name)}"></label>` : ''}
        </div>
        ${stPhotos.length ? `<div class="grid grid-cols-4 sm:grid-cols-6 gap-2">${stPhotos.map(p => `
          <div class="relative">
            <a href="${esc(p.url)}" target="_blank" rel="noopener"><img src="${esc(p.url)}" alt="${esc(st.name)} photo" loading="lazy" class="w-full aspect-square object-cover rounded-lg border border-slate-200"></a>
            ${canWork ? `<button type="button" class="js-stage-photo-del absolute -top-1.5 -right-1.5 h-6 w-6 rounded-full bg-red-500 text-white text-xs" data-id="${p.id}" title="Remove"><i class="fas fa-xmark"></i></button>` : ''}
          </div>`).join('')}</div>`
          : `<p class="text-[11px] text-slate-400">No photos yet.</p>`}
        <p class="js-stage-photo-status text-[11px] text-slate-400 mt-1" data-stage="${esc(st.name)}"></p>
      </div>`;
  };

  const stageCards = stages.map((st, si) => {
    const p = planBy[st.name];
    const canWork = isWorkable(st);
    const status = hasPlan && p ? p.status : (st.done ? 'APPROVED' : 'PLANNED');
    const sub = {
      APPROVED: `Approved${p && p.reviewed_by_name ? ' by ' + esc(p.reviewed_by_name) : ''}${p && p.reviewed_at ? ' · ' + esc(niceWhen(p.reviewed_at)) : ''}`,
      SUBMITTED: `Submitted${p && p.submitted_at ? ' ' + esc(niceWhen(p.submitted_at)) : ''} · waiting for review`,
      RETURNED: 'Returned for fixes',
      SCHEDULED: p && p.scheduled_date ? 'Scheduled · ' + esc(niceDate(p.scheduled_date)) : 'Open',
      PLANNED: 'Not scheduled yet',
    }[status] || '';
    if (canWork) {
      return `<div class="kpi-card mb-4 ring-2 ring-suntrackOrange/40">
        <div class="flex items-center justify-between gap-3 mb-3">
          <p class="text-sm font-extrabold text-slate-800">${si + 1}. ${esc(st.name)} <span class="font-semibold text-slate-400">· ${st.resolved}/${st.total}</span></p>
          <span class="badge bg-amber-100 text-amber-700"><i class="fas fa-person-digging mr-1"></i>Work on this</span>
        </div>
        ${stageBody(st, si, true)}
      </div>`;
    }
    // Every other stage is folded away; tap to look inside (read-only).
    return `<details class="kpi-card mb-3 group ${status === 'PLANNED' ? 'opacity-60' : ''}">
      <summary class="flex items-center justify-between gap-3 cursor-pointer list-none">
        <span class="min-w-0">
          <span class="block text-sm font-bold text-slate-800">${si + 1}. ${esc(st.name)}</span>
          <span class="block text-[11px] text-slate-400">${sub} · ${st.resolved}/${st.total} items · ${st.photos || 0} photo${(st.photos || 0) === 1 ? '' : 's'}</span>
          ${p && p.review_note && status !== 'APPROVED' ? `<span class="block text-[11px] text-red-600 mt-0.5">“${esc(p.review_note)}”</span>` : ''}
        </span>
        <i class="fas fa-chevron-down text-slate-300 text-xs transition group-open:rotate-180"></i>
      </summary>
      <div class="mt-3">${stageBody(st, si, false)}</div>
    </details>`;
  }).join('');

  box.innerHTML = hero + progressCard + stageCards;

  // Click once: checked. Click again: unchecked.
  box.querySelectorAll('.js-inst-check').forEach(btn => {
    btn.addEventListener('click', () => updateInstallItem(btn.dataset.item, btn.dataset.status === 'PENDING' ? 'COMPLETED' : 'PENDING', btn));
  });
  box.querySelectorAll('.js-inst-na').forEach(btn => {
    btn.addEventListener('click', () => updateInstallItem(btn.dataset.item, 'NOT_APPLICABLE', btn));
  });
  box.querySelectorAll('.js-inst-remarks').forEach(inp => {
    inp.addEventListener('change', () => updateInstallItem(inp.dataset.item, inp.dataset.status, inp));
  });
  box.querySelectorAll('.js-stage-photo').forEach(input => {
    input.addEventListener('change', () => uploadStagePhoto(jobId, input));
  });
  box.querySelectorAll('.js-stage-photo-del').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!confirm('Remove this photo?')) return;
      btn.disabled = true;
      const res = await apiPost('installation/photo_delete.php', { photo_id: +btn.dataset.id });
      toast(res.message, res.success ? 'success' : 'error');
      await loadInstallation();
    });
  });
  const submitBtn = document.getElementById('stage-submit-btn');
  if (submitBtn) {
    submitBtn.addEventListener('click', async () => {
      const list = submitBtn.dataset.stages.split('|');
      const what = list.length > 1 ? list.join(', ') : list[0];
      if (!confirm(`Submit ${what} for review?\n\n${list.length > 1 ? 'They' : 'It'} will be locked while Management checks ${list.length > 1 ? 'them' : 'it'}.`)) return;
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-1"></i>Submitting...';
      const note = (document.getElementById('stage-submit-note') || {}).value || '';
      let res = null;
      for (const stage of list) { // in order; stop at the first problem
        res = await apiPost('installation/stage_submit.php', { job_id: jobId, stage, note });
        if (!res.success) break;
      }
      toast(res.success && list.length > 1 ? `${list.length} stages submitted. Management will review them and schedule the next visit.` : res.message,
        res.success ? 'success' : 'error');
      await loadInstallation();
      await loadAssignments();
    });
  }
}

/** Shrink a phone photo (often 4000+ px, several MB) before uploading it. */
function shrinkImage(file, maxSide = 1600, quality = 0.82) {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
      const ctx = c.getContext('2d');
      ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
      ctx.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      c.toBlob(b => resolve(b || file), 'image/jpeg', quality);
    };
    img.onerror = () => { URL.revokeObjectURL(url); resolve(file); }; // let the server judge it
    img.src = url;
  });
}

// A proof photo for one installation stage. The phone camera opens directly;
// the photo is shrunk on the phone first to save mobile data.
async function uploadStagePhoto(jobId, input) {
  const file = input.files && input.files[0];
  input.value = '';
  if (!file) return;
  const stage = input.dataset.stage;
  const status = [...document.querySelectorAll('.js-stage-photo-status')].find(el => el.dataset.stage === stage);
  if (status) status.textContent = 'Uploading photo...';
  const blob = await shrinkImage(file);
  const fd = new FormData();
  fd.append('csrf_token', CSRF_TOKEN);
  fd.append('job_id', jobId);
  fd.append('stage', stage);
  fd.append('photo', blob, 'photo.jpg');
  let json;
  try {
    const res = await fetch(API + 'installation/photo_upload.php', { method: 'POST', body: fd });
    json = await res.json();
  } catch (e) {
    json = { success: false, message: 'Upload failed — check your connection and try again.' };
  }
  toast(json.message, json.success ? 'success' : 'error');
  if (!json.success && status) status.textContent = json.message;
  if (json.success) await loadInstallation();
}

let instBusy = false;
async function updateInstallItem(itemId, status, el) {
  if (instBusy) return; // one change at a time keeps the stage order checks honest
  instBusy = true;
  const box = document.getElementById('inst-body');
  const remarksEl = box.querySelector(`.js-inst-remarks[data-item="${itemId}"]`);
  box.querySelectorAll('.js-inst-check, .js-inst-na').forEach(b => b.disabled = true);

  // Show the tick straight away; the reload below confirms it from the server.
  if (el && el.classList.contains('js-inst-check')) {
    const tick = el.querySelector('span');
    const on = status !== 'PENDING';
    if (tick) {
      ['bg-emerald-500', 'border-emerald-500', 'text-white'].forEach(c => tick.classList.toggle(c, on));
      ['bg-white', 'border-slate-300', 'text-transparent'].forEach(c => tick.classList.toggle(c, !on));
    }
    el.setAttribute('aria-checked', String(on));
  }

  const json = await apiPost('installation/update_item.php', {
    item_id: itemId,
    status: status,
    remarks: remarksEl ? remarksEl.value : ''
  });
  instBusy = false;

  if (!json.success) {
    toast(json.message, 'error');
    await loadInstallation();
    return;
  }
  toast(status === 'PENDING' ? `Unchecked — ${json.data.progress}%` : `Checked — ${json.data.progress}%`, 'success');
  await loadInstallation();
  await loadAssignments();
}

// ---- Maintenance inspection: the installation-style checklist -------------
// Sections (Solar Panels, Battery, Inverter), each with its condition, items
// ticked with who / when, and proof photos; then submitted to Management, who
// approves it (the job can be completed) or returns it with a note.
async function loadMaintenance() {
  const box = document.getElementById('maint-body');
  const jobId = state.selected.maint;
  if (!jobId) { box.dataset.job = ''; box.innerHTML = '<div class="kpi-card text-slate-400 text-sm">You have no open maintenance jobs.</div>'; return; }

  // A refresh of the job on screen keeps the page where it is (as Installation does).
  const refreshing = box.dataset.job === String(jobId);
  const scrollY = window.scrollY;
  if (!refreshing) box.innerHTML = '<div class="kpi-card text-slate-400 text-sm">Loading inspection...</div>';
  const json = await apiGet('maintenance/get.php', { job_id: jobId });
  if (jobId !== state.selected.maint) return;
  if (!json.success) { box.dataset.job = ''; box.innerHTML = `<div class="kpi-card text-red-500 text-sm">${esc(json.message)}</div>`; return; }
  const d = json.data, r = d.record;
  if (!r) { box.dataset.job = ''; box.innerHTML = `<div class="kpi-card text-slate-400 text-sm">${esc(json.message || 'No inspection recorded for this job.')}</div>`; return; }
  box.dataset.job = String(jobId);
  if (refreshing) requestAnimationFrame(() => window.scrollTo(0, scrollY));

  const review = d.review || { status: 'OPEN' };
  const canWork = d.editable && !d.locked;
  const niceWhen = v => v ? new Date(String(v).replace(' ', 'T')).toLocaleString('en-PH', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : '';
  const groups = {};
  d.items.forEach(it => { (groups[it.category] = groups[it.category] || []).push(it); });
  const sections = (d.sections && d.sections.length) ? d.sections
    : (d.categories || Object.keys(groups)).map(name => ({ name, total: (groups[name] || []).length, resolved: (groups[name] || []).filter(i => i.status !== 'PENDING').length, photos: 0, condition: null, condition_field: null }));
  const photosBy = {};
  (d.photos || []).forEach(p => { (photosBy[p.section] = photosBy[p.section] || []).push(p); });
  const resolved = sections.reduce((n, s) => n + s.resolved, 0), total = sections.reduce((n, s) => n + s.total, 0);
  const withCond = sections.filter(s => s.condition).length, withPhoto = sections.filter(s => s.photos > 0).length;

  // ---- What to do now ----------------------------------------------------------
  const stepLine = (n, text, ok) => `
    <li class="flex items-center gap-2 text-sm ${ok ? 'text-emerald-700' : 'text-slate-700'}">
      <span class="w-6 h-6 shrink-0 rounded-full flex items-center justify-center text-xs font-extrabold ${ok ? 'bg-emerald-500 text-white' : 'bg-slate-200 text-slate-600'}">${ok ? '<i class="fas fa-check"></i>' : n}</span><span class="min-w-0">${text}</span></li>`;
  let hero;
  if (!d.editable) {
    hero = `<div class="kpi-card mb-4 border-2 border-slate-200"><p class="text-xs font-bold uppercase text-slate-500 mb-1"><i class="fas fa-lock mr-1"></i>Closed</p>
      <p class="text-lg font-extrabold text-slate-900">This job is closed — the inspection is read-only.</p></div>`;
  } else if (review.status === 'APPROVED') {
    hero = `<div class="kpi-card mb-4 border-2 border-emerald-200 bg-emerald-50/50">
      <p class="text-xs font-bold uppercase text-emerald-700 mb-1"><i class="fas fa-circle-check mr-1"></i>Inspection approved${review.reviewed_by_name ? ' by ' + esc(review.reviewed_by_name) : ''}</p>
      <p class="text-lg font-extrabold text-slate-900">This maintenance job is ready to be completed</p>
      ${review.review_note ? `<p class="mt-2 text-sm bg-white border border-emerald-100 rounded-lg px-3 py-2"><i class="fas fa-comment-dots mr-1 text-emerald-600"></i>${esc(review.review_note)}</p>` : ''}
      <p class="text-sm text-slate-600 mt-1">File the work report and press <b>${esc(STAGE_LABELS.COMPLETED)}</b> in My Assignments.</p></div>`;
  } else if (review.status === 'SUBMITTED') {
    hero = `<div class="kpi-card mb-4 border-2 border-sky-200 bg-sky-50/40">
      <p class="text-xs font-bold uppercase text-sky-700 mb-1"><i class="fas fa-hourglass-half mr-1"></i>Waiting for Management review</p>
      <p class="text-lg font-extrabold text-slate-900">Inspection submitted${review.submitted_at ? ' on ' + esc(niceWhen(review.submitted_at)) : ''}</p>
      <p class="text-sm text-slate-600 mt-1">Nothing to do here for now. You will be notified when it is approved or returned.</p></div>`;
  } else {
    const returned = review.status === 'RETURNED';
    const ready = !d.submit_blocker && d.checklist_ready;
    hero = `<div class="kpi-card mb-4 border-2 ${returned ? 'border-red-200' : 'border-suntrackOrange/40'}">
      <p class="text-xs font-bold uppercase ${returned ? 'text-red-600' : 'text-suntrackOrange'} mb-1">
        ${returned ? '<i class="fas fa-rotate-left mr-1"></i>Returned — please fix and submit again' : '<i class="fas fa-calendar-day mr-1"></i>Today\'s work'} · Maintenance inspection</p>
      <p class="text-xl font-extrabold text-slate-900">${sections.map(s => esc(s.name)).join(' <span class="text-slate-300">+</span> ')}</p>
      ${returned && review.review_note ? `<p class="mt-2 text-sm bg-red-50 border border-red-100 text-red-700 rounded-lg px-3 py-2"><i class="fas fa-comment-dots mr-1"></i><b>Management:</b> ${esc(review.review_note)}</p>` : ''}
      <ol class="mt-3 space-y-2">
        ${stepLine(1, `Tick every item below <span class="text-slate-400">(${resolved}/${total})</span>`, resolved === total)}
        ${stepLine(2, `Record each part's condition <span class="text-slate-400">(${withCond} of ${sections.length})</span>`, withCond === sections.length)}
        ${d.checklist_ready ? stepLine(3, `Add at least one proof photo for each part <span class="text-slate-400">(${withPhoto} of ${sections.length})</span>`, withPhoto === sections.length) : ''}
        ${d.checklist_ready ? stepLine(4, 'Submit it so Management can review it', false) : ''}
      </ol>
      ${d.checklist_ready && d.is_lead !== false ? `
      <textarea id="maint-submit-note" rows="2" maxlength="500" class="field mt-3 !text-sm" placeholder="Note for Management (optional) — e.g. inverter fan noisy, recommend replacement"></textarea>
      <button type="button" id="maint-submit-btn" class="primary-btn w-full mt-2 ${ready ? '' : 'opacity-50'}" ${ready ? '' : 'disabled'}>
        <i class="fas fa-paper-plane mr-1"></i>Submit inspection for review</button>
      ${ready ? '' : `<p class="text-[11px] text-slate-400 text-center mt-1">${esc(d.submit_blocker || 'Finish the steps above to submit.')}</p>`}` : ''}
    </div>`;
  }

  // ---- Progress across the sections ----------------------------------------------
  const pill = (s, i) => {
    const look = s.done && review.status === 'APPROVED' ? ['bg-emerald-500 text-white', '<i class="fas fa-check"></i>', 'Approved']
      : review.status === 'SUBMITTED' ? ['bg-sky-500 text-white', '<i class="fas fa-hourglass-half"></i>', 'In review']
      : s.done ? ['bg-emerald-500 text-white', '<i class="fas fa-check"></i>', 'Ready']
      : s.resolved || s.photos ? ['bg-suntrackOrange text-white', i + 1, `${s.resolved}/${s.total} items`]
      : ['bg-slate-200 text-slate-500', i + 1, 'Not started'];
    return `<div class="flex-1 min-w-0 text-center">
      <span class="mx-auto w-8 h-8 rounded-full flex items-center justify-center text-xs font-extrabold ${look[0]}">${look[1]}</span>
      <p class="mt-1 text-[11px] font-bold text-slate-700 leading-tight truncate">${esc(s.name)}</p>
      <p class="text-[10px] text-slate-400 leading-tight truncate">${esc(look[2])}</p></div>`;
  };
  const progressCard = `
    <div class="kpi-card mb-4">
      <div class="flex items-start justify-between gap-3 flex-wrap mb-3">
        <div class="min-w-0">
          <p class="font-extrabold text-slate-900">${esc(d.job.job_code)}</p>
          <p class="text-xs text-slate-500">${esc(d.client.name)} · ${esc(d.job.site_address || '')}</p>
          ${d.solar_system ? `<p class="text-[11px] text-slate-400">System ${esc(d.solar_system.system_code)} · ${esc(d.solar_system.capacity_kw)} kW · ${esc(d.solar_system.panel_brand || '')} / ${esc(d.solar_system.inverter_brand || '')} / ${esc(d.solar_system.battery_brand || '')}</p>` : ''}
        </div>
        ${stageBadge(d.job.stage)}
      </div>
      <div class="flex items-start gap-1">${sections.map(pill).join('')}</div>
      <div class="mt-3">
        <div class="flex items-center justify-between text-xs mb-1"><span class="text-slate-500 font-semibold">Inspection progress</span>
          <span class="font-bold text-slate-800">${d.counts.progress}% · ${d.counts.resolved}/${d.counts.total}</span></div>
        ${progressBar(d.counts.progress)}
      </div>
    </div>`;

  // ---- One section: condition, items, proof photos ---------------------------------
  const condChips = s => !s.condition_field ? '' : `
    <div class="flex items-center gap-1.5 flex-wrap mb-3">
      <span class="text-[11px] font-bold uppercase text-slate-400 mr-1">Condition</span>
      ${(d.condition_values || ['Good', 'Fair', 'Poor']).map(c => {
        const on = s.condition === c;
        const col = { Good: 'bg-emerald-500 border-emerald-500', Fair: 'bg-amber-500 border-amber-500', Poor: 'bg-red-500 border-red-500' }[c];
        return `<button type="button" class="js-maint-cond text-xs font-bold px-3 py-1.5 rounded-lg border ${on ? col + ' text-white' : 'bg-white border-slate-200 text-slate-600'} ${canWork ? '' : 'cursor-default'}"
                  data-field="${s.condition_field}" data-value="${c}" ${canWork ? '' : 'disabled'}>${c}</button>`;
      }).join('')}
      ${!s.condition ? '<span class="text-[11px] text-amber-600 ml-1">not recorded</span>' : ''}
    </div>`;
  const sectionBody = s => {
    const items = groups[s.name] || [];
    const photos = photosBy[s.name] || [];
    const canAddPhoto = canWork && d.checklist_ready && photos.length < (d.photo_max_per_section || 10);
    return `
      ${condChips(s)}
      <div class="space-y-2">
        ${items.map(it => {
          const ticked = it.status !== 'PENDING';
          return `
          <div class="rounded-xl border ${ticked ? 'border-emerald-200 bg-emerald-50/60' : 'border-slate-200 bg-white'} px-3 py-2.5">
            <div class="flex items-start gap-3">
              <button type="button" role="checkbox" aria-checked="${ticked}" data-item="${it.id}" data-status="${it.status}"
                      class="js-maint-check flex items-start gap-3 flex-1 min-w-0 text-left ${canWork ? 'cursor-pointer' : 'cursor-default'}" ${canWork ? '' : 'disabled'}>
                <span class="mt-0.5 w-6 h-6 shrink-0 rounded-md border-2 flex items-center justify-center transition
                             ${ticked ? 'bg-emerald-500 border-emerald-500 text-white' : 'bg-white border-slate-300 text-transparent'}">
                  <i class="fas ${it.status === 'NOT_APPLICABLE' ? 'fa-minus' : 'fa-check'} text-xs"></i>
                </span>
                <span class="min-w-0">
                  <span class="block text-sm font-semibold ${ticked ? 'text-slate-500 line-through decoration-emerald-400' : 'text-slate-800'}">${esc(it.description)}</span>
                  <span class="block text-[11px] text-slate-400">
                    ${it.status === 'NOT_APPLICABLE' ? '<span class="font-semibold text-slate-500">Not applicable</span> · ' : ''}${it.completed_date ? esc(fmtDate(it.completed_date)) : ''}${it.completed_by_name ? ' · ' + esc(it.completed_by_name) : ''}
                  </span>
                </span>
              </button>
              ${canWork && !ticked ? `<button type="button" class="js-maint-na shrink-0 text-[11px] font-semibold text-slate-400 hover:text-slate-600 border border-slate-200 rounded-lg px-2 py-1" data-item="${it.id}" title="Mark as not applicable for this site">N/A</button>` : ''}
            </div>
            ${canWork || it.remarks ? `<input class="field js-maint-remarks mt-2 !text-xs !py-1.5" data-item="${it.id}" data-status="${it.status}"
                   placeholder="Remarks (optional)" value="${esc(it.remarks || '')}" ${canWork ? '' : 'disabled'}>` : ''}
          </div>`;
        }).join('')}
      </div>
      ${d.checklist_ready ? `
      <div class="mt-3 pt-3 border-t border-slate-100">
        <div class="flex items-center justify-between gap-2 mb-2">
          <p class="text-xs font-bold text-slate-600"><i class="fas fa-camera text-suntrackOrange mr-1"></i>Proof photos
            <span class="font-normal ${photos.length || !canWork ? 'text-slate-400' : 'text-amber-600'}">· ${photos.length ? photos.length + ' added' : 'at least 1 required'}</span></p>
          ${canAddPhoto ? `<label class="primary-btn !py-2 !px-3 text-xs cursor-pointer"><i class="fas fa-camera mr-1"></i>Take photo
              <input type="file" accept="image/*" capture="environment" class="hidden js-maint-photo" data-section="${esc(s.name)}"></label>` : ''}
        </div>
        ${photos.length ? `<div class="grid grid-cols-4 sm:grid-cols-6 gap-2">${photos.map(p => `
          <div class="relative">
            <a href="${esc(p.url)}" target="_blank" rel="noopener"><img src="${esc(p.url)}" alt="${esc(s.name)} photo" loading="lazy" class="w-full aspect-square object-cover rounded-lg border border-slate-200"></a>
            ${canWork ? `<button type="button" class="js-maint-photo-del absolute -top-1.5 -right-1.5 h-6 w-6 rounded-full bg-red-500 text-white text-xs" data-id="${p.id}" title="Remove"><i class="fas fa-xmark"></i></button>` : ''}
          </div>`).join('')}</div>` : '<p class="text-[11px] text-slate-400">No photos yet.</p>'}
        <p class="js-maint-photo-status text-[11px] text-slate-400 mt-1" data-section="${esc(s.name)}"></p>
      </div>` : ''}`;
  };
  const sectionCards = sections.map((s, i) => `
    <div class="kpi-card mb-4 ${canWork ? 'ring-2 ring-suntrackOrange/40' : ''}">
      <div class="flex items-center justify-between gap-3 mb-3">
        <p class="text-sm font-extrabold text-slate-800">${i + 1}. ${esc(s.name)} <span class="font-semibold text-slate-400">· ${s.resolved}/${s.total}</span></p>
        ${s.done ? '<span class="badge bg-emerald-100 text-emerald-700"><i class="fas fa-check mr-1"></i>Ready</span>'
          : canWork ? '<span class="badge bg-amber-100 text-amber-700"><i class="fas fa-person-digging mr-1"></i>Work on this</span>' : ''}
      </div>
      ${sectionBody(s)}
    </div>`).join('');

  // ---- Findings: what the client and the office read ----------------------------
  const dis = canWork ? '' : 'disabled';
  const findings = `
    <div class="kpi-card mb-4">
      <h4 class="font-bold text-slate-900 mb-3">Findings</h4>
      <div class="grid md:grid-cols-2 gap-3">
        <div><label class="lbl">Electrical condition</label>
          <select id="mt-electrical" class="field" ${dis}><option value="">Not recorded</option>
            ${(d.condition_values || []).map(c => `<option value="${c}" ${r.electrical_condition === c ? 'selected' : ''}>${c}</option>`).join('')}</select></div>
        <div class="hidden md:block"></div>
        <div><label class="lbl">Inspection results</label><textarea id="mt-results" rows="3" class="field" ${dis} placeholder="What you checked and what you found...">${esc(r.inspection_results || '')}</textarea></div>
        <div><label class="lbl">Issues found</label><textarea id="mt-issues" rows="3" class="field" ${dis} placeholder="Faults, wear, anything needing follow-up...">${esc(r.issues_found || '')}</textarea></div>
        <div><label class="lbl">Materials used</label><textarea id="mt-materials" rows="2" class="field" ${dis} placeholder="e.g. 1 DC fuse, cleaning solution">${esc(r.materials_used || '')}</textarea></div>
        <div><label class="lbl">Remarks</label><textarea id="mt-remarks" rows="2" class="field" ${dis} placeholder="Notes for the office or the client">${esc(r.remarks || '')}</textarea></div>
      </div>
      ${canWork ? '<button id="mt-save" class="primary-btn mt-4"><i class="fas fa-floppy-disk mr-1"></i>Save findings</button>' : ''}
    </div>`;

  box.innerHTML = hero + progressCard + sectionCards + findings;

  // Click once: checked. Click again: unchecked.
  box.querySelectorAll('.js-maint-check').forEach(b => b.addEventListener('click', () => updateMaintItem(b.dataset.item, b.dataset.status === 'PENDING' ? 'COMPLETED' : 'PENDING', b)));
  box.querySelectorAll('.js-maint-na').forEach(b => b.addEventListener('click', () => updateMaintItem(b.dataset.item, 'NOT_APPLICABLE', b)));
  box.querySelectorAll('.js-maint-remarks').forEach(inp => inp.addEventListener('change', () => updateMaintItem(inp.dataset.item, inp.dataset.status, inp)));
  box.querySelectorAll('.js-maint-cond').forEach(b => b.addEventListener('click', () => saveMaintenance(b, { [b.dataset.field]: b.dataset.value })));
  box.querySelectorAll('.js-maint-photo').forEach(inp => inp.addEventListener('change', () => uploadMaintPhoto(jobId, inp)));
  box.querySelectorAll('.js-maint-photo-del').forEach(b => b.addEventListener('click', async () => {
    if (!confirm('Remove this photo?')) return;
    b.disabled = true;
    const res = await apiPost('maintenance/photo_delete.php', { photo_id: +b.dataset.id });
    toast(res.message, res.success ? 'success' : 'error');
    await loadMaintenance();
  }));
  const saveBtn = document.getElementById('mt-save');
  if (saveBtn) saveBtn.addEventListener('click', e => {
    const val = id => { const el = document.getElementById(id); return el ? el.value : ''; };
    saveMaintenance(e.currentTarget, { electrical_condition: val('mt-electrical'), inspection_results: val('mt-results'),
      issues_found: val('mt-issues'), materials_used: val('mt-materials'), remarks: val('mt-remarks') });
  });
  const submitBtn = document.getElementById('maint-submit-btn');
  if (submitBtn) submitBtn.addEventListener('click', async () => {
    if (!confirm('Submit this maintenance inspection for review?\n\nIt will be locked while Management checks it.')) return;
    await lockBtn(submitBtn, '<i class="fas fa-spinner fa-spin mr-1"></i>Submitting...', async () => {
      const res = await apiPost('maintenance/submit.php', { job_id: jobId, note: (document.getElementById('maint-submit-note') || {}).value || '' });
      toast(res.message, res.success ? 'success' : 'error');
    });
    await loadMaintenance();
    await loadAssignments();
  });
}

async function saveMaintenance(btn, fields) {
  await lockBtn(btn, btn.id === 'mt-save' ? '<i class="fas fa-spinner fa-spin mr-1"></i>Saving...' : btn.innerHTML, async () => {
    const json = await apiPost('maintenance/save.php', { job_id: state.selected.maint, ...fields });
    toast(json.success ? (btn.id === 'mt-save' ? 'Findings saved.' : 'Condition recorded.') : json.message, json.success ? 'success' : 'error');
  });
  await loadMaintenance();
  await loadAssignments();
}

// A proof photo for one inspection section — shrunk on the phone first, like installation photos.
async function uploadMaintPhoto(jobId, input) {
  const file = input.files && input.files[0];
  input.value = '';
  if (!file) return;
  const section = input.dataset.section;
  const status = [...document.querySelectorAll('.js-maint-photo-status')].find(el => el.dataset.section === section);
  if (status) status.textContent = 'Uploading photo...';
  const blob = await shrinkImage(file);
  const fd = new FormData();
  fd.append('csrf_token', CSRF_TOKEN);
  fd.append('job_id', jobId);
  fd.append('section', section);
  fd.append('photo', blob, 'photo.jpg');
  let json;
  try {
    const res = await fetch(API + 'maintenance/photo_upload.php', { method: 'POST', body: fd });
    json = await res.json();
  } catch (e) {
    json = { success: false, message: 'Upload failed — check your connection and try again.' };
  }
  toast(json.message, json.success ? 'success' : 'error');
  if (!json.success && status) status.textContent = json.message;
  if (json.success) await loadMaintenance();
}

let maintBusy = false;
async function updateMaintItem(itemId, status, el) {
  if (maintBusy) return;
  maintBusy = true;
  const box = document.getElementById('maint-body');
  const remarksEl = box.querySelector(`.js-maint-remarks[data-item="${itemId}"]`);
  box.querySelectorAll('.js-maint-check, .js-maint-na').forEach(b => b.disabled = true);
  if (el && el.classList.contains('js-maint-check')) { // show the tick straight away
    const tick = el.querySelector('span'), on = status !== 'PENDING';
    if (tick) {
      ['bg-emerald-500', 'border-emerald-500', 'text-white'].forEach(c => tick.classList.toggle(c, on));
      ['bg-white', 'border-slate-300', 'text-transparent'].forEach(c => tick.classList.toggle(c, !on));
    }
  }
  const json = await apiPost('maintenance/update_item.php', { item_id: itemId, status, remarks: remarksEl ? remarksEl.value : '' });
  maintBusy = false;
  if (!json.success) { toast(json.message, 'error'); await loadMaintenance(); return; }
  toast(status === 'PENDING' ? `Unchecked — ${json.data.counts.progress}%` : `Checked — ${json.data.counts.progress}%`, 'success');
  await loadMaintenance();
  await loadAssignments();
}

let wrSearchTimer = null;
document.getElementById('wr-search').addEventListener('input', () => {
  clearTimeout(wrSearchTimer);
  wrSearchTimer = setTimeout(loadWorkReports, 350);
});

async function loadWorkReports() {
  const list = document.getElementById('wr-list');
  const pendBox = document.getElementById('wr-pending');
  list.innerHTML = '<p class="text-slate-400 text-sm">Loading...</p>';

  const search = document.getElementById('wr-search').value.trim();
  const json = await apiGet('work_reports/list.php', search ? { search } : {});
  if (!json.success) { list.innerHTML = `<p class="text-red-500 text-sm">${esc(json.message)}</p>`; return; }

  const rows = json.data.rows;
  const pendingJobs = json.data.pending_jobs || [];

  pendBox.innerHTML = pendingJobs.length ? `
    <div class="kpi-card">
      <h4 class="font-bold text-slate-900 mb-1">Awaiting a report</h4>
      <p class="text-xs text-slate-500 mb-3">These jobs are completed but have no work report yet. One report per job.</p>
      <div class="divide-y divide-slate-100">
        ${pendingJobs.map(j => `
          <div class="py-2.5 flex items-center justify-between gap-3 flex-wrap">
            <div class="min-w-0">
              <p class="text-sm font-semibold text-slate-900">${esc(j.job_code)} <span class="text-slate-400 font-normal">— ${esc(j.job_type)}</span></p>
              <p class="text-xs text-slate-500">${esc(j.client_name)} · completed ${esc(fmtDate(j.updated_at))}</p>
            </div>
            <button class="stage-btn js-report" data-job="${j.id}" data-code="${esc(j.job_code)}" data-type="${esc(j.job_type)}">Submit Report</button>
          </div>`).join('')}
      </div>
    </div>` : '';
  bindJobActions(pendBox);

  list.innerHTML = rows.length ? rows.map(r => `
    <div class="kpi-card">
      <div class="flex items-start justify-between gap-3 flex-wrap mb-2">
        <div>
          <p class="font-extrabold text-slate-900">${esc(r.report_code)}
            <span class="text-slate-400 font-normal text-sm">— ${esc(r.job_code)}</span></p>
          <p class="text-xs text-slate-500">${esc(r.work_type)} · ${esc(r.client_name)} (${esc(r.client_code)})</p>
        </div>
        <div class="flex items-center gap-2 sm:block sm:text-right">
          <span class="badge bg-emerald-100 text-emerald-700">${esc(r.status)}</span>
          <p class="text-xs text-slate-400 sm:mt-1">${esc(fmtDate(r.submitted_date))}</p>
        </div>
      </div>
      <p class="text-sm text-slate-700">${esc(r.remarks)}</p>
      <div class="grid md:grid-cols-3 gap-2 mt-3 text-xs">
        <p class="text-slate-500"><span class="font-semibold text-slate-700">Materials:</span> ${esc(r.materials_used || '—')}</p>
        <p class="text-slate-500"><span class="font-semibold text-slate-700">Issues:</span> ${esc(r.issues_found || 'None')}</p>
        <p class="text-slate-500"><span class="font-semibold text-slate-700">Duration:</span> ${esc(r.duration_text || fmtDuration(r.duration_minutes))}</p>
      </div>
    </div>`).join('')
    : '<div class="kpi-card text-slate-400 text-sm">No work reports found.</div>';
}

// ---- Work report form --------------------------------------------------------
let reportIssues = 'no'; // 'no' | 'yes'
const rptEl = id => document.getElementById(id);
function rptSelect(selector, value) {
  document.querySelectorAll(selector).forEach(b => b.classList.toggle('chip-on', b.dataset.value === value));
}
function rptSetIssues(v) {
  reportIssues = v;
  rptSelect('.js-ri-chip', v);
  rptEl('report-issues').classList.toggle('hidden', v !== 'yes');
  rptEl('report-issues-err').classList.add('hidden');
  if (v === 'yes') rptEl('report-issues').focus();
}

function openReportModal(jobId, jobCode, jobType) {
  const job = (state.assignments || []).find(j => String(j.id) === String(jobId));
  rptEl('report-modal-title').textContent = 'Work Report — ' + jobCode;
  rptEl('report-modal-sub').textContent = (job ? job.client_name + ' · ' : '') + 'Takes about a minute. * = required.';
  rptEl('report-job-id').value = jobId;
  const typeMap = { INSTALLATION: 'Installation', MAINTENANCE: 'Maintenance', REPAIR: 'Repair', INSPECTION: 'Inspection' };
  rptEl('report-work-type').value = typeMap[jobType] || 'Installation';
  rptSelect('.js-rt-chip', rptEl('report-work-type').value);
  ['report-remarks', 'report-materials', 'report-issues', 'report-duration'].forEach(id => rptEl(id).value = '');
  rptSelect('.js-rd-chip', null);
  rptSetIssues('no');
  ['report-modal-error', 'report-remarks-err'].forEach(id => rptEl(id).classList.add('hidden'));
  rptEl('report-remarks-count').textContent = '0 characters';
  rptEl('report-modal').classList.remove('hidden');
  setTimeout(() => rptEl('report-remarks').focus(), 50);
}

document.querySelectorAll('.js-rt-chip').forEach(b => b.addEventListener('click', () => {
  rptEl('report-work-type').value = b.dataset.value;
  rptSelect('.js-rt-chip', b.dataset.value);
}));
document.querySelectorAll('.js-ri-chip').forEach(b => b.addEventListener('click', () => rptSetIssues(b.dataset.value)));
document.querySelectorAll('.js-rd-chip').forEach(b => b.addEventListener('click', () => {
  rptEl('report-duration').value = b.dataset.value;
  rptSelect('.js-rd-chip', b.dataset.value);
}));
rptEl('report-duration').addEventListener('input', () => rptSelect('.js-rd-chip', rptEl('report-duration').value.trim()));
rptEl('report-remarks').addEventListener('input', () => {
  const n = rptEl('report-remarks').value.trim().length;
  rptEl('report-remarks-count').textContent = n + ' character' + (n === 1 ? '' : 's');
  if (n >= 5) rptEl('report-remarks-err').classList.add('hidden');
});
rptEl('report-issues').addEventListener('input', () => rptEl('report-issues-err').classList.add('hidden'));

const closeReport = () => rptEl('report-modal').classList.add('hidden');
rptEl('report-cancel').addEventListener('click', closeReport);
rptEl('report-close').addEventListener('click', closeReport);

document.getElementById('report-save').addEventListener('click', async (e) => {
  const errBox = document.getElementById('report-modal-error');
  errBox.classList.add('hidden');
  const remarks = rptEl('report-remarks').value.trim();
  const issuesText = rptEl('report-issues').value.trim();
  let bad = null;
  if (remarks.length < 5) { rptEl('report-remarks-err').classList.remove('hidden'); bad = bad || rptEl('report-remarks'); }
  if (reportIssues === 'yes' && !issuesText) { rptEl('report-issues-err').classList.remove('hidden'); bad = bad || rptEl('report-issues'); }
  if (bad) { bad.focus(); bad.scrollIntoView({ block: 'center', behavior: 'smooth' }); return; }

  await lockBtn(e.currentTarget, 'Submitting...', async () => {
    const json = await apiPost('work_reports/create.php', {
      job_id: rptEl('report-job-id').value,
      work_type: rptEl('report-work-type').value,
      remarks,
      materials_used: rptEl('report-materials').value.trim(),
      issues_found: reportIssues === 'yes' ? issuesText : 'None',
      duration: rptEl('report-duration').value.trim()
    });
    if (!json.success) {
      errBox.textContent = json.message;
      errBox.classList.remove('hidden');
      return;
    }
    document.getElementById('report-modal').classList.add('hidden');
    toast(json.message, 'success');
    await loadAssignments();
    if (state.tab === 'work-reports') await loadWorkReports();
  });
});

let histTimer = null;
document.getElementById('hist-search').addEventListener('input', () => {
  clearTimeout(histTimer);
  histTimer = setTimeout(loadHistory, 350);
});
document.getElementById('hist-stage').addEventListener('change', loadHistory);

async function loadHistory() {
  const box = document.getElementById('hist-list');
  box.innerHTML = '<p class="text-slate-400 text-sm">Loading...</p>';

  const params = {};
  const search = document.getElementById('hist-search').value.trim();
  const stage = document.getElementById('hist-stage').value;
  if (search) params.search = search;
  if (stage) params.stage = stage;

  const json = await apiGet('technician/history.php', params);
  if (!json.success) { box.innerHTML = `<p class="text-red-500 text-sm">${esc(json.message)}</p>`; return; }

  const rows = json.data.rows;
  box.innerHTML = rows.length ? rows.map(r => `
    <div class="kpi-card">
      <div class="flex items-start justify-between gap-3 flex-wrap">
        <div class="min-w-0">
          <p class="font-extrabold text-slate-900">${esc(r.job_code)} <span class="text-slate-400 font-normal text-sm">— ${esc(r.job_type)}</span></p>
          <p class="text-xs text-slate-500">${esc(r.client_name)} (${esc(r.client_code)}) · ${esc(r.site_address || '')}</p>
        </div>
        <div class="flex gap-2 items-center flex-wrap">
          ${stageBadge(r.stage)}
          <button class="ghost-btn js-timeline" data-job="${r.id}">Timeline</button>
        </div>
      </div>
      <div class="grid grid-cols-2 md:grid-cols-5 gap-3 text-xs mt-3">
        <div><p class="text-slate-400 font-semibold uppercase">Date</p><p class="text-slate-800 font-semibold">${esc(r.scheduled_date || fmtDate(r.updated_at))}</p></div>
        <div><p class="text-slate-400 font-semibold uppercase">Time In</p><p class="text-slate-800 font-semibold">${esc(fmtDate(r.time_in))}</p></div>
        <div><p class="text-slate-400 font-semibold uppercase">Time Out</p><p class="text-slate-800 font-semibold">${esc(fmtDate(r.time_out))}</p></div>
        <div><p class="text-slate-400 font-semibold uppercase">Duration</p><p class="text-slate-800 font-semibold">${esc(r.duration_text || fmtDuration(r.duration_minutes))}</p></div>
        <div><p class="text-slate-400 font-semibold uppercase">Work Report</p><p class="text-slate-800 font-semibold">${r.report_code ? esc(r.report_code) : '<span class="text-amber-600">Not filed</span>'}</p></div>
      </div>
      <div class="mt-3">
        <div class="flex items-center justify-between text-xs mb-1"><span class="text-slate-500 font-semibold">Progress</span><span class="font-bold text-slate-800">${r.progress}%</span></div>
        ${progressBar(r.progress)}
      </div>
      <div class="js-timeline-box mt-4 hidden" data-job="${r.id}"></div>
    </div>`).join('')
    : '<div class="kpi-card text-slate-400 text-sm">No completed or cancelled jobs yet.</div>';

  box.querySelectorAll('.js-timeline').forEach(btn => {
    btn.addEventListener('click', () => toggleTimeline(btn, +btn.dataset.job));
  });
}

async function toggleTimeline(btn, jobId) {
  const target = document.querySelector(`.js-timeline-box[data-job="${jobId}"]`);
  if (!target) return;
  if (!target.classList.contains('hidden')) { target.classList.add('hidden'); return; }

  target.classList.remove('hidden');
  target.innerHTML = '<p class="text-slate-400 text-sm">Loading timeline...</p>';

  const json = await apiGet('technician/history.php', { job_id: jobId });
  if (!json.success) { target.innerHTML = `<p class="text-red-500 text-sm">${esc(json.message)}</p>`; return; }

  const t = json.data.timeline;
  target.innerHTML = `
    <p class="text-xs font-bold text-slate-400 uppercase mb-3">Status timeline</p>
    <div class="timeline-line">
      ${t.length ? t.map(h => `
        <div class="flex gap-3">
          <div class="timeline-dot"></div>
          <div class="pb-4">
            <p class="text-sm font-bold text-slate-900">${esc(h.from_stage ? niceStage(h.from_stage) + ' → ' : '')}${esc(niceStage(h.to_stage))}</p>
            <p class="text-xs text-slate-500">${esc(fmtDate(h.created_at))}${h.changed_by_name ? ' · ' + esc(h.changed_by_name) : ''}</p>
            ${h.note ? `<p class="text-xs text-slate-500 italic mt-0.5">${esc(h.note)}</p>` : ''}
          </div>
        </div>`).join('') : '<p class="text-slate-400 text-sm">No status history recorded for this job.</p>'}
    </div>`;
}

const AVAIL_META = {
  AVAILABLE: { icon: 'fa-circle-check', cls: 'border-emerald-300 bg-emerald-50 text-emerald-700', desc: 'Ready to accept new assignments.' },
  BUSY:      { icon: 'fa-person-digging', cls: 'border-amber-300 bg-amber-50 text-amber-700',   desc: 'Currently working — dispatch will avoid new jobs.' },
  OFF_DUTY:  { icon: 'fa-mug-hot',       cls: 'border-slate-300 bg-slate-50 text-slate-600',    desc: 'Outside working hours. No new assignments.' },
  ON_LEAVE:  { icon: 'fa-plane',         cls: 'border-sky-300 bg-sky-50 text-sky-700',          desc: 'On approved leave.' }
};

async function loadAvailability() {
  const box = document.getElementById('avail-body');
  box.innerHTML = '<p class="text-slate-400 text-sm">Loading...</p>';

  const json = await apiGet('technician/availability.php');
  if (!json.success) { box.innerHTML = `<p class="text-red-500 text-sm">${esc(json.message)}</p>`; return; }

  const d = json.data;
  box.innerHTML = `
    <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
      ${d.options.map(o => {
        const m = AVAIL_META[o];
        const active = o === d.status;
        return `
        <button class="js-avail text-left border-2 rounded-2xl p-4 transition ${active ? m.cls : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'}" data-status="${o}">
          <i class="fas ${m.icon} text-lg mb-2"></i>
          <p class="font-extrabold text-sm">${esc(niceStage(o))}</p>
          <p class="text-xs mt-1 opacity-80">${esc(m.desc)}</p>
          ${active ? '<p class="text-[11px] font-bold mt-2"><i class="fas fa-check mr-1"></i>Current</p>' : ''}
        </button>`;
      }).join('')}
    </div>
    <p class="text-xs text-slate-400 mt-4">Last updated: ${esc(fmtDate(d.updated_at))} · ${d.open_jobs} open job(s)</p>
    ${d.active_jobs.length ? `
      <div class="bg-amber-50 border border-amber-200 text-amber-700 text-xs rounded-lg px-3 py-2 mt-3">
        Active field work: ${d.active_jobs.map(j => esc(j.job_code) + ' (' + esc(niceStage(j.stage)) + ')').join(', ')}.
        You cannot go Off Duty or On Leave until these are completed or paused.
      </div>` : ''}`;

  box.querySelectorAll('.js-avail').forEach(btn => {
    btn.addEventListener('click', () => setAvailability(btn, btn.dataset.status));
  });
}

async function setAvailability(btn, status) {
  if (status === 'OFF_DUTY' || status === 'ON_LEAVE') {
    const ok = await confirmDialog('Change availability?',
      `Dispatch will see you as ${niceStage(status)} and will stop assigning you new work.`, 'Yes, change it');
    if (!ok) return;
  }
  await lockBtn(btn, '<i class="fas fa-spinner fa-spin"></i>', async () => {
    const json = await apiPost('technician/availability.php', { status });
    toast(json.message, json.success ? 'success' : 'error');
    await loadAvailability();
    await loadAssignments();
  });
}

async function loadProfile() {
  const box = document.getElementById('profile-body');
  box.innerHTML = '<p class="text-slate-400 text-sm">Loading...</p>';

  const json = await apiGet('technician/profile.php');
  if (!json.success) { box.innerHTML = `<p class="text-red-500 text-sm">${esc(json.message)}</p>`; return; }
  const p = json.data;

  box.innerHTML = `
    <div class="grid md:grid-cols-3 gap-3">
      <div><label class="lbl">Full name</label><input id="pf-name" class="field" value="${esc(p.full_name)}"></div>
      <div><label class="lbl">Phone</label><input id="pf-phone" class="field" value="${esc(p.phone || '')}"></div>
      <div><label class="lbl">Email</label><input id="pf-email" type="email" class="field" value="${esc(p.email)}"></div>
    </div>
    <div class="grid md:grid-cols-4 gap-3 mt-4">
      <div><label class="lbl">Technician code</label><input class="field bg-slate-50" value="${esc(p.technician_code)}" disabled></div>
      <div><label class="lbl">Specialization</label><input class="field bg-slate-50" value="${esc(p.specialization || '—')}" disabled></div>
      <div><label class="lbl">Geofencing</label><input class="field bg-slate-50" value="${p.geofence_enabled ? 'Enabled' : 'Disabled'}" disabled></div>
      <div><label class="lbl">Account status</label><input class="field bg-slate-50" value="${esc(p.account_status)}" disabled></div>
    </div>
    <p class="text-xs text-slate-400 mt-3">Greyed-out fields are managed by the office and cannot be changed here. Last sign-in: ${esc(fmtDate(p.last_login))}</p>
    <button id="pf-save" class="primary-btn mt-4"><i class="fas fa-floppy-disk mr-1"></i>Save Profile</button>`;

  document.getElementById('pf-save').addEventListener('click', e => saveProfile(e.currentTarget));
}

async function saveProfile(btn) {
  await lockBtn(btn, '<i class="fas fa-spinner fa-spin mr-1"></i>Saving...', async () => {
    const json = await apiPost('technician/profile.php', {
      full_name: document.getElementById('pf-name').value.trim(),
      phone: document.getElementById('pf-phone').value.trim(),
      email: document.getElementById('pf-email').value.trim()
    });
    toast(json.message, json.success ? 'success' : 'error');
    if (json.success) loadProfile();
  });
}

document.getElementById('pw-save').addEventListener('click', async (e) => {
  const current = document.getElementById('pw-current').value;
  const next = document.getElementById('pw-new').value;
  const confirmVal = document.getElementById('pw-confirm').value;

  if (!current || !next || !confirmVal) { toast('Fill in all three password fields.', 'error'); return; }
  if (next !== confirmVal) { toast('The new password and its confirmation do not match.', 'error'); return; }
  if (next.length < 8) { toast('New password must be at least 8 characters.', 'error'); return; }

  await lockBtn(e.currentTarget, 'Updating...', async () => {
    const json = await apiPost('technician/change_password.php', {
      current_password: current, new_password: next, confirm_password: confirmVal
    });
    toast(json.message, json.success ? 'success' : 'error');
    if (json.success) {
      ['pw-current','pw-new','pw-confirm'].forEach(id => document.getElementById(id).value = '');
    }
  });
});

function startPolling() {
  if (state.pollTimer) clearInterval(state.pollTimer);
  state.pollTimer = setInterval(() => {
    if (document.hidden) return;
    if (['dashboard','assignments','site-map','service-requests'].includes(state.tab)) {
      loadAssignments().then(() => {
        if (state.tab === 'site-map') drawMap();
        if (state.tab === 'service-requests') loadTechServiceRequests();
      });
    }
  }, 30000);
}

/* ---------------- Service Requests (Phase 5) ---------------- */
const SR_STATUS_COLORS = {
  ASSIGNED:'bg-indigo-100 text-indigo-700', SCHEDULED:'bg-violet-100 text-violet-700', IN_PROGRESS:'bg-amber-100 text-amber-700',
  ON_HOLD:'bg-slate-200 text-slate-700', COMPLETED:'bg-emerald-100 text-emerald-700', CANCELLED:'bg-red-100 text-red-700',
  APPROVED:'bg-blue-100 text-blue-700', PENDING:'bg-slate-100 text-slate-600', REJECTED:'bg-red-100 text-red-700'
};
const tsrOpenHistory = new Set();
let tsrLoading = false;

async function loadTechServiceRequests() {
  if (tsrLoading) return;
  tsrLoading = true;
  const box = document.getElementById('tsr-list');
  try {
    const filter = document.getElementById('tsr-filter').value;
    const params = {};
    if (filter === 'open') params.open = 1; else if (filter) params.status = filter;
    const search = document.getElementById('tsr-search').value.trim();
    if (search) params.search = search;

    const json = await apiGet('service_requests/list.php', params);
    if (!json.success) { box.innerHTML = `<div class="kpi-card text-red-500 text-sm">${esc(json.message)}</div>`; return; }
    if (!json.data.length) {
      box.innerHTML = '<div class="kpi-card text-slate-400 text-sm">No service requests here. New ones appear as soon as Management assigns them to you.</div>';
      return;
    }

    // Keep anything the technician is typing across a live refresh.
    const drafts = {};
    box.querySelectorAll('textarea[data-draft]').forEach(t => { if (t.value) drafts[t.id] = t.value; });

    box.innerHTML = json.data.map(sr => tsrCard(sr)).join('');
    Object.keys(drafts).forEach(id => { const el = document.getElementById(id); if (el) el.value = drafts[id]; });

    bindJobActions(box);
    box.querySelectorAll('.js-tsr-note').forEach(b => b.addEventListener('click', () => saveTechSr(b, +b.dataset.id, 'NOTE')));
    box.querySelectorAll('.js-tsr-res').forEach(b => b.addEventListener('click', () => saveTechSr(b, +b.dataset.id, 'RESOLUTION')));
    box.querySelectorAll('.js-tsr-hist').forEach(b => b.addEventListener('click', () => {
      const id = b.dataset.id;
      if (tsrOpenHistory.has(id)) tsrOpenHistory.delete(id); else tsrOpenHistory.add(id);
      document.getElementById('tsr-hist-' + id).classList.toggle('hidden', !tsrOpenHistory.has(id));
      if (tsrOpenHistory.has(id)) loadTechSrHistory(id);
    }));
    box.querySelectorAll('.js-tsr-map').forEach(b => b.addEventListener('click', () => { state.selected.map = +b.dataset.job; showTab('site-map'); }));
    tsrOpenHistory.forEach(id => loadTechSrHistory(id));
  } finally {
    tsrLoading = false;
  }
}

function tsrCard(sr) {
  const job = sr.job_id ? state.assignments.find(j => j.id === Number(sr.job_id)) : null;
  const lat = sr.map_lat, lng = sr.map_lng;
  const hasLoc = lat !== null && lat !== undefined && lng !== null && lng !== undefined;
  const closed = ['COMPLETED', 'CANCELLED', 'REJECTED'].includes(sr.status);
  const addr = sr.site_address || [sr.client_address, sr.barangay, sr.client_city, sr.client_province].filter(Boolean).join(', ');

  let jobBlock = '';
  if (job) {
    // The job buttons below are the existing field workflow (Start Travel, Time In, Start Work, Work Report, Complete...).
    jobBlock = `
      <div class="border-t border-slate-100 pt-3 mt-3">
        <div class="flex items-center gap-2 flex-wrap mb-2 text-xs">
          <span class="font-bold text-slate-700">Job ${esc(job.job_code)}</span>${stageBadge(job.stage)}${geofenceChip(job)}
          ${job.timed_in ? '<span class="badge bg-emerald-100 text-emerald-700"><i class="fas fa-clock mr-1"></i>Timed in</span>' : ''}
        </div>
        <div class="mb-2">${progressBar(job.progress)}</div>
        <p class="text-xs mb-2 js-feedback" id="feedback-${job.id}"></p>
        <div class="flex items-center gap-2 flex-wrap">${jobActionsHtml(job)}</div>
      </div>`;
  } else if (sr.job_code) {
    jobBlock = `<p class="text-xs text-slate-500 border-t border-slate-100 pt-3 mt-3">Job ${esc(sr.job_code)} · ${esc(niceStage(sr.job_stage))}</p>`;
  }

  return `
  <div class="kpi-card">
    <div class="flex items-start justify-between gap-3 flex-wrap mb-2">
      <div class="min-w-0">
        <p class="font-extrabold text-slate-900">${esc(sr.request_code)} <span class="text-slate-400 font-normal text-sm">— ${esc(sr.request_type)}</span></p>
        <p class="text-sm font-semibold text-slate-700 mt-0.5">${esc(sr.subject || '')}</p>
      </div>
      <div class="flex items-center gap-2 flex-wrap justify-end">
        <span class="badge ${SR_STATUS_COLORS[sr.status] || 'bg-slate-100 text-slate-600'}">${esc(niceStage(sr.status))}</span>
        <span class="badge ${PRIORITY_COLORS[sr.priority] || 'bg-slate-100 text-slate-500'}">${esc(sr.priority)}</span>
      </div>
    </div>
    <p class="text-sm text-slate-600 whitespace-pre-line">${esc(sr.description || '')}</p>

    <div class="grid md:grid-cols-2 gap-3 mt-3 text-xs">
      <div class="bg-slate-50 rounded-xl p-3">
        <p class="text-slate-400 font-semibold uppercase mb-1">Client</p>
        <p class="font-bold text-slate-800 text-sm">${esc(sr.client_name)} <span class="text-slate-400 font-normal">(${esc(sr.client_code)})</span></p>
        <p>${sr.client_phone ? `<a class="text-suntrackOrange font-semibold" href="tel:${esc(sr.client_phone)}"><i class="fas fa-phone mr-1"></i>${esc(sr.client_phone)}</a>` : '—'}</p>
        <p class="text-slate-600 mt-1"><i class="fas fa-location-dot mr-1"></i>${esc(addr || 'No address recorded')}</p>
        <p class="text-slate-400 mt-1">${hasLoc ? `${Number(lat).toFixed(6)}, ${Number(lng).toFixed(6)}` : 'No coordinates'}</p>
        <div class="flex items-center gap-4 mt-1">
          ${hasLoc ? `<a class="font-bold text-sky-600" target="_blank" rel="noopener" href="https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}">Directions</a>` : ''}
          ${job && job.has_coordinates ? `<button class="font-bold text-suntrackOrange js-tsr-map" data-job="${job.id}">Show on Site Map</button>` : ''}
          ${job && job.sr_checklist ? `<button class="primary-btn !py-1.5 !px-3 text-xs" onclick="openSrChecklist(${job.id})"><i class="fas fa-list-check mr-1"></i>Open Checklist</button>` : ''}
        </div>
      </div>
      <div class="bg-slate-50 rounded-xl p-3">
        <p class="text-slate-400 font-semibold uppercase mb-1">Schedule</p>
        <p><span class="text-slate-400">Requested:</span> <b>${esc(fmtDate(sr.date_requested))}</b></p>
        <p><span class="text-slate-400">Scheduled:</span> <b>${esc(sr.scheduled_date || 'Not set')}</b></p>
        <p><span class="text-slate-400">Completed:</span> <b>${esc(fmtDate(sr.completion_date))}</b></p>
      </div>
    </div>

    ${sr.technician_notes ? `<div class="mt-3"><p class="lbl">My notes</p><p class="text-xs text-slate-700 whitespace-pre-line bg-amber-50 rounded-lg p-3">${esc(sr.technician_notes)}</p></div>` : ''}

    ${sr.status === 'CANCELLED' || sr.status === 'REJECTED' ? '' : `
    <div class="grid md:grid-cols-2 gap-3 mt-3">
      <div>
        <label class="lbl" for="tsr-note-${sr.id}">Add a progress note</label>
        <textarea id="tsr-note-${sr.id}" data-draft rows="2" maxlength="1000" class="field" placeholder="e.g. Replaced MC4 connector, monitoring output..."></textarea>
        <button class="ghost-btn mt-2 js-tsr-note" data-id="${sr.id}"><i class="fas fa-plus mr-1"></i>Add note</button>
      </div>
      <div>
        <label class="lbl" for="tsr-res-${sr.id}">Resolution</label>
        <textarea id="tsr-res-${sr.id}" data-draft rows="2" maxlength="5000" class="field" placeholder="What was found and what was done">${esc(sr.resolution || '')}</textarea>
        <button class="ghost-btn mt-2 js-tsr-res" data-id="${sr.id}"><i class="fas fa-floppy-disk mr-1"></i>Save resolution</button>
      </div>
    </div>`}
    ${!closed && !job && !sr.job_code ? '<p class="text-xs text-amber-600 mt-3">No job is linked to this request yet. Ask Management to re-assign it.</p>' : ''}

    ${jobBlock}

    <button class="text-xs font-bold text-slate-500 mt-3 js-tsr-hist" data-id="${sr.id}"><i class="fas fa-clock-rotate-left mr-1"></i>History</button>
    <div id="tsr-hist-${sr.id}" class="${tsrOpenHistory.has(String(sr.id)) ? '' : 'hidden'} mt-2"></div>
  </div>`;
}

async function loadTechSrHistory(id) {
  const box = document.getElementById('tsr-hist-' + id);
  if (!box) return;
  const json = await apiGet('service_requests/detail.php', { id });
  if (!json.success) { box.innerHTML = `<p class="text-xs text-red-500">${esc(json.message)}</p>`; return; }
  box.innerHTML = json.data.history.length ? '<div class="timeline-line">' + json.data.history.map(h => `
    <div class="flex gap-3">
      <div class="timeline-dot"></div>
      <div class="pb-3 min-w-0">
        <p class="text-sm font-bold text-slate-900">${esc(niceStage(h.action))}${h.old_status && h.new_status && h.old_status !== h.new_status ? ` <span class="text-xs font-normal text-slate-500">${esc(niceStage(h.old_status))} → ${esc(niceStage(h.new_status))}</span>` : ''}</p>
        <p class="text-xs text-slate-500">${esc(fmtDate(h.created_at))}${h.user_name ? ' · ' + esc(h.user_name) : ''}</p>
        ${h.remarks ? `<p class="text-xs text-slate-500 italic mt-0.5 whitespace-pre-line">${esc(h.remarks)}</p>` : ''}
      </div>
    </div>`).join('') + '</div>' : '<p class="text-xs text-slate-400">No history yet.</p>';
}

async function saveTechSr(btn, id, action) {
  const el = document.getElementById((action === 'NOTE' ? 'tsr-note-' : 'tsr-res-') + id);
  const text = el ? el.value.trim() : '';
  if (!text) { toast(action === 'NOTE' ? 'Type a note first.' : 'Type the resolution first.', 'error'); return; }
  await lockBtn(btn, '<i class="fas fa-spinner fa-spin"></i>', async () => {
    const json = await apiPost('service_requests/technician_update.php', { id, action, text });
    toast(json.message, json.success ? 'success' : 'error');
    if (json.success) {
      if (action === 'NOTE' && el) el.value = '';
      await loadTechServiceRequests();
    }
  });
}

document.getElementById('tsr-filter').addEventListener('change', () => loadTechServiceRequests());
let tsrSearchTimer = null;
document.getElementById('tsr-search').addEventListener('input', () => {
  clearTimeout(tsrSearchTimer);
  tsrSearchTimer = setTimeout(() => loadTechServiceRequests(), 350);
});

(async function boot() {
  renderGpsStrip();
  // Tell the technician up front if this connection cannot do GPS at all,
  // rather than letting them discover it when they try to time in at a site.
  if (window.SunTrackMobile && !SunTrackMobile.isSecure()) {
    SunTrackMobile.warnInsecure('Location access');
  }

  await loadAssignments();
  startPolling();
  if (gpsSupported()) {
    const pos = await refreshPosition(true);
    if (pos) loadAssignments();
  }
})();
</script>

<?php include ROOT_PATH . '/includes/consent_banner.php'; ?>
</body>
</html>
