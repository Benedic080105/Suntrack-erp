<?php
require_once __DIR__ . '/../middleware/admin.php';

$navItems = [
    ['key' => 'dashboard', 'label' => 'Dashboard', 'icon' => 'fa-gauge-high', 'wired' => true],
    ['key' => 'clients', 'label' => 'Clients', 'icon' => 'fa-users', 'wired' => true],
    ['key' => 'projects', 'label' => 'Projects', 'icon' => 'fa-diagram-project', 'wired' => true, 'summary' => true],
    ['key' => 'technicians', 'label' => 'Technician Accounts', 'icon' => 'fa-user-gear', 'wired' => true],
    ['key' => 'staff', 'label' => 'Staff', 'icon' => 'fa-id-badge', 'wired' => true, 'summary' => true],
    ['key' => 'inventory', 'label' => 'Inventory', 'icon' => 'fa-boxes-stacked', 'wired' => true],
    ['key' => 'work-reports', 'label' => 'Work Reports', 'icon' => 'fa-file-lines', 'wired' => true],
    ['key' => 'reports', 'label' => 'Reports', 'icon' => 'fa-chart-column', 'wired' => true],
    ['key' => 'maintenance', 'label' => 'Maintenance Reminders', 'icon' => 'fa-wrench', 'wired' => true, 'summary' => true],
    ['key' => 'service-requests', 'label' => 'Service Requests', 'icon' => 'fa-ticket', 'wired' => true],
    ['key' => 'subcontractors', 'label' => 'Sub-Contractors', 'icon' => 'fa-helmet-safety', 'wired' => true, 'summary' => true],
    ['key' => 'attendance', 'label' => 'Attendance & Geofence', 'icon' => 'fa-location-dot', 'wired' => true],
    ['key' => 'logs', 'label' => 'Logs & Audit', 'icon' => 'fa-clipboard-list', 'wired' => true, 'summary' => true],
    ['key' => 'billing', 'label' => 'Billing', 'icon' => 'fa-file-invoice-dollar', 'wired' => true, 'summary' => true],
    ['key' => 'sitemap', 'label' => 'Site Map', 'icon' => 'fa-map-location-dot', 'wired' => true],
    ['key' => 'account', 'label' => 'Account & Security', 'icon' => 'fa-shield-halved', 'wired' => true],
];
$name = h($_SESSION['full_name']);
$isManagement = in_array($_SESSION['role_key'] ?? '', ['manager', 'staff'], true);
$roleLabel = $isManagement ? 'Management' : 'Admin';
$token = csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SunTrack ERP — Admin</title>
<script src="<?= APP_BASE_URL ?>/assets/vendor/tailwind/tailwind.js"></script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/vendor/fontawesome/css/all.min.css">
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-password.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-logout.js"></script>
<link href="<?= APP_BASE_URL ?>/assets/vendor/inter/inter.css" rel="stylesheet">
<link rel="manifest" href="<?= APP_BASE_URL ?>/manifest.json">
<meta name="theme-color" content="#0b1329">
<link rel="apple-touch-icon" href="<?= APP_BASE_URL ?>/assets/img/app/apple-touch-icon.png">
<script src="<?= APP_BASE_URL ?>/assets/vendor/chartjs/chart.umd.min.js"></script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/vendor/leaflet/leaflet.min.css">
<script src="<?= APP_BASE_URL ?>/assets/vendor/leaflet/leaflet.min.js"></script>
<script>tailwind.config={theme:{extend:{colors:{navy:'#0f172a',solar:'#f97316'},fontFamily:{sans:['Inter','sans-serif']}}}}</script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-realtime.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-paging.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-search.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-pwa.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/vendor/qrcode/qrcode.min.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-account.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-filters.js"></script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/css/suntrack-mobile.css">
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-tables.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-admin-dashboard.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-subcon-mgmt.js"></script>
<style>
  body{font-family:'Inter',sans-serif;}
  .kpi-card{background:#fff;border-radius:1rem;padding:1.25rem;box-shadow:0 1px 3px rgba(0,0,0,.06);border:1px solid #eef0f4}
  .badge{font-size:11px;font-weight:700;padding:2px 8px;border-radius:999px}
  select,input{outline:none}
  .modal-backdrop{background:rgba(0,0,0,.4)}
  table.data-table th{font-size:11px;text-transform:uppercase;color:#94a3b8;font-weight:700;text-align:left;padding:8px 10px}
  table.data-table td{padding:10px;font-size:13px;border-top:1px solid #f1f5f9}
  .icon-btn{font-size:12px;color:#475569;padding:4px 8px;border-radius:6px}
  .icon-btn:hover{background:#f1f5f9;color:#f97316}
  .link-btn{font-size:12px;font-weight:600;cursor:pointer}
  .chart-box{position:relative;height:260px}
  .mini-kpi{background:#fff;border-radius:.85rem;padding:.9rem 1rem;box-shadow:0 1px 3px rgba(0,0,0,.06);border:1px solid #eef0f4}
  .view-only-note{font-size:11px;color:#94a3b8;background:#f8fafc;border:1px dashed #e2e8f0;border-radius:.6rem;padding:6px 10px}
  /* Filter toolbar: one height (40px), one label style, everything sits on the
     same bottom line — including the Search and Clear buttons added by
     suntrack-search.js / suntrack-filters.js. */
  .st-toolbar{display:flex;flex-wrap:wrap;align-items:flex-end;gap:12px}
  .st-toolbar > div:not(.st-tb-checks) > label{display:block;font-size:12px;line-height:16px;font-weight:600;color:#64748b;margin-bottom:6px}
  .st-toolbar .st-tb-search{flex:1 1 280px;min-width:240px}
  .st-toolbar input:not([type=checkbox]):not([type=radio]),.st-toolbar select{height:40px;box-sizing:border-box;padding-top:0;padding-bottom:0;font-size:14px;background-color:#fff}
  .st-toolbar .st-tb-checks{height:40px;display:flex;flex-wrap:wrap;align-items:center;gap:8px 16px}
  .st-toolbar .st-tb-checks label{display:inline-flex;align-items:center;gap:6px;margin:0;font-size:12px;font-weight:600;color:#475569;cursor:pointer;white-space:nowrap}
  .st-toolbar .st-tb-checks input{width:16px;height:16px;accent-color:#f97316;cursor:pointer}
  .st-toolbar button{height:40px!important;box-sizing:border-box;display:inline-flex!important;align-items:center;justify-content:center;gap:6px;
                     padding:0 16px!important;font-size:13px!important;font-weight:700!important;border-radius:8px!important;white-space:nowrap;line-height:1}
  .st-toolbar .st-search-btn{border-radius:0 8px 8px 0!important}
  .st-toolbar .st-filter-tools{align-self:flex-end!important;height:40px}
  .st-toolbar .st-tb-end{margin-left:auto}
  /* Dropdown of checkboxes (Site Map layers). Above Leaflet's panes (z 400–1000). */
  .st-toolbar .st-tb-dd{position:relative}
  .st-toolbar #map-layers-btn{width:250px;justify-content:space-between!important;font-weight:600!important;font-size:14px!important}
  .st-toolbar #map-layers-btn span{flex:1;text-align:left;overflow:hidden;text-overflow:ellipsis}
  .st-tb-dd-menu{position:absolute;top:calc(100% + 6px);left:0;z-index:1100;min-width:250px;background:#fff;border:1px solid #e2e8f0;
                 border-radius:12px;box-shadow:0 12px 28px rgba(15,23,42,.14);padding:6px}
  .st-tb-dd-menu label{display:flex!important;align-items:center;gap:8px;padding:9px 10px;margin:0!important;border-radius:8px;
                       font-size:13px!important;font-weight:600;color:#334155!important;cursor:pointer;white-space:nowrap}
  .st-tb-dd-menu label:hover{background:#f8fafc}
  .st-tb-dd-menu input{width:16px;height:16px;accent-color:#f97316;cursor:pointer}
  .st-toolbar .st-tb-dd-menu .st-tb-dd-all{height:32px!important;width:100%;margin-top:4px;padding:0 10px!important;font-size:12px!important;
                       color:#f97316;background:#fff7ed;border:0;justify-content:center}
</style>
</head>
<body class="bg-slate-50 min-h-screen flex flex-col md:flex-row">

<!-- Phone top bar: on small screens the sidebar becomes a slide-out menu instead of stacking above the page. -->
<div class="md:hidden sticky top-0 z-30 bg-navy border-b border-slate-800/60 px-3 py-3 flex items-center justify-between">
  <button id="mobile-menu-btn" type="button" aria-label="Open menu" aria-controls="app-sidebar" aria-expanded="false" class="text-slate-300 hover:text-white p-2 -ml-2 rounded-lg">
    <i class="fas fa-bars text-lg"></i>
  </button>
  <div class="flex items-center gap-2">
    <div class="bg-solar p-1.5 rounded-lg text-white"><i class="fas fa-solar-panel text-sm"></i></div>
    <span class="text-white font-extrabold text-sm">SunTrack Admin Console</span>
  </div>
  <a href="<?= APP_BASE_URL ?>/logout.php" title="Logout" class="text-slate-400 hover:text-solar p-2 -mr-2"><i class="fas fa-right-from-bracket"></i></a>
</div>
<div id="sidebar-backdrop" class="hidden md:hidden fixed inset-0 bg-black/50 z-40"></div>
<aside id="app-sidebar" class="w-64 max-w-[85vw] bg-navy text-slate-400 flex flex-col justify-between p-4 border-r border-slate-800/40 shrink-0 fixed inset-y-0 left-0 z-50 overflow-y-auto -translate-x-full transition-transform duration-300 ease-in-out md:translate-x-0 md:z-auto md:h-screen md:sticky md:top-0">
  <div>
    <div class="flex items-center gap-2 px-2 mb-6">
      <div class="bg-solar p-2 rounded-xl text-white shadow-lg shadow-orange-600/20"><i class="fas fa-solar-panel text-lg"></i></div>
      <div><p class="text-white font-extrabold text-sm leading-tight">SunTrack</p><p class="text-[10px] text-slate-500 leading-tight">Management Console</p></div>
    </div>
    <nav class="space-y-1 overflow-y-auto max-h-[70vh] pr-1">
      <?php foreach ($navItems as $item): $active = $item['key'] === 'dashboard'; ?>
        <a href="#" data-tab="<?= h($item['key']) ?>"
           class="tab-link flex items-center justify-between gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition <?= $active ? 'bg-solar text-white shadow-md shadow-orange-600/20' : 'hover:bg-slate-800/60 text-slate-300' ?>">
          <span class="flex items-center gap-3"><i class="fas <?= h($item['icon']) ?> w-4"></i><?= h($item['label']) ?></span>
          <?php if (empty($item['wired'])): ?>
            <span class="text-[9px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded-md">soon</span>
          <?php elseif (!empty($item['summary'])): ?>
            <span class="text-[9px] bg-sky-900/60 text-sky-300 px-1.5 py-0.5 rounded-md" title="Admin is view & export only — changes are made in the Management portal">view</span>
          <?php endif; ?>
        </a>
      <?php endforeach; ?>
    </nav>
  </div>
  <div class="bg-slate-900 border border-slate-800/60 rounded-2xl p-3 mt-6 flex items-center gap-3 shadow-inner">
    <div class="h-9 w-9 rounded-xl bg-solar flex items-center justify-center text-white text-sm font-bold"><?= h(initial($name)) ?></div>
    <div class="flex-1 min-w-0"><p class="text-white text-xs font-bold truncate"><?= $name ?></p><p class="text-[10px] text-slate-500"><?= h(current_role()) ?></p></div>
    <a href="<?= APP_BASE_URL ?>/logout.php" title="Logout" class="text-slate-400 hover:text-solar"><i class="fas fa-right-from-bracket"></i></a>
  </div>
</aside>
<script>
// Phone menu: open/close the sidebar drawer; picking a tab closes it again.
(function () {
  var btn = document.getElementById('mobile-menu-btn'), aside = document.getElementById('app-sidebar'), backdrop = document.getElementById('sidebar-backdrop');
  if (!btn || !aside || !backdrop) return;
  function setOpen(open) {
    aside.classList.toggle('-translate-x-full', !open);
    backdrop.classList.toggle('hidden', !open);
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  btn.addEventListener('click', function () { setOpen(aside.classList.contains('-translate-x-full')); });
  backdrop.addEventListener('click', function () { setOpen(false); });
  aside.addEventListener('click', function (e) { if (e.target.closest('.tab-link') && window.innerWidth < 768) setOpen(false); });
  window.addEventListener('resize', function () { if (window.innerWidth >= 768) setOpen(false); });
})();
</script>

<main class="flex-1 min-w-0 p-4 md:p-8">
  <header class="flex items-center justify-between mb-6">
    <div>
      <h1 id="page-title" class="text-2xl md:text-3xl font-extrabold text-slate-900">Admin</h1>
      <p id="page-sub" class="text-slate-500 text-sm mt-1">Company-wide numbers, live from MySQL.</p>
    </div>
    <div class="flex items-center gap-3">
    <span class="hidden md:inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-full <?= $isManagement ? 'bg-navy/10 text-navy' : 'bg-sky-100 text-sky-700' ?>" title="<?= $isManagement ? 'Management: full add / edit / manage access.' : 'Admin: view & export reports and summaries only.' ?>">
      <i class="fas <?= $isManagement ? 'fa-user-gear' : 'fa-eye' ?>"></i> <?= h($roleLabel) ?> Side
    </span>
    <span id="live-indicator" class="inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-full bg-emerald-100 text-emerald-700" title="Live — this page updates itself as other users make changes.">
      <span id="live-dot" class="h-2 w-2 rounded-full bg-emerald-500"></span> <span id="live-text">Live</span>
    </span>
    <button id="btn-add" class="hidden bg-solar hover:bg-orange-600 text-white text-sm font-bold px-4 py-2.5 rounded-xl shadow-lg shadow-orange-600/20">
      <i class="fas fa-plus mr-1"></i> <span id="btn-add-label">Add</span>
    </button>
    </div>
  </header>

  <!-- DASHBOARD -->
  <section id="tab-dashboard" class="tab-panel">
    <!-- Drawn by assets/js/suntrack-admin-dashboard.js from api/dashboard/admin.php -->
    <div id="sad-root"></div>
  </section>

  <!-- SERVICE REQUESTS -->
  <section id="tab-service-requests" class="tab-panel hidden">
    <div class="kpi-card mb-4">
      <div class="st-toolbar">
        <div>
          <label class="block text-xs font-semibold text-slate-500 mb-1">Status</label>
          <select id="sr-filter-status" class="rounded-lg border border-slate-200 text-sm px-3 py-2">
            <option value="">All</option><option value="PENDING">Pending</option><option value="APPROVED">Approved</option>
            <option value="ASSIGNED">Assigned</option><option value="SCHEDULED">Scheduled</option>
            <option value="IN_PROGRESS">In Progress</option><option value="ON_HOLD">On Hold</option>
            <option value="COMPLETED">Completed</option><option value="CANCELLED">Cancelled</option><option value="REJECTED">Rejected</option>
          </select>
        </div>
        <div class="st-tb-search">
          <label>Search</label>
          <input id="sr-filter-search" type="text" placeholder="Code, type, client, city, technician..." class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2">
        </div>
        <button id="sr-filter-btn" class="bg-navy hover:bg-slate-800 text-white"><i class="fas fa-filter"></i> Filter</button>
        <button id="sr-export-btn" class="st-tb-end border border-slate-200 bg-white text-slate-600 hover:border-solar hover:text-solar"><i class="fas fa-file-csv"></i> Export CSV</button>
      </div>
    </div>
    <div class="kpi-card"><div id="admin-sr-list" class="divide-y divide-slate-100 text-sm"></div></div>
  </section>

  <!-- INVENTORY -->
  <section id="tab-inventory" class="tab-panel hidden">
    <div class="kpi-card mb-4">
      <div class="st-toolbar">
        <div class="st-tb-search"><label>Search</label>
          <input id="inv-search" type="text" placeholder="SKU, name, brand, model, serial, location..." class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Category</label>
          <select id="inv-filter-category" class="rounded-lg border border-slate-200 text-sm px-3 py-2"><option value="">All</option><option>Solar Panel</option><option>Inverter</option><option>Battery</option></select></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Status</label>
          <select id="inv-filter-status" class="rounded-lg border border-slate-200 text-sm px-3 py-2"><option value="">All</option><option>ACTIVE</option><option>LOW_STOCK</option><option>OUT_OF_STOCK</option><option>DISCONTINUED</option></select></div>
        <button id="inv-filter-btn" class="bg-navy hover:bg-slate-800 text-white"><i class="fas fa-filter"></i> Filter</button>
        <button id="inv-export-btn" class="st-tb-end border border-slate-200 bg-white text-slate-600 hover:border-solar hover:text-solar"><i class="fas fa-file-csv"></i> Export CSV</button>
      </div>
    </div>
    <div class="kpi-card overflow-x-auto">
      <table class="data-table w-full">
        <thead><tr><th>SKU</th><th>Item</th><th>Category</th><th>Qty</th><th>Unit Cost</th><th>Location</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody id="inv-table-body"></tbody>
      </table>
      <p id="inv-empty" class="hidden text-slate-400 text-sm py-6 text-center">No inventory items match your filters.</p>
    </div>
  </section>

  <!-- CLIENTS -->
  <section id="tab-clients" class="tab-panel hidden">
    <div class="kpi-card mb-4">
      <div class="st-toolbar">
        <div class="st-tb-search"><label>Search</label>
          <input id="cl-search" type="text" placeholder="Name, code, phone, email, address, city..." class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Status</label>
          <select id="cl-filter-status" class="rounded-lg border border-slate-200 text-sm px-3 py-2"><option value="">All</option><option value="ACTIVE">Active</option><option value="INACTIVE">Inactive</option></select></div>
        <button id="cl-filter-btn" class="bg-navy hover:bg-slate-800 text-white"><i class="fas fa-filter"></i> Filter</button>
        <button id="cl-export-btn" class="st-tb-end border border-slate-200 bg-white text-slate-600 hover:border-solar hover:text-solar"><i class="fas fa-file-csv"></i> Export CSV</button>
      </div>
    </div>
    <div class="kpi-card overflow-x-auto">
      <table class="data-table w-full">
        <thead><tr><th>Code</th><th>Name</th><th>Email / Phone</th><th>City</th><th>Systems</th><th>Open Requests</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody id="cl-table-body"></tbody>
      </table>
      <p id="cl-empty" class="hidden text-slate-400 text-sm py-6 text-center">No clients match your filters.</p>
    </div>
  </section>

  <!-- TECHNICIANS -->
  <section id="tab-technicians" class="tab-panel hidden">
    <div class="kpi-card mb-4">
      <div class="st-toolbar">
        <div class="st-tb-search"><label>Search</label>
          <input id="tc-search" type="text" placeholder="Name, code, phone, email, specialization..." class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Status</label>
          <select id="tc-filter-status" class="rounded-lg border border-slate-200 text-sm px-3 py-2"><option value="">All</option><option value="ACTIVE">Active</option><option value="INACTIVE">Inactive</option></select></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Availability</label>
          <select id="tc-filter-avail" class="rounded-lg border border-slate-200 text-sm px-3 py-2"><option value="">All</option><option>AVAILABLE</option><option>BUSY</option><option>OFF_DUTY</option><option>ON_LEAVE</option></select></div>
        <button id="tc-filter-btn" class="bg-navy hover:bg-slate-800 text-white"><i class="fas fa-filter"></i> Filter</button>
        <button id="tc-export-btn" class="st-tb-end border border-slate-200 bg-white text-slate-600 hover:border-solar hover:text-solar"><i class="fas fa-file-csv"></i> Export CSV</button>
      </div>
    </div>
    <div class="kpi-card overflow-x-auto">
      <table class="data-table w-full">
        <thead><tr><th>Code</th><th>Name</th><th>Email / Phone</th><th>Specialization</th><th>Open Jobs</th><th>Availability</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody id="tc-table-body"></tbody>
      </table>
      <p id="tc-empty" class="hidden text-slate-400 text-sm py-6 text-center">No technicians match your filters.</p>
    </div>
  </section>

  <!-- ATTENDANCE & GEOFENCE -->
  <section id="tab-attendance" class="tab-panel hidden">
    <div class="kpi-card mb-4">
      <div class="st-toolbar">
        <div class="st-tb-search"><label>Search</label>
          <input id="att-search" type="text" placeholder="Technician, job code, or site address..." class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Geofence Status</label>
          <select id="att-filter-geofence" class="rounded-lg border border-slate-200 text-sm px-3 py-2"><option value="">All</option><option value="INSIDE">Inside</option><option value="OUTSIDE">Outside</option></select></div>
        <div class="st-tb-checks">
          <input id="att-filter-open" type="checkbox">
          <label for="att-filter-open">Currently timed in only</label>
        </div>
        <button id="att-filter-btn" class="bg-navy hover:bg-slate-800 text-white"><i class="fas fa-filter"></i> Filter</button>
        <button id="att-export-btn" class="st-tb-end border border-slate-200 bg-white text-slate-600 hover:border-solar hover:text-solar"><i class="fas fa-file-csv"></i> Export CSV</button>
      </div>
    </div>
    <div class="kpi-card overflow-x-auto">
      <table class="data-table w-full">
        <thead><tr><th>Technician</th><th>Job</th><th>Time In</th><th>Time Out</th><th>Distance In</th><th>Distance Out</th><th>Geofence</th></tr></thead>
        <tbody id="att-table-body"></tbody>
      </table>
      <p id="att-empty" class="hidden text-slate-400 text-sm py-6 text-center">No attendance records match your filters.</p>
    </div>
  </section>

  <!-- REPORTS (same as the Management Reports tab: preview + CSV) -->
  <section id="tab-reports" class="tab-panel hidden">
    <p class="text-slate-500 text-sm mb-4">Pick a report to preview it below. The filters apply to both the preview and the CSV download.</p>
    <div class="mb-3 space-y-2">
      <div class="flex items-center gap-2">
        <select id="rep-type" class="shrink-0 border border-slate-200 rounded-lg px-3 py-2 text-sm font-semibold" aria-label="Report">
          <?php foreach (report_definitions() as $key => $def): ?>
          <option value="<?= htmlspecialchars($key) ?>"><?= htmlspecialchars($def['label']) ?></option>
          <?php endforeach; ?>
        </select>
        <input id="rep-search" type="search" placeholder="Search..." aria-label="Search" class="border border-slate-200 rounded-lg px-3 py-2 text-sm flex-1 min-w-0">
        <button id="rep-export-btn" class="shrink-0 whitespace-nowrap bg-solar hover:bg-orange-600 disabled:opacity-60 text-white text-sm font-bold px-4 py-2 rounded-xl" onclick="exportReport(this)"><i class="fas fa-download mr-1"></i> Export CSV</button>
      </div>
      <div class="flex flex-wrap gap-2 items-center">
        <select id="rep-status" class="border border-slate-200 rounded-lg px-3 py-2 text-sm" aria-label="Status"></select>
        <span id="rep-dates" class="inline-flex items-center gap-1">
          <input id="rep-from" type="date" class="border border-slate-200 rounded-lg px-3 py-2 text-sm">
          <span class="text-slate-400 text-xs">to</span>
          <input id="rep-to" type="date" class="border border-slate-200 rounded-lg px-3 py-2 text-sm">
        </span>
        <button id="rep-clear" class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold px-3 py-2 rounded-lg hidden" onclick="clearReportFilters()"><i class="fas fa-xmark mr-1"></i> Clear filters</button>
        <button class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold px-3 py-2 rounded-lg" title="Refresh" onclick="loadReport()"><i class="fas fa-rotate"></i></button>
      </div>
    </div>
    <p id="rep-summary" class="text-xs text-slate-500 mb-2 min-h-[1rem]" aria-live="polite"></p>
    <div id="rep-table-wrap" class="kpi-card !p-0 overflow-x-auto transition-opacity">
      <table id="report-preview-table" class="w-full data-table">
        <thead id="rep-thead"></thead>
        <tbody id="rep-tbody"></tbody>
      </table>
    </div>
  </section>

  <!-- WORK REPORTS -->
  <section id="tab-work-reports" class="tab-panel hidden">
    <div class="kpi-card mb-4">
      <div class="st-toolbar">
        <div class="st-tb-search"><label>Search</label>
          <input id="wr-search" type="text" placeholder="Report, job, client, technician, work type..." class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <button id="wr-filter-btn" class="bg-navy hover:bg-slate-800 text-white"><i class="fas fa-filter"></i> Filter</button>
        <button id="wr-export-btn" class="st-tb-end border border-slate-200 bg-white text-slate-600 hover:border-solar hover:text-solar"><i class="fas fa-file-csv"></i> Export CSV</button>
      </div>
    </div>
    <div id="wr-list" class="space-y-3"></div>
    <p id="wr-empty" class="hidden text-slate-400 text-sm py-6 text-center">No work reports match your search.</p>
  </section>

  <!-- STAFF -->
  <section id="tab-staff" class="tab-panel hidden">
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Total Staff</p><p id="stf-k-total" class="text-xl font-extrabold text-slate-900 mt-1">—</p></div>
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Active</p><p id="stf-k-active" class="text-xl font-extrabold text-emerald-600 mt-1">—</p></div>
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">On Leave</p><p id="stf-k-leave" class="text-xl font-extrabold text-amber-500 mt-1">—</p></div>
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Inactive</p><p id="stf-k-inactive" class="text-xl font-extrabold text-slate-400 mt-1">—</p></div>
    </div>
    <div class="kpi-card mb-4"><h3 class="font-bold text-slate-900 mb-3 text-sm">Headcount by Department</h3><div class="chart-box"><canvas id="stf-chart"></canvas></div></div>
    <div class="kpi-card mb-4">
      <div class="st-toolbar">
        <div class="st-tb-search"><label>Search</label>
          <input id="stf-search" type="text" placeholder="Name, code, phone, email, department, position..." class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Status</label>
          <select id="stf-filter-status" class="rounded-lg border border-slate-200 text-sm px-3 py-2"><option value="">All</option><option value="ACTIVE">Active</option><option value="ON_LEAVE">On Leave</option><option value="INACTIVE">Inactive</option></select></div>
        <button id="stf-filter-btn" class="bg-navy hover:bg-slate-800 text-white"><i class="fas fa-filter"></i> Filter</button>
        <button id="stf-export-btn" class="st-tb-end border border-slate-200 bg-white text-slate-600 hover:border-solar hover:text-solar"><i class="fas fa-file-csv"></i> Export CSV</button>
      </div>
    </div>
    <div class="kpi-card overflow-x-auto">
      <table class="data-table w-full">
        <thead><tr><th>Code</th><th>Name</th><th>Email / Phone</th><th>Department</th><th>Position</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody id="stf-table-body"></tbody>
      </table>
      <p id="stf-empty" class="hidden text-slate-400 text-sm py-6 text-center">No staff records match your filters.</p>
    </div>
  </section>

  <!-- PROJECTS (view-only summary) -->
  <section id="tab-projects" class="tab-panel hidden">
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Total Projects</p><p id="prj-k-total" class="text-xl font-extrabold text-slate-900 mt-1">—</p></div>
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">In Progress</p><p id="prj-k-progress" class="text-xl font-extrabold text-amber-500 mt-1">—</p></div>
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Completed</p><p id="prj-k-done" class="text-xl font-extrabold text-emerald-600 mt-1">—</p></div>
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Planned / Scheduled</p><p id="prj-k-planned" class="text-xl font-extrabold text-slate-400 mt-1">—</p></div>
    </div>
    <div class="kpi-card mb-4"><h3 class="font-bold text-slate-900 mb-3 text-sm">Projects by Status</h3><div class="chart-box"><canvas id="prj-chart"></canvas></div></div>
    <div class="kpi-card mb-4">
      <div class="st-toolbar">
        <div class="st-tb-search"><label>Search</label>
          <input id="prj-search" type="text" placeholder="Project, site, address, client, technician..." class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Status</label>
          <select id="prj-filter-status" class="rounded-lg border border-slate-200 text-sm px-3 py-2"><option value="">All</option><option>PLANNED</option><option>SCHEDULED</option><option>IN_PROGRESS</option><option>COMPLETED</option><option>MAINTENANCE</option><option>CANCELLED</option></select></div>
        <button id="prj-filter-btn" class="bg-navy hover:bg-slate-800 text-white"><i class="fas fa-filter"></i> Filter</button>
        <button id="prj-export-btn" class="st-tb-end border border-slate-200 bg-white text-slate-600 hover:border-solar hover:text-solar"><i class="fas fa-file-csv"></i> Export CSV</button>
      </div>
    </div>
    <div class="kpi-card overflow-x-auto">
      <table class="data-table w-full">
        <thead><tr><th>Code</th><th>Site</th><th>Client</th><th>Capacity</th><th>Technician</th><th>Progress</th><th>Checklist</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody id="prj-table-body"></tbody>
      </table>
      <p id="prj-empty" class="hidden text-slate-400 text-sm py-6 text-center">No projects match your filters.</p>
    </div>
  </section>

  <!-- MAINTENANCE REMINDERS (view-only summary) -->
  <section id="tab-maintenance" class="tab-panel hidden">
    <p class="view-only-note mb-4"><i class="fas fa-circle-info mr-1"></i> Summary view only — Management schedules maintenance, assigns technicians and notifies clients from the Management portal.</p>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Total Schedules</p><p id="mnt-k-total" class="text-xl font-extrabold text-slate-900 mt-1">—</p></div>
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Upcoming</p><p id="mnt-k-upcoming" class="text-xl font-extrabold text-sky-600 mt-1">—</p></div>
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Due</p><p id="mnt-k-due" class="text-xl font-extrabold text-amber-500 mt-1">—</p></div>
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Overdue</p><p id="mnt-k-overdue" class="text-xl font-extrabold text-red-500 mt-1">—</p></div>
    </div>
    <div class="kpi-card mb-4"><h3 class="font-bold text-slate-900 mb-3 text-sm">Reminders by Status</h3><div class="chart-box"><canvas id="mnt-chart"></canvas></div></div>
    <div class="kpi-card mb-4">
      <div class="st-toolbar">
        <div class="st-tb-search"><label>Search</label>
          <input id="mnt-search" type="text" placeholder="Project, site, client, city..." class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Status</label>
          <select id="mnt-filter-status" class="rounded-lg border border-slate-200 text-sm px-3 py-2"><option value="">All</option><option>UPCOMING</option><option>DUE</option><option>OVERDUE</option></select></div>
        <button id="mnt-filter-btn" class="bg-navy hover:bg-slate-800 text-white"><i class="fas fa-filter"></i> Filter</button>
        <button id="mnt-export-btn" class="st-tb-end border border-slate-200 bg-white text-slate-600 hover:border-solar hover:text-solar"><i class="fas fa-file-csv"></i> Export CSV</button>
      </div>
    </div>
    <div class="kpi-card overflow-x-auto">
      <table class="data-table w-full">
        <thead><tr><th>Project</th><th>Client</th><th>Last Maintenance</th><th>Next Maintenance</th><th>Status</th><th>Client Notified</th></tr></thead>
        <tbody id="mnt-table-body"></tbody>
      </table>
      <p id="mnt-empty" class="hidden text-slate-400 text-sm py-6 text-center">No maintenance schedules match your filters.</p>
    </div>
  </section>

  <!-- SUB-CONTRACTORS: drawn by assets/js/suntrack-subcon-mgmt.js (Admin: view only) -->
  <section id="tab-subcontractors" class="tab-panel hidden"><div id="subcon-root"></div></section>

  <!-- LOGS & AUDIT (view-only viewer) -->
  <section id="tab-logs" class="tab-panel hidden">
    <p class="view-only-note mb-4"><i class="fas fa-circle-info mr-1"></i> Read-only audit trail. Every create, update, approval, assignment, login and logout is recorded here and cannot be edited. Filters also apply to the CSV export.</p>
    <div class="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Total Log Entries</p><p id="log-k-total" class="text-xl font-extrabold text-slate-900 mt-1">—</p></div>
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Today</p><p id="log-k-today" class="text-xl font-extrabold text-sky-600 mt-1">—</p></div>
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Modules Touched</p><p id="log-k-modules" class="text-xl font-extrabold text-slate-400 mt-1">—</p></div>
    </div>
    <div class="kpi-card mb-4"><h3 class="font-bold text-slate-900 mb-3 text-sm">Activity by Module</h3><div class="chart-box"><canvas id="log-chart"></canvas></div></div>
    <div class="kpi-card mb-4">
      <div id="log-toolbar" class="st-toolbar">
        <div class="st-tb-search"><label>Search</label>
          <input id="log-search" type="text" placeholder="Name, role, action, record ID..." title="Type a person's name to see everything they did" class="w-full rounded-lg border border-slate-200 text-sm px-3"></div>
        <div><label>Show</label>
          <select id="log-filter-role" class="rounded-lg border border-slate-200 text-sm px-3" style="width:230px">
            <option value="team">Team work (default)</option>
            <option value="manager">Manager only</option><option value="staff">Staff only</option>
            <option value="technician">Technicians only</option><option value="warehouse">Warehouse only</option>
            <option value="signins">Sign-ins &amp; sign-outs</option>
            <option value="all">Everything (incl. admin &amp; client work)</option>
          </select></div>
        <div><label>From</label>
          <input id="log-filter-from" type="date" class="rounded-lg border border-slate-200 text-sm px-3" style="width:160px"></div>
        <div><label>To</label>
          <input id="log-filter-to" type="date" class="rounded-lg border border-slate-200 text-sm px-3" style="width:160px"></div>
        <button id="log-filter-btn" class="bg-navy hover:bg-slate-800 text-white"><i class="fas fa-filter"></i> Filter</button>
        <button id="log-export-btn" class="st-tb-end border border-slate-200 bg-white text-slate-600 hover:border-solar hover:text-solar"><i class="fas fa-file-csv"></i> Export CSV</button>
      </div>
    </div>
    <div class="kpi-card overflow-x-auto">
      <table class="data-table w-full">
        <thead><tr><th class="w-36">When</th><th>Who</th><th>What</th><th>Record</th></tr></thead>
        <tbody id="log-table-body"></tbody>
      </table>
      <p id="log-empty" class="hidden text-slate-400 text-sm py-6 text-center">No log entries match your filters.</p>
      <p class="text-slate-400 text-[11px] mt-2">Latest 200 entries. Sign-ins and admin / client activity are hidden by default — choose them under <b>Show</b>. Nothing is ever deleted. Hover a time to see the IP address.</p>
    </div>
  </section>

  <!-- BILLING (view-only summary) -->
  <section id="tab-billing" class="tab-panel hidden">
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Total Invoiced</p><p id="bill-k-total" class="text-xl font-extrabold text-slate-900 mt-1">—</p></div>
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Paid</p><p id="bill-k-paid" class="text-xl font-extrabold text-emerald-600 mt-1">—</p></div>
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Pending</p><p id="bill-k-pending" class="text-xl font-extrabold text-amber-500 mt-1">—</p></div>
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Overdue</p><p id="bill-k-overdue" class="text-xl font-extrabold text-red-500 mt-1">—</p></div>
    </div>
    <div class="kpi-card mb-4"><h3 class="font-bold text-slate-900 mb-3 text-sm">Amount by Payment Status</h3><div class="chart-box"><canvas id="bill-chart"></canvas></div></div>
    <div class="kpi-card mb-4">
      <div class="st-toolbar">
        <div class="st-tb-search"><label>Search</label>
          <input id="bill-search" type="text" placeholder="Invoice, client, project, payment reference..." class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Status</label>
          <select id="bill-filter-status" class="rounded-lg border border-slate-200 text-sm px-3 py-2"><option value="">All</option><option>PENDING</option><option>PAID</option><option>OVERDUE</option><option>CANCELLED</option></select></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Due From</label>
          <input id="bill-date-from" type="date" class="rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Due To</label>
          <input id="bill-date-to" type="date" class="rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <button id="bill-filter-btn" class="bg-navy hover:bg-slate-800 text-white"><i class="fas fa-filter"></i> Filter</button>
        <button id="bill-export-btn" class="st-tb-end border border-slate-200 bg-white text-slate-600 hover:border-solar hover:text-solar"><i class="fas fa-file-csv"></i> Export CSV</button>
      </div>
      <p class="text-slate-400 text-[11px] mt-2">Use the date range to pull up historical billing for a past period.</p>
    </div>
    <div class="kpi-card overflow-x-auto">
      <table class="data-table w-full">
        <thead><tr><th>Invoice</th><th>Client</th><th>Project</th><th>Amount</th><th>Due Date</th><th>Status</th><th>Paid On</th><th>Actions</th></tr></thead>
        <tbody id="bill-table-body"></tbody>
      </table>
      <p id="bill-empty" class="hidden text-slate-400 text-sm py-6 text-center">No invoices match your filters.</p>
    </div>
  </section>

  <!-- SITE MAP — live geofence view -->
  <section id="tab-sitemap" class="tab-panel hidden">
    <div class="grid grid-cols-2 md:grid-cols-5 gap-4 mb-4">
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Clients Pinned</p><p class="text-xl font-extrabold text-slate-900 mt-1"><span id="map-k-pinned">—</span><span id="map-k-clients" class="text-sm font-bold text-slate-400"></span></p></div>
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Open Job Sites</p><p id="map-k-jobs" class="text-xl font-extrabold text-slate-900 mt-1">—</p></div>
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Technicians Tracked</p><p id="map-k-tracked" class="text-xl font-extrabold text-slate-900 mt-1">—</p></div>
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Inside Geofence</p><p id="map-k-inside" class="text-xl font-extrabold text-emerald-600 mt-1">—</p></div>
      <div class="mini-kpi"><p class="text-xs font-semibold text-slate-500 uppercase">Outside Geofence</p><p id="map-k-outside" class="text-xl font-extrabold text-red-500 mt-1">—</p></div>
    </div>
    <div class="kpi-card mb-4">
      <div class="st-toolbar">
        <div class="st-tb-search"><label>Search</label>
          <input id="map-search" type="text" placeholder="Client, technician, job code, city..." class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div class="st-tb-dd" id="map-layers-dd">
          <label>Show on map</label>
          <button type="button" id="map-layers-btn" class="border border-slate-200 bg-white text-slate-700 hover:border-solar" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-layer-group text-slate-400"></i><span id="map-layers-text">All layers</span><i class="fas fa-chevron-down text-[10px] text-slate-400"></i>
          </button>
          <div id="map-layers-menu" class="st-tb-dd-menu hidden" role="menu">
            <label><input type="checkbox" id="map-layer-clients" checked autocomplete="off"> <i class="fas fa-house text-slate-500 w-4 text-center"></i> Client pins &amp; geofences</label>
            <label><input type="checkbox" id="map-layer-jobs" checked autocomplete="off"> <i class="fas fa-circle text-orange-500 w-4 text-center text-[10px]"></i> Open job sites</label>
            <label><input type="checkbox" id="map-layer-techs" checked autocomplete="off"> <i class="fas fa-user-gear text-emerald-500 w-4 text-center"></i> Technicians</label>
            <button type="button" id="map-layers-all" class="st-tb-dd-all">Show all</button>
          </div>
        </div>
        <button id="map-filter-btn" class="bg-navy hover:bg-slate-800 text-white"><i class="fas fa-filter"></i> Filter</button>
      </div>
    </div>
    <div class="grid grid-cols-1 lg:grid-cols-4 gap-4">
      <div class="lg:col-span-3 kpi-card" style="padding:0;overflow:hidden">
        <div id="site-map" style="height:560px;width:100%"></div>
      </div>
      <div class="kpi-card flex flex-col" style="max-height:560px">
        <h3 class="font-bold text-slate-900 text-sm mb-1">Technicians in the field</h3>
        <p class="text-[11px] text-slate-400 mb-3">Live position from their phone's geofence pings. Click one to find them on the map.</p>
        <div id="map-tech-list" class="space-y-2 overflow-y-auto flex-1 min-h-0"></div>
        <div id="map-noloc-wrap" class="hidden mt-3 pt-3 border-t border-slate-100">
          <h4 class="text-[11px] font-bold text-slate-500 uppercase mb-2">In the field — no location yet</h4>
          <div id="map-noloc-list" class="space-y-1 text-xs text-slate-500 max-h-40 overflow-y-auto"></div>
        </div>
        <div class="mt-3 pt-3 border-t border-slate-100 grid grid-cols-2 gap-x-3 gap-y-1.5 text-[11px] text-slate-500">
          <span class="flex items-center gap-1.5"><i class="fas fa-house text-slate-800 w-3"></i> Client pin</span>
          <span class="flex items-center gap-1.5"><span class="inline-block h-3 w-3 rounded-full border-2 border-sky-500 bg-sky-500/10"></span> Geofence</span>
          <span class="flex items-center gap-1.5"><span class="inline-block h-2.5 w-2.5 rounded-full" style="background:#f97316"></span> Job assigned</span>
          <span class="flex items-center gap-1.5"><span class="inline-block h-2.5 w-2.5 rounded-full" style="background:#0ea5e9"></span> Job in field</span>
          <span class="flex items-center gap-1.5"><span class="inline-block h-2.5 w-2.5 rounded-full" style="background:#10b981"></span> Tech inside</span>
          <span class="flex items-center gap-1.5"><span class="inline-block h-2.5 w-2.5 rounded-full" style="background:#ef4444"></span> Tech outside</span>
          <span class="flex items-center gap-1.5 col-span-2"><span class="inline-block h-2.5 w-2.5 rounded-full" style="background:#94a3b8"></span> No recent ping (phone locked / offline)</span>
        </div>
      </div>
    </div>
  </section>

  <section id="tab-fallback" class="tab-panel hidden">
    <div class="kpi-card text-slate-500 text-sm" id="tab-fallback-text">This module's API + full UI wiring lands in the next build phase. The tab and navigation are already in place.</div>
  </section>

  <!-- ACCOUNT & SECURITY (own account only, via api/account/*) -->
  <section id="tab-account" class="tab-panel hidden">
    <div class="grid lg:grid-cols-2 gap-5">
      <div class="kpi-card">
        <h3 class="font-bold text-slate-900 mb-1">Change Password</h3>
        <p class="text-xs text-slate-400 mb-4">You stay signed in on this device.</p>
        <div id="acc-pw-msg" class="hidden text-xs rounded-lg px-3 py-2 mb-3"></div>
        <div class="space-y-3">
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Current Password</label>
            <input id="acc-pw-current" type="password" autocomplete="current-password" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">New Password</label>
            <input id="acc-pw-new" type="password" autocomplete="new-password" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2">
            <p class="text-[11px] text-slate-400 mt-1">At least 8 characters.</p></div>
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Confirm New Password</label>
            <input id="acc-pw-confirm" type="password" autocomplete="new-password" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
          <button id="acc-pw-save" class="w-full rounded-lg bg-navy hover:bg-slate-800 text-white text-sm font-bold px-4 py-2.5">Update Password</button>
        </div>
      </div>
      <div id="twofa-card" class="kpi-card"></div>
      <div class="kpi-card" data-push-card></div>
    </div>
  </section>
</main>

<!-- Assign technician modal (Service Requests) -->
<div id="assign-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-50 p-4">
  <div class="bg-white rounded-2xl p-6 w-full max-w-sm">
    <h3 class="font-bold text-slate-900 mb-1">Assign Technician</h3>
    <p id="assign-sr-code" class="text-xs text-slate-500 mb-4"></p>
    <select id="assign-tech-select" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2 mb-4"></select>
    <div class="flex gap-2">
      <button id="assign-cancel" class="flex-1 border border-slate-200 text-slate-600 text-sm font-semibold py-2 rounded-lg">Cancel</button>
      <button id="assign-confirm" class="flex-1 bg-solar hover:bg-orange-600 text-white text-sm font-semibold py-2 rounded-lg">Assign</button>
    </div>
  </div>
</div>

<!-- Service request details + history (read-only) -->
<div id="sr-detail-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-50 p-4">
  <div class="bg-white rounded-2xl w-full max-w-3xl max-h-[88vh] overflow-y-auto">
    <div class="flex items-center justify-between p-5 border-b border-slate-100">
      <h3 id="sr-detail-title" class="font-bold text-slate-900">Service Request</h3>
      <button id="sr-detail-close" class="text-slate-400 hover:text-slate-700" title="Close"><i class="fas fa-xmark"></i></button>
    </div>
    <div id="sr-detail-body" class="p-5 text-sm"></div>
  </div>
</div>

<!-- Add/Edit Inventory Item Modal -->
<div id="item-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-50 p-4">
  <div class="bg-white rounded-2xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
    <h3 id="item-modal-title" class="font-bold text-slate-900 mb-4">Add Inventory Item</h3>
    <div id="item-modal-error" class="hidden bg-red-50 border border-red-200 text-red-600 text-xs rounded-lg px-3 py-2 mb-3"></div>
    <input type="hidden" id="item-id">
    <div class="space-y-3">
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Item Name</label><input id="item-name" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Category</label>
          <select id="item-category" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"><option>Solar Panel</option><option>Inverter</option><option>Battery</option></select></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Brand</label><input id="item-brand" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Model</label><input id="item-model" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Serial No.</label><input id="item-serial" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Quantity</label><input id="item-qty" type="number" min="0" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Unit Cost</label><input id="item-cost" type="number" step="0.01" min="0" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      </div>
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Warehouse Location</label><input id="item-location" placeholder="e.g. Zone A-01" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
    </div>
    <div class="flex gap-2 mt-5">
      <button id="item-cancel" class="flex-1 border border-slate-200 text-slate-600 text-sm font-semibold py-2 rounded-lg">Cancel</button>
      <button id="item-save" class="flex-1 bg-solar hover:bg-orange-600 text-white text-sm font-semibold py-2 rounded-lg">Save</button>
    </div>
  </div>
</div>

<!-- Receive/Issue/Return Modal -->
<div id="move-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-50 p-4">
  <div class="bg-white rounded-2xl p-6 w-full max-w-sm">
    <h3 id="move-modal-title" class="font-bold text-slate-900 mb-1">Receive Stock</h3>
    <p id="move-modal-item" class="text-xs text-slate-500 mb-4"></p>
    <div id="move-modal-error" class="hidden bg-red-50 border border-red-200 text-red-600 text-xs rounded-lg px-3 py-2 mb-3"></div>
    <input type="hidden" id="move-inv-id">
    <div id="move-job-wrap" class="hidden mb-3"><label class="block text-xs font-semibold text-slate-500 mb-1">Job</label><select id="move-job-select" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></select></div>
    <div class="mb-4"><label class="block text-xs font-semibold text-slate-500 mb-1">Quantity</label><input id="move-qty" type="number" min="1" value="1" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
    <div class="flex gap-2">
      <button id="move-cancel" class="flex-1 border border-slate-200 text-slate-600 text-sm font-semibold py-2 rounded-lg">Cancel</button>
      <button id="move-confirm" class="flex-1 bg-solar hover:bg-orange-600 text-white text-sm font-semibold py-2 rounded-lg">Confirm</button>
    </div>
  </div>
</div>

<!-- History Modal -->
<div id="history-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-50 p-4">
  <div class="bg-white rounded-2xl p-6 w-full max-w-lg max-h-[80vh] overflow-y-auto">
    <div class="flex items-center justify-between mb-4"><h3 id="history-modal-title" class="font-bold text-slate-900">Stock History</h3><button id="history-close" class="text-slate-400 hover:text-slate-600"><i class="fas fa-xmark"></i></button></div>
    <div id="history-list" class="divide-y divide-slate-100 text-sm"></div>
  </div>
</div>

<!-- Project Installation Checklist Modal (view-only) -->
<div id="prj-checklist-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-50 p-4">
  <div class="bg-white rounded-2xl p-6 w-full max-w-lg max-h-[80vh] overflow-y-auto">
    <div class="flex items-center justify-between mb-4"><h3 id="prj-checklist-title" class="font-bold text-slate-900">Installation Checklist</h3><button id="prj-checklist-close" class="text-slate-400 hover:text-slate-600"><i class="fas fa-xmark"></i></button></div>
    <div id="prj-checklist-body" class="text-sm"></div>
  </div>
</div>

<!-- Add/Edit Client Modal -->
<div id="client-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-50 p-4">
  <div class="bg-white rounded-2xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
    <h3 id="client-modal-title" class="font-bold text-slate-900 mb-4">Add Client</h3>
    <div id="client-modal-error" class="hidden bg-red-50 border border-red-200 text-red-600 text-xs rounded-lg px-3 py-2 mb-3"></div>
    <input type="hidden" id="client-id">
    <div class="space-y-3">
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Full Name</label><input id="client-name" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Email</label><input id="client-email" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Phone</label><input id="client-phone" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      </div>
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Address</label><input id="client-address" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">City</label><input id="client-city" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Province</label><input id="client-province" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      </div>

      <!-- Site location. Jobs raised for this client inherit these coordinates
           as the geofence centre, so plotting the site once here geofences
           every future job automatically. -->
      <div class="border border-slate-200 rounded-xl p-3 bg-slate-50/60">
        <div class="flex items-center justify-between mb-2">
          <label class="block text-xs font-bold text-slate-600">
            <i class="fas fa-location-dot text-solar mr-1"></i> Site Location (geofence centre)
          </label>
          <button type="button" id="client-use-my-location" class="text-[11px] font-semibold text-solar hover:underline">
            <i class="fas fa-crosshairs mr-0.5"></i> Use my location
          </button>
        </div>

        <div class="grid grid-cols-2 gap-3">
          <div><label class="block text-[11px] font-semibold text-slate-500 mb-1">Latitude</label>
            <input id="client-lat" type="number" step="any" placeholder="9.5907" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
          <div><label class="block text-[11px] font-semibold text-slate-500 mb-1">Longitude</label>
            <input id="client-lng" type="number" step="any" placeholder="123.1214" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        </div>

        <div class="mt-2">
          <label class="block text-[11px] font-semibold text-slate-500 mb-1">Geofence radius (metres)</label>
          <input id="client-radius" type="number" min="20" max="20000" placeholder="500" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2">
        </div>

        <div id="client-map" class="mt-2 rounded-lg overflow-hidden border border-slate-200" style="height:200px"></div>
        <p class="text-[11px] text-slate-400 mt-1.5">Click the map to drop the pin, or type coordinates above.</p>

        <label id="client-propagate-wrap" class="hidden flex items-start gap-2 mt-2 cursor-pointer">
          <input type="checkbox" id="client-propagate" class="mt-0.5 h-3.5 w-3.5 rounded border-slate-300 text-solar">
          <span class="text-[11px] text-slate-500 leading-snug">Also move the geofence on this client's open jobs. Completed jobs keep the location they were carried out under.</span>
        </label>
      </div>

      <div id="client-password-wrap"><label class="block text-xs font-semibold text-slate-500 mb-1">Password</label><input id="client-password" type="text" placeholder="Initial password (min 8 chars)" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      <div id="client-reset-wrap" class="hidden"><label class="block text-xs font-semibold text-slate-500 mb-1">Reset Password (optional)</label><input id="client-new-password" type="text" placeholder="Leave blank to keep current password" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
    </div>
    <div class="flex gap-2 mt-5">
      <button id="client-cancel" class="flex-1 border border-slate-200 text-slate-600 text-sm font-semibold py-2 rounded-lg">Cancel</button>
      <button id="client-save" class="flex-1 bg-solar hover:bg-orange-600 text-white text-sm font-semibold py-2 rounded-lg">Save</button>
    </div>
  </div>
</div>

<!-- Add/Edit Technician Modal -->
<div id="tech-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-50 p-4">
  <div class="bg-white rounded-2xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
    <h3 id="tech-modal-title" class="font-bold text-slate-900 mb-4">Add Technician</h3>
    <div id="tech-modal-error" class="hidden bg-red-50 border border-red-200 text-red-600 text-xs rounded-lg px-3 py-2 mb-3"></div>
    <input type="hidden" id="tech-id">
    <div class="space-y-3">
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Full Name</label><input id="tech-name" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Email</label><input id="tech-email" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Phone</label><input id="tech-phone" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      </div>
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Specialization</label><input id="tech-spec" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      <div id="tech-avail-wrap" class="hidden"><label class="block text-xs font-semibold text-slate-500 mb-1">Availability</label>
        <select id="tech-availability" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"><option>AVAILABLE</option><option>BUSY</option><option>OFF_DUTY</option><option>ON_LEAVE</option></select></div>
      <div id="tech-password-wrap"><label class="block text-xs font-semibold text-slate-500 mb-1">Password</label><input id="tech-password" type="text" placeholder="Initial password (min 8 chars)" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      <div id="tech-reset-wrap" class="hidden"><label class="block text-xs font-semibold text-slate-500 mb-1">Reset Password (optional)</label><input id="tech-new-password" type="text" placeholder="Leave blank to keep current password" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
    </div>
    <div class="flex gap-2 mt-5">
      <button id="tech-cancel" class="flex-1 border border-slate-200 text-slate-600 text-sm font-semibold py-2 rounded-lg">Cancel</button>
      <button id="tech-save" class="flex-1 bg-solar hover:bg-orange-600 text-white text-sm font-semibold py-2 rounded-lg">Save</button>
    </div>
  </div>
</div>

<!-- Add/Edit Staff Modal -->
<div id="staff-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-50 p-4">
  <div class="bg-white rounded-2xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
    <h3 id="staff-modal-title" class="font-bold text-slate-900 mb-4">Add Staff</h3>
    <div id="staff-modal-error" class="hidden bg-red-50 border border-red-200 text-red-600 text-xs rounded-lg px-3 py-2 mb-3"></div>
    <input type="hidden" id="staff-id">
    <div class="space-y-3">
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Full Name</label><input id="staff-name" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Email</label><input id="staff-email" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Phone</label><input id="staff-phone" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Department</label><input id="staff-department" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Position</label><input id="staff-position" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      </div>
      <div id="staff-status-wrap" class="hidden"><label class="block text-xs font-semibold text-slate-500 mb-1">Status</label>
        <select id="staff-status" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"><option value="ACTIVE">Active</option><option value="ON_LEAVE">On Leave</option><option value="INACTIVE">Inactive</option></select>
        <p class="text-[11px] text-slate-400 mt-1">Inactive also disables portal login. On Leave keeps login access.</p></div>
      <div id="staff-password-wrap"><label class="block text-xs font-semibold text-slate-500 mb-1">Password</label><input id="staff-password" type="text" placeholder="Initial password (min 8 chars)" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      <div id="staff-reset-wrap" class="hidden"><label class="block text-xs font-semibold text-slate-500 mb-1">Reset Password (optional)</label><input id="staff-new-password" type="text" placeholder="Leave blank to keep current password" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
    </div>
    <div class="flex gap-2 mt-5">
      <button id="staff-cancel" class="flex-1 border border-slate-200 text-slate-600 text-sm font-semibold py-2 rounded-lg">Cancel</button>
      <button id="staff-save" class="flex-1 bg-solar hover:bg-orange-600 text-white text-sm font-semibold py-2 rounded-lg">Save</button>
    </div>
  </div>
</div>

<!-- Add/Edit Project Modal -->
<div id="project-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-50 p-4">
  <div class="bg-white rounded-2xl p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto">
    <h3 id="project-modal-title" class="font-bold text-slate-900 mb-4">Add Project</h3>
    <div id="project-modal-error" class="hidden bg-red-50 border border-red-200 text-red-600 text-xs rounded-lg px-3 py-2 mb-3"></div>
    <input type="hidden" id="project-id">
    <div class="space-y-3">
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Client</label>
        <select id="project-client" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"><option value="">Loading clients...</option></select></div>
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Site Name</label><input id="project-site-name" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Address</label><input id="project-address" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">System Type</label><input id="project-system-type" placeholder="e.g. Grid-Tied" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Capacity (kW)</label><input id="project-capacity" type="number" step="0.1" min="0" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Installation Date</label><input id="project-install-date" type="date" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Assigned Technician</label>
          <select id="project-technician" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"><option value="">Unassigned</option></select></div>
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Status</label>
          <select id="project-status" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"><option>PLANNED</option><option>SCHEDULED</option><option>IN_PROGRESS</option><option>COMPLETED</option><option>MAINTENANCE</option><option>CANCELLED</option></select></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Progress (%)</label><input id="project-progress" type="number" min="0" max="100" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      </div>
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Notes</label><textarea id="project-notes" rows="2" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></textarea></div>
    </div>
    <div class="flex gap-2 mt-5">
      <button id="project-cancel" class="flex-1 border border-slate-200 text-slate-600 text-sm font-semibold py-2 rounded-lg">Cancel</button>
      <button id="project-save" class="flex-1 bg-solar hover:bg-orange-600 text-white text-sm font-semibold py-2 rounded-lg">Save</button>
    </div>
  </div>
</div>

<!-- Add/Edit Invoice Modal -->
<div id="invoice-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-50 p-4">
  <div class="bg-white rounded-2xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
    <h3 id="invoice-modal-title" class="font-bold text-slate-900 mb-4">New Invoice</h3>
    <div id="invoice-modal-error" class="hidden bg-red-50 border border-red-200 text-red-600 text-xs rounded-lg px-3 py-2 mb-3"></div>
    <div id="invoice-locked-note" class="hidden bg-slate-50 border border-slate-200 text-slate-500 text-xs rounded-lg px-3 py-2 mb-3"><i class="fas fa-lock mr-1"></i> This invoice is settled and its financial details are locked. Use Record Payment or Cancel from the table instead.</div>
    <input type="hidden" id="invoice-id">
    <div class="space-y-3">
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Client</label>
        <select id="invoice-client" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"><option value="">Loading clients...</option></select></div>
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Project (optional)</label>
        <select id="invoice-project" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"><option value="">No specific project</option></select></div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Amount (₱)</label><input id="invoice-amount" type="number" step="0.01" min="0.01" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Due Date</label><input id="invoice-due-date" type="date" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      </div>
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Notes</label><textarea id="invoice-notes" rows="2" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></textarea></div>
    </div>
    <div class="flex gap-2 mt-5">
      <button id="invoice-cancel-btn" class="flex-1 border border-slate-200 text-slate-600 text-sm font-semibold py-2 rounded-lg">Close</button>
      <button id="invoice-save" class="flex-1 bg-solar hover:bg-orange-600 text-white text-sm font-semibold py-2 rounded-lg">Save</button>
    </div>
  </div>
</div>

<!-- Record Payment Modal -->
<div id="payment-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-50 p-4">
  <div class="bg-white rounded-2xl p-6 w-full max-w-sm">
    <h3 class="font-bold text-slate-900 mb-1">Record Payment</h3>
    <p id="payment-invoice-label" class="text-xs text-slate-500 mb-4">Invoice</p>
    <div id="payment-modal-error" class="hidden bg-red-50 border border-red-200 text-red-600 text-xs rounded-lg px-3 py-2 mb-3"></div>
    <input type="hidden" id="payment-invoice-id">
    <div class="space-y-3">
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Amount Received (₱)</label><input id="payment-amount" type="number" step="0.01" min="0.01" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Payment Method</label>
        <select id="payment-method" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"><option>Cash</option><option>GCash</option><option>Bank Transfer</option><option>Check</option><option>Other</option></select></div>
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Reference No. (optional)</label><input id="payment-reference" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
    </div>
    <div class="flex gap-2 mt-5">
      <button id="payment-cancel" class="flex-1 border border-slate-200 text-slate-600 text-sm font-semibold py-2 rounded-lg">Cancel</button>
      <button id="payment-save" class="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold py-2 rounded-lg">Record Payment</button>
    </div>
  </div>
</div>

<script>
const CSRF_TOKEN = <?= json_encode($token) ?>;
const CURRENT_ROLE = <?= json_encode($_SESSION['role_key'] ?? '') ?>;
const IS_MANAGEMENT = <?= json_encode($isManagement) ?>; // true for manager/staff — full add/edit/manage access. false for admin — view & export only.
let assignTargetId = null, moveMode = null;
const charts = {}; // key -> Chart.js instance, so we can destroy/redraw on reload

// Per the proposal-defense panel's feedback: Admin-side summaries use line
// graphs (not bar charts). Name kept generic since every summary tab calls this.
function renderBarChart(canvasId, labels, values, color) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  if (charts[canvasId]) charts[canvasId].destroy();
  const c = color || '#f97316';
  charts[canvasId] = new Chart(canvas, {
    type: 'line',
    data: { labels, datasets: [{
      label: '', data: values,
      borderColor: c, backgroundColor: c + '26', // ~15% fill under the line
      fill: true, tension: 0.35, pointRadius: 4, pointBackgroundColor: c, pointBorderColor: '#fff', pointBorderWidth: 2, borderWidth: 2.5,
    }] },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
    }
  });
}

const TAB_META = {
  'dashboard':       { title: 'Dashboard', sub: 'A clean summary of the whole system — details live in each module.', panel: 'tab-dashboard', load: loadDashboard },
  'service-requests':{ title: 'Service Requests', sub: 'Approve, reject, and assign technicians.', panel: 'tab-service-requests', load: loadAdminServiceRequests },
  'inventory':       { title: 'Inventory', sub: 'Solar panels, inverters, and batteries — live from MySQL.', panel: 'tab-inventory', load: loadInventory },
  'clients':         { title: 'Clients', sub: 'Client accounts — live from MySQL.', panel: 'tab-clients', load: loadClients },
  'technicians':     { title: 'Technician Accounts', sub: 'Field technician roster — live from MySQL.', panel: 'tab-technicians', load: loadTechnicians },
  'attendance':      { title: 'Attendance & Geofence', sub: 'GPS time-in/out records — live from MySQL.', panel: 'tab-attendance', load: loadAttendance },
  'reports':         { title: 'Reports', sub: 'Preview any report and download it as CSV — live from MySQL.', panel: 'tab-reports', load: () => loadReport() },
  'work-reports':    { title: 'Work Reports', sub: 'Technician-submitted job reports — live from MySQL.', panel: 'tab-work-reports', load: loadWorkReports },
  'staff':           { title: 'Staff', sub: 'Headcount & directory — live from MySQL.', panel: 'tab-staff', load: loadStaff },
  'projects':        { title: 'Projects', sub: 'Install pipeline & scheduling — live from MySQL.', panel: 'tab-projects', load: loadProjects },
  'maintenance':     { title: 'Maintenance Reminders', sub: 'View-only summary — schedules, live from MySQL.', panel: 'tab-maintenance', load: loadMaintenance },
  'subcontractors':  { title: 'Sub-Contractors', sub: 'Roster & approvals — live from MySQL.', panel: 'tab-subcontractors', load: loadSubcontractors },
  'logs':            { title: 'Logs & Audit', sub: 'View-only audit trail, live from MySQL.', panel: 'tab-logs', load: loadLogs },
  'billing':         { title: 'Billing', sub: 'Invoices & payment status — live from MySQL.', panel: 'tab-billing', load: loadBilling },
  'sitemap':         { title: 'Site Map', sub: 'Live geofencing — client pins, job sites, and where technicians are right now.', panel: 'tab-sitemap', load: loadSiteMap },
  'account':         { title: 'Account & Security', sub: 'Your own password and two-step login.', panel: 'tab-account', load: () => SunTrackAccount.renderTwoFactor('twofa-card') },
};

// Own password (api/account/profile.php acts only on the signed-in account).
document.getElementById('acc-pw-save').addEventListener('click', async (e) => {
  const box = document.getElementById('acc-pw-msg');
  const show = (t, ok) => { box.textContent = t; box.className = 'text-xs rounded-lg px-3 py-2 mb-3 ' + (ok ? 'bg-emerald-50 border border-emerald-200 text-emerald-700' : 'bg-red-50 border border-red-200 text-red-600'); };
  const cur = document.getElementById('acc-pw-current').value, nw = document.getElementById('acc-pw-new').value, cf = document.getElementById('acc-pw-confirm').value;
  if (!cur || !nw || !cf) return show('Please fill in all three password fields.', false);
  if (nw !== cf) return show('The new passwords do not match.', false);
  if (nw.length < 8) return show('Your new password must be at least 8 characters.', false);
  e.currentTarget.disabled = true;
  try {
    const res = await fetch('../api/account/profile.php', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'change_password', current_password: cur, new_password: nw, confirm_password: cf, csrf_token: CSRF_TOKEN }) });
    const json = await res.json();
    show(json.message, json.success);
    if (json.success) ['acc-pw-current', 'acc-pw-new', 'acc-pw-confirm'].forEach(id => document.getElementById(id).value = '');
  } catch (err) { show('Network error. Please try again.', false); }
  e.currentTarget.disabled = false;
});
const FALLBACK_TEXT = {};

// Which tab is on screen right now. Real-time updates reload only this tab,
// so a busy warehouse does not force the Clients table to re-render while an
// administrator is reading it.
let CURRENT_TAB = 'dashboard';

document.querySelectorAll('.tab-link').forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    document.querySelectorAll('.tab-link').forEach(l => l.classList.remove('bg-solar','text-white','shadow-md','shadow-orange-600/20'));
    link.classList.add('bg-solar','text-white','shadow-md','shadow-orange-600/20');
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.add('hidden'));
    const key = link.dataset.tab;
    const addBtn = document.getElementById('btn-add');
    addBtn.classList.toggle('hidden', !IS_MANAGEMENT || !['inventory','clients','technicians','staff','projects','billing'].includes(key));
    if (key === 'inventory') document.getElementById('btn-add-label').textContent = 'Add Item';
    if (key === 'clients') document.getElementById('btn-add-label').textContent = 'Add Client';
    if (key === 'technicians') document.getElementById('btn-add-label').textContent = 'Add Technician';
    if (key === 'staff') document.getElementById('btn-add-label').textContent = 'Add Staff';
    if (key === 'projects') document.getElementById('btn-add-label').textContent = 'Add Project';
    if (key === 'billing') document.getElementById('btn-add-label').textContent = 'New Invoice';

    CURRENT_TAB = key;
    const meta = TAB_META[key];
    if (meta) {
      document.getElementById('page-title').textContent = meta.title;
      document.getElementById('page-sub').textContent = meta.sub;
      document.getElementById(meta.panel).classList.remove('hidden');
      meta.load();
    } else {
      document.getElementById('page-title').textContent = link.textContent.trim();
      document.getElementById('page-sub').textContent = 'Coming soon.';
      document.getElementById('tab-fallback-text').textContent = FALLBACK_TEXT[key] || 'This module\'s API + full UI wiring lands in the next build phase. The tab and navigation are already in place.';
      document.getElementById('tab-fallback').classList.remove('hidden');
    }
  });
});

document.getElementById('btn-add').addEventListener('click', () => {
  const visible = document.querySelector('.tab-panel:not(.hidden)').id;
  if (visible === 'tab-inventory') openAddItemModal();
  else if (visible === 'tab-clients') openAddClientModal();
  else if (visible === 'tab-technicians') openAddTechModal();
  else if (visible === 'tab-staff') openAddStaffModal();
  else if (visible === 'tab-projects') openAddProjectModal();
  else if (visible === 'tab-billing') openAddInvoiceModal();
});

function peso(n) { return '₱' + Number(n).toLocaleString('en-PH', {maximumFractionDigits: 0}); }

// The Admin dashboard: four summary cards, one line graph, one pie graph,
// Needs Attention, and the Clients / Technicians / Warehouse buttons — see
// assets/js/suntrack-admin-dashboard.js. Cards open the matching Admin tab.
// Management mounts the same dashboard, mapping the links onto its own tabs.
const ADMIN_DASHBOARD = SunTrackAdminDashboard.mount({
  root: document.getElementById('sad-root'),
  endpoint: '../api/dashboard/admin.php',
  navigate: (tab) => {
    const link = document.querySelector('.tab-link[data-tab="' + tab + '"]');
    if (link) link.click();
  },
});
function loadDashboard() { return ADMIN_DASHBOARD.refresh(); }

// ---- STAFF ----
async function loadStaff() {
  const tbody = document.getElementById('stf-table-body');
  tbody.innerHTML = `<tr><td colspan="7" class="text-slate-400 text-center py-6">Loading...</td></tr>`;
  const params = new URLSearchParams();
  const search = document.getElementById('stf-search').value;
  const status = document.getElementById('stf-filter-status').value;
  if (search) params.set('search', search);
  if (status) params.set('status', status);
  try {
    const res = await stFetch('../api/staff/list.php?' + params.toString());
    const json = await res.json();
    if (!json.success) { tbody.innerHTML = `<tr><td colspan="7" class="text-red-500 py-6 text-center">${escHtml(json.message)}</td></tr>`; return; }
    const s = json.data.stats;
    document.getElementById('stf-k-total').textContent = s.total;
    document.getElementById('stf-k-active').textContent = s.active;
    document.getElementById('stf-k-leave').textContent = s.on_leave;
    document.getElementById('stf-k-inactive').textContent = s.inactive;
    renderBarChart('stf-chart', json.data.chart.labels, json.data.chart.values, '#f97316');
    const rows = json.data.rows;
    document.getElementById('stf-empty').classList.toggle('hidden', rows.length > 0);
    const statusColor = { ACTIVE:'bg-emerald-100 text-emerald-700', ON_LEAVE:'bg-amber-100 text-amber-700', INACTIVE:'bg-slate-100 text-slate-500' };
    tbody.innerHTML = rows.map(r => `
      <tr>
        <td class="font-semibold">${r.staff_code}</td>
        <td>${escHtml(r.full_name)}</td>
        <td class="text-xs">${escHtml(r.email)}<div class="text-slate-400">${escHtml(r.phone ?? '')}</div></td>
        <td>${escHtml(r.department ?? '—')}</td>
        <td>${escHtml(r.position ?? '—')}</td>
        <td><span class="badge ${statusColor[r.status] || 'bg-slate-100 text-slate-500'}">${r.status}</span></td>
        <td class="whitespace-nowrap">
          ${IS_MANAGEMENT ? `<button class="icon-btn stf-edit" data-id="${r.id}" title="Edit"><i class="fas fa-pen"></i></button>` : `<span class="text-[11px] text-slate-300">View only</span>`}
        </td>
      </tr>`).join('');
    window.__staffCache = rows;
    if (IS_MANAGEMENT) {
      document.querySelectorAll('.stf-edit').forEach(b => b.addEventListener('click', () => openEditStaffModal(b.dataset.id)));
    }
  } catch (err) { tbody.innerHTML = `<tr><td colspan="7" class="text-red-500 py-6 text-center">Failed to load staff.</td></tr>`; }
}
document.getElementById('stf-filter-btn').addEventListener('click', loadStaff);
function openAddStaffModal() {
  document.getElementById('staff-modal-title').textContent = 'Add Staff';
  document.getElementById('staff-id').value = '';
  ['staff-name','staff-email','staff-phone','staff-department','staff-position','staff-password'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('staff-email').disabled = false;
  document.getElementById('staff-status-wrap').classList.add('hidden');
  document.getElementById('staff-password-wrap').classList.remove('hidden');
  document.getElementById('staff-reset-wrap').classList.add('hidden');
  document.getElementById('staff-modal-error').classList.add('hidden');
  document.getElementById('staff-modal').classList.remove('hidden');
}
function openEditStaffModal(id) {
  const r = window.__staffCache.find(x => String(x.id) === String(id));
  if (!r) return;
  document.getElementById('staff-modal-title').textContent = 'Edit Staff';
  document.getElementById('staff-id').value = r.id;
  document.getElementById('staff-name').value = r.full_name;
  document.getElementById('staff-email').value = r.email;
  document.getElementById('staff-email').disabled = true;
  document.getElementById('staff-phone').value = r.phone ?? '';
  document.getElementById('staff-department').value = r.department ?? '';
  document.getElementById('staff-position').value = r.position ?? '';
  document.getElementById('staff-status-wrap').classList.remove('hidden');
  document.getElementById('staff-status').value = r.status;
  document.getElementById('staff-password-wrap').classList.add('hidden');
  document.getElementById('staff-reset-wrap').classList.remove('hidden');
  document.getElementById('staff-new-password').value = '';
  document.getElementById('staff-modal-error').classList.add('hidden');
  document.getElementById('staff-modal').classList.remove('hidden');
}
document.getElementById('staff-cancel').addEventListener('click', () => document.getElementById('staff-modal').classList.add('hidden'));
document.getElementById('staff-save').addEventListener('click', async () => {
  const errBox = document.getElementById('staff-modal-error'); errBox.classList.add('hidden');
  const id = document.getElementById('staff-id').value; const isEdit = !!id;
  const payload = { full_name: document.getElementById('staff-name').value.trim(), phone: document.getElementById('staff-phone').value.trim(),
    department: document.getElementById('staff-department').value.trim(), position: document.getElementById('staff-position').value.trim(), csrf_token: CSRF_TOKEN };
  if (!payload.full_name) { errBox.textContent = 'Full name is required.'; errBox.classList.remove('hidden'); return; }
  if (isEdit) {
    payload.id = id;
    payload.status = document.getElementById('staff-status').value;
    const newPw = document.getElementById('staff-new-password').value;
    if (newPw) payload.new_password = newPw;
  } else {
    payload.email = document.getElementById('staff-email').value.trim();
    payload.password = document.getElementById('staff-password').value;
    if (!payload.email || !payload.password) { errBox.textContent = 'Email and password are required.'; errBox.classList.remove('hidden'); return; }
  }
  try {
    const res = await fetch('../api/staff/' + (isEdit ? 'update.php' : 'create.php'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const json = await res.json();
    if (!json.success) { errBox.textContent = json.message; errBox.classList.remove('hidden'); return; }
    document.getElementById('staff-modal').classList.add('hidden'); loadStaff(); loadDashboard();
  } catch (err) { errBox.textContent = 'Network error. Please try again.'; errBox.classList.remove('hidden'); }
});

// ---- PROJECTS ----
async function loadProjects() {
  const tbody = document.getElementById('prj-table-body');
  tbody.innerHTML = `<tr><td colspan="9" class="text-slate-400 text-center py-6">Loading...</td></tr>`;
  const params = new URLSearchParams();
  const search = document.getElementById('prj-search').value;
  const status = document.getElementById('prj-filter-status').value;
  if (search) params.set('search', search);
  if (status) params.set('status', status);
  try {
    const res = await stFetch('../api/projects/list.php?' + params.toString());
    const json = await res.json();
    if (!json.success) { tbody.innerHTML = `<tr><td colspan="9" class="text-red-500 py-6 text-center">${escHtml(json.message)}</td></tr>`; return; }
    const s = json.data.stats;
    document.getElementById('prj-k-total').textContent = s.total;
    document.getElementById('prj-k-progress').textContent = s.in_progress;
    document.getElementById('prj-k-done').textContent = s.completed;
    document.getElementById('prj-k-planned').textContent = s.planned;
    renderBarChart('prj-chart', json.data.chart.labels, json.data.chart.values, '#0f172a');
    const rows = json.data.rows;
    document.getElementById('prj-empty').classList.toggle('hidden', rows.length > 0);
    const statusColor = { PLANNED:'bg-slate-100 text-slate-600', SCHEDULED:'bg-sky-100 text-sky-700', IN_PROGRESS:'bg-amber-100 text-amber-700', COMPLETED:'bg-emerald-100 text-emerald-700', MAINTENANCE:'bg-indigo-100 text-indigo-700', CANCELLED:'bg-red-100 text-red-700' };
    tbody.innerHTML = rows.map(r => `
      <tr>
        <td class="font-semibold">${r.project_code}</td>
        <td>${escHtml(r.site_name)}<div class="text-xs text-slate-400">${escHtml(r.address ?? '')}</div></td>
        <td>${escHtml(r.client_name)}</td>
        <td>${r.capacity_kw ? r.capacity_kw + ' kW' : '—'}</td>
        <td>${escHtml(r.technician_name ?? '—')}</td>
        <td>${r.progress}%</td>
        <td>${r.installation_job_id ? `<button class="prj-view-checklist link-btn text-navy" data-job="${r.installation_job_id}" data-code="${r.project_code}"><i class="fas fa-list-check mr-1"></i>View</button>` : '<span class="text-slate-300 text-xs">—</span>'}</td>
        <td><span class="badge ${statusColor[r.status] || 'bg-slate-100 text-slate-500'}">${r.status}</span></td>
        <td class="whitespace-nowrap">${IS_MANAGEMENT ? `<button class="icon-btn prj-edit" data-id="${r.id}" title="Edit"><i class="fas fa-pen"></i></button>` : `<span class="text-[11px] text-slate-300">View only</span>`}</td>
      </tr>`).join('');
    document.querySelectorAll('.prj-view-checklist').forEach(b => b.addEventListener('click', () => openProjectChecklist(b.dataset.job, b.dataset.code)));
    window.__projectCache = rows;
    if (IS_MANAGEMENT) document.querySelectorAll('.prj-edit').forEach(b => b.addEventListener('click', () => openEditProjectModal(b.dataset.id)));
  } catch (err) { tbody.innerHTML = `<tr><td colspan="9" class="text-red-500 py-6 text-center">Failed to load projects.</td></tr>`; }
}
async function populateProjectDropdowns(selectedClientId, selectedTechId) {
  const clientSel = document.getElementById('project-client');
  const techSel = document.getElementById('project-technician');
  clientSel.innerHTML = '<option value="">Loading clients...</option>';
  techSel.innerHTML = '<option value="">Unassigned</option>';
  try {
    const [clientsRes, techRes] = await Promise.all([
      stFetch('../api/clients/list.php'), stFetch('../api/technicians/list.php')
    ]);
    const clientsJson = await clientsRes.json();
    const techJson = await techRes.json();
    clientSel.innerHTML = '<option value="">Select a client...</option>' +
      (clientsJson.success ? clientsJson.data.map(c => `<option value="${c.id}" ${String(c.id) === String(selectedClientId) ? 'selected' : ''}>${escHtml(c.full_name)} (${c.client_code})</option>`).join('') : '');
    techSel.innerHTML = '<option value="">Unassigned</option>' +
      (techJson.success ? techJson.data.map(t => `<option value="${t.id}" ${String(t.id) === String(selectedTechId) ? 'selected' : ''}>${escHtml(t.full_name)} (${t.technician_code})</option>`).join('') : '');
  } catch (err) {
    clientSel.innerHTML = '<option value="">Failed to load clients</option>';
    techSel.innerHTML = '<option value="">Failed to load technicians</option>';
  }
}
async function openAddProjectModal() {
  document.getElementById('project-modal-title').textContent = 'Add Project';
  document.getElementById('project-id').value = '';
  ['project-site-name','project-address','project-system-type','project-capacity','project-install-date','project-notes'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('project-status').value = 'PLANNED';
  document.getElementById('project-progress').value = 0;
  document.getElementById('project-modal-error').classList.add('hidden');
  document.getElementById('project-modal').classList.remove('hidden');
  await populateProjectDropdowns(null, null);
}
async function openEditProjectModal(id) {
  const r = window.__projectCache.find(x => String(x.id) === String(id));
  if (!r) return;
  document.getElementById('project-modal-title').textContent = 'Edit Project';
  document.getElementById('project-id').value = r.id;
  document.getElementById('project-site-name').value = r.site_name;
  document.getElementById('project-address').value = r.address ?? '';
  document.getElementById('project-system-type').value = r.system_type ?? '';
  document.getElementById('project-capacity').value = r.capacity_kw ?? '';
  document.getElementById('project-install-date').value = r.installation_date ? r.installation_date.substring(0, 10) : '';
  document.getElementById('project-notes').value = r.notes ?? '';
  document.getElementById('project-status').value = r.status;
  document.getElementById('project-progress').value = r.progress;
  document.getElementById('project-modal-error').classList.add('hidden');
  document.getElementById('project-modal').classList.remove('hidden');
  await populateProjectDropdowns(r.client_id, r.assigned_technician_id);
}
document.getElementById('project-cancel').addEventListener('click', () => document.getElementById('project-modal').classList.add('hidden'));
document.getElementById('project-save').addEventListener('click', async () => {
  const errBox = document.getElementById('project-modal-error'); errBox.classList.add('hidden');
  const id = document.getElementById('project-id').value; const isEdit = !!id;
  const payload = {
    client_id: document.getElementById('project-client').value,
    site_name: document.getElementById('project-site-name').value.trim(),
    address: document.getElementById('project-address').value.trim(),
    system_type: document.getElementById('project-system-type').value.trim(),
    capacity_kw: document.getElementById('project-capacity').value,
    installation_date: document.getElementById('project-install-date').value,
    assigned_technician_id: document.getElementById('project-technician').value,
    status: document.getElementById('project-status').value,
    progress: document.getElementById('project-progress').value,
    notes: document.getElementById('project-notes').value.trim(),
    csrf_token: CSRF_TOKEN,
  };
  if (!payload.client_id) { errBox.textContent = 'Please select a client.'; errBox.classList.remove('hidden'); return; }
  if (!payload.site_name) { errBox.textContent = 'Site name is required.'; errBox.classList.remove('hidden'); return; }
  if (isEdit) payload.id = id;
  try {
    const res = await fetch('../api/projects/' + (isEdit ? 'update.php' : 'create.php'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const json = await res.json();
    if (!json.success) { errBox.textContent = json.message; errBox.classList.remove('hidden'); return; }
    document.getElementById('project-modal').classList.add('hidden'); loadProjects(); loadDashboard();
  } catch (err) { errBox.textContent = 'Network error. Please try again.'; errBox.classList.remove('hidden'); }
});

// ---- PROJECT CHECKLIST (view-only) ----
// Per panel feedback: "instead of progress bar, use a checklist" — this pulls
// the real installation_checklists/installation_items data behind each
// project's progress %, view-only (Admin cannot check items here).
async function openProjectChecklist(jobId, projectCode) {
  const modal = document.getElementById('prj-checklist-modal');
  const body = document.getElementById('prj-checklist-body');
  document.getElementById('prj-checklist-title').textContent = `Installation Checklist — ${projectCode}`;
  body.innerHTML = `<p class="text-slate-400 text-sm py-4 text-center">Loading...</p>`;
  modal.classList.remove('hidden');
  try {
    const res = await fetch('../api/installation/get.php?job_id=' + encodeURIComponent(jobId));
    const json = await res.json();
    if (!json.success || !json.data.checklist) {
      body.innerHTML = `<p class="text-slate-400 text-sm py-4 text-center">No checklist has been started for this job yet.</p>`;
      return;
    }
    const items = json.data.items;
    const byCategory = {};
    items.forEach(it => { (byCategory[it.category] ??= []).push(it); });
    const iconFor = (st) => st === 'COMPLETED' ? '<i class="fas fa-circle-check text-emerald-500"></i>'
      : st === 'NOT_APPLICABLE' ? '<i class="fas fa-circle-minus text-slate-300"></i>'
      : '<i class="far fa-circle text-slate-300"></i>';
    body.innerHTML = `<p class="text-xs text-slate-400 mb-3">${json.data.checklist.progress}% complete overall.</p>` +
      Object.entries(byCategory).map(([cat, catItems]) => `
        <div class="mb-4">
          <p class="text-xs font-bold text-slate-500 uppercase mb-2">${cat}</p>
          <div class="space-y-1.5">
            ${catItems.map(it => `<div class="flex items-center gap-2 text-sm"><span class="w-4 text-center">${iconFor(it.status)}</span><span class="${it.status === 'COMPLETED' ? 'text-slate-500 line-through' : 'text-slate-700'}">${escHtml(it.description)}</span></div>`).join('')}
          </div>
        </div>`).join('');
  } catch (err) { body.innerHTML = `<p class="text-red-500 text-sm py-4 text-center">Failed to load checklist.</p>`; }
}
document.getElementById('prj-checklist-close').addEventListener('click', () => document.getElementById('prj-checklist-modal').classList.add('hidden'));
document.getElementById('prj-filter-btn').addEventListener('click', loadProjects);

// ---- MAINTENANCE REMINDERS (view-only summary) ----
async function loadMaintenance() {
  const tbody = document.getElementById('mnt-table-body');
  tbody.innerHTML = `<tr><td colspan="6" class="text-slate-400 text-center py-6">Loading...</td></tr>`;
  const params = new URLSearchParams();
  const search = document.getElementById('mnt-search').value;
  const status = document.getElementById('mnt-filter-status').value;
  if (search) params.set('search', search);
  if (status) params.set('status', status);
  try {
    const res = await stFetch('../api/maintenance/list.php?' + params.toString());
    const json = await res.json();
    if (!json.success) { tbody.innerHTML = `<tr><td colspan="6" class="text-red-500 py-6 text-center">${escHtml(json.message)}</td></tr>`; return; }
    const s = json.data.stats;
    document.getElementById('mnt-k-total').textContent = s.total;
    document.getElementById('mnt-k-upcoming').textContent = s.upcoming;
    document.getElementById('mnt-k-due').textContent = s.due;
    document.getElementById('mnt-k-overdue').textContent = s.overdue;
    renderBarChart('mnt-chart', json.data.chart.labels, json.data.chart.values, '#dc2626');
    const rows = json.data.rows;
    document.getElementById('mnt-empty').classList.toggle('hidden', rows.length > 0);
    const statusColor = { UPCOMING:'bg-sky-100 text-sky-700', DUE:'bg-amber-100 text-amber-700', OVERDUE:'bg-red-100 text-red-700' };
    tbody.innerHTML = rows.map(r => `
      <tr>
        <td class="font-semibold">${r.project_code}<div class="text-xs text-slate-400">${escHtml(r.site_name)}</div></td>
        <td>${escHtml(r.client_name)}</td>
        <td class="text-xs">${r.last_maintenance ?? '—'}</td>
        <td class="text-xs">${r.next_maintenance ?? '—'}</td>
        <td><span class="badge ${statusColor[r.status] || 'bg-slate-100 text-slate-500'}">${r.status}</span></td>
        <td>${Number(r.client_notified) ? '<span class="text-emerald-600 text-xs font-semibold">Yes</span>' : '<span class="text-slate-400 text-xs">No</span>'}</td>
      </tr>`).join('');
  } catch (err) { tbody.innerHTML = `<tr><td colspan="6" class="text-red-500 py-6 text-center">Failed to load maintenance schedules.</td></tr>`; }
}
document.getElementById('mnt-filter-btn').addEventListener('click', loadMaintenance);

// ---- SUB-CONTRACTORS (assets/js/suntrack-subcon-mgmt.js; view only for Admin) ----
const SUBCON = SunTrackSubcon.mount({
  root: document.getElementById('subcon-root'), base: '<?= APP_BASE_URL ?>', csrf: CSRF_TOKEN, canManage: IS_MANAGEMENT,
});
function loadSubcontractors() { SUBCON.refresh(); }

// ---- LOGS & AUDIT (view-only viewer) ----
async function loadLogs() {
  const tbody = document.getElementById('log-table-body');
  tbody.innerHTML = `<tr><td colspan="4" class="text-slate-400 text-center py-6">Loading...</td></tr>`;
  const params = new URLSearchParams();
  const search = document.getElementById('log-search').value;
  if (search) params.set('search', search);
  const role = document.getElementById('log-filter-role').value;
  const from = document.getElementById('log-filter-from').value;
  const to   = document.getElementById('log-filter-to').value;
  if (role) params.set('role', role);
  if (from) params.set('date_from', from);
  if (to)   params.set('date_to', to);
  try {
    const res = await stFetch('../api/logs/list.php?' + params.toString());
    const json = await res.json();
    if (!json.success) { tbody.innerHTML = `<tr><td colspan="4" class="text-red-500 py-6 text-center">${escHtml(json.message)}</td></tr>`; return; }
    const s = json.data.stats;
    document.getElementById('log-k-total').textContent = s.total;
    document.getElementById('log-k-today').textContent = s.today;
    document.getElementById('log-k-modules').textContent = s.modules;
    renderBarChart('log-chart', json.data.chart.labels, json.data.chart.values, '#0f172a');
    const rows = json.data.rows;
    document.getElementById('log-empty').classList.toggle('hidden', rows.length > 0);
    // Compact rows: one line each. "UPDATE_LOCATION" -> "Update location", module as a small tag.
    const nice = s => String(s || '').toLowerCase().replace(/[_:]+/g, ' ').replace(/->/g, ' → ').replace(/^\w/, c => c.toUpperCase());
    const when = s => { const d = new Date(String(s).replace(' ', 'T')); return isNaN(d) ? escHtml(s)
      : d.toLocaleDateString('en-PH', { month: 'short', day: 'numeric' }) + ', ' + d.toLocaleTimeString('en-PH', { hour: 'numeric', minute: '2-digit' }); };
    tbody.innerHTML = rows.map(r => `
      <tr>
        <td class="text-xs text-slate-500 whitespace-nowrap" title="${escHtml(r.created_at + (r.ip_address ? ' · IP ' + r.ip_address : ''))}">${when(r.created_at)}</td>
        <td class="whitespace-nowrap"><span class="font-semibold text-slate-800">${escHtml(r.full_name ?? 'System')}</span>
          <span class="text-[11px] text-slate-400 ml-1">${escHtml(r.role_key ?? '')}</span></td>
        <td><span class="font-semibold text-slate-800">${escHtml(nice(r.action))}</span>
          <span class="ml-1 text-[10px] font-semibold uppercase text-slate-500 bg-slate-100 rounded px-1.5 py-0.5">${escHtml(nice(r.module))}</span></td>
        <td class="text-xs text-slate-500 whitespace-nowrap">${escHtml(r.record_id ?? '—')}</td>
      </tr>`).join('');
  } catch (err) { tbody.innerHTML = `<tr><td colspan="4" class="text-red-500 py-6 text-center">Failed to load logs.</td></tr>`; }
}
document.getElementById('log-filter-btn').addEventListener('click', loadLogs);

// ---- REPORTS (same as Management: live preview + CSV, from includes/report_lib.php) ----
const REPORT_DEFS = <?= json_encode(report_definitions(), JSON_HEX_TAG | JSON_HEX_AMP) ?>;
let repSeq = 0;           // a slower, older response never overwrites a newer one
let repShownType = null;  // the report the table currently shows
let repSearchTimer = null;
const repPeso = n => '₱' + Number(n || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
function repBadge(status) {
  const s = String(status).toUpperCase();
  const groups = [
    [['ACTIVE', 'APPROVED', 'COMPLETED', 'AVAILABLE', 'PAID', 'REVIEWED'], 'bg-emerald-100 text-emerald-700'],
    [['PENDING', 'UPCOMING', 'DUE', 'LOW_STOCK', 'ON_LEAVE', 'PAUSED', 'SUBMITTED', 'NORMAL', 'PLANNED', 'SCHEDULED'], 'bg-amber-100 text-amber-700'],
    [['INACTIVE', 'REJECTED', 'CANCELLED', 'OVERDUE', 'OUT_OF_STOCK', 'URGENT', 'HIGH', 'DISCONTINUED'], 'bg-red-100 text-red-700'],
    [['IN_PROGRESS', 'ASSIGNED', 'EN_ROUTE', 'ARRIVED', 'BUSY', 'LOW', 'ON_HOLD', 'MAINTENANCE'], 'bg-sky-100 text-sky-700'],
  ];
  const cls = (groups.find(g => g[0].includes(s)) || [null, 'bg-slate-100 text-slate-600'])[1];
  return '<span class="badge ' + cls + '">' + escHtml(s.replace(/_/g, ' ')) + '</span>';
}
function repNotice(msg, isError) { // the Admin page has no toast stack: use the summary line
  const el = document.getElementById('rep-summary');
  el.innerHTML = '<span class="' + (isError ? 'text-red-600' : 'text-emerald-600') + ' font-semibold"><i class="fas '
    + (isError ? 'fa-circle-exclamation' : 'fa-circle-check') + ' mr-1"></i>' + escHtml(msg) + '</span>';
}

function reportParams() {
  const type = document.getElementById('rep-type').value;
  const params = new URLSearchParams({ type });
  const s  = document.getElementById('rep-search').value.trim(); if (s) params.set('search', s);
  const st = document.getElementById('rep-status').value;        if (st) params.set('status', st);
  if (REPORT_DEFS[type].date_label) {
    const f = document.getElementById('rep-from').value; if (f) params.set('date_from', f);
    const t = document.getElementById('rep-to').value;   if (t) params.set('date_to', t);
  }
  return params;
}
function reportHasFilters() { return [...reportParams().keys()].some(k => k !== 'type'); }

// Status choices, date range and search hint follow the chosen report.
function setupReportFilters() {
  const def = REPORT_DEFS[document.getElementById('rep-type').value];
  const status = document.getElementById('rep-status');
  status.innerHTML = '<option value="">Any ' + escHtml(def.status_label.toLowerCase()) + '</option>'
    + Object.entries(def.statuses).map(([v, l]) => '<option value="' + escHtml(v) + '">' + escHtml(l) + '</option>').join('');
  status.setAttribute('aria-label', def.status_label);
  document.getElementById('rep-search').placeholder = 'Search: ' + def.search_hint;
  document.getElementById('rep-dates').classList.toggle('hidden', !def.date_label);
  if (def.date_label) {
    document.getElementById('rep-from').title = def.date_label + ' from';
    document.getElementById('rep-to').title = def.date_label + ' to';
  }
}

function reportCell(v, type) {
  if (v === null || v === undefined || v === '') return '<span class="text-slate-300">—</span>';
  switch (type) {
    case 'number':  return '<span class="tabular-nums">' + Number(v).toLocaleString('en-PH') + '</span>';
    case 'money':   return '<span class="tabular-nums">' + repPeso(v) + '</span>';
    case 'percent': {
      const p = Math.max(0, Math.min(100, Number(v) || 0));
      return '<span class="inline-flex items-center gap-2"><span class="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden"><span class="block h-full bg-solar" style="width:' + p + '%"></span></span><span class="tabular-nums text-xs">' + p + '%</span></span>';
    }
    case 'date': {
      const d = new Date(String(v).slice(0, 10) + 'T00:00');
      return isNaN(d) ? escHtml(v) : d.toLocaleDateString('en-PH', { year: 'numeric', month: 'short', day: 'numeric' });
    }
    case 'datetime': {
      const d = new Date(String(v).replace(' ', 'T'));
      return isNaN(d) ? escHtml(v) : d.toLocaleString('en-PH', { year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
    }
    case 'status':  return repBadge(v);
    default: {
      const s = String(v);
      return s.length > 80 ? '<span title="' + escHtml(s) + '">' + escHtml(s.slice(0, 79)) + '…</span>' : escHtml(s);
    }
  }
}

async function loadReport() {
  const seq = ++repSeq;
  const type = document.getElementById('rep-type').value;
  const thead = document.getElementById('rep-thead');
  const tbody = document.getElementById('rep-tbody');
  const wrap = document.getElementById('rep-table-wrap');
  const summary = document.getElementById('rep-summary');
  document.getElementById('rep-clear').classList.toggle('hidden', !reportHasFilters());

  summary.innerHTML = '<i class="fas fa-spinner fa-spin mr-1"></i> Loading ' + escHtml(REPORT_DEFS[type].label) + '…';
  if (repShownType === type) {
    wrap.classList.add('opacity-50');
  } else {
    thead.innerHTML = '';
    tbody.innerHTML = Array.from({ length: 6 }, () =>
      '<tr>' + Array.from({ length: 6 }, () => '<td><span class="block h-3 rounded bg-slate-100 animate-pulse"></span></td>').join('') + '</tr>').join('');
  }

  let json;
  try {
    json = await (await fetch('../api/reports/get_report.php?' + reportParams().toString(), { credentials: 'same-origin' })).json();
  } catch (e) {
    json = { success: false, message: 'Network error. Please try again.' };
  }
  if (seq !== repSeq) return;
  wrap.classList.remove('opacity-50');

  if (!json.success) {
    repShownType = null;
    thead.innerHTML = '';
    tbody.innerHTML = '<tr><td class="text-center text-red-500 py-8"><i class="fas fa-circle-exclamation mr-1"></i> ' + escHtml(json.message || 'The report could not be loaded.') + '</td></tr>';
    summary.textContent = '';
    return;
  }

  const d = json.data;
  repShownType = type;
  thead.innerHTML = '<tr>' + d.columns.map(c =>
    '<th' + (['number', 'money'].includes(c.type) ? ' class="text-right"' : '') + '>' + escHtml(c.label) + '</th>').join('') + '</tr>';
  tbody.innerHTML = d.rows.length
    ? d.rows.map(r => '<tr>' + d.columns.map(c =>
        '<td' + (['number', 'money'].includes(c.type) ? ' class="text-right"' : '') + '>' + reportCell(r[c.key], c.type) + '</td>').join('') + '</tr>').join('')
    : '<tr><td colspan="' + d.columns.length + '" class="text-center py-10">'
      + '<i class="fas fa-magnifying-glass text-2xl text-slate-300 block mb-2"></i>'
      + '<p class="text-slate-600 font-semibold text-sm">No records found matching your filters.</p>'
      + (reportHasFilters() ? '<button class="mt-3 text-solar text-sm font-semibold hover:underline" onclick="clearReportFilters()">Clear filters</button>' : '')
      + '</td></tr>';

  const total = Number(d.total).toLocaleString('en-PH');
  summary.textContent = d.total === d.shown
    ? total + ' record' + (d.total === 1 ? '' : 's') + '.'
    : 'Showing the first ' + d.shown.toLocaleString('en-PH') + ' of ' + total + ' records. '
      + (d.total > 10000 ? 'The CSV export includes the first 10,000.' : 'The CSV export includes all of them.');
}

function clearReportFilters() {
  ['rep-search', 'rep-status', 'rep-from', 'rep-to'].forEach(id => document.getElementById(id).value = '');
  loadReport();
}

// Downloads through fetch, so a failed export shows a message instead of a JSON page.
async function exportReport(btn) {
  const original = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-1"></i> Exporting…';
  try {
    const res = await fetch('../api/reports/export.php?' + reportParams().toString(), { credentials: 'same-origin' });
    if (!res.ok || !(res.headers.get('Content-Type') || '').includes('text/csv')) {
      let msg = 'The export failed. Please try again.';
      try { msg = (await res.json()).message || msg; } catch (e) { /* not JSON */ }
      repNotice(msg, true);
      return;
    }
    const blob = await res.blob();
    const match = /filename="([^"]+)"/.exec(res.headers.get('Content-Disposition') || '');
    const name = match ? match[1] : 'report.csv';
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    repNotice('Downloaded ' + name, false);
  } catch (e) {
    repNotice('Network error. Please try again.', true);
  } finally {
    btn.disabled = false;
    btn.innerHTML = original;
  }
}

document.getElementById('rep-type').addEventListener('change', () => { setupReportFilters(); loadReport(); });
document.getElementById('rep-search').addEventListener('input', () => {
  clearTimeout(repSearchTimer);
  repSearchTimer = setTimeout(loadReport, 350);
});
['rep-status', 'rep-from', 'rep-to'].forEach(id => document.getElementById(id).addEventListener('change', loadReport));
setupReportFilters();

// ---- CSV EXPORTS ----
// Shared helper: build the export URL for a given type using that tab's current filter inputs.
function exportCsv(type, filterMap) {
  const params = new URLSearchParams({ type });
  for (const [param, elId] of Object.entries(filterMap)) {
    const el = document.getElementById(elId);
    if (el && el.value) params.set(param, el.value);
  }
  window.location.href = '../api/export/csv.php?' + params.toString();
}
document.getElementById('stf-export-btn').addEventListener('click', () => exportCsv('staff', { search: 'stf-search', status: 'stf-filter-status' }));
document.getElementById('prj-export-btn').addEventListener('click', () => exportCsv('projects', { search: 'prj-search', status: 'prj-filter-status' }));
document.getElementById('mnt-export-btn').addEventListener('click', () => exportCsv('maintenance', { search: 'mnt-search', status: 'mnt-filter-status' }));
document.getElementById('log-export-btn').addEventListener('click', () => exportCsv('logs', { search: 'log-search', role: 'log-filter-role', date_from: 'log-filter-from', date_to: 'log-filter-to' }));
document.getElementById('bill-export-btn').addEventListener('click', () => exportCsv('billing', { search: 'bill-search', status: 'bill-filter-status', date_from: 'bill-date-from', date_to: 'bill-date-to' }));
document.getElementById('cl-export-btn').addEventListener('click', () => exportCsv('clients', { search: 'cl-search', status: 'cl-filter-status' }));
document.getElementById('tc-export-btn').addEventListener('click', () => exportCsv('technicians', { search: 'tc-search', status: 'tc-filter-status', availability: 'tc-filter-avail' }));
document.getElementById('inv-export-btn').addEventListener('click', () => exportCsv('inventory', { search: 'inv-search', category: 'inv-filter-category', status: 'inv-filter-status' }));
document.getElementById('att-export-btn').addEventListener('click', () => exportCsv('attendance', { search: 'att-search', geofence_status: 'att-filter-geofence' }));
document.getElementById('wr-export-btn').addEventListener('click', () => exportCsv('work_reports', { search: 'wr-search' }));
document.getElementById('sr-export-btn').addEventListener('click', () => exportCsv('service_requests', { status: 'sr-filter-status', search: 'sr-filter-search' }));

// ---- BILLING ----
async function loadBilling() {
  const tbody = document.getElementById('bill-table-body');
  tbody.innerHTML = `<tr><td colspan="8" class="text-slate-400 text-center py-6">Loading...</td></tr>`;
  const params = new URLSearchParams();
  const search = document.getElementById('bill-search').value;
  const status = document.getElementById('bill-filter-status').value;
  const dateFrom = document.getElementById('bill-date-from').value;
  const dateTo = document.getElementById('bill-date-to').value;
  if (search) params.set('search', search);
  if (status) params.set('status', status);
  if (dateFrom) params.set('date_from', dateFrom);
  if (dateTo) params.set('date_to', dateTo);
  try {
    const res = await stFetch('../api/billing/list.php?' + params.toString());
    const json = await res.json();
    if (!json.success) { tbody.innerHTML = `<tr><td colspan="8" class="text-red-500 py-6 text-center">${escHtml(json.message)}</td></tr>`; return; }
    const s = json.data.stats;
    document.getElementById('bill-k-total').textContent = peso(s.total_invoiced);
    document.getElementById('bill-k-paid').textContent = peso(s.paid);
    document.getElementById('bill-k-pending').textContent = peso(s.pending);
    document.getElementById('bill-k-overdue').textContent = peso(s.overdue);
    renderBarChart('bill-chart', json.data.chart.labels, json.data.chart.values, '#10b981');
    const rows = json.data.rows;
    document.getElementById('bill-empty').classList.toggle('hidden', rows.length > 0);
    const statusColor = { PENDING:'bg-slate-100 text-slate-600', PAID:'bg-emerald-100 text-emerald-700', OVERDUE:'bg-red-100 text-red-700', CANCELLED:'bg-slate-100 text-slate-400' };
    const editable = ['PENDING', 'OVERDUE'];
    tbody.innerHTML = rows.map(r => `
      <tr>
        <td class="font-semibold">${r.invoice_code}</td>
        <td>${escHtml(r.client_name)}</td>
        <td>${r.project_code ?? '—'}</td>
        <td>${peso(r.amount)}${editable.includes(r.payment_status) && Number(r.amount_paid) > 0 ? `<div class="text-[11px] text-emerald-600">${peso(r.amount_paid)} paid · ${peso(r.balance)} left</div>` : ''}</td>
        <td class="text-xs">${r.due_date ?? '—'}</td>
        <td><span class="badge ${statusColor[r.payment_status] || 'bg-slate-100 text-slate-500'}">${r.payment_status}</span></td>
        <td class="text-xs">${r.payment_date ?? '—'}</td>
        <td class="whitespace-nowrap">
          <a class="icon-btn" href="../invoice.php?id=${Number(r.id)}" target="_blank" rel="noopener" title="Invoice / PDF"><i class="fas fa-file-invoice text-orange-500"></i></a>
          ${!IS_MANAGEMENT ? `<span class="text-[11px] text-slate-300">View only</span>` : editable.includes(r.payment_status) ? `
          <button class="icon-btn bill-edit" data-id="${r.id}" title="Edit"><i class="fas fa-pen"></i></button>
          <button class="icon-btn bill-pay" data-id="${r.id}" title="Record Payment"><i class="fas fa-hand-holding-dollar text-emerald-600"></i></button>
          <button class="icon-btn bill-cancel-inv" data-id="${r.id}" title="Cancel Invoice"><i class="fas fa-ban text-red-500"></i></button>` : `<span class="text-[11px] text-slate-300">Settled</span>`}
        </td>
      </tr>`).join('');
    window.__billingCache = rows;
    if (IS_MANAGEMENT) {
      document.querySelectorAll('.bill-edit').forEach(b => b.addEventListener('click', () => openEditInvoiceModal(b.dataset.id)));
      document.querySelectorAll('.bill-pay').forEach(b => b.addEventListener('click', () => openPaymentModal(b.dataset.id)));
      document.querySelectorAll('.bill-cancel-inv').forEach(b => b.addEventListener('click', () => cancelInvoice(b.dataset.id)));
    }
  } catch (err) { tbody.innerHTML = `<tr><td colspan="8" class="text-red-500 py-6 text-center">Failed to load billing.</td></tr>`; }
}
document.getElementById('bill-filter-btn').addEventListener('click', loadBilling);

async function populateInvoiceDropdowns(selectedClientId, selectedProjectId) {
  const clientSel = document.getElementById('invoice-client');
  const projectSel = document.getElementById('invoice-project');
  clientSel.innerHTML = '<option value="">Loading clients...</option>';
  try {
    const [clientsRes, projectsRes] = await Promise.all([stFetch('../api/clients/list.php'), stFetch('../api/projects/list.php')]);
    const clientsJson = await clientsRes.json();
    const projectsJson = await projectsRes.json();
    clientSel.innerHTML = '<option value="">Select a client...</option>' +
      (clientsJson.success ? clientsJson.data.map(c => `<option value="${c.id}" ${String(c.id) === String(selectedClientId) ? 'selected' : ''}>${escHtml(c.full_name)} (${c.client_code})</option>`).join('') : '');
    window.__allProjectsForInvoice = projectsJson.success ? projectsJson.data.rows : [];
    refreshInvoiceProjectOptions(selectedClientId, selectedProjectId);
  } catch (err) {
    clientSel.innerHTML = '<option value="">Failed to load clients</option>';
  }
}
function refreshInvoiceProjectOptions(clientId, selectedProjectId) {
  const projectSel = document.getElementById('invoice-project');
  const matches = (window.__allProjectsForInvoice || []).filter(p => String(p.client_id) === String(clientId));
  projectSel.innerHTML = '<option value="">No specific project</option>' +
    matches.map(p => `<option value="${p.id}" ${String(p.id) === String(selectedProjectId) ? 'selected' : ''}>${p.project_code} — ${escHtml(p.site_name)}</option>`).join('');
}
document.getElementById('invoice-client').addEventListener('change', (e) => refreshInvoiceProjectOptions(e.target.value, null));

function setInvoiceFieldsDisabled(disabled) {
  ['invoice-client','invoice-project','invoice-amount','invoice-due-date','invoice-notes'].forEach(id => document.getElementById(id).disabled = disabled);
  document.getElementById('invoice-save').classList.toggle('hidden', disabled);
  document.getElementById('invoice-locked-note').classList.toggle('hidden', !disabled);
}
async function openAddInvoiceModal() {
  document.getElementById('invoice-modal-title').textContent = 'New Invoice';
  document.getElementById('invoice-id').value = '';
  document.getElementById('invoice-amount').value = '';
  document.getElementById('invoice-due-date').value = '';
  document.getElementById('invoice-notes').value = '';
  document.getElementById('invoice-modal-error').classList.add('hidden');
  setInvoiceFieldsDisabled(false);
  document.getElementById('invoice-modal').classList.remove('hidden');
  await populateInvoiceDropdowns(null, null);
}
async function openEditInvoiceModal(id) {
  const r = window.__billingCache.find(x => String(x.id) === String(id));
  if (!r) return;
  document.getElementById('invoice-modal-title').textContent = 'Edit Invoice — ' + r.invoice_code;
  document.getElementById('invoice-id').value = r.id;
  document.getElementById('invoice-amount').value = r.amount;
  document.getElementById('invoice-due-date').value = r.due_date ?? '';
  document.getElementById('invoice-notes').value = r.notes ?? '';
  document.getElementById('invoice-modal-error').classList.add('hidden');
  setInvoiceFieldsDisabled(!['PENDING', 'OVERDUE'].includes(r.payment_status));
  document.getElementById('invoice-modal').classList.remove('hidden');
  await populateInvoiceDropdowns(r.client_id, r.project_id);
}
document.getElementById('invoice-cancel-btn').addEventListener('click', () => document.getElementById('invoice-modal').classList.add('hidden'));
document.getElementById('invoice-save').addEventListener('click', async () => {
  const errBox = document.getElementById('invoice-modal-error'); errBox.classList.add('hidden');
  const id = document.getElementById('invoice-id').value; const isEdit = !!id;
  const payload = {
    client_id: document.getElementById('invoice-client').value,
    project_id: document.getElementById('invoice-project').value,
    amount: document.getElementById('invoice-amount').value,
    due_date: document.getElementById('invoice-due-date').value,
    notes: document.getElementById('invoice-notes').value.trim(),
    csrf_token: CSRF_TOKEN,
  };
  if (!isEdit && !payload.client_id) { errBox.textContent = 'Please select a client.'; errBox.classList.remove('hidden'); return; }
  if (!payload.amount || Number(payload.amount) <= 0) { errBox.textContent = 'Please enter a valid amount.'; errBox.classList.remove('hidden'); return; }
  if (isEdit) payload.id = id;
  try {
    const res = await fetch('../api/billing/' + (isEdit ? 'update.php' : 'create.php'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const json = await res.json();
    if (!json.success) { errBox.textContent = json.message; errBox.classList.remove('hidden'); return; }
    document.getElementById('invoice-modal').classList.add('hidden'); loadBilling(); loadDashboard();
  } catch (err) { errBox.textContent = 'Network error. Please try again.'; errBox.classList.remove('hidden'); }
});
async function cancelInvoice(id) {
  const r = window.__billingCache.find(x => String(x.id) === String(id));
  if (!r) return;
  if (!confirm(`Cancel invoice ${r.invoice_code}? This cannot be undone.`)) return;
  const res = await fetch('../api/billing/update.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, cancel: true, csrf_token: CSRF_TOKEN }) });
  const json = await res.json();
  if (!json.success) { alert(json.message); return; }
  loadBilling();
}
function openPaymentModal(id) {
  const r = window.__billingCache.find(x => String(x.id) === String(id));
  if (!r) return;
  document.getElementById('payment-invoice-id').value = r.id;
  const balance = Number(r.balance ?? r.amount);
  document.getElementById('payment-invoice-label').textContent = Number(r.amount_paid) > 0
    ? `${r.invoice_code} — ${r.client_name} — ${peso(balance)} outstanding of ${peso(r.amount)}`
    : `${r.invoice_code} — ${r.client_name} — ${peso(r.amount)} due`;
  document.getElementById('payment-amount').value = balance.toFixed(2);
  document.getElementById('payment-amount').max = balance.toFixed(2);
  document.getElementById('payment-method').value = 'Cash';
  document.getElementById('payment-reference').value = '';
  document.getElementById('payment-modal-error').classList.add('hidden');
  document.getElementById('payment-modal').classList.remove('hidden');
}
document.getElementById('payment-cancel').addEventListener('click', () => document.getElementById('payment-modal').classList.add('hidden'));
document.getElementById('payment-save').addEventListener('click', async () => {
  const errBox = document.getElementById('payment-modal-error'); errBox.classList.add('hidden');
  const payload = {
    invoice_id: document.getElementById('payment-invoice-id').value,
    amount: document.getElementById('payment-amount').value,
    payment_method: document.getElementById('payment-method').value,
    reference: document.getElementById('payment-reference').value.trim(),
    csrf_token: CSRF_TOKEN,
  };
  if (!payload.amount || Number(payload.amount) <= 0) { errBox.textContent = 'Please enter a valid amount.'; errBox.classList.remove('hidden'); return; }
  try {
    const res = await fetch('../api/billing/record_payment.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const json = await res.json();
    if (!json.success) { errBox.textContent = json.message; errBox.classList.remove('hidden'); return; }
    document.getElementById('payment-modal').classList.add('hidden'); loadBilling(); loadDashboard();
  } catch (err) { errBox.textContent = 'Network error. Please try again.'; errBox.classList.remove('hidden'); }
});

// ---- SITE MAP (live geofence view) ----
// Client pins with their geofence, open job sites, and each technician's
// latest phone location. Reloaded by the realtime heartbeat whenever jobs,
// clients, attendance or geofence pings change, and on a slow timer so a
// phone that stops pinging visibly goes stale.

/** Escape a value for insertion into popup/list HTML. Names come from public self-registration. */
function escHtml(v) {
  return String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

let siteMapInstance = null;
let siteMapFitted = false;
let siteMapOpenKey = null;        // popup to reopen after a live redraw
let siteMapMarkers = {};          // key ('client:1', 'job:5', 'tech:3') -> layer with the popup
const siteMapLayers = {};         // clients / jobs / techs -> L.layerGroup
const JOB_STAGE_COLORS = {
  SUBMITTED: '#f97316', ASSIGNED: '#f97316',
  EN_ROUTE: '#0ea5e9', ARRIVED: '#0ea5e9', IN_PROGRESS: '#0ea5e9', PAUSED: '#0ea5e9',
};

function fmtAge(sec) {
  if (sec < 60) return sec + 's ago';
  if (sec < 3600) return Math.round(sec / 60) + ' min ago';
  return Math.round(sec / 3600) + ' h ago';
}
function techColor(t) { return t.stale ? '#94a3b8' : (t.status === 'INSIDE' ? '#10b981' : '#ef4444'); }
function techStatusLabel(t) { return t.stale ? 'NO RECENT PING' : t.status; }

function ensureSiteMap() {
  if (siteMapInstance) return;
  siteMapInstance = L.map('site-map').setView([10.6765, 122.9509], 11); // Bacolod
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap contributors'
  }).addTo(siteMapInstance);

  ['clients', 'jobs', 'techs'].forEach(k => {
    siteMapLayers[k] = L.layerGroup().addTo(siteMapInstance);
    document.getElementById('map-layer-' + k).addEventListener('change', e => {
      if (e.target.checked) siteMapLayers[k].addTo(siteMapInstance);
      else siteMapInstance.removeLayer(siteMapLayers[k]);
    });
  });
  siteMapInstance.on('popupclose', () => { siteMapOpenKey = null; });
}

/** Register a layer under a key so its popup can be reopened or focused. */
function siteMapTrack(key, layer) {
  siteMapMarkers[key] = layer;
  layer.on('popupopen', () => { siteMapOpenKey = key; });
  return layer;
}

function drawClients(clients) {
  const icon = L.divIcon({
    className: '',
    html: '<div style="width:24px;height:24px;border-radius:8px;background:#0f172a;color:#fff;display:flex;align-items:center;justify-content:center;font-size:11px;box-shadow:0 2px 6px rgba(0,0,0,.35);border:2px solid #fff"><i class="fas fa-house"></i></div>',
    iconSize: [24, 24], iconAnchor: [12, 12], popupAnchor: [0, -12],
  });
  clients.forEach(c => {
    const latlng = [Number(c.lat), Number(c.lng)];
    L.circle(latlng, {
      radius: Number(c.geofence_radius_m), color: '#0ea5e9', weight: 1, dashArray: '4 4', fillOpacity: 0.05,
    }).addTo(siteMapLayers.clients);
    const topReq = c.top_open_request ? String(c.top_open_request).split('|') : null;
    const statusColor = c.client_status === 'ACTIVE' ? '#059669' : (c.client_status === 'INACTIVE' ? '#64748b' : '#dc2626');
    siteMapTrack('client:' + c.id, L.marker(latlng, { icon, title: c.client_code + ' — ' + c.name }))
      .bindPopup(`
        <div style="font-family:Inter,sans-serif;font-size:12px;min-width:220px">
          <p style="font-weight:800;margin-bottom:2px">${escHtml(c.name)}</p>
          <p style="color:#64748b;margin-bottom:4px">${escHtml(c.client_code)} · <span style="color:${statusColor};font-weight:700">${escHtml(c.client_status ?? '')}</span></p>
          <p style="color:#64748b;margin-bottom:4px">${escHtml([c.address, c.barangay, c.city, c.province].filter(Boolean).join(', '))}</p>
          ${c.phone ? `<p><b>Contact:</b> ${escHtml(c.phone)}</p>` : ''}
          <p><b>Service requests:</b> ${Number(c.total_requests)} total · ${Number(c.open_requests)} open</p>
          ${topReq ? `<p><b>Open request:</b> <a href="#" class="sr-map-view" data-code="${escHtml(topReq[0])}" style="color:#f97316;font-weight:700">${escHtml(topReq[0])}</a> · ${escHtml(srLabel(topReq[1]))}</p>` : ''}
          <p><b>Assigned technician:</b> ${escHtml(c.assigned_technician ?? '—')}</p>
          <p><b>Last service:</b> ${escHtml(c.last_service ?? 'None yet')}</p>
          <p><b>Open jobs:</b> ${Number(c.open_jobs)} · <b>Geofence:</b> ${Number(c.geofence_radius_m)} m</p>
          <p style="color:#94a3b8;margin-top:4px">${Number(c.lat).toFixed(6)}, ${Number(c.lng).toFixed(6)}</p>
        </div>`)
      .addTo(siteMapLayers.clients);
  });
}

function drawJobs(jobs) {
  jobs.forEach(j => {
    const latlng = [Number(j.site_lat), Number(j.site_lng)];
    const color = JOB_STAGE_COLORS[j.stage] || '#94a3b8';
    // The geofence Time In is actually judged against — drawn solid while the job is in the field.
    if (j.in_field) {
      L.circle(latlng, { radius: Number(j.geofence_radius_m), color, weight: 2, fillOpacity: 0.08 })
        .addTo(siteMapLayers.jobs);
    }
    siteMapTrack('job:' + j.id, L.circleMarker(latlng, {
      radius: 7, color: '#fff', weight: 2, fillColor: color, fillOpacity: 0.95,
    }))
      .bindPopup(`
        <div style="font-family:Inter,sans-serif;font-size:12px;min-width:190px">
          <p style="font-weight:800;margin-bottom:2px">${escHtml(j.job_code)} <span style="color:${color}">· ${escHtml(j.stage)}</span></p>
          <p style="color:#64748b;margin-bottom:4px">${escHtml(j.site_address)}</p>
          <p><b>Type:</b> ${escHtml(j.job_type)}</p>
          <p><b>Client:</b> ${escHtml(j.client_name)}</p>
          <p><b>Technician:</b> ${escHtml(j.technician_name ?? 'Unassigned')}</p>
          <p><b>Geofence:</b> ${Number(j.geofence_radius_m)} m</p>
          ${j.scheduled_date ? `<p><b>Scheduled:</b> ${escHtml(j.scheduled_date)}</p>` : ''}
          ${j.project_code ? `<p><b>Project:</b> ${escHtml(j.project_code)}</p>` : ''}
        </div>`)
      .addTo(siteMapLayers.jobs);
  });
}

function drawTechnicians(techs) {
  techs.forEach(t => {
    const color = techColor(t);
    const pos = [Number(t.lat), Number(t.lng)];
    const site = [Number(t.site_lat), Number(t.site_lng)];

    if (t.trail.length > 1) {
      L.polyline(t.trail, { color, weight: 3, opacity: 0.55 }).addTo(siteMapLayers.techs);
    }
    // Straight line to the site: the distance being measured.
    L.polyline([pos, site], { color, weight: 1.5, dashArray: '5 6', opacity: 0.9 }).addTo(siteMapLayers.techs);

    const icon = L.divIcon({
      className: '',
      html: `<div style="width:32px;height:32px;border-radius:50%;background:${color};color:#fff;display:flex;align-items:center;justify-content:center;font-size:14px;box-shadow:0 0 0 4px ${color}40,0 2px 8px rgba(0,0,0,.35);border:2px solid #fff"><i class="fas fa-helmet-safety"></i></div>`,
      iconSize: [32, 32], iconAnchor: [16, 16], popupAnchor: [0, -16],
    });
    siteMapTrack('tech:' + t.technician_id, L.marker(pos, { icon, zIndexOffset: 1000 }))
      .bindPopup(`
        <div style="font-family:Inter,sans-serif;font-size:12px;min-width:210px">
          <p style="font-weight:800;margin-bottom:2px">${escHtml(t.technician_name)}</p>
          <p style="color:#64748b;margin-bottom:6px">${escHtml(t.technician_code)}${t.technician_phone ? ' · ' + escHtml(t.technician_phone) : ''}</p>
          <p style="margin-bottom:4px"><span style="background:${color};color:#fff;font-weight:700;font-size:10px;padding:2px 8px;border-radius:999px">${techStatusLabel(t)}</span></p>
          <p><b>Distance to site:</b> ${Math.round(Number(t.distance_m))} m of ${Number(t.geofence_radius_m)} m</p>
          <p><b>Job:</b> ${escHtml(t.job_code)} · ${escHtml(t.stage)}</p>
          <p><b>Client:</b> ${escHtml(t.client_name)}</p>
          <p><b>Timed in:</b> ${t.timed_in_at ? escHtml(t.timed_in_at) : 'Not timed in'}</p>
          <p><b>Last ping:</b> ${fmtAge(t.age_seconds)}</p>
          ${Number(t.gps_jumps) > 0 ? `<p style="margin-top:6px;color:#dc2626;font-weight:700">⚠ ${Number(t.gps_jumps)} impossible location jump(s) — possible fake GPS</p>` : ''}
        </div>`)
      .addTo(siteMapLayers.techs);
  });
}

function renderTechList(techs, noLocation) {
  const list = document.getElementById('map-tech-list');
  list.innerHTML = techs.length ? techs.map(t => {
    const color = techColor(t);
    return `
      <button type="button" class="map-tech-item w-full text-left rounded-xl border border-slate-100 hover:border-slate-300 px-3 py-2" data-key="tech:${t.technician_id}">
        <div class="flex items-center gap-2">
          <span class="inline-block h-2.5 w-2.5 rounded-full shrink-0" style="background:${color}"></span>
          <span class="font-semibold text-sm text-slate-800 truncate">${escHtml(t.technician_name)}</span>
        </div>
        <p class="text-[11px] text-slate-500 mt-0.5 truncate">${escHtml(t.job_code)} · ${escHtml(t.client_name)}</p>
        <p class="text-[11px] mt-0.5"><span class="font-bold" style="color:${color}">${techStatusLabel(t)}</span>
          <span class="text-slate-400">· ${Math.round(Number(t.distance_m))} m · ${fmtAge(t.age_seconds)}</span></p>
        ${Number(t.gps_jumps) > 0 ? `<p class="text-[11px] font-bold text-red-600 mt-0.5"><i class="fas fa-triangle-exclamation"></i> Possible fake GPS (${Number(t.gps_jumps)} jump${Number(t.gps_jumps) > 1 ? 's' : ''})</p>` : ''}
      </button>`;
  }).join('') : `<p class="text-xs text-slate-400 py-4 text-center leading-relaxed">No technician is sending a location right now.<br>
      A technician appears here once they are en route or on site with the Field app open.
      Phones need HTTPS for GPS.</p>`;

  list.querySelectorAll('.map-tech-item').forEach(b => b.addEventListener('click', () => {
    const layerToggle = document.getElementById('map-layer-techs');
    if (!layerToggle.checked) { layerToggle.checked = true; siteMapLayers.techs.addTo(siteMapInstance); syncMapLayersLabel(); }
    const m = siteMapMarkers[b.dataset.key];
    if (!m) return;
    siteMapInstance.setView(m.getLatLng(), Math.max(siteMapInstance.getZoom(), 16));
    m.openPopup();
  }));

  document.getElementById('map-noloc-wrap').classList.toggle('hidden', noLocation.length === 0);
  document.getElementById('map-noloc-list').innerHTML = noLocation.map(j => `
    <div class="flex justify-between gap-2">
      <span class="truncate"><span class="font-semibold text-slate-700">${escHtml(j.technician_name ?? 'Unassigned')}</span> — ${escHtml(j.job_code)}</span>
      <span class="text-slate-400 whitespace-nowrap">${escHtml(j.stage)}${j.timed_in_at ? ' · timed in' : ''}</span>
    </div>`).join('');
}

async function loadSiteMap(opts = {}) {
  ensureSiteMap();
  const params = new URLSearchParams();
  const search = document.getElementById('map-search').value.trim();
  if (search) params.set('search', search);
  try {
    const res = await stFetch('../api/sitemap/list.php?' + params.toString());
    const json = await res.json();
    if (!json.success) return;
    const d = json.data;

    document.getElementById('map-k-pinned').textContent = d.stats.clients_pinned;
    document.getElementById('map-k-clients').textContent = ' / ' + d.stats.clients_total;
    document.getElementById('map-k-jobs').textContent = d.stats.open_jobs;
    document.getElementById('map-k-tracked').textContent = d.stats.techs_tracked;
    document.getElementById('map-k-inside').textContent = d.stats.inside;
    document.getElementById('map-k-outside').textContent = d.stats.outside;

    // Redraw in place. Remember which popup was open so a live update does
    // not snap it shut while someone is reading it.
    const reopen = siteMapOpenKey;
    Object.values(siteMapLayers).forEach(g => g.clearLayers());
    siteMapMarkers = {};
    drawClients(d.clients);
    drawJobs(d.jobs);
    drawTechnicians(d.technicians);
    renderTechList(d.technicians, d.field_without_location);
    if (reopen && siteMapMarkers[reopen]) siteMapMarkers[reopen].openPopup();

    // Frame the data on first load and on an explicit filter — never on a
    // live refresh, which would yank the view away from where the user zoomed.
    if (!siteMapFitted || opts.refit) {
      const points = [
        ...d.clients.map(c => [Number(c.lat), Number(c.lng)]),
        ...d.jobs.map(j => [Number(j.site_lat), Number(j.site_lng)]),
        ...d.technicians.map(t => [Number(t.lat), Number(t.lng)]),
      ];
      if (points.length) {
        siteMapInstance.fitBounds(L.latLngBounds(points).pad(0.15));
        siteMapFitted = true;
      }
    }
    setTimeout(() => siteMapInstance.invalidateSize(), 200);
  } catch (err) { /* leave the map as-is on a network error; the next refresh retries */ }
}
document.getElementById('map-filter-btn').addEventListener('click', () => loadSiteMap({ refit: true }));
// Enter / Esc on map-search are handled by its filter bar (see ADMIN_BARS).

// The heartbeat only fires when data changes. A phone that stops pinging
// changes nothing, so re-check on a slow timer to let its marker turn grey.
setInterval(() => { if (CURRENT_TAB === 'sitemap' && !document.hidden) loadSiteMap(); }, 30000);

// ---- SERVICE REQUESTS ----
const srStatusColor = { PENDING:'bg-slate-100 text-slate-600', APPROVED:'bg-blue-100 text-blue-700', REJECTED:'bg-red-100 text-red-700',
  ASSIGNED:'bg-indigo-100 text-indigo-700', SCHEDULED:'bg-violet-100 text-violet-700', IN_PROGRESS:'bg-amber-100 text-amber-700',
  ON_HOLD:'bg-slate-200 text-slate-700', COMPLETED:'bg-emerald-100 text-emerald-700', CANCELLED:'bg-slate-100 text-slate-500' };
const srLabel = (s) => String(s ?? '').replace(/_/g, ' ');

// Read-only details + full history. Admin monitors; changes are made in the Management portal.
async function viewAdminServiceRequest(id) {
  const modal = document.getElementById('sr-detail-modal');
  const body = document.getElementById('sr-detail-body');
  body.innerHTML = '<p class="text-slate-400">Loading...</p>';
  modal.classList.remove('hidden');
  try {
    const json = await (await stFetch('../api/service_requests/detail.php?id=' + encodeURIComponent(id))).json();
    if (!json.success) { body.innerHTML = `<p class="text-red-500">${escHtml(json.message)}</p>`; return; }
    const { request: r, client: c, technician: t, job: j, history } = json.data;
    document.getElementById('sr-detail-title').textContent = r.request_code + ' — ' + (r.subject || r.service_type || 'Service Request');
    const addr = r.site_address || [c.address, c.barangay, c.city, c.province].filter(Boolean).join(', ');
    const hasLoc = r.lat != null && r.lng != null;
    body.innerHTML = `
      <div class="flex flex-wrap items-center gap-2 mb-3">
        <span class="badge ${srStatusColor[r.status] ?? 'bg-slate-100 text-slate-600'}">${escHtml(srLabel(r.status))}</span>
        <span class="badge bg-slate-100 text-slate-600">${escHtml(r.priority)}</span>
        <span class="text-xs text-slate-500">${escHtml(r.service_type ?? '')}</span>
        <span class="view-only-note ml-auto">View only — managed by the Management team</span>
      </div>
      <p class="text-slate-700 whitespace-pre-line">${escHtml(r.description ?? '')}</p>
      <div class="grid sm:grid-cols-2 gap-4 mt-4">
        <div class="bg-slate-50 rounded-xl p-3">
          <p class="text-[11px] font-bold text-slate-400 uppercase mb-1">Client</p>
          <p class="font-semibold text-slate-800">${escHtml(c.name)} <span class="text-xs text-slate-400">${escHtml(c.client_code)}</span></p>
          ${c.phone ? `<p class="text-xs"><i class="fas fa-phone mr-1 text-slate-400"></i>${escHtml(c.phone)}</p>` : ''}
          ${c.email ? `<p class="text-xs break-all"><i class="fas fa-envelope mr-1 text-slate-400"></i>${escHtml(c.email)}</p>` : ''}
          <p class="text-xs text-slate-600 mt-1">${escHtml(addr || '—')}</p>
          <p class="text-[11px] text-slate-400 mt-1">${hasLoc ? Number(r.lat).toFixed(6) + ', ' + Number(r.lng).toFixed(6) : 'No map pin yet'}</p>
        </div>
        <div class="bg-slate-50 rounded-xl p-3">
          <p class="text-[11px] font-bold text-slate-400 uppercase mb-1">Assignment</p>
          <p class="text-xs"><span class="text-slate-400">Technician:</span> ${t ? `<b>${escHtml(t.name)}</b> (${escHtml(t.technician_code)})${t.phone ? ' · ' + escHtml(t.phone) : ''}` : 'Unassigned'}</p>
          <p class="text-xs mt-1"><span class="text-slate-400">Job:</span> ${j ? `${escHtml(j.job_code)} · ${escHtml(srLabel(j.stage))} · ${Number(j.progress)}%` : '—'}</p>
          <p class="text-xs mt-1"><span class="text-slate-400">Requested:</span> ${escHtml(r.date_requested ?? '—')}${r.created_by_name ? ' by ' + escHtml(r.created_by_name) : ''}</p>
          <p class="text-xs mt-1"><span class="text-slate-400">Scheduled:</span> ${escHtml(r.scheduled_date ?? '—')}</p>
          <p class="text-xs mt-1"><span class="text-slate-400">Completed:</span> ${escHtml(r.completion_date ?? '—')}</p>
        </div>
      </div>
      ${r.technician_notes ? `<p class="text-[11px] font-bold text-slate-400 uppercase mt-4 mb-1">Technician notes</p><p class="text-xs whitespace-pre-line bg-amber-50 rounded-lg p-3">${escHtml(r.technician_notes)}</p>` : ''}
      ${r.resolution ? `<p class="text-[11px] font-bold text-slate-400 uppercase mt-4 mb-1">Resolution</p><p class="text-xs whitespace-pre-line bg-emerald-50 rounded-lg p-3">${escHtml(r.resolution)}</p>` : ''}
      <p class="text-[11px] font-bold text-slate-400 uppercase mt-5 mb-2">History</p>
      ${history.length ? `<div class="border-l-2 border-slate-200 ml-1 pl-4 space-y-3">${history.map(h => `
        <div class="relative"><span class="absolute -left-[22px] top-1 h-2.5 w-2.5 rounded-full bg-solar"></span>
          <p class="font-semibold text-slate-800">${escHtml(srLabel(h.action))}
            ${h.old_status && h.new_status && h.old_status !== h.new_status ? `<span class="text-xs font-normal text-slate-500">${escHtml(srLabel(h.old_status))} → ${escHtml(srLabel(h.new_status))}</span>` : ''}</p>
          <p class="text-[11px] text-slate-400">${escHtml(h.created_at)} · ${escHtml(h.user_name ?? 'System')}${h.user_role ? ' (' + escHtml(h.user_role) + ')' : ''}</p>
          ${h.remarks ? `<p class="text-xs text-slate-600 mt-0.5 whitespace-pre-line">${escHtml(h.remarks)}</p>` : ''}
        </div>`).join('')}</div>` : '<p class="text-slate-400">No history recorded yet.</p>'}`;
  } catch (err) { body.innerHTML = '<p class="text-red-500">Failed to load the request.</p>'; }
}
document.getElementById('sr-detail-close').addEventListener('click', () => document.getElementById('sr-detail-modal').classList.add('hidden'));

// "Open request" link inside a site-map pin: jump to that request in the Service Requests tab.
document.addEventListener('click', (e) => {
  const a = e.target.closest('.sr-map-view');
  if (!a) return;
  e.preventDefault();
  document.getElementById('sr-filter-status').value = '';
  document.getElementById('sr-filter-search').value = a.dataset.code;
  const link = document.querySelector('.tab-link[data-tab="service-requests"]');
  if (link) link.click();
});

async function loadAdminServiceRequests() {
  const list = document.getElementById('admin-sr-list');
  list.innerHTML = '<p class="text-slate-400 py-4">Loading...</p>';
  const params = new URLSearchParams();
  const status = document.getElementById('sr-filter-status').value;
  const search = document.getElementById('sr-filter-search').value;
  if (status) params.set('status', status);
  if (search) params.set('search', search);
  try {
    const res = await stFetch('../api/service_requests/list.php?' + params.toString());
    const json = await res.json();
    if (!json.success) { list.innerHTML = `<p class="text-red-500 py-4">${escHtml(json.message)}</p>`; return; }
    list.innerHTML = json.data.length ? json.data.map(sr => `
      <div class="py-3 flex items-center justify-between gap-4">
        <div class="min-w-0">
          <p class="font-semibold text-slate-900">${escHtml(sr.request_code)} — ${escHtml(sr.subject || sr.request_type)}</p>
          <p class="text-xs text-slate-500">${escHtml(sr.request_type)} · ${escHtml(sr.client_name)} (${escHtml(sr.client_code)}) · ${escHtml(sr.priority)} · requested ${escHtml(String(sr.date_requested ?? '').slice(0, 10))}</p>
          ${sr.technician_name ? `<p class="text-xs text-solar mt-0.5">Assigned: ${escHtml(sr.technician_name)}${sr.job_code ? ' · ' + escHtml(sr.job_code) : ''}</p>` : ''}
          ${sr.scheduled_date ? `<p class="text-xs text-violet-600 mt-0.5">Scheduled: ${escHtml(sr.scheduled_date)}</p>` : ''}
        </div>
        <div class="flex items-center gap-2 shrink-0">
          <button class="sr-view link-btn text-slate-600" data-id="${sr.id}"><i class="fas fa-eye mr-1"></i>Details</button>
          <span class="badge ${srStatusColor[sr.status] ?? 'bg-slate-100 text-slate-600'}">${escHtml(srLabel(sr.status))}</span>
          ${IS_MANAGEMENT && sr.status === 'PENDING' ? `<button class="sr-approve link-btn text-emerald-600" data-id="${sr.id}">Approve</button><button class="sr-reject link-btn text-red-500" data-id="${sr.id}">Reject</button>` : ''}
          ${IS_MANAGEMENT && sr.status === 'APPROVED' ? `<button class="sr-open-assign link-btn text-navy" data-id="${sr.id}" data-code="${sr.request_code}">Assign</button>` : ''}
          ${!IS_MANAGEMENT ? `<span class="text-[11px] text-slate-300">View only</span>` : ''}
        </div>
      </div>`).join('') : '<p class="text-slate-400 py-4">No matching service requests.</p>';
    document.querySelectorAll('.sr-view').forEach(b => b.addEventListener('click', () => viewAdminServiceRequest(b.dataset.id)));
    document.querySelectorAll('.sr-approve').forEach(b => b.addEventListener('click', () => srAction(b.dataset.id, 'APPROVE')));
    document.querySelectorAll('.sr-reject').forEach(b => b.addEventListener('click', () => srAction(b.dataset.id, 'REJECT')));
    document.querySelectorAll('.sr-open-assign').forEach(b => b.addEventListener('click', () => openAssignModal(b.dataset.id, b.dataset.code)));
  } catch (err) { list.innerHTML = '<p class="text-red-500 py-4">Failed to load requests.</p>'; }
}
async function srAction(id, action) {
  await fetch('../api/service_requests/update.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, action, csrf_token: CSRF_TOKEN }) });
  loadAdminServiceRequests(); loadDashboard();
}
async function openAssignModal(id, code) {
  assignTargetId = id;
  document.getElementById('assign-sr-code').textContent = code;
  const select = document.getElementById('assign-tech-select');
  select.innerHTML = '<option>Loading technicians...</option>';
  document.getElementById('assign-modal').classList.remove('hidden');
  const res = await stFetch('../api/technicians/list.php');
  const json = await res.json();
  select.innerHTML = json.success ? json.data.map(t => `<option value="${t.id}">${escHtml(t.full_name)} (${t.technician_code}) — ${t.availability ?? 'AVAILABLE'}</option>`).join('') : '<option>Failed to load technicians</option>';
}
document.getElementById('assign-cancel').addEventListener('click', () => document.getElementById('assign-modal').classList.add('hidden'));
document.getElementById('assign-confirm').addEventListener('click', async () => {
  const techId = document.getElementById('assign-tech-select').value;
  await fetch('../api/service_requests/assign.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: assignTargetId, technician_id: techId, csrf_token: CSRF_TOKEN }) });
  document.getElementById('assign-modal').classList.add('hidden');
  loadAdminServiceRequests(); loadDashboard();
});
document.getElementById('sr-filter-btn').addEventListener('click', loadAdminServiceRequests);

// ---- INVENTORY ----
const statusColor = { ACTIVE:'bg-emerald-100 text-emerald-700', LOW_STOCK:'bg-amber-100 text-amber-700', OUT_OF_STOCK:'bg-red-100 text-red-700', DISCONTINUED:'bg-slate-100 text-slate-500' };
async function loadInventory() {
  const tbody = document.getElementById('inv-table-body');
  tbody.innerHTML = `<tr><td colspan="8" class="text-slate-400 text-center py-6">Loading...</td></tr>`;
  const params = new URLSearchParams();
  const search = document.getElementById('inv-search').value, cat = document.getElementById('inv-filter-category').value, status = document.getElementById('inv-filter-status').value;
  if (search) params.set('search', search); if (cat) params.set('category', cat); if (status) params.set('status', status);
  try {
    const res = await stFetch('../api/inventory/list.php?' + params.toString());
    const json = await res.json();
    if (!json.success) { tbody.innerHTML = `<tr><td colspan="8" class="text-red-500 py-6 text-center">${escHtml(json.message)}</td></tr>`; return; }
    const items = json.data;
    document.getElementById('inv-empty').classList.toggle('hidden', items.length > 0);
    tbody.innerHTML = items.map(i => `
      <tr>
        <td class="font-mono text-xs">${i.sku}</td>
        <td class="font-semibold">${escHtml(i.item_name)}<div class="text-xs text-slate-400">${escHtml(i.brand ?? '')} ${escHtml(i.model ?? '')}</div></td>
        <td>${escHtml(i.category_name)}</td><td>${i.quantity}</td><td>${peso(i.unit_cost)}</td><td>${escHtml(i.warehouse_location ?? '—')}</td>
        <td><span class="badge ${statusColor[i.status] ?? 'bg-slate-100 text-slate-600'}">${i.status.replace('_',' ')}</span></td>
        <td class="whitespace-nowrap">
          ${IS_MANAGEMENT ? `
          <button class="icon-btn edit-item" data-id="${i.id}" title="Edit"><i class="fas fa-pen"></i></button>
          <button class="icon-btn move-receive" data-id="${i.id}" data-name="${escHtml(i.item_name)}" title="Receive"><i class="fas fa-truck-ramp-box"></i></button>
          <button class="icon-btn move-issue" data-id="${i.id}" data-name="${escHtml(i.item_name)}" title="Issue"><i class="fas fa-hand-holding"></i></button>
          <button class="icon-btn move-return" data-id="${i.id}" data-name="${escHtml(i.item_name)}" title="Return"><i class="fas fa-rotate-left"></i></button>` : ''}
          <button class="icon-btn view-history" data-id="${i.id}" data-name="${escHtml(i.item_name)}" title="History"><i class="fas fa-clock-rotate-left"></i></button>
        </td>
      </tr>`).join('');
    window.__inventoryCache = items;
    if (IS_MANAGEMENT) {
    document.querySelectorAll('.edit-item').forEach(b => b.addEventListener('click', () => openEditItemModal(b.dataset.id)));
    document.querySelectorAll('.move-receive').forEach(b => b.addEventListener('click', () => openMoveModal('receive', b.dataset.id, b.dataset.name)));
    document.querySelectorAll('.move-issue').forEach(b => b.addEventListener('click', () => openMoveModal('issue', b.dataset.id, b.dataset.name)));
    document.querySelectorAll('.move-return').forEach(b => b.addEventListener('click', () => openMoveModal('return', b.dataset.id, b.dataset.name)));
    }
    document.querySelectorAll('.view-history').forEach(b => b.addEventListener('click', () => openHistoryModal(b.dataset.id, b.dataset.name)));
  } catch (err) { tbody.innerHTML = `<tr><td colspan="8" class="text-red-500 py-6 text-center">Failed to load inventory.</td></tr>`; }
}
document.getElementById('inv-filter-btn').addEventListener('click', loadInventory);
function openAddItemModal() {
  document.getElementById('item-modal-title').textContent = 'Add Inventory Item';
  document.getElementById('item-id').value = '';
  ['item-name','item-brand','item-model','item-serial','item-location'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('item-category').value = 'Solar Panel';
  document.getElementById('item-qty').value = 0; document.getElementById('item-cost').value = 0;
  document.getElementById('item-qty').disabled = false;
  document.getElementById('item-modal-error').classList.add('hidden');
  document.getElementById('item-modal').classList.remove('hidden');
}
function openEditItemModal(id) {
  const item = window.__inventoryCache.find(i => String(i.id) === String(id));
  if (!item) return;
  document.getElementById('item-modal-title').textContent = 'Edit Inventory Item';
  document.getElementById('item-id').value = item.id;
  document.getElementById('item-name').value = item.item_name;
  document.getElementById('item-category').value = item.category_name;
  document.getElementById('item-brand').value = item.brand ?? '';
  document.getElementById('item-model').value = item.model ?? '';
  document.getElementById('item-serial').value = item.serial_number ?? '';
  document.getElementById('item-qty').value = item.quantity; document.getElementById('item-qty').disabled = true;
  document.getElementById('item-cost').value = item.unit_cost;
  document.getElementById('item-location').value = item.warehouse_location ?? '';
  document.getElementById('item-modal-error').classList.add('hidden');
  document.getElementById('item-modal').classList.remove('hidden');
}
document.getElementById('item-cancel').addEventListener('click', () => document.getElementById('item-modal').classList.add('hidden'));
document.getElementById('item-save').addEventListener('click', async () => {
  const errBox = document.getElementById('item-modal-error'); errBox.classList.add('hidden');
  const id = document.getElementById('item-id').value; const isEdit = !!id;
  const payload = { item_name: document.getElementById('item-name').value.trim(), category: document.getElementById('item-category').value,
    brand: document.getElementById('item-brand').value.trim(), model: document.getElementById('item-model').value.trim(),
    serial_number: document.getElementById('item-serial').value.trim(), unit_cost: document.getElementById('item-cost').value,
    warehouse_location: document.getElementById('item-location').value.trim(), csrf_token: CSRF_TOKEN };
  if (!isEdit) payload.quantity = document.getElementById('item-qty').value; if (isEdit) payload.id = id;
  if (!payload.item_name) { errBox.textContent = 'Item name is required.'; errBox.classList.remove('hidden'); return; }
  try {
    const res = await fetch('../api/inventory/' + (isEdit ? 'update.php' : 'create.php'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const json = await res.json();
    if (!json.success) { errBox.textContent = json.message; errBox.classList.remove('hidden'); return; }
    document.getElementById('item-modal').classList.add('hidden'); loadInventory();
  } catch (err) { errBox.textContent = 'Network error. Please try again.'; errBox.classList.remove('hidden'); }
});
async function openMoveModal(mode, invId, itemName) {
  moveMode = mode;
  document.getElementById('move-inv-id').value = invId;
  document.getElementById('move-qty').value = 1;
  document.getElementById('move-modal-error').classList.add('hidden');
  document.getElementById('move-modal-item').textContent = itemName;
  document.getElementById('move-modal-title').textContent = mode === 'receive' ? 'Receive Stock' : mode === 'issue' ? 'Issue Stock to Job' : 'Return Stock from Job';
  const jobWrap = document.getElementById('move-job-wrap');
  if (mode === 'receive') { jobWrap.classList.add('hidden'); }
  else {
    jobWrap.classList.remove('hidden');
    const select = document.getElementById('move-job-select'); select.innerHTML = '<option>Loading jobs...</option>';
    const res = await fetch('../api/jobs/active.php'); const json = await res.json();
    select.innerHTML = json.success && json.data.length ? json.data.map(j => `<option value="${j.id}">${j.job_code} — ${escHtml(j.client_name)} (${escHtml(j.technician_name ?? 'unassigned')})</option>`).join('') : '<option value="">No active jobs</option>';
  }
  document.getElementById('move-modal').classList.remove('hidden');
}
document.getElementById('move-cancel').addEventListener('click', () => document.getElementById('move-modal').classList.add('hidden'));
document.getElementById('move-confirm').addEventListener('click', async () => {
  const errBox = document.getElementById('move-modal-error'); errBox.classList.add('hidden');
  const invId = document.getElementById('move-inv-id').value, qty = document.getElementById('move-qty').value, jobId = document.getElementById('move-job-select').value;
  if (moveMode !== 'receive' && !jobId) { errBox.textContent = 'Please select a job.'; errBox.classList.remove('hidden'); return; }
  const endpoint = moveMode === 'receive' ? 'receive.php' : moveMode === 'issue' ? 'issue.php' : 'return.php';
  const payload = { inventory_id: invId, quantity: qty, csrf_token: CSRF_TOKEN };
  if (moveMode !== 'receive') payload.job_id = jobId;
  try {
    const res = await fetch('../api/inventory/' + endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const json = await res.json();
    if (!json.success) { errBox.textContent = json.message; errBox.classList.remove('hidden'); return; }
    document.getElementById('move-modal').classList.add('hidden'); loadInventory(); loadDashboard();
  } catch (err) { errBox.textContent = 'Network error. Please try again.'; errBox.classList.remove('hidden'); }
});
async function openHistoryModal(invId, itemName) {
  document.getElementById('history-modal-title').textContent = 'Stock History — ' + itemName;
  const list = document.getElementById('history-list'); list.innerHTML = '<p class="text-slate-400 py-4">Loading...</p>';
  document.getElementById('history-modal').classList.remove('hidden');
  const res = await fetch('../api/inventory/movements.php?inventory_id=' + invId); const json = await res.json();
  list.innerHTML = json.success && json.data.length ? json.data.map(m => `
    <div class="py-2.5 flex justify-between items-center"><div><p class="font-semibold text-slate-900">${m.movement_type} — ${m.quantity} units</p><p class="text-xs text-slate-500">${escHtml(m.reference ?? '')}${m.job_code ? ' · ' + m.job_code : ''}</p></div><p class="text-xs text-slate-400">${m.created_at}</p></div>`).join('')
    : '<p class="text-slate-400 py-4">No movement history yet.</p>';
}
document.getElementById('history-close').addEventListener('click', () => document.getElementById('history-modal').classList.add('hidden'));

// ---- CLIENTS ----
async function loadClients() {
  const tbody = document.getElementById('cl-table-body');
  tbody.innerHTML = `<tr><td colspan="8" class="text-slate-400 text-center py-6">Loading...</td></tr>`;
  const params = new URLSearchParams();
  const search = document.getElementById('cl-search').value, status = document.getElementById('cl-filter-status').value;
  if (search) params.set('search', search); if (status) params.set('status', status);
  try {
    const res = await stFetch('../api/clients/list.php?' + params.toString());
    const json = await res.json();
    if (!json.success) { tbody.innerHTML = `<tr><td colspan="8" class="text-red-500 py-6 text-center">${escHtml(json.message)}</td></tr>`; return; }
    const rows = json.data;
    document.getElementById('cl-empty').classList.toggle('hidden', rows.length > 0);
    tbody.innerHTML = rows.map(c => `
      <tr>
        <td class="font-mono text-xs">${c.client_code}</td>
        <td class="font-semibold">${escHtml(c.full_name)}</td>
        <td><div>${escHtml(c.email)}</div><div class="text-xs text-slate-400">${escHtml(c.phone ?? '')}</div></td>
        <td>
          ${escHtml(c.city ?? '—')}
          ${Number(c.has_coordinates) === 1
            ? `<span class="badge bg-emerald-50 text-emerald-700 ml-1" title="Site plotted at ${c.lat}, ${c.lng} · ${c.geofence_radius_m} m radius"><i class="fas fa-location-dot"></i> Geofenced</span>`
            : `<span class="badge bg-amber-50 text-amber-700 ml-1" title="No site coordinates. Technicians cannot Time In on this client's jobs until the location is plotted."><i class="fas fa-triangle-exclamation"></i> No pin</span>`}
        </td>
        <td>${c.system_count}</td>
        <td>${c.open_requests}</td>
        <td><span class="badge ${c.status === 'ACTIVE' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}">${c.status}</span></td>
        <td class="whitespace-nowrap">
          ${IS_MANAGEMENT ? `
          <button class="icon-btn cl-edit" data-id="${c.id}" title="Edit"><i class="fas fa-pen"></i></button>
          <button class="icon-btn cl-toggle" data-id="${c.id}" data-status="${c.status}" title="${c.status === 'ACTIVE' ? 'Deactivate' : 'Activate'}"><i class="fas ${c.status === 'ACTIVE' ? 'fa-user-slash' : 'fa-user-check'}"></i></button>` : `<span class="text-[11px] text-slate-300">View only</span>`}
        </td>
      </tr>`).join('');
    window.__clientsCache = rows;
    if (IS_MANAGEMENT) {
    document.querySelectorAll('.cl-edit').forEach(b => b.addEventListener('click', () => openEditClientModal(b.dataset.id)));
    document.querySelectorAll('.cl-toggle').forEach(b => b.addEventListener('click', () => toggleClientStatus(b.dataset.id, b.dataset.status)));
    }
  } catch (err) { tbody.innerHTML = `<tr><td colspan="8" class="text-red-500 py-6 text-center">Failed to load clients.</td></tr>`; }
}
document.getElementById('cl-filter-btn').addEventListener('click', loadClients);
async function toggleClientStatus(id, currentStatus) {
  const newStatus = currentStatus === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
  await fetch('../api/clients/toggle_status.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, status: newStatus, csrf_token: CSRF_TOKEN }) });
  loadClients(); loadDashboard();
}
// --- Client site-location picker -------------------------------------------
// Leaflet is already loaded for the Site Map tab, so the picker reuses it.
let clientMap = null, clientMarker = null, clientCircle = null;

// Centre of Bais City, Negros Oriental — a sensible starting view for a
// new client with nothing plotted yet.
const DEFAULT_MAP_CENTRE = [9.5907, 123.1214];

function clientRadiusValue() {
  const v = parseInt(document.getElementById('client-radius').value, 10);
  return (isNaN(v) || v <= 0) ? 500 : v;
}

function setClientPin(lat, lng, recentre) {
  document.getElementById('client-lat').value = Number(lat).toFixed(7);
  document.getElementById('client-lng').value = Number(lng).toFixed(7);
  if (!clientMap) return;

  const pos = [lat, lng];
  if (clientMarker) clientMarker.setLatLng(pos);
  else clientMarker = L.marker(pos, { draggable: true }).addTo(clientMap)
        .on('dragend', (e) => { const p = e.target.getLatLng(); setClientPin(p.lat, p.lng, false); });

  if (clientCircle) { clientCircle.setLatLng(pos); clientCircle.setRadius(clientRadiusValue()); }
  else clientCircle = L.circle(pos, { radius: clientRadiusValue(), color: '#f97316', weight: 2, fillColor: '#f97316', fillOpacity: 0.12 }).addTo(clientMap);

  if (recentre) clientMap.setView(pos, 15);
}

function initClientMap(lat, lng) {
  const el = document.getElementById('client-map');
  if (!el || typeof L === 'undefined') return;

  const centre = (lat != null && lng != null) ? [lat, lng] : DEFAULT_MAP_CENTRE;

  if (!clientMap) {
    clientMap = L.map(el).setView(centre, lat != null ? 15 : 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors', maxZoom: 19
    }).addTo(clientMap);
    clientMap.on('click', (e) => setClientPin(e.latlng.lat, e.latlng.lng, false));
  }

  // Clear any pin left over from the previously edited client.
  if (clientMarker) { clientMap.removeLayer(clientMarker); clientMarker = null; }
  if (clientCircle) { clientMap.removeLayer(clientCircle); clientCircle = null; }

  clientMap.setView(centre, lat != null ? 15 : 12);
  if (lat != null && lng != null) setClientPin(lat, lng, true);

  // The map was sized while its container was display:none, so Leaflet has the
  // wrong dimensions until it is told to re-measure.
  setTimeout(() => clientMap.invalidateSize(), 120);
}

document.getElementById('client-radius').addEventListener('input', () => {
  if (clientCircle) clientCircle.setRadius(clientRadiusValue());
});

document.getElementById('client-use-my-location').addEventListener('click', () => {
  if (!navigator.geolocation) { alert('This browser cannot provide a location.'); return; }
  navigator.geolocation.getCurrentPosition(
    (pos) => setClientPin(pos.coords.latitude, pos.coords.longitude, true),
    (err) => alert('Could not read your location: ' + err.message
      + (location.protocol !== 'https:' && location.hostname !== 'localhost'
         ? '\n\nBrowsers only allow location over HTTPS or on localhost.' : '')),
    { enableHighAccuracy: true, timeout: 10000 }
  );
});

// Typing coordinates by hand should move the pin too.
['client-lat','client-lng'].forEach(id => {
  document.getElementById(id).addEventListener('change', () => {
    const lat = parseFloat(document.getElementById('client-lat').value);
    const lng = parseFloat(document.getElementById('client-lng').value);
    if (!isNaN(lat) && !isNaN(lng)) setClientPin(lat, lng, true);
  });
});

function openAddClientModal() {
  document.getElementById('client-modal-title').textContent = 'Add Client';
  document.getElementById('client-id').value = '';
  ['client-name','client-email','client-phone','client-address','client-city','client-province','client-password','client-lat','client-lng'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('client-radius').value = 500;
  document.getElementById('client-propagate-wrap').classList.add('hidden');
  document.getElementById('client-propagate').checked = false;
  initClientMap(null, null);
  document.getElementById('client-email').disabled = false;
  document.getElementById('client-password-wrap').classList.remove('hidden');
  document.getElementById('client-reset-wrap').classList.add('hidden');
  document.getElementById('client-modal-error').classList.add('hidden');
  document.getElementById('client-modal').classList.remove('hidden');
}
function openEditClientModal(id) {
  const c = window.__clientsCache.find(x => String(x.id) === String(id));
  if (!c) return;
  document.getElementById('client-modal-title').textContent = 'Edit Client';
  document.getElementById('client-id').value = c.id;
  document.getElementById('client-name').value = c.full_name;
  document.getElementById('client-email').value = c.email;
  document.getElementById('client-email').disabled = true;
  document.getElementById('client-phone').value = c.phone ?? '';
  document.getElementById('client-address').value = c.address ?? '';
  document.getElementById('client-city').value = c.city ?? '';
  document.getElementById('client-province').value = c.province ?? '';
  document.getElementById('client-lat').value = c.lat ?? '';
  document.getElementById('client-lng').value = c.lng ?? '';
  document.getElementById('client-radius').value = c.geofence_radius_m ?? 500;
  document.getElementById('client-propagate-wrap').classList.remove('hidden');
  document.getElementById('client-propagate').checked = false;
  initClientMap(c.lat != null ? parseFloat(c.lat) : null, c.lng != null ? parseFloat(c.lng) : null);
  document.getElementById('client-password-wrap').classList.add('hidden');
  document.getElementById('client-reset-wrap').classList.remove('hidden');
  document.getElementById('client-new-password').value = '';
  document.getElementById('client-modal-error').classList.add('hidden');
  document.getElementById('client-modal').classList.remove('hidden');
}
document.getElementById('client-cancel').addEventListener('click', () => document.getElementById('client-modal').classList.add('hidden'));
document.getElementById('client-save').addEventListener('click', async () => {
  const errBox = document.getElementById('client-modal-error'); errBox.classList.add('hidden');
  const id = document.getElementById('client-id').value; const isEdit = !!id;
  const payload = { full_name: document.getElementById('client-name').value.trim(), phone: document.getElementById('client-phone').value.trim(),
    address: document.getElementById('client-address').value.trim(), city: document.getElementById('client-city').value.trim(),
    province: document.getElementById('client-province').value.trim(), csrf_token: CSRF_TOKEN };
  if (!payload.full_name) { errBox.textContent = 'Full name is required.'; errBox.classList.remove('hidden'); return; }

  // Coordinates travel as a pair or not at all — the API rejects a half-filled
  // pair, and a record that looks plotted but is not is worse than a blank one.
  const latRaw = document.getElementById('client-lat').value.trim();
  const lngRaw = document.getElementById('client-lng').value.trim();
  if ((latRaw === '') !== (lngRaw === '')) {
    errBox.textContent = 'Enter both latitude and longitude, or leave both blank.';
    errBox.classList.remove('hidden');
    return;
  }
  payload.lat = latRaw === '' ? null : latRaw;
  payload.lng = lngRaw === '' ? null : lngRaw;

  const radiusRaw = document.getElementById('client-radius').value.trim();
  if (radiusRaw !== '') payload.geofence_radius_m = radiusRaw;

  if (document.getElementById('client-propagate').checked) payload.apply_to_open_jobs = true;
  if (isEdit) {
    payload.id = id;
    const newPw = document.getElementById('client-new-password').value;
    if (newPw) payload.new_password = newPw;
  } else {
    payload.email = document.getElementById('client-email').value.trim();
    payload.password = document.getElementById('client-password').value;
    if (!payload.email || !payload.password) { errBox.textContent = 'Email and password are required.'; errBox.classList.remove('hidden'); return; }
  }
  try {
    const res = await fetch('../api/clients/' + (isEdit ? 'update.php' : 'create.php'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const json = await res.json();
    if (!json.success) { errBox.textContent = json.message; errBox.classList.remove('hidden'); return; }
    document.getElementById('client-modal').classList.add('hidden'); loadClients(); loadDashboard();
  } catch (err) { errBox.textContent = 'Network error. Please try again.'; errBox.classList.remove('hidden'); }
});

// ---- TECHNICIANS ----
const availColor = { AVAILABLE:'bg-emerald-100 text-emerald-700', BUSY:'bg-amber-100 text-amber-700', OFF_DUTY:'bg-slate-100 text-slate-500', ON_LEAVE:'bg-red-100 text-red-700' };
async function loadTechnicians() {
  const tbody = document.getElementById('tc-table-body');
  tbody.innerHTML = `<tr><td colspan="8" class="text-slate-400 text-center py-6">Loading...</td></tr>`;
  const params = new URLSearchParams();
  const search = document.getElementById('tc-search').value, status = document.getElementById('tc-filter-status').value, avail = document.getElementById('tc-filter-avail').value;
  if (search) params.set('search', search); if (status) params.set('status', status); if (avail) params.set('availability', avail);
  try {
    const res = await stFetch('../api/technicians/list.php?' + params.toString());
    const json = await res.json();
    if (!json.success) { tbody.innerHTML = `<tr><td colspan="8" class="text-red-500 py-6 text-center">${escHtml(json.message)}</td></tr>`; return; }
    const rows = json.data;
    document.getElementById('tc-empty').classList.toggle('hidden', rows.length > 0);
    tbody.innerHTML = rows.map(t => `
      <tr>
        <td class="font-mono text-xs">${t.technician_code}</td>
        <td class="font-semibold">${escHtml(t.full_name)}</td>
        <td><div>${escHtml(t.email)}</div><div class="text-xs text-slate-400">${escHtml(t.phone ?? '')}</div></td>
        <td>${escHtml(t.specialization ?? '—')}</td>
        <td>${t.open_jobs}</td>
        <td><span class="badge ${availColor[t.availability] ?? 'bg-slate-100 text-slate-600'}">${(t.availability ?? 'AVAILABLE').replace('_',' ')}</span></td>
        <td><span class="badge ${t.status === 'ACTIVE' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}">${t.status}</span></td>
        <td class="whitespace-nowrap">
          ${IS_MANAGEMENT ? `
          <button class="icon-btn tc-edit" data-id="${t.id}" title="Edit"><i class="fas fa-pen"></i></button>
          <button class="icon-btn tc-toggle" data-id="${t.id}" data-status="${t.status}" title="${t.status === 'ACTIVE' ? 'Deactivate' : 'Activate'}"><i class="fas ${t.status === 'ACTIVE' ? 'fa-user-slash' : 'fa-user-check'}"></i></button>` : `<span class="text-[11px] text-slate-300">View only</span>`}
        </td>
      </tr>`).join('');
    window.__techsCache = rows;
    if (IS_MANAGEMENT) {
    document.querySelectorAll('.tc-edit').forEach(b => b.addEventListener('click', () => openEditTechModal(b.dataset.id)));
    document.querySelectorAll('.tc-toggle').forEach(b => b.addEventListener('click', () => toggleTechStatus(b.dataset.id, b.dataset.status)));
    }
  } catch (err) { tbody.innerHTML = `<tr><td colspan="8" class="text-red-500 py-6 text-center">Failed to load technicians.</td></tr>`; }
}
document.getElementById('tc-filter-btn').addEventListener('click', loadTechnicians);
async function toggleTechStatus(id, currentStatus) {
  const newStatus = currentStatus === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
  await fetch('../api/technicians/toggle_status.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, status: newStatus, csrf_token: CSRF_TOKEN }) });
  loadTechnicians(); loadDashboard();
}
function openAddTechModal() {
  document.getElementById('tech-modal-title').textContent = 'Add Technician';
  document.getElementById('tech-id').value = '';
  ['tech-name','tech-email','tech-phone','tech-spec','tech-password'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('tech-email').disabled = false;
  document.getElementById('tech-password-wrap').classList.remove('hidden');
  document.getElementById('tech-reset-wrap').classList.add('hidden');
  document.getElementById('tech-avail-wrap').classList.add('hidden');
  document.getElementById('tech-modal-error').classList.add('hidden');
  document.getElementById('tech-modal').classList.remove('hidden');
}
function openEditTechModal(id) {
  const t = window.__techsCache.find(x => String(x.id) === String(id));
  if (!t) return;
  document.getElementById('tech-modal-title').textContent = 'Edit Technician';
  document.getElementById('tech-id').value = t.id;
  document.getElementById('tech-name').value = t.full_name;
  document.getElementById('tech-email').value = t.email;
  document.getElementById('tech-email').disabled = true;
  document.getElementById('tech-phone').value = t.phone ?? '';
  document.getElementById('tech-spec').value = t.specialization ?? '';
  document.getElementById('tech-availability').value = t.availability ?? 'AVAILABLE';
  document.getElementById('tech-avail-wrap').classList.remove('hidden');
  document.getElementById('tech-password-wrap').classList.add('hidden');
  document.getElementById('tech-reset-wrap').classList.remove('hidden');
  document.getElementById('tech-new-password').value = '';
  document.getElementById('tech-modal-error').classList.add('hidden');
  document.getElementById('tech-modal').classList.remove('hidden');
}
document.getElementById('tech-cancel').addEventListener('click', () => document.getElementById('tech-modal').classList.add('hidden'));
document.getElementById('tech-save').addEventListener('click', async () => {
  const errBox = document.getElementById('tech-modal-error'); errBox.classList.add('hidden');
  const id = document.getElementById('tech-id').value; const isEdit = !!id;
  const payload = { full_name: document.getElementById('tech-name').value.trim(), phone: document.getElementById('tech-phone').value.trim(),
    specialization: document.getElementById('tech-spec').value.trim(), csrf_token: CSRF_TOKEN };
  if (!payload.full_name) { errBox.textContent = 'Full name is required.'; errBox.classList.remove('hidden'); return; }
  if (isEdit) {
    payload.id = id;
    payload.availability = document.getElementById('tech-availability').value;
    const newPw = document.getElementById('tech-new-password').value;
    if (newPw) payload.new_password = newPw;
  } else {
    payload.email = document.getElementById('tech-email').value.trim();
    payload.password = document.getElementById('tech-password').value;
    if (!payload.email || !payload.password) { errBox.textContent = 'Email and password are required.'; errBox.classList.remove('hidden'); return; }
  }
  try {
    const res = await fetch('../api/technicians/' + (isEdit ? 'update.php' : 'create.php'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const json = await res.json();
    if (!json.success) { errBox.textContent = json.message; errBox.classList.remove('hidden'); return; }
    document.getElementById('tech-modal').classList.add('hidden'); loadTechnicians(); loadDashboard();
  } catch (err) { errBox.textContent = 'Network error. Please try again.'; errBox.classList.remove('hidden'); }
});

// ---- ATTENDANCE & GEOFENCE ----
async function loadAttendance() {
  const tbody = document.getElementById('att-table-body');
  tbody.innerHTML = `<tr><td colspan="7" class="text-slate-400 text-center py-6">Loading...</td></tr>`;
  const params = new URLSearchParams();
  const search = document.getElementById('att-search').value;
  const geofence = document.getElementById('att-filter-geofence').value;
  const openOnly = document.getElementById('att-filter-open').checked;
  if (search) params.set('search', search);
  if (geofence) params.set('geofence_status', geofence);
  if (openOnly) params.set('open_only', '1');
  try {
    const res = await stFetch('../api/attendance/list.php?' + params.toString());
    const json = await res.json();
    if (!json.success) { tbody.innerHTML = `<tr><td colspan="7" class="text-red-500 py-6 text-center">${escHtml(json.message)}</td></tr>`; return; }
    const rows = json.data;
    document.getElementById('att-empty').classList.toggle('hidden', rows.length > 0);
    tbody.innerHTML = rows.map(a => `
      <tr>
        <td class="font-semibold">${escHtml(a.technician_name)}<div class="text-xs text-slate-400">${a.technician_code}</div></td>
        <td>${a.job_code}<div class="text-xs text-slate-400">${escHtml(a.site_address ?? '')}</div></td>
        <td class="text-xs">${a.time_in ?? '—'}</td>
        <td class="text-xs">${a.time_out ?? '<span class="text-amber-600 font-semibold">Still timed in</span>'}</td>
        <td>${a.distance_in_m !== null ? Math.round(a.distance_in_m) + 'm' : '—'}</td>
        <td>${a.distance_out_m !== null ? Math.round(a.distance_out_m) + 'm' : '—'}</td>
        <td><span class="badge ${a.geofence_status === 'INSIDE' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}">${a.geofence_status}</span></td>
      </tr>`).join('');
  } catch (err) { tbody.innerHTML = `<tr><td colspan="7" class="text-red-500 py-6 text-center">Failed to load attendance.</td></tr>`; }
}
document.getElementById('att-filter-btn').addEventListener('click', loadAttendance);

// ---- WORK REPORTS ----
async function loadWorkReports() {
  const list = document.getElementById('wr-list');
  list.innerHTML = '<p class="text-slate-400 text-sm py-4">Loading...</p>';
  const params = new URLSearchParams();
  const search = document.getElementById('wr-search').value;
  if (search) params.set('search', search);
  try {
    const res = await stFetch('../api/work_reports/list.php?' + params.toString());
    const json = await res.json();
    if (!json.success) { list.innerHTML = `<p class="text-red-500 py-4">${escHtml(json.message)}</p>`; return; }
    const rows = json.data.rows || [];
    document.getElementById('wr-empty').classList.toggle('hidden', rows.length > 0);
    list.innerHTML = rows.map(r => `
      <div class="kpi-card">
        <div class="flex items-center justify-between mb-2">
          <p class="font-semibold text-slate-900">${r.report_code} — ${r.job_code} <span class="text-slate-400 font-normal text-xs">(${escHtml(r.work_type)})</span></p>
          <span class="text-xs text-slate-400">${r.submitted_date}</span>
        </div>
        <p class="text-xs text-slate-500 mb-2">${escHtml(r.technician_name)} (${r.technician_code}) · Client: ${escHtml(r.client_name)} (${r.client_code})${r.duration_text ? ' · ' + escHtml(r.duration_text) : (r.duration_minutes ? ' · ' + r.duration_minutes + ' min' : '')}</p>
        <p class="text-sm text-slate-700">${escHtml(r.remarks)}</p>
        ${r.materials_used ? `<p class="text-xs text-slate-500 mt-1"><span class="font-semibold">Materials:</span> ${escHtml(r.materials_used)}</p>` : ''}
        ${r.issues_found ? `<p class="text-xs text-red-500 mt-1"><span class="font-semibold">Issues:</span> ${escHtml(r.issues_found)}</p>` : ''}
      </div>`).join('');
  } catch (err) { list.innerHTML = '<p class="text-red-500 py-4">Failed to load work reports.</p>'; }
}
document.getElementById('wr-filter-btn').addEventListener('click', loadWorkReports);

loadDashboard();

// ---------------------------------------------------------------------------
// Real-time updates
//
// Every table on this page is a read of data that Management, Warehouse and
// Technicians are changing continuously. Rather than each tab polling its own
// endpoint, one heartbeat reports which tables moved and the open tab reloads
// itself — so an edit made anywhere in SunTrack shows up here within one poll.
// ---------------------------------------------------------------------------

// Maps a sync channel to the admin tabs that display it.
const CHANNEL_TABS = {
  inventory:        ['dashboard', 'inventory'],
  stock_movements:  ['dashboard', 'inventory'],
  jobs:             ['dashboard', 'projects', 'attendance', 'sitemap', 'maintenance'],
  projects:         ['dashboard', 'projects', 'maintenance', 'sitemap'],
  clients:          ['dashboard', 'clients', 'sitemap'],
  technicians:      ['dashboard', 'technicians', 'attendance', 'sitemap'],
  staff:            ['dashboard', 'staff'],
  service_requests: ['dashboard', 'service-requests'],
  attendance:       ['dashboard', 'attendance', 'sitemap'],
  geofence:         ['attendance', 'sitemap'],
  maintenance:      ['dashboard', 'maintenance'],
  billing:          ['dashboard', 'billing'],
  work_reports:     ['dashboard', 'work-reports'],
  subcontractors:   ['subcontractors'],
  subcon_assignments: ['subcontractors', 'dashboard'],
  material_requests:['dashboard', 'inventory'],
  audit_logs:       ['logs'],
};

function setLiveState(ok, label) {
  const dot = document.getElementById('live-dot');
  const text = document.getElementById('live-text');
  const box = document.getElementById('live-indicator');
  if (!dot || !text || !box) return;
  box.className = 'inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-full '
    + (ok ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700');
  dot.className = 'h-2 w-2 rounded-full ' + (ok ? 'bg-emerald-500' : 'bg-amber-500');
  text.textContent = label;
}

// Briefly flag that something arrived, so a number changing on screen has a
// visible cause rather than looking like a glitch.
function flashLive(channels) {
  setLiveState(true, 'Updated');
  clearTimeout(window.__liveFlash);
  window.__liveFlash = setTimeout(() => setLiveState(true, 'Live'), 2500);
}

function reloadTabsFor(changedChannels) {
  const affected = new Set();
  changedChannels.forEach(ch => (CHANNEL_TABS[ch] || []).forEach(t => affected.add(t)));
  if (!affected.has(CURRENT_TAB)) return;

  const meta = TAB_META[CURRENT_TAB];
  if (meta && typeof meta.load === 'function') meta.load();
}

// ---------------------------------------------------------------------------
// Site Map "Show on map" dropdown. The checkboxes keep their ids, so the map's
// own change handlers (initSiteMap) still add / remove the layers.
// ---------------------------------------------------------------------------
const MAP_LAYER_NAMES = { clients: 'Client pins', jobs: 'Job sites', techs: 'Technicians' };
function syncMapLayersLabel() {
  const on = Object.keys(MAP_LAYER_NAMES).filter(k => document.getElementById('map-layer-' + k)?.checked);
  document.getElementById('map-layers-text').textContent =
    on.length === 3 ? 'All layers' : on.length === 0 ? 'Nothing shown' : on.map(k => MAP_LAYER_NAMES[k]).join(', ');
}
(function () {
  const dd = document.getElementById('map-layers-dd');
  if (!dd) return;
  const btn = document.getElementById('map-layers-btn');
  const menu = document.getElementById('map-layers-menu');
  const setOpen = (open) => { menu.classList.toggle('hidden', !open); btn.setAttribute('aria-expanded', String(open)); };
  btn.addEventListener('click', () => setOpen(menu.classList.contains('hidden')));
  document.addEventListener('click', (e) => { if (!dd.contains(e.target)) setOpen(false); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') setOpen(false); });
  // Start with every layer on (the map adds them all), even if the browser
  // tries to restore boxes left unticked before a refresh.
  menu.querySelectorAll('input[type=checkbox]').forEach(cb => { cb.checked = true; cb.addEventListener('change', syncMapLayersLabel); });
  document.getElementById('map-layers-all').addEventListener('click', () => {
    menu.querySelectorAll('input[type=checkbox]').forEach(cb => {
      if (!cb.checked) { cb.checked = true; cb.dispatchEvent(new Event('change')); }
    });
    setOpen(false);
  });
  syncMapLayersLabel();
})();

// ---------------------------------------------------------------------------
// Filter bars: search as you type, Enter / Esc, filters apply on change, and a
// Clear button next to each Filter button. The Filter buttons keep working.
// ---------------------------------------------------------------------------
const ADMIN_BARS = [
  ['sr-filter-search', ['sr-filter-status'], 'sr-filter-btn', loadAdminServiceRequests],
  ['inv-search', ['inv-filter-category', 'inv-filter-status'], 'inv-filter-btn', loadInventory],
  ['cl-search', ['cl-filter-status'], 'cl-filter-btn', loadClients],
  ['tc-search', ['tc-filter-status', 'tc-filter-avail'], 'tc-filter-btn', loadTechnicians],
  ['att-search', ['att-filter-geofence', 'att-filter-open'], 'att-filter-btn', loadAttendance],
  ['wr-search', [], 'wr-filter-btn', loadWorkReports],
  ['stf-search', ['stf-filter-status'], 'stf-filter-btn', loadStaff],
  ['prj-search', ['prj-filter-status'], 'prj-filter-btn', loadProjects],
  ['mnt-search', ['mnt-filter-status'], 'mnt-filter-btn', loadMaintenance],
  ['log-search', ['log-filter-role', 'log-filter-from', 'log-filter-to'], 'log-filter-btn', loadLogs],
  ['bill-search', ['bill-filter-status', 'bill-date-from', 'bill-date-to'], 'bill-filter-btn', loadBilling],
  ['map-search', [], 'map-filter-btn', () => loadSiteMap({ refit: true })],
];
ADMIN_BARS.forEach(([search, fields, anchor, load]) => {
  if (!document.getElementById(search)) return;
  SunTrackFilters.bind({ search, fields, anchor, onChange: () => load() });
});

SunTrackRealtime.start({
  endpoint: '../api/realtime/sync.php',
  on: {
    '*': (changed) => { flashLive(changed); reloadTabsFor(changed); },
    error: () => setLiveState(false, 'Reconnecting'),
    sessionExpired: () => { window.location.href = '<?= APP_BASE_URL ?>/login.php?expired=1'; },
  }
});
</script>

<?php include ROOT_PATH . '/includes/consent_banner.php'; ?>
</body>
</html>
