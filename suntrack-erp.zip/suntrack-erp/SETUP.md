# SunTrack ERP — Setup & Seeding

Short version for a fresh XAMPP install. Every command here was tested.

---

## The install order matters

Run these **in this exact order**:

```
1. suntrack_erp.sql                    (schema)
2. phase1_technician_migration.sql
3. phase2_management_migration.sql
4. phase3_geo_realtime_consent.sql
5. phase4_realtime_updated_at.sql
6. phase5_service_requests.sql         (Service Requests: history, scheduling, client map data)
7. phase5_material_requests.sql        (client orders: Management -> Warehouse) — optional
8. phase6_password_resets.sql          ("Forgot password" for clients & technicians)
9. phase7_beta_features.sql            (photos, sign-off, two-step login, push)
10. phase8_inventory_status_threshold.sql (stock status: under 50 units = low stock)
11. phase9_installed_equipment.sql     (exact installed panel / inverter / battery on the client's system)
    then: php database/phase9_backfill_installed_equipment.php
12. php database/phase10_project_installation_jobs.php (installation jobs for projects added before the fix)
13. phase11_work_report_duration_text.sql (work report duration typed as free text)
14. phase12_installation_stage_photos.sql (proof photos per installation checklist stage)
14b. phase13_installation_stage_plan.sql (each stage is a scheduled visit, approved by Management)
14c. phase14_project_crew.sql          (site size Small/Medium/Large and multi-technician installation crews)
14d. phase15_material_invoices.sql     (invoice created automatically when a material request is released)
14e. phase16_inventory_qr.sql          (unique QR codes, printable labels, per-unit serial tracking, quarantine, double-submit protection)
14f. phase17_dashboard_indexes.sql     (optional: two indexes that keep the Admin dashboard fast)
14g. phase18_billing_integrity.sql     (voidable, auditable payments; double-submit protection; invoice → job order link)
14h. phase19_subcontractors.sql       (subcontractor portal + logins, job offers, inspection workflow, automatic assignment when technicians are near full)
14i. phase20_maintenance_checklist.sql (maintenance inspection like the installation checklist: who/when per item, proof photos per section, Management review)
14j. phase21_service_checklists.sql  (a 2–3 step checklist with proof photos for every service request type except Maintenance; Management approves to complete the request)
15. seed.php                           (demo data — optional, run LAST)
```

Every SQL file is safe to re-run: it never drops a table and never deletes a row.

`phase5_service_requests.sql` extends the existing `service_requests` table
(subject, service date, service location, technician notes, resolution,
statuses SCHEDULED and ON_HOLD), adds `service_request_history`, and adds
`barangay` / `postal_code` to `clients`. Until it is imported, the Service
Request screens report that Phase 5 is not set up; everything else keeps
working.

`phase5_material_requests.sql` adds `material_requests`, `material_request_items`
and `stock_movements.material_request_id` — the Material Requests tab in
Management and the Client Orders tab / Prepare Order scan mode in Warehouse.
Until it is imported those tabs report that orders are not set up.

Phase 4 adds `updated_at` to `attendance` and `service_requests` so that a
Time Out, or approving/assigning a request, shows up on other screens in real
time.

**The seeder goes last.** `database/seed.php` checks that phases 1–5 (both
phase 5 files) are in place and stops with a list of the missing files if they
are not. It never
truncates or deletes anything, so it is safe on a database that already has
real data and safe to run again.

---

## Running the seeder

Use the command line. **Seeding from the browser does not work**:
`database/.htaccess` blocks all web access to the `database/` folder (on
purpose — it also holds the `.sql` schema files), so
`http://localhost/suntrack-erp/database/seed.php` always returns Apache's
`403 Forbidden`, whether or not the database is empty.

### Command line

XAMPP does not add PHP to your PATH, so use the full path to `php.exe`.

**Windows**

```cmd
cd C:\xampp\htdocs\suntrack-erp
C:\xampp\php\php.exe database\seed.php
```

**macOS (XAMPP)**

```bash
cd /Applications/XAMPP/htdocs/suntrack-erp
/Applications/XAMPP/bin/php database/seed.php
```

**Linux**

```bash
cd /opt/lampp/htdocs/suntrack-erp
/opt/lampp/bin/php database/seed.php
```

What it creates (all e-mails end in `@suntrack.test`, one demo password for
every account: **`Suntrack12345!`**, stored with `password_hash()`):

| Accounts | E-mail |
|---|---|
| 1 Admin | `admin@suntrack.test` |
| 5 Management | `manager1@suntrack.test` … `manager5@suntrack.test` |
| 1 Warehouse | `warehouse@suntrack.test` |
| 10 Technicians | `technician1@suntrack.test` … `technician10@suntrack.test` |
| 50 Clients | `client1@suntrack.test` … `client50@suntrack.test` (42 active; inactive/suspended ones cannot sign in) |

Plus demo data for every module:

- **Projects & solar systems** — 38 projects (30 installed, 3 installing right
  now, 3 scheduled, 1 planned, 1 cancelled), each with its client's solar system.
- **Installation** — 36 installation jobs with the 17-item checklist,
  attendance, GPS trail, work report, before/after photos and client sign-off.
- **Maintenance** — a schedule for every installed system (overdue, due and
  upcoming), past maintenance visits with inspection records, and one visit
  already booked.
- **Service requests** — 30 (`SR-DEMO-001` … `SR-DEMO-030`) in every status,
  19 assigned across the 10 technicians, with history, notes and resolutions.
- **Warehouse** — 15 stock items (some low, one out, one discontinued),
  receipts, issues, returns, and 16 client orders (`MR-DEMO-…`) in every status.
- **Billing** — invoices for every project and paid service visit (`INV-DEMO-…`)
  with full and partial payments, pending and overdue balances.
- **Sub-contractors, notifications and audit-log activity.**

All 50 clients have their own coordinates around Bacolod City, Talisay, Silay
and Murcia.

Re-running it is safe: accounts are matched by e-mail and updated in place
(names, phones, coordinates and the demo password are restored); everything
else is matched by its demo code and only created when missing, so work you
did on demo records during testing is kept and nothing is created twice.

The run ends with a summary like:

```
 SunTrack ERP Seed Completed

Users:
  1 Admin
  5 Management
  1 Warehouse
  10 Technicians

Clients:
  50  (42 active, 5 inactive, 3 suspended)

Service Requests:
  30  (5 pending, 4 approved, 4 assigned, 5 scheduled, 4 in progress, 1 on hold, 5 completed, 1 cancelled, 1 rejected)

All client coordinates:
  50/50  (50 distinct locations)

Database:
  suntrack_erp
```

---

## Full clean install, start to finish

Using phpMyAdmin for the SQL files and one command for the seeder.

1. **Create the database.** phpMyAdmin → Import → `database/suntrack_erp.sql`.
   (The file creates the `suntrack_erp` database itself, so do not create it
   by hand first.)

2. **Import the migrations,** in order, selecting the `suntrack_erp` database
   first each time:
   - `database/phase1_technician_migration.sql`
   - `database/phase2_management_migration.sql`
   - `database/phase3_geo_realtime_consent.sql`
   - `database/phase4_realtime_updated_at.sql`
   - `database/phase5_service_requests.sql`
   - `database/phase5_material_requests.sql` (if you have it)
   - `database/phase6_password_resets.sql`
   - `database/phase7_beta_features.sql`

3. **Seed.** In a terminal: `cd C:\xampp\htdocs\suntrack-erp` then
   `C:\xampp\php\php.exe database\seed.php`

4. **Log in** at `http://localhost/suntrack-erp/login.php` as
   `admin@suntrack.test` / `Suntrack12345!`.

5. **Check it worked.** In phpMyAdmin, run:

   ```sql
   SELECT COUNT(*) AS clients,
          SUM(lat IS NOT NULL AND lng IS NOT NULL) AS with_coords,
          COUNT(DISTINCT CONCAT(lat, ',', lng)) AS distinct_coords
   FROM clients;

   SELECT SUM(site_lat IS NULL) AS jobs_without_coords FROM jobs;
   ```

   On a fresh install expect `50 / 50 / 50` and `0`.

---

## Troubleshooting

**`403 Forbidden` when opening `database/seed.php` in a browser**
Working as intended — the `database/` folder is blocked from the web. Run the
seeder from the command line instead (see above).

**Nobody can log in / "Invalid email or password" for every account**
The database has no users, i.e. it was never seeded. Run the seeder.

**`SEED FAILED … Missing: … Import database/phaseN_….sql`**
The seeder found a migration that has not been imported yet. Import the files
it lists, in phase order, then run it again.

**`Database connection failed. Please try again later.`**
MySQL is not running, or the credentials in `config/database.php` are wrong.

**`'php' is not recognized as an internal or external command`**
XAMPP does not put PHP on your PATH. Use the full path
`C:\xampp\php\php.exe` as shown in Option B.

**404 at `/suntrack-erp/...`**
Your folder under `htdocs` has a different name. The app auto-detects its own
base URL now, so just use whatever your folder is actually called.

---

## After seeding — before real use

The seeded accounts are sample data and their passwords are in the repository.

- Change the admin password immediately.
- Delete or deactivate the sample technician, client, and warehouse accounts.
- Create a dedicated MySQL user instead of `root` with no password, and update
  `config/database.php`.
- Set `APP_ENV` to `'production'` in `config/config.php`.

See `PHASE3_CHANGES.md` §7 for the rest of the pre-launch list, and §2.1 on why
HTTPS is required before any mobile field use.
