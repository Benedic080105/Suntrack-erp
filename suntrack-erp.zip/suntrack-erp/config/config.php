<?php
/**
 * SunTrack ERP — Core configuration
 * Loaded first by every entry point (pages and API endpoints).
 */

// ---- Environment ----------------------------------------------------
require_once __DIR__ . '/env_loader.php';

define('APP_NAME', 'SunTrack ERP');
// 'development' | 'production'. Set SUNTRACK_ENV on the server (or in
// config/env.php); anything other than 'development' is treated as production,
// so a typo fails safe — errors hidden, not shown.
define('APP_ENV', app_env('SUNTRACK_ENV', 'development') === 'development' ? 'development' : 'production');

/**
 * Base URL of the installation.
 *
 * This used to be a hard-coded '/suntrack-erp', which broke every redirect the
 * moment the folder was renamed, moved to a vhost root, or served from PHP's
 * built-in server. It is now derived from where this file sits relative to the
 * web root, and is still overridable: define APP_BASE_URL before including this
 * file, or set the SUNTRACK_BASE_URL environment variable, and that value wins.
 */
if (!defined('APP_BASE_URL')) {
    $envBase = app_env('SUNTRACK_BASE_URL');

    if ($envBase !== null) {
        define('APP_BASE_URL', rtrim($envBase, '/'));
    } else {
        // config/ lives one level below the app root.
        $appRoot = str_replace('\\', '/', dirname(__DIR__));
        $docRoot = str_replace('\\', '/', rtrim($_SERVER['DOCUMENT_ROOT'] ?? '', '/'));

        $base = '';
        if ($docRoot !== '' && str_starts_with($appRoot, $docRoot)) {
            $base = rtrim(substr($appRoot, strlen($docRoot)), '/');
        }
        define('APP_BASE_URL', $base);
    }
}

// ---- Error reporting --------------------------------------------------
if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
    // In production errors go to the log, not the response body: a stack trace
    // rendered into a JSON endpoint leaks table names and filesystem paths.
    ini_set('log_errors', '1');
}

// API endpoints answer in JSON, so a PHP warning or stack trace printed into
// the body both breaks the client's JSON.parse and leaks filesystem paths and
// SQL. Even in development, API errors go to the PHP error log instead, and
// any uncaught exception becomes a clean JSON 500 (see the handler below).
if (str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/api/')) {
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    set_exception_handler(function (Throwable $e): void {
        error_log('SunTrack API ' . ($_SERVER['SCRIPT_NAME'] ?? '') . ': ' . $e);
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json');
        }
        echo json_encode([
            'success' => false,
            'message' => 'Something went wrong while processing your request. Please check your input and try again.',
            'data'    => [],
        ]);
    });
}

// ---- Timezone -----------------------------------------------------------
date_default_timezone_set('Asia/Manila');

// ---- Sessions -------------------------------------------------------------
if (session_status() === PHP_SESSION_NONE) {
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');

    // Harden the session handler itself, before the session starts.
    ini_set('session.use_strict_mode', '1');  // refuse a session id the server never issued
    ini_set('session.use_only_cookies', '1'); // never accept a session id from the URL

    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => $isHttps, // automatically marks the cookie secure once served over HTTPS
    ]);
    session_start();
}

// ---- Geofence default (also stored in `settings` table; this is the fallback) ----
define('DEFAULT_GEOFENCE_RADIUS_M', 500);

// ---- Paths ---------------------------------------------------------------
define('ROOT_PATH', dirname(__DIR__));

require_once __DIR__ . '/database.php';
require_once ROOT_PATH . '/includes/helpers.php';
require_once ROOT_PATH . '/includes/security.php';
require_once ROOT_PATH . '/middleware/auth.php';
require_once ROOT_PATH . '/includes/settings_lib.php';
require_once ROOT_PATH . '/includes/consent.php';
require_once ROOT_PATH . '/includes/technician_lib.php';
require_once ROOT_PATH . '/includes/material_lib.php';
require_once ROOT_PATH . '/includes/inventory_lib.php';
require_once ROOT_PATH . '/includes/billing_lib.php';
require_once ROOT_PATH . '/includes/subcontractor_lib.php';
require_once ROOT_PATH . '/includes/job_extras_lib.php';
require_once ROOT_PATH . '/includes/totp_lib.php';
require_once ROOT_PATH . '/includes/push_lib.php';
require_once ROOT_PATH . '/includes/service_request_lib.php';
require_once ROOT_PATH . '/includes/sr_checklist_lib.php';
require_once ROOT_PATH . '/includes/project_lib.php';
require_once ROOT_PATH . '/includes/installation_plan_lib.php';
require_once ROOT_PATH . '/includes/crew_lib.php';
require_once ROOT_PATH . '/includes/dashboard_lib.php';
require_once ROOT_PATH . '/includes/report_lib.php';

// ---- Per-request security ------------------------------------------------
send_security_headers(request_is_api());

// Expire idle / over-long sessions before any page or endpoint reads them.
if (session_enforce_timeouts()) {
    if (request_is_api()) {
        json_error('Your session has expired. Please sign in again.', 401, ['session_expired' => true]);
    }
    header('Location: ' . APP_BASE_URL . '/login.php?expired=1');
    exit;
}
