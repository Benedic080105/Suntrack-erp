<?php
/**
 * SunTrack ERP — per-server settings.
 *
 * Every value that differs between your laptop and the live server (database
 * login, development vs production) is read here, in this order:
 *
 *   1. a real environment variable (set in the hosting panel / Apache / Docker)
 *   2. config/env.php, if it exists — for shared hosting where you cannot set
 *      environment variables. Copy config/env.example.php to config/env.php
 *      and fill it in. It is never served: config/.htaccess denies the folder.
 *   3. the default passed in, which matches a stock local XAMPP install
 *
 * So a local XAMPP checkout keeps working with no env.php at all, and the
 * server's secrets never have to be committed into the code.
 */

if (!function_exists('app_env')) {
    function app_env(string $key, ?string $default = null): ?string
    {
        static $file = null;
        if ($file === null) {
            $path = __DIR__ . '/env.php';
            $loaded = is_file($path) ? require $path : [];
            $file = is_array($loaded) ? $loaded : [];
        }

        $value = getenv($key);
        if ($value !== false && $value !== '') {
            return $value;
        }
        if (array_key_exists($key, $file) && $file[$key] !== null) {
            return (string)$file[$key];
        }
        return $default;
    }
}
