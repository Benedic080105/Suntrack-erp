<?php
/**
 * SunTrack ERP — Database connection (PDO / MySQL)
 *
 * Credentials come from SUNTRACK_DB_* (environment variables or
 * config/env.php — see config/env_loader.php). With neither set, the defaults
 * are a stock local XAMPP install: user 'root', empty password. Never deploy
 * on those defaults.
 */
require_once __DIR__ . '/env_loader.php';

define('DB_HOST', app_env('SUNTRACK_DB_HOST', 'localhost'));
define('DB_NAME', app_env('SUNTRACK_DB_NAME', 'suntrack_erp'));
define('DB_USER', app_env('SUNTRACK_DB_USER', 'root'));
define('DB_PASS', app_env('SUNTRACK_DB_PASS', ''));
define('DB_CHARSET', 'utf8mb4');

/**
 * Returns a shared PDO instance. Connects once per request.
 */
function db(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
        // Make MySQL's clock (NOW(), CURDATE(), TIMESTAMP columns) match PHP's
        // Asia/Manila clock. Many hosts run MySQL on UTC, which would store
        // time-ins 8 hours off and break "today" counts between midnight and
        // 8 AM. An offset (not a zone name) works even when the host has not
        // loaded MySQL's time-zone tables; the Philippines has no daylight saving.
        $offset = (string)app_env('SUNTRACK_DB_TIMEZONE', '+08:00');
        if (!preg_match('/^[+-]\d{2}:\d{2}$/', $offset)) {
            $offset = '+08:00'; // only a strict "+HH:MM" value ever reaches the SQL
        }
        $pdo->exec("SET time_zone = '$offset'");
    } catch (PDOException $e) {
        // Never leak connection details to the client.
        http_response_code(500);
        if (defined('APP_ENV') && APP_ENV === 'development') {
            die('Database connection failed: ' . $e->getMessage());
        }
        die('Database connection failed. Please try again later.');
    }

    return $pdo;
}
