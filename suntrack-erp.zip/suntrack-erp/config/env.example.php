<?php
/**
 * Copy this file to config/env.php on the server and fill in real values.
 * Do NOT commit env.php. Environment variables with the same names win over
 * anything in this file.
 */
return [
    // 'production' hides PHP errors from visitors and logs them instead.
    'SUNTRACK_ENV'     => 'production',

    // A dedicated database user — never root. See DEPLOYMENT.md.
    'SUNTRACK_DB_HOST' => 'localhost',
    'SUNTRACK_DB_NAME' => 'suntrack_erp',
    'SUNTRACK_DB_USER' => 'suntrack_app',
    'SUNTRACK_DB_PASS' => 'change-me-to-a-long-random-password',

    // Public address of the site, used in "Forgot password" emails. REQUIRED for
    // those emails in production (never taken from the request, to block
    // reset-link poisoning). No trailing slash.
    'SUNTRACK_APP_URL' => 'https://erp.yourcompany.ph',

    // ---- Outgoing email (password reset + confirmation) -----------------
    // Gmail: turn on 2-Step Verification on the Google account, then create an
    // App Password at https://myaccount.google.com/apppasswords and paste its
    // 16 letters below (spaces are fine). Never use the normal Gmail password.
    'SUNTRACK_SMTP_HOST'   => 'smtp.gmail.com',
    'SUNTRACK_SMTP_PORT'   => '587',
    'SUNTRACK_SMTP_SECURE' => 'tls',
    'SUNTRACK_SMTP_USER'   => 'yourcompany@gmail.com',
    'SUNTRACK_SMTP_PASS'   => 'abcd efgh ijkl mnop',
    // Gmail sends only as the account you log in with, so keep these the same.
    'SUNTRACK_MAIL_FROM'      => 'yourcompany@gmail.com',
    'SUNTRACK_MAIL_FROM_NAME' => 'SunTrack ERP',
    // Only if PHP cannot verify the mail server's certificate (some Windows
    // setups): path to a cacert.pem. Leave unset on normal hosting.
    // 'SUNTRACK_SMTP_CAFILE' => 'C:/xampp/php/extras/ssl/cacert.pem',

    // Only if the app lives somewhere unusual, e.g. '/erp'. Leave unset to auto-detect.
    // 'SUNTRACK_BASE_URL' => '',
];
