<?php
require_once __DIR__ . '/../middleware/management.php';

$navItems = [
    ['key' => 'dashboard',         'label' => 'Dashboard',         'icon' => 'fa-gauge-high'],
    ['key' => 'clients',           'label' => 'Clients',           'icon' => 'fa-users'],
    ['key' => 'projects',          'label' => 'Projects',          'icon' => 'fa-diagram-project'],
    ['key' => 'service-requests',  'label' => 'Service Requests',  'icon' => 'fa-ticket'],
    ['key' => 'jobs',              'label' => 'Jobs',               'icon' => 'fa-briefcase'],
    ['key' => 'technicians',       'label' => 'Technicians',        'icon' => 'fa-user-gear'],
    ['key' => 'installation',      'label' => 'Installation',       'icon' => 'fa-solar-panel'],
    ['key' => 'maintenance',       'label' => 'Maintenance',        'icon' => 'fa-wrench'],
    ['key' => 'material-requests', 'label' => 'Material Requests',  'icon' => 'fa-dolly'],
    ['key' => 'warehouse',         'label' => 'Warehouse',          'icon' => 'fa-boxes-stacked'],
    ['key' => 'subcontractors',    'label' => 'Sub-contractors',    'icon' => 'fa-helmet-safety'],
    ['key' => 'staff',             'label' => 'Staff',              'icon' => 'fa-id-badge'],
    ['key' => 'billing',           'label' => 'Billing',            'icon' => 'fa-file-invoice-dollar'],
    ['key' => 'reports',           'label' => 'Reports',            'icon' => 'fa-chart-column'],
    ['key' => 'notifications',     'label' => 'Notifications',      'icon' => 'fa-bell'],
];
$name  = h($_SESSION['full_name']);
$token = csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SunTrack ERP — Management</title>
<script src="<?= APP_BASE_URL ?>/assets/vendor/tailwind/tailwind.js"></script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/vendor/fontawesome/css/all.min.css">
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-password.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-logout.js"></script>
<link href="<?= APP_BASE_URL ?>/assets/vendor/inter/inter.css" rel="stylesheet">
<link rel="manifest" href="<?= APP_BASE_URL ?>/manifest.json">
<meta name="theme-color" content="#0b1329">
<link rel="apple-touch-icon" href="<?= APP_BASE_URL ?>/assets/img/app/apple-touch-icon.png">
<script>tailwind.config={theme:{extend:{colors:{navy:'#0f172a',solar:'#f97316'},fontFamily:{sans:['Inter','sans-serif']}}}}</script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/vendor/leaflet/leaflet.min.css">
<script src="<?= APP_BASE_URL ?>/assets/vendor/leaflet/leaflet.min.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-realtime.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-paging.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-search.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-pwa.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/vendor/qrcode/qrcode.min.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-qrlabel.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-account.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-filters.js"></script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/css/suntrack-mobile.css">
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-tables.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/vendor/chartjs/chart.umd.min.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-admin-dashboard.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-subcon-mgmt.js"></script>
<style>
  body{font-family:'Inter',sans-serif;}
  .kpi-card{background:#fff;border-radius:1rem;padding:1.25rem;box-shadow:0 1px 3px rgba(0,0,0,.06);border:1px solid #eef0f4}
  .badge{font-size:11px;font-weight:700;padding:2px 8px;border-radius:999px;white-space:nowrap}
  select,input,textarea{outline:none}
  .modal-backdrop{background:rgba(0,0,0,.4)}
  table.data-table th{font-size:11px;text-transform:uppercase;color:#94a3b8;font-weight:700;text-align:left;padding:8px 10px}
  table.data-table td{padding:10px;font-size:13px;border-top:1px solid #f1f5f9}
  .icon-btn{font-size:12px;color:#475569;padding:4px 8px;border-radius:6px}
  .icon-btn:hover{background:#f1f5f9;color:#f97316}
  .link-btn{font-size:12px;font-weight:700;cursor:pointer}
  .tab-panel.hidden{display:none}
  @keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
  .animate-fade-in{animation:fadeIn .2s ease-out}
  /* Client map pins — colour follows the client's most pressing open service request. */
  .cmap-pin{position:relative;width:18px;height:18px;border-radius:999px;border:3px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.45)}
  .cmap-urgent{background:#ef4444}
  .cmap-normal{background:#f59e0b}
  .cmap-good{background:#10b981}
  .cmap-urgent::after{content:'';position:absolute;inset:-3px;border-radius:999px;border:3px solid #ef4444;animation:cmapPulse 1.6s ease-out infinite}
  @keyframes cmapPulse{from{transform:scale(1);opacity:.9}to{transform:scale(2.4);opacity:0}}
  .cmap-legend-btn{display:inline-flex;align-items:center;gap:6px;font-size:12px;font-weight:600;padding:4px 10px;border-radius:999px;border:1px solid #e2e8f0;background:#fff;color:#334155}
  .cmap-legend-btn.off{opacity:.4;text-decoration:line-through}
  .cmap-dot{width:10px;height:10px;border-radius:999px;display:inline-block}
  .leaflet-container{font-family:'Inter',sans-serif}
</style>
</head>
<body class="bg-slate-50 min-h-screen flex flex-col md:flex-row">

<!-- Phone top bar: on small screens the sidebar becomes a slide-out menu instead of stacking above the page. -->
<div class="md:hidden sticky top-0 z-30 bg-navy border-b border-slate-800/60 px-3 py-3 flex items-center justify-between">
  <button id="mobile-menu-btn" type="button" aria-label="Open menu" aria-controls="app-sidebar" aria-expanded="false" class="text-slate-300 hover:text-white p-2 -ml-2 rounded-lg">
    <i class="fas fa-bars text-lg"></i>
  </button>
  <div class="flex items-center gap-2">
    <div class="bg-solar p-1.5 rounded-lg text-white"><i class="fas fa-solar-panel text-sm"></i></div>
    <span class="text-white font-extrabold text-sm">SunTrack Management</span>
  </div>
  <a href="<?= APP_BASE_URL ?>/logout.php" title="Logout" class="text-slate-400 hover:text-solar p-2 -mr-2"><i class="fas fa-right-from-bracket"></i></a>
</div>
<div id="sidebar-backdrop" class="hidden md:hidden fixed inset-0 bg-black/50 z-40"></div>
<aside id="app-sidebar" class="w-64 max-w-[85vw] bg-navy text-slate-400 flex flex-col justify-between p-4 border-r border-slate-800/40 shrink-0 fixed inset-y-0 left-0 z-50 overflow-y-auto -translate-x-full transition-transform duration-300 ease-in-out md:translate-x-0 md:z-auto md:h-screen md:sticky md:top-0">
  <div>
    <div class="flex items-center gap-2 px-2 mb-6">
      <div class="bg-solar p-2 rounded-xl text-white shadow-lg shadow-orange-600/20"><i class="fas fa-solar-panel text-lg"></i></div>
      <div><p class="text-white font-extrabold text-sm leading-tight">SunTrack</p><p class="text-[10px] text-slate-500 leading-tight">Management Console</p></div>
    </div>
    <nav class="space-y-1 overflow-y-auto max-h-[75vh] pr-1">
      <?php foreach ($navItems as $item): ?>
        <a href="#" data-tab="<?= h($item['key']) ?>"
           class="tab-link flex items-center justify-between gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition hover:bg-slate-800/60 text-slate-300">
          <span class="flex items-center gap-3"><i class="fas <?= h($item['icon']) ?> w-4"></i><?= h($item['label']) ?></span>
          <?php if ($item['key'] === 'notifications'): ?>
            <span id="notif-badge" class="hidden text-[10px] bg-red-500 text-white px-1.5 py-0.5 rounded-full font-bold"></span>
          <?php endif; ?>
        </a>
      <?php endforeach; ?>
      <a href="#" data-tab="settings" class="tab-link flex items-center justify-between gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition hover:bg-slate-800/60 text-slate-300">
        <span class="flex items-center gap-3"><i class="fas fa-gear w-4"></i>Settings</span>
      </a>
    </nav>
  </div>
  <div class="bg-slate-900 border border-slate-800/60 rounded-2xl p-3 mt-6 flex items-center gap-3 shadow-inner">
    <div class="h-9 w-9 rounded-xl bg-solar flex items-center justify-center text-white text-sm font-bold"><?= h(initial($name)) ?></div>
    <div class="flex-1 min-w-0"><p class="text-white text-xs font-bold truncate"><?= $name ?></p><p class="text-[10px] text-slate-500">Management</p></div>
    <a href="<?= APP_BASE_URL ?>/logout.php" title="Logout" class="text-slate-400 hover:text-solar"><i class="fas fa-right-from-bracket"></i></a>
  </div>
</aside>
<script>
// Phone menu: open/close the sidebar drawer; picking a tab closes it again.
(function () {
  var btn = document.getElementById('mobile-menu-btn'), aside = document.getElementById('app-sidebar'), backdrop = document.getElementById('sidebar-backdrop');
  if (!btn || !aside || !backdrop) return;
  function setOpen(open) {
    aside.classList.toggle('-translate-x-full', !open);
    backdrop.classList.toggle('hidden', !open);
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  btn.addEventListener('click', function () { setOpen(aside.classList.contains('-translate-x-full')); });
  backdrop.addEventListener('click', function () { setOpen(false); });
  aside.addEventListener('click', function (e) { if (e.target.closest('.tab-link') && window.innerWidth < 768) setOpen(false); });
  window.addEventListener('resize', function () { if (window.innerWidth >= 768) setOpen(false); });
})();
</script>

<main class="flex-1 min-w-0 p-4 md:p-8">
  <header class="flex items-center justify-between mb-6">
    <div>
      <h1 id="page-title" class="text-2xl md:text-3xl font-extrabold text-slate-900">Dashboard</h1>
      <p class="text-slate-500 text-sm mt-1">The operational control center — this is where the work gets done.</p>
    </div>
    <span class="hidden md:inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-full bg-navy/10 text-navy">
      <i class="fas fa-user-gear"></i> Management
    </span>
  </header>

  <!-- DASHBOARD -->
  <section id="tab-dashboard" class="tab-panel">
    <!-- Drawn by assets/js/suntrack-admin-dashboard.js from api/dashboard/admin.php (same as Admin) -->
    <div id="sad-root"></div>
  </section>

  <!-- CLIENTS -->
  <section id="tab-clients" class="tab-panel hidden"><div id="ent-clients"></div></section>

  <!-- PROJECTS -->
  <section id="tab-projects" class="tab-panel hidden"><div id="ent-projects"></div></section>

  <!-- SERVICE REQUESTS -->
  <section id="tab-service-requests" class="tab-panel hidden">
    <div id="sr-review-banner" class="hidden mb-3"></div>
    <div class="mb-4 space-y-2">
    <div class="flex items-center gap-2">
      <input id="sr-search" type="text" placeholder="Search code, client, city, type, technician..." class="border rounded-lg px-3 py-2 text-sm flex-1 min-w-0">
      <button class="shrink-0 whitespace-nowrap bg-solar hover:bg-orange-600 text-white text-sm font-bold px-4 py-2 rounded-xl" onclick="openNewRequestModal()"><i class="fas fa-plus mr-1"></i> New Request</button>
    </div>
    <div class="flex flex-wrap gap-2 items-center">
      <select id="sr-status" class="border rounded-lg px-3 py-2 text-sm">
        <option value="">Any status</option>
        <option value="PENDING">Pending</option><option value="APPROVED">Approved</option>
        <option value="ASSIGNED">Assigned</option><option value="SCHEDULED">Scheduled</option>
        <option value="IN_PROGRESS">In Progress</option><option value="ON_HOLD">On Hold</option>
        <option value="COMPLETED">Completed</option><option value="REJECTED">Rejected</option><option value="CANCELLED">Cancelled</option>
      </select>
      <select id="sr-priority" class="border rounded-lg px-3 py-2 text-sm">
        <option value="">Any priority</option><option>LOW</option><option>NORMAL</option><option>HIGH</option><option>URGENT</option>
      </select>
      <select id="sr-type" class="border rounded-lg px-3 py-2 text-sm max-w-[220px] truncate">
        <option value="">Any service type</option>
        <?php foreach (sr_service_types() as $st): ?><option><?= h($st) ?></option><?php endforeach; ?>
      </select>
      <select id="sr-tech" class="border rounded-lg px-3 py-2 text-sm max-w-[220px] truncate"><option value="">Any technician</option></select>
      <input id="sr-from" type="date" title="Requested from" class="border rounded-lg px-3 py-2 text-sm">
      <input id="sr-to" type="date" title="Requested to" class="border rounded-lg px-3 py-2 text-sm">
      <button id="sr-refresh" class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold px-3 py-2 rounded-lg" title="Refresh" onclick="loadServiceRequests()"><i class="fas fa-rotate"></i></button>
    </div>
    </div>
    <div class="bg-white rounded-2xl border border-slate-100 overflow-x-auto">
      <table class="w-full data-table"><thead><tr>
        <th>Code</th><th>Client</th><th>Service</th><th>Priority</th><th>Status</th><th>Technician</th><th>Scheduled</th><th>Requested</th><th>Actions</th>
      </tr></thead><tbody id="sr-tbody"><tr><td colspan="9" class="text-center text-slate-400 py-6">Loading...</td></tr></tbody></table>
    </div>
  </section>

  <!-- JOBS -->
  <section id="tab-jobs" class="tab-panel hidden">
    <div class="mb-4 space-y-2">
    <div class="flex items-center gap-2">
      <input id="job-search" type="text" placeholder="Search job, client, address, technician, project..." class="border rounded-lg px-3 py-2 text-sm flex-1 min-w-0">
      <button class="shrink-0 whitespace-nowrap bg-solar hover:bg-orange-600 text-white text-sm font-bold px-4 py-2 rounded-xl" onclick="openCreateJobModal()"><i class="fas fa-plus mr-1"></i> Create Job</button>
    </div>
    <div class="flex flex-wrap gap-2 items-center">
      <select id="job-stage" class="border rounded-lg px-3 py-2 text-sm">
        <option value="">Any stage</option>
        <option>SUBMITTED</option><option>ASSIGNED</option><option>EN_ROUTE</option><option>ARRIVED</option>
        <option>IN_PROGRESS</option><option>PAUSED</option><option>COMPLETED</option><option>CANCELLED</option>
      </select>
      <select id="job-type" class="border rounded-lg px-3 py-2 text-sm">
        <option value="">Any type</option><option>INSTALLATION</option><option>MAINTENANCE</option><option>REPAIR</option><option>INSPECTION</option>
      </select>
      <select id="job-priority" class="border rounded-lg px-3 py-2 text-sm">
        <option value="">Any priority</option><option>URGENT</option><option>HIGH</option><option>NORMAL</option><option>LOW</option>
      </select>
      <select id="job-tech" class="border rounded-lg px-3 py-2 text-sm max-w-[220px] truncate"><option value="">Any technician</option></select>
      <input id="job-from" type="date" title="Scheduled from" class="border rounded-lg px-3 py-2 text-sm">
      <input id="job-to" type="date" title="Scheduled to" class="border rounded-lg px-3 py-2 text-sm">
      <label class="flex items-center gap-1 text-xs text-slate-500"><input id="job-unassigned" type="checkbox"> Unassigned only</label>
      <button id="job-refresh" class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold px-3 py-2 rounded-lg" title="Refresh" onclick="loadJobs()"><i class="fas fa-rotate"></i></button>
    </div>
    </div>
    <div class="bg-white rounded-2xl border border-slate-100 overflow-x-auto">
      <table class="w-full data-table"><thead><tr>
        <th>Job</th><th>Type</th><th>Client</th><th>Technician</th><th>Priority</th><th>Stage</th><th>Progress</th><th>Actions</th>
      </tr></thead><tbody id="job-tbody"><tr><td colspan="8" class="text-center text-slate-400 py-6">Loading...</td></tr></tbody></table>
    </div>
  </section>

  <!-- TECHNICIANS -->
  <section id="tab-technicians" class="tab-panel hidden"><div id="ent-technicians"></div></section>

  <!-- INSTALLATION -->
  <section id="tab-installation" class="tab-panel hidden">
    <div class="mb-4 space-y-2">
    <div class="flex items-center gap-2">
      <input id="inst-search" type="text" placeholder="Search job, client, site, technician, project..." class="border rounded-lg px-3 py-2 text-sm flex-1 min-w-0">
    </div>
    <div class="flex flex-wrap gap-2 items-center">
      <select id="inst-status" class="border rounded-lg px-3 py-2 text-sm">
        <option value="">Any status</option><option value="NEEDS_REVIEW">Waiting for my review</option><option value="NOT_STARTED">Not started</option><option value="IN_PROGRESS">In progress</option><option value="COMPLETED">Completed</option>
      </select>
      <input id="inst-from" type="date" title="Scheduled from" class="border rounded-lg px-3 py-2 text-sm">
      <input id="inst-to" type="date" title="Scheduled to" class="border rounded-lg px-3 py-2 text-sm">
      <button id="inst-refresh" class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold px-3 py-2 rounded-lg" title="Refresh" onclick="loadInstallation()"><i class="fas fa-rotate"></i></button>
    </div>
    </div>
    <div id="inst-review-banner" class="hidden mb-3"></div>
    <p class="text-xs text-slate-400 mb-3">Each stage is one visit: the technician does it, adds proof photos and submits it; you approve it and schedule the next visit. Click a row to review.</p>
    <div class="bg-white rounded-2xl border border-slate-100 overflow-x-auto">
      <table class="w-full data-table"><thead><tr>
        <th>Job</th><th>Site</th><th>Client</th><th>Technician</th><th>Current step</th><th>Progress</th><th>Job stage</th>
      </tr></thead><tbody id="inst-tbody"><tr><td colspan="7" class="text-center text-slate-400 py-6">Loading...</td></tr></tbody></table>
    </div>
  </section>

  <!-- MAINTENANCE -->
  <section id="tab-maintenance" class="tab-panel hidden">
    <div id="mnt-review-banner" class="hidden mb-3"></div>
    <div class="mb-4 space-y-2">
    <div class="flex items-center gap-2">
      <input id="mnt-search" type="text" placeholder="Search project, site, client, city..." class="border rounded-lg px-3 py-2 text-sm flex-1 min-w-0">
      <button class="shrink-0 whitespace-nowrap bg-solar hover:bg-orange-600 text-white text-sm font-bold px-4 py-2 rounded-xl" onclick="openScheduleMaintenanceModal()"><i class="fas fa-plus mr-1"></i> Schedule</button>
    </div>
    <div class="flex flex-wrap gap-2 items-center">
      <select id="mnt-status" class="border rounded-lg px-3 py-2 text-sm">
        <option value="">Any status</option><option>UPCOMING</option><option>DUE</option><option>OVERDUE</option>
      </select>
      <input id="mnt-from" type="date" title="Next maintenance from" class="border rounded-lg px-3 py-2 text-sm">
      <input id="mnt-to" type="date" title="Next maintenance to" class="border rounded-lg px-3 py-2 text-sm">
      <button id="mnt-refresh" class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold px-3 py-2 rounded-lg" title="Refresh" onclick="loadMaintenance()"><i class="fas fa-rotate"></i></button>
    </div>
    </div>
    <div class="bg-white rounded-2xl border border-slate-100 overflow-x-auto">
      <table class="w-full data-table"><thead><tr>
        <th>Project</th><th>Client</th><th>Last</th><th>Next</th><th>Status</th><th>Notified</th><th>Actions</th>
      </tr></thead><tbody id="mnt-tbody"><tr><td colspan="7" class="text-center text-slate-400 py-6">Loading...</td></tr></tbody></table>
    </div>
  </section>

  <!-- MATERIAL REQUESTS (client orders sent to the warehouse) -->
  <section id="tab-material-requests" class="tab-panel hidden">
    <div class="mb-2 space-y-2">
    <div class="flex items-center gap-2">
      <input id="mr-search" type="text" placeholder="Search order, client, project..." class="border rounded-lg px-3 py-2 text-sm flex-1 min-w-0">
      <button class="shrink-0 whitespace-nowrap bg-solar hover:bg-orange-600 text-white text-sm font-bold px-4 py-2 rounded-xl" onclick="openCreateMRModal()"><i class="fas fa-plus mr-1"></i> New Request</button>
    </div>
    <div class="flex flex-wrap gap-2 items-center">
      <select id="mr-status" class="border rounded-lg px-3 py-2 text-sm">
        <option value="open">Open (pending / preparing / ready)</option>
        <option value="PENDING">Pending</option><option value="PREPARING">Preparing</option><option value="READY">Ready</option>
        <option value="RELEASED">Released</option><option value="CANCELLED">Cancelled</option><option value="all">All</option>
      </select>
      <input id="mr-from" type="date" title="Requested from" class="border rounded-lg px-3 py-2 text-sm">
      <input id="mr-to" type="date" title="Requested to" class="border rounded-lg px-3 py-2 text-sm">
      <button id="mr-refresh" class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold px-3 py-2 rounded-lg" title="Refresh" onclick="loadMaterialRequests()"><i class="fas fa-rotate"></i></button>
    </div>
    </div>
    <p class="text-xs text-slate-400 mb-4">Tell the warehouse how many panels, inverters and batteries a client needs. They are notified, scan the items out, and the request turns READY — you are notified when it is ready and when it leaves.</p>
    <div class="bg-white rounded-2xl border border-slate-100 overflow-x-auto">
      <table class="w-full data-table"><thead><tr>
        <th>Request</th><th>Client</th><th>Project / Job</th><th>Panels</th><th>Inverters</th><th>Batteries</th><th>Status</th><th>Needed By</th><th>Actions</th>
      </tr></thead><tbody id="mr-tbody"><tr><td colspan="9" class="text-center text-slate-400 py-6">Loading...</td></tr></tbody></table>
    </div>
  </section>

  <!-- WAREHOUSE -->
  <section id="tab-warehouse" class="tab-panel hidden"><div id="ent-inventory"></div></section>

  <!-- SUBCONTRACTORS -->
  <!-- Drawn by assets/js/suntrack-subcon-mgmt.js: auto-assignment, subcontractors, assignments -->
  <section id="tab-subcontractors" class="tab-panel hidden"><div id="subcon-root"></div></section>

  <!-- STAFF -->
  <section id="tab-staff" class="tab-panel hidden"><div id="ent-staff"></div></section>

  <!-- BILLING -->
  <section id="tab-billing" class="tab-panel hidden">
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
      <div class="kpi-card"><p class="text-xs font-semibold text-slate-500 uppercase">Total Invoiced</p><p id="bill-k-total" class="text-xl font-extrabold text-slate-900 mt-2">—</p></div>
      <div class="kpi-card"><p class="text-xs font-semibold text-slate-500 uppercase">Paid</p><p id="bill-k-paid" class="text-xl font-extrabold text-emerald-600 mt-2">—</p></div>
      <div class="kpi-card"><p class="text-xs font-semibold text-slate-500 uppercase">Pending</p><p id="bill-k-pending" class="text-xl font-extrabold text-amber-500 mt-2">—</p></div>
      <div class="kpi-card"><p class="text-xs font-semibold text-slate-500 uppercase">Overdue</p><p id="bill-k-overdue" class="text-xl font-extrabold text-red-500 mt-2">—</p></div>
    </div>
    <div class="mb-4 space-y-2">
    <div class="flex items-center gap-2">
      <input id="bill-search" type="text" placeholder="Search invoice, client, project, payment reference..." class="border rounded-lg px-3 py-2 text-sm flex-1 min-w-0">
      <button class="shrink-0 whitespace-nowrap bg-solar hover:bg-orange-600 text-white text-sm font-bold px-4 py-2 rounded-xl" onclick="openInvoiceModal()"><i class="fas fa-plus mr-1"></i> New Invoice</button>
    </div>
    <div class="flex flex-wrap gap-2 items-center">
      <select id="bill-status" class="border rounded-lg px-3 py-2 text-sm">
        <option value="">Any status</option><option>PENDING</option><option>OVERDUE</option><option>PAID</option><option>CANCELLED</option>
      </select>
      <input id="bill-from" type="date" title="Due from" class="border rounded-lg px-3 py-2 text-sm">
      <input id="bill-to" type="date" title="Due to" class="border rounded-lg px-3 py-2 text-sm">
      <button id="bill-refresh" class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold px-3 py-2 rounded-lg" title="Refresh" onclick="loadBilling()"><i class="fas fa-rotate"></i></button>
    </div>
    </div>
    <div class="bg-white rounded-2xl border border-slate-100 overflow-x-auto">
      <table class="w-full data-table"><thead><tr>
        <th>Invoice</th><th>Client</th><th>Project</th><th>Amount</th><th>Paid</th><th>Balance</th><th>Due</th><th>Status</th><th>Actions</th>
      </tr></thead><tbody id="bill-tbody"><tr><td colspan="9" class="text-center text-slate-400 py-6">Loading...</td></tr></tbody></table>
    </div>
  </section>

  <!-- REPORTS -->
  <section id="tab-reports" class="tab-panel hidden">
    <p class="text-slate-500 text-sm mb-4">Pick a report to preview it below. The filters apply to both the preview and the CSV download.</p>
    <div class="mb-3 space-y-2">
    <div class="flex items-center gap-2">
      <select id="rep-type" class="shrink-0 border rounded-lg px-3 py-2 text-sm font-semibold" aria-label="Report">
        <?php foreach (report_definitions() as $key => $def): ?>
        <option value="<?= htmlspecialchars($key) ?>"><?= htmlspecialchars($def['label']) ?></option>
        <?php endforeach; ?>
      </select>
      <input id="rep-search" type="search" placeholder="Search..." aria-label="Search" class="border rounded-lg px-3 py-2 text-sm flex-1 min-w-0">
      <button id="rep-export-btn" class="shrink-0 whitespace-nowrap bg-solar hover:bg-orange-600 disabled:opacity-60 text-white text-sm font-bold px-4 py-2 rounded-xl" onclick="exportReport(this)"><i class="fas fa-download mr-1"></i> Export CSV</button>
    </div>
    <div class="flex flex-wrap gap-2 items-center">
      <select id="rep-status" class="border rounded-lg px-3 py-2 text-sm" aria-label="Status"></select>
      <span id="rep-dates" class="inline-flex items-center gap-1">
        <input id="rep-from" type="date" class="border rounded-lg px-3 py-2 text-sm">
        <span class="text-slate-400 text-xs">to</span>
        <input id="rep-to" type="date" class="border rounded-lg px-3 py-2 text-sm">
      </span>
      <button id="rep-clear" class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold px-3 py-2 rounded-lg hidden" onclick="clearReportFilters()"><i class="fas fa-xmark mr-1"></i> Clear filters</button>
      <button class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold px-3 py-2 rounded-lg" title="Refresh" onclick="loadReport()"><i class="fas fa-rotate"></i></button>
    </div>
    </div>
    <p id="rep-summary" class="text-xs text-slate-500 mb-2 min-h-[1rem]" aria-live="polite"></p>
    <div id="rep-table-wrap" class="bg-white rounded-2xl border border-slate-100 overflow-x-auto transition-opacity">
      <table id="report-preview-table" class="w-full data-table">
        <thead id="rep-thead"></thead>
        <tbody id="rep-tbody"></tbody>
      </table>
    </div>
  </section>

  <!-- NOTIFICATIONS -->
  <section id="tab-notifications" class="tab-panel hidden">
    <div class="flex items-center justify-between mb-4">
      <h3 class="font-bold text-slate-800">Notifications</h3>
      <button class="link-btn text-solar" onclick="markAllRead()">Mark all as read</button>
    </div>
    <div id="notif-list" class="bg-white rounded-2xl border border-slate-100 divide-y divide-slate-100"></div>
  </section>

  <!-- SETTINGS (own account, via api/account/profile.php) -->
  <section id="tab-settings" class="tab-panel hidden">
    <div class="grid lg:grid-cols-2 gap-5">
      <div class="kpi-card">
        <h3 class="font-bold text-slate-900 mb-1">My Profile</h3>
        <p class="text-xs text-slate-400 mb-4">Your own account details. Only you can change these.</p>
        <div class="space-y-3">
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Full Name</label>
            <input id="pf-name" type="text" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Email</label>
            <input id="pf-email" type="email" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Phone</label>
            <input id="pf-phone" type="tel" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Role</label>
            <input id="pf-role" type="text" disabled class="w-full rounded-lg border border-slate-200 bg-slate-50 text-slate-500 text-sm px-3 py-2"></div>
          <button id="pf-save" onclick="saveProfile(this)" class="w-full rounded-lg bg-solar hover:bg-orange-600 text-white text-sm font-bold px-4 py-2.5">Save Changes</button>
        </div>
      </div>
      <div class="kpi-card">
        <h3 class="font-bold text-slate-900 mb-1">Change Password</h3>
        <p class="text-xs text-slate-400 mb-4">You will stay signed in on this device.</p>
        <div class="space-y-3">
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Current Password</label>
            <input id="pw-current" type="password" autocomplete="current-password" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">New Password</label>
            <input id="pw-new" type="password" autocomplete="new-password" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2">
            <p class="text-[11px] text-slate-400 mt-1">At least 8 characters.</p></div>
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Confirm New Password</label>
            <input id="pw-confirm" type="password" autocomplete="new-password" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
          <button onclick="changePassword(this)" class="w-full rounded-lg bg-navy hover:bg-slate-800 text-white text-sm font-bold px-4 py-2.5">Update Password</button>
        </div>
      </div>
      <div id="twofa-card" class="kpi-card"></div>
      <div class="kpi-card" data-push-card></div>
    </div>
  </section>
</main>

<!-- MODAL -->
<div id="modal-backdrop" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center p-4 z-50">
  <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[85vh] overflow-y-auto">
    <div class="flex items-center justify-between p-5 border-b border-slate-100">
      <h3 id="modal-title" class="font-bold text-slate-800"></h3>
      <button onclick="closeModal()" class="text-slate-400 hover:text-slate-700"><i class="fas fa-xmark"></i></button>
    </div>
    <div id="modal-body" class="p-5"></div>
    <div id="modal-footer" class="flex justify-end gap-2 p-5 border-t border-slate-100">
      <button onclick="closeModal()" class="px-4 py-2 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-100">Cancel</button>
      <button id="modal-submit" class="px-4 py-2 rounded-xl text-sm font-bold text-white bg-solar hover:bg-orange-600">Save</button>
    </div>
  </div>
</div>
<div id="toast-box" class="fixed bottom-6 right-6 space-y-2 z-50"></div>

<script>
const CSRF_TOKEN = <?= json_encode($token) ?>;
const API = '../api/';

/* ---------------- core fetch helpers ---------------- */
async function apiGet(path, params) {
  const qs = params ? '?' + (params instanceof URLSearchParams ? params.toString() : new URLSearchParams(params).toString()) : '';
  try {
    const res = await stFetch(API + path + qs); // follows paged lists
    return await res.json();
  } catch (e) {
    return { success: false, message: 'Network error. Please try again.' };
  }
}
async function apiPost(path, body) {
  const payload = Object.assign({}, body, { csrf_token: CSRF_TOKEN });
  try {
    const res = await fetch(API + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    return await res.json();
  } catch (e) {
    return { success: false, message: 'Network error. Please try again.' };
  }
}
// Escapes quotes too, so the result is also safe inside an HTML attribute.
function esc(str) {
  if (str === null || str === undefined) return '';
  return String(str).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
/**
 * Read a toolbar into query params: { search: 'job-search', unassigned: 'job-unassigned' }.
 * Blank fields are left out; a checked checkbox is sent as 1.
 */
function filterParams(map) {
  const p = new URLSearchParams();
  Object.keys(map).forEach(k => {
    const el = document.getElementById(map[k]);
    if (!el) return;
    const v = el.type === 'checkbox' ? (el.checked ? '1' : '') : String(el.value).trim();
    if (v) p.set(k, v);
  });
  return p;
}
// Filter bars by tab, so each loader can report its result count.
const BARS = {};
function barCount(key, n) { if (BARS[key]) BARS[key].setCount(n); }

function debounce(fn, ms) {
  let t;
  return function (...a) { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}
function toast(msg, isError) {
  const box = document.getElementById('toast-box');
  const el = document.createElement('div');
  el.className = 'px-4 py-3 rounded-xl shadow-lg text-sm font-semibold text-white animate-fade-in ' + (isError ? 'bg-red-500' : 'bg-emerald-500');
  el.textContent = msg;
  box.appendChild(el);
  setTimeout(() => el.remove(), 3500);
}
function badge(status) {
  if (status === null || status === undefined || status === '') return '<span class="text-slate-300">—</span>';
  const s = String(status).toUpperCase();
  const green = ['ACTIVE', 'APPROVED', 'COMPLETED', 'AVAILABLE', 'PAID', 'RECEIVE'];
  const amber = ['PENDING', 'UPCOMING', 'DUE', 'LOW_STOCK', 'ON_LEAVE', 'PAUSED', 'SUBMITTED', 'NORMAL'];
  const red = ['INACTIVE', 'REJECTED', 'CANCELLED', 'OVERDUE', 'OUT_OF_STOCK', 'URGENT', 'HIGH', 'SUSPENDED', 'ISSUE'];
  const blue = ['IN_PROGRESS', 'ASSIGNED', 'EN_ROUTE', 'ARRIVED', 'BUSY', 'LOW', 'RETURN'];
  let cls = 'bg-slate-100 text-slate-600';
  if (green.indexOf(s) !== -1) cls = 'bg-emerald-100 text-emerald-700';
  else if (amber.indexOf(s) !== -1) cls = 'bg-amber-100 text-amber-700';
  else if (red.indexOf(s) !== -1) cls = 'bg-red-100 text-red-700';
  else if (blue.indexOf(s) !== -1) cls = 'bg-sky-100 text-sky-700';
  return '<span class="badge ' + cls + '">' + esc(s.replace(/_/g, ' ')) + '</span>';
}

/* ---------------- modal system ---------------- */
let MODAL_SUBMIT_HANDLER = null;
function openModal(title, bodyHtml, onSubmit) {
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').innerHTML = bodyHtml;
  document.getElementById('modal-footer').classList.remove('hidden');
  MODAL_SUBMIT_HANDLER = onSubmit;
  document.getElementById('modal-backdrop').classList.remove('hidden');
}
function openInfoModal(title, bodyHtml) {
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').innerHTML = bodyHtml;
  document.getElementById('modal-footer').classList.add('hidden');
  MODAL_SUBMIT_HANDLER = null;
  document.getElementById('modal-backdrop').classList.remove('hidden');
}
function closeModal() {
  document.getElementById('modal-backdrop').classList.add('hidden');
  MODAL_SUBMIT_HANDLER = null;
  setModalWide(false); // the service-request detail view widens it; every other form expects the narrow box
}
document.getElementById('modal-submit').addEventListener('click', async () => {
  if (!MODAL_SUBMIT_HANDLER) return;
  const ok = await MODAL_SUBMIT_HANDLER();
  if (ok !== false) closeModal();
});

/* ---------------- select option caches ---------------- */
let SELECT_OPTIONS = { clients: [], technicians: [], projects: [], activeJobs: [] };
async function loadSelectOptions() {
  const results = await Promise.all([
    apiGet('clients/list.php'),
    apiGet('technicians/list.php'),
    apiGet('projects/list.php'),
    apiGet('jobs/active.php'),
  ]);
  const c = results[0], t = results[1], p = results[2], j = results[3];
  if (c.success) {
    SELECT_OPTIONS.clients = c.data.map(r => ({ id: r.id, code: r.client_code, label: r.client_code + ' — ' + r.full_name }));
    SELECT_OPTIONS.cities = [...new Set(c.data.map(r => (r.city || '').trim()).filter(Boolean))].sort();
  }
  if (t.success) SELECT_OPTIONS.technicians = t.data.map(r => ({ id: r.id, label: r.technician_code + ' — ' + r.full_name }));
  if (p.success) SELECT_OPTIONS.projects = p.data.rows.map(r => ({ id: r.id, client_id: r.client_id, label: r.project_code + ' — ' + r.site_name }));
  if (j.success) SELECT_OPTIONS.activeJobs = j.data.map(r => ({ id: r.id, client_code: r.client_code, label: r.job_code + ' — ' + r.client_name }));
  fillDynamicFilters();
}

/**
 * Dropdown filters whose choices come from live data (cities, technicians).
 * Rebuilt after every loadSelectOptions() so a new client's city or a new
 * technician shows up, keeping whatever the user had selected.
 */
function fillDynamicFilters() {
  const fill = (sel, label, opts) => {
    if (!sel) return;
    const keep = sel.value;
    sel.innerHTML = '<option value="">' + esc(label) + '</option>' + opts.map(o => {
      const val = Array.isArray(o) ? o[0] : o, text = Array.isArray(o) ? o[1] : o;
      return '<option value="' + esc(val) + '">' + esc(text) + '</option>';
    }).join('');
    sel.value = keep;
    if (sel.value !== keep) sel.value = '';
  };
  fill(document.getElementById('job-tech'), 'Any technician', SELECT_OPTIONS.technicians.map(t => [t.id, t.label]));
  fill(document.getElementById('sr-tech'), 'Any technician', SELECT_OPTIONS.technicians.map(t => [t.id, t.label]));
  Object.keys(ENTITIES).forEach(key => (ENTITIES[key].filters || []).forEach(f => {
    if (typeof f.opts === 'function') fill(document.getElementById('flt-' + key + '-' + f.name), f.label, f.opts());
  }));
}
function clientOptionsHtml() {
  return '<option value="">— Select —</option>' + SELECT_OPTIONS.clients.map(o => '<option value="' + o.id + '">' + esc(o.label) + '</option>').join('');
}
function techOptionsHtml() {
  return '<option value="">— Select —</option>' + SELECT_OPTIONS.technicians.map(o => '<option value="' + o.id + '">' + esc(o.label) + '</option>').join('');
}

/* ---------------- generic entity engine (Clients, Technicians, Staff, Sub-contractors, Projects, Inventory) ---------------- */
const ENTITY_CACHE = {};
const ENTITIES = {
  clients: {
    title: 'Client', list: 'clients/list.php', create: 'clients/create.php', update: 'clients/update.php',
    toggle: 'clients/toggle_status.php', toggleKey: 'status', onVal: 'ACTIVE', offVal: 'INACTIVE',
    idKey: 'id',
    searchHint: 'Search name, code, phone, email, address, city...',
    filters: [
      { name: 'status', label: 'Any status', opts: ['ACTIVE', 'INACTIVE', 'SUSPENDED'] },
      { name: 'city', label: 'Any city', opts: () => SELECT_OPTIONS.cities },
      { name: 'has_location', label: 'Any map location', opts: [['1', 'Pinned on map'], ['0', 'Not pinned yet']] },
    ],
    columns: [
      ['client_code', 'Code'], ['full_name', 'Name'], ['email', 'Email'], ['phone', 'Phone'],
      ['city', 'City'], ['status', 'Status', 'badge'], ['open_requests', 'Open Reqs'], ['has_coordinates', 'Location', 'pin'],
    ],
    addFields: [
      ['full_name', 'Full name', 'text', true], ['email', 'Email', 'email', true], ['password', 'Password', 'password', true],
      ['phone', 'Phone', 'text', true], ['address', 'Address', 'text', true], ['city', 'City', 'text', true], ['province', 'Province', 'text', false],
      ['location', 'Site location', 'location', false],
    ],
    editFields: [
      ['full_name', 'Full name', 'text'], ['phone', 'Phone', 'text'], ['address', 'Address', 'text'],
      ['city', 'City', 'text'], ['province', 'Province', 'text'],
      ['location', 'Site location', 'location'],
      ['apply_to_open_jobs', "Also move the geofence on this client's open jobs", 'checkbox'],
      ['new_password', 'New password (optional)', 'password'],
    ],
    panelHtml: clientMapPanelHtml,
    afterLoad: renderClientMap,
  },
  technicians: {
    title: 'Technician', list: 'technicians/list.php', create: 'technicians/create.php', update: 'technicians/update.php',
    toggle: 'technicians/toggle_status.php', toggleKey: 'status', onVal: 'ACTIVE', offVal: 'INACTIVE',
    idKey: 'id',
    filters: [
      { name: 'status', label: 'Any status', opts: ['ACTIVE', 'INACTIVE'] },
      { name: 'availability', label: 'Any availability', opts: ['AVAILABLE', 'BUSY', 'OFF_DUTY', 'ON_LEAVE'] },
    ],
    columns: [
      ['technician_code', 'Code'], ['full_name', 'Name'], ['email', 'Email'], ['phone', 'Phone'],
      ['specialization', 'Specialization'], ['availability', 'Availability', 'badge'], ['open_jobs', 'Open Jobs'], ['status', 'Status', 'badge'],
    ],
    addFields: [
      ['full_name', 'Full name', 'text', true], ['email', 'Email', 'email', true], ['password', 'Password', 'password', true],
      ['phone', 'Phone', 'text', true], ['specialization', 'Specialization', 'text', true],
    ],
    editFields: [
      ['full_name', 'Full name', 'text'], ['phone', 'Phone', 'text'], ['specialization', 'Specialization', 'text'],
      ['availability', 'Availability', 'select', false, ['AVAILABLE', 'BUSY', 'OFF_DUTY', 'ON_LEAVE']],
      ['new_password', 'New password (optional)', 'password'],
    ],
  },
  staff: {
    title: 'Staff', list: 'staff/list.php', create: 'staff/create.php', update: 'staff/update.php',
    idKey: 'id',
    filters: [{ name: 'status', label: 'Any status', opts: ['ACTIVE', 'ON_LEAVE', 'INACTIVE'] }],
    columns: [
      ['staff_code', 'Code'], ['full_name', 'Name'], ['email', 'Email'], ['phone', 'Phone'],
      ['department', 'Department'], ['position', 'Position'], ['status', 'Status', 'badge'],
    ],
    addFields: [
      ['full_name', 'Full name', 'text', true], ['email', 'Email', 'email', true], ['password', 'Password', 'password', true],
      ['phone', 'Phone', 'text', false], ['department', 'Department', 'text', false], ['position', 'Position', 'text', false],
      ['status', 'Status', 'select', false, ['ACTIVE', 'ON_LEAVE', 'INACTIVE']],
    ],
    editFields: [
      ['full_name', 'Full name', 'text'], ['phone', 'Phone', 'text'], ['department', 'Department', 'text'],
      ['position', 'Position', 'text'], ['status', 'Status', 'select', false, ['ACTIVE', 'ON_LEAVE', 'INACTIVE']],
      ['new_password', 'New password (optional)', 'password'],
    ],
  },
  subcontractors: {
    title: 'Sub-contractor', list: 'subcontractors/list.php', create: 'subcontractors/create.php', update: 'subcontractors/update.php',
    toggle: 'subcontractors/toggle_approval.php', toggleKey: 'approved', isBoolToggle: true,
    idKey: 'id',
    filters: [{ name: 'approved', label: 'Any approval', opts: [['1', 'Approved'], ['0', 'Pending']] }],
    columns: [
      ['subcon_code', 'Code'], ['name', 'Name'], ['specialization', 'Specialization'], ['phone', 'Phone'],
      ['email', 'Email'], ['area', 'Area'], ['approved', 'Approved', 'boolbadge'],
    ],
    addFields: [
      ['name', 'Company / name', 'text', true], ['specialization', 'Specialization', 'text', false],
      ['phone', 'Phone', 'text', false], ['email', 'Email', 'email', false], ['area', 'Service area', 'text', false],
      ['approved', 'Approve immediately', 'checkbox', false],
    ],
    editFields: [
      ['name', 'Company / name', 'text'], ['specialization', 'Specialization', 'text'],
      ['phone', 'Phone', 'text'], ['email', 'Email', 'email'], ['area', 'Service area', 'text'],
    ],
  },
  projects: {
    title: 'Project', list: 'projects/list.php', create: 'projects/create.php', update: 'projects/update.php',
    idKey: 'id', listShape: 'rows',
    rowClick: r => 'viewProject(' + r.id + ')',
    searchHint: 'Search project, site, address, client, technician...',
    filters: [
      { name: 'status', label: 'Any status', opts: ['PLANNED', 'SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'MAINTENANCE', 'CANCELLED'] },
      { name: 'site_size', label: 'Any size', opts: [['SMALL', 'Small'], ['MEDIUM', 'Medium'], ['LARGE', 'Large']] },
      { name: 'technician_id', label: 'Any technician', opts: () => SELECT_OPTIONS.technicians.map(t => [t.id, t.label]) },
      { name: 'date_from', label: 'Install from', type: 'date' },
      { name: 'date_to', label: 'Install to', type: 'date' },
    ],
    columns: [
      ['project_code', 'Code'], ['site_name', 'Site'], ['client_name', 'Client'],
      ['capacity_kw', 'kW'], ['site_size', 'Size', 'size'], ['crew', 'Crew', 'crew'],
      ['progress', 'Progress %'], ['status', 'Status', 'badge'], ['installation_date', 'Install Date'],
    ],
    addFields: [
      ['client_id', 'Client', 'select-client', true],
      ['site_name', 'Site name', 'text', true],
      ['address', 'Address', 'text', false],
      ['system_type', 'System type', 'text', false],
      ['capacity_kw', 'Capacity (kW)', 'number', false],
      ['installation_date', 'Installation date', 'date', false],
      // Site size from the kW, the crew it needs, and who is free that day.
      ['crew', 'Site size & crew', 'crew', false],
      ['status', 'Status', 'select', false, ['PLANNED', 'SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'MAINTENANCE', 'CANCELLED']],
      ['notes', 'Notes', 'text', false],
      // Filled in -> a material request goes to the warehouse with the project.
      ['mr_panels', 'Solar panels needed (sent to warehouse)', 'number', false],
      ['mr_inverters', 'Inverters needed (sent to warehouse)', 'number', false],
      ['mr_batteries', 'Batteries needed (sent to warehouse)', 'number', false],
    ],
    editFields: [
      ['client_id', 'Client', 'select-client'],
      ['site_name', 'Site name', 'text'], ['address', 'Address', 'text'], ['system_type', 'System type', 'text'],
      ['capacity_kw', 'Capacity (kW)', 'number'], ['installation_date', 'Installation date', 'date'],
      ['crew', 'Site size & crew', 'crew'],
      ['status', 'Status', 'select', false, ['PLANNED', 'SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'MAINTENANCE', 'CANCELLED']],
      ['notes', 'Notes', 'text'],
    ],
    note: 'Progress is calculated from real installation/job checklists and is not editable here. Site size comes from the kW: Small below 5 kW (1 technician), Medium 5–10 kW (2), Large 10 kW and up (4).',
  },
  inventory: {
    title: 'Item', list: 'inventory/list.php', create: 'inventory/create.php', update: 'inventory/update.php',
    idKey: 'id',
    filters: [
      { name: 'category', label: 'Any category', opts: ['Solar Panel', 'Inverter', 'Battery'] },
      { name: 'status', label: 'Any status', opts: ['ACTIVE', 'LOW_STOCK', 'OUT_OF_STOCK', 'DISCONTINUED'] },
    ],
    columns: [
      ['sku', 'SKU'], ['item_name', 'Item'], ['category_name', 'Category'], ['quantity', 'Qty'],
      ['unit_cost', 'Unit Cost'], ['warehouse_location', 'Location'], ['status', 'Status', 'badge'],
    ],
    addFields: [
      ['item_name', 'Item name', 'text', true],
      ['category', 'Category', 'select', true, ['Solar Panel', 'Inverter', 'Battery']],
      ['quantity', 'Initial quantity', 'number', true],
      ['unit_cost', 'Unit cost', 'number', true],
      ['brand', 'Brand', 'text', false], ['model', 'Model', 'text', false],
      ['serial_number', 'Serial number', 'text', false], ['warehouse_location', 'Location', 'text', false],
    ],
    editFields: [
      ['item_name', 'Item name', 'text'], ['brand', 'Brand', 'text'], ['model', 'Model', 'text'],
      ['serial_number', 'Serial number', 'text'], ['warehouse_location', 'Location', 'text'],
      ['unit_cost', 'Unit cost', 'number'],
    ],
    rowActions: function (row) {
      return '<button class="icon-btn" title="QR code &amp; label" onclick="openQrPanel(' + row.id + ')"><i class="fas fa-qrcode"></i></button>'
        + '<button class="icon-btn" title="Receive stock" onclick="stockAction(\'receive\',' + row.id + ')"><i class="fas fa-arrow-down"></i></button>'
        + '<button class="icon-btn" title="Issue to job" onclick="stockAction(\'issue\',' + row.id + ')"><i class="fas fa-arrow-up"></i></button>'
        + '<button class="icon-btn" title="Return from job" onclick="stockAction(\'return\',' + row.id + ')"><i class="fas fa-rotate-left"></i></button>'
        + '<button class="icon-btn" title="Movement history" onclick="viewMovements(' + row.id + ')"><i class="fas fa-clock-rotate-left"></i></button>';
    },
  },
};

// What each entity's search box looks through (mirrors search_columns() in PHP).
const ENTITY_SEARCH_HINTS = {
  technicians: 'Search name, code, phone, email, specialization...',
  staff: 'Search name, code, phone, email, department, position...',
  subcontractors: 'Search name, code, specialization, phone, email, area...',
  inventory: 'Search SKU, item, brand, model, serial, location...',
};

function initEntityTab(key) {
  const cfg = ENTITIES[key];
  const root = document.getElementById('ent-' + key);
  if (!root) return;
  const filtersHtml = cfg.filters.map(f => {
    const id = 'flt-' + key + '-' + f.name;
    if (f.type === 'date') {
      return '<input id="' + id + '" type="date" title="' + esc(f.label) + '" class="border rounded-lg px-3 py-2 text-sm">';
    }
    const list = typeof f.opts === 'function' ? f.opts() : f.opts;
    const opts = list.map(o => {
      const val = Array.isArray(o) ? o[0] : o;
      const label = Array.isArray(o) ? o[1] : o;
      return '<option value="' + esc(val) + '">' + esc(label) + '</option>';
    }).join('');
    // Capped: a select is as wide as its longest option, and a long technician
    // name would otherwise take the whole toolbar from the search box.
    return '<select id="' + id + '" class="border rounded-lg px-3 py-2 text-sm max-w-[220px] truncate"><option value="">' + esc(f.label) + '</option>' + opts + '</select>';
  }).join('');
  const noteHtml = cfg.note ? '<p class="text-xs text-slate-400 mb-3">' + esc(cfg.note) + '</p>' : '';
  const hint = cfg.searchHint || ENTITY_SEARCH_HINTS[key] || 'Search...';
  root.innerHTML = ''
    // Two rows so the toolbar always fits: search + Add on top (Add pinned right),
    // filters + refresh + Clear / result count underneath.
    + '<div class="mb-4 space-y-2">'
    +   '<div class="flex items-center gap-2">'
    +     '<input id="search-' + key + '" type="text" placeholder="' + esc(hint) + '" class="border rounded-lg px-3 py-2 text-sm flex-1 min-w-0">'
    +     '<button class="shrink-0 bg-solar hover:bg-orange-600 text-white text-sm font-bold px-4 py-2 rounded-xl whitespace-nowrap" onclick="openEntityModal(\'' + key + '\')"><i class="fas fa-plus mr-1"></i> Add</button>'
    +   '</div>'
    +   '<div class="flex flex-wrap items-center gap-2">'
    +     filtersHtml
    +     '<button id="refresh-' + key + '" class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold px-3 py-2 rounded-lg" title="Refresh" onclick="loadEntity(\'' + key + '\')"><i class="fas fa-rotate"></i></button>'
    +   '</div>'
    + '</div>'
    + noteHtml
    + (cfg.panelHtml ? cfg.panelHtml() : '')
    + '<div class="bg-white rounded-2xl border border-slate-100 overflow-x-auto">'
    +   '<table class="w-full data-table"><thead><tr>'
    +     cfg.columns.map(c => '<th>' + c[1] + '</th>').join('')
    +     '<th>Actions</th>'
    +   '</tr></thead><tbody id="tbody-' + key + '"><tr><td colspan="99" class="text-center text-slate-400 py-6">Loading...</td></tr></tbody></table>'
    + '</div>';
  BARS['ent-' + key] = SunTrackFilters.bind({
    search: 'search-' + key,
    fields: cfg.filters.map(f => 'flt-' + key + '-' + f.name),
    anchor: 'refresh-' + key,
    onChange: () => loadEntity(key),
  });
}

function renderCell(row, col) {
  const key = col[0], type = col[2];
  const val = row[key];
  if (type === 'badge') return badge(val);
  if (type === 'boolbadge') return Number(val) ? badge('APPROVED') : badge('PENDING');
  if (type === 'size') {
    if (!val) return '<span class="text-slate-300">—</span>';
    const look = { SMALL: 'bg-sky-50 text-sky-700', MEDIUM: 'bg-amber-50 text-amber-700', LARGE: 'bg-red-50 text-red-700' }[val] || '';
    return '<span class="badge ' + look + '">' + esc(val.charAt(0) + val.slice(1).toLowerCase()) + '</span>';
  }
  if (type === 'crew') {
    // Lead first, then helpers; amber when the crew is smaller than the size needs.
    const crew = row.crew || [];
    if (!crew.length) return '<span class="text-amber-600 text-xs font-semibold">No crew yet</span>';
    const need = Number(row.crew_size) || 1;
    const lead = crew.find(m => m.is_lead) || crew[0];
    return '<span class="font-semibold">' + esc(lead.name) + '</span>'
      + (crew.length > 1 ? ' <span class="text-xs text-slate-400" title="' + esc(crew.filter(m => m !== lead).map(m => m.name).join(', ')) + '">+' + (crew.length - 1) + '</span>' : '')
      + '<br><span class="text-[11px] ' + (crew.length < need ? 'text-amber-600 font-semibold' : 'text-slate-400') + '">'
      + crew.length + ' of ' + need + ' technician' + (need === 1 ? '' : 's') + '</span>';
  }
  if (type === 'pin') {
    return Number(val)
      ? '<button class="link-btn text-emerald-600" title="Show on map" onclick="focusClientOnMap(' + row.id + ')"><i class="fas fa-location-dot mr-1"></i>Pinned</button>'
      : '<span class="text-xs text-slate-400"><i class="fas fa-location-crosshairs mr-1"></i>Not pinned</span>';
  }
  return (val === null || val === undefined || val === '') ? '<span class="text-slate-300">—</span>' : esc(String(val));
}

async function loadEntity(key) {
  const cfg = ENTITIES[key];
  const tbody = document.getElementById('tbody-' + key);
  tbody.innerHTML = '<tr><td colspan="99" class="text-center text-slate-400 py-6">Loading...</td></tr>';
  const params = new URLSearchParams();
  const search = document.getElementById('search-' + key).value;
  if (search) params.set('search', search);
  cfg.filters.forEach(f => {
    const v = document.getElementById('flt-' + key + '-' + f.name).value;
    if (v !== '') params.set(f.name, v);
  });
  const json = await apiGet(cfg.list, params);
  if (!json.success) { tbody.innerHTML = '<tr><td colspan="99" class="text-red-500 text-center py-6">' + esc(json.message) + '</td></tr>'; barCount('ent-' + key); return; }
  const rows = cfg.listShape === 'rows' ? json.data.rows : (Array.isArray(json.data) ? json.data : json.data.rows || []);
  ENTITY_CACHE[key] = rows;
  barCount('ent-' + key, rows.length);
  if (cfg.afterLoad) cfg.afterLoad(rows);
  if (!rows.length) { tbody.innerHTML = '<tr><td colspan="99" class="text-center text-slate-400 py-6">Nothing matches. Try fewer words or press Clear.</td></tr>'; return; }
  tbody.innerHTML = rows.map(r => {
    const cells = cfg.columns.map(c => '<td>' + renderCell(r, c) + '</td>').join('');
    let actions = (cfg.rowClick ? '<button class="icon-btn" title="View details" onclick="' + cfg.rowClick(r) + '"><i class="fas fa-eye"></i></button>' : '')
      + '<button class="icon-btn" title="Edit" onclick="openEntityModal(\'' + key + '\',' + r[cfg.idKey] + ')"><i class="fas fa-pen"></i></button>';
    if (cfg.toggle) actions += '<button class="icon-btn" title="Toggle status" onclick="toggleEntity(\'' + key + '\',' + r[cfg.idKey] + ')"><i class="fas fa-power-off"></i></button>';
    if (cfg.rowActions) actions += cfg.rowActions(r);
    // A row that opens its full details when clicked (the action buttons do their own thing).
    return (cfg.rowClick ? '<tr class="cursor-pointer hover:bg-orange-50/50" title="Click for full details" onclick="' + cfg.rowClick(r) + '">' : '<tr>')
      + cells + '<td class="whitespace-nowrap" onclick="event.stopPropagation()">' + actions + '</td></tr>';
  }).join('');
}

function renderField(f, row) {
  const name = f[0], label = f[1], type = f[2], required = f[3], options = f[4];
  const val = (row && row[name] !== null && row[name] !== undefined) ? row[name] : '';
  const reqAttr = required ? 'required' : '';
  if (type === 'select') {
    const opts = options.map(o => '<option value="' + o + '" ' + (String(val) === String(o) ? 'selected' : '') + '>' + o + '</option>').join('');
    return '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">' + esc(label) + '</label>'
      + '<select id="f-' + name + '" class="w-full border rounded-lg px-3 py-2 text-sm">' + opts + '</select>';
  }
  if (type === 'select-client' || type === 'select-tech') {
    const src = type === 'select-client' ? SELECT_OPTIONS.clients : SELECT_OPTIONS.technicians;
    const opts = src.map(o => '<option value="' + o.id + '" ' + (String(val) === String(o.id) ? 'selected' : '') + '>' + esc(o.label) + '</option>').join('');
    return '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">' + esc(label) + '</label>'
      + '<select id="f-' + name + '" class="w-full border rounded-lg px-3 py-2 text-sm"><option value="">— Select —</option>' + opts + '</select>';
  }
  if (type === 'checkbox') {
    return '<label class="flex items-center gap-2 mt-3 text-sm"><input id="f-' + name + '" type="checkbox" ' + (val ? 'checked' : '') + '> ' + esc(label) + '</label>';
  }
  if (type === 'crew') {
    // Filled by crewPickerInit() once the modal is open.
    return '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">' + esc(label) + '</label>'
      + '<div id="f-crew-box" class="border border-slate-200 rounded-xl p-3 text-sm"><p class="text-xs text-slate-400"><i class="fas fa-spinner fa-spin mr-1"></i>Loading technicians...</p></div>';
  }
  if (type === 'location') {
    const lat = row && row.lat != null ? row.lat : '';
    const lng = row && row.lng != null ? row.lng : '';
    return '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">' + esc(label) + '</label>'
      + '<p class="text-[11px] text-slate-400 mb-2">Click the map to drop a pin, drag it to adjust, or type the coordinates. Jobs for this client use it as their geofence centre.</p>'
      + '<div id="f-location-map" class="w-full h-56 rounded-lg border border-slate-200 z-0"></div>'
      + '<div class="grid grid-cols-2 gap-2 mt-2">'
      +   '<div><label class="block text-[11px] font-semibold text-slate-500 mb-1">Latitude</label>'
      +     '<input id="f-lat" type="number" step="any" value="' + esc(String(lat)) + '" placeholder="e.g. 10.6765" class="w-full border rounded-lg px-3 py-2 text-sm"></div>'
      +   '<div><label class="block text-[11px] font-semibold text-slate-500 mb-1">Longitude</label>'
      +     '<input id="f-lng" type="number" step="any" value="' + esc(String(lng)) + '" placeholder="e.g. 122.9509" class="w-full border rounded-lg px-3 py-2 text-sm"></div>'
      + '</div>'
      + '<div class="flex gap-3 mt-2">'
      +   '<button type="button" class="link-btn text-slate-500" onclick="pickerClear()"><i class="fas fa-eraser mr-1"></i>Clear pin</button>'
      + '</div>';
  }
  return '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">' + esc(label) + '</label>'
    + '<input id="f-' + name + '" type="' + type + '" ' + reqAttr + ' value="' + esc(String(val)) + '" class="w-full border rounded-lg px-3 py-2 text-sm">';
}

function openEntityModal(key, id) {
  const cfg = ENTITIES[key];
  const isEdit = id !== undefined && id !== null;
  const fields = isEdit ? cfg.editFields : cfg.addFields;
  let row = null;
  if (isEdit) row = (ENTITY_CACHE[key] || []).find(r => String(r[cfg.idKey]) === String(id));
  const fieldsHtml = fields.map(f => renderField(f, row)).join('');
  openModal((isEdit ? 'Edit ' : 'Add ') + cfg.title, fieldsHtml, async () => {
    const payload = {};
    fields.forEach(f => {
      if (f[2] === 'location') {
        payload.lat = document.getElementById('f-lat').value.trim();
        payload.lng = document.getElementById('f-lng').value.trim();
        return;
      }
      if (f[2] === 'crew') {
        Object.assign(payload, crewPickerValue());
        return;
      }
      const el = document.getElementById('f-' + f[0]);
      if (f[2] === 'checkbox') payload[f[0]] = el.checked;
      else payload[f[0]] = el.value;
    });
    if (isEdit) payload.id = id;
    const json = await apiPost(isEdit ? cfg.update : cfg.create, payload);
    if (!json.success) { toast(json.message, true); return false; }
    toast(json.message, false);
    loadEntity(key);
    // New clients/projects/technicians must show up in the other forms' dropdowns.
    if (['clients', 'projects', 'technicians'].indexOf(key) !== -1) loadSelectOptions();
    return true;
  });
  if (fields.some(f => f[2] === 'location')) {
    initLocationPicker(row && row.lat != null ? parseFloat(row.lat) : null, row && row.lng != null ? parseFloat(row.lng) : null);
  }
  if (fields.some(f => f[2] === 'crew')) crewPickerInit(row);
}

/* ---- Project crew picker: site size -> crew needed -> who is free that day ---- */
const CREW = { ids: [], lead: null, data: null, sizeManual: '', crewManual: '', projectId: null, seq: 0 };
const AVAIL_LOOK = {
  AVAILABLE: ['bg-emerald-50 text-emerald-700', 'Available'], BUSY: ['bg-amber-50 text-amber-700', 'Busy'],
  ON_LEAVE: ['bg-slate-100 text-slate-500', 'On leave'], OFF_DUTY: ['bg-slate-100 text-slate-500', 'Off duty'],
};

function crewPickerInit(row) {
  CREW.ids = []; CREW.lead = null; CREW.data = null; CREW.seq++;
  CREW.projectId = row ? row.id : null;
  CREW.sizeManual = '';
  CREW.savedSize = row && row.site_size ? row.site_size : ''; // kept if it was set by hand (checked on first load)
  CREW.crewManual = row && row.crew_size ? String(row.crew_size) : '';
  CREW.loadedExisting = false;
  ['f-capacity_kw', 'f-installation_date'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('change', crewPickerLoad);
  });
  crewPickerLoad();
}

async function crewPickerLoad() {
  const seq = ++CREW.seq;
  const p = new URLSearchParams();
  const kw = (document.getElementById('f-capacity_kw') || {}).value || '';
  const date = (document.getElementById('f-installation_date') || {}).value || '';
  if (kw) p.set('capacity_kw', kw);
  if (date) p.set('date', date);
  if (CREW.projectId) p.set('project_id', CREW.projectId);
  if (CREW.sizeManual) p.set('site_size', CREW.sizeManual);
  if (CREW.crewManual) p.set('crew_size', CREW.crewManual);
  const json = await apiGet('projects/crew_options.php', p);
  if (seq !== CREW.seq) return; // a newer request is on its way
  const box = document.getElementById('f-crew-box');
  if (!box) return;
  if (!json.success) { box.innerHTML = '<p class="text-xs text-red-500">' + esc(json.message) + '</p>'; return; }
  CREW.data = json.data;
  // A size that differs from what the kW gives was chosen by hand: keep it.
  if (!CREW.loadedExisting && CREW.savedSize && CREW.savedSize !== json.data.site_size && !CREW.sizeManual) {
    CREW.sizeManual = CREW.savedSize;
    CREW.seq++;
    return crewPickerLoad();
  }
  if (!CREW.loadedExisting && json.data.crew.length) {
    CREW.ids = json.data.crew.map(m => m.id);
    const lead = json.data.crew.find(m => m.is_lead);
    CREW.lead = lead ? lead.id : CREW.ids[0];
  }
  CREW.loadedExisting = true;
  crewPickerRender();
}

function crewPickerRender() {
  const d = CREW.data, box = document.getElementById('f-crew-box');
  if (!d || !box) return;
  const need = d.crew_size;
  const picked = CREW.ids.length;
  const kw = (document.getElementById('f-capacity_kw') || {}).value || '';
  const sizeText = d.site_size ? d.size_label + ' site' : 'Size unknown';
  const autoNote = CREW.sizeManual ? 'set by hand' : (kw ? 'from ' + kw + ' kW' : 'enter the kW to size it');
  const tone = picked === 0 ? 'bg-slate-100 text-slate-500' : picked < need ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700';
  const hint = picked === 0 ? 'Tick the technicians for this site. The first one ticked is the lead.'
    : picked < need ? 'This site needs ' + need + ' technician' + (need === 1 ? '' : 's') + '.'
    : 'Crew complete.';
  const lbl = t => '<label class="block text-[11px] font-semibold text-slate-500 uppercase tracking-wide mb-1">' + t + '</label>';

  box.innerHTML = ''
    // Size + crew count, side by side and equal width.
    + '<div class="grid grid-cols-2 gap-3">'
    +   '<div>' + lbl('Site size')
    +     '<select id="f-site-size" class="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm">'
    +       '<option value="">Auto — ' + esc(sizeText) + '</option>'
    +       ['SMALL', 'MEDIUM', 'LARGE'].map(s => '<option value="' + s + '"' + (CREW.sizeManual === s ? ' selected' : '') + '>' + d.rules.labels[s] + ' (' + d.rules.crew[s] + ' tech' + (d.rules.crew[s] === 1 ? '' : 's') + ')</option>').join('')
    +     '</select><p class="text-[11px] text-slate-400 mt-1">' + esc(autoNote) + '</p></div>'
    +   '<div>' + lbl('Technicians needed')
    +     '<input id="f-crew-size" type="number" min="1" max="10" value="' + need + '" class="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"></div>'
    + '</div>'
    // Who is picked so far, and for which day.
    + '<div class="mt-4 flex items-center justify-between gap-2">'
    +   '<p class="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">Choose technicians</p>'
    +   '<span class="badge ' + tone + '">' + picked + ' of ' + need + ' picked</span>'
    + '</div>'
    + '<p class="text-[11px] text-slate-400 mt-0.5 mb-2">' + esc(hint) + ' '
    +   (d.date ? 'Availability for ' + esc(planDate(d.date)) + '.' : 'Set the installation date to see who is free that day.') + '</p>'
    + '<div class="max-h-64 overflow-y-auto border border-slate-200 rounded-lg divide-y divide-slate-100">'
    + d.candidates.map(c => {
        const on = CREW.ids.includes(c.id);
        const isLead = on && CREW.lead === c.id;
        const a = AVAIL_LOOK[c.availability] || AVAIL_LOOK.AVAILABLE;
        return '<label class="flex items-center gap-3 px-3 py-2.5 cursor-pointer transition ' + (on ? 'bg-orange-50' : 'hover:bg-slate-50') + '">'
          + '<input type="checkbox" class="js-crew-pick h-4 w-4 accent-orange-500 shrink-0" value="' + c.id + '"' + (on ? ' checked' : '') + '>'
          + '<span class="flex-1 min-w-0">'
          +   '<span class="block text-sm font-semibold text-slate-800 truncate">' + esc(c.name) + '</span>'
          +   '<span class="block text-[11px] text-slate-400">' + esc(c.code) + ' · ' + c.open_jobs + ' open job' + (c.open_jobs === 1 ? '' : 's')
          +     (c.booked ? ' · <span class="text-red-600 font-semibold">busy that day (' + esc(c.booked) + ')</span>' : '') + '</span>'
          + '</span>'
          + (on
              ? '<button type="button" class="js-crew-lead shrink-0 text-[11px] font-bold px-2.5 py-1 rounded-full border '
                + (isLead ? 'bg-solar text-white border-solar' : 'border-slate-200 text-slate-500 hover:border-solar hover:text-solar') + '" data-id="' + c.id + '">'
                + (isLead ? '<i class="fas fa-star mr-1"></i>Lead' : 'Make lead') + '</button>'
              : '<span class="shrink-0 badge ' + a[0] + '">' + a[1] + '</span>')
          + '</label>';
      }).join('')
    + '</div>';

  box.querySelector('#f-site-size').addEventListener('change', e => { CREW.sizeManual = e.target.value; CREW.crewManual = ''; crewPickerLoad(); });
  box.querySelector('#f-crew-size').addEventListener('change', e => { CREW.crewManual = e.target.value; crewPickerLoad(); });
  box.querySelectorAll('.js-crew-pick').forEach(cb => cb.addEventListener('change', () => {
    const id = Number(cb.value);
    if (cb.checked) { if (!CREW.ids.includes(id)) CREW.ids.push(id); if (!CREW.lead) CREW.lead = id; }
    else { CREW.ids = CREW.ids.filter(x => x !== id); if (CREW.lead === id) CREW.lead = CREW.ids[0] || null; }
    crewPickerRender();
  }));
  box.querySelectorAll('.js-crew-lead').forEach(b => b.addEventListener('click', e => {
    e.preventDefault(); e.stopPropagation(); // inside the row's label: don't untick the box
    CREW.lead = Number(b.dataset.id);
    crewPickerRender();
  }));
}

function crewPickerValue() {
  const lead = CREW.lead && CREW.ids.includes(CREW.lead) ? CREW.lead : (CREW.ids[0] || '');
  return {
    site_size: CREW.sizeManual || '',
    crew_size: CREW.crewManual || (CREW.data ? String(CREW.data.crew_size) : ''),
    crew_ids: CREW.ids.slice(),
    assigned_technician_id: lead,
  };
}

async function toggleEntity(key, id) {
  const cfg = ENTITIES[key];
  const row = (ENTITY_CACHE[key] || []).find(r => String(r[cfg.idKey]) === String(id));
  if (!row) return;
  const payload = { id: id };
  if (cfg.isBoolToggle) {
    payload[cfg.toggleKey] = Number(row[cfg.toggleKey]) ? false : true;
  } else {
    payload[cfg.toggleKey] = row[cfg.toggleKey] === cfg.onVal ? cfg.offVal : cfg.onVal;
  }
  if (!confirm('Change status for this record?')) return;
  const json = await apiPost(cfg.toggle, payload);
  if (!json.success) { toast(json.message, true); return; }
  toast(json.message, false);
  loadEntity(key);
}

/* ---------------- Client maps: site picker + all-clients overview ---------------- */
// Starting view when nothing is plotted yet (Bacolod, same as the Admin site map).
const DEFAULT_MAP_CENTRE = [10.6765, 122.9509];
const OSM_TILES = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
const OSM_ATTRIBUTION = '&copy; OpenStreetMap contributors';

// --- Picker (inside the Add/Edit Client modal) ---
// The modal body is rebuilt on every open, so the picker map is rebuilt too.
let pickerMap = null, pickerMarker = null;

function initLocationPicker(lat, lng) {
  const el = document.getElementById('f-location-map');
  if (!el || typeof L === 'undefined') return;
  if (pickerMap) { pickerMap.remove(); pickerMap = null; pickerMarker = null; }

  const hasPin = lat != null && lng != null && !isNaN(lat) && !isNaN(lng);
  pickerMap = L.map(el).setView(hasPin ? [lat, lng] : pickerStartCentre(), hasPin ? 16 : 12);
  L.tileLayer(OSM_TILES, { attribution: OSM_ATTRIBUTION, maxZoom: 19 }).addTo(pickerMap);
  pickerMap.on('click', (e) => setPickerPin(e.latlng.lat, e.latlng.lng, false));
  if (hasPin) setPickerPin(lat, lng, false);

  // Typing coordinates by hand moves the pin too.
  ['f-lat', 'f-lng'].forEach(id => document.getElementById(id).addEventListener('change', () => {
    const la = parseFloat(document.getElementById('f-lat').value);
    const ln = parseFloat(document.getElementById('f-lng').value);
    if (!isNaN(la) && !isNaN(ln)) setPickerPin(la, ln, true);
  }));

  // The modal was just made visible, so Leaflet must re-measure its container.
  setTimeout(() => pickerMap && pickerMap.invalidateSize(), 120);
}

// Open the picker where the existing clients are, rather than a fixed city.
function pickerStartCentre() {
  return clientMap ? [clientMap.getCenter().lat, clientMap.getCenter().lng] : DEFAULT_MAP_CENTRE;
}

function setPickerPin(lat, lng, recentre) {
  document.getElementById('f-lat').value = Number(lat).toFixed(7);
  document.getElementById('f-lng').value = Number(lng).toFixed(7);
  if (!pickerMap) return;
  if (pickerMarker) pickerMarker.setLatLng([lat, lng]);
  else pickerMarker = L.marker([lat, lng], { draggable: true }).addTo(pickerMap)
    .on('dragend', (e) => { const p = e.target.getLatLng(); setPickerPin(p.lat, p.lng, false); });
  if (recentre) pickerMap.setView([lat, lng], 16);
}

function pickerClear() {
  document.getElementById('f-lat').value = '';
  document.getElementById('f-lng').value = '';
  if (pickerMarker && pickerMap) { pickerMap.removeLayer(pickerMarker); pickerMarker = null; }
}

// --- Overview (Clients tab) ---
// Pin colour follows the client's most pressing OPEN service request.
const CLIENT_MAP_CATEGORIES = {
  urgent: { label: 'Urgent', hint: 'Open URGENT or HIGH priority request', color: '#ef4444' },
  normal: { label: 'Normal', hint: 'Open NORMAL or LOW priority request', color: '#f59e0b' },
  good:   { label: 'Good',   hint: 'No open service requests',             color: '#10b981' },
};
let clientMap = null, clientMapLayer = null;
const clientMapMarkers = {};
const clientMapHidden = new Set();
let clientMapRows = [];
let clientMapFitted = false;

function clientCategory(row) {
  const p = row.top_open_priority;
  if (p === 'URGENT' || p === 'HIGH') return 'urgent';
  if (p === 'NORMAL' || p === 'LOW') return 'normal';
  return 'good';
}

function clientMapPanelHtml() {
  const legend = Object.keys(CLIENT_MAP_CATEGORIES).map(k => {
    const c = CLIENT_MAP_CATEGORIES[k];
    return '<button type="button" id="cmap-leg-' + k + '" class="cmap-legend-btn" title="' + esc(c.hint) + ' — click to show/hide" onclick="toggleClientMapCategory(\'' + k + '\')">'
      + '<span class="cmap-dot" style="background:' + c.color + '"></span>' + c.label
      + ' <span id="cmap-count-' + k + '" class="text-slate-400">0</span></button>';
  }).join('');
  return '<div class="bg-white rounded-2xl border border-slate-100 p-4 mb-4">'
    + '<div class="flex flex-wrap items-center justify-between gap-2 mb-3">'
    +   '<div><h3 class="font-bold text-slate-800"><i class="fas fa-map-location-dot text-solar mr-1"></i> Client Locations</h3>'
    +   '<p class="text-xs text-slate-400">Pins are coloured by each client\'s most pressing open service request. Search and filters above apply to the map too.</p></div>'
    +   '<div class="flex flex-wrap items-center gap-2">' + legend
    +     '<button type="button" class="cmap-legend-btn" title="Zoom to all visible pins" onclick="fitClientMap()"><i class="fas fa-expand"></i></button>'
    +   '</div>'
    + '</div>'
    + '<div id="client-overview-map" class="w-full h-[420px] rounded-xl border border-slate-200 z-0"></div>'
    + '<p id="cmap-unpinned" class="text-xs text-slate-400 mt-2"></p>'
    + '</div>';
}

function ensureClientMap() {
  const el = document.getElementById('client-overview-map');
  if (!el || typeof L === 'undefined') return false;
  if (!clientMap) {
    clientMap = L.map(el).setView(DEFAULT_MAP_CENTRE, 11);
    L.tileLayer(OSM_TILES, { attribution: OSM_ATTRIBUTION, maxZoom: 19 }).addTo(clientMap);
    clientMapLayer = L.layerGroup().addTo(clientMap);
  }
  clientMap.invalidateSize();
  return true;
}

function clientPopupHtml(r) {
  const cat = CLIENT_MAP_CATEGORIES[clientCategory(r)];
  const open = Number(r.open_requests) || 0;
  return '<div class="text-sm" style="min-width:230px">'
    + '<p class="font-bold text-slate-800">' + esc(r.full_name) + '</p>'
    + '<p class="text-xs text-slate-400 mb-1">' + esc(r.client_code) + ' · ' + badge(r.status) + '</p>'
    + '<p class="text-xs text-slate-600">' + esc([r.address, r.barangay, r.city, r.province].filter(Boolean).join(', ')) + '</p>'
    + (r.phone ? '<p class="text-xs text-slate-600"><i class="fas fa-phone mr-1"></i>' + esc(r.phone) + '</p>' : '')
    + '<p class="text-xs mt-2"><span class="cmap-dot" style="background:' + cat.color + '"></span> <b>' + cat.label + '</b>'
    +   (open ? ' — ' + open + ' open request' + (open === 1 ? '' : 's') + (r.top_open_priority ? ' (top: ' + esc(r.top_open_priority) + ')' : '') : '') + '</p>'
    + '<p class="text-xs text-slate-600 mt-1"><b>Service requests:</b> ' + (Number(r.total_requests) || 0) + ' total</p>'
    + '<p class="text-xs text-slate-600"><b>Assigned technician:</b> ' + (r.assigned_technician ? esc(r.assigned_technician) : '—') + '</p>'
    + '<p class="text-xs text-slate-600"><b>Last service:</b> ' + (r.last_service ? esc(r.last_service) : 'None yet') + '</p>'
    + '<p class="text-[11px] text-slate-400 mt-1">' + Number(r.lat).toFixed(6) + ', ' + Number(r.lng).toFixed(6) + '</p>'
    + '<div class="flex flex-wrap gap-3 mt-2">'
    +   (Number(r.total_requests) ? '<a href="#" class="link-btn text-solar" onclick="viewClientRequests(' + r.id + ');return false;">View requests</a>' : '')
    +   '<a href="#" class="link-btn text-emerald-600" onclick="newRequestForClient(' + r.id + ');return false;">New request</a>'
    +   '<a href="#" class="link-btn text-slate-600" onclick="openEntityModal(\'clients\',' + r.id + ');return false;">Edit</a>'
    +   '<a class="link-btn text-sky-600" target="_blank" rel="noopener" href="https://www.google.com/maps/dir/?api=1&destination=' + r.lat + ',' + r.lng + '">Directions</a>'
    + '</div></div>';
}

function renderClientMap(rows) {
  clientMapRows = rows;
  if (!ensureClientMap()) return;
  clientMapLayer.clearLayers();
  Object.keys(clientMapMarkers).forEach(k => delete clientMapMarkers[k]);

  const counts = { urgent: 0, normal: 0, good: 0 };
  let unpinned = 0;
  // Draw good first and urgent last, so urgent pins sit on top where they overlap.
  const order = { good: 0, normal: 1, urgent: 2 };
  rows.slice().sort((a, b) => order[clientCategory(a)] - order[clientCategory(b)]).forEach(r => {
    if (r.lat == null || r.lng == null) { unpinned++; return; }
    const cat = clientCategory(r);
    counts[cat]++;
    if (clientMapHidden.has(cat)) return;
    const icon = L.divIcon({ className: '', html: '<div class="cmap-pin cmap-' + cat + '"></div>', iconSize: [18, 18], iconAnchor: [9, 9], popupAnchor: [0, -10] });
    const m = L.marker([parseFloat(r.lat), parseFloat(r.lng)], { icon: icon, title: r.client_code + ' — ' + r.full_name, zIndexOffset: order[cat] * 1000 })
      .bindPopup(clientPopupHtml(r));
    m.addTo(clientMapLayer);
    clientMapMarkers[r.id] = m;
  });

  Object.keys(counts).forEach(k => {
    document.getElementById('cmap-count-' + k).textContent = counts[k];
    document.getElementById('cmap-leg-' + k).classList.toggle('off', clientMapHidden.has(k));
  });
  document.getElementById('cmap-unpinned').textContent = unpinned
    ? unpinned + ' client' + (unpinned === 1 ? ' has' : 's have') + ' no site location yet. Edit them to drop a pin.'
    : '';

  // Only auto-zoom on first load, so a realtime refresh does not yank the view away.
  if (!clientMapFitted && Object.keys(clientMapMarkers).length) { fitClientMap(); clientMapFitted = true; }
}

function fitClientMap() {
  const markers = Object.values(clientMapMarkers);
  if (!clientMap || !markers.length) return;
  clientMap.fitBounds(L.featureGroup(markers).getBounds().pad(0.15), { maxZoom: 15 });
}

function toggleClientMapCategory(cat) {
  if (clientMapHidden.has(cat)) clientMapHidden.delete(cat); else clientMapHidden.add(cat);
  renderClientMap(clientMapRows);
}

function focusClientOnMap(id) {
  const row = clientMapRows.find(r => String(r.id) === String(id));
  if (!row) return;
  const cat = clientCategory(row);
  if (clientMapHidden.has(cat)) { clientMapHidden.delete(cat); renderClientMap(clientMapRows); }
  const m = clientMapMarkers[id];
  if (!m) return;
  document.getElementById('client-overview-map').scrollIntoView({ behavior: 'smooth', block: 'center' });
  clientMap.setView(m.getLatLng(), 16);
  m.openPopup();
}

// From a map pin: open the New Request form with this client already chosen.
function newRequestForClient(id) {
  openNewRequestModal();
  const sel = document.getElementById('f-sr-client');
  if (sel) sel.value = String(id);
}

function viewClientRequests(id) {
  const row = clientMapRows.find(r => String(r.id) === String(id));
  if (!row) return;
  // Code is exact (two clients can share a name); clear the other filters so
  // none of them hides this client's requests.
  document.getElementById('sr-search').value = row.client_code;
  ['sr-status', 'sr-priority', 'sr-type', 'sr-tech', 'sr-from', 'sr-to'].forEach(fid => { document.getElementById(fid).value = ''; });
  showTab('service-requests');
}

/* ---------------- Warehouse: receive / issue / return / movements ---------------- */
function openQrPanel(invId) {
  SunTrackQR.openPanel({ base: <?= json_encode(APP_BASE_URL) ?>, csrf: CSRF_TOKEN, id: invId, onChanged: () => loadEntity('inventory') });
}
async function stockAction(type, invId) {
  const row = (ENTITY_CACHE.inventory || []).find(r => String(r.id) === String(invId));
  const itemName = row ? row.item_name : 'item';
  if (row && row.tracking_mode === 'SERIAL') {
    // Per-unit items move by serial number / unit label: the Warehouse
    // portal's scanner and stock forms list the units.
    toast(itemName + ' is tracked per unit. Receive, issue and return it from the Warehouse portal so each unit is recorded.', true);
    return;
  }
  const requestKey = SunTrackQR.requestKey(); // one key per form: a double click posts once
  let fieldsHtml = '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Quantity</label>'
    + '<input id="f-qty" type="number" min="1" class="w-full border rounded-lg px-3 py-2 text-sm">';
  if (type === 'receive') {
    fieldsHtml += '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Reference (optional)</label>'
      + '<input id="f-ref" type="text" class="w-full border rounded-lg px-3 py-2 text-sm">';
  } else {
    fieldsHtml += '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Job</label>'
      + '<select id="f-job" class="w-full border rounded-lg px-3 py-2 text-sm"><option value="">— Select —</option>'
      + SELECT_OPTIONS.activeJobs.map(j => '<option value="' + j.id + '">' + esc(j.label) + '</option>').join('') + '</select>';
  }
  if (type === 'return') {
    fieldsHtml += '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Condition</label>'
      + '<select id="f-cond" class="w-full border rounded-lg px-3 py-2 text-sm">'
      + '<option value="GOOD">Good — back into available stock</option>'
      + '<option value="DAMAGED">Damaged — hold in quarantine</option>'
      + '<option value="NEEDS_INSPECTION">Needs inspection — hold in quarantine</option></select>';
  }
  const titles = { receive: 'Receive Stock', issue: 'Issue Stock', return: 'Return Stock' };
  const urls = { receive: 'inventory/receive.php', issue: 'inventory/issue.php', return: 'inventory/return.php' };
  openModal(titles[type] + ' — ' + itemName, fieldsHtml, async () => {
    const qty = Number(document.getElementById('f-qty').value);
    if (!qty || qty <= 0) { toast('Enter a quantity greater than zero.', true); return false; }
    const payload = { inventory_id: invId, quantity: qty, request_key: requestKey };
    if (type === 'return') payload.condition = document.getElementById('f-cond').value;
    if (type === 'receive') {
      payload.reference = document.getElementById('f-ref').value;
    } else {
      const jobId = document.getElementById('f-job').value;
      if (!jobId) { toast('Select a job.', true); return false; }
      payload.job_id = Number(jobId);
    }
    const json = await apiPost(urls[type], payload);
    if (!json.success) { toast(json.message, true); return false; }
    toast(json.message, false);
    loadEntity('inventory');
    return true;
  });
}
async function viewMovements(invId) {
  const row = (ENTITY_CACHE.inventory || []).find(r => String(r.id) === String(invId));
  const itemName = row ? row.item_name : 'item';
  const json = await apiGet('inventory/movements.php', new URLSearchParams({ inventory_id: invId }));
  const rows = json.success ? json.data : [];
  const html = rows.length
    ? '<div class="max-h-80 overflow-y-auto"><table class="w-full data-table"><thead><tr><th>Type</th><th>Qty</th><th>Reference</th><th>Date</th></tr></thead><tbody>'
      + rows.map(r => '<tr><td>' + badge(r.movement_type) + '</td><td>' + r.quantity + '</td><td>' + esc(r.reference || '—') + '</td><td class="text-xs text-slate-500">' + r.created_at + '</td></tr>').join('')
      + '</tbody></table></div>'
    : '<p class="text-slate-400 text-sm">No movements recorded yet.</p>';
  openInfoModal('Movement history — ' + itemName, html);
}

/* ---------------- Dashboard ---------------- */
// The same dashboard as Admin (assets/js/suntrack-admin-dashboard.js, from
// api/dashboard/admin.php). Its links use Admin tab keys; these map them onto
// the Management tabs where each thing is handled.
const MGMT_DASHBOARD = SunTrackAdminDashboard.mount({
  root: document.getElementById('sad-root'),
  endpoint: API + 'dashboard/admin.php',
  tabs: { sitemap: 'jobs', 'work-reports': 'jobs', inventory: 'warehouse' },
  tabNames: { sitemap: 'Jobs', 'work-reports': 'Jobs', inventory: 'Warehouse' },
  navigate: (tab) => showTab(tab),
});
function loadDashboard() { return MGMT_DASHBOARD.refresh(); }

/* ---------------- Service Requests ---------------- */
const SR_SERVICE_TYPES = <?= json_encode(sr_service_types()) ?>;
const SR_OPEN = ['PENDING', 'APPROVED', 'ASSIGNED', 'SCHEDULED', 'IN_PROGRESS', 'ON_HOLD'];
let SR_CACHE = [];

function srStatusBadge(s) {
  const colors = {
    PENDING: 'bg-amber-100 text-amber-700', APPROVED: 'bg-blue-100 text-blue-700', ASSIGNED: 'bg-indigo-100 text-indigo-700',
    SCHEDULED: 'bg-violet-100 text-violet-700', IN_PROGRESS: 'bg-sky-100 text-sky-700', ON_HOLD: 'bg-slate-200 text-slate-700',
    COMPLETED: 'bg-emerald-100 text-emerald-700', CANCELLED: 'bg-slate-100 text-slate-500', REJECTED: 'bg-red-100 text-red-700',
  };
  return '<span class="badge ' + (colors[s] || 'bg-slate-100 text-slate-600') + '">' + esc(String(s || '').replace(/_/g, ' ')) + '</span>';
}
function setModalWide(wide) {
  const box = document.querySelector('#modal-backdrop > div');
  if (!box) return;
  box.classList.toggle('max-w-md', !wide);
  box.classList.toggle('max-w-3xl', wide);
}
function todayIso() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

async function loadServiceRequests() {
  const tbody = document.getElementById('sr-tbody');
  tbody.innerHTML = '<tr><td colspan="9" class="text-center text-slate-400 py-6">Loading...</td></tr>';
  const params = filterParams({ search: 'sr-search', status: 'sr-status', priority: 'sr-priority', service_type: 'sr-type', technician_id: 'sr-tech', date_from: 'sr-from', date_to: 'sr-to' });
  const json = await apiGet('service_requests/list.php', params);
  if (!json.success) { tbody.innerHTML = '<tr><td colspan="9" class="text-red-500 text-center py-6">' + esc(json.message) + '</td></tr>'; barCount('sr'); return; }
  SR_CACHE = json.data;
  barCount('sr', json.data.length);
  // Checklists the technicians submitted, waiting for approval (same banner as Installation).
  const awaiting = json.data.filter(r => r.checklist_status === 'SUBMITTED');
  const srBanner = document.getElementById('sr-review-banner');
  srBanner.classList.toggle('hidden', !awaiting.length);
  srBanner.innerHTML = awaiting.length
    ? '<div class="flex items-center gap-3 rounded-xl border border-violet-200 bg-violet-50 px-4 py-3 text-sm text-violet-800">'
      + '<i class="fas fa-bell"></i><span><b>' + awaiting.length + ' service request' + (awaiting.length === 1 ? '' : 's') + ' waiting for your approval.</b> Check the checklist and photos, then approve to mark it Completed, or return it with a note.</span>'
      + '<button class="ml-auto shrink-0 bg-violet-600 hover:bg-violet-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg" onclick="viewServiceRequest(' + awaiting[0].id + ')">Review next</button></div>'
    : '';
  if (!json.data.length) { tbody.innerHTML = '<tr><td colspan="9" class="text-center text-slate-400 py-6">No service requests match. Try fewer words or press Clear.</td></tr>'; return; }
  tbody.innerHTML = json.data.map(r => {
    let actions = '<button class="icon-btn" title="Details &amp; history" onclick="viewServiceRequest(' + r.id + ')"><i class="fas fa-eye"></i></button>';
    if (r.status === 'PENDING') {
      actions += '<button class="icon-btn text-emerald-600" title="Approve" onclick="srAction(' + r.id + ',\'APPROVE\')"><i class="fas fa-check"></i></button>'
        + '<button class="icon-btn text-red-500" title="Reject" onclick="srAction(' + r.id + ',\'REJECT\')"><i class="fas fa-xmark"></i></button>';
    }
    if (['APPROVED', 'ASSIGNED', 'SCHEDULED', 'ON_HOLD', 'IN_PROGRESS'].indexOf(r.status) !== -1) {
      actions += '<button class="link-btn text-solar ml-1" onclick="openAssignModal(' + r.id + ')">' + (r.technician_name ? 'Reassign' : 'Assign') + '</button>'
        + '<button class="icon-btn" title="Schedule" onclick="openScheduleModal(' + r.id + ')"><i class="fas fa-calendar-day"></i></button>';
    }
    // Click anywhere on the row for the request's full details (the action buttons do their own thing).
    return '<tr class="cursor-pointer hover:bg-orange-50/50" title="Click for full details" onclick="viewServiceRequest(' + r.id + ')">'
      + '<td class="font-semibold text-solar">' + esc(r.request_code) + '</td>'
      + '<td>' + esc(r.client_name) + '<div class="text-[11px] text-slate-400">' + esc(r.client_code) + (r.client_city ? ' · ' + esc(r.client_city) : '') + '</div></td>'
      + '<td>' + esc(r.subject || r.request_type || '—') + '<div class="text-[11px] text-slate-400">' + esc(r.request_type || '') + '</div></td>'
      + '<td>' + badge(r.priority) + '</td>'
      + '<td>' + srStatusBadge(r.status) + (r.checklist_status === 'SUBMITTED' ? '<div class="mt-1"><span class="badge bg-violet-100 text-violet-700"><i class="fas fa-bell mr-1"></i>Awaiting approval</span></div>' : r.checklist_status === 'RETURNED' ? '<div class="mt-1"><span class="badge bg-red-50 text-red-600">Checklist returned</span></div>' : '') + (r.job_code ? '<div class="text-[11px] text-slate-400 mt-0.5">' + esc(r.job_code) + ' · ' + esc(String(r.job_stage || '').replace(/_/g, ' ')) + '</div>' : '') + '</td>'
      + '<td>' + (r.technician_name ? esc(r.technician_name) : '<span class="text-amber-600 font-semibold">Unassigned</span>') + '</td>'
      + '<td class="text-xs">' + (r.scheduled_date ? esc(r.scheduled_date) : '<span class="text-slate-300">—</span>') + '</td>'
      + '<td class="text-slate-500 text-xs">' + esc(r.date_requested) + '</td>'
      + '<td class="whitespace-nowrap" onclick="event.stopPropagation()">' + actions + '</td>'
      + '</tr>';
  }).join('');
}

async function srAction(id, action, extra) {
  let payload = Object.assign({ id: id, action: action }, extra || {});
  if (['REJECT', 'CANCEL', 'HOLD'].indexOf(action) !== -1 && payload.remarks === undefined) {
    const label = { REJECT: 'Reject', CANCEL: 'Cancel', HOLD: 'Put on hold' }[action];
    const reason = prompt(label + ' this service request? Optional reason (shared with the client):', '');
    if (reason === null) return false;
    payload.remarks = reason.trim();
  }
  const json = await apiPost('service_requests/update.php', payload);
  if (!json.success) { toast(json.message, true); return false; }
  toast(json.message, false);
  loadServiceRequests();
  return true;
}

function openNewRequestModal() {
  setModalWide(false);
  const typeOpts = SR_SERVICE_TYPES.map(t => '<option>' + esc(t) + '</option>').join('');
  const html = '<p class="text-xs text-slate-400">A request opened by Management is approved immediately. Assign a technician next.</p>'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Client</label>'
    + '<select id="f-sr-client" class="w-full border rounded-lg px-3 py-2 text-sm">' + clientOptionsHtml() + '</select>'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Service type</label>'
    + '<select id="f-sr-type" class="w-full border rounded-lg px-3 py-2 text-sm">' + typeOpts + '</select>'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Subject</label>'
    + '<input id="f-sr-subject" type="text" maxlength="150" class="w-full border rounded-lg px-3 py-2 text-sm" placeholder="e.g. Inverter shows error E-21">'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Priority</label>'
    + '<select id="f-sr-priority" class="w-full border rounded-lg px-3 py-2 text-sm"><option>NORMAL</option><option>LOW</option><option>HIGH</option><option>URGENT</option></select>'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Description</label>'
    + '<textarea id="f-sr-desc" rows="4" maxlength="5000" class="w-full border rounded-lg px-3 py-2 text-sm" placeholder="What the client reported, when it started, anything already tried..."></textarea>';
  openModal('New Service Request', html, async () => {
    const payload = {
      client_id: Number(document.getElementById('f-sr-client').value),
      service_type: document.getElementById('f-sr-type').value,
      subject: document.getElementById('f-sr-subject').value.trim(),
      priority: document.getElementById('f-sr-priority').value,
      description: document.getElementById('f-sr-desc').value.trim(),
    };
    if (!payload.client_id) { toast('Select a client.', true); return false; }
    if (!payload.subject || !payload.description) { toast('Enter a subject and a description.', true); return false; }
    const json = await apiPost('service_requests/create.php', payload);
    if (!json.success) { toast(json.message, true); return false; }
    toast(json.message, false);
    loadServiceRequests();
    return true;
  });
}

function openAssignModal(srId) {
  setModalWide(false);
  const r = SR_CACHE.find(x => String(x.id) === String(srId)) || {};
  const html = (r.request_code ? '<p class="text-xs text-slate-500">' + esc(r.request_code) + ' — ' + esc(r.subject || r.request_type || '') + (r.technician_name ? '<br>Currently: <b>' + esc(r.technician_name) + '</b>' : '') + '</p>' : '')
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Technician</label>'
    + '<select id="f-tech" class="w-full border rounded-lg px-3 py-2 text-sm">' + techOptionsHtml() + '</select>'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Service date (optional)</label>'
    + '<input id="f-sched" type="date" min="' + todayIso() + '" value="' + esc(r.scheduled_date || '') + '" class="w-full border rounded-lg px-3 py-2 text-sm">'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Note (optional)</label>'
    + '<input id="f-assign-note" type="text" maxlength="255" class="w-full border rounded-lg px-3 py-2 text-sm">';
  openModal(r.technician_name ? 'Reassign Technician' : 'Assign Technician', html, async () => {
    const techId = document.getElementById('f-tech').value;
    if (!techId) { toast('Select a technician.', true); return false; }
    const payload = { id: srId, technician_id: Number(techId), note: document.getElementById('f-assign-note').value.trim() };
    const sched = document.getElementById('f-sched').value;
    if (sched) payload.scheduled_date = sched;
    const json = await apiPost('service_requests/assign.php', payload);
    if (!json.success) { toast(json.message, true); return false; }
    toast(json.message + (json.data && json.data.job_code ? ' Job ' + json.data.job_code + '.' : ''), false);
    loadServiceRequests();
    return true;
  });
}

function openScheduleModal(srId) {
  setModalWide(false);
  const r = SR_CACHE.find(x => String(x.id) === String(srId)) || {};
  const html = '<p class="text-xs text-slate-500">' + esc(r.request_code || '') + (r.technician_name ? ' · ' + esc(r.technician_name) : ' · no technician yet') + '</p>'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Service date</label>'
    + '<input id="f-sched" type="date" min="' + todayIso() + '" value="' + esc(r.scheduled_date || '') + '" class="w-full border rounded-lg px-3 py-2 text-sm">'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Note (optional)</label>'
    + '<input id="f-sched-note" type="text" maxlength="255" class="w-full border rounded-lg px-3 py-2 text-sm">';
  openModal('Schedule Service', html, async () => {
    const d = document.getElementById('f-sched').value;
    if (!d) { toast('Pick a date.', true); return false; }
    return await srAction(srId, 'SCHEDULE', { scheduled_date: d, remarks: document.getElementById('f-sched-note').value.trim() });
  });
}

function srHistoryHtml(history) {
  if (!history.length) return '<p class="text-slate-400 text-sm">No history recorded yet.</p>';
  return '<div class="border-l-2 border-slate-200 ml-1 pl-4 space-y-3">' + history.map(h =>
    '<div class="relative"><span class="absolute -left-[22px] top-1 h-2.5 w-2.5 rounded-full bg-solar"></span>'
    + '<p class="text-sm font-semibold text-slate-800">' + esc(String(h.action).replace(/_/g, ' '))
    + (h.old_status && h.new_status && h.old_status !== h.new_status ? ' <span class="text-xs font-normal text-slate-500">' + esc(h.old_status.replace(/_/g, ' ')) + ' → ' + esc(h.new_status.replace(/_/g, ' ')) + '</span>' : '')
    + '</p>'
    + '<p class="text-[11px] text-slate-400">' + esc(h.created_at) + ' · ' + esc(h.user_name || 'System') + (h.user_role ? ' (' + esc(h.user_role) + ')' : '') + '</p>'
    + (h.remarks ? '<p class="text-xs text-slate-600 mt-0.5 whitespace-pre-line">' + esc(h.remarks) + '</p>' : '')
    + '</div>').join('') + '</div>';
}

async function viewServiceRequest(id) {
  const json = await apiGet('service_requests/detail.php', new URLSearchParams({ id: id }));
  if (!json.success) { toast(json.message, true); return; }
  const d = json.data, r = d.request, c = d.client, t = d.technician, j = d.job;
  const open = SR_OPEN.indexOf(r.status) !== -1;
  const addr = [c.address, c.barangay, c.city, c.province, c.postal_code].filter(Boolean).join(', ');
  const hasLoc = r.lat != null && r.lng != null;

  let buttons = '';
  if (r.status === 'PENDING') {
    buttons += '<button class="px-3 py-1.5 rounded-lg text-xs font-bold bg-emerald-600 text-white" onclick="srDetailAction(' + r.id + ',\'APPROVE\')">Approve</button>'
      + '<button class="px-3 py-1.5 rounded-lg text-xs font-bold bg-red-500 text-white" onclick="srDetailAction(' + r.id + ',\'REJECT\')">Reject</button>';
  }
  if (open && r.status !== 'PENDING') {
    buttons += '<button class="px-3 py-1.5 rounded-lg text-xs font-bold bg-solar text-white" onclick="closeModal();openAssignModal(' + r.id + ')">' + (t ? 'Reassign' : 'Assign') + ' technician</button>'
      + '<button class="px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-100 text-slate-700" onclick="closeModal();openScheduleModal(' + r.id + ')">Schedule</button>';
  }
  if (['ASSIGNED', 'SCHEDULED', 'IN_PROGRESS'].indexOf(r.status) !== -1) {
    buttons += '<button class="px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-100 text-slate-700" onclick="srDetailAction(' + r.id + ',\'HOLD\')">Put on hold</button>';
  }
  if (r.status === 'ON_HOLD') {
    buttons += '<button class="px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-100 text-slate-700" onclick="srDetailAction(' + r.id + ',\'RESUME\')">Resume</button>';
  }
  if (open && r.status !== 'PENDING' && (!j || ['COMPLETED', 'CANCELLED'].indexOf(j.stage) !== -1)) {
    buttons += '<button class="px-3 py-1.5 rounded-lg text-xs font-bold bg-emerald-50 text-emerald-700" onclick="srCompleteFromDetail(' + r.id + ')">Mark completed</button>';
  }
  if (open) {
    buttons += '<button class="px-3 py-1.5 rounded-lg text-xs font-bold bg-red-50 text-red-600" onclick="srDetailAction(' + r.id + ',\'CANCEL\')">Cancel request</button>';
  }

  // One label / value row. Every card uses the same row, so all labels line up
  // in one column and all values start at the same place.
  const row = (label, value) => '<div class="grid grid-cols-[92px_1fr] gap-3 py-2 border-t border-slate-100 first:border-t-0">'
    + '<span class="text-xs font-semibold text-slate-400 pt-0.5">' + label + '</span>'
    + '<span class="text-sm text-slate-800 min-w-0 break-words">' + value + '</span></div>';
  const dash = '<span class="text-slate-300">—</span>';
  const when = v => {
    if (!v) return dash;
    const dt = new Date(String(v).replace(' ', 'T'));
    if (isNaN(dt)) return esc(v);
    const hasTime = String(v).length > 10;
    return esc(dt.toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' }))
      + (hasTime ? ' <span class="text-xs text-slate-400">' + esc(dt.toLocaleTimeString('en-PH', { hour: 'numeric', minute: '2-digit' })) + '</span>' : '');
  };
  const card = (icon, title, body) => '<div class="bg-white border border-slate-200 rounded-xl p-4">'
    + '<p class="text-[11px] font-bold text-slate-400 uppercase tracking-wide mb-1"><i class="fas ' + icon + ' text-solar mr-1.5"></i>' + title + '</p>'
    + body + '</div>';

  const clientCard = card('fa-user', 'Client',
    '<div class="py-2"><p class="font-bold text-slate-900 leading-tight">' + esc(c.name) + '</p>'
    + '<p class="text-xs text-slate-400">' + esc(c.client_code) + '</p></div>'
    + row('Phone', c.phone ? '<a class="hover:text-solar" href="tel:' + esc(c.phone) + '">' + esc(c.phone) + '</a>' : dash)
    + row('Email', c.email ? '<span class="break-all">' + esc(c.email) + '</span>' : dash)
    + row('Address', esc(r.site_address || addr || '') || dash)
    + row('Location', hasLoc
        ? '<span class="text-xs text-slate-500">' + Number(r.lat).toFixed(6) + ', ' + Number(r.lng).toFixed(6) + '</span><br>'
          + '<a class="text-xs text-sky-600 font-semibold hover:underline" target="_blank" rel="noopener" href="https://www.google.com/maps/dir/?api=1&destination=' + r.lat + ',' + r.lng + '"><i class="fas fa-diamond-turn-right mr-1"></i>Get directions</a>'
        : '<span class="text-xs text-amber-600">No map pin yet</span>')
    + row('Account', c.status ? badge(c.status) : dash));

  const jobValue = j
    ? '<span class="font-semibold">' + esc(j.job_code) + '</span> ' + badge(j.stage)
      + '<div class="flex items-center gap-2 mt-1.5"><div class="flex-1 bg-slate-100 rounded-full h-1.5"><div class="bg-solar h-1.5 rounded-full" style="width:' + (Number(j.progress) || 0) + '%"></div></div>'
      + '<span class="text-xs text-slate-500 w-9 text-right">' + (Number(j.progress) || 0) + '%</span></div>'
    : '<span class="text-xs text-slate-400">No job yet</span>';
  const assignCard = card('fa-user-gear', 'Assignment',
    '<div class="py-2">' + (t
      ? '<p class="font-bold text-slate-900 leading-tight">' + esc(t.name) + '</p><p class="text-xs text-slate-400">' + esc(t.technician_code)
        + (t.phone ? ' · <a class="hover:text-solar" href="tel:' + esc(t.phone) + '">' + esc(t.phone) + '</a>' : '') + '</p>'
      : '<p class="font-bold text-amber-600">No technician assigned</p><p class="text-xs text-slate-400">Assign one below to create the job.</p>') + '</div>'
    + row('Job', jobValue)
    + row('Requested', when(r.date_requested) + (r.created_by_name ? '<br><span class="text-xs text-slate-400">by ' + esc(r.created_by_name) + '</span>' : ''))
    + row('Scheduled', when(r.scheduled_date))
    + row('Completed', when(r.completion_date)));

  const section = (title, body) => '<div class="mt-5"><p class="text-[11px] font-bold text-slate-400 uppercase tracking-wide mb-2">' + title + '</p>' + body + '</div>';

  const html = ''
    // Header: what it is, how urgent, what state it is in.
    + '<div class="flex flex-wrap items-start justify-between gap-3">'
    +   '<div class="min-w-0">'
    +     '<p class="text-lg font-extrabold text-slate-900 leading-snug">' + esc(r.subject || r.service_type || 'Service request') + '</p>'
    +     (r.service_type ? '<p class="text-xs text-slate-400 mt-0.5"><i class="fas fa-screwdriver-wrench mr-1"></i>' + esc(r.service_type) + '</p>' : '')
    +   '</div>'
    +   '<div class="flex items-center gap-1.5 shrink-0">' + srStatusBadge(r.status) + badge(r.priority) + '</div>'
    + '</div>'
    + (r.description ? '<p class="mt-3 text-sm text-slate-700 whitespace-pre-line bg-slate-50 border border-slate-100 rounded-xl px-4 py-3">' + esc(r.description) + '</p>' : '')
    + '<div class="grid sm:grid-cols-2 gap-4 mt-4">' + clientCard + assignCard + '</div>'
    + (r.technician_notes ? section('<i class="fas fa-user-gear mr-1"></i>Technician notes', '<p class="text-sm text-slate-700 whitespace-pre-line bg-amber-50 border border-amber-100 rounded-xl px-4 py-3">' + esc(r.technician_notes) + '</p>') : '')
    + (r.resolution ? section('<i class="fas fa-circle-check mr-1"></i>Resolution', '<p class="text-sm text-slate-700 whitespace-pre-line bg-emerald-50 border border-emerald-100 rounded-xl px-4 py-3">' + esc(r.resolution) + '</p>') : '')
    + srChecklistSection(d, r, section)
    + (buttons ? section('Actions', '<div class="flex flex-wrap gap-2">' + buttons + '</div>') : '')
    + section('History', srHistoryHtml(d.history)
        + '<div class="mt-3 flex gap-2"><input id="f-sr-note" type="text" maxlength="1000" placeholder="Add a note to the history..." class="flex-1 min-w-0 border border-slate-200 rounded-lg px-3 py-2 text-sm">'
        + '<button class="px-4 py-2 rounded-lg text-xs font-bold bg-navy text-white shrink-0" onclick="srAddNote(' + r.id + ')">Add note</button></div>');
  setModalWide(true);
  openInfoModal(r.request_code + ' — Service Request', html);
}
// The technician's checklist for this request: steps, items (who / when),
// proof photos, and Approve (request COMPLETED) / Return when it is submitted.
function srChecklistSection(d, r, section) {
  const cl = d.checklist;
  if (!cl) {
    return d.checklist_type ? section('<i class="fas fa-list-check mr-1"></i>' + esc(d.checklist_type) + ' checklist',
      '<p class="text-xs text-slate-400">The technician fills it in on the job (' + (d.job ? 'not started yet' : 'assign a technician first') + ').</p>') : '';
  }
  const look = { OPEN: ['bg-slate-100 text-slate-600', 'In progress · ' + cl.progress + '%'], SUBMITTED: ['bg-violet-100 text-violet-700', 'Waiting for your approval'],
    APPROVED: ['bg-emerald-100 text-emerald-700', 'Approved'], RETURNED: ['bg-red-100 text-red-700', 'Returned for fixes'] }[cl.status];
  const itemsBy = {}, photosBy = {};
  cl.items.forEach(i => (itemsBy[i.step] = itemsBy[i.step] || []).push(i));
  cl.photos.forEach(p => (photosBy[p.step] = photosBy[p.step] || []).push(p));
  const stamp = v => v ? esc(String(v).slice(0, 16)) : '';
  const body = '<div class="border ' + (cl.status === 'SUBMITTED' ? 'border-violet-200 bg-violet-50/30' : 'border-slate-200') + ' rounded-xl p-4">'
    + '<div class="flex items-start justify-between gap-2 flex-wrap mb-2"><div>'
    +   '<span class="badge ' + look[0] + '">' + esc(look[1]) + '</span>'
    +   '<p class="text-[11px] text-slate-400 mt-1">' + (cl.submitted_at ? 'Submitted ' + stamp(cl.submitted_at) + (cl.submitted_by_name ? ' by ' + esc(cl.submitted_by_name) : '') : 'Not submitted yet')
    +   (cl.reviewed_at ? ' · ' + (cl.status === 'APPROVED' ? 'approved' : 'reviewed') + ' ' + stamp(cl.reviewed_at) + (cl.reviewed_by_name ? ' by ' + esc(cl.reviewed_by_name) : '') : '') + '</p></div>'
    +   (cl.status === 'SUBMITTED' && d.can_review
          ? '<div class="flex gap-1.5 shrink-0"><button class="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg" onclick="srChecklistReview(' + r.id + ',\'APPROVE\')"><i class="fas fa-check mr-1"></i>Approve &amp; complete</button>'
            + '<button class="bg-white border border-red-200 text-red-600 text-xs font-bold px-3 py-1.5 rounded-lg" onclick="srChecklistReview(' + r.id + ',\'RETURN\')"><i class="fas fa-rotate-left mr-1"></i>Return</button></div>' : '')
    + '</div>'
    + (cl.submit_note ? '<p class="mb-2 text-xs text-slate-700 bg-white border border-slate-100 rounded-lg px-3 py-2"><i class="fas fa-user-gear text-slate-300 mr-1"></i><b>Work done:</b> ' + esc(cl.submit_note) + '</p>' : '')
    + (cl.review_note ? '<p class="mb-2 text-xs ' + (cl.status === 'RETURNED' ? 'text-red-700 bg-red-50' : 'text-emerald-700 bg-emerald-50') + ' rounded-lg px-3 py-2"><i class="fas fa-comment-dots mr-1"></i>' + esc(cl.review_note) + '</p>' : '')
    + cl.steps.map((s, i) => '<div class="' + (i ? 'mt-3 pt-3 border-t border-slate-100' : '') + '">'
        + '<p class="text-xs font-semibold text-slate-700 mb-1">' + (i + 1) + '. ' + esc(s.name) + ' <span class="font-normal text-slate-400">· ' + s.resolved + '/' + s.total + ' items · ' + s.photos + ' photo' + (s.photos === 1 ? '' : 's') + '</span></p>'
        + (itemsBy[s.name] || []).map(it => '<p class="text-[11px] ' + (it.status === 'PENDING' ? 'text-slate-400' : 'text-slate-600') + '">'
            + (it.status === 'COMPLETED' ? '<i class="fas fa-square-check text-emerald-500 mr-1"></i>' : it.status === 'NOT_APPLICABLE' ? '<i class="fas fa-square-minus text-slate-400 mr-1"></i>' : '<i class="far fa-square text-slate-300 mr-1"></i>')
            + esc(it.description) + (it.completed_by_name ? ' <span class="text-slate-400">· ' + esc(it.completed_by_name) + ', ' + stamp(it.completed_at) + '</span>' : '')
            + (it.remarks ? ' <span class="italic text-slate-500">“' + esc(it.remarks) + '”</span>' : '') + '</p>').join('')
        + ((photosBy[s.name] || []).length ? '<div class="grid grid-cols-5 gap-1.5 mt-1.5">' + photosBy[s.name].map(p => '<a href="' + esc(p.url) + '" target="_blank" rel="noopener">'
            + '<img src="' + esc(p.url) + '" alt="" loading="lazy" class="w-full aspect-square object-cover rounded-lg border border-slate-200 hover:opacity-90"></a>').join('') + '</div>'
          : '<p class="text-[11px] text-slate-300 mt-1">No photo yet</p>')
        + '</div>').join('')
    + '</div>';
  return section('<i class="fas fa-list-check mr-1"></i>' + esc(cl.request_type) + ' checklist', body);
}

function srChecklistReview(srId, decision) {
  const html = decision === 'RETURN'
    ? '<p class="text-sm text-slate-600">The technician will see this note, fix the checklist and submit it again.</p>'
      + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">What needs fixing? *</label>'
      + '<textarea id="f-cl-note" rows="3" maxlength="500" class="w-full border rounded-lg px-3 py-2 text-sm" placeholder="e.g. Add a photo of the new breaker installed."></textarea>'
    : '<p class="text-sm text-slate-600">Approve the checklist. The job and the service request become <b>COMPLETED</b>, and the client and technician are notified.</p>'
      + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Note (optional)</label>'
      + '<textarea id="f-cl-note" rows="2" maxlength="500" class="w-full border rounded-lg px-3 py-2 text-sm" placeholder="e.g. Good work."></textarea>';
  setModalWide(false);
  openModal(decision === 'RETURN' ? 'Return checklist' : 'Approve & complete', html, async () => {
    const note = document.getElementById('f-cl-note').value.trim();
    if (decision === 'RETURN' && !note) { toast('Write what needs fixing.', true); return false; }
    const json = await apiPost('sr_checklist/review.php', { service_request_id: srId, decision, note });
    if (!json.success) { toast(json.message, true); return false; }
    toast(json.message, false);
    loadServiceRequests();
    setTimeout(() => viewServiceRequest(srId), 60);
    return true;
  });
}

async function srDetailAction(id, action) {
  const ok = await srAction(id, action);
  if (ok) viewServiceRequest(id);
}
async function srCompleteFromDetail(id) {
  const resolution = prompt('Mark this request completed. Resolution (what was done):', '');
  if (resolution === null) return;
  const ok = await srAction(id, 'COMPLETE', { resolution: resolution.trim() });
  if (ok) viewServiceRequest(id);
}
async function srAddNote(id) {
  const el = document.getElementById('f-sr-note');
  const text = el ? el.value.trim() : '';
  if (!text) { toast('Type a note first.', true); return; }
  const ok = await srAction(id, 'NOTE', { remarks: text });
  if (ok) viewServiceRequest(id);
}

/* ---------------- Sub-contractors (assets/js/suntrack-subcon-mgmt.js) ---------------- */
const SUBCON = SunTrackSubcon.mount({
  root: document.getElementById('subcon-root'), base: '<?= APP_BASE_URL ?>', csrf: CSRF_TOKEN, canManage: true,
});

/* ---------------- Jobs ---------------- */
let JOB_CACHE = [];
// Who does the job: the technician, or the subcontractor holding it.
function jobWorkerCell(r) {
  if (r.subcontractor) {
    const s = r.subcontractor;
    return '<span class="font-semibold">' + esc(s.name) + '</span>'
      + (s.auto ? ' <span class="text-[10px] font-bold text-violet-700 bg-violet-50 rounded px-1.5 py-0.5" title="Offered automatically because technicians were near full">AUTO</span>' : '')
      + '<span class="block text-[11px] text-slate-500">Subcontractor · ' + esc(s.status_label) + '</span>';
  }
  return r.technician_name ? esc(r.technician_name) : '<span class="text-amber-600 font-semibold">Unassigned</span>';
}
function subcontractJob(jobId) {
  const r = JOB_CACHE.find(x => x.id == jobId);
  if (!r) return;
  SunTrackSubcon.assignJob({ jobId: r.id, jobCode: r.job_code, hasTechnician: !!r.technician_id, onDone: loadJobs });
}
async function loadJobs() {
  const tbody = document.getElementById('job-tbody');
  tbody.innerHTML = '<tr><td colspan="8" class="text-center text-slate-400 py-6">Loading...</td></tr>';
  const params = filterParams({
    search: 'job-search', stage: 'job-stage', job_type: 'job-type', priority: 'job-priority',
    technician_id: 'job-tech', date_from: 'job-from', date_to: 'job-to', unassigned: 'job-unassigned',
  });
  const json = await apiGet('jobs/list.php', params);
  if (!json.success) { tbody.innerHTML = '<tr><td colspan="8" class="text-red-500 text-center py-6">' + esc(json.message) + '</td></tr>'; barCount('jobs'); return; }
  const rows = json.data.rows;
  JOB_CACHE = rows;
  barCount('jobs', rows.length);
  if (!rows.length) { tbody.innerHTML = '<tr><td colspan="8" class="text-center text-slate-400 py-6">No jobs match. Try fewer words or press Clear.</td></tr>'; return; }
  tbody.innerHTML = rows.map(r => {
    const canReassign = ['COMPLETED', 'CANCELLED'].indexOf(r.stage) === -1;
    return '<tr>'
      + '<td class="font-semibold cursor-pointer text-solar" onclick="viewJobDetail(' + r.id + ')">' + esc(r.job_code) + '</td>'
      + '<td>' + esc(r.job_type) + '</td>'
      + '<td>' + esc(r.client_name) + '</td>'
      + '<td>' + jobWorkerCell(r) + '</td>'
      + '<td>' + badge(r.priority) + '</td>'
      + '<td>' + badge(r.stage) + '</td>'
      + '<td><div class="w-24 bg-slate-100 rounded-full h-2"><div class="bg-solar h-2 rounded-full" style="width:' + r.progress + '%"></div></div></td>'
      + '<td class="whitespace-nowrap">' + (r.subcontractor
          ? '<button class="link-btn text-solar" onclick="SUBCON.openAssignment(' + r.subcontractor.assignment_id + ')">View assignment</button>'
          : (canReassign ? '<button class="link-btn text-solar" onclick="openReassignModal(' + r.id + ')">' + (r.technician_name ? 'Reassign' : 'Assign') + '</button>'
              + ' <button class="link-btn text-slate-500 ml-1" onclick="subcontractJob(' + r.id + ')">Subcontract</button>' : '')) + '</td>'
      + '</tr>';
  }).join('');
}
function openCreateJobModal() {
  const html = '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Client</label>'
    + '<select id="f-client" class="w-full border rounded-lg px-3 py-2 text-sm">' + clientOptionsHtml() + '</select>'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Job type</label>'
    + '<select id="f-type" class="w-full border rounded-lg px-3 py-2 text-sm"><option>INSTALLATION</option><option>MAINTENANCE</option><option>REPAIR</option><option>INSPECTION</option></select>'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Priority</label>'
    + '<select id="f-priority" class="w-full border rounded-lg px-3 py-2 text-sm"><option>NORMAL</option><option>LOW</option><option>HIGH</option><option>URGENT</option></select>'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Site address</label>'
    + '<input id="f-addr" type="text" class="w-full border rounded-lg px-3 py-2 text-sm">'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Scheduled date</label>'
    + '<input id="f-sched" type="date" class="w-full border rounded-lg px-3 py-2 text-sm">'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Technician (optional)</label>'
    + '<select id="f-tech" class="w-full border rounded-lg px-3 py-2 text-sm"><option value="">— Leave unassigned —</option>' + SELECT_OPTIONS.technicians.map(o => '<option value="' + o.id + '">' + esc(o.label) + '</option>').join('') + '</select>'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Description</label>'
    + '<textarea id="f-desc" rows="2" class="w-full border rounded-lg px-3 py-2 text-sm"></textarea>';
  openModal('Create Job', html, async () => {
    const clientId = document.getElementById('f-client').value;
    if (!clientId) { toast('Select a client.', true); return false; }
    const payload = {
      client_id: Number(clientId),
      job_type: document.getElementById('f-type').value,
      priority: document.getElementById('f-priority').value,
      site_address: document.getElementById('f-addr').value,
      scheduled_date: document.getElementById('f-sched').value,
      description: document.getElementById('f-desc').value,
    };
    const techId = document.getElementById('f-tech').value;
    if (techId) payload.technician_id = Number(techId);
    const json = await apiPost('jobs/create.php', payload);
    if (!json.success) { toast(json.message, true); return false; }
    toast(json.message, false);
    loadJobs();
    return true;
  });
}
function openReassignModal(jobId) {
  const html = '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Technician</label>'
    + '<select id="f-tech" class="w-full border rounded-lg px-3 py-2 text-sm">' + techOptionsHtml() + '</select>';
  openModal('Assign Technician', html, async () => {
    const techId = document.getElementById('f-tech').value;
    if (!techId) { toast('Select a technician.', true); return false; }
    const json = await apiPost('jobs/reassign.php', { job_id: jobId, technician_id: Number(techId) });
    if (!json.success) { toast(json.message, true); return false; }
    toast(json.message, false);
    loadJobs();
    return true;
  });
}
// Stage history as a vertical timeline: one row per step — stage and who on the
// left, date and time on the right, any note on its own line underneath.
function stageHistoryHtml(history) {
  if (!history || !history.length) return '<p class="text-xs text-slate-400 mb-4">No history yet.</p>';
  const label = s => String(s || '').toLowerCase().replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  const when = ts => {
    const d = new Date(String(ts).replace(' ', 'T'));
    return isNaN(d) ? { date: esc(ts), time: '' } : {
      date: d.toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' }),
      time: d.toLocaleTimeString('en-PH', { hour: 'numeric', minute: '2-digit' }),
    };
  };
  return '<ol class="relative mb-4 ml-1.5 border-l-2 border-slate-100">'
    + history.map((h, i) => {
        const last = i === history.length - 1;
        const w = when(h.created_at);
        return '<li class="relative pl-5 ' + (last ? '' : 'pb-4') + '">'
          + '<span class="absolute -left-[7px] top-1 w-3 h-3 rounded-full border-2 border-white '
          +   (last ? 'bg-solar ring-2 ring-orange-100' : 'bg-slate-300') + '"></span>'
          + '<div class="flex items-start justify-between gap-3">'
          +   '<div class="min-w-0">'
          +     '<p class="text-sm font-bold text-slate-800">' + esc(label(h.to_stage)) + '</p>'
          +     '<p class="text-xs text-slate-500"><i class="fas fa-user text-[10px] text-slate-300 mr-1"></i>' + esc(h.changed_by_name || 'System') + '</p>'
          +   '</div>'
          +   '<div class="text-right shrink-0 leading-tight">'
          +     '<p class="text-xs font-semibold text-slate-600">' + w.date + '</p>'
          +     '<p class="text-[11px] text-slate-400">' + w.time + '</p>'
          +   '</div>'
          + '</div>'
          + (h.note ? '<p class="mt-1.5 text-xs text-slate-600 bg-slate-50 rounded-lg px-2.5 py-1.5">' + esc(h.note) + '</p>' : '')
          + '</li>';
      }).join('')
    + '</ol>';
}

/* ---- Installation: one stage per visit, reviewed by Management ---- */
const PLAN_LOOK = {
  APPROVED:  ['bg-emerald-100 text-emerald-700', 'fa-circle-check'],
  SUBMITTED: ['bg-sky-100 text-sky-700', 'fa-hourglass-half'],
  RETURNED:  ['bg-red-100 text-red-700', 'fa-rotate-left'],
  SCHEDULED: ['bg-orange-100 text-orange-700', 'fa-calendar-day'],
  PLANNED:   ['bg-slate-100 text-slate-500', 'fa-clock'],
};
function planDate(ymd) {
  return ymd ? new Date(String(ymd).slice(0, 10) + 'T00:00').toLocaleDateString('en-PH', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }) : '';
}
// Installation list: where the job stands, with a Review button when a stage waits.
function planStepCell(p) {
  if (!p) return '<span class="text-xs text-slate-400">—</span>';
  const look = PLAN_LOOK[p.all_approved ? 'APPROVED' : p.status] || PLAN_LOOK.PLANNED;
  return '<div class="flex items-center gap-2">'
    + '<span class="badge ' + look[0] + '"><i class="fas ' + look[1] + ' mr-1"></i>' + esc(p.label) + '</span>'
    + (p.status === 'SUBMITTED' ? '<span class="text-[11px] font-bold text-sky-700 underline">Review</span>' : '')
    + '</div>';
}

let LAST_JOB_DETAIL = null;
// Job view: every stage with its date / review state and the action that fits it.
function stagePlanHtml(d) {
  const plan = d.installation_plan || [];
  if (!plan.length) return '';
  const closed = ['COMPLETED', 'CANCELLED'].includes(d.job.stage);
  const photos = {};
  (d.installation_photos || []).forEach(p => { photos[p.stage] = (photos[p.stage] || 0) + 1; });
  const crew = d.crew || [];
  return '<div class="mt-3 border border-slate-200 rounded-xl p-3">'
    + '<p class="font-bold text-sm text-slate-800 mb-1"><i class="fas fa-calendar-check text-solar mr-1"></i>Stage schedule & review</p>'
    + '<p class="text-[11px] text-slate-400 mb-2">One stage per visit. Approve a submitted stage to schedule the next one.</p>'
    + (crew.length ? '<div class="flex flex-wrap items-center gap-1.5 mb-3"><span class="text-[11px] font-semibold text-slate-500 mr-1"><i class="fas fa-users mr-1"></i>Crew (' + crew.length + '):</span>'
        + crew.map(m => '<span class="badge ' + (m.is_lead ? 'bg-orange-100 text-orange-700' : 'bg-slate-100 text-slate-600') + '">' + esc(m.name) + (m.is_lead ? ' · lead' : '') + '</span>').join('') + '</div>' : '')
    + ''
    + plan.map((r, i) => {
        const look = PLAN_LOOK[r.status] || PLAN_LOOK.PLANNED;
        let actions = '';
        if (!closed && r.status === 'SUBMITTED') {
          actions = '<button class="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg" onclick="openStageReview(\'' + esc(r.stage) + '\', \'APPROVE\')"><i class="fas fa-check mr-1"></i>Approve</button>'
            + '<button class="border border-red-200 text-red-600 hover:bg-red-50 text-xs font-bold px-3 py-1.5 rounded-lg" onclick="openStageReview(\'' + esc(r.stage) + '\', \'RETURN\')"><i class="fas fa-rotate-left mr-1"></i>Return</button>';
        } else if (!closed && ['PLANNED', 'SCHEDULED', 'RETURNED'].includes(r.status)) {
          // Any open stage can be booked ahead; it still opens for the crew only
          // once every stage before it is approved.
          actions = '<button class="border border-slate-200 text-slate-600 hover:border-solar hover:text-solar text-xs font-bold px-3 py-1.5 rounded-lg" onclick="openStageSchedule(\'' + esc(r.stage) + '\')">'
            + '<i class="fas fa-calendar mr-1"></i>' + (r.status === 'PLANNED' ? 'Schedule' : 'Reschedule') + '</button>';
        }
        const sub = r.status === 'SUBMITTED' ? 'Submitted ' + esc(String(r.submitted_at || '').slice(0, 16)) + (r.submitted_by_name ? ' by ' + esc(r.submitted_by_name) : '')
          : r.status === 'APPROVED' ? 'Approved' + (r.reviewed_by_name ? ' by ' + esc(r.reviewed_by_name) : '') + (r.reviewed_at ? ' · ' + esc(String(r.reviewed_at).slice(0, 16)) : '')
          : r.scheduled_date ? 'Visit: ' + esc(planDate(r.scheduled_date)) : 'No date yet';
        return '<div class="' + (i ? 'border-t border-slate-100 pt-2.5 mt-2.5' : '') + '">'
          + '<div class="flex items-start justify-between gap-2 flex-wrap">'
          +   '<div class="min-w-0"><p class="text-sm font-semibold text-slate-800">' + r.position + '. ' + esc(r.stage)
          +     ' <span class="badge ' + look[0] + ' ml-1"><i class="fas ' + look[1] + ' mr-1"></i>' + esc(r.status_label) + '</span></p>'
          +   '<p class="text-[11px] text-slate-400">' + sub + ' · ' + (photos[r.stage] || 0) + ' photo' + ((photos[r.stage] || 0) === 1 ? '' : 's') + '</p></div>'
          +   '<div class="flex gap-1.5 shrink-0">' + actions + '</div>'
          + '</div>'
          + (r.submit_note ? '<p class="mt-1.5 text-xs text-slate-600 bg-slate-50 rounded-lg px-2.5 py-1.5"><i class="fas fa-user-gear text-slate-300 mr-1"></i>' + esc(r.submit_note) + '</p>' : '')
          + (r.review_note && r.status !== 'APPROVED' ? '<p class="mt-1.5 text-xs text-red-700 bg-red-50 rounded-lg px-2.5 py-1.5"><i class="fas fa-comment-dots mr-1"></i>' + esc(r.review_note) + '</p>' : '')
          + '</div>';
      }).join('')
    + '</div>';
}

function stageInputDate(offsetDays) {
  const t = new Date(Date.now() + offsetDays * 86400000);
  return t.getFullYear() + '-' + String(t.getMonth() + 1).padStart(2, '0') + '-' + String(t.getDate()).padStart(2, '0');
}

function openStageReview(stage, decision) {
  const d = LAST_JOB_DETAIL;
  if (!d) return;
  const plan = d.installation_plan || [];
  const idx = plan.findIndex(r => r.stage === stage);
  const next = plan[idx + 1] || null;
  const mr = d.open_material_request;
  let html;
  if (decision === 'RETURN') {
    html = '<p class="text-sm text-slate-600">The technician will see this note and fix <b>' + esc(stage) + '</b> before submitting it again.</p>'
      + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">What needs fixing? *</label>'
      + '<textarea id="f-note" rows="3" maxlength="500" class="w-full border rounded-lg px-3 py-2 text-sm" placeholder="e.g. Photo of the roof anchors is blurry — please retake it."></textarea>';
  } else {
    html = '<p class="text-sm text-slate-600">Approve <b>' + esc(stage) + '</b>' + (next ? ' and book the next visit.' : '. This is the last stage — the technician can then complete the job.') + '</p>'
      + (next ? '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Next visit: ' + esc(next.stage) + '</label>'
        + '<input id="f-next-date" type="date" min="' + stageInputDate(0) + '" value="' + (next.scheduled_date || d.suggested_next_date || stageInputDate(1)) + '" class="w-full border rounded-lg px-3 py-2 text-sm">'
        + '<p class="text-[11px] text-slate-400 mt-1">'
        + ((d.crew || []).length ? '<i class="fas fa-wand-magic-sparkles text-solar mr-1"></i>Suggested: the first day the whole crew of ' + d.crew.length + ' is free (Sundays skipped). ' : '')
        + 'Leave empty to schedule it later.</p>' : '')
      + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Note for the technician (optional)</label>'
      + '<textarea id="f-note" rows="2" maxlength="500" class="w-full border rounded-lg px-3 py-2 text-sm" placeholder="e.g. Good work — bring the ladder tomorrow."></textarea>'
      + '<div class="mt-4 border border-slate-200 rounded-xl p-3">'
      +   '<p class="text-xs font-bold text-slate-700 mb-1"><i class="fas fa-dolly text-solar mr-1"></i>Materials from the warehouse</p>'
      +   (mr
          ? '<p class="text-xs text-slate-500">Already requested: <b>' + esc(mr.request_code) + '</b> (' + esc(String(mr.status).toLowerCase()) + (mr.needed_by ? ', needed by ' + esc(planDate(mr.needed_by)) : '') + ').</p>'
          : '<p class="text-[11px] text-slate-400 mb-2">' + (idx === 0 ? 'The inspection is done — request what the next visits need so it is ready on the day.' : 'Optional — request anything still needed.') + ' Leave blank for none.</p>'
            + '<div class="grid grid-cols-3 gap-2">'
            + ['panels', 'inverters', 'batteries'].map(k => '<div><label class="block text-[11px] font-semibold text-slate-500 mb-1">' + k[0].toUpperCase() + k.slice(1) + '</label>'
                + '<input id="f-mr-' + k + '" type="number" min="0" class="w-full border rounded-lg px-2 py-1.5 text-sm" placeholder="0"></div>').join('')
            + '</div>')
      + '</div>';
  }
  openModal((decision === 'RETURN' ? 'Return ' : 'Approve ') + stage, html, async () => {
    const val = id => { const el = document.getElementById(id); return el ? el.value.trim() : ''; };
    if (decision === 'RETURN' && !val('f-note')) { toast('Write what needs fixing.', true); return false; }
    const json = await apiPost('installation/stage_review.php', {
      job_id: d.job.id, stage, decision, note: val('f-note'), next_date: val('f-next-date'),
      mr_panels: val('f-mr-panels'), mr_inverters: val('f-mr-inverters'), mr_batteries: val('f-mr-batteries'),
    });
    if (!json.success) { toast(json.message, true); return false; }
    toast(json.message, false);
    loadInstallation();
    setTimeout(() => viewJobDetail(d.job.id), 50); // back to the job, refreshed
    return true;
  });
}

function openStageSchedule(stage) {
  const d = LAST_JOB_DETAIL;
  if (!d) return;
  const row = (d.installation_plan || []).find(r => r.stage === stage) || {};
  const html = '<p class="text-sm text-slate-600">Pick the day the technician does <b>' + esc(stage) + '</b>. They are notified, and the stage opens for them on that day.</p>'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Visit date</label>'
    + '<input id="f-date" type="date" min="' + stageInputDate(0) + '" value="' + (row.scheduled_date || d.suggested_next_date || stageInputDate(1)) + '" class="w-full border rounded-lg px-3 py-2 text-sm">'
    + ((d.crew || []).length && !row.scheduled_date ? '<p class="text-[11px] text-slate-400 mt-1"><i class="fas fa-wand-magic-sparkles text-solar mr-1"></i>Suggested: the first day the whole crew is free.</p>' : '');
  openModal('Schedule ' + stage, html, async () => {
    const date = document.getElementById('f-date').value;
    if (!date) { toast('Pick a date.', true); return false; }
    const json = await apiPost('installation/stage_schedule.php', { job_id: d.job.id, stage, date });
    if (!json.success) { toast(json.message, true); return false; }
    toast(json.message, false);
    loadInstallation();
    setTimeout(() => viewJobDetail(d.job.id), 50);
    return true;
  });
}

// Proof photos the technician took at each installation stage, in working order.
// Every stage is listed, so a stage without its photo stands out.
// The maintenance inspection as the technician filled it: each section's
// condition, items (who ticked them, when), proof photos — and the review.
function maintenanceReviewHtml(d) {
  const m = d.maintenance;
  const look = { OPEN: ['bg-slate-100 text-slate-600', 'Not submitted yet'], SUBMITTED: ['bg-sky-100 text-sky-700', 'Waiting for your review'],
    APPROVED: ['bg-emerald-100 text-emerald-700', 'Approved'], RETURNED: ['bg-red-100 text-red-700', 'Returned for fixes'] }[m.review_status] || ['bg-slate-100 text-slate-600', m.review_status];
  const condCol = { Good: 'text-emerald-600', Fair: 'text-amber-600', Poor: 'text-red-600' };
  const photosBy = {};
  (m.photos || []).forEach(p => { (photosBy[p.section] = photosBy[p.section] || []).push(p); });
  const itemsBy = {};
  (m.items || []).forEach(i => { (itemsBy[i.category] = itemsBy[i.category] || []).push(i); });
  const sub = m.review_status === 'SUBMITTED' ? 'Submitted ' + esc(String(m.submitted_at || '').slice(0, 16)) + (m.submitted_by_name ? ' by ' + esc(m.submitted_by_name) : '')
    : m.review_status === 'APPROVED' ? 'Approved' + (m.reviewed_by_name ? ' by ' + esc(m.reviewed_by_name) : '') + (m.reviewed_at ? ' · ' + esc(String(m.reviewed_at).slice(0, 16)) : '')
    : m.review_status === 'RETURNED' ? 'Returned' + (m.reviewed_at ? ' · ' + esc(String(m.reviewed_at).slice(0, 16)) : '') : 'The technician has not submitted it yet.';
  return '<div class="mt-3 border border-slate-200 rounded-xl p-3">'
    + '<div class="flex items-start justify-between gap-2 flex-wrap mb-2">'
    +   '<div><p class="font-bold text-sm text-slate-800"><i class="fas fa-wrench text-solar mr-1"></i>Maintenance inspection'
    +     ' <span class="badge ' + look[0] + ' ml-1">' + esc(look[1]) + '</span></p>'
    +   '<p class="text-[11px] text-slate-400">' + sub + '</p></div>'
    +   (m.review_status === 'SUBMITTED'
          ? '<div class="flex gap-1.5 shrink-0"><button class="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg" onclick="openMaintReview(\'APPROVE\')"><i class="fas fa-check mr-1"></i>Approve</button>'
            + '<button class="bg-white border border-red-200 text-red-600 text-xs font-bold px-3 py-1.5 rounded-lg" onclick="openMaintReview(\'RETURN\')"><i class="fas fa-rotate-left mr-1"></i>Return</button></div>' : '')
    + '</div>'
    + (m.submit_note ? '<p class="mb-2 text-xs text-slate-600 bg-slate-50 rounded-lg px-2.5 py-1.5"><i class="fas fa-user-gear text-slate-300 mr-1"></i>' + esc(m.submit_note) + '</p>' : '')
    + (m.review_note ? '<p class="mb-2 text-xs ' + (m.review_status === 'RETURNED' ? 'text-red-700 bg-red-50' : 'text-emerald-700 bg-emerald-50') + ' rounded-lg px-2.5 py-1.5"><i class="fas fa-comment-dots mr-1"></i>' + esc(m.review_note) + '</p>' : '')
    + m.sections.map((s, i) => {
        const list = photosBy[s.name] || [];
        return '<div class="' + (i ? 'mt-3 pt-3 border-t border-slate-100' : '') + '">'
          + '<div class="flex items-center justify-between gap-2 mb-1">'
          +   '<p class="text-xs font-semibold text-slate-700">' + (i + 1) + '. ' + esc(s.name) + ' <span class="text-slate-400 font-normal">· ' + s.resolved + '/' + s.total + ' items</span></p>'
          +   '<span class="text-[11px] font-bold ' + (condCol[s.condition] || 'text-slate-300') + '">' + esc(s.condition || 'No condition') + '</span>'
          + '</div>'
          + (itemsBy[s.name] || []).map(it => '<p class="text-[11px] ' + (it.status === 'PENDING' ? 'text-slate-400' : 'text-slate-600') + '">'
              + (it.status === 'COMPLETED' ? '<i class="fas fa-square-check text-emerald-500 mr-1"></i>' : it.status === 'NOT_APPLICABLE' ? '<i class="fas fa-square-minus text-slate-400 mr-1"></i>' : '<i class="far fa-square text-slate-300 mr-1"></i>')
              + esc(it.description) + (it.completed_by_name ? ' <span class="text-slate-400">· ' + esc(it.completed_by_name) + (it.completed_at ? ', ' + esc(String(it.completed_at).slice(0, 16)) : '') + '</span>' : '')
              + (it.remarks ? ' <span class="italic text-slate-500">“' + esc(it.remarks) + '”</span>' : '') + '</p>').join('')
          + (list.length
              ? '<div class="grid grid-cols-4 gap-1.5 mt-1.5">' + list.map(p =>
                  '<a href="' + esc(p.url) + '" target="_blank" rel="noopener" title="' + esc((p.uploaded_by_name || '') + ' · ' + String(p.created_at).slice(0, 16)) + '">'
                  + '<img src="' + esc(p.url) + '" alt="' + esc(s.name) + ' photo" loading="lazy" class="w-full aspect-square object-cover rounded-lg border border-slate-200 hover:opacity-90"></a>').join('') + '</div>'
              : '<p class="text-[11px] text-slate-300 mt-1">No photo yet</p>')
          + '</div>';
      }).join('')
    + ((m.issues_found || m.inspection_results) ? '<div class="mt-3 pt-3 border-t border-slate-100 text-xs text-slate-600">'
        + (m.inspection_results ? '<p><b>Results:</b> ' + esc(m.inspection_results) + '</p>' : '')
        + (m.issues_found ? '<p class="mt-1"><b>Issues:</b> ' + esc(m.issues_found) + '</p>' : '') + '</div>' : '')
    + '</div>';
}

function openMaintReview(decision) {
  const d = LAST_JOB_DETAIL;
  if (!d) return;
  const html = decision === 'RETURN'
    ? '<p class="text-sm text-slate-600">The technician will see this note and fix the inspection before submitting it again.</p>'
      + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">What needs fixing? *</label>'
      + '<textarea id="f-note" rows="3" maxlength="500" class="w-full border rounded-lg px-3 py-2 text-sm" placeholder="e.g. Battery photo is blurry — please retake it."></textarea>'
    : '<p class="text-sm text-slate-600">Approve the maintenance inspection of <b>' + esc(d.job.job_code) + '</b>. The technician can then file the work report and complete the job.</p>'
      + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Note for the technician (optional)</label>'
      + '<textarea id="f-note" rows="2" maxlength="500" class="w-full border rounded-lg px-3 py-2 text-sm" placeholder="e.g. Good work — schedule the inverter fan replacement."></textarea>';
  openModal((decision === 'RETURN' ? 'Return' : 'Approve') + ' maintenance inspection', html, async () => {
    const note = document.getElementById('f-note').value.trim();
    if (decision === 'RETURN' && !note) { toast('Write what needs fixing.', true); return false; }
    const json = await apiPost('maintenance/review.php', { job_id: d.job.id, decision, note });
    if (!json.success) { toast(json.message, true); return false; }
    toast(json.message, false);
    if (CURRENT_TAB === 'maintenance') loadMaintenance();
    setTimeout(() => viewJobDetail(d.job.id), 50); // back to the job, refreshed
    return true;
  });
}

function installationPhotosHtml(photos) {
  const order = ['Site Preparation', 'Mounting', 'Electrical', 'Testing', 'Finalization'];
  const byStage = {};
  photos.forEach(p => { (byStage[p.stage] = byStage[p.stage] || []).push(p); });
  Object.keys(byStage).forEach(s => { if (!order.includes(s)) order.push(s); });
  return '<div class="mt-3 border border-slate-200 rounded-xl p-3">'
    + '<p class="font-bold text-sm text-slate-800 mb-2"><i class="fas fa-camera text-solar mr-1"></i>Installation photos'
    + ' <span class="font-normal text-xs text-slate-400">· ' + photos.length + ' photo' + (photos.length === 1 ? '' : 's') + '</span></p>'
    + order.map((stage, i) => {
        const list = byStage[stage] || [];
        return '<div class="' + (i ? 'mt-3 pt-3 border-t border-slate-100' : '') + '">'
          + '<div class="flex items-center justify-between gap-2 mb-1.5">'
          +   '<p class="text-xs font-semibold text-slate-700">' + (i + 1) + '. ' + esc(stage) + '</p>'
          +   (list.length ? '<span class="text-[11px] text-slate-400">' + list.length + ' photo' + (list.length === 1 ? '' : 's') + '</span>'
                           : '<span class="text-[11px] text-slate-300">No photo yet</span>')
          + '</div>'
          + (list.length
              ? '<div class="grid grid-cols-4 gap-1.5">' + list.map(p =>
                  '<a href="' + esc(p.url) + '" target="_blank" rel="noopener" title="' + esc((p.uploaded_by_name || '') + ' · ' + String(p.created_at).slice(0, 16)) + '">'
                  + '<img src="' + esc(p.url) + '" alt="' + esc(stage) + ' photo" loading="lazy" class="w-full aspect-square object-cover rounded-lg border border-slate-200 hover:opacity-90"></a>').join('')
                + '</div>'
              : '')
          + '</div>';
      }).join('')
    + '</div>';
}

// The technician's work report as one card: who filed it and when, then every field they wrote.
function workReportCardHtml(r) {
  if (!r) {
    return '<div class="mt-3 border border-dashed border-slate-200 rounded-xl p-3 text-xs text-slate-400">'
      + '<i class="fas fa-file-lines mr-1"></i>No work report filed yet. The technician files it before completing the job.</div>';
  }
  const duration = r.duration_text || (r.duration_minutes ? r.duration_minutes + ' min' : '');
  const field = (label, value, full) =>
    '<div' + (full ? ' class="col-span-2"' : '') + '><p class="text-[11px] font-semibold text-slate-400 uppercase">' + label + '</p>'
    + '<p class="text-sm ' + (value ? 'text-slate-800 whitespace-pre-line break-words' : 'text-slate-300') + '">' + (value ? esc(value) : '—') + '</p></div>';
  return '<div class="mt-3 border border-slate-200 rounded-xl p-3">'
    + '<div class="flex items-start justify-between gap-2 mb-3">'
    +   '<div><p class="font-bold text-sm text-slate-800"><i class="fas fa-file-lines text-solar mr-1"></i>Work report ' + esc(r.report_code) + '</p>'
    +   '<p class="text-xs text-slate-500">' + esc(r.technician_name || '—') + (r.technician_code ? ' (' + esc(r.technician_code) + ')' : '')
    +   (r.submitted_date ? ' · submitted ' + esc(String(r.submitted_date).slice(0, 16)) : '') + '</p></div>'
    +   (r.status ? badge(r.status) : '')
    + '</div>'
    + '<div class="grid grid-cols-2 gap-3">'
    +   field('Work type', r.work_type)
    +   field('Duration', duration)
    +   field('Remarks', r.remarks, true)
    +   field('Materials used', r.materials_used, true)
    +   field('Issues found', r.issues_found, true)
    + '</div></div>';
}
async function viewJobDetail(jobId) {
  const json = await apiGet('jobs/detail.php', new URLSearchParams({ job_id: jobId }));
  if (!json.success) { toast(json.message, true); return; }
  const d = json.data, j = d.job;
  LAST_JOB_DETAIL = d; // the stage Approve / Return / Schedule forms read it
  let html = '<div class="grid grid-cols-2 gap-3 text-sm mb-4">'
    + '<div><p class="text-slate-400 text-xs">Client</p><p class="font-semibold">' + esc(j.client_name) + '</p></div>'
    + '<div><p class="text-slate-400 text-xs">Technician</p><p class="font-semibold">' + (j.technician_name ? esc(j.technician_name) : '—') + '</p></div>'
    + '<div><p class="text-slate-400 text-xs">Stage</p><p>' + badge(j.stage) + '</p></div>'
    + '<div><p class="text-slate-400 text-xs">Priority</p><p>' + badge(j.priority) + '</p></div>'
    + '<div><p class="text-slate-400 text-xs">Site</p><p>' + esc(j.site_address || '—') + '</p></div>'
    + '<div><p class="text-slate-400 text-xs">Scheduled</p><p>' + (j.scheduled_date || '—') + '</p></div>'
    + '</div>'
    + '<h4 class="font-bold text-sm text-slate-700 mb-3">Stage history</h4>'
    + stageHistoryHtml(d.history);
  if (d.checklist) {
    html += '<p class="text-xs mb-2"><span class="font-semibold">Installation checklist:</span> ' + d.checklist.progress + '% complete</p>';
    html += stagePlanHtml(d);
    html += installationPhotosHtml(d.installation_photos || []);
  }
  if (d.maintenance) html += d.maintenance.sections ? maintenanceReviewHtml(d) : '<p class="text-xs mb-2"><span class="font-semibold">Maintenance inspection:</span> ' + badge(d.maintenance.status) + '</p>';
  // The technician's work report, in full.
  html += workReportCardHtml(d.work_report);
  // The client's sign-off.
  if (d.confirmation) {
    const c = d.confirmation;
    html += '<div class="mt-3 border border-emerald-200 bg-emerald-50 rounded-xl p-3 text-xs">'
      + '<p class="font-semibold text-emerald-800"><i class="fas fa-signature mr-1"></i>Signed by ' + esc(c.signer_name)
      + (c.method === 'ON_SITE' ? ' (on site)' : ' (client portal)') + ' · ' + esc(c.created_at) + '</p>'
      + (c.rating ? '<p class="text-amber-500 text-base">' + '★'.repeat(Number(c.rating)) + '<span class="text-slate-300">' + '★'.repeat(5 - Number(c.rating)) + '</span></p>' : '')
      + (c.comment ? '<p class="text-slate-600 mt-1">“' + esc(c.comment) + '”</p>' : '')
      + '<img src="' + esc(c.signature_url) + '" alt="signature" class="mt-2 bg-white rounded border border-slate-200 max-h-24">'
      + '</div>';
  } else if (j.stage === 'COMPLETED') {
    html += '<p class="text-xs text-slate-400 mt-3"><i class="fas fa-hourglass-half mr-1"></i>Waiting for the client to sign off.</p>';
  }
  openInfoModal('Job ' + j.job_code, html);
}

/* ---------------- Project details (Projects tab: click a row) ---------------- */
// Everything about one project in one window: project, client, solar system,
// crew, jobs, installation stages and photos, maintenance, billing, warehouse
// orders, service requests and work reports (api/projects/detail.php).
async function viewProject(id) {
  setModalWide(true);
  openInfoModal('Project', '<p class="text-sm text-slate-400 py-6 text-center"><i class="fas fa-spinner fa-spin mr-1"></i>Loading project...</p>');
  const json = await apiGet('projects/detail.php', { id });
  if (!json.success) { document.getElementById('modal-body').innerHTML = '<p class="text-red-500 text-sm">' + esc(json.message) + '</p>'; return; }
  const d = json.data, p = d.project, c = d.client, s = d.system, b = d.billing, inst = d.installation, m = d.maintenance;
  const dash = v => (v === null || v === undefined || v === '') ? '<span class="text-slate-300">—</span>' : esc(v);
  const row = (k, v) => '<div class="flex justify-between gap-3 py-1.5 border-b border-slate-50 last:border-0"><span class="text-xs text-slate-400 shrink-0">' + k + '</span><span class="text-sm text-right text-slate-800 min-w-0 break-words">' + v + '</span></div>';
  const card = (title, icon, inner, extra) => '<div class="border border-slate-200 rounded-xl p-4 ' + (extra || '') + '">'
    + '<p class="text-xs font-bold uppercase text-slate-500 mb-2"><i class="fas ' + icon + ' text-solar mr-1"></i>' + title + '</p>' + inner + '</div>';
  const empty = t => '<p class="text-xs text-slate-400">' + t + '</p>';
  const when = v => v ? esc(String(v).slice(0, 16)) : '—';
  const pct = Math.max(0, Math.min(100, Number(p.progress) || 0));

  // ---- Header -------------------------------------------------------------------
  let html = '<div class="flex items-start justify-between gap-3 flex-wrap mb-4">'
    + '<div class="min-w-0"><p class="text-xl font-extrabold text-slate-900">' + esc(p.site_name || p.project_code) + '</p>'
    + '<p class="text-sm text-slate-500">' + esc(p.project_code) + (p.address ? ' · ' + esc(p.address) : '') + '</p></div>'
    + '<div class="flex items-center gap-2 flex-wrap">' + badge(p.status)
    + (d.can_manage ? '<button class="text-xs font-bold px-3 py-1.5 rounded-lg border border-slate-200 hover:border-solar hover:text-solar" onclick="closeModal();setTimeout(()=>openEntityModal(\'projects\',' + p.id + '),60)"><i class="fas fa-pen mr-1"></i>Edit</button>' : '')
    + '</div></div>'
    + '<div class="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">'
    + [['Capacity', p.capacity_kw ? esc(p.capacity_kw) + ' kW' : '—'], ['Site size', dash(p.site_size ? p.site_size.charAt(0) + p.site_size.slice(1).toLowerCase() : '')],
       ['Install date', dash(p.installation_date)], ['System type', dash(p.system_type)]]
        .map(x => '<div class="bg-slate-50 rounded-xl px-3 py-2"><p class="text-[11px] font-bold uppercase text-slate-400">' + x[0] + '</p><p class="text-sm font-bold text-slate-800">' + x[1] + '</p></div>').join('')
    + '</div>'
    + '<div class="mb-4"><div class="flex justify-between text-xs mb-1"><span class="font-semibold text-slate-500">Progress</span><span class="font-bold text-slate-800">' + pct + '%</span></div>'
    + '<div class="w-full bg-slate-100 rounded-full h-2"><div class="bg-solar h-2 rounded-full" style="width:' + pct + '%"></div></div></div>'
    + (p.notes ? '<p class="text-xs text-slate-600 bg-slate-50 rounded-lg px-3 py-2 mb-4"><i class="fas fa-note-sticky text-slate-300 mr-1"></i>' + esc(p.notes) + '</p>' : '');

  // ---- Client + solar system -------------------------------------------------------
  const mapLink = c.lat !== null && c.lng !== null ? ' <a class="text-sky-600 font-semibold" target="_blank" rel="noopener" href="https://www.google.com/maps?q=' + c.lat + ',' + c.lng + '"><i class="fas fa-map-location-dot"></i> Map</a>' : '';
  html += '<div class="grid md:grid-cols-2 gap-3 mb-3">'
    + card('Client', 'fa-user', row('Name', '<b>' + esc(c.name) + '</b> <span class="text-slate-400">' + esc(c.client_code) + '</span>')
        + row('Phone', c.phone ? '<a class="text-solar font-semibold" href="tel:' + esc(c.phone) + '">' + esc(c.phone) + '</a>' : dash(''))
        + row('Email', c.email ? '<a class="text-solar" href="mailto:' + esc(c.email) + '">' + esc(c.email) + '</a>' : dash(''))
        + row('Address', dash(c.address) + mapLink)
        + row('Portal account', badge(c.account_status) + (c.last_login ? ' <span class="text-[11px] text-slate-400">last login ' + when(c.last_login) + '</span>' : ''))
        + row('Client since', dash(c.registered)))
    + card('Solar system', 'fa-solar-panel', s
        ? row('System', '<b>' + esc(s.system_code) + '</b> ' + badge(s.status)) + row('Capacity', s.capacity_kw ? esc(s.capacity_kw) + ' kW' : dash(''))
          + row('Panels', dash(s.panel_brand)) + row('Inverter', dash(s.inverter_brand)) + row('Battery', dash(s.battery_brand))
          + row('Installed', dash(s.installation_date)) + row('Warranty', dash(s.warranty_info))
        : empty('No solar system recorded yet.'))
    + '</div>';

  // ---- Crew + billing ----------------------------------------------------------------
  html += '<div class="grid md:grid-cols-2 gap-3 mb-3">'
    + card('Crew', 'fa-users', d.crew.length ? d.crew.map(t => '<div class="flex items-center justify-between gap-2 py-1.5 border-b border-slate-50 last:border-0">'
          + '<span class="text-sm"><b>' + esc(t.name) + '</b> <span class="text-xs text-slate-400">' + esc(t.code) + '</span>' + (t.is_lead ? ' <span class="badge bg-orange-100 text-orange-700">Lead</span>' : '') + '</span>'
          + (t.phone ? '<a class="text-xs text-solar font-semibold whitespace-nowrap shrink-0" href="tel:' + esc(t.phone) + '">' + esc(t.phone) + '</a>' : '') + '</div>').join('')
        : empty('No technician assigned yet.'))
    + card('Billing' + (b.scope === 'client' && b.invoices.length ? ' <span class="normal-case font-normal text-slate-400">(client\'s invoices)</span>' : ''), 'fa-file-invoice-dollar',
        '<div class="grid grid-cols-3 gap-2 mb-2">'
        + [['Billed', b.billed, 'text-slate-800'], ['Paid', b.paid, 'text-emerald-600'], ['Balance', b.balance, b.balance > 0 ? 'text-red-600' : 'text-slate-800']]
            .map(x => '<div class="bg-slate-50 rounded-lg px-2 py-1.5"><p class="text-[10px] font-bold uppercase text-slate-400">' + x[0] + '</p><p class="text-sm font-extrabold ' + x[2] + '">' + peso(x[1]) + '</p></div>').join('')
        + '</div>'
        + (b.invoices.length ? b.invoices.slice(0, 6).map(i => '<div class="flex items-center justify-between gap-2 py-1 text-xs border-b border-slate-50 last:border-0">'
            + '<span><b>' + esc(i.invoice_code) + '</b> ' + badge(i.payment_status) + (i.overdue ? ' <b class="text-red-600">overdue</b>' : '') + '</span>'
            + '<span class="text-right">' + peso(i.amount) + (i.balance > 0 ? '<span class="block text-red-600">' + peso(i.balance) + ' due</span>' : '') + '</span></div>').join('')
          : empty('No invoices yet.')))
    + '</div>';

  // ---- Jobs ----------------------------------------------------------------------------
  html += card('Jobs (' + d.jobs.length + ')', 'fa-briefcase', d.jobs.length
      ? '<div class="divide-y divide-slate-50">' + d.jobs.map(j => '<button type="button" class="w-full text-left flex items-center justify-between gap-3 py-2 hover:bg-slate-50 rounded-lg px-1" onclick="viewJobDetail(' + j.id + ')">'
          + '<span class="min-w-0"><b class="text-sm">' + esc(j.job_code) + '</b> <span class="text-xs text-slate-400">' + esc(j.job_type) + '</span>'
          + '<span class="block text-[11px] text-slate-500">' + (j.technician_name ? esc(j.technician_name) : 'Unassigned') + ' · ' + (j.scheduled_date ? esc(j.scheduled_date) : 'not scheduled') + (j.report_code ? ' · report ' + esc(j.report_code) : '') + '</span></span>'
          + '<span class="flex items-center gap-2 shrink-0"><span class="text-[11px] text-slate-400">' + (j.progress || 0) + '%</span>' + badge(j.stage) + '<i class="fas fa-chevron-right text-slate-300 text-xs"></i></span></button>').join('') + '</div>'
      : empty('No jobs for this project yet.'), 'mb-3');

  // ---- Installation stages + photos -------------------------------------------------------
  if (inst) {
    const look = { APPROVED: 'bg-emerald-500 text-white', SUBMITTED: 'bg-sky-500 text-white', RETURNED: 'bg-red-500 text-white', SCHEDULED: 'bg-solar text-white' };
    html += card('Installation · ' + esc(inst.job_code), 'fa-screwdriver-wrench',
      (inst.plan.length ? '<div class="flex items-start gap-1 mb-3">' + inst.plan.map((st, i) => '<div class="flex-1 min-w-0 text-center">'
          + '<span class="mx-auto w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-extrabold ' + (look[st.status] || 'bg-slate-200 text-slate-500') + '">'
          + (st.status === 'APPROVED' ? '<i class="fas fa-check"></i>' : i + 1) + '</span>'
          + '<p class="mt-1 text-[11px] font-bold text-slate-700 truncate">' + esc(st.stage) + '</p>'
          + '<p class="text-[10px] text-slate-400 truncate">' + esc(st.status.charAt(0) + st.status.slice(1).toLowerCase()) + '</p></div>').join('') + '</div>' : '')
      + (inst.summary ? '<p class="text-xs text-slate-500 mb-2">' + esc(inst.summary.label) + ' · checklist ' + inst.progress + '%</p>' : '')
      + (inst.photos.length ? '<div class="grid grid-cols-5 sm:grid-cols-8 gap-1.5">' + inst.photos.map(ph => '<a href="' + esc(ph.url) + '" target="_blank" rel="noopener" title="' + esc(ph.stage) + '">'
          + '<img src="' + esc(ph.url) + '" alt="" loading="lazy" class="w-full aspect-square object-cover rounded-lg border border-slate-200 hover:opacity-90"></a>').join('') + '</div>'
        : empty('No installation photos yet.')), 'mb-3');
  }

  // ---- Maintenance -------------------------------------------------------------------------
  const sch = m.schedule;
  const cond = v => v ? '<span class="' + ({ Good: 'text-emerald-600', Fair: 'text-amber-600', Poor: 'text-red-600' }[v] || '') + ' font-semibold">' + esc(v) + '</span>' : '<span class="text-slate-300">—</span>';
  html += card('Maintenance', 'fa-wrench',
    (sch ? '<div class="grid grid-cols-3 gap-2 mb-2">'
        + [['Last visit', dash(sch.last_maintenance)], ['Next visit', dash(sch.next_maintenance)], ['Status', badge(sch.status)]]
            .map(x => '<div class="bg-slate-50 rounded-lg px-2 py-1.5"><p class="text-[10px] font-bold uppercase text-slate-400">' + x[0] + '</p><p class="text-sm font-bold">' + x[1] + '</p></div>').join('') + '</div>'
      : empty('No maintenance schedule yet — it starts when the installation is completed.'))
    + (m.visits.length ? m.visits.map(v => '<button type="button" class="w-full text-left flex items-center justify-between gap-2 py-1.5 text-xs border-b border-slate-50 last:border-0 hover:bg-slate-50 rounded px-1" onclick="viewJobDetail(' + v.job_id + ')">'
        + '<span><b>' + esc(v.job_code) + '</b> · ' + (v.technician_name ? esc(v.technician_name) : 'Unassigned') + (v.completion_date ? ' · ' + esc(String(v.completion_date).slice(0, 10)) : '')
        + '<span class="block text-slate-400">Panels ' + cond(v.panel_condition) + ' · Battery ' + cond(v.battery_condition) + ' · Inverter ' + cond(v.inverter_condition) + (v.issues_found ? ' · ' + esc(v.issues_found) : '') + '</span></span>'
        + badge(v.stage) + '</button>').join('') : ''), 'mb-3');

  // ---- Warehouse orders, service requests, work reports ------------------------------------
  html += '<div class="grid md:grid-cols-3 gap-3">'
    + card('Warehouse orders', 'fa-dolly', d.materials.length ? d.materials.map(x => '<div class="flex items-center justify-between gap-2 py-1 text-xs border-b border-slate-50 last:border-0">'
        + '<span><b>' + esc(x.request_code) + '</b>' + (x.needed_by ? '<span class="block text-slate-400">needed by ' + esc(x.needed_by) + '</span>' : '') + '</span>' + badge(x.status) + '</div>').join('') : empty('None.'))
    + card('Service requests', 'fa-ticket', d.requests.length ? d.requests.map(x => '<div class="flex items-center justify-between gap-2 py-1 text-xs border-b border-slate-50 last:border-0">'
        + '<span class="min-w-0"><b>' + esc(x.request_code) + '</b><span class="block text-slate-500 truncate">' + esc(x.subject || x.request_type || '') + '</span></span>' + badge(x.status) + '</div>').join('') : empty('None.'))
    + card('Work reports', 'fa-file-lines', d.reports.length ? d.reports.map(x => '<div class="py-1 text-xs border-b border-slate-50 last:border-0">'
        + '<b>' + esc(x.report_code) + '</b> <span class="text-slate-400">' + esc(x.job_code) + '</span>'
        + '<span class="block text-slate-500">' + esc(x.technician_name || '') + (x.submitted_date ? ' · ' + esc(String(x.submitted_date).slice(0, 10)) : '') + '</span>'
        + (x.remarks ? '<span class="block text-slate-600 truncate">' + esc(x.remarks) + '</span>' : '') + '</div>').join('') : empty('None.'))
    + '</div>';

  document.getElementById('modal-title').textContent = p.project_code + ' — ' + (c.name || '');
  document.getElementById('modal-body').innerHTML = html;
}

/* ---------------- Installation ---------------- */
async function loadInstallation() {
  const tbody = document.getElementById('inst-tbody');
  tbody.innerHTML = '<tr><td colspan="7" class="text-center text-slate-400 py-6">Loading...</td></tr>';
  const params = filterParams({ search: 'inst-search', status: 'inst-status', date_from: 'inst-from', date_to: 'inst-to' });
  const json = await apiGet('installation/list.php', params);
  if (!json.success) { tbody.innerHTML = '<tr><td colspan="7" class="text-red-500 text-center py-6">' + esc(json.message) + '</td></tr>'; barCount('inst'); return; }
  const rows = json.data;
  barCount('inst', rows.length);
  // How many stages wait for a decision (across the rows shown).
  const waiting = rows.filter(r => r.plan && r.plan.status === 'SUBMITTED');
  const banner = document.getElementById('inst-review-banner');
  banner.classList.toggle('hidden', !waiting.length);
  banner.innerHTML = waiting.length
    ? '<div class="flex items-center gap-3 rounded-xl border border-sky-200 bg-sky-50 px-4 py-3 text-sm text-sky-800">'
      + '<i class="fas fa-hourglass-half"></i><span><b>' + waiting.length + ' stage' + (waiting.length === 1 ? '' : 's') + ' waiting for your review.</b> Approve to schedule the next visit, or return with a note.</span>'
      + '<button class="ml-auto bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg" onclick="viewJobDetail(' + waiting[0].job_id + ')">Review next</button></div>'
    : '';
  if (!rows.length) { tbody.innerHTML = '<tr><td colspan="7" class="text-center text-slate-400 py-6">No installation jobs match. Try fewer words or press Clear.</td></tr>'; return; }
  tbody.innerHTML = rows.map(r =>
    '<tr class="cursor-pointer hover:bg-slate-50" onclick="viewJobDetail(' + r.job_id + ')">'
    + '<td class="font-semibold">' + esc(r.job_code) + '</td>'
    + '<td>' + esc(r.site_name || r.site_address || '—') + '</td>'
    + '<td>' + esc(r.client_name) + '</td>'
    + '<td>' + (r.technician_name ? esc(r.technician_name) : '<span class="text-amber-600">Unassigned</span>') + '</td>'
    + '<td>' + planStepCell(r.plan) + '</td>'
    + '<td><div class="w-24 bg-slate-100 rounded-full h-2"><div class="bg-solar h-2 rounded-full" style="width:' + (r.checklist_progress || 0) + '%"></div></div>'
    +   '<span class="text-[11px] text-slate-400">' + (r.plan ? r.plan.approved + '/' + r.plan.total + ' stages approved' : (r.items_done || 0) + ' / ' + (r.items_total || 0) + ' items') + '</span></td>'
    + '<td>' + badge(r.stage) + '</td>'
    + '</tr>'
  ).join('');
}

/* ---------------- Maintenance ---------------- */
let MNT_CACHE = [];
async function loadMaintenance() {
  const tbody = document.getElementById('mnt-tbody');
  tbody.innerHTML = '<tr><td colspan="7" class="text-center text-slate-400 py-6">Loading...</td></tr>';
  const params = filterParams({ search: 'mnt-search', status: 'mnt-status', date_from: 'mnt-from', date_to: 'mnt-to' });
  const json = await apiGet('maintenance/list.php', params);
  if (!json.success) { tbody.innerHTML = '<tr><td colspan="7" class="text-red-500 text-center py-6">' + esc(json.message) + '</td></tr>'; barCount('mnt'); return; }
  const rows = json.data.rows;
  MNT_CACHE = rows;
  // Maintenance inspections waiting for a decision (same banner as Installation).
  const waiting = json.data.pending_reviews || [];
  const mBanner = document.getElementById('mnt-review-banner');
  mBanner.classList.toggle('hidden', !waiting.length);
  mBanner.innerHTML = waiting.length
    ? '<div class="flex items-center gap-3 rounded-xl border border-sky-200 bg-sky-50 px-4 py-3 text-sm text-sky-800">'
      + '<i class="fas fa-hourglass-half"></i><span><b>' + waiting.length + ' maintenance inspection' + (waiting.length === 1 ? '' : 's') + ' waiting for your review.</b> Check the photos, then approve or return with a note.</span>'
      + '<button class="ml-auto shrink-0 bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg" onclick="viewJobDetail(' + waiting[0].job_id + ')">Review next</button></div>'
    : '';
  barCount('mnt', rows.length);
  if (!rows.length) { tbody.innerHTML = '<tr><td colspan="7" class="text-center text-slate-400 py-6">No maintenance schedules match. Try fewer words or press Clear.</td></tr>'; return; }
  tbody.innerHTML = rows.map(r =>
    '<tr>'
    + '<td class="font-semibold">' + esc(r.project_code) + '<span class="text-slate-400 text-xs block">' + esc(r.site_name) + '</span></td>'
    + '<td>' + esc(r.client_name) + '</td>'
    + '<td>' + (r.last_maintenance || '—') + '</td>'
    + '<td>' + (r.next_maintenance || '—') + '</td>'
    + '<td>' + badge(r.status) + '</td>'
    + '<td>' + (Number(r.client_notified) ? '<i class="fas fa-check text-emerald-500"></i>' : '<span class="text-slate-300">—</span>') + '</td>'
    + '<td class="whitespace-nowrap space-x-1">'
    +   '<button class="link-btn text-solar" onclick="openRescheduleModal(' + r.id + ')">Reschedule</button>'
    +   '<button class="link-btn text-sky-600" onclick="openMaintAssignModal(' + r.id + ')">Assign</button>'
    +   '<button class="link-btn text-slate-500" onclick="notifyClient(' + r.id + ')">Notify</button>'
    + '</td>'
    + '</tr>'
  ).join('');
}
function openScheduleMaintenanceModal() {
  const html = '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Project</label>'
    + '<select id="f-project" class="w-full border rounded-lg px-3 py-2 text-sm"><option value="">— Select —</option>' + SELECT_OPTIONS.projects.map(o => '<option value="' + o.id + '">' + esc(o.label) + '</option>').join('') + '</select>'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Next maintenance date</label>'
    + '<input id="f-date" type="date" class="w-full border rounded-lg px-3 py-2 text-sm">';
  openModal('Schedule Maintenance', html, async () => {
    const projectId = document.getElementById('f-project').value;
    const date = document.getElementById('f-date').value;
    if (!projectId || !date) { toast('Select a project and a date.', true); return false; }
    const json = await apiPost('maintenance/schedule.php', { project_id: Number(projectId), action: 'SCHEDULE', next_maintenance: date });
    if (!json.success) { toast(json.message, true); return false; }
    toast(json.message, false);
    loadMaintenance();
    return true;
  });
}
function openRescheduleModal(scheduleId) {
  const row = MNT_CACHE.find(r => String(r.id) === String(scheduleId));
  if (!row) return;
  const html = '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">New date</label>'
    + '<input id="f-date" type="date" value="' + (row.next_maintenance || '') + '" class="w-full border rounded-lg px-3 py-2 text-sm">';
  openModal('Reschedule — ' + row.project_code, html, async () => {
    const date = document.getElementById('f-date').value;
    if (!date) { toast('Select a date.', true); return false; }
    const json = await apiPost('maintenance/schedule.php', { project_id: row.project_id, action: 'RESCHEDULE', next_maintenance: date });
    if (!json.success) { toast(json.message, true); return false; }
    toast(json.message, false);
    loadMaintenance();
    return true;
  });
}
function openMaintAssignModal(scheduleId) {
  const row = MNT_CACHE.find(r => String(r.id) === String(scheduleId));
  if (!row) return;
  const html = '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Technician</label>'
    + '<select id="f-tech" class="w-full border rounded-lg px-3 py-2 text-sm">' + techOptionsHtml() + '</select>';
  openModal('Assign Technician — ' + row.project_code, html, async () => {
    const techId = document.getElementById('f-tech').value;
    if (!techId) { toast('Select a technician.', true); return false; }
    const json = await apiPost('maintenance/schedule.php', { project_id: row.project_id, action: 'ASSIGN', technician_id: Number(techId) });
    if (!json.success) { toast(json.message, true); return false; }
    toast(json.message, false);
    loadMaintenance();
    return true;
  });
}
async function notifyClient(scheduleId) {
  const row = MNT_CACHE.find(r => String(r.id) === String(scheduleId));
  if (!row) return;
  if (!confirm('Notify the client about maintenance for ' + row.project_code + '?')) return;
  const json = await apiPost('maintenance/schedule.php', { project_id: row.project_id, action: 'NOTIFY' });
  if (!json.success) { toast(json.message, true); return; }
  toast(json.message, false);
  loadMaintenance();
}

/* ---------------- Material Requests (client orders for the warehouse) ---------------- */
const MR_BADGE = {
  PENDING: 'bg-amber-100 text-amber-700', PREPARING: 'bg-sky-100 text-sky-700', READY: 'bg-emerald-100 text-emerald-700',
  RELEASED: 'bg-violet-100 text-violet-700', CANCELLED: 'bg-red-100 text-red-700',
};
function mrBadge(s) { return '<span class="badge ' + (MR_BADGE[s] || 'bg-slate-100 text-slate-600') + '">' + esc(s) + '</span>'; }
/** "4 / 10" for one category, green once complete, a dash when not ordered. */
function mrLineCell(lines, category) {
  const l = (lines || []).find(x => x.category_name === category);
  if (!l) return '<span class="text-slate-300">—</span>';
  const req = Number(l.qty_required), prep = Math.min(Number(l.qty_prepared), req);
  return '<span class="' + (prep >= req ? 'text-emerald-600 font-bold' : '') + '">' + prep + ' / ' + req + '</span>';
}

let MR_CACHE = [];
async function loadMaterialRequests() {
  const tbody = document.getElementById('mr-tbody');
  tbody.innerHTML = '<tr><td colspan="9" class="text-center text-slate-400 py-6">Loading...</td></tr>';
  const params = filterParams({ status: 'mr-status', search: 'mr-search', date_from: 'mr-from', date_to: 'mr-to' });
  const json = await apiGet('material_requests/list.php', params);
  if (!json.success) { tbody.innerHTML = '<tr><td colspan="9" class="text-red-500 text-center py-6">' + esc(json.message) + '</td></tr>'; barCount('mr'); return; }
  MR_CACHE = json.data.rows;
  barCount('mr', MR_CACHE.length);
  if (!MR_CACHE.length) { tbody.innerHTML = '<tr><td colspan="9" class="text-center text-slate-400 py-6">No material requests match. Try fewer words or press Clear.</td></tr>'; return; }
  const today = new Date().toISOString().slice(0, 10);
  tbody.innerHTML = MR_CACHE.map(r => {
    const open = ['PENDING', 'PREPARING', 'READY'].indexOf(r.status) !== -1;
    const overdue = open && r.needed_by && r.needed_by < today;
    let actions = '<button class="link-btn text-solar" onclick="viewMR(' + r.id + ')">View</button>';
    if (open && Number(r.qty_prepared) === 0) actions += ' <button class="link-btn text-red-500 ml-2" onclick="cancelMR(' + r.id + ')">Cancel</button>';
    return '<tr>'
      + '<td class="font-semibold cursor-pointer text-solar" onclick="viewMR(' + r.id + ')">' + esc(r.request_code) + '</td>'
      + '<td>' + esc(r.client_name) + '<span class="block text-xs text-slate-400">' + esc(r.client_code) + '</span></td>'
      + '<td class="text-xs">' + (esc([r.project_code, r.job_code].filter(Boolean).join(' · ')) || '<span class="text-slate-300">—</span>') + '</td>'
      + '<td>' + mrLineCell(r.lines, 'Solar Panel') + '</td>'
      + '<td>' + mrLineCell(r.lines, 'Inverter') + '</td>'
      + '<td>' + mrLineCell(r.lines, 'Battery') + '</td>'
      + '<td>' + mrBadge(r.status) + '</td>'
      + '<td class="text-xs ' + (overdue ? 'text-red-600 font-bold' : 'text-slate-500') + '">' + (r.needed_by ? esc(r.needed_by) + (overdue ? ' (overdue)' : '') : '—') + '</td>'
      + '<td class="whitespace-nowrap">' + actions + '</td>'
      + '</tr>';
  }).join('');
}

function openCreateMRModal(clientId) {
  const num = (id, label) => '<div><label class="block text-xs font-semibold text-slate-500 mb-1">' + label + '</label>'
    + '<input id="' + id + '" type="number" min="0" step="1" placeholder="0" class="w-full border rounded-lg px-3 py-2 text-sm"></div>';
  const html = '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-1">Client</label>'
    + '<select id="f-mr-client" class="w-full border rounded-lg px-3 py-2 text-sm">' + clientOptionsHtml() + '</select>'
    + '<div class="grid grid-cols-2 gap-2 mt-3">'
    +   '<div><label class="block text-xs font-semibold text-slate-500 mb-1">Project (optional)</label><select id="f-mr-project" class="w-full border rounded-lg px-3 py-2 text-sm"></select></div>'
    +   '<div><label class="block text-xs font-semibold text-slate-500 mb-1">Job (optional)</label><select id="f-mr-job" class="w-full border rounded-lg px-3 py-2 text-sm"></select></div>'
    + '</div>'
    + '<p class="text-xs font-semibold text-slate-700 mt-4 mb-2">Items needed</p>'
    + '<div class="grid grid-cols-3 gap-2">' + num('f-mr-panels', 'Solar panels') + num('f-mr-inverters', 'Inverters') + num('f-mr-batteries', 'Batteries') + '</div>'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Needed by (optional)</label>'
    + '<input id="f-mr-needed" type="date" class="w-full border rounded-lg px-3 py-2 text-sm">'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Notes for the warehouse (optional)</label>'
    + '<input id="f-mr-notes" type="text" maxlength="255" placeholder="e.g. preferred brand, 450W panels" class="w-full border rounded-lg px-3 py-2 text-sm">';

  openModal('New Material Request', html, async () => {
    const client = document.getElementById('f-mr-client').value;
    if (!client) { toast('Select a client.', true); return false; }
    const payload = {
      client_id: Number(client),
      project_id: document.getElementById('f-mr-project').value || null,
      job_id: document.getElementById('f-mr-job').value || null,
      panels: document.getElementById('f-mr-panels').value,
      inverters: document.getElementById('f-mr-inverters').value,
      batteries: document.getElementById('f-mr-batteries').value,
      needed_by: document.getElementById('f-mr-needed').value,
      notes: document.getElementById('f-mr-notes').value.trim(),
    };
    if (!(Number(payload.panels) > 0 || Number(payload.inverters) > 0 || Number(payload.batteries) > 0)) {
      toast('Enter how many panels, inverters or batteries are needed.', true); return false;
    }
    const json = await apiPost('material_requests/create.php', payload);
    if (!json.success) { toast(json.message, true); return false; }
    toast(json.message, false);
    if (CURRENT_TAB === 'material-requests') loadMaterialRequests();
    return true;
  });

  // Only offer the chosen client's projects and jobs — the server rejects others.
  const clientSel = document.getElementById('f-mr-client');
  const fillLinked = () => {
    const cid = clientSel.value;
    const client = SELECT_OPTIONS.clients.find(c => String(c.id) === String(cid));
    const projects = SELECT_OPTIONS.projects.filter(p => String(p.client_id) === String(cid));
    const jobs = client ? SELECT_OPTIONS.activeJobs.filter(j => j.client_code === client.code) : [];
    document.getElementById('f-mr-project').innerHTML = '<option value="">— None —</option>' + projects.map(p => '<option value="' + p.id + '">' + esc(p.label) + '</option>').join('');
    document.getElementById('f-mr-job').innerHTML = '<option value="">— None —</option>' + jobs.map(j => '<option value="' + j.id + '">' + esc(j.label) + '</option>').join('');
  };
  clientSel.addEventListener('change', fillLinked);
  if (clientId) clientSel.value = String(clientId);
  fillLinked();
}

async function viewMR(id) {
  const json = await apiGet('material_requests/get.php', new URLSearchParams({ id: id }));
  if (!json.success) { toast(json.message, true); return; }
  const d = json.data, r = d.request;
  const row = (k, v) => '<div><p class="text-slate-400 text-xs">' + k + '</p><p class="font-semibold">' + v + '</p></div>';
  let html = '<div class="grid grid-cols-2 gap-3 text-sm mb-4">'
    + row('Client', esc(r.client_name) + ' <span class="text-slate-400 font-normal">(' + esc(r.client_code) + ')</span>')
    + row('Status', mrBadge(r.status))
    + row('Project / Job', esc([r.project_code, r.job_code].filter(Boolean).join(' · ')) || '—')
    + row('Needed by', esc(r.needed_by) || '—')
    + row('Requested by', esc(r.requested_by_name) || '—')
    + row('Requested at', esc(r.created_at))
    + (r.ready_at ? row('Ready at', esc(r.ready_at)) : '')
    + (r.status === 'RELEASED' ? row('Released', esc(r.released_at) + ' by ' + esc(r.released_by_name || '—') + (r.released_to ? ' to ' + esc(r.released_to) : '')) : '')
    + '</div>'
    + (r.notes ? '<p class="text-xs text-slate-500 mb-3"><b>Notes:</b> ' + esc(r.notes) + '</p>' : '')
    + '<h4 class="font-bold text-sm text-slate-700 mb-2">Items</h4><div class="space-y-2 mb-4">'
    + d.lines.map(l => {
        const req = Number(l.qty_required), prep = Math.min(Number(l.qty_prepared), req);
        return '<div><div class="flex justify-between text-xs mb-1"><span class="font-semibold">' + esc(l.category_name) + '</span><span>' + prep + ' / ' + req + '</span></div>'
          + '<div class="w-full bg-slate-100 rounded-full h-2"><div class="h-2 rounded-full ' + (prep >= req ? 'bg-emerald-500' : 'bg-solar') + '" style="width:' + (req ? Math.round(prep * 100 / req) : 0) + '%"></div></div></div>';
      }).join('')
    + '</div>'
    + '<h4 class="font-bold text-sm text-slate-700 mb-2">Prepared by the warehouse</h4>'
    + (d.picked.length
        ? '<table class="w-full data-table"><thead><tr><th>SKU</th><th>Item</th><th>Qty</th></tr></thead><tbody>'
          + d.picked.map(p => '<tr><td class="text-xs">' + esc(p.sku) + '</td><td>' + esc(p.item_name) + '</td><td class="font-bold">' + p.quantity + '</td></tr>').join('')
          + '</tbody></table>'
        : '<p class="text-xs text-slate-400">Nothing prepared yet.</p>');
  openInfoModal('Material Request ' + r.request_code, html);
}

async function cancelMR(id) {
  const r = MR_CACHE.find(x => String(x.id) === String(id));
  if (!confirm('Cancel ' + (r ? r.request_code : 'this request') + '? The warehouse will be told not to prepare it.')) return;
  const json = await apiPost('material_requests/cancel.php', { request_id: id });
  toast(json.message, !json.success);
  if (json.success) loadMaterialRequests();
}
// Search/filter bars: search as you type, Enter/Esc, Clear, result count.
// Clear resets each dropdown to its first option — for Material Requests that
// is "Open", the default view.
function bindFilterBars() {
  BARS.sr = SunTrackFilters.bind({ search: 'sr-search', fields: ['sr-status', 'sr-priority', 'sr-type', 'sr-tech', 'sr-from', 'sr-to'], anchor: 'sr-refresh', onChange: loadServiceRequests });
  BARS.jobs = SunTrackFilters.bind({ search: 'job-search', fields: ['job-stage', 'job-type', 'job-priority', 'job-tech', 'job-from', 'job-to', 'job-unassigned'], anchor: 'job-refresh', onChange: loadJobs });
  BARS.inst = SunTrackFilters.bind({ search: 'inst-search', fields: ['inst-status', 'inst-from', 'inst-to'], anchor: 'inst-refresh', onChange: loadInstallation });
  BARS.mnt = SunTrackFilters.bind({ search: 'mnt-search', fields: ['mnt-status', 'mnt-from', 'mnt-to'], anchor: 'mnt-refresh', onChange: loadMaintenance });
  BARS.mr = SunTrackFilters.bind({ search: 'mr-search', fields: ['mr-status', 'mr-from', 'mr-to'], anchor: 'mr-refresh', onChange: loadMaterialRequests });
  BARS.bill = SunTrackFilters.bind({ search: 'bill-search', fields: ['bill-status', 'bill-from', 'bill-to'], anchor: 'bill-refresh', onChange: loadBilling });
}

/* ---------------- Billing ---------------- */
let BILL_CACHE = [];
function peso(n) {
  return '₱' + Number(n || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
async function loadBilling() {
  const tbody = document.getElementById('bill-tbody');
  tbody.innerHTML = '<tr><td colspan="9" class="text-center text-slate-400 py-6">Loading...</td></tr>';
  const params = filterParams({ search: 'bill-search', status: 'bill-status', date_from: 'bill-from', date_to: 'bill-to' });
  const json = await apiGet('billing/list.php', params);
  if (!json.success) { tbody.innerHTML = '<tr><td colspan="9" class="text-red-500 text-center py-6">' + esc(json.message) + '</td></tr>'; barCount('bill'); return; }
  const s = json.data.stats;
  document.getElementById('bill-k-total').textContent = peso(s.total_invoiced);
  document.getElementById('bill-k-paid').textContent = peso(s.paid);
  document.getElementById('bill-k-pending').textContent = peso(s.pending);
  document.getElementById('bill-k-overdue').textContent = peso(s.overdue);
  const rows = json.data.rows;
  BILL_CACHE = rows;
  barCount('bill', rows.length);
  if (!rows.length) { tbody.innerHTML = '<tr><td colspan="9" class="text-center text-slate-400 py-6">No invoices match. Try fewer words or press Clear.</td></tr>'; return; }
  tbody.innerHTML = rows.map(r => {
    const open = r.payment_status === 'PENDING' || r.payment_status === 'OVERDUE';
    const actions = '<a class="icon-btn" title="View / PDF" target="_blank" rel="noopener" href="../invoice.php?id=' + r.id + '"><i class="fas fa-file-pdf"></i></a>'
      + (open
        ? '<button class="icon-btn text-emerald-600" title="Record payment" onclick="openPaymentModal(' + r.id + ')"><i class="fas fa-hand-holding-dollar"></i></button>'
          + '<button class="icon-btn" title="Edit" onclick="openInvoiceModal(' + r.id + ')"><i class="fas fa-pen"></i></button>'
          + '<button class="icon-btn text-red-500" title="Cancel invoice" onclick="cancelInvoice(' + r.id + ')"><i class="fas fa-ban"></i></button>'
        : '');
    // Click anywhere on the row (except the action buttons) to see the whole invoice.
    return '<tr class="cursor-pointer hover:bg-orange-50/40" onclick="if (!event.target.closest(\'a,button\')) viewInvoiceDetail(' + r.id + ')">'
      + '<td class="font-semibold">' + esc(r.invoice_code) + '</td>'
      + '<td><span class="font-semibold text-slate-800 hover:text-solar hover:underline">' + esc(r.client_name) + '</span></td>'
      + '<td>' + (r.project_code ? esc(r.project_code) : '<span class="text-slate-300">—</span>')
      +   (r.material_request_code ? '<span class="block text-[11px] text-sky-700 font-semibold" title="Created automatically when the warehouse released this request"><i class="fas fa-dolly mr-1"></i>Materials · ' + esc(r.material_request_code) + '</span>' : '')
      + '</td>'
      + '<td>' + peso(r.amount) + '</td>'
      + '<td class="text-emerald-600">' + peso(r.amount_paid) + '</td>'
      + '<td class="font-semibold">' + peso(r.balance) + '</td>'
      + '<td class="text-xs">' + esc(r.due_date || '—') + '</td>'
      + '<td>' + badge(r.payment_status) + '</td>'
      + '<td class="whitespace-nowrap">' + actions + '</td>'
      + '</tr>';
  }).join('');
}
// Everything about one invoice: client, project, line items, payments, totals.
async function viewInvoiceDetail(id) {
  const json = await apiGet('billing/detail.php', new URLSearchParams({ id }));
  if (!json.success) { toast(json.message, true); return; }
  const d = json.data, i = d.invoice;
  const dash = '<span class="text-slate-300">—</span>';
  const date = v => v ? esc(new Date(String(v).slice(0, 10) + 'T00:00').toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' })) : dash;
  const row = (label, value) => '<div class="grid grid-cols-[96px_1fr] gap-3 py-2 border-t border-slate-100 first:border-t-0">'
    + '<span class="text-xs font-semibold text-slate-400">' + label + '</span><span class="text-sm text-slate-800 min-w-0 break-words">' + value + '</span></div>';
  const card = (icon, title, body) => '<div class="bg-white border border-slate-200 rounded-xl p-4">'
    + '<p class="text-[11px] font-bold text-slate-400 uppercase tracking-wide mb-1"><i class="fas ' + icon + ' text-solar mr-1.5"></i>' + title + '</p>' + body + '</div>';
  const section = (title, body) => '<div class="mt-5"><p class="text-[11px] font-bold text-slate-400 uppercase tracking-wide mb-2">' + title + '</p>' + body + '</div>';
  const open = i.payment_status === 'PENDING' || i.payment_status === 'OVERDUE';
  const addr = [i.address, i.city, i.province].filter(Boolean).join(', ');

  const clientCard = card('fa-user', 'Bill to',
    '<div class="py-2"><p class="font-bold text-slate-900 leading-tight">' + esc(i.client_name) + '</p><p class="text-xs text-slate-400">' + esc(i.client_code) + '</p></div>'
    + row('Phone', i.client_phone ? '<a class="hover:text-solar" href="tel:' + esc(i.client_phone) + '">' + esc(i.client_phone) + '</a>' : dash)
    + row('Email', i.client_email ? '<span class="break-all">' + esc(i.client_email) + '</span>' : dash)
    + row('Address', addr ? esc(addr) : dash));

  const invCard = card('fa-file-invoice-dollar', 'Invoice',
    '<div class="py-2"><p class="font-bold text-slate-900 leading-tight">' + esc(i.invoice_code) + '</p>'
    + '<p class="text-xs text-slate-400">' + (i.project_code ? esc(i.project_code) + (i.site_name ? ' · ' + esc(i.site_name) : '') : 'No project') + '</p></div>'
    + (i.material_request_code ? row('Source', '<span class="text-sky-700 font-semibold"><i class="fas fa-dolly mr-1"></i>Materials · ' + esc(i.material_request_code) + '</span><br><span class="text-[11px] text-slate-400">Created when the warehouse released it</span>') : '')
    + (i.job ? row('Job order', esc(i.job.job_code) + ' <span class="text-[11px] text-slate-400">' + esc(String(i.job.job_type || '').toLowerCase()) + ' · ' + esc(String(i.job.stage || '').toLowerCase().replace(/_/g, ' ')) + '</span>') : '')
    + row('Issued', date(i.created_at))
    + row('Due', date(i.due_date))
    + (i.payment_date ? row('Paid on', date(i.payment_date)) : '')
    + (i.capacity_kw ? row('System', esc(Number(i.capacity_kw) + ' kW' + (i.system_type ? ' · ' + i.system_type : ''))) : ''));

  const lines = d.lines || [];
  const linesTable = lines.length
    ? '<div class="overflow-x-auto border border-slate-200 rounded-xl"><table class="w-full text-sm">'
      + '<thead><tr class="bg-slate-50 text-[11px] uppercase text-slate-400">'
      +   '<th class="text-left font-bold px-3 py-2">Item</th><th class="text-right font-bold px-3 py-2">Qty</th>'
      +   '<th class="text-right font-bold px-3 py-2">Unit price</th><th class="text-right font-bold px-3 py-2">Amount</th></tr></thead><tbody>'
      + lines.map(l => '<tr class="border-t border-slate-100 align-top">'
          + '<td class="px-3 py-2"><span class="font-semibold text-slate-800">' + esc(l.item_name) + '</span>'
          +   '<span class="block text-[11px] text-slate-400">' + esc([l.category, l.sku, l.model].filter(Boolean).join(' · ')) + '</span></td>'
          + '<td class="px-3 py-2 text-right tabular-nums">' + Number(l.quantity) + '</td>'
          + '<td class="px-3 py-2 text-right tabular-nums whitespace-nowrap">' + peso(l.unit_price) + '</td>'
          + '<td class="px-3 py-2 text-right tabular-nums whitespace-nowrap font-semibold">' + peso(l.line_total) + '</td></tr>').join('')
      + '<tr class="border-t-2 border-slate-200"><td colspan="3" class="px-3 py-2 text-right font-bold text-slate-700">'
      +   (d.lines_source === 'invoice' ? 'Total' : 'Materials total') + '</td>'
      +   '<td class="px-3 py-2 text-right font-extrabold whitespace-nowrap">' + peso(d.lines_total) + '</td></tr>'
      + '</tbody></table></div>'
      + (d.lines_source === 'project' ? '<p class="text-[11px] text-slate-400 mt-1">Materials installed for this project, shown for reference. The invoice amount was entered separately.</p>' : '')
    : '<p class="text-sm text-slate-400">' + esc(i.notes || 'No line items — a single amount was invoiced.') + '</p>';

  // Voided payments stay listed (crossed out, with who and why) — corrections never erase history.
  const payments = d.payments.length
    ? '<div class="border border-slate-200 rounded-xl divide-y divide-slate-100">' + d.payments.map(p => {
        const voided = !!p.voided_at;
        return '<div class="flex items-center justify-between gap-3 px-3 py-2.5 text-sm' + (voided ? ' bg-slate-50' : '') + '">'
        + '<span class="min-w-0"><span class="font-semibold ' + (voided ? 'text-slate-400 line-through' : 'text-slate-800') + '">' + date(p.paid_at) + '</span>'
        +   (voided ? ' <span class="text-[10px] font-bold uppercase bg-slate-200 text-slate-600 rounded px-1.5 py-0.5 ml-1">Voided</span>' : '')
        +   '<span class="block text-[11px] text-slate-400">' + esc([p.payment_method, p.reference, p.recorded_by_name ? 'by ' + p.recorded_by_name : ''].filter(Boolean).join(' · ')) + '</span>'
        +   (voided ? '<span class="block text-[11px] text-slate-500">Voided ' + date(p.voided_at) + (p.voided_by_name ? ' by ' + esc(p.voided_by_name) : '') + ' — ' + esc(p.void_reason) + '</span>' : '')
        + '</span>'
        + '<span class="flex items-center gap-2 shrink-0"><span class="font-bold whitespace-nowrap ' + (voided ? 'text-slate-400 line-through' : 'text-emerald-600') + '">' + peso(p.amount) + '</span>'
        +   (!voided && d.can_void ? '<button class="text-[11px] font-bold text-red-600 bg-red-50 hover:bg-red-100 rounded-lg px-2 py-1" onclick="voidPayment(' + p.id + ',' + i.id + ',\'' + esc(peso(p.amount)) + '\')">Void</button>' : '')
        + '</span></div>';
      }).join('') + '</div>'
      + (d.can_void ? '<p class="text-[11px] text-slate-400 mt-1">Recorded a payment by mistake? Void it — it stays in the history but stops counting as paid. Then record the correct one.</p>' : '')
    : '<p class="text-sm text-slate-400">No payments recorded yet.</p>';

  const totals = '<div class="grid grid-cols-3 gap-2">'
    + [['Amount', peso(i.amount), 'text-slate-900'], ['Paid', peso(d.paid), 'text-emerald-600'],
       [i.payment_status === 'CANCELLED' ? 'Cancelled' : 'Balance', peso(d.balance), d.balance > 0 ? 'text-red-600' : 'text-slate-900']]
      .map(t => '<div class="bg-slate-50 border border-slate-100 rounded-xl px-3 py-2.5"><p class="text-[11px] font-semibold text-slate-400 uppercase">' + t[0] + '</p>'
        + '<p class="text-base font-extrabold ' + t[2] + '">' + t[1] + '</p></div>').join('') + '</div>';

  const actions = '<a class="px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-100 text-slate-700" target="_blank" rel="noopener" href="' + esc(d.pdf_url) + '"><i class="fas fa-file-pdf mr-1"></i>View / PDF</a>'
    + (open
      ? '<button class="px-3 py-1.5 rounded-lg text-xs font-bold bg-emerald-600 text-white" onclick="closeModal();openPaymentModal(' + i.id + ')"><i class="fas fa-hand-holding-dollar mr-1"></i>Record payment</button>'
        + '<button class="px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-100 text-slate-700" onclick="closeModal();openInvoiceModal(' + i.id + ')"><i class="fas fa-pen mr-1"></i>Edit</button>'
        + '<button class="px-3 py-1.5 rounded-lg text-xs font-bold bg-red-50 text-red-600" onclick="closeModal();cancelInvoice(' + i.id + ')"><i class="fas fa-ban mr-1"></i>Cancel invoice</button>'
      : '');

  const html = ''
    + '<div class="flex flex-wrap items-start justify-between gap-3">'
    +   '<div class="min-w-0"><p class="text-lg font-extrabold text-slate-900 leading-snug">' + esc(i.client_name) + '</p>'
    +   '<p class="text-xs text-slate-400 mt-0.5">' + esc(i.invoice_code) + (i.notes ? ' · ' + esc(i.notes) : '') + '</p></div>'
    +   '<div class="shrink-0">' + badge(i.payment_status) + '</div>'
    + '</div>'
    + '<div class="mt-4">' + totals + '</div>'
    + '<div class="grid sm:grid-cols-2 gap-4 mt-4">' + clientCard + invCard + '</div>'
    + section('Line items', linesTable)
    + section('Payments', payments)
    + section('Actions', '<div class="flex flex-wrap gap-2">' + actions + '</div>');
  setModalWide(true);
  openInfoModal('Invoice ' + i.invoice_code, html);
}

function invoiceProjectOptions(clientId, selected) {
  const list = SELECT_OPTIONS.projects.filter(p => String(p.client_id) === String(clientId));
  return '<option value="">— No project —</option>' + list.map(p =>
    '<option value="' + p.id + '"' + (String(p.id) === String(selected) ? ' selected' : '') + '>' + esc(p.label) + '</option>').join('');
}
function openInvoiceModal(id) {
  setModalWide(false);
  const r = id ? BILL_CACHE.find(x => String(x.id) === String(id)) : null;
  const html = (r ? '<p class="text-xs text-slate-500">' + esc(r.invoice_code) + ' — ' + esc(r.client_name) + '</p>'
      : '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Client</label>'
        + '<select id="f-inv-client" class="w-full border rounded-lg px-3 py-2 text-sm">' + clientOptionsHtml() + '</select>')
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Project (optional)</label>'
    + '<select id="f-inv-project" class="w-full border rounded-lg px-3 py-2 text-sm">' + invoiceProjectOptions(r ? r.client_id : '', r ? r.project_id : '') + '</select>'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Amount (₱)</label>'
    + '<input id="f-inv-amount" type="number" min="0.01" step="0.01" value="' + esc(r ? r.amount : '') + '" class="w-full border rounded-lg px-3 py-2 text-sm">'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Due date</label>'
    + '<input id="f-inv-due" type="date" value="' + esc(r ? (r.due_date || '') : '') + '" class="w-full border rounded-lg px-3 py-2 text-sm">'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Notes</label>'
    + '<input id="f-inv-notes" type="text" maxlength="255" value="' + esc(r ? (r.notes || '') : '') + '" class="w-full border rounded-lg px-3 py-2 text-sm">';
  openModal(r ? 'Edit Invoice' : 'New Invoice', html, async () => {
    const amount = document.getElementById('f-inv-amount').value;
    if (!(Number(amount) > 0)) { toast('Enter an amount greater than zero.', true); return false; }
    const payload = {
      amount: amount,
      project_id: document.getElementById('f-inv-project').value,
      due_date: document.getElementById('f-inv-due').value,
      notes: document.getElementById('f-inv-notes').value.trim(),
    };
    if (r) payload.id = r.id;
    else {
      payload.client_id = document.getElementById('f-inv-client').value;
      if (!payload.client_id) { toast('Select a client.', true); return false; }
    }
    const json = await apiPost(r ? 'billing/update.php' : 'billing/create.php', payload);
    if (!json.success) { toast(json.message, true); return false; }
    toast(json.message, false);
    loadBilling();
    return true;
  });
  if (!r) {
    // The project list follows the chosen client.
    document.getElementById('f-inv-client').addEventListener('change', (e) => {
      document.getElementById('f-inv-project').innerHTML = invoiceProjectOptions(e.target.value, '');
    });
  }
}
function openPaymentModal(id) {
  setModalWide(false);
  const r = BILL_CACHE.find(x => String(x.id) === String(id));
  if (!r) return;
  const html = '<p class="text-xs text-slate-500">' + esc(r.invoice_code) + ' — ' + esc(r.client_name) + '<br>Balance: <b>' + peso(r.balance) + '</b> of ' + peso(r.amount) + '</p>'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Amount received (₱)</label>'
    + '<input id="f-pay-amount" type="number" min="0.01" step="0.01" value="' + esc(String(Number(r.balance).toFixed(2))) + '" class="w-full border rounded-lg px-3 py-2 text-sm">'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Method</label>'
    + '<select id="f-pay-method" class="w-full border rounded-lg px-3 py-2 text-sm"><option>CASH</option><option>GCASH</option><option>BANK_TRANSFER</option><option>CHECK</option><option>CREDIT_CARD</option></select>'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Date received</label>'
    + '<input id="f-pay-date" type="date" value="' + new Date().toLocaleDateString('en-CA') + '" max="' + new Date().toLocaleDateString('en-CA') + '" class="w-full border rounded-lg px-3 py-2 text-sm">'
    + '<label class="block text-xs font-semibold text-slate-500 mb-1 mt-3">Reference (optional)</label>'
    + '<input id="f-pay-ref" type="text" maxlength="50" placeholder="e.g. GCash or bank reference no." class="w-full border rounded-lg px-3 py-2 text-sm">';
  // One key per form: a double click or a retried request records one payment, not two.
  const requestKey = SunTrackQR.requestKey();
  openModal('Record Payment', html, async () => {
    const json = await apiPost('billing/record_payment.php', {
      invoice_id: r.id,
      amount: document.getElementById('f-pay-amount').value,
      payment_method: document.getElementById('f-pay-method').value,
      paid_on: document.getElementById('f-pay-date').value,
      reference: document.getElementById('f-pay-ref').value.trim(),
      request_key: requestKey,
    });
    if (!json.success) { toast(json.message, true); return false; }
    toast(json.message, false);
    loadBilling();
    return true;
  });
}
// Void a wrongly recorded payment. Never deletes it: it stays in the history.
async function voidPayment(paymentId, invoiceId, amountText) {
  const reason = prompt('Void the ' + amountText + ' payment?\n\nIt stays in the payment history but will no longer count as paid.\nWhy are you voiding it? (required)');
  if (reason === null) return;
  if (reason.trim().length < 5) { toast('Please give a short reason (at least 5 characters).', true); return; }
  const json = await apiPost('billing/void_payment.php', { payment_id: paymentId, reason: reason.trim() });
  toast(json.message, !json.success);
  if (json.success) { closeModal(); loadBilling(); viewInvoiceDetail(invoiceId); }
}
async function cancelInvoice(id) {
  const r = BILL_CACHE.find(x => String(x.id) === String(id));
  if (!confirm('Cancel invoice ' + (r ? r.invoice_code : '') + '? This cannot be undone.')) return;
  const json = await apiPost('billing/update.php', { id: id, cancel: true });
  toast(json.message, !json.success);
  if (json.success) loadBilling();
}

/* ---------------- Notifications ---------------- */
async function loadNotifications() {
  const box = document.getElementById('notif-list');
  box.innerHTML = '<p class="text-slate-400 text-sm p-6 text-center">Loading...</p>';
  const json = await apiGet('notifications/list.php', new URLSearchParams({ limit: 100 }));
  if (!json.success) { box.innerHTML = '<p class="text-red-500 text-sm p-6 text-center">' + esc(json.message) + '</p>'; return; }
  const rows = json.data.rows;
  updateNotifBadge(json.data.unread_count);
  box.innerHTML = rows.length ? rows.map(n =>
    '<div class="flex items-start justify-between gap-3 p-4 ' + (Number(n.is_read) ? '' : 'bg-orange-50/60') + '">'
    + '<div><p class="text-sm ' + (Number(n.is_read) ? 'text-slate-600' : 'font-semibold text-slate-800') + '">' + esc(n.message) + '</p>'
    + '<p class="text-xs text-slate-400 mt-1">' + n.created_at + '</p></div>'
    + (Number(n.is_read) ? '' : '<button class="link-btn text-solar shrink-0" onclick="markRead(' + n.id + ')">Mark read</button>')
    + '</div>'
  ).join('') : '<p class="text-slate-400 text-sm p-6 text-center">No notifications yet.</p>';
}
async function markRead(id) {
  await apiPost('notifications/mark_read.php', { id: id });
  loadNotifications();
}
async function markAllRead() {
  await apiPost('notifications/mark_read.php', { all: true });
  loadNotifications();
}
function updateNotifBadge(count) {
  const el = document.getElementById('notif-badge');
  if (!el) return;
  if (count > 0) { el.textContent = count > 99 ? '99+' : String(count); el.classList.remove('hidden'); }
  else el.classList.add('hidden');
}
async function pollNotifications() {
  const json = await apiGet('notifications/list.php', new URLSearchParams({ unread_only: 1, limit: 1 }));
  if (json.success) updateNotifBadge(json.data.unread_count);
}

/* ---------------- Reports ---------------- */
// Definitions (labels, statuses, date field) come from includes/report_lib.php,
// the same file the preview and the CSV export are built from.
const REPORT_DEFS = <?= json_encode(report_definitions(), JSON_HEX_TAG | JSON_HEX_AMP) ?>;
let repSeq = 0;           // a slower, older response never overwrites a newer one
let repShownType = null;  // the report the table currently shows
let repSearchTimer = null;

function reportParams() {
  const type = document.getElementById('rep-type').value;
  const params = new URLSearchParams({ type });
  const s  = document.getElementById('rep-search').value.trim(); if (s) params.set('search', s);
  const st = document.getElementById('rep-status').value;        if (st) params.set('status', st);
  if (REPORT_DEFS[type].date_label) {
    const f = document.getElementById('rep-from').value; if (f) params.set('date_from', f);
    const t = document.getElementById('rep-to').value;   if (t) params.set('date_to', t);
  }
  return params;
}
function reportHasFilters() {
  return [...reportParams().keys()].some(k => k !== 'type');
}

// Status choices, date range and search hint follow the chosen report.
function setupReportFilters() {
  const def = REPORT_DEFS[document.getElementById('rep-type').value];
  const status = document.getElementById('rep-status');
  status.innerHTML = '<option value="">Any ' + esc(def.status_label.toLowerCase()) + '</option>'
    + Object.entries(def.statuses).map(([v, l]) => '<option value="' + esc(v) + '">' + esc(l) + '</option>').join('');
  status.setAttribute('aria-label', def.status_label);
  document.getElementById('rep-search').placeholder = 'Search: ' + def.search_hint;
  const dates = document.getElementById('rep-dates');
  dates.classList.toggle('hidden', !def.date_label);
  if (def.date_label) {
    document.getElementById('rep-from').title = def.date_label + ' from';
    document.getElementById('rep-to').title = def.date_label + ' to';
  }
}

function reportCell(v, type) {
  if (v === null || v === undefined || v === '') return '<span class="text-slate-300">—</span>';
  switch (type) {
    case 'number':  return '<span class="tabular-nums">' + Number(v).toLocaleString('en-PH') + '</span>';
    case 'money':   return '<span class="tabular-nums">' + peso(v) + '</span>';
    case 'percent': {
      const p = Math.max(0, Math.min(100, Number(v) || 0));
      return '<span class="inline-flex items-center gap-2"><span class="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden"><span class="block h-full bg-solar" style="width:' + p + '%"></span></span><span class="tabular-nums text-xs">' + p + '%</span></span>';
    }
    case 'date': {
      const d = new Date(String(v).slice(0, 10) + 'T00:00');
      return isNaN(d) ? esc(v) : d.toLocaleDateString('en-PH', { year: 'numeric', month: 'short', day: 'numeric' });
    }
    case 'datetime': {
      const d = new Date(String(v).replace(' ', 'T'));
      return isNaN(d) ? esc(v) : d.toLocaleString('en-PH', { year: 'numeric', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
    }
    case 'status':  return badge(v);
    default: {
      const s = String(v);
      return s.length > 80 ? '<span title="' + esc(s) + '">' + esc(s.slice(0, 79)) + '…</span>' : esc(s);
    }
  }
}

async function loadReport() {
  const seq = ++repSeq;
  const type = document.getElementById('rep-type').value;
  const thead = document.getElementById('rep-thead');
  const tbody = document.getElementById('rep-tbody');
  const wrap = document.getElementById('rep-table-wrap');
  const summary = document.getElementById('rep-summary');
  document.getElementById('rep-clear').classList.toggle('hidden', !reportHasFilters());

  summary.innerHTML = '<i class="fas fa-spinner fa-spin mr-1"></i> Loading ' + esc(REPORT_DEFS[type].label) + '…';
  if (repShownType === type) {
    wrap.classList.add('opacity-50');   // same columns: keep the rows on screen while refreshing
  } else {
    thead.innerHTML = '';
    tbody.innerHTML = Array.from({ length: 6 }, () =>
      '<tr>' + Array.from({ length: 6 }, () => '<td><span class="block h-3 rounded bg-slate-100 animate-pulse"></span></td>').join('') + '</tr>').join('');
  }

  const json = await apiGet('reports/get_report.php', reportParams());
  if (seq !== repSeq) return;
  wrap.classList.remove('opacity-50');

  if (!json.success) {
    repShownType = null;
    thead.innerHTML = '';
    tbody.innerHTML = '<tr><td class="text-center text-red-500 py-8"><i class="fas fa-circle-exclamation mr-1"></i> ' + esc(json.message || 'The report could not be loaded.') + '</td></tr>';
    summary.textContent = '';
    return;
  }

  const d = json.data;
  repShownType = type;
  thead.innerHTML = '<tr>' + d.columns.map(c =>
    '<th' + (['number', 'money'].includes(c.type) ? ' class="text-right"' : '') + '>' + esc(c.label) + '</th>').join('') + '</tr>';

  if (!d.rows.length) {
    tbody.innerHTML = '<tr><td colspan="' + d.columns.length + '" class="text-center py-10">'
      + '<i class="fas fa-magnifying-glass text-2xl text-slate-300 block mb-2"></i>'
      + '<p class="text-slate-600 font-semibold text-sm">No records found matching your filters.</p>'
      + (reportHasFilters() ? '<button class="mt-3 text-solar text-sm font-semibold hover:underline" onclick="clearReportFilters()">Clear filters</button>' : '')
      + '</td></tr>';
  } else {
    tbody.innerHTML = d.rows.map(r => '<tr>' + d.columns.map(c =>
      '<td' + (['number', 'money'].includes(c.type) ? ' class="text-right"' : '') + '>' + reportCell(r[c.key], c.type) + '</td>').join('') + '</tr>').join('');
  }

  const total = Number(d.total).toLocaleString('en-PH');
  summary.textContent = d.total === d.shown
    ? total + ' record' + (d.total === 1 ? '' : 's') + '.'
    : 'Showing the first ' + d.shown.toLocaleString('en-PH') + ' of ' + total + ' records. '
      + (d.total > 10000 ? 'The CSV export includes the first 10,000.' : 'The CSV export includes all of them.');
}

function clearReportFilters() {
  ['rep-search', 'rep-status', 'rep-from', 'rep-to'].forEach(id => document.getElementById(id).value = '');
  loadReport();
}

// Downloads through fetch, so a failed export shows a message here instead of
// navigating the page to a JSON error.
async function exportReport(btn) {
  const original = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-1"></i> Exporting…';
  try {
    const res = await fetch(API + 'reports/export.php?' + reportParams().toString(), { credentials: 'same-origin' });
    if (!res.ok || !(res.headers.get('Content-Type') || '').includes('text/csv')) {
      let msg = 'The export failed. Please try again.';
      try { msg = (await res.json()).message || msg; } catch (e) { /* not JSON */ }
      toast(msg, true);
      return;
    }
    const blob = await res.blob();
    const match = /filename="([^"]+)"/.exec(res.headers.get('Content-Disposition') || '');
    const name = match ? match[1] : 'report.csv';
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast('Downloaded ' + name);
  } catch (e) {
    toast('Network error. Please try again.', true);
  } finally {
    btn.disabled = false;
    btn.innerHTML = original;
  }
}

document.getElementById('rep-type').addEventListener('change', () => {
  setupReportFilters();   // statuses differ per report, so the old choice is dropped
  loadReport();
});
document.getElementById('rep-search').addEventListener('input', () => {
  clearTimeout(repSearchTimer);
  repSearchTimer = setTimeout(loadReport, 350);
});
['rep-status', 'rep-from', 'rep-to'].forEach(id => document.getElementById(id).addEventListener('change', loadReport));
setupReportFilters();

/* ---------------- Tabs ---------------- */
const TAB_TITLES = {
  dashboard: 'Dashboard', clients: 'Clients', projects: 'Projects', 'service-requests': 'Service Requests',
  jobs: 'Jobs', technicians: 'Technicians', installation: 'Installation', maintenance: 'Maintenance',
  warehouse: 'Warehouse', subcontractors: 'Sub-contractors', staff: 'Staff', reports: 'Reports',
  notifications: 'Notifications', settings: 'Settings', 'material-requests': 'Material Requests', billing: 'Billing',
};
const TAB_LOADERS = {
  dashboard: loadDashboard,
  'service-requests': loadServiceRequests,
  jobs: loadJobs,
  clients: () => loadEntity('clients'),
  technicians: () => loadEntity('technicians'),
  projects: () => loadEntity('projects'),
  installation: loadInstallation,
  maintenance: loadMaintenance,
  warehouse: () => loadEntity('inventory'),
  'material-requests': loadMaterialRequests,
  subcontractors: () => SUBCON.refresh(),
  staff: () => loadEntity('staff'),
  billing: loadBilling,
  reports: loadReport,
  notifications: loadNotifications,
  settings: () => { loadProfile(); SunTrackAccount.renderTwoFactor('twofa-card'); },
};

/* ---------------- settings (own account) ---------------- */
async function loadProfile() {
  const json = await apiGet('account/profile.php');
  if (!json.success) { toast(json.message, true); return; }
  document.getElementById('pf-name').value  = json.data.full_name || '';
  document.getElementById('pf-email').value = json.data.email || '';
  document.getElementById('pf-phone').value = json.data.phone || '';
  document.getElementById('pf-role').value  = json.data.role_name || '';
}
async function saveProfile(btn) {
  btn.disabled = true;
  const json = await apiPost('account/profile.php', {
    action: 'update_profile',
    full_name: document.getElementById('pf-name').value.trim(),
    email: document.getElementById('pf-email').value.trim(),
    phone: document.getElementById('pf-phone').value.trim(),
  });
  btn.disabled = false;
  toast(json.message, !json.success);
}
async function changePassword(btn) {
  const cur = document.getElementById('pw-current').value;
  const nw  = document.getElementById('pw-new').value;
  const cf  = document.getElementById('pw-confirm').value;
  if (!cur || !nw || !cf) { toast('Please fill in all three password fields.', true); return; }
  if (nw !== cf)          { toast('The new passwords do not match.', true); return; }
  if (nw.length < 8)      { toast('Your new password must be at least 8 characters.', true); return; }
  btn.disabled = true;
  const json = await apiPost('account/profile.php', {
    action: 'change_password', current_password: cur, new_password: nw, confirm_password: cf,
  });
  btn.disabled = false;
  toast(json.message, !json.success);
  if (json.success) ['pw-current','pw-new','pw-confirm'].forEach(id => document.getElementById(id).value = '');
}

let CURRENT_TAB = 'dashboard';
function showTab(key) {
  CURRENT_TAB = key;
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.add('hidden'));
  document.querySelectorAll('.tab-link').forEach(a => a.classList.remove('bg-solar', 'text-white', 'shadow-md'));
  const panel = document.getElementById('tab-' + key);
  if (!panel) return;
  panel.classList.remove('hidden');
  const link = document.querySelector('.tab-link[data-tab="' + key + '"]');
  if (link) link.classList.add('bg-solar', 'text-white', 'shadow-md');
  document.getElementById('page-title').textContent = TAB_TITLES[key] || key;
  const loader = TAB_LOADERS[key];
  if (loader) loader();
}
document.querySelectorAll('.tab-link').forEach(a => {
  a.addEventListener('click', (e) => { e.preventDefault(); showTab(a.dataset.tab); });
});

/* ---------------- Init ---------------- */
// Which sync channels feed which Management tab.
const CHANNEL_TABS = {
  inventory:        ['dashboard', 'warehouse', 'reports'],
  stock_movements:  ['dashboard', 'warehouse', 'material-requests', 'reports'],
  material_requests:['dashboard', 'material-requests'],
  jobs:             ['dashboard', 'jobs', 'projects', 'maintenance', 'reports'],
  projects:         ['dashboard', 'projects', 'maintenance', 'reports'],
  clients:          ['dashboard', 'clients', 'reports'],
  technicians:      ['dashboard', 'technicians', 'reports'],
  staff:            ['staff'],
  // 'clients' too: the client map colours pins by open request priority.
  service_requests: ['dashboard', 'service-requests', 'clients', 'reports'],
  attendance:       ['dashboard', 'reports'],
  maintenance:      ['dashboard', 'maintenance', 'reports'],
  billing:          ['dashboard', 'billing'],
  work_reports:     ['dashboard', 'reports'],
  subcontractors:   ['subcontractors'],
  subcon_assignments: ['subcontractors', 'jobs', 'dashboard'],
  installation_plan:['installation'],
};

function startRealtime() {
  SunTrackRealtime.start({
    endpoint: '../api/realtime/sync.php',
    on: {
      // The notification bell is driven by the heartbeat's counter rather than
      // its own timer, so the badge and the tables can never disagree.
      counters: (counters) => {
        const badge = document.getElementById('notif-badge');
        if (badge && counters && typeof counters.unread_notifications === 'number') {
          const n = counters.unread_notifications;
          badge.textContent = n;
          badge.classList.toggle('hidden', n === 0);
        }
      },
      '*': (changed) => {
        const affected = new Set();
        changed.forEach(ch => (CHANNEL_TABS[ch] || []).forEach(t => affected.add(t)));
        if (affected.has(CURRENT_TAB)) {
          const loader = TAB_LOADERS[CURRENT_TAB];
          if (loader) loader();
        }
        // A new notification should appear whether or not that tab is open.
        if (CURRENT_TAB === 'notifications') loadNotifications();
      },
      sessionExpired: () => { window.location.href = '<?= APP_BASE_URL ?>/login.php?expired=1'; },
    }
  });
}

/* ---------------- Init ---------------- */
async function init() {
  await loadSelectOptions();
  ['clients', 'technicians', 'staff', 'projects', 'inventory'].forEach(initEntityTab);
  bindFilterBars();
  showTab('dashboard');
  pollNotifications();
  startRealtime();
}
init();
</script>

<?php include ROOT_PATH . '/includes/consent_banner.php'; ?>
</body>
</html>
