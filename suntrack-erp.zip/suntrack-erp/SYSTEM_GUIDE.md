# SunTrack ERP — How the System Works

A guide for the team and beta testers: who uses which portal, how work flows
from a client's request to a finished job, and what each feature is for.

---

## 1. The five portals

Everyone signs in at the same page (`/login.php`); the system sends each person
to their own portal based on their role.

| Portal | Who | What they do there |
|---|---|---|
| **Management** | Managers and office staff | Run the business: clients, service requests, jobs, projects, technicians, material requests, maintenance, reports |
| **Technician** | Field technicians (on a phone) | See assigned jobs, GPS Time In/Out, update job stages, checklists, work reports |
| **Warehouse** | Stock clerks (phone or PC) | Inventory, QR scanning, prepare client orders, releases, stock reports |
| **Client** | Customers | Request service, follow progress, see their solar system, maintenance and history |
| **Admin** | Owner / auditor | View everything live and export CSVs — **view-only**, cannot change data |

Only **clients** can create their own account (`Create an account` on the
login page). Every other account is made by Management, or by the
`database/create_user.php` script for the very first staff accounts.

---

## 2. The main workflow — from a client's problem to a finished job

```
 CLIENT                MANAGEMENT                TECHNICIAN (phone)                CLIENT
 ──────                ──────────                ──────────────────                ──────
 Submits a      ──►    Approves the      ──►     Sees the job, taps          ──►   Gets notified at
 service               request, assigns          En Route → Arrived                 every step; request
 request               a technician              GPS Time In (must be at site)      closes automatically
 (Low→Urgent)          (a job is created)        In Progress → Time Out →           when the job is
                                                 Completed → Work report            completed
```

Step by step:

1. **Client submits a service request** (Client portal → Service Requests),
   choosing a priority: Low, Normal, High or Urgent.
2. **Management reviews it** (Management → Service Requests) and **Approves**
   or **Rejects** it.
3. **Management assigns a technician.** This automatically creates a **job**
   that copies the client's pinned site location — that pin is the job's
   **geofence**.
4. **The technician works the job** on their phone (Technician → My
   Assignments). A job can only move forward in this order:
   `Assigned → En Route → Arrived → In Progress → (Paused) → Completed`.
   - **In Progress needs a GPS Time In** at the site (see §4).
   - **Completed needs a Time Out** first, and for installations a 100%
     checklist, for maintenance a finished inspection.
   - A mistaken step can be undone for a short time (recorded in history).
5. **The technician submits a work report** (what was done, materials,
   issues, time spent).
6. **The client is notified at every step** and their request is marked
   **Completed** automatically. Management sees the report; Admin sees it all.

Management can also create jobs directly (Jobs → Create Job), e.g. for
inspections, without a client request.

---

## 3. Installation projects and materials (Management ↔ Warehouse)

1. **Management creates a Project** for a client (Projects → Add). If they fill
   in *Solar panels / Inverters / Batteries needed*, a **Material Request** is
   sent to the warehouse automatically. Requests can also be made directly
   (Management → Material Requests → New Request).
2. **The warehouse is notified** — a red badge appears on *Client Orders*.
3. **The clerk prepares the order**: open it → *Scan items for this order*.
   Each scan takes one unit out of stock and counts it toward the order.
   Wrong item, too many, or not enough stock is refused on the spot.
4. When every line is filled the order turns **READY** by itself and
   Management is notified.
5. **Release**: the clerk records who took it (technician/driver). The order
   is closed and a **printable slip** with signature lines is available.

**Scanner modes** (Warehouse → QR Scanner): *Look Up* (see what a code is),
*Restock (In)*, *Stock Out*, *Return*, *Prepare Order*. Scanning an order
slip's code (`MR-2026-0001`) opens that order.

---

## 4. The geofence (GPS attendance)

- Every client has a **pin on the map** (set when the client is added, or
  later under Clients → Edit). Jobs inherit it. The default radius is
  **500 m**.
- **Time In only works inside the radius.** Outside, the phone shows how far
  away the technician is.
- **Time In also needs a clear GPS reading.** If the phone only knows its
  position roughly (e.g. indoors, "±800 m"), Time In asks the technician to
  step outside and try again — a rough reading cannot prove where they are.
  The GPS strip at the top of the technician's screen turns **amber** ("GPS
  signal weak") whenever the reading is rougher than ±150 m, so they know
  before tapping. Time In and Time Out always take a fresh GPS reading.
- **While a job is active, the phone reports its position every 20 seconds**
  and keeps the screen awake. Management/Admin see live technicians, their
  trail, and INSIDE / OUTSIDE status on the **Site Map**.
- A job **with no site pin** cannot be timed in to — pin the client first.

**Needs HTTPS** on the live site: phones only share GPS (and the camera, for
scanning) with secure `https://` pages. On a phone, allow *Location* for the
site and keep the SunTrack page open while working a job (web pages cannot
track in the background).

---

## 5. Maintenance

Management schedules each project's next maintenance date. The status
updates itself every day: **Upcoming → Due** (within 14 days) **→ Overdue**
(date passed). From there Management can assign a technician (creates a
maintenance job with an inspection form) and notify the client.

---

## 6. Everyday tools

- **Live updates.** Screens refresh themselves within a few seconds when
  someone else changes something — no need to reload.
- **Notifications.** The bell / Notifications tab in each portal.
- **Search.** Type any words in any order — every word must match
  (`maria bacolod`, a phone number, a job code). Filters (status, dates,
  city, technician…) apply instantly; **Clear** resets them; **Esc** clears
  the search box.
- **Client map** (Management → Clients): every client pin, coloured by their
  most pressing open request — red Urgent/High, amber Normal/Low, green none.
- **Exports.** CSV export on most lists, matching exactly what is on screen.
- **Password reset.** Clients and technicians use *Forgot password?* on the
  login page (email link, valid 30 minutes, one use, with a confirmation
  email afterwards). Staff ask Management to reset theirs.

---

## 7. Security in one paragraph

Passwords are stored with bcrypt; 5 wrong guesses lock the account for 15
minutes; sessions expire after 60 idle minutes; every change needs a
per-session security token; each role can only reach its own screens and
data (checked on the server, not just hidden); all database queries are
parameterised; everything shown on screen is escaped; secret folders are
blocked from the web. See `DEPLOYMENT.md` for the go-live checklist.

---

## 8. Beta-testing checklist (what to try)

1. A client registers, then submits a request from a phone.
2. Management approves, assigns, and watches it on the client map.
3. The technician times in **at** the site (and tries from far away — it must
   refuse), completes the job, submits a report.
4. The client sees the progress notifications and the completed request.
5. Management creates a project with materials; the warehouse scans the
   order to READY and releases it; print the slip.
6. Try *Forgot password?* as a client and as a technician.
7. Try every portal on a phone and on a laptop.

Report anything odd with: the portal, the screen, what you did, what you
expected, and a screenshot.
