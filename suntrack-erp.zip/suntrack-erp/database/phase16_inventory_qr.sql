-- =====================================================================
-- SunTrack ERP — Phase 16: QR labels, serialized units, safe stock moves
--
-- Builds on the existing inventory / stock_movements tables (no copies):
--
--   inventory.qr_code          already holds QR-<SKU>; now UNIQUE, so two
--                              products can never share a label. Blank or
--                              duplicate values are cleared first (the later
--                              row gets a "Generate QR Code" button instead).
--   inventory.tracking_mode    PRODUCT = one QR per SKU, quantity typed in
--                              SERIAL  = every unit has its own QR + serial no.
--                              Existing items stay PRODUCT: their
--                              serial_number column holds lot numbers, not
--                              per-unit serials.
--   inventory.quarantine_qty   damaged / to-inspect returns. Never counted
--                              as available stock until Inspection passes it.
--   inventory_units            one row per serialized unit (its QR identifier,
--                              serial number, status, condition, current job)
--   stock_movements            + unit_id, item_condition, original_movement_id
--                              (a return points at the issue it reverses)
--   stock_request_keys         one row per submitted stock form, so a double
--                              tap or a retried request is applied only once
--
-- Safe to re-run: every change checks first.
-- phpMyAdmin: select the suntrack_erp database > Import > choose this file > Go.
-- =====================================================================

-- 1. QR identifiers: clear blanks and duplicates, then enforce uniqueness.
UPDATE inventory SET qr_code = NULL WHERE qr_code = '';

UPDATE inventory i
JOIN (
    SELECT qr_code, MIN(id) AS keep_id
    FROM inventory
    WHERE qr_code IS NOT NULL
    GROUP BY qr_code
    HAVING COUNT(*) > 1
) d ON d.qr_code = i.qr_code AND i.id <> d.keep_id
SET i.qr_code = NULL;

CREATE TABLE IF NOT EXISTS inventory_units (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    inventory_id        INT UNSIGNED  NOT NULL,
    unit_code           VARCHAR(40)   NOT NULL,              -- QR payload and short label id, e.g. UNIT-9007-0001
    serial_number       VARCHAR(100)  NOT NULL,              -- manufacturer serial
    status              ENUM('IN_STOCK','ISSUED','QUARANTINE','WRITTEN_OFF') NOT NULL DEFAULT 'IN_STOCK',
    item_condition      ENUM('GOOD','DAMAGED','NEEDS_INSPECTION') NOT NULL DEFAULT 'GOOD',
    job_id              INT UNSIGNED  NULL,                  -- where it is while ISSUED
    material_request_id INT UNSIGNED  NULL,
    warehouse_location  VARCHAR(50)   NULL,
    created_at          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_unit_code (unit_code),
    UNIQUE KEY uq_unit_serial (inventory_id, serial_number),
    KEY idx_unit_status (inventory_id, status),
    KEY idx_unit_serial (serial_number),
    CONSTRAINT fk_unit_inventory FOREIGN KEY (inventory_id) REFERENCES inventory (id) ON DELETE CASCADE,
    CONSTRAINT fk_unit_job FOREIGN KEY (job_id) REFERENCES jobs (id) ON DELETE SET NULL,
    CONSTRAINT fk_unit_mr FOREIGN KEY (material_request_id) REFERENCES material_requests (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS stock_request_keys (
    request_key   VARCHAR(64)  NOT NULL PRIMARY KEY,
    endpoint      VARCHAR(40)  NOT NULL,
    user_id       INT UNSIGNED NULL,
    response_json MEDIUMTEXT   NULL,                         -- replayed if the same form is sent again
    created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_srk_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP PROCEDURE IF EXISTS suntrack16_upgrade;
DELIMITER //
CREATE PROCEDURE suntrack16_upgrade()
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'inventory' AND INDEX_NAME = 'uq_inventory_qr'
    ) THEN
        ALTER TABLE inventory ADD UNIQUE KEY uq_inventory_qr (qr_code);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'inventory' AND COLUMN_NAME = 'tracking_mode'
    ) THEN
        ALTER TABLE inventory ADD COLUMN tracking_mode ENUM('PRODUCT','SERIAL') NOT NULL DEFAULT 'PRODUCT' AFTER qr_code;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'inventory' AND COLUMN_NAME = 'quarantine_qty'
    ) THEN
        ALTER TABLE inventory ADD COLUMN quarantine_qty INT NOT NULL DEFAULT 0 AFTER quantity;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'stock_movements' AND COLUMN_NAME = 'unit_id'
    ) THEN
        ALTER TABLE stock_movements
            ADD COLUMN unit_id INT UNSIGNED NULL AFTER material_request_id,
            ADD COLUMN item_condition ENUM('GOOD','DAMAGED','NEEDS_INSPECTION') NULL AFTER unit_id,
            ADD COLUMN original_movement_id INT UNSIGNED NULL AFTER item_condition,
            ADD KEY idx_move_unit (unit_id),
            ADD KEY idx_move_original (original_movement_id),
            ADD CONSTRAINT fk_move_unit FOREIGN KEY (unit_id) REFERENCES inventory_units (id) ON DELETE SET NULL,
            ADD CONSTRAINT fk_move_original FOREIGN KEY (original_movement_id) REFERENCES stock_movements (id) ON DELETE SET NULL;
    END IF;
END //
DELIMITER ;
CALL suntrack16_upgrade();
DROP PROCEDURE IF EXISTS suntrack16_upgrade;

-- Products left without a QR identifier (none in the current data) get one
-- from their QR panel's "Generate QR Code" button, never silently here.
