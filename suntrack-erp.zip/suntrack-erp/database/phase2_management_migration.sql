-- ============================================================================
-- SunTrack ERP — Phase 2 Management Migration
-- Safe to run once. Every statement is guarded so re-running it is a no-op.
--
-- Everything else in Phase 2 (Management portal, Jobs/Maintenance/
-- Notifications endpoints, Admin read-only enforcement) reuses the existing
-- schema exactly as it is — this is the ONE change that was genuinely
-- required: maintenance_schedules.project_id had no unique constraint,
-- so "one schedule row per project" could not be enforced atomically by
-- the database, only hoped for by application code. Without it, two
-- concurrent "Schedule Maintenance" clicks for the same project could each
-- see no existing row and both INSERT, creating duplicates.
-- ============================================================================

SET @idx_exists := (
    SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME   = 'maintenance_schedules'
      AND INDEX_NAME   = 'uq_maint_schedule_project'
);

SET @sql := IF(
    @idx_exists = 0,
    'ALTER TABLE maintenance_schedules ADD UNIQUE KEY uq_maint_schedule_project (project_id)',
    'SELECT "uq_maint_schedule_project already exists — skipped" AS notice'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
