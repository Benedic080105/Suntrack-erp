<?php
/**
 * SunTrack ERP — Phase 10 backfill: installation jobs for existing projects.
 *
 * Until this fix, adding a project with a technician only saved the technician
 * on the project; no installation job was created, so the technician never saw
 * it. New and edited projects now create the job themselves
 * (includes/project_lib.php, project_sync_installation_job()). This script does
 * the same once for projects created before the fix:
 *
 *   php database/phase10_project_installation_jobs.php            create the missing jobs
 *   php database/phase10_project_installation_jobs.php --dry-run  only list them
 *   php database/phase10_project_installation_jobs.php --project=SITE-841   just that project
 *
 * Only open projects (not completed / under maintenance / cancelled) with a
 * technician and no installation job are touched; each technician gets the
 * usual "new job" notification. Safe to re-run: a project that already has its
 * job is skipped.
 *
 * Command line only: refuses a browser, and database/ is blocked by .htaccess.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/settings_lib.php';
require_once __DIR__ . '/../includes/technician_lib.php';
require_once __DIR__ . '/../middleware/auth.php';
require_once __DIR__ . '/../includes/project_lib.php';
if (!defined('DEFAULT_GEOFENCE_RADIUS_M')) {
    define('DEFAULT_GEOFENCE_RADIUS_M', 500); // config/config.php's fallback; not loaded on the command line
}

$dryRun = in_array('--dry-run', $argv, true);
$only = null;
foreach ($argv as $arg) {
    if (str_starts_with($arg, '--project=')) {
        $only = substr($arg, strlen('--project='));
    }
}
$pdo = db();

$stmt = $pdo->prepare(
    "SELECT p.id, p.project_code, p.site_name, p.status, p.installation_date, u.full_name AS technician
     FROM projects p
     JOIN technicians t ON t.id = p.assigned_technician_id
     JOIN users u ON u.id = t.user_id
     WHERE p.status NOT IN ('COMPLETED', 'MAINTENANCE', 'CANCELLED')
       AND NOT EXISTS (SELECT 1 FROM jobs j WHERE j.project_id = p.id AND j.job_type = 'INSTALLATION')"
    . ($only !== null ? ' AND p.project_code = :code' : '') . '
     ORDER BY p.id'
);
$stmt->execute($only !== null ? [':code' => $only] : []);
$projects = $stmt->fetchAll();

if (!$projects) {
    echo "Nothing to do: every open project with a technician already has its installation job.\n";
    exit;
}

$created = 0;
foreach ($projects as $p) {
    $label = "{$p['project_code']} ({$p['site_name']}, {$p['status']}) -> {$p['technician']}";
    if ($dryRun) {
        echo "would create: $label\n";
        continue;
    }
    $pdo->beginTransaction();
    try {
        $notes = project_sync_installation_job((int)$p['id']);
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        echo "FAILED: $label — {$e->getMessage()}\n";
        continue;
    }
    project_send_job_notifications($notes);
    $code = $pdo->prepare("SELECT job_code FROM jobs WHERE project_id = :p AND job_type = 'INSTALLATION' ORDER BY id DESC LIMIT 1");
    $code->execute([':p' => $p['id']]);
    echo "created {$code->fetchColumn()}: $label\n";
    $created++;
}

echo $dryRun
    ? "\nDry run: " . count($projects) . " project(s) would get an installation job.\n"
    : "\nDone: $created of " . count($projects) . " project(s) now have an installation job.\n";
