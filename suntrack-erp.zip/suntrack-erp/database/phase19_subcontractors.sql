-- =====================================================================
-- SunTrack ERP — Phase 19: subcontractors, automatic assignment, portal
--
-- Extends what exists (no copies):
--   roles                      + 'subcontractor' — a portal login on the existing
--                                users table and login page
--   subcontractors             + contact person, address, specialties, rates,
--                                contract / insurance / permit references,
--                                4-state status, linked portal user, and
--                                max_active_jobs (how many jobs they take at once)
--   subcontractor_assignments  a job given to ONE subcontractor (a unique index
--                                stops two open assignments on the same job).
--                                auto_assigned / assignment_reason record why the
--                                system chose them; offer_expires_at moves an
--                                unanswered offer on to the next subcontractor.
--   subcontractor_events       who did what and when (incl. automatic actions)
--   subcontractor_files        completion photos and documents
--   Payables tables (invoices / payments / variations) are created for later
--   use; client billing is untouched.
--
-- Job stage, assignment status and payment status stay separate.
-- Installation / maintenance checklists are the existing ones.
--
-- Safe to re-run. phpMyAdmin: select suntrack_erp > Import > this file > Go.
-- =====================================================================

INSERT INTO roles (role_key, role_label)
SELECT 'subcontractor', 'Subcontractor' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM roles WHERE role_key = 'subcontractor');

DROP PROCEDURE IF EXISTS suntrack19_upgrade;
DELIMITER //
CREATE PROCEDURE suntrack19_upgrade()
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
                   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'subcontractors' AND COLUMN_NAME = 'status') THEN
        ALTER TABLE subcontractors
            ADD COLUMN contact_person    VARCHAR(150) NULL AFTER name,
            ADD COLUMN address           VARCHAR(255) NULL AFTER area,
            ADD COLUMN specialties       VARCHAR(255) NULL AFTER specialization,
            ADD COLUMN rate_type         ENUM('PER_JOB','PER_DAY','PER_KW','OTHER') NULL AFTER address,
            ADD COLUMN default_rate      DECIMAL(12,2) NULL AFTER rate_type,
            ADD COLUMN rate_notes        VARCHAR(255) NULL AFTER default_rate,
            ADD COLUMN contract_start    DATE NULL AFTER rate_notes,
            ADD COLUMN contract_end      DATE NULL AFTER contract_start,
            ADD COLUMN qualifications    TEXT NULL AFTER contract_end,
            ADD COLUMN insurance_ref     VARCHAR(100) NULL AFTER qualifications,
            ADD COLUMN insurance_expiry  DATE NULL AFTER insurance_ref,
            ADD COLUMN permit_ref        VARCHAR(100) NULL AFTER insurance_expiry,
            ADD COLUMN contract_doc_ref  VARCHAR(150) NULL AFTER permit_ref,
            ADD COLUMN notes             TEXT NULL AFTER contract_doc_ref,
            ADD COLUMN status            ENUM('PENDING','APPROVED','SUSPENDED','INACTIVE') NOT NULL DEFAULT 'PENDING' AFTER approved,
            ADD COLUMN status_reason     VARCHAR(255) NULL AFTER status,
            ADD COLUMN status_changed_at DATETIME NULL AFTER status_reason,
            ADD COLUMN status_changed_by INT UNSIGNED NULL AFTER status_changed_at,
            ADD COLUMN user_id           INT UNSIGNED NULL AFTER status_changed_by,
            ADD UNIQUE KEY uq_subcon_user (user_id),
            ADD KEY idx_subcon_status (status),
            ADD CONSTRAINT fk_subcon_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL,
            ADD CONSTRAINT fk_subcon_status_by FOREIGN KEY (status_changed_by) REFERENCES users (id) ON DELETE SET NULL;
        UPDATE subcontractors SET status = IF(approved = 1, 'APPROVED', 'PENDING');
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
                   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'subcontractors' AND COLUMN_NAME = 'max_active_jobs') THEN
        ALTER TABLE subcontractors ADD COLUMN max_active_jobs SMALLINT UNSIGNED NOT NULL DEFAULT 3 AFTER user_id;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
                   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'stock_movements' AND COLUMN_NAME = 'subcontractor_id') THEN
        ALTER TABLE stock_movements
            MODIFY movement_type ENUM('RECEIVE','ISSUE','RETURN','ADJUST','TRANSFER','CONSUME','LOSS') NOT NULL,
            ADD COLUMN subcontractor_id INT UNSIGNED NULL AFTER technician_id,
            ADD COLUMN acknowledged_at  DATETIME NULL AFTER subcontractor_id,
            ADD COLUMN acknowledged_by  INT UNSIGNED NULL AFTER acknowledged_at,
            ADD KEY idx_move_subcon (subcontractor_id),
            ADD CONSTRAINT fk_move_subcon FOREIGN KEY (subcontractor_id) REFERENCES subcontractors (id) ON DELETE SET NULL,
            ADD CONSTRAINT fk_move_ack_by FOREIGN KEY (acknowledged_by) REFERENCES users (id) ON DELETE SET NULL;
    END IF;
END //
DELIMITER ;
CALL suntrack19_upgrade();
DROP PROCEDURE IF EXISTS suntrack19_upgrade;

CREATE TABLE IF NOT EXISTS subcontractor_assignments (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    assignment_code     VARCHAR(20)   NOT NULL,
    job_id              INT UNSIGNED  NOT NULL,
    subcontractor_id    INT UNSIGNED  NOT NULL,
    status              ENUM('AWAITING_ACCEPTANCE','ACCEPTED','DECLINED','SCHEDULED','IN_PROGRESS',
                             'AWAITING_INSPECTION','REVISION_REQUIRED','APPROVED','COMPLETED','CANCELLED')
                        NOT NULL DEFAULT 'AWAITING_ACCEPTANCE',
    scope               TEXT          NOT NULL,
    instructions        TEXT          NULL,
    materials_note      TEXT          NULL,
    contract_amount     DECIMAL(14,2) NOT NULL DEFAULT 0,
    assigned_at         DATETIME      NOT NULL,
    assigned_by         INT UNSIGNED  NULL,
    expected_completion DATE          NULL,
    scheduled_date      DATE          NULL,
    responded_at        DATETIME      NULL,
    responded_by        INT UNSIGNED  NULL,
    decline_reason      VARCHAR(255)  NULL,
    started_at          DATETIME      NULL,
    submitted_at        DATETIME      NULL,
    submission_round    SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    reviewed_at         DATETIME      NULL,
    reviewed_by         INT UNSIGNED  NULL,
    review_note         VARCHAR(500)  NULL,
    revision_count      SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    completed_at        DATETIME      NULL,
    completed_by        INT UNSIGNED  NULL,
    cancelled_reason    VARCHAR(255)  NULL,
    active_job_id       INT UNSIGNED AS (IF(status IN ('DECLINED','CANCELLED','COMPLETED'), NULL, job_id)) PERSISTENT,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_sa_code (assignment_code),
    UNIQUE KEY uq_sa_active_job (active_job_id),
    KEY idx_sa_subcon (subcontractor_id, status),
    KEY idx_sa_job (job_id),
    KEY idx_sa_status (status),
    CONSTRAINT fk_sa_job FOREIGN KEY (job_id) REFERENCES jobs (id) ON DELETE CASCADE,
    CONSTRAINT fk_sa_subcon FOREIGN KEY (subcontractor_id) REFERENCES subcontractors (id),
    CONSTRAINT fk_sa_assigned_by FOREIGN KEY (assigned_by) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT fk_sa_responded_by FOREIGN KEY (responded_by) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT fk_sa_reviewed_by FOREIGN KEY (reviewed_by) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT fk_sa_completed_by FOREIGN KEY (completed_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP PROCEDURE IF EXISTS suntrack19_auto;
DELIMITER //
CREATE PROCEDURE suntrack19_auto()
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
                   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'subcontractor_assignments' AND COLUMN_NAME = 'auto_assigned') THEN
        ALTER TABLE subcontractor_assignments
            ADD COLUMN auto_assigned     TINYINT(1)   NOT NULL DEFAULT 0 AFTER assigned_by,
            ADD COLUMN assignment_reason VARCHAR(255) NULL AFTER auto_assigned,
            ADD COLUMN offer_expires_at  DATETIME     NULL AFTER assignment_reason,
            ADD KEY idx_sa_offer (status, offer_expires_at);
    END IF;
END //
DELIMITER ;
CALL suntrack19_auto();
DROP PROCEDURE IF EXISTS suntrack19_auto;

-- Field profile: each subcontractor company works its accepted jobs through
-- the same field portal as technicians (GPS Time In / Out, checklists, stage
-- photos, work reports). It does that as a technicians row linked to the
-- company (technicians.subcontractor_id). Those rows are not company
-- technicians: they are left out of technician lists, slots and dropdowns.
DROP PROCEDURE IF EXISTS suntrack19_field;
DELIMITER //
CREATE PROCEDURE suntrack19_field()
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
                   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'technicians' AND COLUMN_NAME = 'subcontractor_id') THEN
        ALTER TABLE technicians
            ADD COLUMN subcontractor_id INT UNSIGNED NULL AFTER user_id,
            ADD UNIQUE KEY uq_tech_subcon (subcontractor_id),
            ADD CONSTRAINT fk_tech_subcon FOREIGN KEY (subcontractor_id) REFERENCES subcontractors (id) ON DELETE CASCADE;
    END IF;
END //
DELIMITER ;
CALL suntrack19_field();
DROP PROCEDURE IF EXISTS suntrack19_field;

CREATE TABLE IF NOT EXISTS subcontractor_events (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    assignment_id    INT UNSIGNED NULL,
    subcontractor_id INT UNSIGNED NOT NULL,
    action           VARCHAR(40)  NOT NULL,
    from_status      VARCHAR(30)  NULL,
    to_status        VARCHAR(30)  NULL,
    note             VARCHAR(500) NULL,
    actor_user_id    INT UNSIGNED NULL,
    actor_role       VARCHAR(20)  NULL,
    created_at       DATETIME     NOT NULL,
    KEY idx_se_assignment (assignment_id, id),
    KEY idx_se_subcon (subcontractor_id, id),
    CONSTRAINT fk_se_assignment FOREIGN KEY (assignment_id) REFERENCES subcontractor_assignments (id) ON DELETE CASCADE,
    CONSTRAINT fk_se_subcon FOREIGN KEY (subcontractor_id) REFERENCES subcontractors (id) ON DELETE CASCADE,
    CONSTRAINT fk_se_actor FOREIGN KEY (actor_user_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS subcontractor_files (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    assignment_id    INT UNSIGNED  NOT NULL,
    category         ENUM('COMPLETION_PHOTO','INSPECTION_EVIDENCE','SUPPORTING_DOCUMENT','INVOICE','ASSIGNMENT_ATTACHMENT') NOT NULL,
    submission_round SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    file_name        VARCHAR(80)   NOT NULL,
    original_name    VARCHAR(150)  NOT NULL,
    mime             VARCHAR(60)   NOT NULL,
    size_bytes       INT UNSIGNED  NOT NULL,
    uploaded_by      INT UNSIGNED  NULL,
    created_at       DATETIME      NOT NULL,
    KEY idx_sf_assignment (assignment_id, category),
    CONSTRAINT fk_sf_assignment FOREIGN KEY (assignment_id) REFERENCES subcontractor_assignments (id) ON DELETE CASCADE,
    CONSTRAINT fk_sf_user FOREIGN KEY (uploaded_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS subcontractor_variations (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    assignment_id INT UNSIGNED  NOT NULL,
    description   VARCHAR(255)  NOT NULL,
    amount        DECIMAL(14,2) NOT NULL,
    status        ENUM('APPROVED','VOIDED') NOT NULL DEFAULT 'APPROVED',
    approved_by   INT UNSIGNED  NULL,
    approved_at   DATETIME      NOT NULL,
    voided_by     INT UNSIGNED  NULL,
    voided_at     DATETIME      NULL,
    void_reason   VARCHAR(255)  NULL,
    KEY idx_sv_assignment (assignment_id),
    CONSTRAINT fk_sv_assignment FOREIGN KEY (assignment_id) REFERENCES subcontractor_assignments (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS subcontractor_invoices (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    assignment_id    INT UNSIGNED  NOT NULL,
    subcontractor_id INT UNSIGNED  NOT NULL,
    invoice_ref      VARCHAR(50)   NOT NULL,
    amount           DECIMAL(14,2) NOT NULL,
    submitted_at     DATETIME      NOT NULL,
    submitted_by     INT UNSIGNED  NULL,
    notes            VARCHAR(500)  NULL,
    status           ENUM('SUBMITTED','UNDER_REVIEW','REVISION_REQUIRED','APPROVED','PARTIALLY_PAID','PAID','REJECTED') NOT NULL DEFAULT 'SUBMITTED',
    approved_amount  DECIMAL(14,2) NULL,
    due_date         DATE          NULL,
    reviewed_at      DATETIME      NULL,
    reviewed_by      INT UNSIGNED  NULL,
    review_note      VARCHAR(500)  NULL,
    request_key      VARCHAR(64)   NULL,
    created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_si_ref (subcontractor_id, invoice_ref),
    UNIQUE KEY uq_si_request (request_key),
    KEY idx_si_assignment (assignment_id),
    CONSTRAINT fk_si_assignment FOREIGN KEY (assignment_id) REFERENCES subcontractor_assignments (id),
    CONSTRAINT fk_si_subcon FOREIGN KEY (subcontractor_id) REFERENCES subcontractors (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS subcontractor_payments (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    invoice_id  INT UNSIGNED  NOT NULL,
    amount      DECIMAL(14,2) NOT NULL,
    method      VARCHAR(30)   NOT NULL,
    reference   VARCHAR(60)   NOT NULL,
    paid_at     DATETIME      NOT NULL,
    recorded_by INT UNSIGNED  NULL,
    request_key VARCHAR(64)   NULL,
    voided_at   DATETIME      NULL,
    voided_by   INT UNSIGNED  NULL,
    void_reason VARCHAR(255)  NULL,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_sp_request (request_key),
    KEY idx_sp_invoice (invoice_id, voided_at),
    CONSTRAINT fk_sp_invoice FOREIGN KEY (invoice_id) REFERENCES subcontractor_invoices (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Automatic assignment defaults (changeable in Management > Sub-contractors).
INSERT INTO settings (setting_key, setting_value)
SELECT k, v FROM (
    SELECT 'subcon_auto_mode' AS k, 'auto' AS v UNION ALL
    SELECT 'tech_max_open_jobs', '4' UNION ALL
    SELECT 'subcon_capacity_threshold', '85' UNION ALL
    SELECT 'subcon_offer_hours', '24'
) d
WHERE NOT EXISTS (SELECT 1 FROM settings s WHERE s.setting_key = d.k);
