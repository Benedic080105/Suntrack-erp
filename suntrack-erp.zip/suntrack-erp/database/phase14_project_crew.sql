-- =====================================================================
-- SunTrack ERP — Phase 14: site size and installation crews
--
--   projects.site_size   SMALL / MEDIUM / LARGE — worked out from the
--                        system's kW (includes/crew_lib.php), or set by hand
--   projects.crew_size   how many technicians the installation needs
--                        (recommended from the size; Management may change it)
--   project_crew         the extra technicians on the installation. The lead
--                        stays in projects.assigned_technician_id (and the
--                        job's technician_id); everyone here helps on site.
--
-- Safe to re-run: columns are added only once, the table only if missing.
-- Existing projects get their size from capacity_kw.
-- =====================================================================

DROP PROCEDURE IF EXISTS suntrack14_crew;
DELIMITER //
CREATE PROCEDURE suntrack14_crew()
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
                   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'site_size') THEN
        ALTER TABLE projects ADD COLUMN site_size ENUM('SMALL','MEDIUM','LARGE') NULL AFTER capacity_kw;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
                   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'projects' AND COLUMN_NAME = 'crew_size') THEN
        ALTER TABLE projects ADD COLUMN crew_size TINYINT UNSIGNED NULL AFTER site_size;
    END IF;
END //
DELIMITER ;
CALL suntrack14_crew();
DROP PROCEDURE IF EXISTS suntrack14_crew;

CREATE TABLE IF NOT EXISTS project_crew (
    project_id    INT UNSIGNED NOT NULL,
    technician_id INT UNSIGNED NOT NULL,
    added_by      INT UNSIGNED NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (project_id, technician_id),
    CONSTRAINT fk_pc_project FOREIGN KEY (project_id)    REFERENCES projects(id)    ON DELETE CASCADE,
    CONSTRAINT fk_pc_tech    FOREIGN KEY (technician_id) REFERENCES technicians(id) ON DELETE CASCADE,
    CONSTRAINT fk_pc_user    FOREIGN KEY (added_by)      REFERENCES users(id)       ON DELETE SET NULL,
    INDEX idx_pc_tech (technician_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Existing projects: size from kW (same thresholds as crew_lib.php's defaults).
UPDATE projects
SET site_size = CASE WHEN capacity_kw < 5 THEN 'SMALL' WHEN capacity_kw < 10 THEN 'MEDIUM' ELSE 'LARGE' END
WHERE site_size IS NULL AND capacity_kw IS NOT NULL;
