<?php
/**
 * SunTrack ERP — Phase 9 backfill: installed equipment for systems completed
 * before the change. Run once, after phase9_installed_equipment.sql:
 *
 *   php database/phase9_backfill_installed_equipment.php
 *
 * For every completed (or under-maintenance) project, the solar system's
 * Panel / Inverter / Battery are set to the stock actually issued for its
 * installation — the same function a technician's completion now calls. A
 * category with nothing issued keeps the text already on file. Safe to re-run.
 *
 * Command line only: refuses a browser, and database/ is blocked by .htaccess.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/project_lib.php';

$pdo = db();
$projects = $pdo->query(
    "SELECT p.id, p.project_code, s.system_code
     FROM projects p JOIN solar_systems s ON s.id = p.solar_system_id
     WHERE p.status IN ('COMPLETED', 'MAINTENANCE')
     ORDER BY p.id"
)->fetchAll();

$updated = 0;
foreach ($projects as $p) {
    $equipment = project_installed_equipment((int)$p['id']);
    if (!$equipment) {
        echo "{$p['project_code']} / {$p['system_code']}: no stock issued — left as it is\n";
        continue;
    }
    project_record_installed_equipment((int)$p['id']);
    $updated++;
    echo "{$p['project_code']} / {$p['system_code']}: " . implode(' | ', array_map(
        fn($cat, $items) => $cat . ': ' . system_equipment_text($items), array_keys($equipment), $equipment
    )) . "\n";
}
echo "\nDone: $updated of " . count($projects) . " completed installations updated from the warehouse records.\n";
