-- ============================================================================
-- SunTrack ERP — Phase 6 Migration
-- Self-service "Forgot password" for client and technician accounts.
--
-- Safe to run more than once. It never drops a table and never deletes a row.
--
--   mysql -u root suntrack_erp < database/phase6_password_resets.sql
--
-- Only a SHA-256 hash of each reset token is stored, so someone who can read
-- this table still cannot use a pending link. Tokens are single-use, expire
-- after 30 minutes, and requesting a new one voids the older ones.
-- ============================================================================

CREATE TABLE IF NOT EXISTS password_resets (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    token_hash CHAR(64) NOT NULL UNIQUE,
    expires_at DATETIME NOT NULL,
    used_at DATETIME NULL,
    requested_ip VARCHAR(45) NULL,
    created_at DATETIME NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_pr_user (user_id, created_at),
    INDEX idx_pr_ip (requested_ip, created_at)
) ENGINE=InnoDB;

-- ============================================================================
-- End of Phase 6 migration.
-- ============================================================================
