-- ============================================================================
-- SunTrack ERP — Phase 5 Migration: Service Requests
--
-- Safe to run more than once. Every statement is guarded, so re-running this
-- file is a no-op. It never drops a table and never deletes a row.
--
--   mysql -u root suntrack_erp < database/phase5_service_requests.sql
--
-- or phpMyAdmin → select the `suntrack_erp` database → Import this file.
--
-- Run it after phases 1–4 (it does not depend on phase 6 or 7, and they do
-- not depend on it).
--
-- What it changes, and why:
--
--   1. service_requests (EXISTING table, extended — no second table)
--        subject, created_by, scheduled_date, site_address,
--        location_lat / location_lng, technician_notes, resolution,
--        created_at (+ updated_at, identical to phase 4, in case phase 4
--        was skipped). The status list gains SCHEDULED and ON_HOLD.
--        request_type stays the "service type" column, date_requested the
--        requested date and completion_date the completed date, so every
--        existing query keeps working unchanged.
--
--   2. service_request_history (NEW)
--        One row per thing that happened to a request: created, approved,
--        assigned, scheduled, status changed, note added, cancelled... so
--        Management and Admin can see the full story of every request.
--
--   3. clients (EXISTING table, extended)
--        barangay and postal_code for complete addresses. lat / lng /
--        geofence_radius_m are the phase 3 columns; they are re-checked here
--        only so a database that skipped phase 3 still ends up with them.
--
--   4. Backfills for rows that already exist: subject from request_type,
--        location from the client's pin, scheduled date from the linked job,
--        and a "created" history row for every request without history.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- Guarded helpers. Dropped again at the end of the file.
-- ---------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS suntrack5_add_column;
DROP PROCEDURE IF EXISTS suntrack5_add_index;
DROP PROCEDURE IF EXISTS suntrack5_add_fk;
DROP PROCEDURE IF EXISTS suntrack5_extend_sr_status;
DROP PROCEDURE IF EXISTS suntrack5_add_sr_created_at;

DELIMITER //

CREATE PROCEDURE suntrack5_add_column(
    IN p_table  VARCHAR(64),
    IN p_column VARCHAR(64),
    IN p_ddl    VARCHAR(1024)
)
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME   = p_table
          AND COLUMN_NAME  = p_column
    ) THEN
        SET @sql = p_ddl;
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END //

-- Adds an index unless one with this name exists OR another index already
-- leads with the same column (e.g. the index MySQL created for a foreign key),
-- so the table never carries two identical indexes.
CREATE PROCEDURE suntrack5_add_index(
    IN p_table  VARCHAR(64),
    IN p_index  VARCHAR(64),
    IN p_column VARCHAR(64),
    IN p_ddl    VARCHAR(1024)
)
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME   = p_table
          AND (INDEX_NAME = p_index OR (COLUMN_NAME = p_column AND SEQ_IN_INDEX = 1))
    ) THEN
        SET @sql = p_ddl;
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END //

CREATE PROCEDURE suntrack5_add_fk(
    IN p_table      VARCHAR(64),
    IN p_constraint VARCHAR(64),
    IN p_ddl        VARCHAR(1024)
)
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.TABLE_CONSTRAINTS
        WHERE CONSTRAINT_SCHEMA = DATABASE()
          AND TABLE_NAME        = p_table
          AND CONSTRAINT_NAME   = p_constraint
          AND CONSTRAINT_TYPE   = 'FOREIGN KEY'
    ) THEN
        SET @sql = p_ddl;
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END //

-- The status list is only ever widened. Every existing value is kept, so no
-- stored row can be truncated by the change.
CREATE PROCEDURE suntrack5_extend_sr_status()
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME   = 'service_requests'
          AND COLUMN_NAME  = 'status'
          AND (LOCATE('SCHEDULED', COLUMN_TYPE) = 0 OR LOCATE('ON_HOLD', COLUMN_TYPE) = 0)
    ) THEN
        ALTER TABLE service_requests
            MODIFY COLUMN status ENUM(
                'PENDING','APPROVED','ASSIGNED','SCHEDULED','IN_PROGRESS',
                'ON_HOLD','COMPLETED','CANCELLED','REJECTED'
            ) NOT NULL DEFAULT 'PENDING';
    END IF;
END //

-- created_at is backfilled from date_requested only at the moment the column
-- is first added, so a re-run never rewrites it.
CREATE PROCEDURE suntrack5_add_sr_created_at()
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME   = 'service_requests'
          AND COLUMN_NAME  = 'created_at'
    ) THEN
        ALTER TABLE service_requests
            ADD COLUMN created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER completion_date;

        IF EXISTS (
            SELECT 1 FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME   = 'service_requests'
              AND COLUMN_NAME  = 'updated_at'
        ) THEN
            -- updated_at = updated_at keeps ON UPDATE from moving it.
            UPDATE service_requests
            SET created_at = date_requested, updated_at = updated_at
            WHERE date_requested IS NOT NULL;
        ELSE
            UPDATE service_requests
            SET created_at = date_requested
            WHERE date_requested IS NOT NULL;
        END IF;
    END IF;
END //

DELIMITER ;

-- ---------------------------------------------------------------------------
-- 1. Client location + complete address.
--    lat / lng / geofence_radius_m use exactly the phase 3 definitions.
-- ---------------------------------------------------------------------------
CALL suntrack5_add_column('clients', 'lat',
    'ALTER TABLE clients ADD COLUMN lat DECIMAL(10,7) NULL AFTER province');

CALL suntrack5_add_column('clients', 'lng',
    'ALTER TABLE clients ADD COLUMN lng DECIMAL(10,7) NULL AFTER lat');

CALL suntrack5_add_column('clients', 'geofence_radius_m',
    'ALTER TABLE clients ADD COLUMN geofence_radius_m SMALLINT UNSIGNED NOT NULL DEFAULT 500 AFTER lng');

CALL suntrack5_add_column('clients', 'barangay',
    'ALTER TABLE clients ADD COLUMN barangay VARCHAR(100) NULL AFTER address');

CALL suntrack5_add_column('clients', 'postal_code',
    'ALTER TABLE clients ADD COLUMN postal_code VARCHAR(10) NULL AFTER province');

CALL suntrack5_add_index('clients', 'idx_clients_geo', 'lat',
    'ALTER TABLE clients ADD INDEX idx_clients_geo (lat, lng)');

-- ---------------------------------------------------------------------------
-- 2. Service request columns.
-- ---------------------------------------------------------------------------
CALL suntrack5_add_column('service_requests', 'subject',
    'ALTER TABLE service_requests ADD COLUMN subject VARCHAR(150) NULL AFTER request_type');

CALL suntrack5_add_column('service_requests', 'created_by',
    'ALTER TABLE service_requests ADD COLUMN created_by INT UNSIGNED NULL AFTER client_id');

CALL suntrack5_add_column('service_requests', 'scheduled_date',
    'ALTER TABLE service_requests ADD COLUMN scheduled_date DATE NULL AFTER date_requested');

CALL suntrack5_add_column('service_requests', 'site_address',
    'ALTER TABLE service_requests ADD COLUMN site_address VARCHAR(255) NULL AFTER description');

-- DECIMAL(10,7) matches clients.lat/lng and jobs.site_lat/site_lng exactly.
CALL suntrack5_add_column('service_requests', 'location_lat',
    'ALTER TABLE service_requests ADD COLUMN location_lat DECIMAL(10,7) NULL AFTER site_address');

CALL suntrack5_add_column('service_requests', 'location_lng',
    'ALTER TABLE service_requests ADD COLUMN location_lng DECIMAL(10,7) NULL AFTER location_lat');

CALL suntrack5_add_column('service_requests', 'technician_notes',
    'ALTER TABLE service_requests ADD COLUMN technician_notes TEXT NULL AFTER assigned_technician_id');

CALL suntrack5_add_column('service_requests', 'resolution',
    'ALTER TABLE service_requests ADD COLUMN resolution TEXT NULL AFTER technician_notes');

-- Same definition as phase 4; skipped when phase 4 already added it.
CALL suntrack5_add_column('service_requests', 'updated_at',
    'ALTER TABLE service_requests ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER completion_date');

CALL suntrack5_add_sr_created_at();

CALL suntrack5_extend_sr_status();

-- created_by -> users. SET NULL so deleting a staff login never deletes the
-- request it once raised.
CALL suntrack5_add_fk('service_requests', 'fk_sr_created_by',
    'ALTER TABLE service_requests ADD CONSTRAINT fk_sr_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL');

-- ---------------------------------------------------------------------------
-- 3. Indexes for the columns every list, map and dashboard filters on.
--    client_id / status / assigned_technician_id usually exist already
--    (idx_sr_client, idx_sr_status, and the foreign-key index) and are skipped.
-- ---------------------------------------------------------------------------
CALL suntrack5_add_index('service_requests', 'idx_sr_client', 'client_id',
    'ALTER TABLE service_requests ADD INDEX idx_sr_client (client_id)');

CALL suntrack5_add_index('service_requests', 'idx_sr_technician', 'assigned_technician_id',
    'ALTER TABLE service_requests ADD INDEX idx_sr_technician (assigned_technician_id)');

CALL suntrack5_add_index('service_requests', 'idx_sr_status', 'status',
    'ALTER TABLE service_requests ADD INDEX idx_sr_status (status)');

CALL suntrack5_add_index('service_requests', 'idx_sr_priority', 'priority',
    'ALTER TABLE service_requests ADD INDEX idx_sr_priority (priority)');

CALL suntrack5_add_index('service_requests', 'idx_sr_created', 'created_at',
    'ALTER TABLE service_requests ADD INDEX idx_sr_created (created_at)');

CALL suntrack5_add_index('service_requests', 'idx_sr_scheduled', 'scheduled_date',
    'ALTER TABLE service_requests ADD INDEX idx_sr_scheduled (scheduled_date)');

CALL suntrack5_add_index('service_requests', 'idx_sr_requested', 'date_requested',
    'ALTER TABLE service_requests ADD INDEX idx_sr_requested (date_requested)');

CALL suntrack5_add_index('service_requests', 'idx_sr_updated', 'updated_at',
    'ALTER TABLE service_requests ADD INDEX idx_sr_updated (updated_at)');

-- ---------------------------------------------------------------------------
-- 4. History / audit trail.
--    old_status / new_status are VARCHAR rather than ENUM so the history can
--    never reject a row because the status list grew later.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS service_request_history (
    id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    service_request_id INT UNSIGNED NOT NULL,
    user_id            INT UNSIGNED NULL,          -- users.id; NULL = system
    action             VARCHAR(40)  NOT NULL,      -- CREATED, APPROVED, ASSIGNED, SCHEDULED, STATUS_CHANGED, NOTE_ADDED, ...
    old_status         VARCHAR(20)  NULL,
    new_status         VARCHAR(20)  NULL,
    remarks            VARCHAR(1000) NULL,
    created_at         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_srh_request FOREIGN KEY (service_request_id) REFERENCES service_requests(id) ON DELETE CASCADE,
    CONSTRAINT fk_srh_user    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_srh_request (service_request_id, id),
    INDEX idx_srh_created (created_at),
    INDEX idx_srh_action (action)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 5. Backfills. Each only fills values that are still empty, and each keeps
--    updated_at where it was (updated_at = updated_at), so the real-time
--    feed does not report every request as just changed.
-- ---------------------------------------------------------------------------

-- Subject defaults to the service type.
UPDATE service_requests
SET subject = LEFT(request_type, 150), updated_at = updated_at
WHERE subject IS NULL AND request_type IS NOT NULL;

-- Service location defaults to the client's plotted site.
UPDATE service_requests sr
JOIN clients c ON c.id = sr.client_id
SET sr.location_lat = c.lat,
    sr.location_lng = c.lng,
    sr.updated_at   = sr.updated_at
WHERE sr.location_lat IS NULL AND sr.location_lng IS NULL
  AND c.lat IS NOT NULL AND c.lng IS NOT NULL;

UPDATE service_requests sr
JOIN clients c ON c.id = sr.client_id
SET sr.site_address = LEFT(CONCAT_WS(', ', NULLIF(c.address, ''), NULLIF(c.barangay, ''), NULLIF(c.city, ''), NULLIF(c.province, '')), 255),
    sr.updated_at   = sr.updated_at
WHERE sr.site_address IS NULL
  AND COALESCE(c.address, c.city) IS NOT NULL;

-- Scheduled date follows the linked job, when the job has one.
UPDATE service_requests sr
JOIN jobs j ON j.id = sr.job_id
SET sr.scheduled_date = j.scheduled_date,
    sr.updated_at     = sr.updated_at
WHERE sr.scheduled_date IS NULL AND j.scheduled_date IS NOT NULL;

-- Every request gets at least its "created" history row.
INSERT INTO service_request_history (service_request_id, user_id, action, old_status, new_status, remarks, created_at)
SELECT sr.id, sr.created_by, 'CREATED', NULL, 'PENDING',
       'Recorded by the Phase 5 migration (request existed before history tracking).',
       COALESCE(sr.date_requested, NOW())
FROM service_requests sr
WHERE NOT EXISTS (SELECT 1 FROM service_request_history h WHERE h.service_request_id = sr.id);

-- ...and, when it has already moved on, one row bringing it to its current status.
INSERT INTO service_request_history (service_request_id, user_id, action, old_status, new_status, remarks, created_at)
SELECT sr.id, NULL, 'STATUS_CHANGED', 'PENDING', sr.status,
       'Status at the time history tracking was enabled.',
       sr.updated_at
FROM service_requests sr
WHERE sr.status <> 'PENDING'
  AND NOT EXISTS (
      SELECT 1 FROM service_request_history h
      WHERE h.service_request_id = sr.id AND h.action <> 'CREATED'
  );

DROP PROCEDURE IF EXISTS suntrack5_add_column;
DROP PROCEDURE IF EXISTS suntrack5_add_index;
DROP PROCEDURE IF EXISTS suntrack5_add_fk;
DROP PROCEDURE IF EXISTS suntrack5_extend_sr_status;
DROP PROCEDURE IF EXISTS suntrack5_add_sr_created_at;

-- ============================================================================
-- End of Phase 5 migration.
-- ============================================================================
