-- =====================================================================
-- SunTrack ERP — Phase 9: installed equipment on the client's solar system
--
-- When an installation is completed, the system's Panel / Inverter / Battery
-- are set to the exact stock items issued for it, e.g.
--   "LONGi Hi-MO 6 545W Panel (ST-INV-9002) × 15"
-- (includes/project_lib.php, project_record_installed_equipment()).
--
--   1. panel_brand / inverter_brand / battery_brand widened from 100 to 255
--      characters, so a system built from two or three items fits.
--   2. Installed systems with no installation date get the day their
--      installation job was completed (else the project's installation date).
--
-- Then fill in the equipment for installations completed before this change:
--   php database/phase9_backfill_installed_equipment.php
--
-- Safe to re-run: widening is a no-op the second time, and step 2 only
-- touches rows whose date is still empty.
-- =====================================================================

ALTER TABLE solar_systems
    MODIFY COLUMN panel_brand    VARCHAR(255) NULL,
    MODIFY COLUMN inverter_brand VARCHAR(255) NULL,
    MODIFY COLUMN battery_brand  VARCHAR(255) NULL;

UPDATE solar_systems s
JOIN projects p ON p.solar_system_id = s.id
SET s.installation_date = COALESCE(
        (SELECT DATE(MIN(h.created_at))
           FROM job_status_history h JOIN jobs j ON j.id = h.job_id
          WHERE j.project_id = p.id AND j.job_type = 'INSTALLATION' AND h.to_stage = 'COMPLETED'),
        p.installation_date)
WHERE s.installation_date IS NULL
  AND s.status IN ('ACTIVE', 'FAULT', 'DECOMMISSIONED');
