-- =====================================================================
-- SUNTRACK ERP — PHASE 1 (TECHNICIAN PORTAL) MIGRATION
-- =====================================================================
-- Run this ONCE against an existing suntrack_erp database, e.g.
--   mysql -u root suntrack_erp < database/phase1_technician_migration.sql
-- or paste it into phpMyAdmin's SQL tab with `suntrack_erp` selected.
--
-- It does NOT drop the database, does NOT drop any table, and does NOT
-- touch any existing row. Every statement is guarded, so running it a
-- second time is harmless.
--
-- Phase 1 was built deliberately on the existing schema — no new tables
-- were needed. This file only adds:
--   1. a UNIQUE index on work_reports.job_id, so "one report per job" is
--      guaranteed by the database and a double-clicked Submit button can
--      never create two rows;
--   2. supporting indexes for the geofence location trail and job status
--      timeline, which Phase 1 now reads on every poll.
--
-- If you are importing database/suntrack_erp.sql fresh, you can still run
-- this afterwards — it will simply add the indexes.
-- =====================================================================

USE suntrack_erp;

-- ---------------------------------------------------------------------
-- Guarded index helper: adds an index only when it does not already exist.
-- ---------------------------------------------------------------------
DROP PROCEDURE IF EXISTS suntrack_add_index;

DELIMITER //
CREATE PROCEDURE suntrack_add_index(
    IN p_table VARCHAR(64),
    IN p_index VARCHAR(64),
    IN p_ddl   VARCHAR(512)
)
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME   = p_table
          AND INDEX_NAME   = p_index
    ) THEN
        SET @sql = p_ddl;
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END //
DELIMITER ;

-- ---------------------------------------------------------------------
-- 1. One work report per job — enforced by the database.
--    Safety net: if historical data somehow contains duplicates, the
--    ALTER below fails loudly rather than silently deleting anything.
--    Resolve duplicates by hand first, then re-run this file.
-- ---------------------------------------------------------------------
CALL suntrack_add_index(
    'work_reports',
    'uq_work_reports_job',
    'ALTER TABLE work_reports ADD UNIQUE KEY uq_work_reports_job (job_id)'
);

-- ---------------------------------------------------------------------
-- 2. Location trail lookups: "latest ping for this technician / job".
-- ---------------------------------------------------------------------
CALL suntrack_add_index(
    'geofence_records',
    'idx_geo_tech_time',
    'ALTER TABLE geofence_records ADD INDEX idx_geo_tech_time (technician_id, recorded_at)'
);

CALL suntrack_add_index(
    'geofence_records',
    'idx_geo_job_tech',
    'ALTER TABLE geofence_records ADD INDEX idx_geo_job_tech (job_id, technician_id, id)'
);

-- ---------------------------------------------------------------------
-- 3. Job status timeline + undo both read the newest history row first.
-- ---------------------------------------------------------------------
CALL suntrack_add_index(
    'job_status_history',
    'idx_jsh_job_created',
    'ALTER TABLE job_status_history ADD INDEX idx_jsh_job_created (job_id, id)'
);

-- ---------------------------------------------------------------------
-- 4. Attendance lookups per technician + job (open time-in checks).
-- ---------------------------------------------------------------------
CALL suntrack_add_index(
    'attendance',
    'idx_att_job_tech',
    'ALTER TABLE attendance ADD INDEX idx_att_job_tech (job_id, technician_id, id)'
);

DROP PROCEDURE IF EXISTS suntrack_add_index;

-- =====================================================================
-- End of Phase 1 migration.
-- =====================================================================
