-- ============================================================================
-- SunTrack ERP — Phase 5 Migration: Material Requests ("client orders")
--
-- Management tells the Warehouse how many solar panels, inverters and
-- batteries a client needs; the Warehouse scans items out against the order
-- until every line is filled (READY), then releases it (RELEASED).
--
-- Used by: includes/material_lib.php, api/material_requests/*,
--          api/projects/create.php, api/warehouse/reports.php,
--          api/scan/lookup.php, api/realtime/sync.php,
--          the Management "Material Requests" tab and the Warehouse
--          "Client Orders" tab.
--
-- Safe to run more than once. It never drops a table and never deletes a row.
--
--   mysql -u root suntrack_erp < database/phase5_material_requests.sql
--
-- Can be imported before or after phase5_service_requests.sql.
-- ============================================================================

-- One order per client request. Status is recomputed from the lines by
-- mr_recalc(): PENDING (nothing scanned) -> PREPARING -> READY (every line
-- filled) -> RELEASED (handed over). CANCELLED only while nothing is scanned.
CREATE TABLE IF NOT EXISTS material_requests (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_code  VARCHAR(20)  NOT NULL UNIQUE,              -- MR-2026-0001
    client_id     INT UNSIGNED NOT NULL,
    project_id    INT UNSIGNED NULL,
    job_id        INT UNSIGNED NULL,
    status        ENUM('PENDING','PREPARING','READY','RELEASED','CANCELLED') NOT NULL DEFAULT 'PENDING',
    needed_by     DATE         NULL,
    notes         VARCHAR(255) NULL,
    requested_by  INT UNSIGNED NULL,                         -- users.id (Management)
    ready_at      DATETIME     NULL,
    released_at   DATETIME     NULL,
    released_by   INT UNSIGNED NULL,                         -- users.id (Warehouse)
    released_to   VARCHAR(150) NULL,                         -- who physically received it
    created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_mr_client       FOREIGN KEY (client_id)    REFERENCES clients(id)  ON DELETE CASCADE,
    CONSTRAINT fk_mr_project      FOREIGN KEY (project_id)   REFERENCES projects(id) ON DELETE SET NULL,
    CONSTRAINT fk_mr_job          FOREIGN KEY (job_id)       REFERENCES jobs(id)     ON DELETE SET NULL,
    CONSTRAINT fk_mr_requested_by FOREIGN KEY (requested_by) REFERENCES users(id)    ON DELETE SET NULL,
    CONSTRAINT fk_mr_released_by  FOREIGN KEY (released_by)  REFERENCES users(id)    ON DELETE SET NULL,
    INDEX idx_mr_status (status, needed_by),
    INDEX idx_mr_client (client_id),
    INDEX idx_mr_created (created_at),
    INDEX idx_mr_updated (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- One line per stock category on an order (Solar Panel / Inverter / Battery).
-- category_id matches inventory_categories.id (TINYINT UNSIGNED).
CREATE TABLE IF NOT EXISTS material_request_items (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id    INT UNSIGNED     NOT NULL,
    category_id   TINYINT UNSIGNED NOT NULL,
    qty_required  INT UNSIGNED     NOT NULL,
    qty_prepared  INT UNSIGNED     NOT NULL DEFAULT 0,
    CONSTRAINT fk_mri_request  FOREIGN KEY (request_id)  REFERENCES material_requests(id) ON DELETE CASCADE,
    CONSTRAINT fk_mri_category FOREIGN KEY (category_id) REFERENCES inventory_categories(id),
    UNIQUE KEY uq_mri_line (request_id, category_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- stock_movements.material_request_id: every unit scanned onto an order is an
-- ordinary ISSUE movement tagged with the order (RETURN when taken back off).
-- ---------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS suntrack5m_upgrade;

DELIMITER //
CREATE PROCEDURE suntrack5m_upgrade()
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'stock_movements' AND COLUMN_NAME = 'material_request_id'
    ) THEN
        ALTER TABLE stock_movements ADD COLUMN material_request_id INT UNSIGNED NULL AFTER job_id;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'stock_movements' AND INDEX_NAME = 'idx_move_mr'
    ) THEN
        ALTER TABLE stock_movements ADD INDEX idx_move_mr (material_request_id, inventory_id);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.TABLE_CONSTRAINTS
        WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = 'stock_movements'
          AND CONSTRAINT_NAME = 'fk_move_mr' AND CONSTRAINT_TYPE = 'FOREIGN KEY'
    ) THEN
        ALTER TABLE stock_movements
            ADD CONSTRAINT fk_move_mr FOREIGN KEY (material_request_id) REFERENCES material_requests(id) ON DELETE SET NULL;
    END IF;
END //
DELIMITER ;

CALL suntrack5m_upgrade();
DROP PROCEDURE IF EXISTS suntrack5m_upgrade;

-- ============================================================================
-- End of Phase 5 (material requests) migration.
-- ============================================================================
