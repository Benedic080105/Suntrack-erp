-- =====================================================================
-- SunTrack ERP — Phase 8: inventory status by a fixed 50-unit threshold
--
-- Stock status no longer follows each item's reorder level. The rule is now
-- (includes/helpers.php, inventory_status() / INVENTORY_LOW_STOCK_BELOW):
--     0 or less      OUT_OF_STOCK
--     1 – 49         LOW_STOCK
--     50 or more     ACTIVE
-- New stock movements apply it automatically; this re-applies it once to the
-- rows already in the table. DISCONTINUED items are left alone.
--
-- Safe to re-run: it only rewrites the status column to what the rule says.
-- If INVENTORY_LOW_STOCK_BELOW is ever changed, change the 50 below to match.
-- =====================================================================

UPDATE inventory
SET status = CASE
        WHEN quantity <= 0 THEN 'OUT_OF_STOCK'
        WHEN quantity < 50 THEN 'LOW_STOCK'
        ELSE 'ACTIVE'
    END
WHERE status <> 'DISCONTINUED';
