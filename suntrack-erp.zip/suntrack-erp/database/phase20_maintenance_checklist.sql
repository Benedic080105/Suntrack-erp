-- =====================================================================
-- SunTrack ERP — Phase 20: maintenance checklist like the installation one
--
-- The maintenance inspection now works the way the installation checklist
-- does:
--   maintenance_items    + completed_at / completed_by — who ticked each item
--                          and when (shown under the item, like installation)
--   maintenance_photos     proof photos per section (Solar Panels, Battery,
--                          Inverter) — at least one each before submitting
--   maintenance_records  + review: the technician submits the inspection,
--                          Management approves it or returns it with a note;
--                          the job can be completed once it is approved
--
-- Safe to re-run. phpMyAdmin: select suntrack_erp > Import > this file > Go.
-- =====================================================================

DROP PROCEDURE IF EXISTS suntrack20_upgrade;
DELIMITER //
CREATE PROCEDURE suntrack20_upgrade()
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
                   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'maintenance_items' AND COLUMN_NAME = 'completed_at') THEN
        ALTER TABLE maintenance_items
            ADD COLUMN completed_at DATETIME NULL AFTER remarks,
            ADD COLUMN completed_by INT UNSIGNED NULL AFTER completed_at,
            ADD CONSTRAINT fk_mi_completed_by FOREIGN KEY (completed_by) REFERENCES users (id) ON DELETE SET NULL;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
                   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'maintenance_records' AND COLUMN_NAME = 'review_status') THEN
        ALTER TABLE maintenance_records
            ADD COLUMN review_status ENUM('OPEN','SUBMITTED','APPROVED','RETURNED') NOT NULL DEFAULT 'OPEN' AFTER status,
            ADD COLUMN submitted_at  DATETIME NULL AFTER review_status,
            ADD COLUMN submitted_by  INT UNSIGNED NULL AFTER submitted_at,
            ADD COLUMN submit_note   VARCHAR(500) NULL AFTER submitted_by,
            ADD COLUMN reviewed_at   DATETIME NULL AFTER submit_note,
            ADD COLUMN reviewed_by   INT UNSIGNED NULL AFTER reviewed_at,
            ADD COLUMN review_note   VARCHAR(500) NULL AFTER reviewed_by,
            ADD KEY idx_mr_review (review_status),
            ADD CONSTRAINT fk_mr_submitted_by FOREIGN KEY (submitted_by) REFERENCES users (id) ON DELETE SET NULL,
            ADD CONSTRAINT fk_mr_reviewed_by FOREIGN KEY (reviewed_by) REFERENCES users (id) ON DELETE SET NULL;
        -- Inspections finished before this phase count as approved.
        UPDATE maintenance_records SET review_status = 'APPROVED' WHERE status = 'COMPLETED';
    END IF;
END //
DELIMITER ;
CALL suntrack20_upgrade();
DROP PROCEDURE IF EXISTS suntrack20_upgrade;

CREATE TABLE IF NOT EXISTS maintenance_photos (
    id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    maintenance_id INT UNSIGNED NOT NULL,
    job_id         INT UNSIGNED NOT NULL,
    section        VARCHAR(50)  NOT NULL,
    uploaded_by    INT UNSIGNED NULL,
    file_name      VARCHAR(80)  NOT NULL,
    mime           VARCHAR(30)  NOT NULL,
    size_bytes     INT UNSIGNED NOT NULL,
    width          SMALLINT UNSIGNED NULL,
    height         SMALLINT UNSIGNED NULL,
    created_at     DATETIME     NOT NULL,
    KEY idx_mp_record_section (maintenance_id, section),
    KEY idx_mp_job (job_id),
    CONSTRAINT fk_mp_record FOREIGN KEY (maintenance_id) REFERENCES maintenance_records (id) ON DELETE CASCADE,
    CONSTRAINT fk_mp_job FOREIGN KEY (job_id) REFERENCES jobs (id) ON DELETE CASCADE,
    CONSTRAINT fk_mp_user FOREIGN KEY (uploaded_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
