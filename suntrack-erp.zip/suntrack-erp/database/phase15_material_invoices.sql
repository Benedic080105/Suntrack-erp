-- =====================================================================
-- SunTrack ERP — Phase 15: invoices for released material requests
--
-- When the warehouse releases a client's material request, an invoice for the
-- materials issued on it is created automatically (includes/material_lib.php,
-- mr_create_invoice). It appears in Management > Billing and in the client's
-- My Invoices.
--
--   invoices.material_request_id   the request it bills (one invoice per request)
--   invoice_items                  the lines, frozen at release time, so a later
--                                  price change never alters an issued invoice
-- Safe to re-run.
-- =====================================================================

DROP PROCEDURE IF EXISTS suntrack15_upgrade;
DELIMITER //
CREATE PROCEDURE suntrack15_upgrade()
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'invoices' AND COLUMN_NAME = 'material_request_id'
    ) THEN
        ALTER TABLE invoices ADD COLUMN material_request_id INT UNSIGNED NULL AFTER project_id;
        ALTER TABLE invoices ADD UNIQUE KEY uq_invoice_mr (material_request_id);
    END IF;
END //
DELIMITER ;
CALL suntrack15_upgrade();
DROP PROCEDURE IF EXISTS suntrack15_upgrade;

CREATE TABLE IF NOT EXISTS invoice_items (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    invoice_id    INT UNSIGNED  NOT NULL,
    inventory_id  INT UNSIGNED  NULL,
    category      VARCHAR(50)   NULL,
    description   VARCHAR(200)  NOT NULL,
    sku           VARCHAR(30)   NULL,
    model         VARCHAR(100)  NULL,
    quantity      INT           NOT NULL,
    unit_price    DECIMAL(12,2) NOT NULL,
    line_total    DECIMAL(14,2) NOT NULL,
    CONSTRAINT fk_ii_invoice   FOREIGN KEY (invoice_id)   REFERENCES invoices(id)  ON DELETE CASCADE,
    CONSTRAINT fk_ii_inventory FOREIGN KEY (inventory_id) REFERENCES inventory(id) ON DELETE SET NULL,
    INDEX idx_ii_invoice (invoice_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
