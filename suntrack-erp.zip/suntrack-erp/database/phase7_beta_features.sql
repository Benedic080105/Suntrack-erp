-- ============================================================================
-- SunTrack ERP — Phase 7 Migration: beta features
--
--   job_photos             before / after photos on a job's work report
--   job_confirmations      client sign-off (signature + rating) on a finished job
--   users.totp_*           two-step login (authenticator app) for staff
--   user_recovery_codes    one-time backup codes for two-step login
--   push_subscriptions     phone / browser push notifications (installed app)
--   geofence_records.flag  GPS readings flagged as impossible jumps
--
-- Safe to run more than once. It never drops a table and never deletes a row.
--
--   mysql -u root suntrack_erp < database/phase7_beta_features.sql
-- ============================================================================

CREATE TABLE IF NOT EXISTS job_photos (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    job_id INT UNSIGNED NOT NULL,
    uploaded_by INT UNSIGNED NULL,                 -- users.id
    kind ENUM('BEFORE','AFTER') NOT NULL,
    file_name VARCHAR(80) NOT NULL,                -- random name inside storage/job_photos/
    mime VARCHAR(30) NOT NULL,
    size_bytes INT UNSIGNED NOT NULL,
    width SMALLINT UNSIGNED NULL,
    height SMALLINT UNSIGNED NULL,
    created_at DATETIME NOT NULL,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_photos_job (job_id, kind)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS job_confirmations (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    job_id INT UNSIGNED NOT NULL UNIQUE,           -- one sign-off per job
    confirmed_by INT UNSIGNED NULL,                -- users.id (client, or technician holding the phone)
    method ENUM('CLIENT_PORTAL','ON_SITE') NOT NULL,
    signer_name VARCHAR(150) NOT NULL,
    signature_file VARCHAR(80) NOT NULL,           -- PNG inside storage/signatures/
    rating TINYINT UNSIGNED NULL,                  -- 1..5
    comment VARCHAR(500) NULL,
    ip_address VARCHAR(45) NULL,
    created_at DATETIME NOT NULL,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    FOREIGN KEY (confirmed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS user_recovery_codes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    code_hash VARCHAR(255) NOT NULL,
    used_at DATETIME NULL,
    created_at DATETIME NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_rc_user (user_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS push_subscriptions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    endpoint TEXT NOT NULL,
    endpoint_hash CHAR(64) NOT NULL UNIQUE,
    p256dh VARCHAR(255) NULL,
    auth VARCHAR(255) NULL,
    created_at DATETIME NOT NULL,
    last_sent_at DATETIME NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_push_user (user_id)
) ENGINE=InnoDB;

DROP PROCEDURE IF EXISTS suntrack_add_column7;
DELIMITER //
CREATE PROCEDURE suntrack_add_column7(IN p_table VARCHAR(64), IN p_column VARCHAR(64), IN p_ddl VARCHAR(512))
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = p_table AND COLUMN_NAME = p_column
    ) THEN
        SET @sql = p_ddl; PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
    END IF;
END //
DELIMITER ;

CALL suntrack_add_column7('users', 'totp_secret',
    'ALTER TABLE users ADD COLUMN totp_secret VARCHAR(64) NULL');
CALL suntrack_add_column7('users', 'totp_enabled',
    'ALTER TABLE users ADD COLUMN totp_enabled TINYINT(1) NOT NULL DEFAULT 0');
CALL suntrack_add_column7('users', 'totp_last_step',
    'ALTER TABLE users ADD COLUMN totp_last_step BIGINT NULL');
CALL suntrack_add_column7('geofence_records', 'accuracy_m',
    'ALTER TABLE geofence_records ADD COLUMN accuracy_m DECIMAL(8,1) NULL');
CALL suntrack_add_column7('geofence_records', 'flag',
    'ALTER TABLE geofence_records ADD COLUMN flag VARCHAR(30) NULL');

DROP PROCEDURE IF EXISTS suntrack_add_column7;

-- Default policy: a work report needs at least one before and one after photo.
INSERT IGNORE INTO settings (setting_key, setting_value) VALUES ('work_report_require_photos', '1');

-- ============================================================================
-- End of Phase 7 migration.
-- ============================================================================
