-- =====================================================================
-- SunTrack ERP — Phase 21: a checklist for every service request type
--
-- Each service type except Maintenance (which has its own inspection
-- checklist) gets a 2–3 step checklist — Repair, Inspection, Replacement,
-- Installation Support, Panel / Battery / Inverter Issue, Other. The steps
-- and items are defined in includes/sr_checklist_lib.php.
--
--   sr_checklists        one per service-request job: its review state
--                        (technician submits -> Management approves, which
--                        completes the job and the request, or returns it)
--   sr_checklist_items   the items of each step, who ticked them and when
--   sr_checklist_photos  proof photos — at least one per step
--
-- Safe to re-run. phpMyAdmin: select suntrack_erp > Import > this file > Go.
-- =====================================================================

CREATE TABLE IF NOT EXISTS sr_checklists (
    id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    service_request_id INT UNSIGNED NOT NULL,
    job_id             INT UNSIGNED NOT NULL,
    request_type       VARCHAR(80)  NOT NULL,
    status             ENUM('OPEN','SUBMITTED','APPROVED','RETURNED') NOT NULL DEFAULT 'OPEN',
    submitted_at       DATETIME     NULL,
    submitted_by       INT UNSIGNED NULL,
    submit_note        VARCHAR(1000) NULL,
    reviewed_at        DATETIME     NULL,
    reviewed_by        INT UNSIGNED NULL,
    review_note        VARCHAR(500) NULL,
    created_at         DATETIME     NOT NULL,
    updated_at         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_srcl_job (job_id),
    KEY idx_srcl_sr (service_request_id),
    KEY idx_srcl_status (status),
    CONSTRAINT fk_srcl_sr  FOREIGN KEY (service_request_id) REFERENCES service_requests (id) ON DELETE CASCADE,
    CONSTRAINT fk_srcl_job FOREIGN KEY (job_id) REFERENCES jobs (id) ON DELETE CASCADE,
    CONSTRAINT fk_srcl_submitted_by FOREIGN KEY (submitted_by) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT fk_srcl_reviewed_by  FOREIGN KEY (reviewed_by)  REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sr_checklist_items (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    checklist_id INT UNSIGNED NOT NULL,
    step         VARCHAR(60)  NOT NULL,
    position     TINYINT UNSIGNED NOT NULL,
    description  VARCHAR(200) NOT NULL,
    status       ENUM('PENDING','COMPLETED','NOT_APPLICABLE') NOT NULL DEFAULT 'PENDING',
    remarks      VARCHAR(255) NULL,
    completed_at DATETIME     NULL,
    completed_by INT UNSIGNED NULL,
    KEY idx_srcli_checklist (checklist_id, position),
    CONSTRAINT fk_srcli_checklist FOREIGN KEY (checklist_id) REFERENCES sr_checklists (id) ON DELETE CASCADE,
    CONSTRAINT fk_srcli_user FOREIGN KEY (completed_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sr_checklist_photos (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    checklist_id INT UNSIGNED NOT NULL,
    job_id       INT UNSIGNED NOT NULL,
    step         VARCHAR(60)  NOT NULL,
    uploaded_by  INT UNSIGNED NULL,
    file_name    VARCHAR(80)  NOT NULL,
    mime         VARCHAR(30)  NOT NULL,
    size_bytes   INT UNSIGNED NOT NULL,
    width        SMALLINT UNSIGNED NULL,
    height       SMALLINT UNSIGNED NULL,
    created_at   DATETIME     NOT NULL,
    KEY idx_srclp_checklist (checklist_id, step),
    KEY idx_srclp_job (job_id),
    CONSTRAINT fk_srclp_checklist FOREIGN KEY (checklist_id) REFERENCES sr_checklists (id) ON DELETE CASCADE,
    CONSTRAINT fk_srclp_job  FOREIGN KEY (job_id) REFERENCES jobs (id) ON DELETE CASCADE,
    CONSTRAINT fk_srclp_user FOREIGN KEY (uploaded_by) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
