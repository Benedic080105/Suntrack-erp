<?php
/**
 * SunTrack ERP — create a login from the command line.
 *
 * A fresh install has roles but no users, and only clients can self-register,
 * so this is how the first Admin, Manager, Staff and Warehouse accounts are
 * made. Technicians and clients can then be added from the Management portal.
 *
 * Command line only: it refuses to run from a browser, and the database/
 * folder is also blocked from the web by database/.htaccess.
 *
 *   php database/create_user.php --role=manager --email=owner@company.ph --name="Juan Dela Cruz"
 *   php database/create_user.php --role=admin --email=admin@company.ph --name="IT Admin" --password="..."
 *
 * Roles: admin | manager | staff | warehouse
 * If --password is left out, a strong random one is generated and printed once.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';

// helpers.php's str_len() etc. work without the rest of the app, but
// PASSWORD_MIN_LENGTH lives in security.php — mirror it here.
$minLength = defined('PASSWORD_MIN_LENGTH') ? PASSWORD_MIN_LENGTH : 8;

$opts = getopt('', ['role:', 'email:', 'name:', 'password::', 'phone::', 'department::', 'position::']);
$role  = strtolower(trim($opts['role'] ?? ''));
$email = strtolower(trim($opts['email'] ?? ''));
$name  = trim($opts['name'] ?? '');

function fail(string $msg): void
{
    fwrite(STDERR, "Error: $msg\n");
    exit(1);
}

$allowed = ['admin', 'manager', 'staff', 'warehouse'];
if (!in_array($role, $allowed, true)) {
    fail('--role must be one of: ' . implode(', ', $allowed) . '. (Add technicians and clients from the Management portal.)');
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    fail('--email must be a valid email address.');
}
if ($name === '') {
    fail('--name is required.');
}

$generated = false;
$password = $opts['password'] ?? '';
if ($password === '' || $password === false) {
    // 18 characters from a set with no look-alikes (0/O, 1/l/I).
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
    $password = '';
    for ($i = 0; $i < 18; $i++) {
        $password .= $alphabet[random_int(0, strlen($alphabet) - 1)];
    }
    $generated = true;
} elseif (strlen($password) < max(10, $minLength)) {
    fail('--password must be at least ' . max(10, $minLength) . ' characters for a staff account.');
}

$pdo = db();

$stmt = $pdo->prepare('SELECT id FROM roles WHERE role_key = :r');
$stmt->execute([':r' => $role]);
$roleId = $stmt->fetchColumn();
if (!$roleId) {
    fail("Role '$role' is missing from the roles table. Import database/suntrack_erp.sql first.");
}

$stmt = $pdo->prepare('SELECT id FROM users WHERE email = :e');
$stmt->execute([':e' => $email]);
if ($stmt->fetch()) {
    fail("An account with $email already exists.");
}

$pdo->beginTransaction();
try {
    $pdo->prepare(
        'INSERT INTO users (role_id, email, password_hash, full_name, phone, status)
         VALUES (:role, :email, :hash, :name, :phone, "ACTIVE")'
    )->execute([
        ':role'  => $roleId,
        ':email' => $email,
        ':hash'  => password_hash($password, PASSWORD_DEFAULT),
        ':name'  => $name,
        ':phone' => trim($opts['phone'] ?? '') ?: null,
    ]);
    $userId = (int)$pdo->lastInsertId();

    // Managers and staff sign in through the Management portal, which expects
    // a staff profile row (see attempt_login in middleware/auth.php).
    $code = null;
    if ($role === 'manager' || $role === 'staff') {
        $staffStmt = $pdo->prepare(
            'INSERT INTO staff (user_id, staff_code, department, position, status) VALUES (:u, :c, :d, :p, "ACTIVE")'
        );
        $code = with_unique_code('staff', 'staff_code', 'STF-', function (string $c) use ($staffStmt, $userId, $opts, $role) {
            $staffStmt->execute([
                ':u' => $userId, ':c' => $c,
                ':d' => trim($opts['department'] ?? '') ?: 'Operations',
                ':p' => trim($opts['position'] ?? '') ?: ucfirst($role),
            ]);
            return $c;
        });
    }
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    fail('Could not create the account: ' . $e->getMessage());
}

echo "Created $role account #$userId" . ($code ? " ($code)" : '') . "\n";
echo "  Email:    $email\n";
if ($generated) {
    echo "  Password: $password\n";
    echo "  (Shown once. Give it to the user privately; they should change it under Settings after signing in.)\n";
}
