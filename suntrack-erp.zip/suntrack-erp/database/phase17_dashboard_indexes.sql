-- =====================================================================
-- SunTrack ERP — Phase 17: indexes for the Admin dashboard (optional)
--
-- The Admin dashboard (api/dashboard/admin.php) finds each job's completion
-- time in job_status_history and counts new jobs by jobs.created_at. These
-- two indexes keep those lookups fast as the history grows. Nothing else
-- changes: no data is touched, and the dashboard works without them.
--
-- Safe to re-run. phpMyAdmin: select suntrack_erp > Import > this file > Go.
-- =====================================================================

DROP PROCEDURE IF EXISTS suntrack17_upgrade;
DELIMITER //
CREATE PROCEDURE suntrack17_upgrade()
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'job_status_history' AND INDEX_NAME = 'idx_jsh_stage_created'
    ) THEN
        ALTER TABLE job_status_history ADD KEY idx_jsh_stage_created (to_stage, created_at, job_id);
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'jobs' AND INDEX_NAME = 'idx_jobs_created'
    ) THEN
        ALTER TABLE jobs ADD KEY idx_jobs_created (created_at);
    END IF;
END //
DELIMITER ;
CALL suntrack17_upgrade();
DROP PROCEDURE IF EXISTS suntrack17_upgrade;
