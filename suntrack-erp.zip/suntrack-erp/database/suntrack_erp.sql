-- =====================================================================
-- SUNTRACK ERP — DATABASE SCHEMA
-- NCO Technology Solutions
-- Import this file directly through phpMyAdmin (or `mysql -u root -p < suntrack_erp.sql`)
-- =====================================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+08:00";

DROP DATABASE IF EXISTS suntrack_erp;
CREATE DATABASE suntrack_erp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE suntrack_erp;

-- =====================================================================
-- 1. ROLES & USERS (auth core)
-- =====================================================================

CREATE TABLE roles (
    id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    role_key VARCHAR(20) NOT NULL UNIQUE,      -- admin, manager, staff, technician, client, warehouse
    role_label VARCHAR(50) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    role_id TINYINT UNSIGNED NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    phone VARCHAR(30) NULL,
    status ENUM('ACTIVE','INACTIVE','SUSPENDED') NOT NULL DEFAULT 'ACTIVE',
    last_login DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(id),
    INDEX idx_users_role (role_id),
    INDEX idx_users_status (status)
) ENGINE=InnoDB;

-- =====================================================================
-- 2. STAFF / TECHNICIANS / CLIENTS (role-specific profile tables)
-- =====================================================================

CREATE TABLE staff (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL UNIQUE,
    staff_code VARCHAR(20) NOT NULL UNIQUE,     -- STF-101
    department VARCHAR(80) NULL,
    position VARCHAR(80) NULL,
    status ENUM('ACTIVE','ON_LEAVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE technicians (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL UNIQUE,
    technician_code VARCHAR(20) NOT NULL UNIQUE,  -- TECH-01
    specialization VARCHAR(100) NULL,
    geofence_enabled TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE technician_availability (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    technician_id INT UNSIGNED NOT NULL UNIQUE,
    status ENUM('AVAILABLE','BUSY','OFF_DUTY','ON_LEAVE') NOT NULL DEFAULT 'AVAILABLE',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (technician_id) REFERENCES technicians(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE clients (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL UNIQUE,
    client_code VARCHAR(20) NOT NULL UNIQUE,    -- CLIENT-001
    address VARCHAR(255) NULL,
    city VARCHAR(100) NULL,
    province VARCHAR(100) NULL,
    date_registered DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_clients_city (city)
) ENGINE=InnoDB;

CREATE TABLE subcontractors (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    subcon_code VARCHAR(20) NOT NULL UNIQUE,    -- SC-01
    name VARCHAR(150) NOT NULL,
    specialization VARCHAR(150) NULL,
    phone VARCHAR(30) NULL,
    email VARCHAR(150) NULL,
    area VARCHAR(100) NULL,
    approved TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =====================================================================
-- 3. SOLAR SYSTEMS / PROJECTS / JOBS
-- =====================================================================

CREATE TABLE solar_systems (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    system_code VARCHAR(30) NOT NULL UNIQUE,    -- ST-SYS-2026-001
    client_id INT UNSIGNED NOT NULL,
    panel_brand VARCHAR(100) NULL,
    inverter_brand VARCHAR(100) NULL,
    battery_brand VARCHAR(100) NULL,
    capacity_kw DECIMAL(8,2) NULL,
    installation_date DATE NULL,
    installation_address VARCHAR(255) NULL,
    warranty_info VARCHAR(255) NULL,
    status ENUM('PLANNED','INSTALLING','ACTIVE','FAULT','DECOMMISSIONED') NOT NULL DEFAULT 'PLANNED',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    INDEX idx_solar_client (client_id)
) ENGINE=InnoDB;

CREATE TABLE projects (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    project_code VARCHAR(20) NOT NULL UNIQUE,   -- SITE-801
    client_id INT UNSIGNED NOT NULL,
    solar_system_id INT UNSIGNED NULL,
    site_name VARCHAR(150) NOT NULL,
    address VARCHAR(255) NULL,
    system_type VARCHAR(100) NULL,
    capacity_kw DECIMAL(8,2) NULL,
    installation_date DATE NULL,
    assigned_technician_id INT UNSIGNED NULL,
    status ENUM('PLANNED','SCHEDULED','IN_PROGRESS','COMPLETED','MAINTENANCE','CANCELLED') NOT NULL DEFAULT 'PLANNED',
    progress TINYINT UNSIGNED NOT NULL DEFAULT 0,
    last_maintenance DATE NULL,
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    FOREIGN KEY (solar_system_id) REFERENCES solar_systems(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_technician_id) REFERENCES technicians(id) ON DELETE SET NULL,
    INDEX idx_projects_client (client_id),
    INDEX idx_projects_status (status)
) ENGINE=InnoDB;

CREATE TABLE jobs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    job_code VARCHAR(30) NOT NULL UNIQUE,       -- JOB-2026-1001
    project_id INT UNSIGNED NULL,
    client_id INT UNSIGNED NOT NULL,
    technician_id INT UNSIGNED NULL,
    job_type ENUM('INSTALLATION','MAINTENANCE','REPAIR','INSPECTION') NOT NULL DEFAULT 'INSTALLATION',
    site_address VARCHAR(255) NULL,
    site_lat DECIMAL(10,7) NULL,
    site_lng DECIMAL(10,7) NULL,
    geofence_radius_m SMALLINT UNSIGNED NOT NULL DEFAULT 500,
    scheduled_date DATE NULL,
    priority ENUM('LOW','NORMAL','HIGH','URGENT') NOT NULL DEFAULT 'NORMAL',
    description TEXT NULL,
    stage ENUM('SUBMITTED','ASSIGNED','EN_ROUTE','ARRIVED','IN_PROGRESS','PAUSED','COMPLETED','CANCELLED') NOT NULL DEFAULT 'SUBMITTED',
    progress TINYINT UNSIGNED NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    FOREIGN KEY (technician_id) REFERENCES technicians(id) ON DELETE SET NULL,
    INDEX idx_jobs_client (client_id),
    INDEX idx_jobs_technician (technician_id),
    INDEX idx_jobs_stage (stage),
    INDEX idx_jobs_date (scheduled_date)
) ENGINE=InnoDB;

CREATE TABLE job_status_history (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    job_id INT UNSIGNED NOT NULL,
    from_stage VARCHAR(20) NULL,
    to_stage VARCHAR(20) NOT NULL,
    changed_by INT UNSIGNED NULL,      -- users.id
    note VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    FOREIGN KEY (changed_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_jsh_job (job_id)
) ENGINE=InnoDB;

-- =====================================================================
-- 4. INSTALLATION CHECKLIST (5 categories / 17 items, from prototype)
-- =====================================================================

CREATE TABLE installation_checklists (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    job_id INT UNSIGNED NOT NULL UNIQUE,
    progress TINYINT UNSIGNED NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE installation_items (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    checklist_id INT UNSIGNED NOT NULL,
    item_key VARCHAR(20) NOT NULL,       -- sp1, mo1, el1, te1, fi1 ...
    category VARCHAR(50) NOT NULL,       -- Site Preparation, Mounting, Electrical, Testing, Finalization
    description VARCHAR(150) NOT NULL,
    status ENUM('PENDING','COMPLETED','NOT_APPLICABLE') NOT NULL DEFAULT 'PENDING',
    completed_by INT UNSIGNED NULL,      -- users.id
    completed_date DATETIME NULL,
    remarks VARCHAR(255) NULL,
    FOREIGN KEY (checklist_id) REFERENCES installation_checklists(id) ON DELETE CASCADE,
    FOREIGN KEY (completed_by) REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE KEY uq_checklist_item (checklist_id, item_key),
    INDEX idx_install_items_checklist (checklist_id)
) ENGINE=InnoDB;

-- =====================================================================
-- 5. MAINTENANCE (6-item inspection, from prototype)
-- =====================================================================

CREATE TABLE maintenance_records (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    job_id INT UNSIGNED NOT NULL,
    client_id INT UNSIGNED NOT NULL,
    solar_system_id INT UNSIGNED NULL,
    technician_id INT UNSIGNED NULL,
    panel_condition ENUM('Good','Fair','Poor') NULL,
    battery_condition ENUM('Good','Fair','Poor') NULL,
    inverter_condition ENUM('Good','Fair','Poor') NULL,
    electrical_condition ENUM('Good','Fair','Poor') NULL,
    inspection_results TEXT NULL,
    materials_used TEXT NULL,
    issues_found TEXT NULL,
    remarks TEXT NULL,
    status ENUM('PENDING','IN_PROGRESS','COMPLETED') NOT NULL DEFAULT 'PENDING',
    completion_date DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    FOREIGN KEY (solar_system_id) REFERENCES solar_systems(id) ON DELETE SET NULL,
    FOREIGN KEY (technician_id) REFERENCES technicians(id) ON DELETE SET NULL,
    INDEX idx_maint_job (job_id),
    INDEX idx_maint_client (client_id)
) ENGINE=InnoDB;

CREATE TABLE maintenance_items (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    maintenance_id INT UNSIGNED NOT NULL,
    item_key VARCHAR(20) NOT NULL,       -- mnt1..mnt6
    description VARCHAR(150) NOT NULL,
    status ENUM('PENDING','COMPLETED','NOT_APPLICABLE') NOT NULL DEFAULT 'PENDING',
    remarks VARCHAR(255) NULL,
    FOREIGN KEY (maintenance_id) REFERENCES maintenance_records(id) ON DELETE CASCADE,
    UNIQUE KEY uq_maint_item (maintenance_id, item_key)
) ENGINE=InnoDB;

-- schedule/reminder side (5-year interval reminders seen in management.html)
CREATE TABLE maintenance_schedules (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    project_id INT UNSIGNED NOT NULL,
    last_maintenance DATE NULL,
    next_maintenance DATE NULL,
    status ENUM('UPCOMING','DUE','OVERDUE') NOT NULL DEFAULT 'UPCOMING',
    client_notified TINYINT(1) NOT NULL DEFAULT 0,
    notified_at DATETIME NULL,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- 6. WORK REPORTS
-- =====================================================================

CREATE TABLE work_reports (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    report_code VARCHAR(20) NOT NULL UNIQUE,   -- WR-2601
    job_id INT UNSIGNED NOT NULL,
    technician_id INT UNSIGNED NOT NULL,
    client_id INT UNSIGNED NOT NULL,
    work_type VARCHAR(50) NULL,
    remarks TEXT NULL,
    materials_used TEXT NULL,
    issues_found TEXT NULL,
    duration_minutes INT UNSIGNED NULL,
    status ENUM('DRAFT','SUBMITTED','REVIEWED') NOT NULL DEFAULT 'SUBMITTED',
    submitted_date DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    FOREIGN KEY (technician_id) REFERENCES technicians(id) ON DELETE CASCADE,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    INDEX idx_wr_job (job_id),
    INDEX idx_wr_tech (technician_id)
) ENGINE=InnoDB;

-- =====================================================================
-- 7. SERVICE REQUESTS
-- =====================================================================

CREATE TABLE service_requests (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_code VARCHAR(20) NOT NULL UNIQUE,  -- SR-2026-001
    client_id INT UNSIGNED NOT NULL,
    solar_system_id INT UNSIGNED NULL,
    job_id INT UNSIGNED NULL,                  -- linked once assigned
    request_type VARCHAR(80) NULL,
    description TEXT NULL,
    priority ENUM('LOW','NORMAL','HIGH','URGENT') NOT NULL DEFAULT 'NORMAL',
    status ENUM('PENDING','APPROVED','REJECTED','ASSIGNED','IN_PROGRESS','COMPLETED','CANCELLED') NOT NULL DEFAULT 'PENDING',
    assigned_technician_id INT UNSIGNED NULL,
    date_requested DATETIME DEFAULT CURRENT_TIMESTAMP,
    completion_date DATETIME NULL,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    FOREIGN KEY (solar_system_id) REFERENCES solar_systems(id) ON DELETE SET NULL,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_technician_id) REFERENCES technicians(id) ON DELETE SET NULL,
    INDEX idx_sr_client (client_id),
    INDEX idx_sr_status (status)
) ENGINE=InnoDB;

-- =====================================================================
-- 8. INVENTORY / WAREHOUSE (Solar Panel, Inverter, Battery ONLY)
-- =====================================================================

CREATE TABLE inventory_categories (
    id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(50) NOT NULL UNIQUE   -- Solar Panel, Inverter, Battery
) ENGINE=InnoDB;

CREATE TABLE warehouses (
    id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    warehouse_name VARCHAR(100) NOT NULL,
    location VARCHAR(150) NULL
) ENGINE=InnoDB;

CREATE TABLE inventory (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sku VARCHAR(30) NOT NULL UNIQUE,            -- ST-INV-9923
    item_name VARCHAR(150) NOT NULL,
    category_id TINYINT UNSIGNED NOT NULL,
    brand VARCHAR(100) NULL,
    model VARCHAR(100) NULL,
    serial_number VARCHAR(100) NULL,
    quantity INT NOT NULL DEFAULT 0,
    unit_cost DECIMAL(12,2) NOT NULL DEFAULT 0,
    reorder_level INT NOT NULL DEFAULT 5,
    warehouse_id TINYINT UNSIGNED NULL,
    warehouse_location VARCHAR(50) NULL,        -- e.g. Zone A / A-01
    status ENUM('ACTIVE','LOW_STOCK','OUT_OF_STOCK','DISCONTINUED') NOT NULL DEFAULT 'ACTIVE',
    qr_code VARCHAR(60) NULL,
    date_added DATE DEFAULT (CURRENT_DATE),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES inventory_categories(id),
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(id) ON DELETE SET NULL,
    INDEX idx_inv_category (category_id),
    INDEX idx_inv_status (status)
) ENGINE=InnoDB;

CREATE TABLE stock_movements (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    movement_code VARCHAR(30) NOT NULL UNIQUE,  -- MV-260601-001
    inventory_id INT UNSIGNED NOT NULL,
    movement_type ENUM('RECEIVE','ISSUE','RETURN','ADJUST','TRANSFER') NOT NULL,
    quantity INT NOT NULL,
    job_id INT UNSIGNED NULL,
    technician_id INT UNSIGNED NULL,
    from_location VARCHAR(100) NULL,
    to_location VARCHAR(100) NULL,
    reference VARCHAR(50) NULL,
    recorded_by INT UNSIGNED NULL,              -- users.id
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (inventory_id) REFERENCES inventory(id) ON DELETE CASCADE,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE SET NULL,
    FOREIGN KEY (technician_id) REFERENCES technicians(id) ON DELETE SET NULL,
    FOREIGN KEY (recorded_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_move_inventory (inventory_id),
    INDEX idx_move_job (job_id),
    INDEX idx_move_type (movement_type)
) ENGINE=InnoDB;

-- =====================================================================
-- 9. BILLING
-- =====================================================================

CREATE TABLE invoices (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    invoice_code VARCHAR(20) NOT NULL UNIQUE,   -- TX-9001
    client_id INT UNSIGNED NOT NULL,
    project_id INT UNSIGNED NULL,
    amount DECIMAL(14,2) NOT NULL,
    due_date DATE NULL,
    payment_status ENUM('PENDING','PAID','OVERDUE','CANCELLED') NOT NULL DEFAULT 'PENDING',
    payment_reference VARCHAR(50) NULL,
    payment_date DATE NULL,
    notes VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL,
    INDEX idx_inv_client (client_id),
    INDEX idx_inv_status (payment_status)
) ENGINE=InnoDB;

CREATE TABLE payments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT UNSIGNED NOT NULL,
    amount DECIMAL(14,2) NOT NULL,
    payment_method VARCHAR(50) NULL,
    reference VARCHAR(50) NULL,
    paid_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    recorded_by INT UNSIGNED NULL,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
    FOREIGN KEY (recorded_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =====================================================================
-- 10. NOTIFICATIONS
-- =====================================================================

CREATE TABLE notifications (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    type VARCHAR(50) NOT NULL,                 -- SERVICE_REQUEST, JOB_STATUS, MAINTENANCE_DUE, INVOICE_OVERDUE, ...
    message VARCHAR(255) NOT NULL,
    related_table VARCHAR(50) NULL,
    related_id INT UNSIGNED NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_notif_user (user_id, is_read)
) ENGINE=InnoDB;

-- =====================================================================
-- 11. ATTENDANCE / GEOFENCE (GPS, 500m rule)
-- =====================================================================

CREATE TABLE attendance (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    technician_id INT UNSIGNED NOT NULL,
    job_id INT UNSIGNED NOT NULL,
    time_in DATETIME NULL,
    time_out DATETIME NULL,
    lat_in DECIMAL(10,7) NULL,
    lng_in DECIMAL(10,7) NULL,
    lat_out DECIMAL(10,7) NULL,
    lng_out DECIMAL(10,7) NULL,
    distance_in_m DECIMAL(8,2) NULL,
    distance_out_m DECIMAL(8,2) NULL,
    geofence_status ENUM('INSIDE','OUTSIDE') NULL,
    auto_timed_out TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (technician_id) REFERENCES technicians(id) ON DELETE CASCADE,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    INDEX idx_att_tech (technician_id),
    INDEX idx_att_job (job_id)
) ENGINE=InnoDB;

CREATE TABLE geofence_records (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    job_id INT UNSIGNED NOT NULL,
    technician_id INT UNSIGNED NOT NULL,
    lat DECIMAL(10,7) NOT NULL,
    lng DECIMAL(10,7) NOT NULL,
    distance_m DECIMAL(8,2) NOT NULL,
    status ENUM('INSIDE','OUTSIDE') NOT NULL,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    FOREIGN KEY (technician_id) REFERENCES technicians(id) ON DELETE CASCADE,
    INDEX idx_geo_job (job_id)
) ENGINE=InnoDB;

-- =====================================================================
-- 12. LOGS / AUDIT
-- =====================================================================

CREATE TABLE activity_logs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NULL,
    action VARCHAR(255) NOT NULL,
    module VARCHAR(50) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NULL,
    role_key VARCHAR(20) NULL,
    action VARCHAR(100) NOT NULL,               -- CREATE, UPDATE, DELETE, LOGIN, ASSIGN, APPROVE...
    module VARCHAR(50) NOT NULL,                -- clients, jobs, inventory...
    record_id VARCHAR(30) NULL,
    ip_address VARCHAR(45) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_audit_module (module),
    INDEX idx_audit_created (created_at)
) ENGINE=InnoDB;

-- =====================================================================
-- 13. SETTINGS
-- =====================================================================

CREATE TABLE settings (
    id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(50) NOT NULL UNIQUE,
    setting_value VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

-- =====================================================================
-- SEED: ROLES, INVENTORY CATEGORIES, WAREHOUSE, SETTINGS
-- =====================================================================

INSERT INTO roles (role_key, role_label) VALUES
('admin','Administrator'),
('manager','Manager'),
('staff','Staff'),
('technician','Technician'),
('client','Client'),
('warehouse','Warehouse');

INSERT INTO inventory_categories (category_name) VALUES
('Solar Panel'),('Inverter'),('Battery');

INSERT INTO warehouses (warehouse_name, location) VALUES
('Main Warehouse','Bacolod City');

INSERT INTO settings (setting_key, setting_value) VALUES
('geofence_radius_m','500'),
('low_stock_threshold_pct','150'),
('critical_stock_threshold','5'),
('capacity_warning_pct','80'),
('maintenance_interval_years','5');

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
-- End of schema. Sample data (50 clients, technicians, jobs, inventory,
-- etc. per section 44) ships separately as database/seed.sql / seed.php
-- so this file stays a clean, re-runnable structure-only import.
-- =====================================================================
