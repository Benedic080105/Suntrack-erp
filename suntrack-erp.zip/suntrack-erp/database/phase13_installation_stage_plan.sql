-- =====================================================================
-- SunTrack ERP — Phase 13: scheduled, approved installation stages
--
-- An installation is no longer one long checklist. Each stage (Site
-- Preparation / inspection, Mounting, Electrical, Testing, Finalization) is
-- its own scheduled visit:
--
--   PLANNED    not scheduled yet (waits for the stage before it to be approved)
--   SCHEDULED  booked for scheduled_date — the technician works it on that day
--   SUBMITTED  the technician ticked everything, added proof photos and sent it
--              for review; locked while Management checks it
--   APPROVED   Management accepted it; the next stage can be scheduled
--   RETURNED   Management sent it back with a note; the technician fixes it
--              and submits again
--
-- Rows are created automatically the first time a checklist is opened
-- (includes/installation_plan_lib.php), so existing jobs need no backfill:
-- stages already finished at that moment are recorded as APPROVED.
-- Safe to re-run.
-- =====================================================================

CREATE TABLE IF NOT EXISTS installation_stage_plan (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    checklist_id    INT UNSIGNED NOT NULL,
    job_id          INT UNSIGNED NOT NULL,
    stage           VARCHAR(50)  NOT NULL,              -- installation_items.category
    position        TINYINT UNSIGNED NOT NULL,          -- 1 = first stage
    status          ENUM('PLANNED','SCHEDULED','SUBMITTED','APPROVED','RETURNED') NOT NULL DEFAULT 'PLANNED',
    scheduled_date  DATE         NULL,
    submitted_at    DATETIME     NULL,
    submitted_by    INT UNSIGNED NULL,                  -- users.id (technician)
    submit_note     VARCHAR(500) NULL,
    reviewed_at     DATETIME     NULL,
    reviewed_by     INT UNSIGNED NULL,                  -- users.id (management)
    review_note     VARCHAR(500) NULL,
    updated_at      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_isp_checklist FOREIGN KEY (checklist_id) REFERENCES installation_checklists(id) ON DELETE CASCADE,
    CONSTRAINT fk_isp_job       FOREIGN KEY (job_id)       REFERENCES jobs(id)                    ON DELETE CASCADE,
    CONSTRAINT fk_isp_submitter FOREIGN KEY (submitted_by) REFERENCES users(id)                   ON DELETE SET NULL,
    CONSTRAINT fk_isp_reviewer  FOREIGN KEY (reviewed_by)  REFERENCES users(id)                   ON DELETE SET NULL,
    UNIQUE KEY uq_isp_stage (checklist_id, stage),
    INDEX idx_isp_status (status, scheduled_date),
    INDEX idx_isp_job (job_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
