-- ============================================================================
-- SunTrack ERP — Phase 3 Migration
-- Geofencing hardening · Client coordinates · Real-time sync · Consent & privacy
--
-- Safe to run more than once. Every statement is guarded, so re-running this
-- file is a no-op. It never drops a table and never deletes a row.
--
--   mysql -u root suntrack_erp < database/phase3_geo_realtime_consent.sql
--
-- What it adds, and why:
--
--   1. clients.lat / clients.lng / clients.geofence_radius_m
--      New clients can now carry site coordinates. Jobs created for a client
--      inherit them automatically, which closes the geofence hole described
--      in (4) below at the source.
--
--   2. login_attempts
--      Before this, an attacker could try passwords against the login endpoint
--      as fast as the network allowed. This table backs a lockout window.
--
--   3. consent_logs + users.privacy_accepted_at / cookie_consent_at
--      Records who agreed to the privacy policy and cookie terms, when, from
--      which IP, and against which version of the document.
--
--   4. settings rows for geofence policy
--      geofence_strict = 1 means a job with no site coordinates CANNOT be
--      timed into. Previously a missing coordinate silently disabled the
--      geofence and let a technician time in from anywhere.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- Guarded helpers. Dropped again at the end of the file.
-- ---------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS suntrack_add_column;
DROP PROCEDURE IF EXISTS suntrack_add_index3;

DELIMITER //

CREATE PROCEDURE suntrack_add_column(
    IN p_table  VARCHAR(64),
    IN p_column VARCHAR(64),
    IN p_ddl    VARCHAR(512)
)
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME   = p_table
          AND COLUMN_NAME  = p_column
    ) THEN
        SET @sql = p_ddl;
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END //

CREATE PROCEDURE suntrack_add_index3(
    IN p_table VARCHAR(64),
    IN p_index VARCHAR(64),
    IN p_ddl   VARCHAR(512)
)
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME   = p_table
          AND INDEX_NAME   = p_index
    ) THEN
        SET @sql = p_ddl;
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END //

DELIMITER ;

-- ---------------------------------------------------------------------------
-- 1. Client site coordinates.
--    DECIMAL(10,7) matches jobs.site_lat / jobs.site_lng exactly, so a value
--    copied from client to job is never silently rounded.
-- ---------------------------------------------------------------------------
CALL suntrack_add_column('clients', 'lat',
    'ALTER TABLE clients ADD COLUMN lat DECIMAL(10,7) NULL AFTER province');

CALL suntrack_add_column('clients', 'lng',
    'ALTER TABLE clients ADD COLUMN lng DECIMAL(10,7) NULL AFTER lat');

CALL suntrack_add_column('clients', 'geofence_radius_m',
    'ALTER TABLE clients ADD COLUMN geofence_radius_m SMALLINT UNSIGNED NOT NULL DEFAULT 500 AFTER lng');

-- Finding "clients that still need coordinates plotted" is a common admin task.
CALL suntrack_add_index3('clients', 'idx_clients_geo',
    'ALTER TABLE clients ADD INDEX idx_clients_geo (lat, lng)');

-- ---------------------------------------------------------------------------
-- 2. Login throttling.
--    Keyed by BOTH email and IP so that neither a single-account password
--    spray nor a single-host attack against many accounts gets a free pass.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_attempts (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email       VARCHAR(150) NOT NULL,
    ip_address  VARCHAR(45)  NULL,
    successful  TINYINT(1)   NOT NULL DEFAULT 0,
    user_agent  VARCHAR(255) NULL,
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_attempt_email (email, created_at),
    INDEX idx_attempt_ip (ip_address, created_at)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------------
-- 3. Privacy / cookie consent.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS consent_logs (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id       INT UNSIGNED NULL,          -- NULL = consent given before login
    consent_type  ENUM('PRIVACY','COOKIES','TERMS') NOT NULL,
    decision      ENUM('ACCEPTED','REJECTED','ESSENTIAL_ONLY') NOT NULL,
    policy_version VARCHAR(20) NOT NULL,
    ip_address    VARCHAR(45)  NULL,
    user_agent    VARCHAR(255) NULL,
    created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_consent_user (user_id, consent_type)
) ENGINE=InnoDB;

CALL suntrack_add_column('users', 'privacy_accepted_at',
    'ALTER TABLE users ADD COLUMN privacy_accepted_at DATETIME NULL AFTER last_login');

CALL suntrack_add_column('users', 'privacy_version',
    'ALTER TABLE users ADD COLUMN privacy_version VARCHAR(20) NULL AFTER privacy_accepted_at');

CALL suntrack_add_column('users', 'cookie_consent_at',
    'ALTER TABLE users ADD COLUMN cookie_consent_at DATETIME NULL AFTER privacy_version');

-- ---------------------------------------------------------------------------
-- 4. Settings. INSERT IGNORE relies on the UNIQUE key on setting_key, so an
--    operator who has already tuned a value keeps their value on re-run.
-- ---------------------------------------------------------------------------
INSERT IGNORE INTO settings (setting_key, setting_value) VALUES
    ('geofence_default_radius_m', '500'),
    ('geofence_strict',           '1'),
    ('geofence_ping_seconds',     '20'),
    ('realtime_poll_seconds',     '10'),
    ('privacy_policy_version',    '1.0'),
    ('company_name',              'NCO Technology Solutions'),
    ('company_email',             'privacy@ncotechsolutions.com');

-- ---------------------------------------------------------------------------
-- 5. Real-time change feed.
--    The sync endpoint fingerprints tables using MAX(updated_at) + COUNT(*),
--    which needs no writes anywhere in the app. But tables that only ever get
--    INSERTs (attendance, geofence_records, stock_movements) have no
--    updated_at, so an index on the timestamp they DO have keeps the
--    fingerprint query cheap when polled every few seconds.
-- ---------------------------------------------------------------------------
CALL suntrack_add_index3('stock_movements', 'idx_move_created',
    'ALTER TABLE stock_movements ADD INDEX idx_move_created (created_at)');

CALL suntrack_add_index3('attendance', 'idx_att_created',
    'ALTER TABLE attendance ADD INDEX idx_att_created (created_at)');

CALL suntrack_add_index3('notifications', 'idx_notif_created',
    'ALTER TABLE notifications ADD INDEX idx_notif_created (created_at)');

CALL suntrack_add_index3('inventory', 'idx_inv_updated',
    'ALTER TABLE inventory ADD INDEX idx_inv_updated (updated_at)');

CALL suntrack_add_index3('jobs', 'idx_jobs_updated',
    'ALTER TABLE jobs ADD INDEX idx_jobs_updated (updated_at)');

-- ---------------------------------------------------------------------------
-- 6. Backfill: give existing clients coordinates derived from the jobs that
--    already reference their sites, so the strict geofence in (4) does not
--    suddenly block technicians on day one. Only fills rows that are NULL.
-- ---------------------------------------------------------------------------
UPDATE clients c
JOIN (
    SELECT client_id,
           AVG(site_lat) AS avg_lat,
           AVG(site_lng) AS avg_lng
    FROM jobs
    WHERE site_lat IS NOT NULL AND site_lng IS NOT NULL
    GROUP BY client_id
) j ON j.client_id = c.id
SET c.lat = j.avg_lat,
    c.lng = j.avg_lng
WHERE c.lat IS NULL OR c.lng IS NULL;

-- And the reverse: jobs with no coordinates inherit from their client.
UPDATE jobs j
JOIN clients c ON c.id = j.client_id
SET j.site_lat = c.lat,
    j.site_lng = c.lng
WHERE (j.site_lat IS NULL OR j.site_lng IS NULL)
  AND c.lat IS NOT NULL AND c.lng IS NOT NULL;

DROP PROCEDURE IF EXISTS suntrack_add_column;
DROP PROCEDURE IF EXISTS suntrack_add_index3;

-- ============================================================================
-- End of Phase 3 migration.
-- ============================================================================
