-- =====================================================================
-- SunTrack ERP — Phase 18: billing integrity (auditable payments, job link)
--
-- Builds on the existing invoices / payments tables — no copies:
--
--   payments.voided_at / voided_by / void_reason
--        A wrong payment is VOIDED, never deleted: it stays in the history
--        (who recorded it, who voided it, why) but stops counting toward
--        what the client has paid. api/billing/void_payment.php.
--   payments.request_key  (UNIQUE)
--        One key per payment form: the same form sent twice (double click,
--        network retry) records one payment, not two.
--   invoices.job_id
--        The job order an invoice bills. Filled in for existing invoices from
--        the released material request's job, or else the project's
--        installation job. New invoices set it on creation.
--
-- Invoice states stay as they are: PENDING (unpaid or partially paid),
-- OVERDUE, PAID and CANCELLED (shown as "Voided"). "Partially paid" is
-- derived — a PENDING/OVERDUE invoice with valid payments on it.
--
-- Safe to re-run. phpMyAdmin: select suntrack_erp > Import > this file > Go.
-- =====================================================================

DROP PROCEDURE IF EXISTS suntrack18_upgrade;
DELIMITER //
CREATE PROCEDURE suntrack18_upgrade()
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'payments' AND COLUMN_NAME = 'voided_at'
    ) THEN
        ALTER TABLE payments
            ADD COLUMN voided_at   DATETIME     NULL AFTER recorded_by,
            ADD COLUMN voided_by   INT UNSIGNED NULL AFTER voided_at,
            ADD COLUMN void_reason VARCHAR(255) NULL AFTER voided_by,
            ADD COLUMN request_key VARCHAR(64)  NULL AFTER void_reason,
            ADD UNIQUE KEY uq_payment_request (request_key),
            ADD KEY idx_pay_valid (invoice_id, voided_at),
            ADD KEY idx_pay_paid_at (paid_at),
            ADD CONSTRAINT fk_pay_voided_by FOREIGN KEY (voided_by) REFERENCES users (id) ON DELETE SET NULL;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'invoices' AND COLUMN_NAME = 'job_id'
    ) THEN
        ALTER TABLE invoices
            ADD COLUMN job_id INT UNSIGNED NULL AFTER project_id,
            ADD KEY idx_inv_job (job_id),
            ADD KEY idx_inv_due (due_date),
            ADD CONSTRAINT fk_inv_job FOREIGN KEY (job_id) REFERENCES jobs (id) ON DELETE SET NULL;
    END IF;
END //
DELIMITER ;
CALL suntrack18_upgrade();
DROP PROCEDURE IF EXISTS suntrack18_upgrade;

-- Link existing invoices to their job order (only where none is set yet).
UPDATE invoices i
JOIN material_requests mr ON mr.id = i.material_request_id
SET i.job_id = mr.job_id
WHERE i.job_id IS NULL AND mr.job_id IS NOT NULL;

UPDATE invoices i
JOIN (SELECT project_id, MIN(id) AS job_id FROM jobs
      WHERE job_type = 'INSTALLATION' AND project_id IS NOT NULL GROUP BY project_id) j
  ON j.project_id = i.project_id
SET i.job_id = j.job_id
WHERE i.job_id IS NULL AND i.material_request_id IS NULL;
