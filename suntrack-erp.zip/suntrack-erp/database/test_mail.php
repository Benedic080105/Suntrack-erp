<?php
/**
 * SunTrack ERP — send a test email to check the mail settings.
 *
 * Command line only (the database/ folder is also blocked from the web).
 *
 *   php database/test_mail.php --to=you@gmail.com
 *
 * Uses the same SUNTRACK_SMTP_* settings as the live app (config/env.php).
 * On failure, the reason is printed here and written to the PHP error log.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

// Load only what mail needs — no session, no database.
if (!defined('APP_NAME')) {
    define('APP_NAME', 'SunTrack ERP');
}
require_once __DIR__ . '/../config/env_loader.php';
require_once __DIR__ . '/../includes/mailer.php';

$opts = getopt('', ['to:']);
$to = trim($opts['to'] ?? '');
if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
    fwrite(STDERR, "Usage: php database/test_mail.php --to=you@gmail.com\n");
    exit(1);
}

// Show the failure reason on screen instead of only in the log.
ini_set('log_errors', '1');
ini_set('error_log', 'php://stderr');

echo 'Mail server : ' . (app_env('SUNTRACK_SMTP_HOST') ?? '(none — using PHP mail())') . "\n";
echo 'Port / mode : ' . app_env('SUNTRACK_SMTP_PORT', '587') . ' / ' . app_env('SUNTRACK_SMTP_SECURE', 'tls') . "\n";
echo 'Login       : ' . (app_env('SUNTRACK_SMTP_USER') ?? '(none)') . "\n";
echo 'Password    : ' . (app_env('SUNTRACK_SMTP_PASS') !== null ? '(set)' : '(not set)') . "\n";
echo 'From        : ' . mail_from_address() . "\n";
echo "Sending to  : $to ...\n";

$ok = send_mail(
    $to,
    APP_NAME . ' — test email',
    "This is a test email from " . APP_NAME . ".\n\nIf you can read this, password reset emails will be delivered.\nSent " . date('F j, Y g:i A') . "\n",
    '<p style="font-family:Arial,sans-serif;font-size:15px">This is a test email from <b>' . htmlspecialchars(APP_NAME) . '</b>.</p>'
    . '<p style="font-family:Arial,sans-serif;font-size:15px">If you can read this, password reset emails will be delivered.</p>'
);

if ($ok) {
    echo "OK — the mail server accepted it. Check the inbox (and Spam) of $to.\n";
    exit(0);
}
echo "FAILED — see the reason above. Common fixes are listed in DEPLOYMENT.md (\"Email\").\n";
exit(1);
