<?php
/**
 * SunTrack ERP — switch off two-step login for a staff member who lost both
 * their phone and their backup codes. Command line only.
 *
 *   php database/reset_2fa.php --email=staff@company.ph
 *
 * They can sign in with just their password afterwards and set it up again
 * from Settings. The reset is written to the audit log.
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
require_once __DIR__ . '/../config/database.php';

$email = strtolower(trim(getopt('', ['email:'])['email'] ?? ''));
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    fwrite(STDERR, "Usage: php database/reset_2fa.php --email=staff@company.ph\n");
    exit(1);
}
$pdo = db();
$stmt = $pdo->prepare('SELECT id, totp_enabled FROM users WHERE email = :e');
$stmt->execute([':e' => $email]);
$u = $stmt->fetch();
if (!$u) {
    fwrite(STDERR, "No account with $email.\n");
    exit(1);
}
if (!(int)$u['totp_enabled']) {
    echo "Two-step login is already off for $email.\n";
    exit(0);
}
$pdo->prepare('UPDATE users SET totp_secret = NULL, totp_enabled = 0, totp_last_step = NULL WHERE id = :id')->execute([':id' => $u['id']]);
$pdo->prepare('DELETE FROM user_recovery_codes WHERE user_id = :id')->execute([':id' => $u['id']]);
$pdo->prepare("INSERT INTO audit_logs (user_id, role_key, action, module, record_id, ip_address) VALUES (NULL, 'cli', '2FA_RESET', 'auth', :r, NULL)")
    ->execute([':r' => (string)$u['id']]);
echo "Two-step login switched off for $email. They can sign in with their password and set it up again.\n";
