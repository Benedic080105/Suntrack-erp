-- =====================================================================
-- SunTrack ERP — Phase 11: free-text duration on work reports
--
-- Technicians may now type the duration any way they like ("2 hours 30 mins",
-- "1.5 hrs", "half day"). duration_text keeps exactly what was typed and is
-- what every screen shows; duration_minutes is still filled whenever the text
-- reads as a time (api/work_reports/create.php), so averages keep working.
--
-- Existing reports get their minutes written out as text ("500 min").
-- Safe to re-run: the column is only added once, and only empty texts are filled.
-- =====================================================================

DROP PROCEDURE IF EXISTS suntrack11_duration_text;
DELIMITER //
CREATE PROCEDURE suntrack11_duration_text()
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'work_reports' AND COLUMN_NAME = 'duration_text'
    ) THEN
        ALTER TABLE work_reports ADD COLUMN duration_text VARCHAR(100) NULL AFTER issues_found;
    END IF;
END //
DELIMITER ;
CALL suntrack11_duration_text();
DROP PROCEDURE IF EXISTS suntrack11_duration_text;

UPDATE work_reports
SET duration_text = CONCAT(duration_minutes, ' min')
WHERE duration_text IS NULL AND duration_minutes IS NOT NULL;
