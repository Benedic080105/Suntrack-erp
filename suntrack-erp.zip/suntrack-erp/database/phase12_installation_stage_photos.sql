-- =====================================================================
-- SunTrack ERP — Phase 12: proof photos per installation stage
--
-- The technician attaches photos to each stage of the installation checklist
-- (Site Preparation, Mounting, Electrical, Testing, Finalization). A stage
-- counts as finished only when all its items are ticked AND it has at least
-- one photo, so the next stage stays locked until then (includes/technician_lib.php).
-- Management sees the photos, grouped by stage, in the installation job view.
--
-- Files live in storage/installation_photos/ under random names and are only
-- served through api/installation/photo_view.php after an access check.
-- Safe to re-run.
-- =====================================================================

CREATE TABLE IF NOT EXISTS installation_photos (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    checklist_id  INT UNSIGNED NOT NULL,
    job_id        INT UNSIGNED NOT NULL,
    stage         VARCHAR(50)  NOT NULL,               -- installation_items.category
    uploaded_by   INT UNSIGNED NULL,                   -- users.id
    file_name     VARCHAR(80)  NOT NULL,               -- random name inside storage/installation_photos/
    mime          VARCHAR(30)  NOT NULL,
    size_bytes    INT UNSIGNED NOT NULL,
    width         SMALLINT UNSIGNED NULL,
    height        SMALLINT UNSIGNED NULL,
    created_at    DATETIME     NOT NULL,
    CONSTRAINT fk_ip_checklist FOREIGN KEY (checklist_id) REFERENCES installation_checklists(id) ON DELETE CASCADE,
    CONSTRAINT fk_ip_job       FOREIGN KEY (job_id)       REFERENCES jobs(id)                    ON DELETE CASCADE,
    CONSTRAINT fk_ip_user      FOREIGN KEY (uploaded_by)  REFERENCES users(id)                   ON DELETE SET NULL,
    INDEX idx_ip_checklist_stage (checklist_id, stage)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
