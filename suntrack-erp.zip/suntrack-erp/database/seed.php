<?php
/**
 * SunTrack ERP — full demo seed (every module).
 *
 *   C:\xampp\php\php.exe database\seed.php          (Windows / XAMPP)
 *   php database/seed.php                           (PHP on your PATH)
 *
 * What it creates:
 *   Accounts        1 Admin, 5 Management, 1 Warehouse, 10 Technicians,
 *                   50 Clients (Bacolod City / Negros Occidental, each with its
 *                   own map coordinates)
 *   Projects        38 installation projects with their solar systems:
 *                   30 installed, 3 installing now, 3 scheduled, 1 planned,
 *                   1 cancelled
 *   Installation    36 installation jobs, each with the 17-item checklist,
 *                   attendance, GPS trail, work report, photos and sign-off
 *   Maintenance     a schedule for every installed system (overdue / due /
 *                   upcoming), 7 maintenance jobs with inspection records
 *   Service         30 service requests in every status, with jobs, history,
 *   requests        notes and resolutions
 *   Warehouse       15 stock items, receipts, issues, returns, and 15 client
 *                   orders (material requests) in every status
 *   Billing         invoices for every project and paid service visit, with
 *                   full and partial payments, pending and overdue balances
 *   Other           6 sub-contractors, notifications and audit-log activity
 *
 * SAFE TO RUN AGAIN. Nothing is ever truncated or deleted:
 *   - accounts are matched by e-mail (…@suntrack.test) and updated in place,
 *     so names, phones, coordinates and the demo password are restored;
 *   - everything else is matched by its own demo code (SR-DEMO-…,
 *     JOB-DEMO-…, MR-DEMO-…, INV-DEMO-…, ST-INV-90xx, MV-DEMO-…) or by
 *     client + site name, and only created when missing — so anything you
 *     have since worked on (a job you completed, an order you picked) is never
 *     rewound, and nothing is created twice;
 *   - demo codes never take a number from the real SR-YYYY- / JOB-YYYY- /
 *     MR-YYYY- / INV-YYYY- sequences.
 *
 * Command line only. It refuses to run from a browser, and the database/
 * folder is also blocked from the web by database/.htaccess — that block is
 * intentional and should stay.
 *
 * Requires the schema plus:
 *   phase1_technician_migration.sql, phase2_management_migration.sql,
 *   phase3_geo_realtime_consent.sql, phase4_realtime_updated_at.sql,
 *   phase5_service_requests.sql, phase5_material_requests.sql
 * Optional: phase7_beta_features.sql (job photos + client sign-offs are
 * seeded only when it is imported).
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

date_default_timezone_set('Asia/Manila');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';

/** The one demo password for every seeded account. */
const DEMO_PASSWORD = 'Suntrack12345!';
const DEMO_DOMAIN   = 'suntrack.test';

function out(string $line = ''): void
{
    echo $line . PHP_EOL;
}

function fail(string $message): never
{
    fwrite(STDERR, PHP_EOL . 'SEED FAILED' . PHP_EOL . $message . PHP_EOL);
    exit(1);
}

/** 'Y-m-d H:i:s' for N hours ago (fractions allowed). */
function hours_ago(float $hours): string
{
    return date('Y-m-d H:i:s', (int)round(time() - $hours * 3600));
}

/** 'Y-m-d' for today + N days (negative = past). */
function day_offset(int $days): string
{
    return date('Y-m-d', strtotime(($days >= 0 ? '+' : '') . $days . ' days'));
}

/** 'Y-m-d H:i:s' on the day N days ago (negative = future) at a clock time. */
function day_at(int $daysAgo, string $time): string
{
    return day_offset(-$daysAgo) . ' ' . $time . ':00';
}

/** OVERDUE / DUE (within 14 days) / UPCOMING — the app's maintenance rule. */
function maint_status(string $nextDate): string
{
    $days = (strtotime($nextDate) - strtotime(date('Y-m-d'))) / 86400;
    return $days < 0 ? 'OVERDUE' : ($days <= 14 ? 'DUE' : 'UPCOMING');
}

// ---------------------------------------------------------------------------
// Tiny PNG writer (zlib only — XAMPP ships PHP without GD by default)
// ---------------------------------------------------------------------------

function png_chunk(string $type, string $data): string
{
    return pack('N', strlen($data)) . $type . $data . pack('N', crc32($type . $data));
}

/** @param callable(int,int):array{0:int,1:int,2:int} $pixel */
function png_bytes(int $w, int $h, callable $pixel): string
{
    $raw = '';
    for ($y = 0; $y < $h; $y++) {
        $raw .= "\0";
        for ($x = 0; $x < $w; $x++) {
            [$r, $g, $b] = $pixel($x, $y);
            $raw .= chr($r) . chr($g) . chr($b);
        }
    }
    return "\x89PNG\r\n\x1a\n"
        . png_chunk('IHDR', pack('NNCCCCC', $w, $h, 8, 2, 0, 0, 0))
        . png_chunk('IDAT', gzcompress($raw, 9))
        . png_chunk('IEND', '');
}

/** A rooftop illustration: bare roof (BEFORE) or roof with a panel array (AFTER). */
function demo_site_photo(string $kind, int $variant): string
{
    $w = 480;
    $h = 320;
    $roof = [[150, 70, 55], [120, 80, 70], [95, 95, 105]][$variant % 3];
    $cols = 4 + $variant % 3;
    return png_bytes($w, $h, function (int $x, int $y) use ($kind, $roof, $cols, $w) {
        $roofTop = 120 + (int)(abs($x - $w / 2) * 0.12);
        if ($y < $roofTop) {                                   // sky
            return [110 + (int)($y * 0.5), 170 + (int)($y * 0.3), 235];
        }
        if ($kind === 'AFTER') {                               // panel array
            $px0 = 70; $px1 = $w - 70; $py0 = $roofTop + 25; $py1 = 280;
            if ($x >= $px0 && $x < $px1 && $y >= $py0 && $y < $py1) {
                $cw = (int)(($px1 - $px0) / $cols);
                $frame = (($x - $px0) % $cw) < 3 || (($y - $py0) % 52) < 3;
                return $frame ? [200, 205, 210] : [25, 45, 95 + (int)(($y - $py0) * 0.25)];
            }
        }
        $stripe = (($y - $roofTop) % 18) < 2 ? 25 : 0;           // roof sheets
        return [$roof[0] - $stripe, $roof[1] - $stripe, $roof[2] - $stripe];
    });
}

/** A handwritten-looking signature line on white. */
function demo_signature(int $variant): string
{
    $w = 360;
    $h = 120;
    $ink = [];
    $phase = $variant * 0.7;
    for ($x = 24; $x < 336; $x++) {
        $y = (int)round(62 + 26 * sin($x / 17 + $phase) * cos($x / 53) - ($x > 250 ? ($x - 250) * 0.15 : 0));
        for ($dy = -1; $dy <= 1; $dy++) {
            $ink[$y + $dy][$x] = true;
            $ink[$y + $dy][$x + 1] = true;
        }
    }
    return png_bytes($w, $h, fn(int $x, int $y) => isset($ink[$y][$x]) ? [20, 30, 80] : [255, 255, 255]);
}

/** Write a demo image into storage/<bucket>/ under a random name; returns [name, bytes]. */
function demo_store_png(string $bucket, string $png): array
{
    $dir = dirname(__DIR__) . '/storage/' . $bucket;
    if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
        throw new RuntimeException("Cannot create storage/$bucket");
    }
    $name = bin2hex(random_bytes(16)) . '.png';
    if (file_put_contents($dir . '/' . $name, $png) === false) {
        throw new RuntimeException("Cannot write to storage/$bucket");
    }
    return [$name, strlen($png)];
}

// ===========================================================================
// 0. Connect and verify the database is ready
// ===========================================================================

// Probe first so a stopped MySQL gets a useful message (db() alone only says
// "connection failed"). The probe never prints the DSN or credentials.
try {
    new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET, DB_USER, DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (PDOException $e) {
    $why = str_contains($e->getMessage(), 'Unknown database')
        ? 'The database does not exist yet — import database/suntrack_erp.sql first.'
        : 'Start MySQL in the XAMPP Control Panel and check config/database.php (or config/env.php).';
    fail('Could not connect to the database "' . DB_NAME . "\".\n$why");
}

// The app's own shared connection (Asia/Manila clock, exceptions on). Every
// statement below — and with_unique_code() in helpers.php — runs on it, so the
// whole seed is a single transaction.
$pdo = db();

$tables = array_column($pdo->query('SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()')->fetchAll(), 'TABLE_NAME');
$tableSet = array_flip(array_map('strtolower', $tables));

$columns = [];
foreach ($pdo->query('SELECT TABLE_NAME, COLUMN_NAME, COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE()')->fetchAll() as $r) {
    $columns[strtolower($r['TABLE_NAME'])][strtolower($r['COLUMN_NAME'])] = $r['COLUMN_TYPE'];
}
$indexes = [];
foreach ($pdo->query('SELECT TABLE_NAME, INDEX_NAME FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE()')->fetchAll() as $r) {
    $indexes[strtolower($r['TABLE_NAME'])][$r['INDEX_NAME']] = true;
}

$problems = [];
$need = function (bool $ok, string $what, string $file) use (&$problems) {
    if (!$ok) {
        $problems[$file][] = $what;
    }
};

foreach (['roles', 'users', 'staff', 'technicians', 'technician_availability', 'clients', 'subcontractors',
          'solar_systems', 'projects', 'jobs', 'job_status_history', 'installation_checklists', 'installation_items',
          'maintenance_records', 'maintenance_items', 'maintenance_schedules', 'work_reports', 'service_requests',
          'inventory_categories', 'warehouses', 'inventory', 'stock_movements', 'invoices', 'payments',
          'notifications', 'attendance', 'geofence_records', 'audit_logs', 'settings'] as $t) {
    $need(isset($tableSet[$t]), "table `$t`", 'database/suntrack_erp.sql');
}
if (!$problems) {
    $need(isset($indexes['work_reports']['uq_work_reports_job']), 'index work_reports.uq_work_reports_job', 'database/phase1_technician_migration.sql');
    $need(isset($indexes['maintenance_schedules']['uq_maint_schedule_project']), 'index maintenance_schedules.uq_maint_schedule_project', 'database/phase2_management_migration.sql');
    foreach (['lat', 'lng', 'geofence_radius_m'] as $c) {
        $need(isset($columns['clients'][$c]), "column clients.$c", 'database/phase3_geo_realtime_consent.sql');
    }
    $need(isset($tableSet['login_attempts']), 'table `login_attempts`', 'database/phase3_geo_realtime_consent.sql');
    $need(isset($columns['attendance']['updated_at']), 'column attendance.updated_at', 'database/phase4_realtime_updated_at.sql');
    $need(isset($columns['service_requests']['updated_at']), 'column service_requests.updated_at', 'database/phase4_realtime_updated_at.sql');
    foreach (['subject', 'created_by', 'scheduled_date', 'site_address', 'location_lat', 'location_lng', 'technician_notes', 'resolution', 'created_at'] as $c) {
        $need(isset($columns['service_requests'][$c]), "column service_requests.$c", 'database/phase5_service_requests.sql');
    }
    foreach (['barangay', 'postal_code'] as $c) {
        $need(isset($columns['clients'][$c]), "column clients.$c", 'database/phase5_service_requests.sql');
    }
    $need(isset($tableSet['service_request_history']), 'table `service_request_history`', 'database/phase5_service_requests.sql');
    $statusType = $columns['service_requests']['status'] ?? '';
    $need(str_contains($statusType, "'SCHEDULED'") && str_contains($statusType, "'ON_HOLD'"),
        'service_requests.status values SCHEDULED / ON_HOLD', 'database/phase5_service_requests.sql');
    $need(isset($tableSet['material_requests']), 'table `material_requests`', 'database/phase5_material_requests.sql');
    $need(isset($tableSet['material_request_items']), 'table `material_request_items`', 'database/phase5_material_requests.sql');
    $need(isset($columns['stock_movements']['material_request_id']), 'column stock_movements.material_request_id', 'database/phase5_material_requests.sql');
}

if ($problems) {
    $msg = 'The database "' . DB_NAME . "\" is not ready for the seed. Missing:\n";
    foreach ($problems as $file => $items) {
        $msg .= "\n  Import  $file\n";
        foreach ($items as $i) {
            $msg .= "    - $i\n";
        }
    }
    $msg .= "\nImport the files above in phpMyAdmin (with `" . DB_NAME . "` selected) in phase order,\n"
        . "then run this seed again. Every migration is safe to re-run.";
    fail($msg);
}

// Phase 7 extras are optional.
$hasPhotos   = isset($tableSet['job_photos']);
$hasSignoffs = isset($tableSet['job_confirmations']);
$geoExtra    = isset($columns['geofence_records']['accuracy_m']);

$roleIds = [];
foreach ($pdo->query('SELECT id, role_key FROM roles')->fetchAll() as $r) {
    $roleIds[$r['role_key']] = (int)$r['id'];
}
$missingRoles = array_diff(['admin', 'manager', 'staff', 'technician', 'client', 'warehouse'], array_keys($roleIds));
if ($missingRoles) {
    fail('The roles table is missing: ' . implode(', ', $missingRoles) . '. Re-import database/suntrack_erp.sql on a fresh install.');
}

$categoryIds = [];
foreach ($pdo->query('SELECT id, category_name FROM inventory_categories')->fetchAll() as $r) {
    $categoryIds[$r['category_name']] = (int)$r['id'];
}
if (array_diff(['Solar Panel', 'Inverter', 'Battery'], array_keys($categoryIds))) {
    fail('inventory_categories must contain Solar Panel, Inverter and Battery. Re-import database/suntrack_erp.sql on a fresh install.');
}
$warehouseRow = $pdo->query('SELECT id, warehouse_name FROM warehouses ORDER BY id LIMIT 1')->fetch();
if (!$warehouseRow) {
    $pdo->exec("INSERT INTO warehouses (warehouse_name, location) VALUES ('Main Warehouse', 'Bacolod City')");
    $warehouseRow = $pdo->query('SELECT id, warehouse_name FROM warehouses ORDER BY id LIMIT 1')->fetch();
}
$warehouseId = (int)$warehouseRow['id'];

// ===========================================================================
// 1. Demo data
// ===========================================================================

$systemAccounts = [
    // [email local part, role, full name, phone, staff department, staff position]
    ['admin',      'admin',     'Roberto Lim Araneta',              '0917 845 2201', null, null],
    ['manager1',   'manager',   'Katherine Joy Yulo Benedicto',     '0918 223 4410', 'Operations',       'Operations Manager'],
    ['manager2',   'manager',   'Rafael Antonio Gonzaga Hilado',    '0919 556 1023', 'Service',          'Service Manager'],
    ['manager3',   'manager',   'Cecilia Marie Jalandoni Locsin',   '0927 301 8845', 'Dispatch',         'Dispatch Coordinator'],
    ['manager4',   'manager',   'Leonardo Villanueva Ramos',        '0939 412 7756', 'Field Operations', 'Field Operations Supervisor'],
    ['manager5',   'manager',   'Andrea Nicole Tan Sy',             '0945 678 9012', 'Customer Service', 'Customer Service Lead'],
    ['warehouse',  'warehouse', 'Gilbert Sy Chua',                  '0955 120 3344', null, null],
];

$technicianAccounts = [
    // [full name, phone, specialization]
    ['Renato Cruz Dela Peña',          '0917 330 1101', 'Solar PV installation & repair'],
    ['Jerome Santos Villaflor',        '0918 330 1102', 'Inverter diagnostics'],
    ['Mary Grace Lim Alcantara',       '0919 330 1103', 'Battery storage systems'],
    ['Allan Torres Gerona',            '0920 330 1104', 'Electrical wiring & protection'],
    ['Joel Reyes Maravilla',           '0927 330 1105', 'Preventive maintenance'],
    ['Kevin Bautista Dumalagan',       '0928 330 1106', 'Roof mounting & structural'],
    ['Rhea Mae Aguilar Sumugat',       '0939 330 1107', 'Monitoring & inspection'],
    ['Michael Angelo Garcia Belleza',  '0945 330 1108', 'Grid-tie systems'],
    ['Norberto Flores Tabanao',        '0961 330 1109', 'Off-grid & hybrid systems'],
    ['Darwin Ramos Lopena',            '0966 330 1110', 'General solar technician'],
];

/*
 * 50 clients. [first, middle, last, phone, street address, barangay, city,
 * postal code, latitude, longitude, account status]
 *
 * Coordinates follow each barangay, on land, spread across Bacolod City with a
 * few in Talisay, Silay and Murcia. Province is Negros Occidental for all.
 * Statuses use the existing users.status values (ACTIVE / INACTIVE /
 * SUSPENDED): only ACTIVE accounts can sign in.
 */
$clients = [
    ['Maria Cristina', 'Lopez',      'Villanueva',  '0917 512 0101', '18 Lacson Street, Purok Malipayon',            'Mandalagan',       'Bacolod City', '6100', 10.6987000, 122.9638000, 'ACTIVE'],
    ['Jose Antonio',   'Gonzaga',    'Ledesma',     '0918 512 0102', 'Blk 3 Lot 7, Villa Angela Subdivision',        'Mandalagan',       'Bacolod City', '6100', 10.7032000, 122.9661000, 'ACTIVE'],
    ['Ana Patricia',   'Reyes',      'Montinola',   '0919 512 0103', '45 Bata Road, Purok Kaunlaran',                'Bata',             'Bacolod City', '6100', 10.6998000, 122.9574000, 'ACTIVE'],
    ['Ramon',          'Javellana',  'Gatuslao',    '0920 512 0104', 'Lot 22, Northdrive Homes',                     'Bata',             'Bacolod City', '6100', 10.6945000, 122.9602000, 'ACTIVE'],
    ['Kristine Joy',   'Dizon',      'Bautista',    '0927 512 0105', '12 Banago Road, Purok Sampaguita',             'Banago',           'Bacolod City', '6100', 10.6979000, 122.9512000, 'ACTIVE'],
    ['Eduardo',        'Lim',        'Tan',         '0928 512 0106', '88 Banago Wharf Road',                         'Banago',           'Bacolod City', '6100', 10.7012000, 122.9531000, 'ACTIVE'],
    ['Rosario',        'Alvarez',    'Pacheco',     '0939 512 0107', '27 Burgos Avenue',                             'Villamonte',       'Bacolod City', '6100', 10.6801000, 122.9652000, 'ACTIVE'],
    ['Mark Anthony',   'Cruz',       'Dela Rosa',   '0945 512 0108', 'Blk 9 Lot 14, Villamonte Heights',             'Villamonte',       'Bacolod City', '6100', 10.6762000, 122.9689000, 'ACTIVE'],
    ['Liza Marie',     'Fernandez',  'Garcia',      '0955 512 0109', '3 Rosario Street, Purok Masagana',             'Taculing',         'Bacolod City', '6100', 10.6603000, 122.9598000, 'INACTIVE'],
    ['Carlo',          'Mendoza',    'Aguilar',     '0961 512 0110', 'Lot 5, Taculing Road',                         'Taculing',         'Bacolod City', '6100', 10.6567000, 122.9634000, 'ACTIVE'],
    ['Grace',          'Ramos',      'Soriano',     '0966 512 0111', '62 Alijis Road, Purok Kawayan',                'Alijis',           'Bacolod City', '6100', 10.6482000, 122.9551000, 'ACTIVE'],
    ['Ricardo',        'Torres',     'Espinosa',    '0977 512 0112', 'Blk 2 Lot 11, Alijis Village',                 'Alijis',           'Bacolod City', '6100', 10.6441000, 122.9586000, 'ACTIVE'],
    ['Jennifer',       'Navarro',    'Salazar',     '0995 512 0113', 'Purok Riverside, Singcang Road',               'Singcang-Airport', 'Bacolod City', '6100', 10.6463000, 122.9392000, 'ACTIVE'],
    ['Antonio',        'Domingo',    'Ocampo',      '0998 512 0114', '15 Airport Subdivision',                       'Singcang-Airport', 'Bacolod City', '6100', 10.6428000, 122.9421000, 'SUSPENDED'],
    ['Michelle Anne',  'Castillo',   'Rivera',      '0917 512 0115', 'Tangub Highway, Purok Bagong Silang',          'Tangub',           'Bacolod City', '6100', 10.6322000, 122.9468000, 'ACTIVE'],
    ['Fernando',       'Aquino',     'Valdez',      '0918 512 0116', 'Lot 30, Tangub Homes',                         'Tangub',           'Bacolod City', '6100', 10.6289000, 122.9503000, 'ACTIVE'],
    ['Teresita',       'Morales',    'Jimenez',     '0919 512 0117', 'Purok Bayabas, Pahanocoy Road',                'Pahanocoy',        'Bacolod City', '6100', 10.6184000, 122.9447000, 'ACTIVE'],
    ['Rodel',          'Pascual',    'Marquez',     '0920 512 0118', 'Blk 6 Lot 2, Pahanocoy Village',               'Pahanocoy',        'Bacolod City', '6100', 10.6151000, 122.9479000, 'INACTIVE'],
    ['Annabelle',      'Santiago',   'Uy',          '0927 512 0119', 'Sum-ag Highway, Purok Mabinuligon',            'Sum-ag',           'Bacolod City', '6100', 10.6038000, 122.9341000, 'ACTIVE'],
    ['Ronaldo',        'Gutierrez',  'Sison',       '0928 512 0120', 'Lot 8, Sum-ag Heights',                        'Sum-ag',           'Bacolod City', '6100', 10.5997000, 122.9378000, 'ACTIVE'],
    ['Cherry Mae',     'Flores',     'Ybañez',      '0939 512 0121', 'Purok Malipayon, Handumanan Road',             'Handumanan',       'Bacolod City', '6100', 10.6278000, 122.9652000, 'ACTIVE'],
    ['Danilo',         'Villareal',  'Hofileña',    '0945 512 0122', 'Blk 4 Lot 9, Handumanan Relocation Site',      'Handumanan',       'Bacolod City', '6100', 10.6243000, 122.9701000, 'ACTIVE'],
    ['Josephine',      'Abad',       'Sarmiento',   '0955 512 0123', 'Mansilingan Road, Purok Paghidaet',            'Mansilingan',      'Bacolod City', '6100', 10.6392000, 122.9788000, 'ACTIVE'],
    ['Ernesto',        'Belmonte',   'Yulo',        '0961 512 0124', 'Lot 17, Mansilingan Agro Village',             'Mansilingan',      'Bacolod City', '6100', 10.6355000, 122.9832000, 'ACTIVE'],
    ['Marites',        'Cordova',    'Lacson',      '0966 512 0125', 'Estefania Road, Purok Bougainvillea',          'Estefania',        'Bacolod City', '6100', 10.6702000, 122.9839000, 'ACTIVE'],
    ['Vicente',        'Hilado',     'Coscolluela', '0977 512 0126', 'Blk 1 Lot 3, Estefania Subdivision',           'Estefania',        'Bacolod City', '6100', 10.6668000, 122.9876000, 'ACTIVE'],
    ['Rowena',         'Panganiban', 'Lizares',     '0995 512 0127', 'Granada-Murcia Road, Purok Uswag',             'Granada',          'Bacolod City', '6100', 10.6604000, 123.0298000, 'INACTIVE'],
    ['Alfredo',        'Escalante',  'Jalandoni',   '0998 512 0128', 'Lot 41, Granada Highlands',                    'Granada',          'Bacolod City', '6100', 10.6561000, 123.0254000, 'ACTIVE'],
    ['Lorna',          'Benedicto',  'Treñas',      '0917 512 0129', 'Alangilan Road, Purok Pag-asa',                'Alangilan',        'Bacolod City', '6100', 10.6418000, 123.0476000, 'ACTIVE'],
    ['Gerardo',        'Infante',    'Robles',      '0918 512 0130', 'Purok Malinong, Felisa Road',                  'Felisa',           'Bacolod City', '6100', 10.6458000, 122.9963000, 'ACTIVE'],
    ['Shiela Mae',     'Tolentino',  'Arceo',       '0919 512 0131', 'Lot 12, Felisa Heights',                       'Felisa',           'Bacolod City', '6100', 10.6492000, 123.0018000, 'SUSPENDED'],
    ['Benjamin',       'Ortiz',      'Saldivar',    '0920 512 0132', 'Cabug Road, Purok Kalipay',                    'Cabug',            'Bacolod City', '6100', 10.6192000, 123.0048000, 'ACTIVE'],
    ['Melanie',        'Quiambao',   'Dela Cruz',   '0927 512 0133', '8 Montevista Avenue',                          'Montevista',       'Bacolod City', '6100', 10.6882000, 122.9788000, 'ACTIVE'],
    ['Arnold',         'Bayona',     'Gaston',      '0928 512 0134', 'Blk 5 Lot 6, Vista Alegre Subdivision',        'Vista Alegre',     'Bacolod City', '6100', 10.6803000, 122.9951000, 'ACTIVE'],
    ['Corazon',        'Sorilla',    'Magalona',    '0939 512 0135', 'Purok Lunhaw, Vista Alegre Road',              'Vista Alegre',     'Bacolod City', '6100', 10.6838000, 122.9907000, 'ACTIVE'],
    ['Paolo',          'Regalado',   'Fuentebella', '0945 512 0136', '112 Araneta Street',                           'Barangay 13',      'Bacolod City', '6100', 10.6652000, 122.9506000, 'INACTIVE'],
    ['Janet',          'Gonzales',   'Cuenca',      '0955 512 0137', '54 Rizal Street',                              'Barangay 22',      'Bacolod City', '6100', 10.6693000, 122.9488000, 'ACTIVE'],
    ['Nestor',         'Villanueva', 'Pido',        '0961 512 0138', '9 Gatuslao Street',                            'Barangay 8',       'Bacolod City', '6100', 10.6721000, 122.9494000, 'ACTIVE'],
    ['Imelda',         'Ramos',      'Locsin',      '0966 512 0139', '31 Hernaez Street',                            'Barangay 26',      'Bacolod City', '6100', 10.6748000, 122.9532000, 'ACTIVE'],
    ['Francis',        'Ledesma',    'Tupas',       '0977 512 0140', '76 Libertad Street',                           'Barangay 35',      'Bacolod City', '6100', 10.6618000, 122.9527000, 'ACTIVE'],
    ['Gemma',          'Tingson',    'Arroyo',      '0995 512 0141', 'Burgos Street, Purok Masinadyahon',            'Barangay 2',       'Bacolod City', '6100', 10.6779000, 122.9561000, 'ACTIVE'],
    ['Raul',           'Gamboa',     'Concepcion',  '0998 512 0142', '20 Galo Street',                               'Barangay 18',      'Bacolod City', '6100', 10.6701000, 122.9544000, 'ACTIVE'],
    ['Evangeline',     'Salcedo',    'Yap',         '0917 512 0143', '5 San Juan Street',                            'Barangay 40',      'Bacolod City', '6100', 10.6634000, 122.9479000, 'ACTIVE'],
    ['Christopher',    'Diaz',       'Montelibano', '0918 512 0144', 'Circumferential Road, Purok Bag-ong Banwa',    'Alijis',           'Bacolod City', '6100', 10.6513000, 122.9649000, 'ACTIVE'],
    ['Arlene',         'Javier',     'Puentebella', '0919 512 0145', '14 Rizal Street',                              'Zone 12-A',        'Talisay City', '6115', 10.7368000, 122.9728000, 'INACTIVE'],
    ['Rogelio',        'Pama',       'Golez',       '0920 512 0146', 'Purok Sambag',                                 'Concepcion',       'Talisay City', '6115', 10.7316000, 122.9811000, 'ACTIVE'],
    ['Sharon',         'Ditching',   'Gico',        '0927 512 0147', 'Purok Paraiso',                                'Matab-ang',        'Talisay City', '6115', 10.7292000, 122.9902000, 'ACTIVE'],
    ['Victor',         'Javelosa',   'Seville',     '0928 512 0148', 'Murcia Highway',                               'Blumentritt',      'Murcia',       '6129', 10.6048000, 123.0405000, 'SUSPENDED'],
    ['Leonora',        'Caro',       'Abello',      '0939 512 0149', 'Purok Kahirup',                                'Zone 4 (Poblacion)', 'Murcia',     '6129', 10.6075000, 123.0378000, 'ACTIVE'],
    ['Dennis',         'Uygongco',   'Lacuna',      '0945 512 0150', '7 Rizal Street',                               'Zone II (Poblacion)', 'Silay City','6116', 10.7978000, 122.9771000, 'ACTIVE'],
];

/*
 * 30 service requests.
 * [n, client #, service type, subject, description, priority, status, technician # | null,
 *  requested (hours ago), scheduled (days from today) | null, completed (hours ago) | null,
 *  job stage | null, technician notes | null, resolution | null, remarks | null]
 */
$requests = [
    [1,  1,  'Inverter Issue', 'Inverter shows fault code E-21', 'Since yesterday afternoon the inverter display shows E-21 and the grid light blinks. The app shows zero output even at peak sun.', 'HIGH', 'PENDING', null, 20, null, null, null, null, null, null],
    [2,  3,  'Panel Issue', 'Two panels cracked after the storm', "After last night's thunderstorm we noticed two panels on the east side with visible cracks. No smoke or burning smell.", 'URGENT', 'PENDING', null, 5, null, null, null, null, null, null],
    [3,  12, 'Maintenance', 'Request for annual preventive maintenance', 'Our system is almost one year old. We would like the yearly cleaning and full check-up, preferably on a Saturday morning.', 'LOW', 'PENDING', null, 50, null, null, null, null, null, null],
    [4,  25, 'Battery Issue', 'Battery backup drains before midnight', 'The battery used to last until morning, but now it is empty around 11 PM with the same appliances running.', 'NORMAL', 'PENDING', null, 30, null, null, null, null, null, null],
    [5,  40, 'Other', 'Monitoring app stopped showing data', "The monitoring app has shown 'offline' for 3 days. Our home Wi-Fi is working normally.", 'LOW', 'PENDING', null, 70, null, null, null, null, null, null],
    [6,  5,  'Inspection', 'Pre-typhoon inspection of roof mounts', 'PAGASA announced a typhoon this week. Please inspect the mounting rails and clamps before it arrives.', 'NORMAL', 'APPROVED', null, 96, null, null, null, null, null, null],
    [7,  22, 'Repair', 'Loose DC cable near the combiner box', 'One of the DC cables near the combiner box is hanging loose and the conduit cover came off.', 'HIGH', 'APPROVED', null, 75, null, null, null, null, null, null],
    [8,  33, 'Replacement', 'Replace damaged MC4 connectors', 'During our own cleaning we saw two MC4 connectors under the array that look melted.', 'NORMAL', 'APPROVED', null, 120, null, null, null, null, null, null],
    [9,  46, 'Installation Support', 'Add two panels to the existing array', 'We want to add two more panels to the system. Please check whether the inverter can handle the extra capacity.', 'LOW', 'APPROVED', null, 144, null, null, null, null, null, null],
    [10, 2,  'Inverter Issue', 'Inverter beeping intermittently', 'The inverter beeps every few minutes in the afternoon. No error code is displayed.', 'HIGH', 'ASSIGNED', 1, 110, null, null, 'ASSIGNED', null, null, null],
    [11, 7,  'Panel Issue', 'Output dropped by about 30%', 'Daily production went from about 18 kWh to 12 kWh this month, even on sunny days.', 'NORMAL', 'ASSIGNED', 2, 98, null, null, 'ASSIGNED', null, null, null],
    [12, 15, 'Battery Issue', 'Battery not charging to full', 'The battery stops at 70% even after a full sunny day.', 'HIGH', 'ASSIGNED', 3, 80, null, null, 'ASSIGNED', null, null, null],
    [13, 28, 'Repair', 'Solar breaker trips when the aircon runs', 'The solar breaker trips whenever the bedroom aircon and the refrigerator run at the same time.', 'URGENT', 'ASSIGNED', 4, 50, null, null, 'ASSIGNED', null, null, null],
    [14, 10, 'Maintenance', 'Semi-annual cleaning and check-up', 'Regular six-month maintenance as recommended in our service contract.', 'NORMAL', 'SCHEDULED', 5, 190, 2, null, 'ASSIGNED', null, null, null],
    [15, 19, 'Inspection', 'Post-installation inspection', '30-day inspection after our installation was completed last month.', 'NORMAL', 'SCHEDULED', 6, 170, 3, null, 'ASSIGNED', null, null, null],
    [16, 24, 'Replacement', 'Replace corroded mounting clamps', 'Rust is visible on several mid clamps, probably from the salty air.', 'LOW', 'SCHEDULED', 7, 215, 5, null, 'ASSIGNED', null, null, null],
    [17, 34, 'Inverter Issue', 'Inverter firmware update and check', 'The supplier advised a firmware update for our inverter model.', 'NORMAL', 'SCHEDULED', 8, 140, 1, null, 'ASSIGNED', null, null, null],
    [18, 41, 'Maintenance', 'Quarterly maintenance visit', 'Quarterly maintenance for the rooftop system at our store on Burgos Street.', 'LOW', 'SCHEDULED', 9, 240, 7, null, 'ASSIGNED', null, null, null],
    [19, 4,  'Panel Issue', 'Hot spot visible on one panel', "Our electrician's thermal scan showed a hot spot on one panel in the second row.", 'HIGH', 'IN_PROGRESS', 10, 100, 0, null, 'EN_ROUTE', null, null, null],
    [20, 11, 'Inverter Issue', 'Inverter shuts down at noon', 'Every day around 12 noon the inverter shuts down for about 20 minutes, then restarts on its own.', 'URGENT', 'IN_PROGRESS', 1, 72, 0, null, 'ARRIVED', 'On site. Inverter heatsink very hot — checking ventilation and fan.', null, null],
    [21, 20, 'Battery Issue', 'Battery casing is swelling', 'We noticed the battery casing bulging. We already switched off the battery breaker.', 'URGENT', 'IN_PROGRESS', 2, 30, 0, null, 'EN_ROUTE', null, null, null],
    [22, 30, 'Repair', 'Grounding wire cut during renovation', 'Our contractor accidentally cut the grounding wire while renovating the garage.', 'HIGH', 'IN_PROGRESS', 3, 54, 0, null, 'ARRIVED', null, null, null],
    [23, 38, 'Replacement', 'Replace failed charge controller', 'The charge controller display is blank and the battery is not charging.', 'NORMAL', 'ON_HOLD', 4, 220, -2, null, 'PAUSED', 'Controller confirmed dead (no output on PV input). Waiting for the replacement unit from the supplier, ETA 5 days.', null, 'Waiting for replacement charge controller from supplier.'],
    [24, 6,  'Maintenance', 'Annual maintenance and panel cleaning', 'Yearly maintenance and panel cleaning.', 'NORMAL', 'COMPLETED', 5, 740, -28, 670, 'COMPLETED', 'All strings within spec.', 'Cleaned all 12 panels, re-torqued clamps, checked DC/AC connections and inverter logs. All readings normal.', null],
    [25, 13, 'Inverter Issue', 'Inverter error after brownout', "After a brownout the inverter shows 'Grid Fault' and will not reconnect.", 'HIGH', 'COMPLETED', 6, 500, -20, 470, 'COMPLETED', null, 'Grid protection settings were reset by the brownout. Restored the settings to the utility standard and updated the firmware. Inverter reconnected and producing normally.', null],
    [26, 21, 'Panel Issue', 'Shading and bird droppings on panels', 'Production dropped; we see bird droppings and a tree branch shading part of the array.', 'LOW', 'COMPLETED', 10, 430, -16, 380, 'COMPLETED', null, "Cleaned the panels, trimmed the overhanging branch with the owner's permission and installed bird deterrent spikes. Output is back to the expected range.", null],
    [27, 29, 'Battery Issue', 'Battery backup lasts only two hours', 'Backup used to last 6 hours; now it only lasts about 2 hours.', 'NORMAL', 'COMPLETED', 8, 330, -11, 260, 'COMPLETED', 'Capacity test: module 2 at 41% of rated capacity.', 'Capacity test showed a weak battery module. Replaced it under warranty and recalibrated the BMS. Backup time restored to about 6 hours.', null],
    [28, 35, 'Inspection', 'Insurance inspection report', 'Our insurer requires an inspection report of the solar installation.', 'NORMAL', 'COMPLETED', 9, 300, -9, 210, 'COMPLETED', null, 'Full inspection done: mounting, wiring, grounding, inverter and labeling all compliant. Report and photos sent to the client.', null],
    [29, 43, 'Repair', 'Water leak at roof penetration', 'Rainwater drips inside near where the solar conduit enters the roof.', 'HIGH', 'CANCELLED', null, 260, null, null, null, null, null, 'Our roofer already resealed the penetration, so no visit is needed.'],
    [30, 16, 'Other', 'Relocate panels to a new roof extension', 'We are building a second floor and want the panels moved to the new roof.', 'LOW', 'REJECTED', null, 360, null, null, null, null, null, 'Relocation is a new installation project, not a service request. Our sales team will contact you for a quotation.'],
];

/* Sub-contractors. [code, name, specialization, phone, email, area, approved] */
$subcontractors = [
    ['SC-01', 'Negros Roofing & Structural Works', 'Roof reinforcement & mounting structures',      '0917 601 2201', 'ops@negrosroofing.test',      'Bacolod City / Talisay',   1],
    ['SC-02', 'Visayas Electrical Contractors',    'Electrical permits, net-metering & grid tie-in', '0918 601 2202', 'permits@visayaselectric.test','Negros Occidental',        1],
    ['SC-03', 'Silay Scaffolding Services',        'Scaffolding & height-access equipment',          '0919 601 2203', 'rent@silayscaffold.test',     'Silay / Victorias',        1],
    ['SC-04', 'BCD Crane & Hauling',               'Crane lifting & materials hauling',              '0927 601 2204', 'dispatch@bcdcrane.test',      'Bacolod City',             1],
    ['SC-05', 'Ilonggo Solar Cleaning Co.',        'Panel cleaning & washing',                       '0939 601 2205', 'hello@ilonggoclean.test',     'Bacolod / Iloilo',         0],
    ['SC-06', 'Murcia Civil Works',                'Ground-mount footings & civil works',            '0945 601 2206', 'office@murciacivil.test',     'Murcia / Bago',            0],
];

/*
 * Stock catalog. [sku, item name, category, brand, model, unit cost, reorder level,
 *                 location, stock left after the demo orders (buffer), panel watts | null]
 * Opening stock = what the demo orders use + the buffer, so the final counts
 * land exactly on the buffer: a few items end LOW or OUT of stock on purpose.
 */
$catalog = [
    ['ST-INV-9001', 'Jinko Tiger Neo 580W Mono Panel',       'Solar Panel', 'Jinko Solar',    'JKM580N-72HL4-V',     8900,   40, 'Zone A / A-01', 140, 580],
    ['ST-INV-9002', 'LONGi Hi-MO 6 545W Panel',               'Solar Panel', 'LONGi',          'LR5-72HTH-545M',      8250,   40, 'Zone A / A-02',  95, 545],
    ['ST-INV-9003', 'Trina Vertex S 440W Panel',              'Solar Panel', 'Trina Solar',    'TSM-440NEG9R.28',     6950,   30, 'Zone A / A-03',  14, 440],
    ['ST-INV-9004', 'Canadian Solar HiKu6 550W Panel',        'Solar Panel', 'Canadian Solar', 'CS6W-550MS',          8400,   30, 'Zone A / A-04',  80, 550],
    ['ST-INV-9005', 'JA Solar DeepBlue 3.0 550W Panel',       'Solar Panel', 'JA Solar',       'JAM72D40-550/MB',     8300,   30, 'Zone A / A-05',  12, 550],
    ['ST-INV-9006', 'Huawei SUN2000-5KTL Hybrid Inverter',    'Inverter',    'Huawei',         'SUN2000-5KTL-L1',    62000,    5, 'Zone B / B-01',  14, null],
    ['ST-INV-9007', 'Growatt SPH 6000 Hybrid Inverter',       'Inverter',    'Growatt',        'SPH6000',            48500,    5, 'Zone B / B-02',   9, null],
    ['ST-INV-9008', 'Deye SUN-8K-SG04LP1 Hybrid Inverter',    'Inverter',    'Deye',           'SUN-8K-SG04LP1-EU',  68000,    4, 'Zone B / B-03',   2, null],
    ['ST-INV-9009', 'SMA Sunny Boy 5.0 Grid-tie Inverter',    'Inverter',    'SMA',            'SB5.0-1AV-41',       71500,    3, 'Zone B / B-04',   6, null],
    ['ST-INV-9010', 'GoodWe GW5K-ET Hybrid Inverter',         'Inverter',    'GoodWe',         'GW5K-ET',            55000,    4, 'Zone B / B-05',   7, null],
    ['ST-INV-9011', 'Pylontech US5000 4.8kWh Battery',        'Battery',     'Pylontech',      'US5000',             58000,    6, 'Zone C / C-01',  16, null],
    ['ST-INV-9012', 'BYD Battery-Box Premium HVS 7.7kWh',     'Battery',     'BYD',            'HVS 7.7',           165000,    3, 'Zone C / C-02',   4, null],
    ['ST-INV-9013', 'Huawei LUNA2000-5 Battery Module',       'Battery',     'Huawei',         'LUNA2000-5-E0',      92000,    4, 'Zone C / C-03',   0, null],
    ['ST-INV-9014', 'Dyness BX51100 5.12kWh Battery',         'Battery',     'Dyness',         'BX51100',            52000,    6, 'Zone C / C-04',  11, null],
    ['ST-INV-9015', 'Deye SE-G5.1 Pro 5.12kWh Battery',       'Battery',     'Deye',           'SE-G5.1 Pro-B',      54000,    6, 'Zone C / C-05',   9, null],
];
$discontinuedSkus = ['ST-INV-9005'];
$catalogBySku = [];
foreach ($catalog as $c) {
    $catalogBySku[$c[0]] = $c;
}

/*
 * Installation projects. Every client with a service request has an installed
 * system (you can't report a broken inverter you don't own); a few more
 * clients are mid-installation, scheduled, planned or cancelled.
 */
$installedClients = [1, 2, 3, 4, 5, 6, 7, 10, 11, 12, 13, 15, 16, 19, 20, 21, 22, 24, 25, 28, 29, 30, 33, 34, 35, 38, 40, 41, 43, 46];
$installedDaysAgo = [690, 655, 620, 590, 560, 530, 505, 480, 450, 425, 400, 372, 350, 38, 330, 305, 280, 262, 240, 215, 196, 175, 158, 140, 122, 104, 90, 76, 62, 50];
// Next maintenance, days from today: 3 overdue, 3 due within 14 days, the rest upcoming.
$nextMaintOffsets = [-40, -18, -6, 3, 8, 12, 21, 35, 48, 60, 75, 90, 110, 130, 150, 170, 190, 210, 230, 250, 270, 290, 300, 310, 320, 330, 340, 350, 355, 360];

$kwChoices    = [5.0, 6.0, 3.3, 8.0, 10.0, 4.4, 6.0, 12.0, 5.0, 8.0];
$panelPool    = ['ST-INV-9001', 'ST-INV-9002', 'ST-INV-9004', 'ST-INV-9001', 'ST-INV-9003', 'ST-INV-9002'];
$hybridInv    = ['ST-INV-9006', 'ST-INV-9007', 'ST-INV-9010', 'ST-INV-9008'];
$batteryPool  = ['ST-INV-9011', 'ST-INV-9014', 'ST-INV-9015', 'ST-INV-9012', 'ST-INV-9013'];

$projectPlan = [];
$addProject = function (int $client, string $status, ?int $tech, int $k, array $extra) use (&$projectPlan, $kwChoices, $panelPool, $hybridInv, $batteryPool, $catalogBySku) {
    $kw = $kwChoices[$k % count($kwChoices)];
    $hybrid = $k % 3 !== 2;                                     // two in three systems carry a battery
    $panel = $panelPool[$k % count($panelPool)];
    $inverter = $hybrid ? $hybridInv[$k % count($hybridInv)] : 'ST-INV-9009';
    $battery = $hybrid ? $batteryPool[$k % count($batteryPool)] : null;
    $projectPlan[] = array_merge([
        'client' => $client, 'status' => $status, 'tech' => $tech, 'kw' => $kw, 'hybrid' => $hybrid,
        'panel' => $panel, 'inverter' => $inverter, 'battery' => $battery,
        'panels' => (int)ceil($kw * 1000 / $catalogBySku[$panel][9]),
        'batteries' => $hybrid ? ($kw >= 8 ? 2 : 1) : 0,
        'mr' => null, 'job_stage' => null, 'checklist_done' => 0, 'days' => null, 'next_maint' => null,
    ], $extra);
};
foreach ($installedClients as $k => $c) {
    // The six most recent installs went through a client order in the warehouse.
    $addProject($c, 'COMPLETED', ($k % 10) + 1, $k, [
        'days' => $installedDaysAgo[$k], 'job_stage' => 'COMPLETED', 'checklist_done' => 17,
        'next_maint' => $nextMaintOffsets[$k], 'mr' => $installedDaysAgo[$k] <= 125 ? 'RELEASED' : null,
    ]);
}
$addProject(8,  'IN_PROGRESS', 5,    30, ['days' => 0,   'job_stage' => 'IN_PROGRESS', 'checklist_done' => 10, 'mr' => 'RELEASED']);
$addProject(17, 'IN_PROGRESS', 6,    31, ['days' => 0,   'job_stage' => 'IN_PROGRESS', 'checklist_done' => 6,  'mr' => 'RELEASED']);
$addProject(23, 'IN_PROGRESS', 7,    32, ['days' => 0,   'job_stage' => 'EN_ROUTE',    'checklist_done' => 0,  'mr' => 'READY']);
$addProject(26, 'SCHEDULED',   8,    33, ['days' => -3,  'job_stage' => 'ASSIGNED',    'checklist_done' => 0,  'mr' => 'PREPARING']);
$addProject(32, 'SCHEDULED',   9,    34, ['days' => -6,  'job_stage' => 'ASSIGNED',    'checklist_done' => 0,  'mr' => 'PENDING']);
$addProject(37, 'SCHEDULED',   10,   35, ['days' => -10, 'job_stage' => 'ASSIGNED',    'checklist_done' => 0,  'mr' => 'PENDING']);
$addProject(39, 'PLANNED',     null, 36, ['days' => -30, 'mr' => 'PENDING']);
$addProject(42, 'CANCELLED',   null, 37, ['days' => -45, 'mr' => 'CANCELLED']);

// --- Sanity checks on the data itself, before touching the database ---------
if (count($clients) !== 50 || count($technicianAccounts) !== 10 || count($systemAccounts) !== 7) {
    fail('Internal seed data is incomplete (expected 50 clients, 10 technicians, 7 other accounts).');
}
$seenCoords = [];
foreach ($clients as $i => $c) {
    [$lat, $lng] = [$c[8], $c[9]];
    if ($lat < 10.55 || $lat > 10.85 || $lng < 122.88 || $lng > 123.10) {
        fail('Client #' . ($i + 1) . " has coordinates outside the Bacolod area: $lat, $lng");
    }
    $key = sprintf('%.7f,%.7f', $lat, $lng);
    if (isset($seenCoords[$key])) {
        fail('Clients #' . $seenCoords[$key] . ' and #' . ($i + 1) . " share the coordinates $key.");
    }
    $seenCoords[$key] = $i + 1;
}
$seenProjectClients = [];
foreach ($projectPlan as $p) {
    if ($clients[$p['client'] - 1][10] !== 'ACTIVE' || isset($seenProjectClients[$p['client']])) {
        fail('Internal seed data: project for client #' . $p['client'] . ' is invalid.');
    }
    $seenProjectClients[$p['client']] = true;
}

// --- Material-request plan: which units each order picks, so opening stock fits ---
$mrPlan = [];      // ordered list of orders
$usage = [];       // sku => net units the demo takes out of stock
$mrNo = 0;
foreach ($projectPlan as $pi => $p) {
    if ($p['mr'] === null) {
        continue;
    }
    $mrNo++;
    $lines = [['Solar Panel', $p['panel'], $p['panels']], ['Inverter', $p['inverter'], 1]];
    if ($p['battery']) {
        $lines[] = ['Battery', $p['battery'], $p['batteries']];
    }
    $picks = [];
    foreach ($lines as $li => [$cat, $sku, $qty]) {
        $pick = match ($p['mr']) {
            'RELEASED', 'READY' => $qty,
            'PREPARING'         => $cat === 'Solar Panel' ? intdiv($qty, 2) : ($cat === 'Inverter' ? 1 : 0),
            default             => 0,
        };
        if ($pick > 0) {
            $picks[$li] = $pick;
            $usage[$sku] = ($usage[$sku] ?? 0) + $pick;
        }
    }
    $mrPlan[] = ['code' => sprintf('MR-DEMO-%04d', $mrNo), 'project' => $pi, 'sr' => null, 'status' => $p['mr'], 'lines' => $lines, 'picks' => $picks];
}
// A replacement battery for the swollen one in SR-DEMO-021 — ordered, not yet prepared.
$mrNo++;
$mrPlan[] = ['code' => sprintf('MR-DEMO-%04d', $mrNo), 'project' => null, 'sr' => 21, 'status' => 'PENDING',
             'lines' => [['Battery', 'ST-INV-9011', 1]], 'picks' => []];
// Direct stock movements tied to service work.
$usage['ST-INV-9011'] = ($usage['ST-INV-9011'] ?? 0) + 1;   // warranty battery module for SR-DEMO-027
$usage['ST-INV-9001'] = ($usage['ST-INV-9001'] ?? 0) - 1;   // one surplus panel returned after an install

// ===========================================================================
// 2. Write helpers
// ===========================================================================

/**
 * Create or update a login by e-mail. Returns [users.id, was created].
 * The password is re-hashed on every run with password_hash(), exactly as
 * the app's own account endpoints do, so login.php's password_verify() works.
 */
function seed_user(PDO $pdo, int $roleId, string $email, string $name, ?string $phone, string $status): array
{
    $hash = password_hash(DEMO_PASSWORD, PASSWORD_DEFAULT);
    $find = $pdo->prepare('SELECT id FROM users WHERE email = :e');
    $find->execute([':e' => $email]);
    $id = $find->fetchColumn();

    if ($id) {
        $pdo->prepare(
            'UPDATE users SET role_id = :r, full_name = :n, phone = :p, status = :s, password_hash = :h WHERE id = :id'
        )->execute([':r' => $roleId, ':n' => $name, ':p' => $phone, ':s' => $status, ':h' => $hash, ':id' => $id]);
        return [(int)$id, false];
    }

    $pdo->prepare(
        'INSERT INTO users (role_id, email, password_hash, full_name, phone, status) VALUES (:r, :e, :h, :n, :p, :s)'
    )->execute([':r' => $roleId, ':e' => $email, ':h' => $hash, ':n' => $name, ':p' => $phone, ':s' => $status]);
    return [(int)$pdo->lastInsertId(), true];
}

/**
 * Create or update the role profile row (staff / technicians / clients) for a
 * user. A new row gets $preferredCode, or — if a real record already holds that
 * code — the next free code in the normal sequence, so the seed never collides
 * with live data. $insertOnly fields are written on creation only.
 *
 * @return array{0:int, 1:string} [profile id, code]
 */
function seed_profile(PDO $pdo, string $table, string $codeCol, int $userId, string $preferredCode, string $prefix, int $pad, array $fields, array $insertOnly = []): array
{
    $find = $pdo->prepare("SELECT id, `$codeCol` AS code FROM `$table` WHERE user_id = :u");
    $find->execute([':u' => $userId]);
    if ($row = $find->fetch()) {
        if ($fields) {
            $sets = implode(', ', array_map(fn($k) => "`$k` = :$k", array_keys($fields)));
            $params = [':id' => $row['id']];
            foreach ($fields as $k => $v) {
                $params[":$k"] = $v;
            }
            $pdo->prepare("UPDATE `$table` SET $sets WHERE id = :id")->execute($params);
        }
        return [(int)$row['id'], $row['code']];
    }

    $all = array_merge($fields, $insertOnly);
    $cols = array_merge(['user_id', $codeCol], array_keys($all));
    $sql = "INSERT INTO `$table` (`" . implode('`, `', $cols) . '`) VALUES (:user_id, :code, '
        . implode(', ', array_map(fn($k) => ":$k", array_keys($all))) . ')';
    $stmt = $pdo->prepare($sql);
    $params = [':user_id' => $userId];
    foreach ($all as $k => $v) {
        $params[":$k"] = $v;
    }

    $taken = $pdo->prepare("SELECT 1 FROM `$table` WHERE `$codeCol` = :c");
    $taken->execute([':c' => $preferredCode]);
    if (!$taken->fetchColumn()) {
        $stmt->execute($params + [':code' => $preferredCode]);
        return [(int)$pdo->lastInsertId(), $preferredCode];
    }
    $code = with_unique_code($table, $codeCol, $prefix, function (string $c) use ($stmt, $params) {
        $stmt->execute($params + [':code' => $c]);
        return $c;
    }, $pad);
    return [(int)$pdo->lastInsertId(), $code];
}

/** Insert a row with a code: the preferred code if free, else the next in $prefix's sequence. */
function seed_insert_with_code(PDO $pdo, string $table, string $codeCol, string $preferred, string $prefix, int $pad, int $floor, callable $insert): string
{
    $taken = $pdo->prepare("SELECT 1 FROM `$table` WHERE `$codeCol` = :c");
    $taken->execute([':c' => $preferred]);
    if (!$taken->fetchColumn()) {
        $insert($preferred);
        return $preferred;
    }
    return with_unique_code($table, $codeCol, $prefix, function (string $c) use ($insert) {
        $insert($c);
        return $c;
    }, $pad, 10, $floor);
}

out('SunTrack ERP — full demo seed');
out('Database: ' . DB_NAME);
out('Seeding... (hashing 67 passwords and drawing demo photos takes a few seconds)');

$created = [
    'users' => 0, 'requests' => 0, 'jobs' => 0, 'projects' => 0, 'systems' => 0, 'schedules' => 0,
    'items' => 0, 'movements' => 0, 'orders' => 0, 'invoices' => 0, 'payments' => 0, 'subcontractors' => 0,
    'photos' => 0, 'signoffs' => 0,
];
$skippedRequests = 0;
$managerUserIds = [];
$warehouseUserId = null;
$techProfiles = [];   // n => ['id' => technicians.id, 'user_id' => .., 'name' => .., 'code' => ..]
$clientProfiles = []; // n => ['id' => clients.id, 'user_id' => .., 'name' => .., 'code' => .., 'lat' => .., 'lng' => .., 'address' => ..]
$accountsOut = [];

// Statements shared by several sections.
$auditInsert = $pdo->prepare(
    'INSERT INTO audit_logs (user_id, role_key, action, module, record_id, ip_address, created_at)
     VALUES (:u, :r, :a, :m, :rec, "127.0.0.1", :at)'
);
$audit = fn(?int $uid, ?string $role, string $action, string $module, string $record, string $at) =>
    $auditInsert->execute([':u' => $uid, ':r' => $role, ':a' => $action, ':m' => $module, ':rec' => $record, ':at' => $at]);

$notifAny = $pdo->prepare(
    'INSERT INTO notifications (user_id, type, message, related_table, related_id, is_read, created_at)
     VALUES (:u, :type, :m, :tbl, :rid, :read, :at)'
);
$notifyAt = fn(int $uid, string $type, string $msg, ?string $tbl, ?int $rid, int $read, string $at) =>
    $notifAny->execute([':u' => $uid, ':type' => $type, ':m' => $msg, ':tbl' => $tbl, ':rid' => $rid, ':read' => $read, ':at' => $at]);

$jobFind = $pdo->prepare('SELECT id FROM jobs WHERE job_code = :c');
$jshInsert = $pdo->prepare(
    'INSERT INTO job_status_history (job_id, from_stage, to_stage, changed_by, note, created_at) VALUES (:j, :f, :t, :u, :n, :at)'
);
$attInsert = $pdo->prepare(
    'INSERT INTO attendance (technician_id, job_id, time_in, time_out, lat_in, lng_in, lat_out, lng_out,
                             distance_in_m, distance_out_m, geofence_status, created_at, updated_at)
     VALUES (:t, :j, :tin, :tout, :lat, :lng, :lat2, :lng2, :din, :dout, "INSIDE", :tin2, :upd)'
);
$wrInsert = $pdo->prepare(
    'INSERT IGNORE INTO work_reports (report_code, job_id, technician_id, client_id, work_type, remarks, materials_used,
                                      issues_found, duration_minutes, status, submitted_date, created_at)
     VALUES (:code, :j, :t, :c, :type, :remarks, :materials, :issues, :dur, "SUBMITTED", :at, :at2)'
);
$geoInsert = $geoExtra
    ? $pdo->prepare('INSERT INTO geofence_records (job_id, technician_id, lat, lng, distance_m, status, recorded_at, accuracy_m)
                     VALUES (:j, :t, :lat, :lng, :d, :s, :at, :acc)')
    : $pdo->prepare('INSERT INTO geofence_records (job_id, technician_id, lat, lng, distance_m, status, recorded_at)
                     VALUES (:j, :t, :lat, :lng, :d, :s, :at)');
$ping = function (int $jobId, int $techId, float $lat, float $lng, float $dist, string $status, string $at) use ($geoInsert, $geoExtra) {
    $p = [':j' => $jobId, ':t' => $techId, ':lat' => round($lat, 7), ':lng' => round($lng, 7), ':d' => round($dist, 2), ':s' => $status, ':at' => $at];
    if ($geoExtra) {
        $p[':acc'] = 8.0;
    }
    $geoInsert->execute($p);
};

$pdo->beginTransaction();
try {
    // =======================================================================
    // A. Accounts
    // =======================================================================
    $staffNo = 100;
    foreach ($systemAccounts as [$local, $role, $name, $phone, $dept, $position]) {
        $email = $local . '@' . DEMO_DOMAIN;
        [$uid, $isNew] = seed_user($pdo, $roleIds[$role], $email, $name, $phone, 'ACTIVE');
        $created['users'] += $isNew ? 1 : 0;
        if ($role === 'manager') {
            // Managers sign in through the Management portal, which resolves a staff profile.
            $staffNo++;
            seed_profile($pdo, 'staff', 'staff_code', $uid, 'STF-' . $staffNo, 'STF-', 3,
                ['department' => $dept, 'position' => $position, 'status' => 'ACTIVE']);
            $managerUserIds[] = $uid;
        }
        if ($role === 'warehouse') {
            $warehouseUserId = $uid;
        }
        $accountsOut[] = [ucfirst($role === 'manager' ? 'management' : $role), $email, $name];
    }

    foreach ($technicianAccounts as $i => [$name, $phone, $spec]) {
        $n = $i + 1;
        $email = 'technician' . $n . '@' . DEMO_DOMAIN;
        [$uid, $isNew] = seed_user($pdo, $roleIds['technician'], $email, $name, $phone, 'ACTIVE');
        $created['users'] += $isNew ? 1 : 0;
        [$techId, $code] = seed_profile($pdo, 'technicians', 'technician_code', $uid, pad_code('TECH-', $n, 2), 'TECH-', 2,
            ['specialization' => $spec], ['geofence_enabled' => 1]);
        // Availability is only created, never reset: a technician mid-job stays BUSY.
        $pdo->prepare('INSERT IGNORE INTO technician_availability (technician_id, status) VALUES (:t, "AVAILABLE")')
            ->execute([':t' => $techId]);
        $techProfiles[$n] = ['id' => $techId, 'user_id' => $uid, 'name' => $name, 'code' => $code];
        $accountsOut[] = ['Technician', $email, $name . " ($code)"];
    }

    foreach ($clients as $i => [$first, $middle, $last, $phone, $street, $brgy, $city, $postal, $lat, $lng, $status]) {
        $n = $i + 1;
        $name = "$first $middle $last";
        $email = 'client' . $n . '@' . DEMO_DOMAIN;
        [$uid, $isNew] = seed_user($pdo, $roleIds['client'], $email, $name, $phone, $status);
        $created['users'] += $isNew ? 1 : 0;

        // Registered over the past ~2 years, oldest first.
        $registered = day_offset(-(760 - $i * 12));
        [$clientId, $code] = seed_profile($pdo, 'clients', 'client_code', $uid, pad_code('CLIENT-', $n, 3), 'CLIENT-', 3,
            [
                'address' => $street, 'barangay' => $brgy, 'city' => $city, 'province' => 'Negros Occidental',
                'postal_code' => $postal, 'lat' => $lat, 'lng' => $lng, 'geofence_radius_m' => 500,
            ],
            ['date_registered' => $registered, 'created_at' => $registered . ' 09:00:00']
        );
        $clientProfiles[$n] = [
            'id' => $clientId, 'user_id' => $uid, 'name' => $name, 'last' => $last, 'code' => $code, 'lat' => $lat, 'lng' => $lng,
            'address' => "$street, $brgy, $city, Negros Occidental $postal",
        ];
    }
    $mgr = fn(int $k) => $managerUserIds[$k % count($managerUserIds)];

    // =======================================================================
    // B. Sub-contractors (master data: matched by name, kept up to date)
    // =======================================================================
    $scFind = $pdo->prepare('SELECT id FROM subcontractors WHERE name = :n');
    $scInsert = $pdo->prepare(
        'INSERT INTO subcontractors (subcon_code, name, specialization, phone, email, area, approved, created_at)
         VALUES (:code, :name, :spec, :phone, :email, :area, :ok, :at)'
    );
    foreach ($subcontractors as $k => [$code, $name, $spec, $phone, $email, $area, $ok]) {
        $scFind->execute([':n' => $name]);
        if ($id = $scFind->fetchColumn()) {
            $pdo->prepare('UPDATE subcontractors SET specialization = :s, phone = :p, email = :e, area = :a WHERE id = :id')
                ->execute([':s' => $spec, ':p' => $phone, ':e' => $email, ':a' => $area, ':id' => $id]);
            continue;
        }
        $at = day_at(400 - $k * 40, '10:00');
        $used = seed_insert_with_code($pdo, 'subcontractors', 'subcon_code', $code, 'SC-', 2, 0,
            fn(string $c) => $scInsert->execute([':code' => $c, ':name' => $name, ':spec' => $spec, ':phone' => $phone,
                                                  ':email' => $email, ':area' => $area, ':ok' => $ok, ':at' => $at]));
        $created['subcontractors']++;
        $audit($mgr($k), 'manager', 'CREATE', 'subcontractors', $used, $at);
    }

    // =======================================================================
    // C. Inventory (created once; stock only ever moves through movements)
    // =======================================================================
    $inv = [];   // sku => inventory.id
    $invFind = $pdo->prepare('SELECT id FROM inventory WHERE sku = :s');
    $invInsert = $pdo->prepare(
        'INSERT INTO inventory (sku, item_name, category_id, brand, model, serial_number, quantity, unit_cost, reorder_level,
                                warehouse_id, warehouse_location, status, qr_code, date_added, created_at)
         VALUES (:sku, :name, :cat, :brand, :model, :serial, 0, :cost, :reorder, :wh, :loc, :status, :qr, :added, :at)'
    );
    $moveExists = $pdo->prepare('SELECT 1 FROM stock_movements WHERE movement_code = :c');
    $moveInsert = $pdo->prepare(
        'INSERT INTO stock_movements (movement_code, inventory_id, movement_type, quantity, job_id, material_request_id,
                                      technician_id, from_location, to_location, reference, recorded_by, created_at)
         VALUES (:code, :inv, :type, :qty, :job, :mr, :tech, :from, :to, :ref, :by, :at)'
    );
    /**
     * Record one stock movement (once — matched by its code) and apply it to the
     * item. An ISSUE that the shelf cannot cover is skipped, never driven negative.
     */
    $move = function (string $code, string $sku, string $type, int $qty, string $at, array $o = []) use ($pdo, &$inv, $moveExists, $moveInsert, &$created, &$warehouseUserId): bool {
        if ($qty <= 0 || !isset($inv[$sku])) {
            return false;
        }
        $moveExists->execute([':c' => $code]);
        if ($moveExists->fetchColumn()) {
            return false;
        }
        $row = $pdo->prepare('SELECT quantity FROM inventory WHERE id = :id FOR UPDATE');
        $row->execute([':id' => $inv[$sku]]);
        $onHand = (int)$row->fetchColumn();
        $delta = $type === 'ISSUE' ? -$qty : $qty;
        if ($onHand + $delta < 0) {
            return false;
        }
        $moveInsert->execute([
            ':code' => $code, ':inv' => $inv[$sku], ':type' => $type, ':qty' => $qty,
            ':job' => $o['job'] ?? null, ':mr' => $o['mr'] ?? null, ':tech' => $o['tech'] ?? null,
            ':from' => $o['from'] ?? null, ':to' => $o['to'] ?? null, ':ref' => $o['ref'] ?? null,
            ':by' => $o['by'] ?? $warehouseUserId, ':at' => $at,
        ]);
        $pdo->prepare('UPDATE inventory SET quantity = quantity + :d WHERE id = :id')->execute([':d' => $delta, ':id' => $inv[$sku]]);
        $created['movements']++;
        return true;
    };

    foreach ($catalog as $k => [$sku, $name, $cat, $brand, $model, $cost, $reorder, $loc, $buffer, $watts]) {
        $invFind->execute([':s' => $sku]);
        $id = $invFind->fetchColumn();
        $isNew = false;
        if (!$id) {
            $invInsert->execute([
                ':sku' => $sku, ':name' => $name, ':cat' => $categoryIds[$cat], ':brand' => $brand, ':model' => $model,
                ':serial' => 'LOT-' . date('Y') . '-' . substr($sku, -4), ':cost' => $cost, ':reorder' => $reorder,
                ':wh' => $warehouseId, ':loc' => $loc,
                ':status' => in_array($sku, $discontinuedSkus, true) ? 'DISCONTINUED' : 'OUT_OF_STOCK',
                ':qr' => 'QR-' . $sku, ':added' => day_offset(-150), ':at' => day_at(150, '08:30'),
            ]);
            $id = (int)$pdo->lastInsertId();
            $isNew = true;
            $created['items']++;
            $audit($warehouseUserId, 'warehouse', 'CREATE', 'inventory', $sku, day_at(150, '08:30'));
        }
        $inv[$sku] = (int)$id;
        if ($isNew) {
            // Opening stock (most of it) and one restock delivery.
            $total = max(0, ($usage[$sku] ?? 0) + $buffer);
            $opening = (int)ceil($total * 0.7);
            $restock = $total - $opening;
            $move("MV-DEMO-R{$sku}-A", $sku, 'RECEIVE', $opening, day_at(150, '09:00'),
                ['ref' => 'PO-' . date('Y') . '-0' . (101 + $k) . ' opening stock', 'from' => $brand . ' distributor', 'to' => $warehouseRow['warehouse_name'] . ' / ' . $loc]);
            $move("MV-DEMO-R{$sku}-B", $sku, 'RECEIVE', $restock, day_at(28, '10:30'),
                ['ref' => 'PO-' . date('Y') . '-0' . (201 + $k) . ' restock', 'from' => $brand . ' distributor', 'to' => $warehouseRow['warehouse_name'] . ' / ' . $loc]);
        }
    }

    // =======================================================================
    // D. Projects, solar systems, installation jobs, maintenance
    // =======================================================================
    $sysFind     = $pdo->prepare('SELECT id FROM solar_systems WHERE client_id = :c ORDER BY id LIMIT 1');
    $sysInsert   = $pdo->prepare(
        'INSERT INTO solar_systems (system_code, client_id, panel_brand, inverter_brand, battery_brand, capacity_kw,
                                    installation_date, installation_address, warranty_info, status, created_at)
         VALUES (:code, :c, :pb, :ib, :bb, :kw, :date, :addr, :warranty, :status, :at)'
    );
    $prjFind     = $pdo->prepare('SELECT id, project_code FROM projects WHERE client_id = :c AND site_name = :s');
    $prjInsert   = $pdo->prepare(
        'INSERT INTO projects (project_code, client_id, solar_system_id, site_name, address, system_type, capacity_kw,
                               installation_date, assigned_technician_id, status, progress, last_maintenance, notes, created_at)
         VALUES (:code, :c, :sys, :site, :addr, :type, :kw, :date, :tech, :status, :progress, :lastm, :notes, :at)'
    );
    $jobInsert   = $pdo->prepare(
        'INSERT INTO jobs (job_code, project_id, client_id, technician_id, job_type, site_address, site_lat, site_lng, geofence_radius_m,
                           scheduled_date, priority, description, stage, progress, created_at, updated_at)
         VALUES (:code, :p, :c, :t, :type, :addr, :lat, :lng, 500, :sched, :prio, :desc, :stage, :progress, :created, :updated)'
    );
    $chkFind     = $pdo->prepare('SELECT id FROM installation_checklists WHERE job_id = :j');
    $chkInsert   = $pdo->prepare('INSERT INTO installation_checklists (job_id, progress, created_at) VALUES (:j, :p, :at)');
    $itemInsert  = $pdo->prepare(
        'INSERT INTO installation_items (checklist_id, item_key, category, description, status, completed_by, completed_date, remarks)
         VALUES (:c, :k, :cat, :d, :s, :by, :at, :r)'
    );
    $schedInsert = $pdo->prepare(
        'INSERT IGNORE INTO maintenance_schedules (project_id, last_maintenance, next_maintenance, status, client_notified, notified_at)
         VALUES (:p, :last, :next, :status, :notified, :nat)'
    );
    $mrecInsert  = $pdo->prepare(
        'INSERT INTO maintenance_records (job_id, client_id, solar_system_id, technician_id, panel_condition, battery_condition,
                                          inverter_condition, electrical_condition, inspection_results, materials_used, issues_found,
                                          remarks, status, completion_date, created_at)
         VALUES (:j, :c, :sys, :t, :pc, :bc, :ic, :ec, :res, :mat, :iss, :rem, "COMPLETED", :done, :at)'
    );
    $mitemInsert = $pdo->prepare(
        'INSERT INTO maintenance_items (maintenance_id, item_key, description, status, remarks) VALUES (:m, :k, :d, "COMPLETED", :r)'
    );
    $photoInsert = $hasPhotos ? $pdo->prepare(
        'INSERT INTO job_photos (job_id, uploaded_by, kind, file_name, mime, size_bytes, width, height, created_at)
         VALUES (:j, :u, :k, :f, "image/png", :s, 480, 320, :at)'
    ) : null;
    $signInsert = $hasSignoffs ? $pdo->prepare(
        'INSERT IGNORE INTO job_confirmations (job_id, confirmed_by, method, signer_name, signature_file, rating, comment, ip_address, created_at)
         VALUES (:j, :u, :m, :n, :f, :r, :c, "127.0.0.1", :at)'
    ) : null;

    $checklistTemplate = [
        ['sp1', 'Site Preparation', 'Site survey and roof assessment completed'],
        ['sp2', 'Site Preparation', 'Safety equipment and work area barricades set up'],
        ['sp3', 'Site Preparation', 'Materials checked against the bill of materials'],
        ['mo1', 'Mounting',         'Roof anchors / footings installed'],
        ['mo2', 'Mounting',         'Mounting rails installed and leveled'],
        ['mo3', 'Mounting',         'Solar panels mounted and clamped'],
        ['mo4', 'Mounting',         'Roof penetrations sealed and waterproofed'],
        ['el1', 'Electrical',       'DC string wiring and MC4 connections'],
        ['el2', 'Electrical',       'Combiner box / DC isolator installed'],
        ['el3', 'Electrical',       'Inverter mounted and connected'],
        ['el4', 'Electrical',       'AC wiring, breaker and grounding completed'],
        ['te1', 'Testing',          'Open-circuit voltage and polarity checked'],
        ['te2', 'Testing',          'Insulation resistance test passed'],
        ['te3', 'Testing',          'System powered up and output verified'],
        ['fi1', 'Finalization',     'Monitoring app configured for the client'],
        ['fi2', 'Finalization',     'Site cleaned and system labels applied'],
        ['fi3', 'Finalization',     'Client walkthrough and handover completed'],
    ];
    $maintTemplate = [
        ['mnt1', 'Panel inspection'], ['mnt2', 'Cable inspection'], ['mnt3', 'Inverter inspection'],
        ['mnt4', 'Battery inspection'], ['mnt5', 'Mounting inspection'], ['mnt6', 'Performance testing'],
    ];

    $projectIds = [];   // plan index => ['id', 'code', 'system', 'job' (install job id), 'job_code', 'date']
    $photoVariant = 0;
    $completedOrder = 0;

    foreach ($projectPlan as $pi => $p) {
        $c = $clientProfiles[$p['client']];
        $tech = $p['tech'] ? $techProfiles[$p['tech']] : null;
        $pPanel = $catalogBySku[$p['panel']];
        $pInv = $catalogBySku[$p['inverter']];
        $pBat = $p['battery'] ? $catalogBySku[$p['battery']] : null;
        $isStore = $p['client'] === 41;
        $siteName = $c['last'] . ($isStore ? ' Store Rooftop' : ' Residence') . ' — ' . number_format($p['kw'], 1) . ' kW';
        $systemType = $p['hybrid'] ? 'Hybrid (grid-tie + battery)' : 'Grid-tie';
        $installDate = $p['status'] === 'COMPLETED' ? day_offset(-$p['days']) : ($p['days'] !== null && $p['days'] <= 0 ? day_offset(-$p['days']) : null);
        $startedDaysAgo = $p['status'] === 'COMPLETED' ? $p['days'] + 25 : ($p['status'] === 'IN_PROGRESS' ? 14 : 20);

        // --- Solar system (one per client; reused if the client already has one) ---
        $sysFind->execute([':c' => $c['id']]);
        $systemId = $sysFind->fetchColumn() ?: null;
        if (!$systemId && $p['status'] !== 'CANCELLED') {
            $sysStatus = match ($p['status']) {
                'COMPLETED'   => $p['client'] === 38 ? 'FAULT' : 'ACTIVE',  // failed charge controller, SR-DEMO-023 on hold
                'IN_PROGRESS' => 'INSTALLING',
                default       => 'PLANNED',
            };
            $year = $installDate ? substr($installDate, 0, 4) : date('Y');
            seed_insert_with_code($pdo, 'solar_systems', 'system_code', sprintf('ST-SYS-%s-%03d', $year, $p['client']), "ST-SYS-$year-", 3, 0,
                fn(string $code) => $sysInsert->execute([
                    ':code' => $code, ':c' => $c['id'], ':pb' => $pPanel[3] . ' ' . $pPanel[4], ':ib' => $pInv[3] . ' ' . $pInv[4],
                    ':bb' => $pBat ? $pBat[3] . ' ' . $pBat[4] : null, ':kw' => $p['kw'],
                    ':date' => $p['status'] === 'COMPLETED' ? $installDate : null, ':addr' => $c['address'],
                    ':warranty' => 'Panels 25 yrs performance / 12 yrs product; inverter 10 yrs' . ($pBat ? '; battery 10 yrs' : ''),
                    ':status' => $sysStatus, ':at' => day_at($startedDaysAgo, '09:00'),
                ]));
            $systemId = (int)$pdo->lastInsertId();
            $created['systems']++;
        }

        // --- Project (matched by client + site name) -------------------------
        $prjFind->execute([':c' => $c['id'], ':s' => $siteName]);
        $prj = $prjFind->fetch();
        $isNewProject = false;
        if (!$prj) {
            $progress = match ($p['status']) {
                'COMPLETED' => 100,
                'IN_PROGRESS' => (int)round($p['checklist_done'] * 100 / 17),
                default => 0,
            };
            $notes = match ($p['status']) {
                'CANCELLED' => 'Client postponed the project indefinitely (budget). Quotation kept on file.',
                'PLANNED'   => 'Site survey done; waiting for the client to confirm the battery option.',
                default     => $p['panels'] . ' x ' . $pPanel[1] . ', 1 x ' . $pInv[1] . ($pBat ? ', ' . $p['batteries'] . ' x ' . $pBat[1] : '') . '.',
            };
            $code = seed_insert_with_code($pdo, 'projects', 'project_code', 'SITE-' . (801 + $pi), 'SITE-', 3, 800,
                fn(string $code) => $prjInsert->execute([
                    ':code' => $code, ':c' => $c['id'], ':sys' => $systemId, ':site' => $siteName, ':addr' => $c['address'],
                    ':type' => $systemType, ':kw' => $p['kw'], ':date' => $installDate, ':tech' => $tech ? $tech['id'] : null,
                    ':status' => $p['status'], ':progress' => $progress, ':lastm' => null, ':notes' => $notes,
                    ':at' => day_at($startedDaysAgo, '09:30'),
                ]));
            $prj = ['id' => (int)$pdo->lastInsertId(), 'project_code' => $code];
            $isNewProject = true;
            $created['projects']++;
            $audit($mgr($pi), 'manager', 'CREATE', 'projects', $code, day_at($startedDaysAgo, '09:30'));
        }
        $projectId = (int)$prj['id'];
        $projectIds[$pi] = ['id' => $projectId, 'code' => $prj['project_code'], 'system' => $systemId, 'job' => null, 'job_code' => null, 'date' => $installDate];

        if (!$tech || $p['job_stage'] === null) {
            continue;
        }

        // --- Installation job --------------------------------------------------
        $jobCode = sprintf('JOB-DEMO-I%03d', $p['client']);
        $jobFind->execute([':c' => $jobCode]);
        $jobId = $jobFind->fetchColumn() ?: null;
        $isNewJob = false;
        if (!$jobId) {
            $stage = $p['job_stage'];
            $jobProgress = $stage === 'COMPLETED' ? 100 : (int)round($p['checklist_done'] * 100 / 17);
            [$createdAt, $updatedAt] = match ($stage) {
                'COMPLETED'   => [day_at($p['days'] + 7, '10:00'), day_at($p['days'], '16:40')],
                'IN_PROGRESS' => [day_at(6, '10:00'), hours_ago(0.4)],
                'EN_ROUTE'    => [day_at(6, '10:00'), hours_ago(0.5)],
                default       => [day_at(5, '10:00'), day_at(5, '10:00')],
            };
            $jobInsert->execute([
                ':code' => $jobCode, ':p' => $projectId, ':c' => $c['id'], ':t' => $tech['id'], ':type' => 'INSTALLATION',
                ':addr' => $c['address'], ':lat' => $c['lat'], ':lng' => $c['lng'], ':sched' => $installDate,
                ':prio' => 'NORMAL', ':desc' => "Install {$p['kw']} kW {$systemType} system — {$siteName} ({$prj['project_code']})",
                ':stage' => $stage, ':progress' => $jobProgress, ':created' => $createdAt, ':updated' => $updatedAt,
            ]);
            $jobId = (int)$pdo->lastInsertId();
            $isNewJob = true;
            $created['jobs']++;

            $jsh = fn(?string $from, string $to, int $by, string $at, ?string $note = null) =>
                $jshInsert->execute([':j' => $jobId, ':f' => $from, ':t' => $to, ':u' => $by, ':n' => $note, ':at' => $at]);
            $jsh(null, 'ASSIGNED', $mgr($pi), $createdAt, "Installation scheduled for {$prj['project_code']}");
            $notifyAt($tech['user_id'], 'JOB_STATUS', "New job assigned to you: $jobCode.", 'jobs', $jobId, $stage === 'ASSIGNED' ? 0 : 1, $createdAt);

            if ($stage === 'COMPLETED') {
                $d = $p['days'];
                $jsh('ASSIGNED', 'EN_ROUTE', $tech['user_id'], day_at($d, '07:30'));
                $jsh('EN_ROUTE', 'ARRIVED', $tech['user_id'], day_at($d, '08:10'));
                $jsh('ARRIVED', 'IN_PROGRESS', $tech['user_id'], day_at($d, '08:25'));
                $jsh('IN_PROGRESS', 'COMPLETED', $tech['user_id'], day_at($d, '16:40'), 'System commissioned and handed over.');
                $attInsert->execute([
                    ':t' => $tech['id'], ':j' => $jobId, ':tin' => day_at($d, '08:15'), ':tout' => day_at($d, '16:30'),
                    ':lat' => round($c['lat'] + 0.00011, 7), ':lng' => round($c['lng'] - 0.00008, 7),
                    ':lat2' => round($c['lat'] + 0.00006, 7), ':lng2' => round($c['lng'] + 0.00004, 7),
                    ':din' => 15.6 + $pi % 9, ':dout' => 9.4 + $pi % 7, ':tin2' => day_at($d, '08:15'), ':upd' => day_at($d, '16:30'),
                ]);
                $ping($jobId, $tech['id'], $c['lat'] + 0.00011, $c['lng'] - 0.00008, 15.6 + $pi % 9, 'INSIDE', day_at($d, '08:15'));
                $ping($jobId, $tech['id'], $c['lat'] + 0.00006, $c['lng'] + 0.00004, 9.4 + $pi % 7, 'INSIDE', day_at($d, '16:30'));
                $wrInsert->execute([
                    ':code' => sprintf('WR-DEMO-I%03d', $p['client']), ':j' => $jobId, ':t' => $tech['id'], ':c' => $c['id'],
                    ':type' => 'Installation',
                    ':remarks' => "Installed {$p['panels']} panels ({$pPanel[1]}), {$pInv[1]}" . ($pBat ? " and {$p['batteries']} x {$pBat[1]}" : '') . '. All 17 checklist items passed; system commissioned and client briefed on the monitoring app.',
                    ':materials' => "{$p['panels']} x {$pPanel[1]}, 1 x {$pInv[1]}" . ($pBat ? ", {$p['batteries']} x {$pBat[1]}" : '') . ', rails, clamps, PV cable, MC4 connectors, breakers',
                    ':issues' => $pi % 4 === 0 ? 'Two roof sheets replaced before mounting (client-supplied).' : 'None',
                    ':dur' => 470 + ($pi % 4) * 15, ':at' => day_at($d, '16:20'), ':at2' => day_at($d, '16:20'),
                ]);
                $audit($tech['user_id'], 'technician', 'STATUS_CHANGE:IN_PROGRESS->COMPLETED', 'jobs', $jobCode, day_at($d, '16:40'));
                $notifyAt($c['user_id'], 'JOB_STATUS', "Job $jobCode: Your job has been completed.", 'jobs', $jobId, 1, day_at($d, '16:40'));
            } elseif ($stage === 'IN_PROGRESS') {
                // Working on site right now: timed in, sending GPS pings.
                $jsh('ASSIGNED', 'EN_ROUTE', $tech['user_id'], hours_ago(3.2));
                $jsh('EN_ROUTE', 'ARRIVED', $tech['user_id'], hours_ago(2.7));
                $jsh('ARRIVED', 'IN_PROGRESS', $tech['user_id'], hours_ago(2.5));
                $attInsert->execute([
                    ':t' => $tech['id'], ':j' => $jobId, ':tin' => hours_ago(2.6), ':tout' => null,
                    ':lat' => round($c['lat'] + 0.00009, 7), ':lng' => round($c['lng'] + 0.00007, 7), ':lat2' => null, ':lng2' => null,
                    ':din' => 12.8, ':dout' => null, ':tin2' => hours_ago(2.6), ':upd' => hours_ago(2.6),
                ]);
                for ($h = 2.6; $h > 0.05; $h -= 0.33) {
                    $ping($jobId, $tech['id'], $c['lat'] + 0.00009 * sin($h * 3), $c['lng'] + 0.00007 * cos($h * 3), 8 + 6 * abs(sin($h)), 'INSIDE', hours_ago($h));
                }
                $pdo->prepare('UPDATE technician_availability SET status = "BUSY" WHERE technician_id = :t AND status = "AVAILABLE"')
                    ->execute([':t' => $tech['id']]);
            } elseif ($stage === 'EN_ROUTE') {
                $jsh('ASSIGNED', 'EN_ROUTE', $tech['user_id'], hours_ago(0.5), 'Leaving the warehouse with the prepared order.');
                foreach ([[0.45, 0.018], [0.35, 0.013], [0.25, 0.009], [0.15, 0.006], [0.07, 0.004]] as [$h, $off]) {
                    $lat = $c['lat'] - $off;
                    $lng = $c['lng'] - $off * 0.6;
                    $ping($jobId, $tech['id'], $lat, $lng, distance_meters($lat, $lng, $c['lat'], $c['lng']), 'OUTSIDE', hours_ago($h));
                }
            }
        }
        $projectIds[$pi]['job'] = (int)$jobId;
        $projectIds[$pi]['job_code'] = $jobCode;

        // --- The 17-item checklist (created once with the job) ------------------
        $chkFind->execute([':j' => $jobId]);
        if (!$chkFind->fetchColumn()) {
            $done = $p['checklist_done'];
            $chkInsert->execute([':j' => $jobId, ':p' => (int)round($done * 100 / 17), ':at' => $p['status'] === 'COMPLETED' ? day_at($p['days'], '08:30') : day_at(5, '10:00')]);
            $checklistId = (int)$pdo->lastInsertId();
            foreach ($checklistTemplate as $k => [$key, $cat, $desc]) {
                $isDone = $k < $done;
                $at = null;
                if ($isDone) {
                    $at = $p['status'] === 'COMPLETED'
                        ? day_at($p['days'], sprintf('%02d:%02d', 8 + intdiv($k * 30, 60), ($k * 30) % 60))
                        : hours_ago(2.4 - $k * 0.2);
                }
                $itemInsert->execute([
                    ':c' => $checklistId, ':k' => $key, ':cat' => $cat, ':d' => $desc,
                    ':s' => $isDone ? 'COMPLETED' : 'PENDING', ':by' => $isDone ? $tech['user_id'] : null, ':at' => $at,
                    ':r' => $isDone && $key === 'te3' ? 'Output verified against the expected yield.' : null,
                ]);
            }
        }

        if ($p['status'] !== 'COMPLETED' || !$isNewJob) {
            continue;
        }
        $completedOrder++;

        // --- Before / after photos and the client's sign-off (phase 7) ----------
        if ($p['days'] <= 130 && $photoInsert) {
            foreach (['BEFORE', 'AFTER'] as $kind) {
                [$file, $bytes] = demo_store_png('job_photos', demo_site_photo($kind, $photoVariant));
                $photoInsert->execute([':j' => $jobId, ':u' => $tech['user_id'], ':k' => $kind, ':f' => $file, ':s' => $bytes,
                                       ':at' => day_at($p['days'], $kind === 'BEFORE' ? '08:20' : '16:10')]);
                $created['photos']++;
            }
            $photoVariant++;
        }
        if ($p['days'] <= 330 && $signInsert) {
            [$file] = demo_store_png('signatures', demo_signature($pi));
            $onSite = $pi % 2 === 0;
            $signInsert->execute([
                ':j' => $jobId, ':u' => $onSite ? $tech['user_id'] : $c['user_id'], ':m' => $onSite ? 'ON_SITE' : 'CLIENT_PORTAL',
                ':n' => $c['name'], ':f' => $file, ':r' => $pi % 5 === 0 ? 4 : 5,
                ':c' => $pi % 5 === 0 ? 'Good work. Team arrived a bit late but finished on time.' : 'Very professional team, clean installation. Thank you!',
                ':at' => $onSite ? day_at($p['days'], '16:45') : day_at($p['days'] - 1, '19:10'),
            ]);
            $created['signoffs']++;
        }
    }

    // --- Maintenance: history visits, schedules and one open visit -------------
    $maintJobNo = 0;
    foreach ($projectPlan as $pi => $p) {
        if ($p['status'] !== 'COMPLETED') {
            continue;
        }
        $pr = $projectIds[$pi];
        $c = $clientProfiles[$p['client']];
        $lastMaint = null;

        // Systems installed more than a year ago had their first-year visit.
        if ($p['days'] > 400) {
            $maintJobNo++;
            $tech = $techProfiles[(($pi + 4) % 10) + 1];
            $visitDays = $p['days'] - 365;
            $code = sprintf('JOB-DEMO-M%02d', $maintJobNo);
            $jobFind->execute([':c' => $code]);
            if (!$jobFind->fetchColumn()) {
                $jobInsert->execute([
                    ':code' => $code, ':p' => $pr['id'], ':c' => $c['id'], ':t' => $tech['id'], ':type' => 'MAINTENANCE',
                    ':addr' => $c['address'], ':lat' => $c['lat'], ':lng' => $c['lng'], ':sched' => day_offset(-$visitDays),
                    ':prio' => 'NORMAL', ':desc' => "First-year maintenance — {$pr['code']}", ':stage' => 'COMPLETED', ':progress' => 100,
                    ':created' => day_at($visitDays + 10, '09:00'), ':updated' => day_at($visitDays, '12:30'),
                ]);
                $mJobId = (int)$pdo->lastInsertId();
                $created['jobs']++;
                foreach ([[null, 'ASSIGNED', $mgr($pi), day_at($visitDays + 10, '09:00'), 'Maintenance scheduled by Management'],
                          ['ASSIGNED', 'EN_ROUTE', $tech['user_id'], day_at($visitDays, '08:00'), null],
                          ['EN_ROUTE', 'ARRIVED', $tech['user_id'], day_at($visitDays, '08:35'), null],
                          ['ARRIVED', 'IN_PROGRESS', $tech['user_id'], day_at($visitDays, '08:45'), null],
                          ['IN_PROGRESS', 'COMPLETED', $tech['user_id'], day_at($visitDays, '12:30'), null]] as [$f, $t, $by, $at, $note]) {
                    $jshInsert->execute([':j' => $mJobId, ':f' => $f, ':t' => $t, ':u' => $by, ':n' => $note, ':at' => $at]);
                }
                $attInsert->execute([
                    ':t' => $tech['id'], ':j' => $mJobId, ':tin' => day_at($visitDays, '08:40'), ':tout' => day_at($visitDays, '12:20'),
                    ':lat' => round($c['lat'] + 0.0001, 7), ':lng' => round($c['lng'], 7), ':lat2' => round($c['lat'], 7), ':lng2' => round($c['lng'] + 0.0001, 7),
                    ':din' => 11.1, ':dout' => 10.9, ':tin2' => day_at($visitDays, '08:40'), ':upd' => day_at($visitDays, '12:20'),
                ]);
                $fair = $maintJobNo % 3 === 0;
                $mrecInsert->execute([
                    ':j' => $mJobId, ':c' => $c['id'], ':sys' => $pr['system'], ':t' => $tech['id'],
                    ':pc' => 'Good', ':bc' => $p['hybrid'] ? ($fair ? 'Fair' : 'Good') : null, ':ic' => 'Good', ':ec' => $fair ? 'Fair' : 'Good',
                    ':res' => 'Annual inspection: panels cleaned, connections re-torqued, inverter logs reviewed. Output within 3% of expected yield.',
                    ':mat' => 'Cleaning kit, anti-corrosion spray', ':iss' => $fair ? 'Minor corrosion on two mid clamps; treated.' : 'None',
                    ':rem' => 'Next visit in 12 months.', ':done' => day_at($visitDays, '12:30'), ':at' => day_at($visitDays, '08:45'),
                ]);
                $recId = (int)$pdo->lastInsertId();
                foreach ($maintTemplate as [$key, $desc]) {
                    $mitemInsert->execute([':m' => $recId, ':k' => $key, ':d' => $desc,
                        ':r' => $key === 'mnt4' && !$p['hybrid'] ? 'No battery on this system.' : null]);
                }
                $wrInsert->execute([
                    ':code' => sprintf('WR-DEMO-M%02d', $maintJobNo), ':j' => $mJobId, ':t' => $tech['id'], ':c' => $c['id'],
                    ':type' => 'Maintenance', ':remarks' => 'First-year maintenance completed. Panels cleaned; all six inspection points passed.',
                    ':materials' => 'Cleaning kit, anti-corrosion spray', ':issues' => $fair ? 'Minor clamp corrosion treated.' : 'None',
                    ':dur' => 215, ':at' => day_at($visitDays, '12:15'), ':at2' => day_at($visitDays, '12:15'),
                ]);
            }
            $lastMaint = day_offset(-$visitDays);
        }
        if ($p['client'] === 6) {
            $lastMaint = day_offset(-28);           // SR-DEMO-024 annual maintenance, done 28 days ago
        }
        if ($lastMaint) {
            $pdo->prepare('UPDATE projects SET last_maintenance = :d WHERE id = :id AND (last_maintenance IS NULL OR last_maintenance < :d2)')
                ->execute([':d' => $lastMaint, ':d2' => $lastMaint, ':id' => $pr['id']]);
        }

        $next = $p['client'] === 6 ? day_offset(330) : day_offset($p['next_maint']);
        $status = maint_status($next);
        $notified = in_array($status, ['DUE', 'OVERDUE'], true) && $pi % 3 !== 2;
        $schedInsert->execute([
            ':p' => $pr['id'], ':last' => $lastMaint, ':next' => $next, ':status' => $status,
            ':notified' => $notified ? 1 : 0, ':nat' => $notified ? day_at(5, '09:00') : null,
        ]);
        if ($schedInsert->rowCount() > 0) {
            $created['schedules']++;
            if ($notified) {
                $notifyAt($c['user_id'], 'MAINTENANCE_DUE', "Your maintenance schedule has been updated. Next visit: $next.", 'maintenance_schedules', (int)$pdo->lastInsertId(), 0, day_at(5, '09:00'));
            }
        }
    }

    // An overdue system already has its visit booked (Maintenance -> Assign).
    $overduePi = null;
    foreach ($projectPlan as $pi => $p) {
        if ($p['status'] === 'COMPLETED' && $p['next_maint'] === -40) {
            $overduePi = $pi;
            break;
        }
    }
    if ($overduePi !== null) {
        $p = $projectPlan[$overduePi];
        $pr = $projectIds[$overduePi];
        $c = $clientProfiles[$p['client']];
        $tech = $techProfiles[9];
        $code = 'JOB-DEMO-M90';
        $jobFind->execute([':c' => $code]);
        if (!$jobFind->fetchColumn()) {
            $jobInsert->execute([
                ':code' => $code, ':p' => $pr['id'], ':c' => $c['id'], ':t' => $tech['id'], ':type' => 'MAINTENANCE',
                ':addr' => $c['address'], ':lat' => $c['lat'], ':lng' => $c['lng'], ':sched' => day_offset(2),
                ':prio' => 'HIGH', ':desc' => "Scheduled maintenance for {$pr['code']} (overdue)", ':stage' => 'ASSIGNED', ':progress' => 0,
                ':created' => day_at(1, '15:00'), ':updated' => day_at(1, '15:00'),
            ]);
            $mJobId = (int)$pdo->lastInsertId();
            $created['jobs']++;
            $jshInsert->execute([':j' => $mJobId, ':f' => null, ':t' => 'ASSIGNED', ':u' => $mgr(1), ':n' => 'Maintenance scheduled by Management', ':at' => day_at(1, '15:00')]);
            $notifyAt($tech['user_id'], 'JOB_STATUS', "New maintenance job assigned to you: $code.", 'jobs', $mJobId, 0, day_at(1, '15:00'));
            $audit($mgr(1), 'manager', 'ASSIGN', 'maintenance_schedules', $pr['code'], day_at(1, '15:00'));
        }
    }

    // =======================================================================
    // E. Service requests (created once, never rewound)
    // =======================================================================
    $srExists  = $pdo->prepare('SELECT id FROM service_requests WHERE request_code = :c');
    $srInsert  = $pdo->prepare(
        'INSERT INTO service_requests
            (request_code, client_id, created_by, solar_system_id, job_id, request_type, subject, description, site_address,
             location_lat, location_lng, priority, status, assigned_technician_id, technician_notes, resolution,
             date_requested, scheduled_date, completion_date, created_at, updated_at)
         VALUES (:code, :client, :created_by, :sys, :job, :type, :subject, :desc, :addr,
                 :lat, :lng, :priority, :status, :tech, :notes, :resolution,
                 :requested, :scheduled, :completed, :requested2, :updated)'
    );
    $histInsert = $pdo->prepare(
        'INSERT INTO service_request_history (service_request_id, user_id, action, old_status, new_status, remarks, created_at)
         VALUES (:sr, :u, :a, :o, :n, :r, :t)'
    );
    $srJobInsert = $pdo->prepare(
        'INSERT INTO jobs (job_code, client_id, technician_id, job_type, site_address, site_lat, site_lng, geofence_radius_m,
                           scheduled_date, priority, description, stage, progress, created_at, updated_at)
         VALUES (:code, :client, :tech, :type, :addr, :lat, :lng, 500, :sched, :priority, :desc, :stage, :progress, :created, :updated)'
    );
    $systemOf = [];
    foreach ($projectPlan as $pi => $p) {
        $systemOf[$p['client']] = $projectIds[$pi]['system'] ?? null;
    }

    $jobTypeFor = fn(string $t) => match ($t) { 'Maintenance' => 'MAINTENANCE', 'Inspection' => 'INSPECTION', default => 'REPAIR' };
    $progressFor = ['ASSIGNED' => 0, 'EN_ROUTE' => 10, 'ARRIVED' => 25, 'IN_PROGRESS' => 60, 'PAUSED' => 60, 'COMPLETED' => 100];
    $srJobIds = [];

    foreach ($requests as [$n, $cNo, $type, $subject, $desc, $priority, $status, $tNo, $reqH, $schedDays, $doneH, $stage, $notes, $resolution, $remarks]) {
        $code = sprintf('SR-DEMO-%03d', $n);
        $client  = $clientProfiles[$cNo];
        $jobCode = $tNo ? sprintf('JOB-DEMO-%03d', $n) : null;

        $srExists->execute([':c' => $code]);
        if ($srId = $srExists->fetchColumn()) {
            $skippedRequests++;
            // Older runs had no solar systems yet: link the request to the client's system.
            $pdo->prepare('UPDATE service_requests SET solar_system_id = :s, updated_at = updated_at WHERE id = :id AND solar_system_id IS NULL')
                ->execute([':s' => $systemOf[$cNo] ?? null, ':id' => $srId]);
            if ($jobCode) {
                $jobFind->execute([':c' => $jobCode]);
                $srJobIds[$n] = (int)$jobFind->fetchColumn() ?: null;
            }
            continue;
        }

        $tech    = $tNo ? $techProfiles[$tNo] : null;
        $manager = $managerUserIds[($n - 1) % count($managerUserIds)];
        $sched   = $schedDays !== null ? day_offset($schedDays) : null;

        // Event timeline (hours ago), always in the past and in order.
        $tCreated  = $reqH;
        $tApproved = $reqH - 2;
        $tAssigned = $reqH - 6;
        $tStarted  = match (true) {
            $stage === 'COMPLETED' => $doneH + 4,
            $stage === 'PAUSED'    => 49,
            in_array($stage, ['EN_ROUTE', 'ARRIVED'], true) => $n % 2 ? 1.5 : 2.5,
            default => null,
        };
        $lastEvent = match ($status) {
            'PENDING'   => $tCreated,
            'APPROVED'  => $tApproved,
            'REJECTED'  => $reqH - 3,
            'CANCELLED' => $reqH - 20,
            'ASSIGNED'  => $tAssigned,
            'SCHEDULED' => $tAssigned - 1,
            'ON_HOLD'   => 45,
            'COMPLETED' => $doneH,
            default     => $stage === 'ARRIVED' ? $tStarted - 0.5 : $tStarted,
        };

        // The job first, so the request can point at it.
        $jobId = null;
        if ($tech) {
            $jobFind->execute([':c' => $jobCode]);
            $jobId = $jobFind->fetchColumn() ?: null;
            if (!$jobId) {
                $srJobInsert->execute([
                    ':code' => $jobCode, ':client' => $client['id'], ':tech' => $tech['id'], ':type' => $jobTypeFor($type),
                    ':addr' => $client['address'], ':lat' => $client['lat'], ':lng' => $client['lng'],
                    ':sched' => $sched, ':priority' => $priority,
                    ':desc' => "$code — $subject ($type): $desc",
                    ':stage' => $stage, ':progress' => $progressFor[$stage] ?? 0,
                    ':created' => hours_ago($tAssigned), ':updated' => hours_ago($lastEvent),
                ]);
                $jobId = (int)$pdo->lastInsertId();
                $created['jobs']++;

                $jh = fn(?string $from, string $to, int $by, float $h, ?string $note = null) => $jshInsert->execute([
                    ':j' => $jobId, ':f' => $from, ':t' => $to, ':u' => $by, ':n' => $note, ':at' => hours_ago($h),
                ]);
                $jh(null, 'ASSIGNED', $manager, $tAssigned, "Created from service request $code");
                $chain = match ($stage) {
                    'EN_ROUTE'  => ['EN_ROUTE'],
                    'ARRIVED'   => ['EN_ROUTE', 'ARRIVED'],
                    'PAUSED'    => ['EN_ROUTE', 'ARRIVED', 'IN_PROGRESS', 'PAUSED'],
                    'COMPLETED' => ['EN_ROUTE', 'ARRIVED', 'IN_PROGRESS', 'COMPLETED'],
                    default     => [],
                };
                $prev = 'ASSIGNED';
                foreach ($chain as $k => $to) {
                    $at = $to === 'COMPLETED' ? $doneH : ($to === 'PAUSED' ? 45 : $tStarted - $k * 0.5);
                    $jh($prev, $to, $tech['user_id'], $at, $to === 'PAUSED' ? $remarks : null);
                    $prev = $to;
                }

                // Real time in/out where the work actually happened on site.
                if (in_array($stage, ['PAUSED', 'COMPLETED'], true)) {
                    $tin  = $stage === 'COMPLETED' ? $doneH + 3.2 : 48.2; // just before "Start Work"
                    $tout = $stage === 'COMPLETED' ? $doneH + 0.1 : 45.2;
                    $attInsert->execute([
                        ':t' => $tech['id'], ':j' => $jobId, ':tin' => hours_ago($tin), ':tout' => hours_ago($tout),
                        ':lat' => round($client['lat'] + 0.00012, 7), ':lng' => round($client['lng'] - 0.00009, 7),
                        ':lat2' => round($client['lat'] + 0.00008, 7), ':lng2' => round($client['lng'] + 0.00005, 7),
                        ':din' => 16.4 + $n % 9, ':dout' => 10.2 + $n % 7, ':tin2' => hours_ago($tin), ':upd' => hours_ago($tout),
                    ]);
                    $ping($jobId, $tech['id'], $client['lat'] + 0.00012, $client['lng'] - 0.00009, 16.4 + $n % 9, 'INSIDE', hours_ago($tin));
                    $ping($jobId, $tech['id'], $client['lat'] + 0.00008, $client['lng'] + 0.00005, 10.2 + $n % 7, 'INSIDE', hours_ago($tout));
                }
                if ($stage === 'COMPLETED') {
                    $wrInsert->execute([
                        ':code' => sprintf('WR-DEMO-%03d', $n), ':j' => $jobId, ':t' => $tech['id'], ':c' => $client['id'],
                        ':type' => ucfirst(strtolower($jobTypeFor($type))), ':remarks' => $resolution,
                        ':materials' => $type === 'Battery Issue' ? '1 battery module (warranty)' : ($type === 'Maintenance' ? 'Cleaning kit, anti-corrosion spray' : 'None'),
                        ':issues' => $notes, ':dur' => 150 + ($n % 5) * 10,
                        ':at' => hours_ago($doneH + 0.3), ':at2' => hours_ago($doneH + 0.3),
                    ]);
                    if ($photoInsert) {
                        foreach (['BEFORE', 'AFTER'] as $kind) {
                            [$file, $bytes] = demo_store_png('job_photos', demo_site_photo($kind, $n));
                            $photoInsert->execute([':j' => $jobId, ':u' => $tech['user_id'], ':k' => $kind, ':f' => $file, ':s' => $bytes,
                                                   ':at' => hours_ago($kind === 'BEFORE' ? $doneH + 3 : $doneH + 0.4)]);
                            $created['photos']++;
                        }
                    }
                    if ($signInsert && $n % 2 === 0) {
                        [$file] = demo_store_png('signatures', demo_signature($n));
                        $signInsert->execute([':j' => $jobId, ':u' => $client['user_id'], ':m' => 'CLIENT_PORTAL', ':n' => $client['name'],
                            ':f' => $file, ':r' => 5, ':c' => 'Fixed quickly. Thank you!', ':at' => hours_ago($doneH - 5)]);
                        $created['signoffs']++;
                    }
                }
            }
        }
        $srJobIds[$n] = $jobId ? (int)$jobId : null;

        $srInsert->execute([
            ':code' => $code, ':client' => $client['id'], ':created_by' => $client['user_id'], ':sys' => $systemOf[$cNo] ?? null, ':job' => $jobId,
            ':type' => $type, ':subject' => $subject, ':desc' => $desc, ':addr' => $client['address'],
            ':lat' => $client['lat'], ':lng' => $client['lng'], ':priority' => $priority, ':status' => $status,
            ':tech' => $tech ? $tech['id'] : null, ':notes' => $notes, ':resolution' => $resolution,
            ':requested' => hours_ago($tCreated), ':scheduled' => $sched,
            ':completed' => $status === 'COMPLETED' ? hours_ago($doneH) : null,
            ':requested2' => hours_ago($tCreated), ':updated' => hours_ago($lastEvent),
        ]);
        $srId = (int)$pdo->lastInsertId();
        $created['requests']++;

        // History, oldest first.
        $h = fn(string $action, ?string $old, ?string $new, ?int $by, float $at, ?string $r = null) => $histInsert->execute([
            ':sr' => $srId, ':u' => $by, ':a' => $action, ':o' => $old, ':n' => $new, ':r' => $r, ':t' => hours_ago($at),
        ]);
        $h('CREATED', null, 'PENDING', $client['user_id'], $tCreated, 'Submitted by the client.');

        if ($status === 'REJECTED') {
            $h('REJECTED', 'PENDING', 'REJECTED', $manager, $reqH - 3, $remarks);
        } elseif ($status !== 'PENDING') {
            $h('APPROVED', 'PENDING', 'APPROVED', $manager, $tApproved);
        }
        if ($status === 'CANCELLED') {
            $h('CANCELLED', 'APPROVED', 'CANCELLED', $client['user_id'], $reqH - 20, "Cancelled by the client: $remarks");
        }
        if ($tech) {
            $h('ASSIGNED', 'APPROVED', 'ASSIGNED', $manager, $tAssigned, "Assigned to {$tech['name']} ({$tech['code']}), job $jobCode");
            if ($sched !== null) {
                $h('SCHEDULED', 'ASSIGNED', 'SCHEDULED', $manager, $tAssigned - 1, "Service date set to $sched");
            }
            $before = $sched !== null ? 'SCHEDULED' : 'ASSIGNED';
            if ($tStarted !== null) {
                $h('WORK_STARTED', $before, 'IN_PROGRESS', $tech['user_id'], $tStarted, 'Job stage: En Route');
            }
            if ($notes !== null && $status !== 'COMPLETED') {
                $h('TECH_NOTE', 'IN_PROGRESS', 'IN_PROGRESS', $tech['user_id'], $stage === 'PAUSED' ? 45.5 : max(0.2, $tStarted - 1), $notes);
            }
            if ($status === 'ON_HOLD') {
                $h('PUT_ON_HOLD', 'IN_PROGRESS', 'ON_HOLD', $tech['user_id'], 45, "Job stage: Paused — $remarks");
            }
            if ($status === 'COMPLETED') {
                $h('WORK_COMPLETED', 'IN_PROGRESS', 'COMPLETED', $tech['user_id'], $doneH, 'Job stage: Completed');
            }
        }

        // A few notifications, the way the live app would have sent them.
        if ($status === 'PENDING') {
            foreach ($managerUserIds as $mid) {
                $notifyAt($mid, 'SERVICE_REQUEST', "New service request $code from {$client['name']}: $subject ($type, $priority)", 'service_requests', $srId, 0, hours_ago($tCreated));
            }
        }
        if ($tech && $status !== 'COMPLETED') {
            $notifyAt($tech['user_id'], 'SERVICE_REQUEST', "You've been assigned service request $code ($subject) — job $jobCode" . ($sched ? " on $sched" : '') . '.',
                'service_requests', $srId, in_array($status, ['ASSIGNED', 'SCHEDULED'], true) ? 0 : 1, hours_ago($tAssigned));
        }
        if ($status === 'COMPLETED') {
            $notifyAt($client['user_id'], 'SERVICE_REQUEST', "Your service request $code ($subject) has been completed.", 'service_requests', $srId, 1, hours_ago($doneH));
        }
    }

    // SR-DEMO-024 was a maintenance visit: give its job the inspection record.
    if (!empty($srJobIds[24])) {
        $has = $pdo->prepare('SELECT 1 FROM maintenance_records WHERE job_id = :j');
        $has->execute([':j' => $srJobIds[24]]);
        if (!$has->fetchColumn()) {
            $c6 = $clientProfiles[6];
            $mrecInsert->execute([
                ':j' => $srJobIds[24], ':c' => $c6['id'], ':sys' => $systemOf[6] ?? null, ':t' => $techProfiles[5]['id'],
                ':pc' => 'Good', ':bc' => 'Good', ':ic' => 'Good', ':ec' => 'Good',
                ':res' => 'Cleaned all panels, re-torqued clamps, checked DC/AC connections and inverter logs. All readings normal.',
                ':mat' => 'Cleaning kit, anti-corrosion spray', ':iss' => 'None', ':rem' => 'Annual maintenance (SR-DEMO-024).',
                ':done' => hours_ago(670), ':at' => hours_ago(673),
            ]);
            $recId = (int)$pdo->lastInsertId();
            foreach ($maintTemplate as [$key, $desc]) {
                $mitemInsert->execute([':m' => $recId, ':k' => $key, ':d' => $desc, ':r' => null]);
            }
        }
    }

    // =======================================================================
    // F. Material requests (client orders) and their picks
    // =======================================================================
    $mrFind  = $pdo->prepare('SELECT id FROM material_requests WHERE request_code = :c');
    $mrIns   = $pdo->prepare(
        'INSERT INTO material_requests (request_code, client_id, project_id, job_id, status, needed_by, notes, requested_by,
                                        ready_at, released_at, released_by, released_to, created_at, updated_at)
         VALUES (:code, :c, :p, :j, "PENDING", :needed, :notes, :by, NULL, NULL, NULL, NULL, :at, :at2)'
    );
    $mriIns  = $pdo->prepare('INSERT INTO material_request_items (request_id, category_id, qty_required, qty_prepared) VALUES (:r, :c, :q, 0)');
    $mriPrep = $pdo->prepare('UPDATE material_request_items SET qty_prepared = qty_prepared + :q WHERE request_id = :r AND category_id = :c');

    foreach ($mrPlan as $mi => $o) {
        $mrFind->execute([':c' => $o['code']]);
        if ($mrFind->fetchColumn()) {
            continue;
        }
        if ($o['project'] !== null) {
            $p = $projectPlan[$o['project']];
            $pr = $projectIds[$o['project']];
            $client = $clientProfiles[$p['client']];
            $tech = $p['tech'] ? $techProfiles[$p['tech']] : null;
            $jobId = $pr['job'];
            $projectId = $pr['id'];
            $notes = "For project {$pr['code']} — " . $client['last'] . ' site';
            $anchor = $p['status'] === 'COMPLETED' ? $p['days'] : 0;   // days ago the materials were needed
            $neededBy = $pr['date'] ?? day_offset(30);
            [$createdDays, $pickDays, $releaseDays] = match ($o['status']) {
                'RELEASED'  => $p['status'] === 'COMPLETED' ? [$anchor + 12, $anchor + 4, $anchor + 1] : [9, 4, 1],
                'READY'     => [6, 1, null],
                'PREPARING' => [3, 1, null],
                'CANCELLED' => [20, null, null],
                default     => [$p['status'] === 'PLANNED' ? 4 : 2, null, null],
            };
        } else {
            // The service order: SR-DEMO-021's replacement battery.
            $client = $clientProfiles[20];
            $tech = $techProfiles[2];
            $jobId = $srJobIds[21] ?? null;
            $projectId = null;
            $notes = 'Replacement for the swollen battery — SR-DEMO-021';
            $neededBy = day_offset(1);
            [$createdDays, $pickDays, $releaseDays] = [0, null, null];
        }
        $by = $mgr($mi);
        $createdAt = $createdDays === 0 ? hours_ago(1.2) : day_at($createdDays, '10:15');
        $mrIns->execute([':code' => $o['code'], ':c' => $client['id'], ':p' => $projectId, ':j' => $jobId,
                         ':needed' => $neededBy, ':notes' => $notes, ':by' => $by, ':at' => $createdAt, ':at2' => $createdAt]);
        $mrId = (int)$pdo->lastInsertId();
        $created['orders']++;
        $audit($by, 'manager', 'CREATE', 'material_requests', $o['code'], $createdAt);

        $summary = [];
        foreach ($o['lines'] as [$cat, $sku, $qty]) {
            $mriIns->execute([':r' => $mrId, ':c' => $categoryIds[$cat], ':q' => $qty]);
            $summary[] = "$qty $cat";
        }
        $notifyAt($warehouseUserId, 'MATERIAL_REQUEST', "New client order {$o['code']} for {$client['name']} ({$client['code']}): " . implode(', ', $summary)
            . ", needed by $neededBy.", 'material_requests', $mrId, $o['status'] === 'PENDING' ? 0 : 1, $createdAt);

        // Scan the planned units out of stock and onto the order.
        $lastPickAt = null;
        foreach ($o['picks'] as $li => $pickQty) {
            [$cat, $sku] = $o['lines'][$li];
            $at = day_at($pickDays, sprintf('%02d:%02d', 9 + $li, 10 + $li * 7));
            $ok = $move(sprintf('MV-DEMO-P%s-%d', substr($o['code'], -4), $li + 1), $sku, 'ISSUE', $pickQty, $at, [
                'job' => $jobId, 'mr' => $mrId, 'tech' => $tech['id'] ?? null, 'ref' => 'Prepared for ' . $o['code'],
                'from' => $warehouseRow['warehouse_name'] . ' / ' . $catalogBySku[$sku][7], 'to' => 'Client order ' . $o['code'],
            ]);
            if ($ok) {
                $mriPrep->execute([':q' => $pickQty, ':r' => $mrId, ':c' => $categoryIds[$cat]]);
                $lastPickAt = $at;
            }
        }

        // Status from what was actually picked (same rule as mr_recalc()).
        $t = $pdo->prepare('SELECT COALESCE(SUM(qty_required),0) AS req, COALESCE(SUM(LEAST(qty_prepared, qty_required)),0) AS prep FROM material_request_items WHERE request_id = :r');
        $t->execute([':r' => $mrId]);
        $tot = $t->fetch();
        $complete = (int)$tot['prep'] >= (int)$tot['req'] && (int)$tot['req'] > 0;
        $status = $o['status'] === 'CANCELLED' ? 'CANCELLED'
            : ($complete ? ($o['status'] === 'RELEASED' ? 'RELEASED' : 'READY') : ((int)$tot['prep'] > 0 ? 'PREPARING' : 'PENDING'));
        $releasedAt = $status === 'RELEASED' ? day_at($releaseDays, '07:15') : null;
        $pdo->prepare(
            'UPDATE material_requests
             SET status = :s, ready_at = :ready, released_at = :rel, released_by = :rby, released_to = :rto, updated_at = :upd
             WHERE id = :id'
        )->execute([
            ':s' => $status, ':ready' => in_array($status, ['READY', 'RELEASED'], true) ? $lastPickAt : null,
            ':rel' => $releasedAt, ':rby' => $releasedAt ? $warehouseUserId : null,
            ':rto' => $releasedAt ? ($tech['name'] ?? null) : null,
            ':upd' => $releasedAt ?? $lastPickAt ?? ($o['status'] === 'CANCELLED' ? day_at(18, '14:00') : $createdAt), ':id' => $mrId,
        ]);
        if ($status === 'READY') {
            foreach ($managerUserIds as $mid) {
                $notifyAt($mid, 'MATERIAL_REQUEST', "Client order {$o['code']} is prepared and ready to go.", 'material_requests', $mrId, 0, $lastPickAt);
            }
        }
        if ($status === 'RELEASED') {
            $audit($warehouseUserId, 'warehouse', 'RELEASE', 'material_requests', $o['code'], $releasedAt);
        }
        if ($status === 'CANCELLED') {
            $audit($by, 'manager', 'CANCEL', 'material_requests', $o['code'], day_at(18, '14:00'));
        }
    }

    // Direct stock movements tied to field work.
    if (!empty($srJobIds[27])) {
        $move('MV-DEMO-X01', 'ST-INV-9011', 'ISSUE', 1, hours_ago(264), [
            'job' => $srJobIds[27], 'tech' => $techProfiles[8]['id'], 'ref' => 'Warranty replacement module — SR-DEMO-027',
            'from' => $warehouseRow['warehouse_name'] . ' / Zone C / C-01', 'to' => 'JOB-DEMO-027',
        ]);
    }
    $lastInstall = null;
    foreach ($projectPlan as $pi => $p) {
        if ($p['status'] === 'COMPLETED' && $p['panel'] === 'ST-INV-9001' && !empty($projectIds[$pi]['job'])
            && ($lastInstall === null || $p['days'] < $projectPlan[$lastInstall]['days'])) {
            $lastInstall = $pi;
        }
    }
    if ($lastInstall !== null) {
        $move('MV-DEMO-X02', 'ST-INV-9001', 'RETURN', 1, day_at(max(0, $projectPlan[$lastInstall]['days'] - 1), '15:30'), [
            'job' => $projectIds[$lastInstall]['job'], 'tech' => $techProfiles[$projectPlan[$lastInstall]['tech']]['id'],
            'ref' => 'Surplus panel returned after installation', 'from' => $projectIds[$lastInstall]['job_code'],
            'to' => $warehouseRow['warehouse_name'] . ' / Zone A / A-01',
        ]);
    }

    // Item status always follows the shelf (DISCONTINUED stays DISCONTINUED).
    foreach ($catalog as [$sku, , , , , , $reorder]) {
        if (!isset($inv[$sku])) {
            continue;
        }
        $row = $pdo->prepare('SELECT quantity, reorder_level, status FROM inventory WHERE id = :id');
        $row->execute([':id' => $inv[$sku]]);
        $r = $row->fetch();
        $pdo->prepare('UPDATE inventory SET status = :s WHERE id = :id')
            ->execute([':s' => inventory_status((int)$r['quantity'], $r['status']), ':id' => $inv[$sku]]);
    }

    // =======================================================================
    // G. Billing — invoices and payments
    // =======================================================================
    $invcFind = $pdo->prepare('SELECT id FROM invoices WHERE invoice_code = :c');
    $invcIns  = $pdo->prepare(
        'INSERT INTO invoices (invoice_code, client_id, project_id, amount, due_date, payment_status, payment_reference, payment_date, notes, created_at)
         VALUES (:code, :c, :p, :amt, :due, :status, NULL, NULL, :notes, :at)'
    );
    $payIns   = $pdo->prepare(
        'INSERT INTO payments (invoice_id, amount, payment_method, reference, paid_at, recorded_by) VALUES (:i, :a, :m, :r, :at, :by)'
    );
    $methods = ['BANK_TRANSFER', 'GCASH', 'CHECK', 'CASH', 'BANK_TRANSFER', 'CREDIT_CARD'];
    $invNo = 0;

    /**
     * One invoice with its payments. $payments: [[amount, 'Y-m-d H:i:s'], ...].
     * Status: CANCELLED / PAID when covered / OVERDUE when $overdue / else PENDING.
     */
    $invoice = function (array $client, ?int $projectId, float $amount, string $due, string $createdAt, string $notes, array $payments, bool $overdue = false, bool $cancelled = false)
        use ($pdo, &$invNo, $invcFind, $invcIns, $payIns, $methods, &$created, $mgr, $audit, $notifyAt) {
        $invNo++;
        $code = sprintf('INV-DEMO-%04d', $invNo);
        $invcFind->execute([':c' => $code]);
        if ($invcFind->fetchColumn()) {
            return;
        }
        $paid = array_sum(array_column($payments, 0));
        $status = $cancelled ? 'CANCELLED' : (round($paid * 100) >= round($amount * 100) ? 'PAID' : ($overdue ? 'OVERDUE' : 'PENDING'));
        $invcIns->execute([':code' => $code, ':c' => $client['id'], ':p' => $projectId, ':amt' => $amount, ':due' => $due,
                           ':status' => $status, ':notes' => $notes, ':at' => $createdAt]);
        $invoiceId = (int)$pdo->lastInsertId();
        $created['invoices']++;
        $audit($mgr($invNo), 'manager', 'CREATE', 'billing', $code, $createdAt);
        $lastRef = null;
        $lastDate = null;
        foreach ($payments as $k => [$amt, $at]) {
            $lastRef = sprintf('OR-%s-%d', substr($code, -4), $k + 1);
            $lastDate = substr($at, 0, 10);
            $payIns->execute([':i' => $invoiceId, ':a' => $amt, ':m' => $methods[($invNo + $k) % count($methods)], ':r' => $lastRef, ':at' => $at, ':by' => $mgr($invNo + $k)]);
            $created['payments']++;
            $audit($mgr($invNo + $k), 'manager', $k === count($payments) - 1 && $status === 'PAID' ? 'RECORD_PAYMENT' : 'RECORD_PARTIAL_PAYMENT', 'billing', $code, $at);
        }
        $pdo->prepare('UPDATE invoices SET payment_reference = :r, payment_date = :d WHERE id = :id')
            ->execute([':r' => $lastRef, ':d' => $status === 'PAID' ? $lastDate : null, ':id' => $invoiceId]);
        if ($status === 'OVERDUE') {
            $notifyAt($client['user_id'], 'INVOICE_OVERDUE', "Invoice $code is past due. Balance: ₱" . number_format($amount - $paid, 2) . '.', 'invoices', $invoiceId, 0, day_at(2, '08:00'));
        }
    };

    foreach ($projectPlan as $pi => $p) {
        $client = $clientProfiles[$p['client']];
        $pr = $projectIds[$pi];
        $amount = round(($p['kw'] * 52000 + $p['batteries'] * 60000) / 1000) * 1000;
        $label = "{$p['kw']} kW " . ($p['hybrid'] ? 'hybrid' : 'grid-tie') . " solar installation — {$pr['code']}";
        $half = round($amount / 2, 2);
        switch ($p['status']) {
            case 'COMPLETED':
                $d = $p['days'];
                $created50 = day_at($d + 20, '11:00');
                $kind = $pi % 10;
                if ($kind <= 6) {               // fully paid: downpayment + balance on completion
                    $invoice($client, $pr['id'], $amount, day_offset(-$d + 15), $created50, $label,
                        [[$half, day_at($d + 18, '14:00')], [$amount - $half, day_at(max(0, $d - 5), '10:30')]]);
                } elseif ($kind === 7) {        // balance not yet due
                    $invoice($client, $pr['id'], $amount, day_offset(20), $created50, $label . ' (balance on 60-day terms)',
                        [[$half, day_at($d + 18, '14:00')]]);
                } else {                        // balance overdue
                    $invoice($client, $pr['id'], $amount, day_offset(-15 - $kind), $created50, $label,
                        [[round($amount * 0.3, 2), day_at($d + 18, '14:00')]], true);
                }
                break;
            case 'IN_PROGRESS':
                $invoice($client, $pr['id'], $amount, day_offset(25), day_at(15, '11:00'), $label . ' (50% downpayment received)',
                    [[$half, day_at(13, '15:20')]]);
                break;
            case 'SCHEDULED':
                $invoice($client, $pr['id'], $amount, day_offset(14), day_at(10, '11:00'), $label,
                    $p['client'] === 26 ? [[round($amount * 0.3, 2), day_at(8, '13:00')]] : []);
                break;
            case 'CANCELLED':
                $invoice($client, $pr['id'], $amount, day_offset(-10), day_at(19, '11:00'), $label . ' — project cancelled by the client', [], false, true);
                break;
        }
    }
    // Paid service visits (warranty work is not billed).
    $invoice($clientProfiles[6],  null, 3000, day_offset(-14), hours_ago(668), 'Annual maintenance and panel cleaning — SR-DEMO-024', [[3000, hours_ago(600)]]);
    $invoice($clientProfiles[13], null, 4500, day_offset(-5),  hours_ago(466), 'Inverter reset and firmware update — SR-DEMO-025', [[4500, hours_ago(420)]]);
    $invoice($clientProfiles[21], null, 3500, day_offset(-2),  hours_ago(376), 'Panel cleaning and tree trimming — SR-DEMO-026', [[3500, hours_ago(330)]]);
    $invoice($clientProfiles[35], null, 2500, day_offset(10),  hours_ago(205), 'Insurance inspection report — SR-DEMO-028', []);

    // A login trail so the audit log and dashboards show recent activity.
    $loginCheck = $pdo->prepare("SELECT 1 FROM audit_logs WHERE action = 'LOGIN' AND module = 'auth' AND record_id = :r AND created_at = :at");
    foreach (array_merge($managerUserIds, [$warehouseUserId], array_column($techProfiles, 'user_id')) as $k => $uid) {
        $at = day_at(0, sprintf('%02d:%02d', 7 + intdiv($k, 6), ($k * 9) % 60));
        if (strtotime($at) > time()) {
            continue;
        }
        $loginCheck->execute([':r' => (string)$uid, ':at' => $at]);
        if (!$loginCheck->fetchColumn()) {
            $role = in_array($uid, $managerUserIds, true) ? 'manager' : ($uid === $warehouseUserId ? 'warehouse' : 'technician');
            $audit($uid, $role, 'LOGIN', 'auth', (string)$uid, $at);
        }
    }

    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    fail("Nothing was saved (the whole seed runs in one transaction).\nReason: " . $e->getMessage() . "\nAt: " . basename($e->getFile()) . ':' . $e->getLine());
}

// ===========================================================================
// 3. Summary — read back from the database, not from the arrays above
// ===========================================================================

$like = '%@' . DEMO_DOMAIN;
$countRole = $pdo->prepare('SELECT COUNT(*) FROM users u JOIN roles r ON r.id = u.role_id WHERE u.email LIKE :d AND r.role_key = :r');
$roleCount = function (string $role) use ($countRole, $like) {
    $countRole->execute([':d' => $like, ':r' => $role]);
    return (int)$countRole->fetchColumn();
};
$q = fn(string $sql) => $pdo->query($sql)->fetchColumn();
$grouped = function (string $sql) use ($pdo) {
    $rows = $pdo->query($sql)->fetchAll();
    return implode(', ', array_map(fn($r) => $r['n'] . ' ' . strtolower(str_replace('_', ' ', $r['s'])), $rows));
};

$clientStats = $pdo->prepare(
    'SELECT COUNT(*) AS total, SUM(c.lat IS NOT NULL AND c.lng IS NOT NULL) AS pinned,
            COUNT(DISTINCT CONCAT(c.lat, ",", c.lng)) AS distinct_coords,
            SUM(u.status = "ACTIVE") AS active, SUM(u.status = "INACTIVE") AS inactive, SUM(u.status = "SUSPENDED") AS suspended
     FROM clients c JOIN users u ON u.id = c.user_id WHERE u.email LIKE :d AND u.email LIKE "client%"'
);
$clientStats->execute([':d' => $like]);
$cs = $clientStats->fetch();
$allClients = $pdo->query('SELECT COUNT(*) AS total, SUM(lat IS NOT NULL AND lng IS NOT NULL) AS pinned FROM clients')->fetch();

out();
out('==============================================');
out(' SunTrack ERP Seed Completed');
out('==============================================');
out();
out('Users:');
out('  ' . $roleCount('admin') . ' Admin');
out('  ' . $roleCount('manager') . ' Management');
out('  ' . $roleCount('warehouse') . ' Warehouse');
out('  ' . $roleCount('technician') . ' Technicians');
out();
out('Clients:');
out('  ' . (int)$cs['total'] . '  (' . (int)$cs['active'] . ' active, ' . (int)$cs['inactive'] . ' inactive, ' . (int)$cs['suspended'] . ' suspended)');
out();
out('All client coordinates:');
out('  ' . (int)$cs['pinned'] . '/' . (int)$cs['total'] . '  (' . (int)$cs['distinct_coords'] . ' distinct locations)');
if ((int)$allClients['total'] !== (int)$cs['total']) {
    out('  Whole database: ' . (int)$allClients['pinned'] . '/' . (int)$allClients['total'] . ' clients pinned');
}
out();
out('Projects:            ' . $q('SELECT COUNT(*) FROM projects') . '  (' . $grouped('SELECT status AS s, COUNT(*) AS n FROM projects GROUP BY status ORDER BY n DESC') . ')');
out('Solar systems:       ' . $q('SELECT COUNT(*) FROM solar_systems') . '  (' . $grouped('SELECT status AS s, COUNT(*) AS n FROM solar_systems GROUP BY status ORDER BY n DESC') . ')');
out('Jobs:                ' . $q('SELECT COUNT(*) FROM jobs') . '  (' . $grouped('SELECT job_type AS s, COUNT(*) AS n FROM jobs GROUP BY job_type ORDER BY n DESC') . ')');
out('Installation checklists: ' . $q('SELECT COUNT(*) FROM installation_checklists') . '  (' . $q('SELECT COUNT(*) FROM installation_items') . ' items)');
out('Maintenance schedules:   ' . $q('SELECT COUNT(*) FROM maintenance_schedules') . '  (' . $grouped('SELECT status AS s, COUNT(*) AS n FROM maintenance_schedules GROUP BY status ORDER BY FIELD(status, "OVERDUE", "DUE", "UPCOMING")') . ')');
out('Maintenance records:     ' . $q('SELECT COUNT(*) FROM maintenance_records'));
out('Service requests:    ' . $q("SELECT COUNT(*) FROM service_requests WHERE request_code LIKE 'SR-DEMO-%'") . ' demo  (' . $grouped("SELECT status AS s, COUNT(*) AS n FROM service_requests WHERE request_code LIKE 'SR-DEMO-%' GROUP BY status") . ')');
out('Inventory items:     ' . $q('SELECT COUNT(*) FROM inventory') . '  (' . $grouped('SELECT status AS s, COUNT(*) AS n FROM inventory GROUP BY status ORDER BY n DESC') . ')');
out('Stock movements:     ' . $q('SELECT COUNT(*) FROM stock_movements') . '  (' . $grouped('SELECT movement_type AS s, COUNT(*) AS n FROM stock_movements GROUP BY movement_type') . ')');
out('Material requests:   ' . $q('SELECT COUNT(*) FROM material_requests') . '  (' . $grouped("SELECT status AS s, COUNT(*) AS n FROM material_requests GROUP BY status ORDER BY FIELD(status, 'PENDING', 'PREPARING', 'READY', 'RELEASED', 'CANCELLED')") . ')');
out('Invoices:            ' . $q('SELECT COUNT(*) FROM invoices') . '  (' . $grouped('SELECT payment_status AS s, COUNT(*) AS n FROM invoices GROUP BY payment_status ORDER BY n DESC') . '), '
    . $q('SELECT COUNT(*) FROM payments') . ' payments');
out('Sub-contractors:     ' . $q('SELECT COUNT(*) FROM subcontractors'));
out('Work reports:        ' . $q('SELECT COUNT(*) FROM work_reports') . ',  attendance records: ' . $q('SELECT COUNT(*) FROM attendance') . ',  GPS pings: ' . $q('SELECT COUNT(*) FROM geofence_records'));
if ($hasPhotos || $hasSignoffs) {
    out('Job photos:          ' . ($hasPhotos ? $q('SELECT COUNT(*) FROM job_photos') : 0) . ',  client sign-offs: ' . ($hasSignoffs ? $q('SELECT COUNT(*) FROM job_confirmations') : 0));
}
out();
out('Database:');
out('  ' . DB_NAME);
out();
$newTotal = array_sum($created);
out('This run: ' . ($newTotal === 0
    ? 'nothing new was needed — every demo record already exists'
    : implode(', ', array_map(fn($k, $v) => "$v $k", array_keys(array_filter($created)), array_filter($created))) . ' created')
    . ($skippedRequests ? "; $skippedRequests demo service request(s) already existed and were left as they are" : '') . '.');
out();
out('----------------------------------------------');
out(' Demo login accounts — password for ALL: ' . DEMO_PASSWORD);
out('----------------------------------------------');
foreach ($accountsOut as [$role, $email, $name]) {
    out(sprintf('  %-11s %-28s %s', $role, $email, $name));
}
out(sprintf('  %-11s %-28s %s', 'Client', 'client1@' . DEMO_DOMAIN, '… client50@' . DEMO_DOMAIN . ' (active ones can sign in)'));
out();
out('Sign in at: http://localhost/<your-folder>/login.php');
out('These are demo credentials. Change or remove them before real use.');
