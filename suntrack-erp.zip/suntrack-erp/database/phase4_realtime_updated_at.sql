-- ============================================================================
-- SunTrack ERP — Phase 4 Migration
-- Real-time fix: updated_at on attendance and service_requests
--
-- Safe to run more than once. Every statement is guarded, so re-running this
-- file is a no-op. It never drops a table and never deletes a row.
--
--   mysql -u root suntrack_erp < database/phase4_realtime_updated_at.sql
--
-- Why:
--   api/realtime/sync.php fingerprints each table with COUNT(*) + MAX(id) +
--   MAX(<timestamp>). Two tables had no timestamp that moves on UPDATE:
--
--     attendance        fingerprinted on created_at — a technician's Time Out
--                       is an UPDATE, so it never reached any other screen.
--     service_requests  fingerprinted on date_requested — approving, rejecting
--                       or assigning a request is an UPDATE, so Admin and
--                       Management never saw it change until a manual reload.
--
--   An ON UPDATE CURRENT_TIMESTAMP column moves on every change without any
--   endpoint having to remember to set it, which keeps the "correct by
--   construction" property the sync endpoint was built around.
--
-- Order: can run any time after phase 3. The seeder truncates rows but keeps
-- columns, so re-seeding does not undo this.
-- ============================================================================

DROP PROCEDURE IF EXISTS suntrack_add_column;
DROP PROCEDURE IF EXISTS suntrack_add_index4;

DELIMITER //

CREATE PROCEDURE suntrack_add_column(
    IN p_table  VARCHAR(64),
    IN p_column VARCHAR(64),
    IN p_ddl    VARCHAR(512)
)
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME   = p_table
          AND COLUMN_NAME  = p_column
    ) THEN
        SET @sql = p_ddl;
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END //

CREATE PROCEDURE suntrack_add_index4(
    IN p_table VARCHAR(64),
    IN p_index VARCHAR(64),
    IN p_ddl   VARCHAR(512)
)
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME   = p_table
          AND INDEX_NAME   = p_index
    ) THEN
        SET @sql = p_ddl;
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END //

DELIMITER ;

-- ---------------------------------------------------------------------------
-- 1. The columns. Existing rows are stamped with the migration time, which is
--    harmless: the fingerprint only needs the value to MOVE on later changes.
-- ---------------------------------------------------------------------------
CALL suntrack_add_column('attendance', 'updated_at',
    'ALTER TABLE attendance ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at');

CALL suntrack_add_column('service_requests', 'updated_at',
    'ALTER TABLE service_requests ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER completion_date');

-- ---------------------------------------------------------------------------
-- 2. Indexes, so MAX(updated_at) stays cheap when polled every few seconds.
-- ---------------------------------------------------------------------------
CALL suntrack_add_index4('attendance', 'idx_att_updated',
    'ALTER TABLE attendance ADD INDEX idx_att_updated (updated_at)');

CALL suntrack_add_index4('service_requests', 'idx_sr_updated',
    'ALTER TABLE service_requests ADD INDEX idx_sr_updated (updated_at)');

DROP PROCEDURE IF EXISTS suntrack_add_column;
DROP PROCEDURE IF EXISTS suntrack_add_index4;

-- ============================================================================
-- End of Phase 4 migration.
-- ============================================================================
