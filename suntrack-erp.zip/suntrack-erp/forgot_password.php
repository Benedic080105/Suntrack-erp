<?php
require_once __DIR__ . '/config/config.php';

if (is_logged_in()) {
    header('Location: ' . redirect_path_for_role(current_role()));
    exit;
}

$token = csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SunTrack ERP — Forgot Password</title>
<script src="<?= APP_BASE_URL ?>/assets/vendor/tailwind/tailwind.js"></script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/vendor/fontawesome/css/all.min.css">
<link href="<?= APP_BASE_URL ?>/assets/vendor/inter/inter.css" rel="stylesheet">
<script>
  tailwind.config = { theme: { extend: {
    colors: { suntrackDark: '#0b1329', suntrackNav: '#0f1934', suntrackOrange: '#f97316' },
    fontFamily: { sans: ['Inter','sans-serif'] }
  }}}
</script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/css/suntrack-mobile.css">
<style>body{font-family:'Inter',sans-serif;}</style>
</head>
<body class="bg-suntrackDark min-h-screen flex items-center justify-center p-4">

  <div class="w-full max-w-md">
    <div class="text-center mb-8">
      <div class="inline-flex items-center justify-center h-14 w-14 rounded-2xl bg-suntrackOrange shadow-lg shadow-orange-600/30 mb-4">
        <i class="fas fa-key text-white text-2xl"></i>
      </div>
      <h1 class="text-2xl font-extrabold text-white">Forgot your password?</h1>
      <p class="text-slate-400 text-sm mt-1">We'll email you a link to choose a new one.</p>
    </div>

    <div class="bg-suntrackNav border border-slate-800/60 rounded-2xl p-8 shadow-xl">
      <div id="fp-msg" class="hidden text-sm rounded-xl px-4 py-3 mb-4"></div>

      <form id="fp-form" class="space-y-4">
        <div>
          <label for="fp-email" class="block text-slate-300 text-sm font-semibold mb-1.5">Email on your account</label>
          <input type="email" id="fp-email" required autocomplete="username"
                 class="w-full rounded-xl bg-slate-900/60 border border-slate-700 text-white text-sm px-4 py-3 focus:outline-none focus:ring-2 focus:ring-suntrackOrange placeholder-slate-500"
                 placeholder="you@example.com">
        </div>
        <button type="submit" id="fp-btn"
                class="w-full bg-suntrackOrange hover:bg-orange-600 text-white font-bold text-sm py-3 rounded-xl shadow-lg shadow-orange-600/20 transition">
          Send reset link
        </button>
      </form>

      <p class="text-slate-500 text-xs mt-5 leading-relaxed">
        <i class="fas fa-circle-info mr-1"></i>
        For <b class="text-slate-400">clients</b> and <b class="text-slate-400">technicians</b>.
        Management, warehouse and admin staff: ask your manager to reset your password.
      </p>

      <p class="text-center text-slate-500 text-xs mt-6">
        Remembered it? <a href="login.php" class="text-suntrackOrange font-semibold hover:underline">Back to sign in</a>
      </p>
    </div>
  </div>

<script>
const CSRF_TOKEN = <?= json_encode($token) ?>;

function showMsg(text, ok) {
  const box = document.getElementById('fp-msg');
  box.className = 'text-sm rounded-xl px-4 py-3 mb-4 ' + (ok
    ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300'
    : 'bg-red-500/10 border border-red-500/30 text-red-400');
  box.textContent = text;
}

document.getElementById('fp-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = document.getElementById('fp-btn');
  btn.disabled = true;
  btn.textContent = 'Sending...';
  try {
    const res = await fetch('api/auth/forgot_password.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: document.getElementById('fp-email').value.trim(), csrf_token: CSRF_TOKEN })
    });
    const data = await res.json();
    showMsg(data.message || 'Something went wrong.', !!data.success);
    // Local development only: the server has no mail, so it hands the link back.
    if (data.success && data.data && data.data.dev_reset_link) {
      const box = document.getElementById('fp-msg');
      const p = document.createElement('p');
      p.className = 'mt-2 text-xs text-amber-300 break-all';
      p.textContent = 'Development mode — email not sent. Test link: ';
      const a = document.createElement('a');
      a.href = data.data.dev_reset_link;
      a.textContent = 'open reset page';
      a.className = 'underline font-semibold';
      p.appendChild(a);
      box.appendChild(p);
    }
    if (data.success) document.getElementById('fp-form').classList.add('hidden');
  } catch (err) {
    showMsg('Network error. Please try again.', false);
  }
  btn.disabled = false;
  btn.textContent = 'Send reset link';
});
</script>
<?php include ROOT_PATH . '/includes/consent_banner.php'; ?>
</body>
</html>
