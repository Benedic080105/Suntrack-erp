/**
 * SunTrack service worker — makes the site installable and shows phone
 * notifications.
 *
 * Deliberately does NOT cache pages, API answers or scripts: everything is
 * always loaded fresh from the server exactly as before. The only cached
 * file is offline.html, shown when a page cannot load at all.
 *
 * Push: the push message is empty. On arrival this worker asks
 * api/push/latest.php (with the user's own session) what to show.
 */
'use strict';

const CACHE = 'suntrack-shell-v1';
const scoped = (path) => new URL(path, self.registration.scope).href;
const OFFLINE = scoped('offline.html');
const ICON = scoped('assets/img/app/icon-192.png');
const BADGE = scoped('assets/img/app/badge-96.png');

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE).then((c) => c.addAll([OFFLINE, ICON, BADGE])).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith('suntrack-') && k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

// Page loads only: straight to the network; the offline page if that fails.
self.addEventListener('fetch', (event) => {
  if (event.request.mode !== 'navigate' || event.request.method !== 'GET') return;
  event.respondWith(
    fetch(event.request).catch(() => caches.match(OFFLINE).then((r) => r || Response.error()))
  );
});

self.addEventListener('push', (event) => {
  event.waitUntil((async () => {
    let title = 'SunTrack';
    let body = 'You have a new notification.';
    let url = self.registration.scope;
    let tag = 'suntrack';
    try {
      const res = await fetch(scoped('api/push/latest.php'), { credentials: 'include', cache: 'no-store' });
      const json = await res.json();
      if (json.success && json.data) {
        if (json.data.url) url = new URL(json.data.url, self.registration.scope).href;
        const n = json.data.notification;
        if (n) { title = 'SunTrack · ' + n.title; body = n.message; tag = 'suntrack-' + n.id; }
      }
    } catch (e) { /* signed out or offline: show the plain message */ }
    // Browsers require a visible notification for every push.
    await self.registration.showNotification(title, { body, icon: ICON, badge: BADGE, tag, data: { url } });
  })());
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || self.registration.scope;
  event.waitUntil((async () => {
    const wins = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const w of wins) {
      if (w.url.startsWith(url) && 'focus' in w) return w.focus();
    }
    return self.clients.openWindow(url);
  })());
});
