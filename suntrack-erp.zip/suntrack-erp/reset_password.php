<?php
require_once __DIR__ . '/config/config.php';
require_once ROOT_PATH . '/includes/password_reset_lib.php';

$tokenParam = trim((string)($_GET['token'] ?? ''));

// Check the link up front so an expired one says so immediately, rather than
// after the person has typed a new password twice.
$valid = false;
try {
    $valid = $tokenParam !== '' && password_reset_find($tokenParam) !== null;
} catch (Throwable $e) {
    $valid = false; // table missing (phase 6 not imported) reads as an invalid link
}

$csrf = csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="referrer" content="no-referrer">
<title>SunTrack ERP — Choose a New Password</title>
<script src="<?= APP_BASE_URL ?>/assets/vendor/tailwind/tailwind.js"></script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/vendor/fontawesome/css/all.min.css">
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-password.js"></script>
<link href="<?= APP_BASE_URL ?>/assets/vendor/inter/inter.css" rel="stylesheet">
<script>
  tailwind.config = { theme: { extend: {
    colors: { suntrackDark: '#0b1329', suntrackNav: '#0f1934', suntrackOrange: '#f97316' },
    fontFamily: { sans: ['Inter','sans-serif'] }
  }}}
</script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/css/suntrack-mobile.css">
<style>body{font-family:'Inter',sans-serif;}</style>
</head>
<body class="bg-suntrackDark min-h-screen flex items-center justify-center p-4">

  <div class="w-full max-w-md">
    <div class="text-center mb-8">
      <div class="inline-flex items-center justify-center h-14 w-14 rounded-2xl bg-suntrackOrange shadow-lg shadow-orange-600/30 mb-4">
        <i class="fas fa-lock text-white text-2xl"></i>
      </div>
      <h1 class="text-2xl font-extrabold text-white">Choose a new password</h1>
    </div>

    <div class="bg-suntrackNav border border-slate-800/60 rounded-2xl p-8 shadow-xl">
<?php if (!$valid): ?>
      <div class="bg-red-500/10 border border-red-500/30 text-red-400 text-sm rounded-xl px-4 py-3 mb-4">
        This reset link is invalid, already used, or expired. Links work once and last <?= PASSWORD_RESET_TTL_MINUTES ?> minutes.
      </div>
      <a href="forgot_password.php" class="block text-center w-full bg-suntrackOrange hover:bg-orange-600 text-white font-bold text-sm py-3 rounded-xl">Request a new link</a>
<?php else: ?>
      <div id="rp-msg" class="hidden text-sm rounded-xl px-4 py-3 mb-4"></div>
      <form id="rp-form" class="space-y-4">
        <div>
          <label for="rp-pass" class="block text-slate-300 text-sm font-semibold mb-1.5">New password</label>
          <input type="password" id="rp-pass" required minlength="<?= PASSWORD_MIN_LENGTH ?>" autocomplete="new-password"
                 class="w-full rounded-xl bg-slate-900/60 border border-slate-700 text-white text-sm px-4 py-3 focus:outline-none focus:ring-2 focus:ring-suntrackOrange">
          <p class="text-slate-500 text-xs mt-1">At least <?= PASSWORD_MIN_LENGTH ?> characters.</p>
        </div>
        <div>
          <label for="rp-confirm" class="block text-slate-300 text-sm font-semibold mb-1.5">Type it again</label>
          <input type="password" id="rp-confirm" required autocomplete="new-password"
                 class="w-full rounded-xl bg-slate-900/60 border border-slate-700 text-white text-sm px-4 py-3 focus:outline-none focus:ring-2 focus:ring-suntrackOrange">
        </div>
        <label class="flex items-center gap-2 text-slate-400 text-xs"><input type="checkbox" id="rp-show"> Show passwords</label>
        <button type="submit" id="rp-btn"
                class="w-full bg-suntrackOrange hover:bg-orange-600 text-white font-bold text-sm py-3 rounded-xl shadow-lg shadow-orange-600/20 transition">
          Save new password
        </button>
      </form>
      <a id="rp-signin" href="login.php" class="hidden block text-center w-full bg-suntrackOrange hover:bg-orange-600 text-white font-bold text-sm py-3 rounded-xl">Go to sign in</a>
<?php endif; ?>
      <p class="text-center text-slate-500 text-xs mt-6"><a href="login.php" class="text-suntrackOrange font-semibold hover:underline">Back to sign in</a></p>
    </div>
  </div>

<?php if ($valid): ?>
<script>
const CSRF_TOKEN = <?= json_encode($csrf) ?>;
const RESET_TOKEN = <?= json_encode($tokenParam) ?>;
const MIN_LEN = <?= (int)PASSWORD_MIN_LENGTH ?>;

// Drop the token from the address bar and history once the page has it.
history.replaceState(null, '', location.pathname);

function showMsg(text, ok) {
  const box = document.getElementById('rp-msg');
  box.className = 'text-sm rounded-xl px-4 py-3 mb-4 ' + (ok
    ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300'
    : 'bg-red-500/10 border border-red-500/30 text-red-400');
  box.textContent = text;
}

document.getElementById('rp-show').addEventListener('change', (e) => {
  ['rp-pass', 'rp-confirm'].forEach(id => document.getElementById(id).type = e.target.checked ? 'text' : 'password');
});

document.getElementById('rp-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const pass = document.getElementById('rp-pass').value;
  const confirm = document.getElementById('rp-confirm').value;
  if (pass.length < MIN_LEN) { showMsg('Your new password must be at least ' + MIN_LEN + ' characters.', false); return; }
  if (pass !== confirm) { showMsg('The two passwords do not match.', false); return; }

  const btn = document.getElementById('rp-btn');
  btn.disabled = true;
  btn.textContent = 'Saving...';
  try {
    const res = await fetch('api/auth/reset_password.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: RESET_TOKEN, password: pass, confirm_password: confirm, csrf_token: CSRF_TOKEN })
    });
    const data = await res.json();
    showMsg(data.message || 'Something went wrong.', !!data.success);
    if (data.success) {
      document.getElementById('rp-form').classList.add('hidden');
      document.getElementById('rp-signin').classList.remove('hidden');
    }
  } catch (err) {
    showMsg('Network error. Please try again.', false);
  }
  btn.disabled = false;
  btn.textContent = 'Save new password';
});
</script>
<?php endif; ?>
<?php include ROOT_PATH . '/includes/consent_banner.php'; ?>
</body>
</html>
