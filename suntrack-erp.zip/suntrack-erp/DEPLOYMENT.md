# SunTrack ERP — Setup & Deployment Guide

## 1. First-time setup (XAMPP / local)

> **[SETUP.md](SETUP.md) is the authoritative install guide** — it has the exact
> order for the schema, the four migrations and the seeder, and why the order
> matters. The summary below follows it.

1. Copy this whole folder into your XAMPP `htdocs` folder. Any folder name
   works — the base URL is detected automatically (override it with the
   `SUNTRACK_BASE_URL` environment variable if you need to).
2. Start **Apache** and **MySQL** from the XAMPP Control Panel.
3. Import the schema: phpMyAdmin → Import → choose `database/suntrack_erp.sql`.
   The file creates the `suntrack_erp` database itself, so don't create it by
   hand first. Then import, in order, with `suntrack_erp` selected:
   `phase1_technician_migration.sql`, `phase2_management_migration.sql`.
4. Import `phase3_geo_realtime_consent.sql`, `phase4_realtime_updated_at.sql`,
   `phase5_service_requests.sql`, `phase5_material_requests.sql`,
   `phase6_password_resets.sql` and `phase7_beta_features.sql`, in that order.
5. **Demo data (optional).** `C:\xampp\php\php.exe database\seed.php` adds the
   demo accounts below and demo data for every module (50 clients with map
   coordinates, projects, installations, maintenance, service requests,
   stock, client orders, invoices and sub-contractors). Skip it for a real beta and create the first logins with
   `database/create_user.php` (see section 3) instead.
6. Visit `http://localhost/suntrack-erp/login.php` and sign in with any of the
   accounts below.

### Demo accounts (seeded by step 5)

Every demo account uses the password **`Suntrack12345!`**.

| Role | Email |
|---|---|
| Admin (view/export only) | admin@suntrack.test |
| Management | manager1@suntrack.test … manager5@suntrack.test |
| Warehouse | warehouse@suntrack.test |
| Technician | technician1@suntrack.test … technician10@suntrack.test |
| Client | client1@suntrack.test … client50@suntrack.test (inactive/suspended ones cannot sign in) |

**Change every one of these passwords before letting anyone outside your own
testing use the system.**

## 2. "The dashboard has no data" checklist

If any portal looks empty right after setup, work through this in order:

1. Did you run step 5 above (seeding)? This is the most common cause.
2. Check you're looking at the right role — e.g. a technician only ever sees
   *their own* assigned jobs, so a technician with nothing assigned will
   correctly show an empty dashboard even with the rest of the data seeded.
3. Open your browser's DevTools → Console tab while the page loads. A red
   error there (rather than a blank/loading dashboard) usually points at a
   specific broken request you can report back.
4. Confirm `config/database.php` actually points at the database you
   imported the schema into (database name, host, credentials).

## 3. Before you let real users touch this (production checklist)

The defaults in this project are intentionally tuned for local XAMPP
development and a first look during grading/demoing. Before exposing this to
the internet or to real beta users, go through this list:

- [ ] **Create `config/env.php` on the server** (copy `config/env.example.php`).
      Set `SUNTRACK_ENV` to `production` — this hides PHP error details from
      visitors while still logging them — and fill in the `SUNTRACK_DB_*`
      login. Real environment variables with the same names also work and win
      over the file. No code edits are needed; without the file the app keeps
      the local XAMPP defaults, so never deploy without it.
- [ ] **Create the first logins** from the server's command line (SSH or the
      host's terminal). Only clients can self-register, so a fresh database has
      no staff at all until you do this:
      ```
      php database/create_user.php --role=manager --email=you@company.ph --name="Your Name"
      php database/create_user.php --role=warehouse --email=stock@company.ph --name="Warehouse"
      php database/create_user.php --role=admin --email=it@company.ph --name="IT Admin"
      ```
      A strong password is generated and printed once. Technicians and clients
      are then added from the Management portal.
- [ ] **Set up email** (password reset link + "password changed"
      confirmation) — see "Email" below. If mail cannot be sent, a reset
      request still reaches Management as an in-app notification.
- [ ] **Make sure PHP can write its error log** (`log_errors` on, `error_log`
      pointing at a writable file). On shared hosting this is usually preset.
- [ ] **Change every default password** in the table above, and remove any
      demo accounts you don't actually need.
- [ ] **Use a dedicated, least-privilege database user** instead of `root`.
      The app itself only ever needs to read/write data, never to alter
      table structure, so create a scoped user:
      ```sql
      CREATE USER 'suntrack_app'@'localhost' IDENTIFIED BY 'choose-a-strong-password';
      GRANT SELECT, INSERT, UPDATE, DELETE ON suntrack_erp.* TO 'suntrack_app'@'localhost';
      FLUSH PRIVILEGES;
      ```
      Then update `DB_USER` / `DB_PASS` in `config/database.php` to match.
      Keep using the `root` (or another full-privilege) account for importing
      the `.sql` migrations, which alter table structure.
- [ ] **Serve the site over HTTPS.** Required, not optional: phone browsers
      block the camera (QR scanner) and GPS (technician geofence) on plain
      http. Session cookies are then marked secure automatically.
- [ ] **Confirm `.htaccess` is being respected.** This project ships
      `.htaccess` files that block direct access to `config/`, `database/`,
      `includes/`, and `middleware/`, plus any `.sql`/`.env`/`.log` file
      anywhere in the project. This requires Apache's `mod_rewrite` and
      `AllowOverride All` (both are on by default in XAMPP). If you deploy to
      a different host, confirm `.htaccess` support is enabled, or
      reproduce the same blocks in that host's own config.
- [ ] **Back up the database** on a real schedule once it holds real data —
      nothing in this app does that for you.

### Email (Gmail)

Emails go out through Gmail's own server, so they are signed by Google and
land in the inbox instead of Spam. Gmail allows about 500 emails a day, which
is plenty for password resets.

1. On the Google account that will send the emails, turn on
   **2-Step Verification**.
2. Open <https://myaccount.google.com/apppasswords>, create an App Password
   named "SunTrack", and copy the 16 letters.
3. In `config/env.php` set `SUNTRACK_SMTP_HOST=smtp.gmail.com`, port `587`,
   secure `tls`, `SUNTRACK_SMTP_USER` and `SUNTRACK_MAIL_FROM` = that Gmail
   address, `SUNTRACK_SMTP_PASS` = the App Password, and `SUNTRACK_APP_URL`
   = your site address (the reset link points there).
4. Test it: `php database/test_mail.php --to=you@gmail.com`

Later, for a company address (no-reply@yourcompany.ph), use the SMTP details
from your host's email section instead — same settings, different values.

**Troubleshooting**
- *535 Username and Password not accepted* — you used the normal Gmail
  password, or 2-Step Verification is off. Use an App Password.
- *TLS handshake failed* on a Windows PC — antivirus (AVG, Avast, Kaspersky…)
  "mail shield" features intercept encrypted mail. Turn off outgoing-mail
  (SMTP) scanning in the antivirus, or test from the real server. Hosting
  servers do not have this problem.
- *cannot connect* — the host blocks outgoing port 587; try port `465` with
  secure `ssl`, or ask the host to open it.

### Server requirements

PHP **8.1+** (developed on 8.2) with `pdo_mysql`, `mbstring`, `openssl`;
MySQL 8 or MariaDB 10.4+; Apache with `.htaccess` (`AllowOverride All`).
Any cPanel/hPanel shared host or a small LAMP VPS fits. Static hosts
(Vercel, Netlify, GitHub Pages) cannot run it — it needs PHP and MySQL.

### Upload steps (shared hosting)

1. Create the database and a database user in the hosting panel.
2. phpMyAdmin → import `suntrack_erp.sql`, then phases 1–6 in order.
   (The schema file starts with `DROP DATABASE … CREATE DATABASE suntrack_erp`;
   on hosts where you cannot create databases, remove those first lines and
   import into the database the panel made for you.)
3. Upload the project files (not `database/*.sql` — they are blocked anyway).
4. Create `config/env.php` from `config/env.example.php`.
5. Turn on the free SSL certificate and force HTTPS.
6. Run `database/create_user.php` for the first manager / warehouse / admin.
7. Sign in on a phone and a laptop; check Settings → change password.

## 4. Scope notes for evaluators / graders

- **Admin role is view + export only, by design.** Every create/edit/delete
  action in the system is restricted to the Management side (`manager` /
  `staff` roles) and enforced on the server, not just hidden in the UI — an
  Admin session cannot mutate data even by calling the API directly.
- List views (Clients, Technicians, Staff, Inventory, Projects, Billing,
  Sub-Contractors, Service Requests, Maintenance) cap at 500 rows per request
  as a safety net against the page slowing down after months of real
  accumulated data; the existing search/filter controls on each tab narrow
  results well below that in normal use. This is a deliberate, low-risk
  choice over building a full pagination UI under time pressure — worth
  revisiting if the dataset genuinely grows past that.
