# SunTrack ERP — Phase 3 Changes & Deployment Notes

Everything in this document was tested against a running installation
(PHP 8.3, MariaDB 10.11, your schema + all three migrations + the seeder).

---

## 1. Deploy in this order

```bash
# 1. Back up first. This migration alters tables.
mysqldump -u root suntrack_erp > suntrack_backup_$(date +%F).sql

# 2. Copy the files over your existing installation (nothing is deleted).

# 3. Run the Phase 3 migration.
mysql -u root suntrack_erp < database/phase3_geo_realtime_consent.sql
```

**If you ever re-run the seeder, run the Phase 3 migration again afterwards.**
The seeder wipes and rebuilds `clients` and `jobs`, and it predates client
coordinates — so seeding last leaves 50 clients with no location and 7 jobs
that strict geofencing will refuse. Phase 3's backfill repairs this, and it is
idempotent, so re-running it costs nothing. See `SETUP.md` for the full order.

The migration is **guarded and idempotent** — every statement checks before it
acts, so running it twice is a no-op. Verified by running it twice in a row.

### Before going live

Set `APP_ENV` to `'production'` in `config/config.php`. In development it
prints PHP errors into the response body, which leaks table names and file
paths into your API responses.

---

## 2. Read this first — two things that will bite you

### 2.1 HTTPS is not optional any more

Browsers only allow **geolocation** and **camera access** on a secure origin
(HTTPS, or `localhost`). Over plain `http://192.168.x.x` — a typical XAMPP LAN
setup — both are refused.

The cruel part is how Chrome reports it: as `PERMISSION_DENIED`. So a
technician is told to grant a permission they have already granted, and no
amount of tapping "Allow" ever helps.

This release detects the real cause and says so plainly, both as a persistent
red banner and in every GPS/camera error message. But **the fix is still to
serve SunTrack over HTTPS.** Until you do:

- Technicians cannot Time In (no GPS).
- Warehouse cannot scan (no camera).

For a local network, a self-signed certificate in Apache is enough to unblock
both. This is the single highest-priority item before field rollout.

### 2.2 Strict geofencing is ON, and 6 clients have no pin

`geofence_strict = 1` means a job with no site coordinates **refuses Time In**.
Previously such a job silently disabled the geofence entirely and let a
technician time in from anywhere, recording it as `INSIDE`.

The migration backfilled coordinates in both directions (clients from their
jobs, jobs from their clients) and every job now has coordinates. But 6 clients
still have none, because there was nothing to infer from. Plot them in
**Admin → Clients** (they show an amber "No pin" badge) before rollout.

Escape hatch during transition:

```sql
UPDATE settings SET setting_value = '0' WHERE setting_key = 'geofence_strict';
```

---

## 3. What changed

### 3.1 Security fixes

| Issue | Before | Now |
|---|---|---|
| **Geofence bypass** | A job with no coordinates skipped the distance check entirely — time in from anywhere, stamped `INSIDE` | Refused under `geofence_strict`; status stored as `NULL`, not a false `INSIDE` |
| **Login brute force** | Unlimited password guesses | 5 failures per email / 20 per IP in a 15-minute sliding window, checked *before* the hash comparison |
| **Session lifetime** | Lasted as long as the browser stayed open | 60-minute idle and 12-hour absolute timeouts |
| **Security headers** | Only in `.htaccess` — silently absent under nginx or `AllowOverride off` | Sent from PHP, so they hold everywhere. Adds a CSP and `Permissions-Policy` |
| **`APP_BASE_URL`** | Hard-coded `/suntrack-erp`; every redirect broke if the folder was renamed | Auto-detected, overridable via constant or `SUNTRACK_BASE_URL` |
| **Code generation** | `COUNT(*) + 1` — collided after any deletion, and two concurrent creates produced the same code | `MAX()`-based with retry-on-duplicate, refereed by the UNIQUE index |
| **Session handling** | Defaults | `use_strict_mode` and `use_only_cookies` enabled |
| **Password minimum** | 6 characters | 8 characters |

Verified: lockout fires on attempt 6 and refuses even the *correct* password
while locked.

### 3.2 Real-time updates

A single heartbeat — `api/realtime/sync.php` — reports which tables have
changed. Each portal reloads only the tab currently on screen.

Built on **fingerprints** (`COUNT(*)` + `MAX(id)` + `MAX(updated_at)`) rather
than a change-feed table. That means no write endpoint had to be modified, and
none can forget to announce itself — a channel is correct by construction.

- **Role-scoped**: admin sees 15 channels, warehouse 3, client 3, technician 2.
  A client's poll never touches your inventory tables.
- **Cheap**: unchanged polls short-circuit to a tiny payload; each channel is
  one indexed aggregate.
- **Polite**: pauses when the tab is hidden, resumes immediately on return,
  backs off exponentially on errors, never fires on the first poll.

Tune the interval without a redeploy:

```sql
UPDATE settings SET setting_value = '5' WHERE setting_key = 'realtime_poll_seconds';
```

Verified end to end: warehouse issues stock through the real API (117 → 115),
and the admin's very next poll reports both `inventory` and `stock_movements`
changed with fresh counters.

### 3.3 Client coordinates

`clients` gained `lat`, `lng`, and `geofence_radius_m`.

- Admin → Clients now has a **Leaflet map picker**: click, drag the pin, "use
  my location", or type coordinates directly.
- A job created **without** coordinates inherits the client's — including their
  radius, not the global default.
- Half-filled pairs, `0,0`, and out-of-range values are all rejected. A record
  that *looks* plotted but is wrong is worse than a blank one.
- Moving a client's pin optionally propagates to their **open** jobs. Completed
  jobs keep their original location, because their attendance was judged
  against it.
- Unplotted clients show an amber "No pin" badge in the admin table.

### 3.4 Mobile — technician, warehouse, client

The slide-in drawer nav was already well built. These are the gaps that only
show up on a real handset:

- **iOS auto-zoom** — Safari zooms the page whenever a focused input is under
  16px, and Tailwind's `text-sm` is 14px. Every form triggered it. Forced to
  16px under `pointer: coarse` only, so desktop is untouched.
- **Safe-area insets** — `viewport-fit=cover` plus `env(safe-area-inset-*)` on
  the top bar, drawer, page bottom, and cookie banner, so nothing hides under
  a notch or home indicator.
- **Touch targets** — 44×44px minimum on buttons and icon actions (matters for
  a warehouse clerk tapping Receive/Issue/Return with gloves), plus
  `touch-action: manipulation` so a double-tap fires instead of zooming.
- **Screen wake lock** — a locked phone stopped the geofence ping timer,
  leaving a gap in the trail that reads like the technician left the site. The
  screen is now held awake **only while a job is actively in the field**, and
  released the moment it is not, so it does not drain the battery all day.
- **QR scanner** — video constrained to the viewport, long-press-save
  suppressed, control strip enlarged. Camera was already correctly requesting
  the rear lens (`facingMode: environment`).
- **Honest diagnostics** — GPS and camera failures now name the actual cause:
  insecure origin, permission denied, camera in use by another app, no camera
  found, or indoor timeout.

### 3.5 Privacy, cookies, consent

- **`privacy.php`** — a real policy, not filler. Specific about what location
  tracking does and does not do, which matters because you are tracking
  employees. Written against the Data Privacy Act of 2012 (RA 10173).
- **Cookie banner** on all 8 pages, hidden once answered. Offers "Accept all"
  and "Essential only" rather than a reject button that could not be honoured —
  SunTrack sets exactly two cookies and both are strictly necessary.
- **Consent enforced server-side** at registration. A client-side checkbox is a
  courtesy, not a control.
- Every decision logged to `consent_logs` with version, IP, user agent, and
  timestamp, and mirrored onto the user row.
- A **policy version bump** re-prompts everyone:
  ```sql
  UPDATE settings SET setting_value = '1.1' WHERE setting_key = 'privacy_policy_version';
  ```

---

## 4. New files

```
database/phase3_geo_realtime_consent.sql   migration (idempotent)
includes/settings_lib.php                  runtime settings, cached per request
includes/security.php                      throttling, session timeouts, headers
includes/consent.php                       consent recording
includes/consent_banner.php                cookie banner (include before </body>)
api/realtime/sync.php                      the heartbeat
api/consent/save.php                       consent endpoint
assets/js/suntrack-realtime.js             polling client
assets/js/suntrack-mobile.js               secure-context, diagnostics, wake lock
assets/css/suntrack-mobile.css             mobile stylesheet
privacy.php                                policy + cookie notice
```

## 5. Settings you can tune

| Key | Default | Effect |
|---|---|---|
| `geofence_strict` | `1` | Jobs with no coordinates refuse Time In |
| `geofence_default_radius_m` | `500` | Fallback radius |
| `geofence_ping_seconds` | `20` | Location trail interval |
| `realtime_poll_seconds` | `10` | Heartbeat interval |
| `privacy_policy_version` | `1.0` | Bump to re-prompt consent |
| `company_name` / `company_email` | — | Shown on the privacy page |

---

## 6. Test results

- **107 PHP files** — zero syntax errors
- **All 5 roles** log in successfully
- **Every read endpoint × every role** — no unexpected failures
- **All 8 pages** render with zero PHP errors/warnings
- **Migration** — idempotent, verified by running twice
- **Geofence** — 5 km away refused (`5482 m / 300 m`); 50 m allowed; double
  time-in refused; ping recorded; time-out from outside recorded honestly;
  no-coordinates job refused under strict and allowed with strict off
- **Brute force** — locks at attempt 6, refuses the correct password while locked
- **Real-time** — stock change propagates to admin on the next poll
- **Coordinates** — inheritance works with the client's 300 m radius, not the
  500 m default; all validation rejections confirmed
- **Consent** — registration blocked without it, logged with IP and version

---

## 7. Still worth doing

1. **HTTPS.** See §2.1. Nothing on mobile works properly without it.
2. **Plot the 6 remaining clients.** See §2.2.
3. **Change the DB credentials.** `config/database.php` still ships the XAMPP
   default (`root`, empty password). Create a dedicated MySQL user with rights
   to this schema only.
4. **Rotate the seeded passwords.** `admin123`, `tech123` and friends are in
   the seeder and therefore in your repository.
5. Consider a retention job for `geofence_records` — it grows by roughly one
   row per technician per 20 seconds of active field work.
