<?php
require_once __DIR__ . '/../middleware/warehouse.php';
require_once __DIR__ . '/../includes/dark_sidebar.php';

$navItems = [
    ['key' => 'dashboard', 'label' => 'Dashboard', 'icon' => 'fa-gauge-high', 'wired' => true],
    ['key' => 'orders', 'label' => 'Client Orders', 'icon' => 'fa-truck-ramp-box', 'wired' => true, 'badge_id' => 'orders-badge'],
    ['key' => 'inventory', 'label' => 'Inventory', 'icon' => 'fa-boxes-stacked', 'wired' => true],
    ['key' => 'warehouse', 'label' => 'Warehouse', 'icon' => 'fa-warehouse', 'wired' => true],
    ['key' => 'scanner', 'label' => 'QR Scanner', 'icon' => 'fa-qrcode', 'wired' => true],
    ['key' => 'reports', 'label' => 'Reports', 'icon' => 'fa-chart-column', 'wired' => true],
    ['key' => 'notifications', 'label' => 'Notifications', 'icon' => 'fa-bell', 'wired' => true, 'badge_id' => 'notif-badge'],
    ['key' => 'settings', 'label' => 'Settings', 'icon' => 'fa-gear', 'wired' => true],
];
$token = csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>SunTrack ERP — Warehouse</title>
<script src="<?= APP_BASE_URL ?>/assets/vendor/tailwind/tailwind.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/vendor/html5-qrcode/html5-qrcode.min.js"></script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/vendor/fontawesome/css/all.min.css">
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-password.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-logout.js"></script>
<link href="<?= APP_BASE_URL ?>/assets/vendor/inter/inter.css" rel="stylesheet">
<link rel="manifest" href="<?= APP_BASE_URL ?>/manifest.json">
<meta name="theme-color" content="#0b1329">
<link rel="apple-touch-icon" href="<?= APP_BASE_URL ?>/assets/img/app/apple-touch-icon.png">
<script>tailwind.config={theme:{extend:{colors:{suntrackDark:'#0b1329',suntrackNav:'#0f1934',suntrackOrange:'#f97316'},fontFamily:{sans:['Inter','sans-serif']}}}}</script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/css/suntrack-mobile.css">
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-mobile.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-tables.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-realtime.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-paging.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-search.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-pwa.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/vendor/qrcode/qrcode.min.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-qrlabel.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-account.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-filters.js"></script>
<style>body{font-family:'Inter',sans-serif;}
  .kpi-card{background:#fff;border-radius:1rem;padding:1.25rem;box-shadow:0 1px 3px rgba(0,0,0,.06);border:1px solid #eef0f4}
  .badge{font-size:11px;font-weight:700;padding:2px 8px;border-radius:999px}
  input,select,textarea{outline:none}
  .modal-backdrop{background:rgba(0,0,0,.4)}
  table.inv-table th{font-size:11px;text-transform:uppercase;color:#94a3b8;font-weight:700;text-align:left;padding:8px 10px}
  table.inv-table td{padding:10px;font-size:13px;border-top:1px solid #f1f5f9}
  .icon-btn{font-size:12px;color:#475569;padding:4px 8px;border-radius:6px}
  .icon-btn:hover{background:#f1f5f9;color:#f97316}
  .ord-filter{font-size:12px;font-weight:700;padding:6px 12px;border-radius:999px;border:1px solid #e2e8f0;background:#fff;color:#475569}
  .ord-filter.active{background:#0b1329;border-color:#0b1329;color:#fff}
  .scan-mode{font-size:12px;font-weight:700;padding:10px 8px;border-radius:12px;border:1px solid #e2e8f0;background:#fff;color:#334155;text-align:center}
  .scan-mode i{display:block;font-size:16px;margin-bottom:4px}
  .scan-mode.active{color:#fff;border-color:transparent;box-shadow:0 4px 12px rgba(0,0,0,.12)}
  .bar{height:8px;border-radius:999px;background:#f1f5f9;overflow:hidden}
  .bar > span{display:block;height:100%;border-radius:999px}
</style>
</head>
<body class="st-portal bg-slate-50 min-h-screen flex flex-col md:flex-row">

<?php render_dark_sidebar($navItems, 'dashboard', 'Warehouse Core'); ?>

<main class="flex-1 min-w-0 p-4 md:p-8">
  <header class="st-page-head flex flex-wrap items-center justify-between gap-3 mb-6">
    <div>
      <h1 id="page-title" class="text-2xl md:text-3xl font-extrabold text-slate-900">Warehouse Dashboard</h1>
      <p id="page-sub" class="text-slate-500 text-sm mt-1">Live stock levels from the central database.</p>
    </div>
    <div class="flex items-center gap-3">
    <span id="live-indicator" class="inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-full bg-emerald-100 text-emerald-700" title="Live — stock levels refresh themselves as other users receive, issue, or return items.">
      <span id="live-dot" class="h-2 w-2 rounded-full bg-emerald-500"></span> <span id="live-text">Live</span>
    </span>
    <button id="btn-add-item" class="hidden bg-suntrackOrange hover:bg-orange-600 text-white text-sm font-bold px-4 py-2.5 rounded-xl shadow-lg shadow-orange-600/20">
      <i class="fas fa-plus mr-1"></i> Add Item
    </button>
    </div>
  </header>

  <!-- DASHBOARD -->
  <section id="tab-dashboard" class="tab-panel">
    <div id="dash-loading" class="text-slate-400 text-sm">Loading...</div>
    <div id="dash-content" class="hidden space-y-6">
      <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div class="kpi-card"><p class="text-xs font-semibold text-slate-500 uppercase">Active SKUs</p><p id="kpi-skus" class="text-2xl font-extrabold text-slate-900 mt-2">—</p></div>
        <div class="kpi-card"><p class="text-xs font-semibold text-slate-500 uppercase">Total Stock Qty</p><p id="kpi-qty" class="text-2xl font-extrabold text-slate-900 mt-2">—</p></div>
        <div class="kpi-card"><p class="text-xs font-semibold text-slate-500 uppercase">Low Stock</p><p id="kpi-low" class="text-2xl font-extrabold text-amber-500 mt-2">—</p></div>
        <div class="kpi-card"><p class="text-xs font-semibold text-slate-500 uppercase">Out of Stock</p><p id="kpi-out" class="text-2xl font-extrabold text-red-500 mt-2">—</p></div>
      </div>
      <div class="grid md:grid-cols-2 gap-6">
        <div class="kpi-card"><h3 class="font-bold text-slate-900 mb-3">Stock by Category</h3><div id="by-category" class="text-sm text-slate-600 space-y-2"></div></div>
        <div class="kpi-card"><h3 class="font-bold text-slate-900 mb-3">Stock Alerts</h3><div id="stock-alerts" class="text-sm text-slate-600 space-y-2"></div></div>
      </div>
      <div class="kpi-card">
        <div class="flex items-center justify-between mb-3">
          <h3 class="font-bold text-slate-900"><i class="fas fa-truck-ramp-box text-suntrackOrange mr-1"></i> Client Orders to Prepare</h3>
          <button type="button" class="text-xs font-bold text-suntrackOrange hover:underline" onclick="goToTab('orders')">View all</button>
        </div>
        <div id="dash-orders" class="space-y-2 text-sm"><p class="text-slate-400">Loading...</p></div>
      </div>
      <div class="kpi-card"><h3 class="font-bold text-slate-900 mb-3">Recent Warehouse Activity</h3><div id="recent-activity" class="text-sm text-slate-600 divide-y divide-slate-100"></div></div>
    </div>
  </section>

  <!-- CLIENT ORDERS (material requests from Management) -->
  <section id="tab-orders" class="tab-panel hidden space-y-4">
    <div class="kpi-card">
      <div class="flex flex-wrap gap-2 items-center">
        <div id="ord-filters" class="flex flex-wrap gap-1">
          <button type="button" data-ord-status="open" class="ord-filter">Open</button>
          <button type="button" data-ord-status="READY" class="ord-filter">Ready</button>
          <button type="button" data-ord-status="RELEASED" class="ord-filter">Released</button>
          <button type="button" data-ord-status="CANCELLED" class="ord-filter">Cancelled</button>
          <button type="button" data-ord-status="all" class="ord-filter">All</button>
        </div>
        <input id="ord-search" type="text" placeholder="Search order, client, city, project, notes..." class="flex-1 min-w-[180px] rounded-lg border border-slate-200 text-sm px-3 py-2">
      </div>
      <p class="text-[11px] text-slate-400 mt-2">Management sends an order when a client needs panels, inverters or batteries. Open it and scan the items in — it turns <b>READY</b> by itself once everything is prepared, then release it to whoever takes it out.</p>
    </div>
    <div id="ord-list" class="grid md:grid-cols-2 xl:grid-cols-3 gap-4"></div>
  </section>

  <!-- NOTIFICATIONS -->
  <section id="tab-notifications" class="tab-panel hidden">
    <div class="flex items-center justify-between mb-4">
      <h3 class="font-bold text-slate-800">Notifications</h3>
      <button type="button" id="notif-mark-all" class="text-xs font-bold text-suntrackOrange hover:underline">Mark all as read</button>
    </div>
    <div id="notif-list" class="kpi-card !p-0 divide-y divide-slate-100"></div>
  </section>

  <!-- INVENTORY -->
  <section id="tab-inventory" class="tab-panel hidden">
    <div class="kpi-card mb-4">
      <div class="grid grid-cols-2 gap-3 items-end sm:flex sm:flex-wrap">
        <div class="col-span-2 sm:flex-1 sm:min-w-[180px]">
          <label class="block text-xs font-semibold text-slate-500 mb-1">Search</label>
          <input id="inv-search" type="text" placeholder="SKU, name, brand, model, serial, location..." class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2">
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-500 mb-1">Category</label>
          <select id="inv-filter-category" class="w-full sm:w-auto rounded-lg border border-slate-200 text-sm px-3 py-2">
            <option value="">All</option><option>Solar Panel</option><option>Inverter</option><option>Battery</option>
          </select>
        </div>
        <div>
          <label class="block text-xs font-semibold text-slate-500 mb-1">Status</label>
          <select id="inv-filter-status" class="w-full sm:w-auto rounded-lg border border-slate-200 text-sm px-3 py-2">
            <option value="">All</option><option>ACTIVE</option><option>LOW_STOCK</option><option>OUT_OF_STOCK</option><option>DISCONTINUED</option>
          </select>
        </div>
        <button id="inv-filter-btn" class="w-full sm:w-auto bg-suntrackDark hover:bg-slate-800 text-white text-sm font-semibold px-4 py-2 rounded-lg">Filter</button>
      </div>
    </div>

    <div class="kpi-card overflow-x-auto">
      <table class="inv-table data-table w-full">
        <thead><tr>
          <th>SKU</th><th>Item</th><th>Category</th><th>Qty</th><th>Unit Cost</th><th>Location</th><th>Status</th><th>Actions</th>
        </tr></thead>
        <tbody id="inv-table-body"></tbody>
      </table>
      <p id="inv-empty" class="hidden text-slate-400 text-sm py-6 text-center">No inventory items match your filters.</p>
    </div>
  </section>

  <!-- QR SCANNER -->
  <section id="tab-scanner" class="tab-panel hidden">
    <div class="kpi-card mb-4">
      <p class="text-xs font-semibold text-slate-500 mb-2">What are you scanning for?</p>
      <div id="scan-modes" class="grid grid-cols-2 sm:grid-cols-5 gap-2"></div>
      <p id="scan-mode-hint" class="text-xs mt-3 rounded-lg px-3 py-2"></p>
      <div id="prepare-wrap" class="hidden mt-3">
        <label class="block text-xs font-semibold text-slate-500 mb-1">Client order to prepare</label>
        <select id="prepare-order-select" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></select>
        <div id="prepare-progress" class="mt-3"></div>
      </div>
    </div>

    <div class="kpi-card mb-4">
      <div class="flex flex-wrap items-center justify-between gap-3 mb-3">
        <div>
          <h3 class="font-bold text-slate-900">Scan a Code</h3>
          <p class="text-xs text-slate-500 mt-0.5">Point your camera at an item's QR code / barcode, or type the SKU below.</p>
        </div>
        <button id="qr-toggle-btn" class="bg-suntrackOrange hover:bg-orange-600 text-white text-sm font-bold px-4 py-2.5 rounded-xl shadow-lg shadow-orange-600/20 whitespace-nowrap">
          <i class="fas fa-camera mr-1"></i> Start Scanning
        </button>
      </div>
      <div id="qr-reader" class="hidden rounded-xl overflow-hidden border border-slate-200"></div>
      <p id="qr-cam-error" class="hidden text-xs text-red-600 mt-2"></p>
      <p class="text-[11px] text-slate-400 mt-2">Camera access requires HTTPS (or localhost) and browser permission.</p>
    </div>

    <div class="kpi-card mb-4">
      <label class="block text-xs font-semibold text-slate-500 mb-1">Camera not working? Type the code instead</label>
      <div class="flex gap-2">
        <input id="qr-manual-code" type="text" placeholder="SKU, QR code, unit code or serial no." class="flex-1 rounded-lg border border-slate-200 text-sm px-3 py-2" autocomplete="off">
        <button id="qr-manual-btn" class="bg-suntrackDark hover:bg-slate-800 text-white text-sm font-semibold px-4 py-2 rounded-lg shrink-0">Look Up</button>
      </div>
    </div>

    <div id="qr-loading" class="hidden text-slate-400 text-sm text-center py-4">Looking up code...</div>
    <div id="qr-result" class="hidden kpi-card"></div>
    <div id="qr-notfound" class="hidden kpi-card text-center text-slate-500 text-sm py-6">
      <i class="fas fa-circle-exclamation text-amber-400 text-xl mb-2 block"></i>No matching record for that code.
    </div>
  </section>

  <!-- ==================== WAREHOUSE ==================== -->
  <section id="tab-warehouse" class="tab-panel hidden space-y-5">
    <div class="kpi-card">
      <div class="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide">Warehouse</p>
          <h2 id="wh-name" class="text-xl font-extrabold text-slate-900">—</h2>
          <p id="wh-location" class="text-sm text-slate-500"><i class="fas fa-location-dot mr-1"></i>—</p>
        </div>
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          <div><p id="wh-skus" class="text-2xl font-extrabold text-slate-900">—</p><p class="text-[11px] text-slate-400 font-semibold">SKUs</p></div>
          <div><p id="wh-qty" class="text-2xl font-extrabold text-slate-900">—</p><p class="text-[11px] text-slate-400 font-semibold">Units</p></div>
          <div><p id="wh-low" class="text-2xl font-extrabold text-amber-500">—</p><p class="text-[11px] text-slate-400 font-semibold">Low</p></div>
          <div><p id="wh-out" class="text-2xl font-extrabold text-red-500">—</p><p class="text-[11px] text-slate-400 font-semibold">Out</p></div>
        </div>
      </div>
    </div>

    <div class="kpi-card">
      <h3 class="font-bold text-slate-900 mb-3">Today</h3>
      <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div class="rounded-xl bg-emerald-50 p-3"><p id="wh-t-recv" class="text-xl font-extrabold text-emerald-700">0</p><p class="text-[11px] font-semibold text-emerald-600">Units received</p></div>
        <div class="rounded-xl bg-orange-50 p-3"><p id="wh-t-issue" class="text-xl font-extrabold text-orange-700">0</p><p class="text-[11px] font-semibold text-orange-600">Units issued</p></div>
        <div class="rounded-xl bg-sky-50 p-3"><p id="wh-t-ret" class="text-xl font-extrabold text-sky-700">0</p><p class="text-[11px] font-semibold text-sky-600">Units returned</p></div>
        <div class="rounded-xl bg-slate-100 p-3"><p id="wh-t-total" class="text-xl font-extrabold text-slate-700">0</p><p class="text-[11px] font-semibold text-slate-500">Total movements</p></div>
      </div>
    </div>

    <div class="kpi-card">
      <h3 class="font-bold text-slate-900 mb-3">Quick Actions</h3>
      <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <button type="button" data-quick="receive" class="st-primary-action rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm px-4 py-3"><i class="fas fa-arrow-down-long mr-1"></i> Receive Stock</button>
        <button type="button" data-quick="issue" class="st-primary-action rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-sm px-4 py-3"><i class="fas fa-arrow-up-long mr-1"></i> Issue Stock</button>
        <button type="button" data-quick="return" class="st-primary-action rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-sm px-4 py-3"><i class="fas fa-rotate-left mr-1"></i> Return Stock</button>
        <button type="button" data-quick="scan" class="st-primary-action rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-sm px-4 py-3"><i class="fas fa-qrcode mr-1"></i> Scan QR</button>
      </div>
      <p class="text-[11px] text-slate-400 mt-2">Receive, Issue and Return open the scanner in that mode — scan the item next.</p>
    </div>

    <div class="grid lg:grid-cols-2 gap-5">
      <div class="kpi-card">
        <h3 class="font-bold text-slate-900 mb-3">Recent Movements</h3>
        <div class="overflow-x-auto">
          <table class="w-full text-sm data-table"><thead><tr class="text-left text-slate-400 text-xs uppercase">
            <th class="py-2">Movement</th><th>Item</th><th>Qty</th><th>Job</th><th>User</th><th>Date</th>
          </tr></thead><tbody id="wh-movements"></tbody></table>
        </div>
      </div>
      <div class="kpi-card">
        <h3 class="font-bold text-slate-900 mb-3">Stock Alerts</h3>
        <div id="wh-alerts" class="space-y-2"></div>
      </div>
    </div>
  </section>

  <!-- ==================== REPORTS ==================== -->
  <section id="tab-reports" class="tab-panel hidden space-y-5">
    <div class="kpi-card">
      <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Report</label>
          <select id="rp-report" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2">
            <option value="movements">Stock Movements</option>
            <option value="inventory">Current Inventory</option>
            <option value="low_stock">Low Stock</option>
            <option value="out_of_stock">Out of Stock</option>
            <option value="issued">Items Issued to Jobs</option>
            <option value="received">Items Received</option>
            <option value="returned">Items Returned</option>
            <option value="orders">Client Orders (prepared &amp; released)</option>
          </select></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Date From</label>
          <input type="date" id="rp-from" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Date To</label>
          <input type="date" id="rp-to" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Category</label>
          <select id="rp-cat" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"><option value="">All categories</option></select></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Movement Type</label>
          <select id="rp-mtype" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2">
            <option value="">All types</option><option value="RECEIVE">Receive</option><option value="ISSUE">Issue</option><option value="RETURN">Return</option>
          </select></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Item</label>
          <select id="rp-item" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"><option value="">All items</option></select></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Job</label>
          <select id="rp-job" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"><option value="">All jobs</option></select></div>
        <div class="flex items-end gap-2">
          <button id="rp-run" class="flex-1 st-primary-action rounded-lg bg-suntrackOrange hover:bg-orange-600 text-white text-sm font-bold px-4 py-2"><i class="fas fa-filter mr-1"></i> Run</button>
          <button id="rp-clear" class="rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-bold px-3 py-2" title="Clear filters"><i class="fas fa-xmark"></i></button>
        </div>
      </div>
    </div>

    <div class="grid grid-cols-2 lg:grid-cols-6 gap-3">
      <div class="kpi-card text-center"><p id="rp-recv" class="text-xl font-extrabold text-emerald-600">0</p><p class="text-[11px] text-slate-400 font-semibold">Received</p></div>
      <div class="kpi-card text-center"><p id="rp-issued" class="text-xl font-extrabold text-orange-600">0</p><p class="text-[11px] text-slate-400 font-semibold">Issued</p></div>
      <div class="kpi-card text-center"><p id="rp-ret" class="text-xl font-extrabold text-sky-600">0</p><p class="text-[11px] text-slate-400 font-semibold">Returned</p></div>
      <div class="kpi-card text-center"><p id="rp-stock" class="text-xl font-extrabold text-slate-900">0</p><p class="text-[11px] text-slate-400 font-semibold">Current stock</p></div>
      <div class="kpi-card text-center"><p id="rp-low" class="text-xl font-extrabold text-amber-500">0</p><p class="text-[11px] text-slate-400 font-semibold">Low stock</p></div>
      <div class="kpi-card text-center"><p id="rp-out" class="text-xl font-extrabold text-red-500">0</p><p class="text-[11px] text-slate-400 font-semibold">Out of stock</p></div>
    </div>

    <div class="kpi-card">
      <div class="flex flex-wrap items-center justify-between gap-2 mb-3">
        <h3 class="font-bold text-slate-900">Results <span id="rp-count" class="text-xs font-semibold text-slate-400"></span></h3>
        <button id="rp-export" class="rounded-lg bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold px-4 py-2"><i class="fas fa-file-csv mr-1"></i> Export CSV</button>
      </div>
      <div id="rp-truncated" class="hidden bg-amber-50 border border-amber-200 text-amber-800 text-xs rounded-lg px-3 py-2 mb-3"></div>
      <div class="overflow-x-auto">
        <table class="w-full text-sm data-table"><thead id="rp-head"></thead><tbody id="rp-body"></tbody></table>
      </div>
    </div>
  </section>

  <!-- ==================== SETTINGS ==================== -->
  <section id="tab-settings" class="tab-panel hidden space-y-5">
    <div class="grid lg:grid-cols-2 gap-5">
      <div class="kpi-card">
        <h3 class="font-bold text-slate-900 mb-1">My Profile</h3>
        <p class="text-xs text-slate-400 mb-4">Your own account details. Only you can change these.</p>
        <div id="pf-msg" class="hidden text-xs rounded-lg px-3 py-2 mb-3"></div>
        <div class="space-y-3">
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Full Name</label>
            <input id="pf-name" type="text" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Email</label>
            <input id="pf-email" type="email" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Phone</label>
            <input id="pf-phone" type="tel" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Role</label>
            <input id="pf-role" type="text" disabled class="w-full rounded-lg border border-slate-200 bg-slate-50 text-slate-500 text-sm px-3 py-2">
            <p class="text-[11px] text-slate-400 mt-1">Your role is set by Management and cannot be changed here.</p></div>
          <button id="pf-save" class="st-primary-action w-full rounded-lg bg-suntrackOrange hover:bg-orange-600 text-white text-sm font-bold px-4 py-2.5">Save Changes</button>
        </div>
      </div>

      <div class="kpi-card">
        <h3 class="font-bold text-slate-900 mb-1">Change Password</h3>
        <p class="text-xs text-slate-400 mb-4">You will stay signed in on this device. Other devices are signed out.</p>
        <div id="pw-msg" class="hidden text-xs rounded-lg px-3 py-2 mb-3"></div>
        <div class="space-y-3">
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Current Password</label>
            <input id="pw-current" type="password" autocomplete="current-password" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">New Password</label>
            <input id="pw-new" type="password" autocomplete="new-password" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2">
            <p class="text-[11px] text-slate-400 mt-1">At least 8 characters.</p></div>
          <div><label class="block text-xs font-semibold text-slate-500 mb-1">Confirm New Password</label>
            <input id="pw-confirm" type="password" autocomplete="new-password" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
          <button id="pw-save" class="st-primary-action w-full rounded-lg bg-slate-800 hover:bg-slate-900 text-white text-sm font-bold px-4 py-2.5">Update Password</button>
        </div>
      </div>
      <div id="twofa-card" class="kpi-card"></div>
      <div class="kpi-card" data-push-card></div>
    </div>

    <div class="kpi-card">
      <h3 class="font-bold text-slate-900 mb-2">Account</h3>
      <div class="grid sm:grid-cols-3 gap-3 text-sm">
        <div><p class="text-[11px] text-slate-400 font-semibold uppercase">Status</p><p id="pf-status" class="font-bold text-slate-700">—</p></div>
        <div><p class="text-[11px] text-slate-400 font-semibold uppercase">Last Sign-in</p><p id="pf-last" class="font-bold text-slate-700">—</p></div>
        <div><p class="text-[11px] text-slate-400 font-semibold uppercase">Member Since</p><p id="pf-since" class="font-bold text-slate-700">—</p></div>
      </div>
      <a href="<?= APP_BASE_URL ?>/privacy.php" target="_blank" rel="noopener" class="inline-block mt-4 text-xs font-semibold text-suntrackOrange hover:underline">
        <i class="fas fa-shield-halved mr-1"></i> Privacy Policy &amp; Cookie Notice
      </a>
    </div>
  </section>
</main>

<!-- Add/Edit Item Modal -->
<div id="item-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-50 p-4">
  <div class="bg-white rounded-2xl p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
    <h3 id="item-modal-title" class="font-bold text-slate-900 mb-4">Add Inventory Item</h3>
    <div id="item-modal-error" class="hidden bg-red-50 border border-red-200 text-red-600 text-xs rounded-lg px-3 py-2 mb-3"></div>
    <input type="hidden" id="item-id">
    <div class="space-y-3">
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Item Name</label><input id="item-name" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Category</label>
          <select id="item-category" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"><option>Solar Panel</option><option>Inverter</option><option>Battery</option></select>
        </div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Brand</label><input id="item-brand" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Model</label><input id="item-model" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Lot / Batch No.</label><input id="item-serial" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      </div>
      <div id="item-tracking-wrap">
        <label class="block text-xs font-semibold text-slate-500 mb-1">QR tracking</label>
        <select id="item-tracking" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2">
          <option value="PRODUCT">One QR for the product — type the quantity when moving stock</option>
          <option value="SERIAL">One QR per unit — each unit has its own serial number</option>
        </select>
        <p class="text-[11px] text-slate-400 mt-1">Use per-unit QR for inverters and batteries you want to trace by serial number (warranty, service history).</p>
      </div>
      <div id="item-serials-wrap" class="hidden">
        <label class="block text-xs font-semibold text-slate-500 mb-1">Serial numbers on hand <span id="item-serials-count" class="text-slate-400"></span></label>
        <textarea id="item-serials" rows="4" placeholder="One serial number per line (leave empty if none in stock yet)" class="w-full rounded-lg border border-slate-200 text-xs font-mono px-3 py-2"></textarea>
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div id="item-qty-wrap"><label class="block text-xs font-semibold text-slate-500 mb-1">Quantity</label><input id="item-qty" type="number" min="0" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <div><label class="block text-xs font-semibold text-slate-500 mb-1">Unit Cost</label><input id="item-cost" type="number" step="0.01" min="0" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
      </div>
      <div><label class="block text-xs font-semibold text-slate-500 mb-1">Warehouse Location</label><input id="item-location" placeholder="e.g. Zone A-01" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
    </div>
    <div class="flex gap-2 mt-5">
      <button id="item-cancel" class="flex-1 border border-slate-200 text-slate-600 text-sm font-semibold py-2 rounded-lg">Cancel</button>
      <button id="item-save" class="flex-1 bg-suntrackOrange hover:bg-orange-600 text-white text-sm font-semibold py-2 rounded-lg">Save</button>
    </div>
  </div>
</div>

<!-- Receive/Issue/Return Modal -->
<div id="move-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-50 p-4">
  <div class="bg-white rounded-2xl p-6 w-full max-w-sm max-h-[92vh] overflow-y-auto">
    <h3 id="move-modal-title" class="font-bold text-slate-900 mb-1">Receive Stock</h3>
    <p id="move-modal-item" class="text-xs text-slate-500 mb-4"></p>
    <div id="move-modal-error" class="hidden bg-red-50 border border-red-200 text-red-600 text-xs rounded-lg px-3 py-2 mb-3"></div>
    <input type="hidden" id="move-inv-id">
    <div id="move-job-wrap" class="hidden mb-3">
      <label id="move-job-label" class="block text-xs font-semibold text-slate-500 mb-1">Job</label>
      <select id="move-job-select" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></select>
    </div>
    <div id="move-units-wrap" class="hidden mb-3">
      <label class="block text-xs font-semibold text-slate-500 mb-1">Units <span id="move-units-count" class="text-slate-400"></span></label>
      <div id="move-units" class="max-h-48 overflow-y-auto rounded-lg border border-slate-200 divide-y divide-slate-100 text-xs"></div>
      <p class="text-[11px] text-slate-400 mt-1">Tick each unit that is moving. Each unit counts once.</p>
    </div>
    <div id="move-serials-wrap" class="hidden mb-3">
      <label class="block text-xs font-semibold text-slate-500 mb-1">Serial numbers received <span id="move-serials-count" class="text-slate-400"></span></label>
      <textarea id="move-serials" rows="4" placeholder="One serial number per line — each unit gets its own QR label" class="w-full rounded-lg border border-slate-200 text-xs font-mono px-3 py-2"></textarea>
    </div>
    <div id="move-cond-wrap" class="hidden mb-3">
      <label class="block text-xs font-semibold text-slate-500 mb-1">Condition</label>
      <select id="move-condition" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2">
        <option value="GOOD">Good — back into available stock</option>
        <option value="DAMAGED">Damaged — hold in quarantine</option>
        <option value="NEEDS_INSPECTION">Needs inspection — hold in quarantine</option>
      </select>
    </div>
    <div id="move-ref-wrap" class="hidden mb-3">
      <label class="block text-xs font-semibold text-slate-500 mb-1">Reference (optional)</label>
      <input id="move-ref" type="text" maxlength="50" placeholder="e.g. Supplier DR-1042" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2">
    </div>
    <div id="move-qty-wrap" class="mb-4">
      <label class="block text-xs font-semibold text-slate-500 mb-1">Quantity</label>
      <input id="move-qty" type="number" min="1" value="1" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2">
    </div>
    <div class="flex gap-2">
      <button id="move-cancel" class="flex-1 border border-slate-200 text-slate-600 text-sm font-semibold py-2 rounded-lg">Cancel</button>
      <button id="move-confirm" class="flex-1 bg-suntrackOrange hover:bg-orange-600 text-white text-sm font-semibold py-2 rounded-lg">Confirm</button>
    </div>
  </div>
</div>

<!-- Client Order Modal -->
<div id="order-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-50 p-4">
  <div class="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
    <div class="flex items-center justify-between p-5 border-b border-slate-100">
      <h3 id="order-title" class="font-bold text-slate-900">Client Order</h3>
      <button type="button" id="order-close" class="text-slate-400 hover:text-slate-600"><i class="fas fa-xmark"></i></button>
    </div>
    <div id="order-body" class="p-5 text-sm"></div>
  </div>
</div>

<div id="toast-box" class="fixed bottom-6 right-4 left-4 sm:left-auto space-y-2 z-[60]"></div>

<!-- History Modal -->
<div id="history-modal" class="hidden fixed inset-0 modal-backdrop flex items-center justify-center z-50 p-4">
  <div class="bg-white rounded-2xl p-6 w-full max-w-lg max-h-[80vh] overflow-y-auto">
    <div class="flex items-center justify-between mb-4">
      <h3 id="history-modal-title" class="font-bold text-slate-900">Stock History</h3>
      <button id="history-close" class="text-slate-400 hover:text-slate-600"><i class="fas fa-xmark"></i></button>
    </div>
    <div id="history-list" class="divide-y divide-slate-100 text-sm"></div>
  </div>
</div>

<script>
const CSRF_TOKEN = <?= json_encode($token) ?>;
const WIRED_TABS = ['dashboard','inventory','scanner'];
let moveMode = null; // 'receive' | 'issue' | 'return'
let moveInvName = '';

// Which tab is on screen. Live stock updates reload only what is visible.
let CURRENT_TAB = 'dashboard';

document.querySelectorAll('.tab-link').forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    document.querySelectorAll('.tab-link').forEach(l => l.classList.remove('bg-suntrackOrange','text-white','shadow-md','shadow-orange-600/20'));
    link.classList.add('bg-suntrackOrange','text-white','shadow-md','shadow-orange-600/20');
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.add('hidden'));
    const key = link.dataset.tab;
    CURRENT_TAB = key;
    document.getElementById('btn-add-item').classList.toggle('hidden', key !== 'inventory');
    if (key !== 'scanner') stopQrScanner(); // don't leave the camera running when the tab isn't visible
    if (key === 'dashboard') {
      document.getElementById('page-title').textContent = 'Warehouse Dashboard';
      document.getElementById('page-sub').textContent = 'Live stock levels from the central database.';
      document.getElementById('tab-dashboard').classList.remove('hidden');
    } else if (key === 'inventory') {
      document.getElementById('page-title').textContent = 'Inventory';
      document.getElementById('page-sub').textContent = 'Solar panels, inverters, and batteries — live from MySQL.';
      document.getElementById('tab-inventory').classList.remove('hidden');
      loadInventory();
    } else if (key === 'scanner') {
      // Scanning needs the camera, which is blocked outright on an insecure
      // origin — flag it as soon as the tab opens, not after a failed tap.
      if (window.SunTrackMobile && !SunTrackMobile.isSecure()) {
        SunTrackMobile.warnInsecure('Camera access');
      }
      document.getElementById('page-title').textContent = 'QR Scanner';
      document.getElementById('page-sub').textContent = 'Scan an item to look it up and receive, issue, or return stock on the spot.';
      document.getElementById('tab-scanner').classList.remove('hidden');
    } else if (key === 'warehouse') {
      document.getElementById('page-title').textContent = 'Warehouse';
      document.getElementById('page-sub').textContent = 'Operational overview — today\u2019s activity, recent movements, and stock alerts.';
      document.getElementById('tab-warehouse').classList.remove('hidden');
      loadWarehouse();
    } else if (key === 'reports') {
      document.getElementById('page-title').textContent = 'Reports';
      document.getElementById('page-sub').textContent = 'Filter stock activity and export it for records.';
      document.getElementById('tab-reports').classList.remove('hidden');
      initReports();
    } else if (key === 'settings') {
      document.getElementById('page-title').textContent = 'Settings';
      document.getElementById('page-sub').textContent = 'Your profile and password.';
      document.getElementById('tab-settings').classList.remove('hidden');
      loadProfile();
      SunTrackAccount.renderTwoFactor('twofa-card');
    } else if (key === 'orders') {
      document.getElementById('page-title').textContent = 'Client Orders';
      document.getElementById('page-sub').textContent = 'What Management needs sent out to each client — scan items in until each order is ready.';
      document.getElementById('tab-orders').classList.remove('hidden');
      loadOrders();
    } else if (key === 'notifications') {
      document.getElementById('page-title').textContent = 'Notifications';
      document.getElementById('page-sub').textContent = 'New client orders and updates from Management.';
      document.getElementById('tab-notifications').classList.remove('hidden');
      loadNotifications();
    }
  });
});

function goToTab(key) {
  document.querySelector('.tab-link[data-tab="' + key + '"]')?.click();
}

/* =========================================================================
   Shared helpers
   ========================================================================= */

function fmtDate(v) {
  if (!v) return '—';
  const d = new Date(v.replace(' ', 'T'));
  if (isNaN(d)) return v;
  return d.toLocaleString('en-PH', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function esc(v) {
  if (v === null || v === undefined || v === '') return '—';
  return String(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

const MOVE_BADGE = {
  RECEIVE: 'bg-emerald-50 text-emerald-700',
  ISSUE:   'bg-orange-50 text-orange-700',
  RETURN:  'bg-sky-50 text-sky-700',
  ADJUST:  'bg-slate-100 text-slate-600',
  TRANSFER:'bg-violet-50 text-violet-700',
};
function moveBadge(t) {
  return `<span class="badge ${MOVE_BADGE[t] || 'bg-slate-100 text-slate-600'}">${esc(t)}</span>`;
}

/**
 * Run an async action with the button locked.
 *
 * A warehouse clerk on a phone taps hard and often taps twice. Without this,
 * a double tap posts two movements and doubles the stock change. The server
 * is still the real guard, but this removes the common case.
 */
async function withButtonLock(btn, label, fn) {
  if (!btn || btn.disabled) return;
  const original = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = `<i class="fas fa-circle-notch fa-spin mr-1"></i> ${label}`;
  try { return await fn(); }
  finally { btn.disabled = false; btn.innerHTML = original; }
}

function toast(msg, isError) {
  const box = document.getElementById('toast-box');
  const el = document.createElement('div');
  el.className = 'px-4 py-3 rounded-xl shadow-lg text-sm font-semibold text-white ' + (isError ? 'bg-red-500' : 'bg-emerald-600');
  el.textContent = msg;
  box.appendChild(el);
  setTimeout(() => el.remove(), isError ? 5000 : 3500);
}

// Short buzz on a good scan, a double buzz on a rejected one — the clerk can
// keep their eyes on the shelf instead of the screen.
function scanFeedback(ok) {
  try { if (navigator.vibrate) navigator.vibrate(ok ? 80 : [120, 60, 120]); } catch (e) {}
}

async function getJson(url) {
  try {
    const res = await stFetch(url); // follows paged lists; other responses pass straight through
    return await res.json();
  } catch (e) {
    return { success: false, message: 'Network error. Please try again.' };
  }
}

async function postJson(url, body) {
  try {
    const res = await fetch(url, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(Object.assign({}, body, { csrf_token: CSRF_TOKEN }))
    });
    return await res.json();
  } catch (e) {
    return { success: false, message: 'Network error. Please try again.' };
  }
}

function setBadge(id, n) {
  const el = document.getElementById(id);
  if (!el || typeof n !== 'number') return;
  el.textContent = n > 99 ? '99+' : String(n);
  el.classList.toggle('hidden', n === 0);
}

function showMsg(el, text, ok) {
  el.textContent = text;
  el.className = 'text-xs rounded-lg px-3 py-2 mb-3 ' +
    (ok ? 'bg-emerald-50 border border-emerald-200 text-emerald-700'
        : 'bg-red-50 border border-red-200 text-red-600');
  el.classList.remove('hidden');
}

/* =========================================================================
   WAREHOUSE module
   ========================================================================= */

async function loadWarehouse() {
  try {
    const res = await fetch('../api/dashboard/warehouse.php');
    const json = await res.json();
    if (!json.success) return;
    const d = json.data;

    document.getElementById('wh-name').textContent = d.warehouse?.warehouse_name || 'Main Warehouse';
    document.getElementById('wh-location').innerHTML =
      '<i class="fas fa-location-dot mr-1"></i>' + esc(d.warehouse?.location);

    document.getElementById('wh-skus').textContent = d.kpis.active_skus;
    document.getElementById('wh-qty').textContent  = Number(d.kpis.total_quantity).toLocaleString();
    document.getElementById('wh-low').textContent  = d.kpis.low_stock;
    document.getElementById('wh-out').textContent  = d.kpis.out_of_stock;

    const t = d.today || {};
    document.getElementById('wh-t-recv').textContent  = t.received ?? 0;
    document.getElementById('wh-t-issue').textContent = t.issued ?? 0;
    document.getElementById('wh-t-ret').textContent   = t.returned ?? 0;
    document.getElementById('wh-t-total').textContent = t.total_movements ?? 0;

    const mv = document.getElementById('wh-movements');
    const rows = d.recent_movements || [];
    mv.innerHTML = rows.length
      ? rows.map(m => `<tr class="border-t border-slate-100">
          <td class="py-2">${moveBadge(m.movement_type)}</td>
          <td class="font-semibold text-slate-700">${esc(m.item_name)}</td>
          <td>${m.quantity}</td>
          <td class="text-slate-500">${esc(m.job_code)}</td>
          <td class="text-slate-500">${esc(m.recorded_by_name)}</td>
          <td class="text-slate-400 text-xs">${fmtDate(m.created_at)}</td>
        </tr>`).join('')
      : '<tr><td colspan="6" class="py-6 text-center text-slate-400">No stock movements yet.</td></tr>';

    const alerts = document.getElementById('wh-alerts');
    const list = d.low_stock_list || [];
    alerts.innerHTML = list.length
      ? list.map(a => `
        <button type="button" data-alert-sku="${esc(a.sku)}"
                class="w-full text-left flex items-center justify-between gap-3 rounded-xl border border-slate-100 hover:border-suntrackOrange hover:bg-orange-50/40 px-3 py-2 transition">
          <span>
            <span class="block font-semibold text-slate-700 text-sm">${esc(a.item_name)}</span>
            <span class="block text-[11px] text-slate-400">${esc(a.sku)} · ${a.quantity} left, low below <?= INVENTORY_LOW_STOCK_BELOW ?></span>
          </span>
          <span class="badge ${a.status === 'OUT_OF_STOCK' ? 'bg-red-50 text-red-600' : 'bg-amber-50 text-amber-600'}">
            ${a.status === 'OUT_OF_STOCK' ? 'OUT OF STOCK' : 'LOW'}
          </span>
        </button>`).join('')
      : '<p class="text-sm text-slate-400 py-4 text-center">All stock levels are healthy.</p>';

    // Clicking an alert opens Inventory filtered to that item.
    alerts.querySelectorAll('[data-alert-sku]').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelector('.tab-link[data-tab="inventory"]')?.click();
        const search = document.getElementById('inv-search');
        if (search) { search.value = btn.dataset.alertSku; loadInventory(); }
      });
    });
  } catch (err) {
    document.getElementById('wh-movements').innerHTML =
      '<tr><td colspan="6" class="py-6 text-center text-slate-400">Could not load warehouse activity.</td></tr>';
  }
}

// Quick actions. Receive/Issue/Return need an item, so they open the scanner
// already in that mode — the next scan goes straight to the quantity step.
document.querySelectorAll('[data-quick]').forEach(btn => {
  btn.addEventListener('click', () => {
    const mode = btn.dataset.quick;
    goToTab('scanner');
    setScanMode(mode === 'scan' ? 'lookup' : mode);
  });
});

/* =========================================================================
   CLIENT ORDERS module (material requests from Management)
   ========================================================================= */

const ORDER_STATUS_CLS = {
  PENDING:   'bg-amber-100 text-amber-700',
  PREPARING: 'bg-sky-100 text-sky-700',
  READY:     'bg-emerald-100 text-emerald-700',
  RELEASED:  'bg-violet-100 text-violet-700',
  CANCELLED: 'bg-red-100 text-red-600',
};
const OPEN_ORDER_STATUSES = ['PENDING', 'PREPARING', 'READY'];

function orderBadge(s) {
  return `<span class="badge ${ORDER_STATUS_CLS[s] || 'bg-slate-100 text-slate-600'}">${esc(s)}</span>`;
}

function isOverdue(o) {
  return o.needed_by && OPEN_ORDER_STATUSES.includes(o.status) && o.needed_by < new Date().toISOString().slice(0, 10);
}

/** Per-category progress bars: "Solar Panel 4 / 10". */
function orderLinesHtml(lines) {
  if (!lines || !lines.length) return '<p class="text-xs text-slate-400">No items.</p>';
  return lines.map(l => {
    const req = Number(l.qty_required), prep = Math.min(Number(l.qty_prepared), req);
    const pct = req ? Math.round(prep * 100 / req) : 0;
    const done = prep >= req;
    return `<div class="mb-2">
      <div class="flex justify-between text-xs mb-1">
        <span class="font-semibold text-slate-700">${esc(l.category_name)}</span>
        <span class="${done ? 'text-emerald-600 font-bold' : 'text-slate-500'}">${prep} / ${req}${done ? ' <i class="fas fa-check"></i>' : ''}</span>
      </div>
      <div class="bar"><span style="width:${pct}%;background:${done ? '#10b981' : '#f97316'}"></span></div>
    </div>`;
  }).join('');
}

let ORD_STATUS = 'open';
async function loadOrders() {
  const box = document.getElementById('ord-list');
  document.querySelectorAll('.ord-filter').forEach(b => b.classList.toggle('active', b.dataset.ordStatus === ORD_STATUS));
  const params = new URLSearchParams({ status: ORD_STATUS });
  const s = document.getElementById('ord-search').value.trim();
  if (s) params.set('search', s);
  const json = await getJson('../api/material_requests/list.php?' + params.toString());
  if (!json.success) { box.innerHTML = `<p class="text-red-500 text-sm">${esc(json.message)}</p>`; ORD_BAR.setCount(); return; }
  const rows = json.data.rows;
  ORD_BAR.setCount(rows.length);
  box.innerHTML = rows.length ? rows.map(o => `
    <button type="button" data-order-id="${o.id}" class="kpi-card text-left hover:border-suntrackOrange transition">
      <div class="flex items-start justify-between gap-2 mb-2">
        <div>
          <p class="font-mono text-xs text-slate-400">${esc(o.request_code)}</p>
          <p class="font-bold text-slate-900">${esc(o.client_name)}</p>
          <p class="text-xs text-slate-500">${esc(o.client_code)}${o.project_code ? ' · ' + esc(o.project_code) : ''}${o.job_code ? ' · ' + esc(o.job_code) : ''}</p>
        </div>
        ${orderBadge(o.status)}
      </div>
      ${orderLinesHtml(o.lines)}
      <p class="text-[11px] mt-2 ${isOverdue(o) ? 'text-red-600 font-bold' : 'text-slate-400'}">
        ${o.needed_by ? '<i class="fas fa-calendar-day mr-1"></i>Needed by ' + esc(o.needed_by) + (isOverdue(o) ? ' — overdue' : '') : 'No deadline set'}
      </p>
    </button>`).join('')
    : '<p class="text-slate-400 text-sm col-span-full text-center py-8">No client orders here.</p>';
  box.querySelectorAll('[data-order-id]').forEach(b => b.addEventListener('click', () => openOrder(b.dataset.orderId)));
}
document.querySelectorAll('.ord-filter').forEach(b => b.addEventListener('click', () => { ORD_STATUS = b.dataset.ordStatus; loadOrders(); }));
// Clear also returns the status pills to "Open", the default view.
const ORD_BAR = SunTrackFilters.bind({ search: 'ord-search', onChange: loadOrders, onClear: () => { ORD_STATUS = 'open'; } });

async function loadDashOrders() {
  const box = document.getElementById('dash-orders');
  const json = await getJson('../api/material_requests/list.php?status=open');
  if (!json.success) { box.innerHTML = `<p class="text-slate-400">${esc(json.message)}</p>`; return; }
  const rows = json.data.rows.slice(0, 5);
  box.innerHTML = rows.length ? rows.map(o => `
    <button type="button" data-order-id="${o.id}" class="w-full text-left flex items-center justify-between gap-3 rounded-xl border border-slate-100 hover:border-suntrackOrange hover:bg-orange-50/40 px-3 py-2 transition">
      <span class="min-w-0">
        <span class="block font-semibold text-slate-700 truncate">${esc(o.client_name)} <span class="font-mono text-[11px] text-slate-400">${esc(o.request_code)}</span></span>
        <span class="block text-[11px] ${isOverdue(o) ? 'text-red-600 font-bold' : 'text-slate-400'}">${o.lines.map(l => esc(l.category_name) + ' ' + Math.min(l.qty_prepared, l.qty_required) + '/' + l.qty_required).join(' · ')}${o.needed_by ? ' · by ' + esc(o.needed_by) : ''}</span>
      </span>
      ${orderBadge(o.status)}
    </button>`).join('')
    : '<p class="text-slate-400">No client orders waiting. New ones from Management appear here.</p>';
  box.querySelectorAll('[data-order-id]').forEach(b => b.addEventListener('click', () => openOrder(b.dataset.orderId)));
}

// --- Order detail modal ---
let OPEN_ORDER = null;          // last detail payload shown in the modal
let INV_PICKER_CACHE = null;    // inventory rows for the manual "add item" picker

async function openOrder(id) {
  const json = await getJson('../api/material_requests/get.php?id=' + encodeURIComponent(id));
  if (!json.success) { toast(json.message, true); return; }
  renderOrder(json.data);
  document.getElementById('order-modal').classList.remove('hidden');
}

async function refreshOpenOrder() {
  if (!OPEN_ORDER || document.getElementById('order-modal').classList.contains('hidden')) return;
  const json = await getJson('../api/material_requests/get.php?id=' + OPEN_ORDER.request.id);
  if (json.success) renderOrder(json.data);
}

function renderOrder(d) {
  OPEN_ORDER = d;
  const r = d.request;
  const open = OPEN_ORDER_STATUSES.includes(r.status);
  const canScan = r.status === 'PENDING' || r.status === 'PREPARING';
  document.getElementById('order-title').innerHTML = `${esc(r.request_code)} ${orderBadge(r.status)}`;

  const info = [
    ['Client', `${esc(r.client_name)} <span class="text-slate-400">(${esc(r.client_code)})</span>`],
    ['Phone', esc(r.client_phone)],
    ['Deliver to', esc([r.client_address, r.client_city, r.client_province].filter(Boolean).join(', '))],
    ['Project / Job', esc([r.project_code && (r.project_code + (r.site_name ? ' — ' + r.site_name : '')), r.job_code].filter(Boolean).join(' · '))],
    ['Technician', esc(r.technician_name)],
    ['Needed by', r.needed_by ? `<span class="${isOverdue(r) ? 'text-red-600 font-bold' : ''}">${esc(r.needed_by)}</span>` : '—'],
    ['Requested by', esc(r.requested_by_name) + ` <span class="text-slate-400 text-xs">${fmtDate(r.created_at)}</span>`],
    ['Notes', esc(r.notes)],
  ];
  if (r.ready_at) info.push(['Ready since', fmtDate(r.ready_at)]);
  if (r.status === 'RELEASED') info.push(['Released', `${fmtDate(r.released_at)} by ${esc(r.released_by_name)}${r.released_to ? ' to <b>' + esc(r.released_to) + '</b>' : ''}`]);

  const picked = d.picked.length
    ? `<table class="w-full text-sm"><thead><tr class="text-left text-slate-400 text-[11px] uppercase"><th class="py-1">Item</th><th>SKU</th><th>Qty</th><th></th></tr></thead><tbody>`
      + d.picked.map(p => `<tr class="border-t border-slate-100">
          <td class="py-2"><span class="font-semibold text-slate-700">${esc(p.item_name)}</span><span class="block text-[11px] text-slate-400">${esc(p.category_name)}</span></td>
          <td class="text-xs font-mono text-slate-500">${esc(p.sku)}</td>
          <td class="font-bold">${p.quantity}</td>
          <td class="text-right">${open ? `<button type="button" class="icon-btn text-red-500" title="Remove one and return it to stock" data-unpick="${p.inventory_id}" data-name="${esc(p.item_name)}"><i class="fas fa-minus"></i></button>` : ''}</td>
        </tr>`).join('') + '</tbody></table>'
    : '<p class="text-xs text-slate-400">Nothing scanned for this order yet.</p>';

  const history = d.history.length
    ? d.history.map(h => `<p class="flex justify-between gap-2 py-1 border-t border-slate-50 text-xs">
        <span>${moveBadge(h.movement_type)} ${h.quantity} × ${esc(h.item_name)}</span>
        <span class="text-slate-400">${esc(h.recorded_by_name)} · ${fmtDate(h.created_at)}</span></p>`).join('')
    : '<p class="text-xs text-slate-400">No activity yet.</p>';

  let actions = '';
  if (canScan) {
    actions += `<button type="button" id="ord-scan" class="st-primary-action rounded-xl bg-suntrackOrange hover:bg-orange-600 text-white font-bold text-sm px-4 py-2.5"><i class="fas fa-qrcode mr-1"></i> Scan items for this order</button>
      <button type="button" id="ord-manual-toggle" class="rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm px-4 py-2.5"><i class="fas fa-keyboard mr-1"></i> Add manually</button>`;
  }
  if (r.status === 'READY') {
    actions += `<div class="w-full rounded-xl bg-emerald-50 border border-emerald-200 p-3">
        <p class="text-emerald-800 font-bold text-sm mb-2"><i class="fas fa-circle-check mr-1"></i> Everything is prepared. Release it when it leaves the warehouse.</p>
        <div class="flex flex-wrap gap-2">
          <input id="ord-released-to" type="text" maxlength="150" placeholder="Received by (technician / driver)" value="${r.technician_name ? esc(r.technician_name) : ''}" class="flex-1 min-w-[180px] rounded-lg border border-emerald-200 text-sm px-3 py-2">
          <button type="button" id="ord-release" class="st-primary-action rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm px-4 py-2"><i class="fas fa-truck-fast mr-1"></i> Release</button>
        </div>
      </div>`;
  }
  actions += `<button type="button" id="ord-print" class="rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-sm px-4 py-2.5"><i class="fas fa-print mr-1"></i> Print slip</button>`;

  document.getElementById('order-body').innerHTML = `
    <div class="grid sm:grid-cols-2 gap-x-6 gap-y-2 mb-4">
      ${info.map(([k, v]) => `<div><p class="text-[11px] text-slate-400 font-semibold uppercase">${k}</p><p class="text-slate-700">${v}</p></div>`).join('')}
    </div>
    <h4 class="font-bold text-slate-800 mb-2">Items needed</h4>
    <div class="mb-4">${orderLinesHtml(d.lines)}</div>
    <div class="flex flex-wrap gap-2 mb-4">${actions}</div>
    <div id="ord-manual" class="hidden rounded-xl border border-slate-200 p-3 mb-4">
      <div class="flex flex-wrap gap-2 items-end">
        <div class="flex-1 min-w-[200px]"><label class="block text-xs font-semibold text-slate-500 mb-1">Item</label>
          <select id="ord-manual-item" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"><option>Loading…</option></select></div>
        <div class="w-24"><label class="block text-xs font-semibold text-slate-500 mb-1">Qty</label>
          <input id="ord-manual-qty" type="number" min="1" value="1" class="w-full rounded-lg border border-slate-200 text-sm px-3 py-2"></div>
        <button type="button" id="ord-manual-add" class="st-primary-action rounded-lg bg-suntrackOrange hover:bg-orange-600 text-white font-bold text-sm px-4 py-2">Add</button>
      </div>
    </div>
    <h4 class="font-bold text-slate-800 mb-2">Prepared items</h4>
    <div class="mb-4">${picked}</div>
    <details><summary class="font-bold text-slate-800 cursor-pointer mb-2">Activity log</summary>${history}</details>`;

  document.getElementById('ord-scan')?.addEventListener('click', () => {
    document.getElementById('order-modal').classList.add('hidden');
    goToTab('scanner');
    setScanMode('prepare', r.id);
  });
  document.getElementById('ord-manual-toggle')?.addEventListener('click', () => {
    const box = document.getElementById('ord-manual');
    box.classList.toggle('hidden');
    if (!box.classList.contains('hidden')) fillManualPicker(d);
  });
  document.getElementById('ord-manual-add')?.addEventListener('click', (e) => {
    const invId = document.getElementById('ord-manual-item').value;
    const qty = Number(document.getElementById('ord-manual-qty').value);
    if (!invId) { toast('Choose an item.', true); return; }
    if (!qty || qty < 1) { toast('Enter a quantity of at least 1.', true); return; }
    withButtonLock(e.currentTarget, 'Adding…', () => pickIntoOrder(r.id, { inventory_id: Number(invId), quantity: qty }));
  });
  document.getElementById('ord-release')?.addEventListener('click', (e) => {
    const to = document.getElementById('ord-released-to').value.trim();
    if (!confirm(`Release ${r.request_code}${to ? ' to ' + to : ''}? This closes the order.`)) return;
    withButtonLock(e.currentTarget, 'Releasing…', async () => {
      const json = await postJson('../api/material_requests/release.php', { request_id: r.id, released_to: to });
      toast(json.message, !json.success);
      if (json.success) { renderOrder(json.data.detail); afterOrderChange(); }
    });
  });
  document.getElementById('ord-print').addEventListener('click', () => printOrderSlip(d));
  document.querySelectorAll('[data-unpick]').forEach(b => b.addEventListener('click', () => {
    if (!confirm(`Remove 1 × ${b.dataset.name} from ${r.request_code} and put it back in stock?`)) return;
    withButtonLock(b, '', async () => {
      const json = await postJson('../api/material_requests/unpick.php', { request_id: r.id, inventory_id: Number(b.dataset.unpick), quantity: 1 });
      toast(json.message, !json.success);
      if (json.success) { renderOrder(json.data.detail); afterOrderChange(json.data.detail); }
    });
  }));
}
document.getElementById('order-close').addEventListener('click', () => document.getElementById('order-modal').classList.add('hidden'));

/** Only offer items whose category still has something left to prepare. */
async function fillManualPicker(d) {
  const select = document.getElementById('ord-manual-item');
  if (!INV_PICKER_CACHE) {
    const json = await getJson('../api/inventory/list.php');
    INV_PICKER_CACHE = json.success ? json.data : [];
  }
  const needed = new Set(d.lines.filter(l => Number(l.qty_prepared) < Number(l.qty_required)).map(l => l.category_name));
  const items = INV_PICKER_CACHE.filter(i => needed.has(i.category_name) && Number(i.quantity) > 0 && i.status !== 'DISCONTINUED');
  select.innerHTML = items.length
    ? '<option value="">— Choose an item —</option>' + items.map(i => `<option value="${i.id}">${esc(i.item_name)} (${esc(i.sku)}) — ${i.quantity} in stock</option>`).join('')
    : '<option value="">No stock available for the remaining items</option>';
}

/**
 * Scan / add an item into an order. Shared by the order modal's manual add
 * and the scanner's Prepare mode. Returns the API response.
 */
async function pickIntoOrder(requestId, payload) {
  const json = await postJson('../api/material_requests/pick.php', Object.assign({ request_id: requestId }, payload));
  scanFeedback(json.success);
  toast(json.message, !json.success);
  if (json.success) {
    INV_PICKER_CACHE = null; // quantities changed
    if (OPEN_ORDER && String(OPEN_ORDER.request.id) === String(requestId) && !document.getElementById('order-modal').classList.contains('hidden')) {
      renderOrder(json.data.detail);
    }
    afterOrderChange(json.data.detail);
  }
  return json;
}

/** Keep every view of orders in step after a change made on this screen. */
function afterOrderChange(detail) {
  if (detail && PREPARE_ORDER_ID && String(detail.request.id) === String(PREPARE_ORDER_ID)) renderPrepareProgress(detail);
  loadDashOrders();
  if (CURRENT_TAB === 'orders') loadOrders();
  if (CURRENT_TAB === 'inventory') loadInventory();
}

/** A printable pick / release slip — the paper copy that travels with the goods. */
function printOrderSlip(d) {
  const r = d.request;
  const rows = d.picked.map(p => `<tr><td>${esc(p.sku)}</td><td>${esc(p.item_name)}</td><td>${esc(p.category_name)}</td><td style="text-align:right">${p.quantity}</td></tr>`).join('')
    || '<tr><td colspan="4">No items prepared yet.</td></tr>';
  const lines = d.lines.map(l => `<tr><td>${esc(l.category_name)}</td><td style="text-align:right">${l.qty_required}</td><td style="text-align:right">${Math.min(l.qty_prepared, l.qty_required)}</td></tr>`).join('');
  const w = window.open('', '_blank', 'width=800,height=900');
  if (!w) { toast('Allow pop-ups to print the slip.', true); return; }
  w.document.write(`<!DOCTYPE html><html><head><title>${esc(r.request_code)}</title>
    <style>body{font-family:Arial,sans-serif;font-size:13px;margin:32px;color:#111}h1{font-size:20px;margin:0}
    table{width:100%;border-collapse:collapse;margin:8px 0 18px}th,td{border:1px solid #ccc;padding:6px;text-align:left}
    th{background:#f3f4f6}.muted{color:#666}.sig{display:flex;gap:40px;margin-top:48px}.sig div{flex:1;border-top:1px solid #111;padding-top:4px}</style></head><body>
    <h1>SunTrack — Client Order ${esc(r.request_code)}</h1>
    <p class="muted">Status: ${esc(r.status)} · Printed ${esc(new Date().toLocaleString('en-PH'))}</p>
    <p><b>Client:</b> ${esc(r.client_name)} (${esc(r.client_code)})<br><b>Deliver to:</b> ${esc([r.client_address, r.client_city, r.client_province].filter(Boolean).join(', '))}<br>
    <b>Phone:</b> ${esc(r.client_phone)}<br><b>Project / Job:</b> ${esc([r.project_code, r.job_code].filter(Boolean).join(' · '))}<br>
    <b>Needed by:</b> ${esc(r.needed_by)}</p>
    <h3>Required</h3><table><tr><th>Category</th><th style="text-align:right">Required</th><th style="text-align:right">Prepared</th></tr>${lines}</table>
    <h3>Items prepared</h3><table><tr><th>SKU</th><th>Item</th><th>Category</th><th style="text-align:right">Qty</th></tr>${rows}</table>
    ${r.status === 'RELEASED' ? `<p><b>Released:</b> ${esc(r.released_at)} by ${esc(r.released_by_name)} to ${esc(r.released_to)}</p>` : ''}
    <div class="sig"><div>Prepared by (Warehouse)</div><div>Received by</div><div>Date</div></div>
    <script>window.onload=function(){window.print();}<\/script></body></html>`);
  w.document.close();
}

/* =========================================================================
   NOTIFICATIONS module
   ========================================================================= */

async function loadNotifications() {
  const box = document.getElementById('notif-list');
  box.innerHTML = '<p class="text-slate-400 text-sm p-6 text-center">Loading...</p>';
  const json = await getJson('../api/notifications/list.php?limit=100');
  if (!json.success) { box.innerHTML = `<p class="text-red-500 text-sm p-6 text-center">${esc(json.message)}</p>`; return; }
  setBadge('notif-badge', json.data.unread_count);
  const rows = json.data.rows;
  box.innerHTML = rows.length ? rows.map(n => {
    const unread = !Number(n.is_read);
    const isOrder = n.related_table === 'material_requests' && n.related_id;
    return `<div class="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 sm:gap-3 p-4 ${unread ? 'bg-orange-50/60' : ''}">
      <div class="min-w-0">
        <p class="text-sm ${unread ? 'font-semibold text-slate-800' : 'text-slate-600'}">${esc(n.message)}</p>
        <p class="text-xs text-slate-400 mt-1">${fmtDate(n.created_at)}</p>
      </div>
      <div class="flex items-center gap-4 shrink-0">
        ${isOrder ? `<button type="button" class="text-xs font-bold text-suntrackOrange" data-notif-order="${n.related_id}" data-notif-id="${n.id}">Open order</button>` : ''}
        ${unread ? `<button type="button" class="text-xs font-bold text-slate-500" data-notif-read="${n.id}">Mark read</button>` : ''}
      </div>
    </div>`;
  }).join('') : '<p class="text-slate-400 text-sm p-6 text-center">No notifications yet.</p>';

  box.querySelectorAll('[data-notif-read]').forEach(b => b.addEventListener('click', async () => {
    await postJson('../api/notifications/mark_read.php', { id: Number(b.dataset.notifRead) });
    loadNotifications();
  }));
  box.querySelectorAll('[data-notif-order]').forEach(b => b.addEventListener('click', async () => {
    postJson('../api/notifications/mark_read.php', { id: Number(b.dataset.notifId) }).then(loadNotifications);
    openOrder(b.dataset.notifOrder);
  }));
}
document.getElementById('notif-mark-all').addEventListener('click', async () => {
  await postJson('../api/notifications/mark_read.php', { all: true });
  loadNotifications();
});

/* =========================================================================
   REPORTS module
   ========================================================================= */

let reportsReady = false;
let lastReportRows = [];
let lastReportType = 'movements';

async function initReports() {
  if (reportsReady) return;
  reportsReady = true;

  // Populate the filter dropdowns from the same endpoints the rest of the
  // portal uses — no separate lookup APIs.
  try {
    const [invRes, jobRes] = await Promise.all([
      stFetch('../api/inventory/list.php'),
      fetch('../api/jobs/active.php')
    ]);
    const inv = await invRes.json();
    const jobs = await jobRes.json();

    if (inv.success) {
      const items = inv.data.items || inv.data || [];
      const cats = new Map();
      items.forEach(i => { if (i.category_id) cats.set(i.category_id, i.category_name); });
      document.getElementById('rp-cat').innerHTML =
        '<option value="">All categories</option>' +
        [...cats].map(([id, n]) => `<option value="${id}">${esc(n)}</option>`).join('');
      document.getElementById('rp-item').innerHTML =
        '<option value="">All items</option>' +
        items.map(i => `<option value="${i.id}">${esc(i.item_name)}</option>`).join('');
    }
    if (jobs.success) {
      const list = jobs.data.jobs || jobs.data || [];
      document.getElementById('rp-job').innerHTML =
        '<option value="">All jobs</option>' +
        list.map(j => `<option value="${j.id}">${esc(j.job_code)}</option>`).join('');
    }
  } catch (e) { /* filters stay as "All" — the report still runs */ }

  document.getElementById('rp-run').addEventListener('click', (e) => runReport(e.currentTarget));
  document.getElementById('rp-export').addEventListener('click', (e) => exportReport(e.currentTarget));
  document.getElementById('rp-clear').addEventListener('click', () => {
    ['rp-from','rp-to','rp-cat','rp-mtype','rp-item','rp-job'].forEach(id => document.getElementById(id).value = '');
    runReport();
  });
  document.getElementById('rp-report').addEventListener('change', () => runReport());

  runReport();
}

function reportQuery() {
  const p = new URLSearchParams();
  p.set('report', document.getElementById('rp-report').value);
  const map = { date_from:'rp-from', date_to:'rp-to', category:'rp-cat', movement_type:'rp-mtype', inventory_id:'rp-item', job_id:'rp-job' };
  Object.entries(map).forEach(([key, id]) => {
    const v = document.getElementById(id).value;
    if (v) p.set(key, v);
  });
  return p;
}

const MOVEMENT_REPORTS = ['movements','issued','received','returned'];

async function runReport(btn) {
  const body = document.getElementById('rp-body');
  body.innerHTML = '<tr><td colspan="10" class="py-6 text-center text-slate-400">Loading…</td></tr>';

  const run = async () => {
    try {
      const res = await fetch('../api/warehouse/reports.php?' + reportQuery().toString());
      const json = await res.json();
      if (!json.success) {
        body.innerHTML = `<tr><td colspan="10" class="py-6 text-center text-red-500">${esc(json.message)}</td></tr>`;
        return;
      }
      renderReport(json.data);
    } catch (err) {
      body.innerHTML = '<tr><td colspan="10" class="py-6 text-center text-slate-400">Could not load the report.</td></tr>';
    }
  };

  if (btn) await withButtonLock(btn, 'Running…', run); else await run();
}

function renderReport(d) {
  const s = d.summary;
  document.getElementById('rp-recv').textContent   = s.total_received;
  document.getElementById('rp-issued').textContent = s.total_issued;
  document.getElementById('rp-ret').textContent    = s.total_returned;
  document.getElementById('rp-stock').textContent  = Number(s.current_stock).toLocaleString();
  document.getElementById('rp-low').textContent    = s.low_stock_items;
  document.getElementById('rp-out').textContent    = s.out_of_stock_items;
  document.getElementById('rp-count').textContent  = `(${s.rows_returned} row${s.rows_returned === 1 ? '' : 's'})`;

  const trunc = document.getElementById('rp-truncated');
  trunc.classList.toggle('hidden', !s.truncated);
  if (s.truncated) trunc.textContent = `Showing the first ${s.row_limit} rows. Narrow the dates or filters to see the rest.`;

  lastReportRows = d.rows || [];
  lastReportType = d.report;

  const head = document.getElementById('rp-head');
  const body = document.getElementById('rp-body');
  const isMovement = MOVEMENT_REPORTS.includes(d.report);

  if (!lastReportRows.length) {
    head.innerHTML = '';
    body.innerHTML = '<tr><td class="py-8 text-center text-slate-400">No warehouse activity matches your filters.</td></tr>';
    return;
  }

  if (d.report === 'orders') {
    const pr = (p, q) => `<span class="${Number(p) >= Number(q) ? 'text-emerald-600 font-bold' : ''}">${p}/${q}</span>`;
    head.innerHTML = `<tr class="text-left text-slate-400 text-xs uppercase">
      <th class="py-2">Date</th><th>Order</th><th>Client</th><th>Project / Job</th><th>Status</th>
      <th>Panels</th><th>Inverters</th><th>Batteries</th><th>Needed By</th><th>Released</th></tr>`;
    body.innerHTML = lastReportRows.map(r => `<tr class="border-t border-slate-100">
      <td class="py-2 text-slate-400 text-xs whitespace-nowrap">${fmtDate(r.created_at)}</td>
      <td class="text-xs font-mono text-slate-500">${esc(r.request_code)}</td>
      <td class="font-semibold text-slate-700">${esc(r.client_name)}</td>
      <td class="text-slate-500">${esc([r.project_code, r.job_code].filter(Boolean).join(' · '))}</td>
      <td>${orderBadge(r.status)}</td>
      <td>${pr(r.panels_prepared, r.panels_required)}</td>
      <td>${pr(r.inverters_prepared, r.inverters_required)}</td>
      <td>${pr(r.batteries_prepared, r.batteries_required)}</td>
      <td class="text-slate-500">${esc(r.needed_by)}</td>
      <td class="text-slate-500 text-xs">${r.released_at ? fmtDate(r.released_at) + (r.released_to ? ' → ' + esc(r.released_to) : '') : '—'}</td></tr>`).join('');
    return;
  }

  if (isMovement) {
    head.innerHTML = `<tr class="text-left text-slate-400 text-xs uppercase">
      <th class="py-2">Date</th><th>Movement Code</th><th>Item</th><th>SKU</th><th>Category</th>
      <th>Movement</th><th>Qty</th><th>Job / Order</th><th>Client</th><th>User</th></tr>`;
    body.innerHTML = lastReportRows.map(r => `<tr class="border-t border-slate-100">
      <td class="py-2 text-slate-400 text-xs whitespace-nowrap">${fmtDate(r.created_at)}</td>
      <td class="text-xs font-mono text-slate-500">${esc(r.movement_code)}</td>
      <td class="font-semibold text-slate-700">${esc(r.item_name)}</td>
      <td class="text-xs text-slate-500">${esc(r.sku)}</td>
      <td class="text-slate-500">${esc(r.category_name)}</td>
      <td>${moveBadge(r.movement_type)}</td>
      <td class="font-bold">${r.quantity}</td>
      <td class="text-slate-500">${esc([r.job_code, r.request_code].filter(Boolean).join(' · '))}</td>
      <td class="text-slate-500">${esc(r.client_name)}</td>
      <td class="text-slate-500">${esc(r.recorded_by_name)}</td></tr>`).join('');
  } else {
    head.innerHTML = `<tr class="text-left text-slate-400 text-xs uppercase">
      <th class="py-2">Item</th><th>SKU</th><th>Category</th><th>Brand</th><th>Model</th>
      <th>Qty</th><th>Location</th><th>Status</th></tr>`;
    body.innerHTML = lastReportRows.map(r => `<tr class="border-t border-slate-100">
      <td class="py-2 font-semibold text-slate-700">${esc(r.item_name)}</td>
      <td class="text-xs text-slate-500">${esc(r.sku)}</td>
      <td class="text-slate-500">${esc(r.category_name)}</td>
      <td class="text-slate-500">${esc(r.brand)}</td>
      <td class="text-slate-500">${esc(r.model)}</td>
      <td class="font-bold">${r.quantity}</td>
      <td class="text-slate-500">${esc(r.warehouse_location)}</td>
      <td>${moveBadge(r.status)}</td></tr>`).join('');
  }
}

/**
 * CSV export, built from the rows already on screen so that what is exported
 * is exactly what the user filtered. No user or authentication fields are
 * included — only the person's display name against a movement.
 */
async function exportReport(btn) {
  await withButtonLock(btn, 'Exporting…', async () => {
    if (!lastReportRows.length) {
      alert('There is nothing to export. Adjust your filters and run the report first.');
      return;
    }

    const isMovement = MOVEMENT_REPORTS.includes(lastReportType);
    const cols = lastReportType === 'orders'
      ? [['created_at','Date'],['request_code','Order'],['client_code','Client Code'],['client_name','Client'],
         ['project_code','Project'],['job_code','Job'],['status','Status'],
         ['panels_required','Panels Required'],['panels_prepared','Panels Prepared'],
         ['inverters_required','Inverters Required'],['inverters_prepared','Inverters Prepared'],
         ['batteries_required','Batteries Required'],['batteries_prepared','Batteries Prepared'],
         ['needed_by','Needed By'],['requested_by_name','Requested By'],['ready_at','Ready At'],
         ['released_at','Released At'],['released_by_name','Released By'],['released_to','Released To']]
      : isMovement
      ? [['created_at','Date'],['movement_code','Movement Code'],['item_name','Item'],['sku','SKU'],
         ['category_name','Category'],['movement_type','Movement'],['quantity','Quantity'],
         ['job_code','Job'],['request_code','Order'],['client_name','Client'],['recorded_by_name','User']]
      : [['item_name','Item'],['sku','SKU'],['category_name','Category'],['brand','Brand'],['model','Model'],
         ['quantity','Quantity'],['unit_cost','Unit Cost'],
         ['warehouse_location','Location'],['status','Status']];

    // Guard against CSV formula injection: a value starting with = + - or @
    // is executed by Excel when the file is opened.
    const cell = (v) => {
      let str = (v === null || v === undefined) ? '' : String(v);
      if (/^[=+\-@\t\r]/.test(str)) str = "'" + str;
      return '"' + str.replace(/"/g, '""') + '"';
    };

    const lines = [cols.map(c => cell(c[1])).join(',')];
    lastReportRows.forEach(r => lines.push(cols.map(c => cell(r[c[0]])).join(',')));

    // BOM so Excel reads UTF-8 correctly.
    const blob = new Blob(['\uFEFF' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `suntrack-${lastReportType}-${new Date().toISOString().slice(0,10)}.csv`;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
  });
}

/* =========================================================================
   SETTINGS module
   ========================================================================= */

async function loadProfile() {
  try {
    const res = await fetch('../api/account/profile.php');
    const json = await res.json();
    if (!json.success) return;
    const u = json.data;
    document.getElementById('pf-name').value  = u.full_name || '';
    document.getElementById('pf-email').value = u.email || '';
    document.getElementById('pf-phone').value = u.phone || '';
    document.getElementById('pf-role').value  = u.role_name || '';
    document.getElementById('pf-status').textContent = u.status || '—';
    document.getElementById('pf-last').textContent   = fmtDate(u.last_login);
    document.getElementById('pf-since').textContent  = fmtDate(u.member_since);
  } catch (e) {
    showMsg(document.getElementById('pf-msg'), 'Could not load your profile.', false);
  }
}

document.getElementById('pf-save').addEventListener('click', (e) => {
  const btn = e.currentTarget;
  const msg = document.getElementById('pf-msg');
  withButtonLock(btn, 'Saving…', async () => {
    try {
      const res = await fetch('../api/account/profile.php', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'update_profile',
          full_name: document.getElementById('pf-name').value.trim(),
          email: document.getElementById('pf-email').value.trim(),
          phone: document.getElementById('pf-phone').value.trim(),
          csrf_token: CSRF_TOKEN
        })
      });
      const json = await res.json();
      showMsg(msg, json.message, json.success);
    } catch (err) {
      showMsg(msg, 'Could not save your settings. Please try again.', false);
    }
  });
});

document.getElementById('pw-save').addEventListener('click', (e) => {
  const btn = e.currentTarget;
  const msg = document.getElementById('pw-msg');
  const cur = document.getElementById('pw-current').value;
  const nw  = document.getElementById('pw-new').value;
  const cf  = document.getElementById('pw-confirm').value;

  if (!cur || !nw || !cf) { showMsg(msg, 'Please fill in all three password fields.', false); return; }
  if (nw !== cf)          { showMsg(msg, 'The new passwords do not match.', false); return; }
  if (nw.length < 8)      { showMsg(msg, 'Your new password must be at least 8 characters.', false); return; }

  withButtonLock(btn, 'Updating…', async () => {
    try {
      const res = await fetch('../api/account/profile.php', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'change_password',
          current_password: cur, new_password: nw, confirm_password: cf,
          csrf_token: CSRF_TOKEN
        })
      });
      const json = await res.json();
      showMsg(msg, json.message, json.success);
      if (json.success) ['pw-current','pw-new','pw-confirm'].forEach(id => document.getElementById(id).value = '');
    } catch (err) {
      showMsg(msg, 'Could not update your password. Please try again.', false);
    }
  });
});

function peso(n) { return '₱' + Number(n).toLocaleString('en-PH', {maximumFractionDigits: 0}); }

async function loadDashboard() {
  try {
    const res = await fetch('../api/dashboard/warehouse.php');
    const json = await res.json();
    if (!json.success) { document.getElementById('dash-loading').textContent = json.message; return; }
    const d = json.data;
    document.getElementById('kpi-skus').textContent = d.kpis.active_skus;
    document.getElementById('kpi-qty').textContent = d.kpis.total_quantity;
    document.getElementById('kpi-low').textContent = d.kpis.low_stock;
    document.getElementById('kpi-out').textContent = d.kpis.out_of_stock;
    document.getElementById('by-category').innerHTML = d.by_category.map(c =>
      `<p class="flex justify-between"><span>${esc(c.category_name)}</span><span class="font-semibold">${c.total_qty} units · ${c.sku_count} SKUs</span></p>`).join('');
    document.getElementById('stock-alerts').innerHTML = d.low_stock_list.length
      ? d.low_stock_list.map(i => `<p class="flex justify-between"><span>${esc(i.item_name)}</span><span class="badge ${i.status==='OUT_OF_STOCK'?'bg-red-100 text-red-700':'bg-amber-100 text-amber-700'}">${i.quantity} left</span></p>`).join('')
      : '<p class="text-slate-400">No alerts — stock levels healthy.</p>';
    document.getElementById('recent-activity').innerHTML = d.recent_activity.map(m =>
      `<p class="py-2 flex justify-between"><span>${esc(m.movement_code)} — ${esc(m.item_name)}</span><span class="font-semibold">${m.movement_type} ${m.quantity}</span></p>`).join('');
    document.getElementById('dash-loading').classList.add('hidden');
    document.getElementById('dash-content').classList.remove('hidden');
  } catch (err) {
    document.getElementById('dash-loading').textContent = 'Failed to load dashboard.';
  }
}

const statusColor = { ACTIVE:'bg-emerald-100 text-emerald-700', LOW_STOCK:'bg-amber-100 text-amber-700', OUT_OF_STOCK:'bg-red-100 text-red-700', DISCONTINUED:'bg-slate-100 text-slate-500' };

async function loadInventory() {
  const tbody = document.getElementById('inv-table-body');
  tbody.innerHTML = `<tr><td colspan="8" class="text-slate-400 text-center py-6">Loading...</td></tr>`;
  const params = new URLSearchParams();
  const search = document.getElementById('inv-search').value;
  const cat = document.getElementById('inv-filter-category').value;
  const status = document.getElementById('inv-filter-status').value;
  if (search) params.set('search', search);
  if (cat) params.set('category', cat);
  if (status) params.set('status', status);

  try {
    const res = await stFetch('../api/inventory/list.php?' + params.toString());
    const json = await res.json();
    if (!json.success) { tbody.innerHTML = `<tr><td colspan="8" class="text-red-500 py-6 text-center">${esc(json.message)}</td></tr>`; INV_BAR.setCount(); return; }
    const items = json.data;
    INV_BAR.setCount(items.length);
    document.getElementById('inv-empty').classList.toggle('hidden', items.length > 0);
    tbody.innerHTML = items.map(i => `
      <tr>
        <td class="font-mono text-xs">${esc(i.sku)}${i.qr_code ? '' : '<div class="text-[10px] font-sans font-bold text-amber-600">No QR yet</div>'}</td>
        <td class="font-semibold">${esc(i.item_name)}<div class="text-xs text-slate-400">${esc(`${i.brand ?? ''} ${i.model ?? ''}`.trim())}${i.tracking_mode === 'SERIAL' ? ' <span class="badge bg-violet-50 text-violet-700">Per-unit QR</span>' : ''}</div></td>
        <td>${esc(i.category_name)}</td>
        <td>${i.quantity}${Number(i.quarantine_qty) > 0 ? `<div class="text-[11px] font-bold text-amber-600" title="Returned damaged / to inspect — not available">+${i.quarantine_qty} held</div>` : ''}</td>
        <td>${peso(i.unit_cost)}</td>
        <td>${esc(i.warehouse_location)}</td>
        <td><span class="badge ${statusColor[i.status] ?? 'bg-slate-100 text-slate-600'}">${esc(i.status.replace('_',' '))}</span></td>
        <td class="whitespace-nowrap">
          <button class="icon-btn view-qr" data-id="${i.id}" title="QR code &amp; label"><i class="fas fa-qrcode"></i></button>
          <button class="icon-btn edit-item" data-id="${i.id}" title="Edit"><i class="fas fa-pen"></i></button>
          <button class="icon-btn move-receive" data-id="${i.id}" data-name="${esc(i.item_name)}" title="Receive"><i class="fas fa-truck-ramp-box"></i></button>
          <button class="icon-btn move-issue" data-id="${i.id}" data-name="${esc(i.item_name)}" data-cat="${esc(i.category_name)}" title="Stock out (client order or job)"><i class="fas fa-hand-holding"></i></button>
          <button class="icon-btn move-return" data-id="${i.id}" data-name="${esc(i.item_name)}" title="Return"><i class="fas fa-rotate-left"></i></button>
          <button class="icon-btn view-history" data-id="${i.id}" data-name="${esc(i.item_name)}" title="History"><i class="fas fa-clock-rotate-left"></i></button>
        </td>
      </tr>`).join('');

    window.__inventoryCache = items;
    document.querySelectorAll('.view-qr').forEach(b => b.addEventListener('click', () => openQrPanel(b.dataset.id)));
    document.querySelectorAll('.edit-item').forEach(b => b.addEventListener('click', () => openEditModal(b.dataset.id)));
    document.querySelectorAll('.move-receive').forEach(b => b.addEventListener('click', () => openMoveModal('receive', b.dataset.id, b.dataset.name)));
    document.querySelectorAll('.move-issue').forEach(b => b.addEventListener('click', () => openMoveModal('issue', b.dataset.id, b.dataset.name, b.dataset.cat)));
    document.querySelectorAll('.move-return').forEach(b => b.addEventListener('click', () => openMoveModal('return', b.dataset.id, b.dataset.name)));
    document.querySelectorAll('.view-history').forEach(b => b.addEventListener('click', () => openHistoryModal(b.dataset.id, b.dataset.name)));
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="8" class="text-red-500 py-6 text-center">Failed to load inventory.</td></tr>`;
  }
}
document.getElementById('inv-filter-btn').addEventListener('click', loadInventory);
const INV_BAR = SunTrackFilters.bind({ search: 'inv-search', fields: ['inv-filter-category', 'inv-filter-status'], anchor: 'inv-filter-btn', onChange: loadInventory });

// --- Add / Edit item modal ---
function openAddModal() {
  document.getElementById('item-modal-title').textContent = 'Add Inventory Item';
  document.getElementById('item-id').value = '';
  ['item-name','item-brand','item-model','item-serial','item-location'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('item-category').value = 'Solar Panel';
  document.getElementById('item-qty').value = 0;
  document.getElementById('item-cost').value = 0;
  document.getElementById('item-qty').disabled = false;
  document.getElementById('item-tracking').value = 'PRODUCT';
  document.getElementById('item-serials').value = '';
  document.getElementById('item-tracking-wrap').classList.remove('hidden');
  syncItemTracking();
  ITEM_REQUEST_KEY = SunTrackQR.requestKey();
  document.getElementById('item-modal-error').classList.add('hidden');
  document.getElementById('item-modal').classList.remove('hidden');
}
let ITEM_REQUEST_KEY = null;
function serialList(text) { return String(text).split(/[\r\n,;]+/).map(s => s.trim()).filter(Boolean); }
// Per-unit tracking: the quantity is the number of serials entered.
function syncItemTracking() {
  const serial = document.getElementById('item-tracking').value === 'SERIAL' && !document.getElementById('item-tracking-wrap').classList.contains('hidden');
  document.getElementById('item-serials-wrap').classList.toggle('hidden', !serial);
  document.getElementById('item-qty-wrap').classList.toggle('hidden', serial);
  const n = serialList(document.getElementById('item-serials').value).length;
  document.getElementById('item-serials-count').textContent = serial ? `(${n} unit${n === 1 ? '' : 's'})` : '';
}
document.getElementById('item-tracking').addEventListener('change', syncItemTracking);
document.getElementById('item-serials').addEventListener('input', syncItemTracking);

function openQrPanel(id) {
  SunTrackQR.openPanel({ base: <?= json_encode(APP_BASE_URL) ?>, csrf: CSRF_TOKEN, id, onChanged: () => { loadInventory(); loadDashboard(); } });
}
function openEditModal(id) {
  const item = window.__inventoryCache.find(i => String(i.id) === String(id));
  if (!item) return;
  document.getElementById('item-modal-title').textContent = 'Edit Inventory Item';
  document.getElementById('item-id').value = item.id;
  document.getElementById('item-name').value = item.item_name;
  document.getElementById('item-category').value = item.category_name;
  document.getElementById('item-brand').value = item.brand ?? '';
  document.getElementById('item-model').value = item.model ?? '';
  document.getElementById('item-serial').value = item.serial_number ?? '';
  document.getElementById('item-qty').value = item.quantity;
  document.getElementById('item-qty').disabled = true; // quantity only changes via receive/issue/return
  document.getElementById('item-cost').value = item.unit_cost;
  document.getElementById('item-location').value = item.warehouse_location ?? '';
  // Tracking changes go through the QR panel (it needs every unit's serial).
  document.getElementById('item-tracking-wrap').classList.add('hidden');
  syncItemTracking();
  document.getElementById('item-modal-error').classList.add('hidden');
  document.getElementById('item-modal').classList.remove('hidden');
}
document.getElementById('btn-add-item').addEventListener('click', openAddModal);
document.getElementById('item-cancel').addEventListener('click', () => document.getElementById('item-modal').classList.add('hidden'));

document.getElementById('item-save').addEventListener('click', async () => {
  const errBox = document.getElementById('item-modal-error');
  errBox.classList.add('hidden');
  const id = document.getElementById('item-id').value;
  const isEdit = !!id;

  const payload = {
    item_name: document.getElementById('item-name').value.trim(),
    category: document.getElementById('item-category').value,
    brand: document.getElementById('item-brand').value.trim(),
    model: document.getElementById('item-model').value.trim(),
    serial_number: document.getElementById('item-serial').value.trim(),
    unit_cost: document.getElementById('item-cost').value,
    warehouse_location: document.getElementById('item-location').value.trim(),
    csrf_token: CSRF_TOKEN
  };
  if (!isEdit) {
    payload.tracking_mode = document.getElementById('item-tracking').value;
    if (payload.tracking_mode === 'SERIAL') payload.serials = serialList(document.getElementById('item-serials').value);
    else payload.quantity = document.getElementById('item-qty').value;
    payload.request_key = ITEM_REQUEST_KEY; // a double tap creates one item, not two
  }
  if (isEdit) payload.id = id;

  if (!payload.item_name) { errBox.textContent = 'Item name is required.'; errBox.classList.remove('hidden'); return; }

  const btn = document.getElementById('item-save');
  await withButtonLock(btn, 'Saving…', async () => {
    try {
      const res = await fetch('../api/inventory/' + (isEdit ? 'update.php' : 'create.php'), {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
      });
      const json = await res.json();
      if (!json.success) { errBox.textContent = json.message; errBox.classList.remove('hidden'); return; }
      document.getElementById('item-modal').classList.add('hidden');
      toast(json.message, false);
      loadInventory();
      // A new product goes straight to its QR code, ready to print and stick on.
      if (!isEdit && json.data && json.data.id) openQrPanel(json.data.id);
    } catch (err) {
      errBox.textContent = 'Network error. Please try again.';
      errBox.classList.remove('hidden');
    }
  });
});

// --- Receive / Issue / Return modal ---
/**
 * $categoryName (optional) narrows Stock Out's client-order choices to orders
 * that still need that kind of item. The server re-checks it either way.
 *
 * Target values are prefixed — "job:12" or "mr:3" — so one select can offer
 * both jobs and client orders without the two id spaces colliding.
 */
/*
 * $preselectUnit (optional) is a scanned unit label: for per-unit items it is
 * ticked already, so scan → confirm is one tap.
 */
let MOVE = null; // { mode, invId, tracking, requestKey }
async function openMoveModal(mode, invId, itemName, categoryName, preselectUnit) {
  moveMode = mode;
  moveInvName = itemName;
  MOVE = null;
  const errBox = document.getElementById('move-modal-error');
  document.getElementById('move-inv-id').value = invId;
  document.getElementById('move-qty').value = 1;
  errBox.classList.add('hidden');
  document.getElementById('move-modal-item').textContent = itemName;
  document.getElementById('move-modal-title').textContent = mode === 'receive' ? 'Restock — Receive Stock' : mode === 'issue' ? 'Stock Out — to Client Order or Job' : 'Return Stock from Job';
  document.getElementById('move-job-label').textContent = mode === 'issue' ? 'Send to' : 'Job';
  ['move-units-wrap', 'move-serials-wrap', 'move-cond-wrap', 'move-ref-wrap', 'move-job-wrap'].forEach(id => document.getElementById(id).classList.add('hidden'));
  document.getElementById('move-qty-wrap').classList.remove('hidden');
  document.getElementById('move-serials').value = '';
  document.getElementById('move-ref').value = '';
  document.getElementById('move-condition').value = 'GOOD';
  document.getElementById('move-job-select').innerHTML = '';
  document.getElementById('move-confirm').disabled = true; // until the item has loaded
  document.getElementById('move-modal').classList.remove('hidden');

  // Fresh from the server: tracking mode, live quantity, and the units.
  const info = await getJson('../api/inventory/qr.php?id=' + encodeURIComponent(invId));
  if (!info.success) { errBox.textContent = info.message; errBox.classList.remove('hidden'); return; }
  const it = info.data.item;
  const serial = it.tracking_mode === 'SERIAL';
  MOVE = { mode, invId, tracking: it.tracking_mode, requestKey: SunTrackQR.requestKey() };
  document.getElementById('move-modal-item').textContent = `${it.item_name} · ${it.sku} · ${it.quantity} available`
    + (it.quarantine_qty ? ` · ${it.quarantine_qty} in quarantine` : '');

  if (mode === 'receive') {
    document.getElementById('move-ref-wrap').classList.remove('hidden');
    if (serial) {
      document.getElementById('move-serials-wrap').classList.remove('hidden');
      document.getElementById('move-qty-wrap').classList.add('hidden');
      syncMoveSerials();
    }
  }
  if (mode === 'return') document.getElementById('move-cond-wrap').classList.remove('hidden');

  if (serial && mode !== 'receive') {
    document.getElementById('move-qty-wrap').classList.add('hidden');
    document.getElementById('move-units-wrap').classList.remove('hidden');
    const wanted = mode === 'issue' ? 'IN_STOCK' : 'ISSUED';
    const list = info.data.units.filter(u => u.status === wanted);
    const pre = String(preselectUnit || '').toUpperCase();
    document.getElementById('move-units').innerHTML = list.length
      ? list.map(u => `<label class="flex items-center gap-2 px-3 py-2 cursor-pointer">
          <input type="checkbox" class="move-unit" value="${u.id}" data-code="${esc(u.unit_code)}" ${u.unit_code.toUpperCase() === pre || String(u.serial_number).toUpperCase() === pre ? 'checked' : ''}>
          <span class="font-mono font-bold">${esc(u.unit_code)}</span><span class="font-mono text-slate-500 truncate">S/N ${esc(u.serial_number)}</span>
          ${mode === 'return' ? `<span class="ml-auto text-orange-600 font-semibold">${esc(u.job_code || u.request_code)}</span>` : ''}</label>`).join('')
      : `<p class="px-3 py-3 text-slate-400">No units ${mode === 'issue' ? 'in stock' : 'out on jobs or orders'}.</p>`;
    document.querySelectorAll('.move-unit').forEach(cb => cb.addEventListener('change', syncMoveUnits));
    syncMoveUnits();
    if (pre && !list.some(u => u.unit_code.toUpperCase() === pre || String(u.serial_number).toUpperCase() === pre)) {
      errBox.textContent = `${preselectUnit} cannot be ${mode === 'issue' ? 'issued — it is not in stock' : 'returned — it is not out on a job'}.`;
      errBox.classList.remove('hidden');
    }
  }

  // Issue picks a client order or job; a product return picks the job it came
  // back from. Per-unit returns already know their job from the unit.
  if (mode === 'issue' || (mode === 'return' && !serial)) {
    const jobWrap = document.getElementById('move-job-wrap');
    const select = document.getElementById('move-job-select');
    jobWrap.classList.remove('hidden');
    select.innerHTML = '<option value="">Loading...</option>';

    const [jobs, orders] = await Promise.all([
      getJson('../api/jobs/active.php'),
      mode === 'issue' ? getJson('../api/material_requests/list.php?status=open') : Promise.resolve(null),
    ]);

    let html = '';
    if (orders && orders.success) {
      const open = orders.data.rows.filter(o => o.status !== 'READY' && o.lines.some(l =>
        Number(l.qty_prepared) < Number(l.qty_required) && (!categoryName || l.category_name === categoryName)));
      if (open.length) {
        html += '<optgroup label="Client orders that need this item">' + open.map(o => {
          const need = o.lines.filter(l => !categoryName || l.category_name === categoryName)
            .map(l => `${l.category_name} ${Math.min(l.qty_prepared, l.qty_required)}/${l.qty_required}`).join(', ');
          return `<option value="mr:${o.id}">${esc(o.request_code)} — ${esc(o.client_name)} (${esc(need)})</option>`;
        }).join('') + '</optgroup>';
      }
    }
    if (jobs.success && jobs.data.length) {
      html += '<optgroup label="Active jobs">' + jobs.data.map(j =>
        `<option value="job:${j.id}">${esc(j.job_code)} — ${esc(j.client_name)} (${esc(j.technician_name ?? 'unassigned')})</option>`).join('') + '</optgroup>';
    }
    select.innerHTML = html ? '<option value="">— Choose —</option>' + html : '<option value="">Nothing open to send this to</option>';
  }
  document.getElementById('move-confirm').disabled = false;
  if (serial && mode === 'receive') document.getElementById('move-serials').focus();
  else if (!serial) document.getElementById('move-qty').focus();
}
function pickedUnits() {
  return Array.from(document.querySelectorAll('.move-unit:checked')).map(cb => ({ id: Number(cb.value), code: cb.dataset.code }));
}
function syncMoveUnits() {
  const n = pickedUnits().length;
  document.getElementById('move-units-count').textContent = `(${n} selected)`;
}
function syncMoveSerials() {
  const n = serialList(document.getElementById('move-serials').value).length;
  document.getElementById('move-serials-count').textContent = `(${n} unit${n === 1 ? '' : 's'})`;
}
document.getElementById('move-serials').addEventListener('input', syncMoveSerials);
document.getElementById('move-cancel').addEventListener('click', () => document.getElementById('move-modal').classList.add('hidden'));

document.getElementById('move-confirm').addEventListener('click', (e) => {
  const errBox = document.getElementById('move-modal-error');
  errBox.classList.add('hidden');
  if (!MOVE) return;
  const fail = (msg) => { errBox.textContent = msg; errBox.classList.remove('hidden'); scanFeedback(false); };
  const invId = document.getElementById('move-inv-id').value;
  const qty = document.getElementById('move-qty').value;
  const target = document.getElementById('move-job-select').value; // "job:12" | "mr:3" | ""
  const serial = MOVE.tracking === 'SERIAL';
  const units = serial && moveMode !== 'receive' ? pickedUnits() : [];
  const serials = serial && moveMode === 'receive' ? serialList(document.getElementById('move-serials').value) : [];

  if ((moveMode === 'issue' || (moveMode === 'return' && !serial)) && !target) {
    return fail(moveMode === 'issue' ? 'Choose the client order or job this is going to.' : 'Please select a job.');
  }
  if (serial && moveMode !== 'receive' && !units.length) return fail('Tick at least one unit.');
  if (serial && moveMode === 'receive' && !serials.length) return fail('Enter the serial number of each unit received.');
  if (!serial && !(Number(qty) >= 1)) return fail('Quantity must be at least 1.');

  // Locked so a double tap cannot post the movement twice; the request key
  // makes the server ignore a repeat even if one slips through.
  withButtonLock(e.currentTarget, 'Saving…', async () => {
    let json, url;
    if (moveMode === 'issue' && target.startsWith('mr:')) {
      url = '../api/material_requests/pick.php';
      const requestId = Number(target.slice(3));
      if (serial) {
        // One scan per unit, exactly as the Prepare scanner does it.
        for (const u of units) {
          json = await postJson(url, { request_id: requestId, code: u.code });
          if (!json.success) break;
        }
      } else {
        json = await postJson(url, { request_id: requestId, inventory_id: Number(invId), quantity: Number(qty) });
      }
    } else {
      url = '../api/inventory/' + (moveMode === 'receive' ? 'receive.php' : moveMode === 'issue' ? 'issue.php' : 'return.php');
      const payload = { inventory_id: Number(invId), request_key: MOVE.requestKey };
      if (moveMode === 'receive') {
        payload.reference = document.getElementById('move-ref').value.trim();
        if (serial) payload.serials = serials; else payload.quantity = Number(qty);
      } else {
        if (serial) payload.unit_ids = units.map(u => u.id); else payload.quantity = Number(qty);
        if (target) payload.job_id = Number(target.replace(/^job:/, ''));
        if (moveMode === 'return') payload.condition = document.getElementById('move-condition').value;
      }
      json = await postJson(url, payload);
    }
    if (!json.success) { fail(json.message); return; }
    scanFeedback(true);
    toast(json.message, false);
    document.getElementById('move-modal').classList.add('hidden');
    INV_PICKER_CACHE = null;
    loadInventory();
    loadDashboard();
    if (url.includes('material_requests')) afterOrderChange(json.data.detail);
    const scanned = window.__scannedInvItem;
    if (scanned && String(scanned.id) === String(invId) && !document.getElementById('tab-scanner').classList.contains('hidden')) {
      lookupCode(scanned.code, true);
    }
  });
});

// --- History modal ---
const CONDITION_LABEL = { GOOD: 'Good', DAMAGED: 'Damaged', NEEDS_INSPECTION: 'Needs inspection' };
async function openHistoryModal(invId, itemName) {
  document.getElementById('history-modal-title').textContent = 'Stock History — ' + itemName;
  const list = document.getElementById('history-list');
  list.innerHTML = '<p class="text-slate-400 py-4">Loading...</p>';
  document.getElementById('history-modal').classList.remove('hidden');

  const json = await getJson('../api/inventory/movements.php?inventory_id=' + encodeURIComponent(invId));
  list.innerHTML = json.success && json.data.length
    ? json.data.map(m => `
      <div class="py-2.5 flex justify-between items-center gap-3">
        <div>
          <p class="font-semibold text-slate-900">${esc(m.movement_type)} — ${m.quantity} unit${Number(m.quantity) === 1 ? '' : 's'}${m.unit_code ? ` · <span class="font-mono">${esc(m.unit_code)}</span>` : ''}</p>
          <p class="text-xs text-slate-500">${m.reference ? esc(m.reference) : ''}${m.job_code ? ' · ' + esc(m.job_code) : ''}${m.request_code ? ' · ' + esc(m.request_code) : ''}${m.item_condition && m.item_condition !== 'GOOD' ? ' · <b class="text-amber-700">' + esc(CONDITION_LABEL[m.item_condition]) + '</b>' : ''}</p>
          <p class="text-[11px] text-slate-400 font-mono">${esc(m.movement_code)}${m.original_movement_code ? ' · reverses ' + esc(m.original_movement_code) : ''}</p>
        </div>
        <p class="text-xs text-slate-400 text-right whitespace-nowrap">${esc(m.created_at)}<br>${esc(m.recorded_by_name)}</p>
      </div>`).join('')
    : '<p class="text-slate-400 py-4">No movement history yet.</p>';
}
document.getElementById('history-close').addEventListener('click', () => document.getElementById('history-modal').classList.add('hidden'));

// --- QR Scanner ---
let qrScanner = null;
let qrIsRunning = false;
window.__scannedInvItem = null;

function hideQrResults() {
  document.getElementById('qr-result').classList.add('hidden');
  document.getElementById('qr-notfound').classList.add('hidden');
}

function stopQrScanner() {
  if (qrScanner && qrIsRunning) {
    qrIsRunning = false;
    qrScanner.stop().then(() => qrScanner.clear()).catch(() => {});
  }
  document.getElementById('qr-reader').classList.add('hidden');
  document.getElementById('qr-toggle-btn').innerHTML = '<i class="fas fa-camera mr-1"></i> Start Scanning';
}

async function startQrScanner() {
  const errBox = document.getElementById('qr-cam-error');
  errBox.classList.add('hidden');
  hideQrResults();
  document.getElementById('qr-reader').classList.remove('hidden');
  document.getElementById('qr-toggle-btn').innerHTML = '<i class="fas fa-stop mr-1"></i> Stop Scanning';

  try {
    if (!qrScanner) qrScanner = new Html5Qrcode('qr-reader');
    await qrScanner.start(
      { facingMode: 'environment' },
      { fps: 10, qrbox: { width: 240, height: 240 } },
      (decodedText) => onScanDecoded(decodedText),
      () => { /* per-frame decode miss — ignore, this fires constantly while aiming */ }
    );
    qrIsRunning = true;
  } catch (err) {
    document.getElementById('qr-reader').classList.add('hidden');
    document.getElementById('qr-toggle-btn').innerHTML = '<i class="fas fa-camera mr-1"></i> Start Scanning';
    // Name the actual cause. Over plain http:// the browser blocks the camera
    // outright and reports it as a permission failure, so the generic message
    // used to send clerks hunting through settings that were already correct.
    errBox.textContent = window.SunTrackMobile
      ? SunTrackMobile.describeCameraError(err)
      : 'Could not access the camera. You can still look up a code manually below.';
    errBox.classList.remove('hidden');
  }
}
document.getElementById('qr-toggle-btn').addEventListener('click', () => { qrIsRunning ? stopQrScanner() : startQrScanner(); });

document.getElementById('qr-manual-btn').addEventListener('click', (e) => {
  const input = document.getElementById('qr-manual-code');
  const code = input.value.trim();
  if (!code) return;
  withButtonLock(e.currentTarget, 'Working…', async () => {
    await handleCode(code);
    // In Prepare mode the clerk types code after code, so clear and refocus.
    if (SCAN_MODE === 'prepare') { input.value = ''; input.focus(); }
  });
});
document.getElementById('qr-manual-code').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') { e.preventDefault(); document.getElementById('qr-manual-btn').click(); }
});

/* ---------------------------------------------------------------------------
   Scan modes — tell the scanner what the clerk is doing, so one scan does the
   right thing instead of always showing a card and asking.
   --------------------------------------------------------------------------- */
const SCAN_MODES = {
  lookup:  { label: 'Look Up',       icon: 'fa-magnifying-glass', color: '#1e293b',
             hint: 'Look up — scan any code to see what it is. Nothing changes in stock.', hintCls: 'bg-slate-50 text-slate-600' },
  receive: { label: 'Restock (In)',  icon: 'fa-arrow-down-long', color: '#059669',
             hint: 'Restock — each item you scan is ADDED to stock (e.g. a supplier delivery). You confirm the quantity.', hintCls: 'bg-emerald-50 text-emerald-800' },
  issue:   { label: 'Stock Out',     icon: 'fa-arrow-up-long', color: '#ea580c',
             hint: 'Stock out — each item you scan is TAKEN OUT of stock for a client order or job. You choose where it goes.', hintCls: 'bg-orange-50 text-orange-800' },
  return:  { label: 'Return',        icon: 'fa-rotate-left', color: '#0284c7',
             hint: 'Return — each item you scan comes BACK into stock from a job.', hintCls: 'bg-sky-50 text-sky-800' },
  prepare: { label: 'Prepare Order', icon: 'fa-truck-ramp-box', color: '#7c3aed',
             hint: 'Prepare order — each scan takes 1 unit out of stock for the selected client order. Keep scanning; the camera stays on until the order is READY. Tip: scanning an order\'s slip code (MR-…) selects it.', hintCls: 'bg-violet-50 text-violet-800' },
};
let SCAN_MODE = 'lookup';
let PREPARE_ORDER_ID = null;

document.getElementById('scan-modes').innerHTML = Object.entries(SCAN_MODES).map(([key, m]) =>
  `<button type="button" class="scan-mode" data-scan-mode="${key}"><i class="fas ${m.icon}"></i>${m.label}</button>`).join('');
document.querySelectorAll('[data-scan-mode]').forEach(b => b.addEventListener('click', () => setScanMode(b.dataset.scanMode)));

async function setScanMode(mode, orderId) {
  if (!SCAN_MODES[mode]) mode = 'lookup';
  SCAN_MODE = mode;
  document.querySelectorAll('[data-scan-mode]').forEach(b => {
    const active = b.dataset.scanMode === mode;
    b.classList.toggle('active', active);
    b.style.background = active ? SCAN_MODES[b.dataset.scanMode].color : '';
  });
  const hint = document.getElementById('scan-mode-hint');
  hint.className = 'text-xs mt-3 rounded-lg px-3 py-2 ' + SCAN_MODES[mode].hintCls;
  hint.textContent = SCAN_MODES[mode].hint;
  document.getElementById('prepare-wrap').classList.toggle('hidden', mode !== 'prepare');
  document.getElementById('qr-manual-code').placeholder = mode === 'prepare' ? 'Scan or type an item SKU or unit code, e.g. ST-INV-9001' : 'SKU, QR code, unit code or serial no.';
  if (mode === 'prepare') await loadPrepareOrders(orderId);
}

async function loadPrepareOrders(selectId) {
  const select = document.getElementById('prepare-order-select');
  const json = await getJson('../api/material_requests/list.php?status=open');
  const rows = json.success ? json.data.rows : [];
  if (selectId) PREPARE_ORDER_ID = String(selectId);
  if (PREPARE_ORDER_ID && !rows.some(o => String(o.id) === PREPARE_ORDER_ID)) PREPARE_ORDER_ID = null;
  if (!PREPARE_ORDER_ID) {
    const firstToDo = rows.find(o => o.status !== 'READY');
    PREPARE_ORDER_ID = firstToDo ? String(firstToDo.id) : null;
  }
  select.innerHTML = rows.length
    ? rows.map(o => `<option value="${o.id}" ${String(o.id) === PREPARE_ORDER_ID ? 'selected' : ''}>${esc(o.request_code)} — ${esc(o.client_name)} (${o.qty_prepared}/${o.qty_required}) ${o.status === 'READY' ? '✓ READY' : ''}</option>`).join('')
    : '<option value="">No open client orders</option>';
  await refreshPrepare();
}
document.getElementById('prepare-order-select').addEventListener('change', (e) => {
  PREPARE_ORDER_ID = e.target.value || null;
  refreshPrepare();
});

async function refreshPrepare() {
  const box = document.getElementById('prepare-progress');
  if (!PREPARE_ORDER_ID) { box.innerHTML = '<p class="text-xs text-slate-400">Nothing to prepare. New orders from Management will appear here.</p>'; return; }
  const json = await getJson('../api/material_requests/get.php?id=' + encodeURIComponent(PREPARE_ORDER_ID));
  if (json.success) renderPrepareProgress(json.data);
}

function renderPrepareProgress(d) {
  const r = d.request;
  const box = document.getElementById('prepare-progress');
  box.innerHTML = `
    <div class="rounded-xl border border-slate-200 p-3">
      <div class="flex items-center justify-between gap-2 mb-2">
        <div><p class="font-bold text-slate-900">${esc(r.client_name)}</p>
          <p class="text-[11px] text-slate-400">${esc(r.request_code)}${r.needed_by ? ' · needed by ' + esc(r.needed_by) : ''}</p></div>
        ${orderBadge(r.status)}
      </div>
      ${orderLinesHtml(d.lines)}
      ${r.status === 'READY'
        ? '<p class="text-xs font-bold text-emerald-700 mt-2"><i class="fas fa-circle-check mr-1"></i>Everything is prepared. Open the order to release it.</p>'
        : ''}
      <button type="button" class="text-xs font-bold text-suntrackOrange hover:underline mt-2" data-prep-open="${r.id}">Open order details</button>
    </div>`;
  box.querySelector('[data-prep-open]').addEventListener('click', () => openOrder(r.id));
  // Keep the dropdown's "x/y" in step without refetching the list.
  const opt = document.querySelector(`#prepare-order-select option[value="${r.id}"]`);
  if (opt) {
    const req = d.lines.reduce((s, l) => s + Number(l.qty_required), 0);
    const prep = d.lines.reduce((s, l) => s + Math.min(Number(l.qty_prepared), Number(l.qty_required)), 0);
    opt.textContent = `${r.request_code} — ${r.client_name} (${prep}/${req}) ${r.status === 'READY' ? '✓ READY' : ''}`;
  }
}

// Continuous scanning in Prepare mode: the camera pauses while a scan is being
// saved and ignores the same code for a moment, so holding one box under the
// camera cannot count it several times.
let scanBusy = false, lastScan = { code: '', at: 0 };

async function onScanDecoded(code) {
  const continuous = SCAN_MODE === 'prepare' && !code.startsWith('MR-');
  if (!continuous) { stopQrScanner(); handleCode(code); return; }

  if (scanBusy || (code === lastScan.code && Date.now() - lastScan.at < 2500)) return;
  scanBusy = true;
  lastScan = { code, at: Date.now() };
  try { qrScanner.pause(true); } catch (e) {}
  const json = await handleCode(code);
  const done = json && json.success && json.data.status === 'READY';
  setTimeout(() => {
    scanBusy = false;
    if (done) { stopQrScanner(); return; }  // order complete — nothing left to scan
    try { if (qrIsRunning) qrScanner.resume(); } catch (e) {}
  }, 1200);
}

/** One code, whatever mode we are in. Returns the pick response in Prepare mode. */
async function handleCode(code) {
  code = String(code).trim();
  if (!code) return null;

  // An order slip always selects that order, from any mode.
  if (code.startsWith('MR-')) { await lookupCode(code); return null; }

  if (SCAN_MODE === 'prepare') {
    if (!PREPARE_ORDER_ID) { toast('Choose a client order to prepare first.', true); scanFeedback(false); return null; }
    hideQrResults();
    return pickIntoOrder(Number(PREPARE_ORDER_ID), { code });
  }
  await lookupCode(code);
  return null;
}

/**
 * Look a code up and show its card. $refreshOnly re-renders the card (e.g.
 * fresh quantity after a movement) without firing the mode's action again.
 */
async function lookupCode(code, refreshOnly) {
  hideQrResults();
  document.getElementById('qr-loading').classList.remove('hidden');
  const json = await getJson('../api/scan/lookup.php?code=' + encodeURIComponent(code));
  document.getElementById('qr-loading').classList.add('hidden');
  if (!json.success || !json.data.found) {
    const box = document.getElementById('qr-notfound');
    box.innerHTML = '<i class="fas fa-circle-exclamation text-amber-400 text-xl mb-2 block"></i>'
      + `<p class="font-semibold text-slate-700">${esc(json.data && json.data.code ? json.data.code : code)}</p>`
      + `<p class="mt-1">${esc(json.message || 'No matching record for that code.')}</p>`;
    box.classList.remove('hidden');
    if (!refreshOnly) scanFeedback(false);
    return;
  }
  const result = json.data.result;
  renderQrResult(result);
  if (refreshOnly) return;

  if (result.module === 'material_requests') {
    goToTab('scanner');
    await setScanMode('prepare', result.id);
    toast(`${result.record_id} selected — scan its items now.`, false);
    return;
  }
  // Restock / Stock Out / Return go straight to the quantity step.
  if (result.module === 'inventory' && ['receive', 'issue', 'return'].includes(SCAN_MODE)) {
    const block = scanBlocker(result, SCAN_MODE);
    if (block) { toast(block, true); scanFeedback(false); return; }
    scanFeedback(true);
    openMoveModal(SCAN_MODE, result.id, result.name, result.category, result.unit ? result.unit.code : null);
  }
}

/** Why this scanned item cannot take this action right now, or null. The server re-checks all of it. */
function scanBlocker(result, mode) {
  if (!result.can_write) return 'View only — your role cannot move stock.';
  const u = result.unit;
  if (!u) return null;
  if (u.status === 'WRITTEN_OFF') return `${u.code} was written off and is no longer active.`;
  if (mode === 'receive') return `${u.code} is already registered. To add new units, scan the product label (${result.sku}).`;
  if (mode === 'issue' && u.status !== 'IN_STOCK') return `${u.code} is ${u.status === 'ISSUED' ? 'already issued' : 'in quarantine'} and cannot be issued.`;
  if (mode === 'return' && u.status !== 'ISSUED') return `${u.code} is not out on a job, so it cannot be returned.`;
  return null;
}

function renderQrResult(result) {
  const box = document.getElementById('qr-result');
  // Field values come from the database — escape them, never trust them as HTML.
  const rows = Object.entries(result.fields).map(([label, value]) =>
    `<div class="flex justify-between gap-3 py-1.5 border-b border-slate-50 last:border-0"><span class="text-slate-500">${esc(label)}</span><span class="font-semibold text-slate-900 text-right">${esc(value)}</span></div>`
  ).join('');

  window.__scannedInvItem = null;
  let actionsHtml = '';
  const inStockMode = ['receive', 'issue', 'return', 'prepare'].includes(SCAN_MODE);

  if (result.module === 'inventory' && result.id) {
    window.__scannedInvItem = { id: result.id, name: result.name, code: result.record_id, category: result.category, unit: result.unit ? result.unit.code : null };
    // Only the actions that can succeed for this item / unit right now.
    const acts = [
      ['receive', 'Restock', 'fa-arrow-down-long', 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700'],
      ['issue', 'Stock Out', 'fa-arrow-up-long', 'bg-orange-50 hover:bg-orange-100 text-orange-700'],
      ['return', 'Return', 'fa-rotate-left', 'bg-sky-50 hover:bg-sky-100 text-sky-700'],
    ].filter(a => !scanBlocker(result, a[0]));
    const notes = [];
    if (!result.can_write) notes.push('View only — your role can look items up but not move stock.');
    if (result.item_status === 'DISCONTINUED') notes.push('This product is discontinued (inactive). Check before issuing it.');
    if (result.unit && result.unit.status === 'QUARANTINE') notes.push('This unit is in quarantine. Open QR / Label to pass or write it off after inspection.');
    if (result.unit && result.unit.status === 'WRITTEN_OFF') notes.push('This unit was written off and is no longer active.');
    if (!result.unit && result.tracking === 'SERIAL') notes.push('Tracked per unit — Stock Out and Return let you tick the units, or scan a unit label directly.');
    actionsHtml = `
      ${notes.map(n => `<p class="mt-3 text-xs text-amber-800 bg-amber-50 rounded-lg px-3 py-2"><i class="fas fa-circle-info mr-1"></i>${esc(n)}</p>`).join('')}
      <div class="grid grid-cols-${acts.length + 1} gap-2 mt-4 pt-4 border-t border-slate-100">
        ${acts.map(a => `<button id="qr-act-${a[0]}" class="${a[3]} text-xs font-bold py-2.5 rounded-lg"><i class="fas ${a[2]} block mb-1"></i>${a[1]}</button>`).join('')}
        <button id="qr-act-label" class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold py-2.5 rounded-lg"><i class="fas fa-qrcode block mb-1"></i>QR / Label</button>
      </div>`;
  } else if (result.module === 'material_requests' && result.id) {
    actionsHtml = `<button id="qr-act-order" class="w-full mt-4 bg-violet-600 hover:bg-violet-700 text-white text-sm font-bold py-2.5 rounded-lg"><i class="fas fa-truck-ramp-box mr-1"></i>Open order</button>`;
  } else if (inStockMode) {
    actionsHtml = `<p class="mt-3 text-xs text-amber-700 bg-amber-50 rounded-lg px-3 py-2"><i class="fas fa-triangle-exclamation mr-1"></i>This is a ${esc(result.type)}, not a stock item, so nothing was moved.</p>`;
  }

  box.innerHTML = `
    <div class="flex items-center justify-between mb-2">
      <span class="badge bg-slate-100 text-slate-600">${esc(result.type)}</span>
      <span class="text-[11px] text-slate-400">Scanned just now</span>
    </div>
    <div class="text-sm">${rows}</div>
    ${actionsHtml}`;
  box.classList.remove('hidden');

  const it = window.__scannedInvItem;
  if (it) {
    ['receive', 'issue', 'return'].forEach(mode => document.getElementById('qr-act-' + mode)
      ?.addEventListener('click', () => openMoveModal(mode, it.id, it.name, it.category, it.unit)));
    document.getElementById('qr-act-label').addEventListener('click', () => openQrPanel(it.id));
  }
  document.getElementById('qr-act-order')?.addEventListener('click', () => openOrder(result.id));
}

setScanMode('lookup');

loadDashboard();
loadDashOrders();

// ---------------------------------------------------------------------------
// Real-time stock
//
// Stock is the one thing in SunTrack that several people move at once: a clerk
// receives a delivery while a technician is issued parts for a job and another
// clerk processes a return. A stale quantity on this screen is how an item
// gets issued twice. The heartbeat below reloads the figures whenever the
// inventory or stock_movements tables change, whoever changed them.
// ---------------------------------------------------------------------------

function setLiveState(ok, label) {
  const dot = document.getElementById('live-dot');
  const text = document.getElementById('live-text');
  const box = document.getElementById('live-indicator');
  if (!dot || !text || !box) return;
  box.className = 'inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-full '
    + (ok ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700');
  dot.className = 'h-2 w-2 rounded-full ' + (ok ? 'bg-emerald-500' : 'bg-amber-500');
  text.textContent = label;
}

function flashLive() {
  setLiveState(true, 'Updated');
  clearTimeout(window.__liveFlash);
  window.__liveFlash = setTimeout(() => setLiveState(true, 'Live'), 2500);
}

// Keep the low-stock / out-of-stock badges honest on every poll, even when no
// table fingerprint moved (an item edited elsewhere still counts).
function applyStockCounters(counters) {
  if (!counters || !counters.inventory) return;
  const c = counters.inventory;
  const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
  set('kpi-live-low', c.low_stock);
  set('kpi-live-out', c.out_of_stock);
}

// Badges for new client orders and unread notifications. A new order raised by
// Management bumps both, so the clerk sees it without opening anything.
let lastUnread = null;
function applyBadges(counters) {
  if (!counters) return;
  setBadge('orders-badge', counters.open_material_requests);
  const unread = counters.unread_notifications;
  if (typeof unread === 'number') {
    setBadge('notif-badge', unread);
    if (lastUnread !== null && unread > lastUnread && CURRENT_TAB === 'notifications') loadNotifications();
    lastUnread = unread;
  }
}

SunTrackRealtime.start({
  endpoint: '../api/realtime/sync.php',
  channels: ['inventory', 'stock_movements', 'jobs', 'material_requests'],
  on: {
    ready: (versions, counters) => applyBadges(counters),
    counters: (counters) => { applyStockCounters(counters); applyBadges(counters); },
    '*': (changed) => {
      flashLive();
      // The dashboard totals depend on both stock tables, so refresh them for
      // any change; the inventory table only when it is the visible tab.
      loadDashboard();
      if (CURRENT_TAB === 'inventory') loadInventory();
      if (CURRENT_TAB === 'warehouse') loadWarehouse();

      // Orders move when Management creates/cancels one or another clerk scans.
      if (changed.includes('material_requests') || changed.includes('stock_movements')) {
        INV_PICKER_CACHE = null;
        loadDashOrders();
        if (CURRENT_TAB === 'orders') loadOrders();
        refreshOpenOrder();
        if (CURRENT_TAB === 'scanner' && SCAN_MODE === 'prepare' && !scanBusy) loadPrepareOrders();
      }
    },
    error: () => setLiveState(false, 'Reconnecting'),
    sessionExpired: () => { window.location.href = '<?= APP_BASE_URL ?>/login.php?expired=1'; },
  }
});
</script>

<?php include ROOT_PATH . '/includes/consent_banner.php'; ?>
</body>
</html>
