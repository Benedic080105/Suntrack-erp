<?php
/**
 * Printable QR labels for one inventory item.
 *
 *   ?id=N                    the item (required)
 *   &layout=thermal|sheet    thermal: one 50 x 30 mm label per page (label printers)
 *                            sheet:   A4, 3 x 7 labels of 63.5 x 38.1 mm (Avery L7160 / J8160)
 *   &copies=N                product label copies (1–200)
 *   &units=in_stock|1,2,3    serialized units instead of the product label
 *   &print=1                 open the print dialog once drawn
 *
 * Open to every role allowed in the warehouse portal (printing changes
 * nothing). Labels carry identifiers and descriptions only.
 */
require_once __DIR__ . '/../middleware/warehouse.php';

$id = (int)($_GET['id'] ?? 0);
$payload = inv_qr_ready() && $id > 0 ? inv_item_payload(db(), $id) : null;
if (!$payload) {
    http_response_code(404);
    die('Inventory item not found.');
}
$item = $payload['item'];
$layout = ($_GET['layout'] ?? 'thermal') === 'sheet' ? 'sheet' : 'thermal';
$copies = max(1, min(200, (int)($_GET['copies'] ?? 1)));

$labels = [];
$unitsParam = trim((string)($_GET['units'] ?? ''));
if ($unitsParam !== '') {
    $wanted = $unitsParam === 'in_stock' ? null : array_map('intval', explode(',', $unitsParam));
    foreach ($payload['units'] as $u) {
        $match = $wanted === null ? $u['status'] === 'IN_STOCK' : in_array((int)$u['id'], $wanted, true);
        if ($match) {
            $labels[] = ['title' => $item['item_name'], 'sku' => $item['sku'], 'code' => $u['unit_code'],
                         'serial' => $u['serial_number'], 'kind' => 'unit'];
        }
    }
} elseif ($item['qr_code']) {
    for ($i = 0; $i < $copies; $i++) {
        $labels[] = ['title' => $item['item_name'], 'sku' => $item['sku'], 'code' => $item['qr_code'],
                     'serial' => $item['serial_number'] ?: null, 'kind' => 'product'];
    }
}
$autoPrint = !empty($_GET['print']) && $labels;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>QR Labels — <?= htmlspecialchars($item['sku']) ?></title>
<script src="<?= APP_BASE_URL ?>/assets/vendor/qrcode/qrcode.min.js"></script>
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-qrlabel.js"></script>
<style>
  * { box-sizing: border-box; }
  body { margin: 0; font-family: Arial, Helvetica, sans-serif; color: #000; background: #e2e8f0; }
  .toolbar { position: sticky; top: 0; display: flex; flex-wrap: wrap; gap: 8px; align-items: center; padding: 10px 16px; background: #0b1329; color: #fff; font-size: 13px; z-index: 2; }
  .toolbar b { margin-right: auto; }
  .toolbar a, .toolbar button { color: #fff; background: #1e293b; border: 0; border-radius: 8px; padding: 7px 12px; font-size: 13px; font-weight: 700; text-decoration: none; cursor: pointer; }
  .toolbar button.primary { background: #f97316; }
  .hint { font-size: 12px; color: #475569; padding: 8px 16px; }
  .pages { padding: 16px; display: flex; flex-direction: column; align-items: center; gap: 16px; }

  /* One label: QR on the left, text on the right. Sizes in mm so print is exact. */
  .label { background: #fff; display: flex; gap: 2mm; padding: 2mm; overflow: hidden; }
  .label .qr { height: 100%; aspect-ratio: 1 / 1; flex: none; }
  .label .qr svg { width: 100%; height: 100%; display: block; }
  .label .info { flex: 1; min-width: 0; display: flex; flex-direction: column; }
  .label .brand { font-weight: 700; font-size: 6.5pt; display: flex; align-items: center; gap: 1mm; letter-spacing: .02em; }
  .label .brand i { width: 2.4mm; height: 2.4mm; border-radius: 50%; background: #000; display: inline-block; }
  .label .name { font-weight: 700; font-size: 7pt; line-height: 1.15; margin-top: 1mm; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
  .label .sku { font-family: "Courier New", monospace; font-weight: 700; font-size: 8pt; margin-top: 1mm; white-space: nowrap; }
  .label .serial { font-size: 6.5pt; margin-top: .5mm; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .label .code { font-family: "Courier New", monospace; font-weight: 700; font-size: 6.5pt; margin-top: auto; white-space: nowrap; }

  .thermal .label { width: 50mm; height: 30mm; box-shadow: 0 1px 4px rgba(0,0,0,.2); }
  .sheet .page { width: 210mm; height: 297mm; background: #fff; padding: 15.15mm 7.25mm; display: grid;
                 grid-template-columns: repeat(3, 63.5mm); grid-auto-rows: 38.1mm; column-gap: 2.5mm; box-shadow: 0 1px 4px rgba(0,0,0,.2); }
  .sheet .label { width: 63.5mm; height: 38.1mm; padding: 3mm; outline: 1px dashed #cbd5e1; }
  .sheet .label .name { font-size: 8pt; }
  .sheet .label .sku { font-size: 9pt; }

  @media print {
    body { background: #fff; }
    .toolbar, .hint { display: none; }
    .pages { padding: 0; gap: 0; display: block; }
    .thermal .label { box-shadow: none; page-break-after: always; break-after: page; }
    .sheet .page { box-shadow: none; page-break-after: always; break-after: page; }
    .sheet .label { outline: 0; }
  }
  @page { margin: 0; size: <?= $layout === 'sheet' ? 'A4' : '50mm 30mm' ?>; }
</style>
</head>
<body>
<div class="toolbar">
  <b><?= htmlspecialchars($item['item_name']) ?> · <?= count($labels) ?> label<?= count($labels) === 1 ? '' : 's' ?></b>
  <a href="?<?= htmlspecialchars(http_build_query(array_merge($_GET, ['layout' => 'thermal', 'print' => null]))) ?>">Thermal 50×30 mm</a>
  <a href="?<?= htmlspecialchars(http_build_query(array_merge($_GET, ['layout' => 'sheet', 'print' => null]))) ?>">A4 sheet</a>
  <button type="button" class="primary" onclick="window.print()">Print</button>
</div>
<p class="hint">Print at <b>100% / Actual size</b> (turn off "Fit to page"). Thermal printers: set the paper to 50 × 30 mm. Scan one label with your phone before sticking the batch.</p>
<div id="pages" class="pages <?= $layout ?>"></div>
<?php if (!$labels): ?>
<p class="hint" style="text-align:center">Nothing to print — <?= $unitsParam !== '' ? 'no matching units.' : 'this item has no QR code yet. Generate one from its QR panel first.' ?></p>
<?php endif; ?>
<script>
const LABELS = <?= json_encode($labels, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
const LAYOUT = <?= json_encode($layout) ?>;
function e(v) { return String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function labelHtml(l) {
  return '<div class="label"><div class="qr">' + SunTrackQR.svg(l.code, { margin: 2 }) + '</div><div class="info">'
    + '<div class="brand"><i></i>SunTrack</div>'
    + '<div class="name">' + e(l.title) + '</div>'
    + '<div class="sku">' + e(l.sku) + '</div>'
    + (l.serial ? '<div class="serial">' + (l.kind === 'unit' ? 'S/N ' : 'Lot ') + e(l.serial) + '</div>' : '')
    + '<div class="code">' + e(l.code) + '</div></div></div>';
}
const root = document.getElementById('pages');
if (LAYOUT === 'sheet') {
  for (let i = 0; i < LABELS.length; i += 21) {
    root.insertAdjacentHTML('beforeend', '<div class="page">' + LABELS.slice(i, i + 21).map(labelHtml).join('') + '</div>');
  }
} else {
  root.innerHTML = LABELS.map(labelHtml).join('');
}
<?php if ($autoPrint): ?>
window.addEventListener('load', () => setTimeout(() => window.print(), 300));
<?php endif; ?>
</script>
</body>
</html>
