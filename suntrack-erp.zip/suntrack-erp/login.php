<?php
require_once __DIR__ . '/config/config.php';

// Already logged in? Send straight to their portal.
if (is_logged_in()) {
    header('Location: ' . redirect_path_for_role(current_role()));
    exit;
}

$token = csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SunTrack ERP — Login</title>
<script src="<?= APP_BASE_URL ?>/assets/vendor/tailwind/tailwind.js"></script>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/vendor/fontawesome/css/all.min.css">
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-password.js"></script>
<link href="<?= APP_BASE_URL ?>/assets/vendor/inter/inter.css" rel="stylesheet">
<link rel="manifest" href="<?= APP_BASE_URL ?>/manifest.json">
<meta name="theme-color" content="#0b1329">
<link rel="apple-touch-icon" href="<?= APP_BASE_URL ?>/assets/img/app/apple-touch-icon.png">
<script src="<?= APP_BASE_URL ?>/assets/js/suntrack-pwa.js"></script>
<script>
  tailwind.config = {
    theme: { extend: {
      colors: { suntrackDark: '#0b1329', suntrackNav: '#0f1934', suntrackOrange: '#f97316' },
      fontFamily: { sans: ['Inter','sans-serif'] }
    }}
  }
</script>
<style>body{font-family:'Inter',sans-serif;}</style>
</head>
<body class="bg-suntrackDark min-h-screen flex items-center justify-center p-4">

  <div class="w-full max-w-md">
    <div class="text-center mb-8">
      <div class="inline-flex items-center justify-center h-14 w-14 rounded-2xl bg-suntrackOrange shadow-lg shadow-orange-600/30 mb-4">
        <i class="fas fa-solar-panel text-white text-2xl"></i>
      </div>
      <h1 class="text-2xl font-extrabold text-white">SunTrack ERP</h1>
      <p class="text-slate-400 text-sm mt-1">NCO Technology Solutions</p>
    </div>

    <div class="bg-suntrackNav border border-slate-800/60 rounded-2xl p-8 shadow-xl">
      <h2 class="text-lg font-bold text-white mb-1">Sign in</h2>
      <p class="text-slate-400 text-sm mb-6">Use your SunTrack account credentials.</p>

      <div id="login-error" class="hidden bg-red-500/10 border border-red-500/30 text-red-400 text-sm rounded-xl px-4 py-3 mb-4"></div>

      <form id="login-form" class="space-y-4">
        <div>
          <label class="block text-slate-300 text-sm font-semibold mb-1.5">Email</label>
          <input type="email" id="email" name="email" required autocomplete="username"
                 class="w-full rounded-xl bg-slate-900/60 border border-slate-700 text-white text-sm px-4 py-3 focus:outline-none focus:ring-2 focus:ring-suntrackOrange placeholder-slate-500"
                 placeholder="you@suntrack.test">
        </div>
        <div>
          <label class="block text-slate-300 text-sm font-semibold mb-1.5">Password</label>
          <input type="password" id="password" name="password" required autocomplete="current-password"
                 class="w-full rounded-xl bg-slate-900/60 border border-slate-700 text-white text-sm px-4 py-3 focus:outline-none focus:ring-2 focus:ring-suntrackOrange placeholder-slate-500"
                 placeholder="••••••••">
          <div class="text-right mt-1.5">
            <a href="forgot_password.php" class="text-xs font-semibold text-suntrackOrange hover:underline">Forgot password?</a>
          </div>
        </div>
        <button type="submit" id="login-btn"
                class="w-full bg-suntrackOrange hover:bg-orange-600 text-white font-bold text-sm py-3 rounded-xl shadow-lg shadow-orange-600/20 transition">
          Sign In
        </button>
      </form>

      <!-- Two-step login: shown after a correct password for staff who turned it on. -->
      <form id="twofa-form" class="hidden space-y-4">
        <p class="text-slate-300 text-sm"><i class="fas fa-shield-halved text-suntrackOrange mr-1"></i>
          Enter the 6-digit code from your authenticator app.</p>
        <input type="text" id="twofa-code" inputmode="numeric" autocomplete="one-time-code" maxlength="9"
               class="w-full rounded-xl bg-slate-900/60 border border-slate-700 text-white text-lg tracking-[0.4em] text-center px-4 py-3 focus:outline-none focus:ring-2 focus:ring-suntrackOrange"
               placeholder="123456">
        <button type="submit" id="twofa-btn"
                class="w-full bg-suntrackOrange hover:bg-orange-600 text-white font-bold text-sm py-3 rounded-xl shadow-lg shadow-orange-600/20 transition">
          Verify
        </button>
        <p class="text-slate-500 text-xs">Lost your phone? Type one of your backup codes (like <span class="font-mono">k7p2-9xqm</span>) instead.
          <a href="login.php" class="text-suntrackOrange font-semibold hover:underline ml-1">Start over</a></p>
      </form>

      <p class="text-center text-slate-500 text-xs mt-6">
        New client? <a href="register.php" class="text-suntrackOrange font-semibold hover:underline">Create an account</a>
      </p>
    </div>

    <p class="text-center text-slate-600 text-xs mt-6">&copy; <?= date('Y') ?> NCO Technology Solutions</p>
  </div>

<script>
const CSRF_TOKEN = <?= json_encode($token) ?>;

document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = document.getElementById('login-btn');
  const errBox = document.getElementById('login-error');
  errBox.classList.add('hidden');
  btn.disabled = true;
  btn.textContent = 'Signing in...';

  try {
    const res = await fetch('api/auth/login.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: document.getElementById('email').value.trim(),
        password: document.getElementById('password').value,
        csrf_token: CSRF_TOKEN
      })
    });
    const data = await res.json();

    if (!data.success) {
      errBox.textContent = data.message || 'Login failed.';
      errBox.classList.remove('hidden');
      btn.disabled = false;
      btn.textContent = 'Sign In';
      return;
    }

    if (data.data && data.data.requires_2fa) {
      // Password was right; now the authenticator code.
      document.getElementById('login-form').classList.add('hidden');
      document.getElementById('twofa-form').classList.remove('hidden');
      document.getElementById('twofa-code').focus();
      return;
    }

    window.location.href = data.data.redirect;
  } catch (err) {
    errBox.textContent = 'Network error. Please try again.';
    errBox.classList.remove('hidden');
    btn.disabled = false;
    btn.textContent = 'Sign In';
  }
});

document.getElementById('twofa-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = document.getElementById('twofa-btn');
  const errBox = document.getElementById('login-error');
  errBox.classList.add('hidden');
  btn.disabled = true;
  btn.textContent = 'Checking...';
  try {
    const res = await fetch('api/auth/verify_2fa.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: document.getElementById('twofa-code').value.trim(), csrf_token: CSRF_TOKEN })
    });
    const data = await res.json();
    if (data.success) { window.location.href = data.data.redirect; return; }
    errBox.textContent = data.message || 'That code is not right.';
    errBox.classList.remove('hidden');
    if (data.data && data.data.restart) {
      // Expired or too many tries: back to the password step.
      document.getElementById('twofa-form').classList.add('hidden');
      document.getElementById('login-form').classList.remove('hidden');
      document.getElementById('login-btn').disabled = false;
      document.getElementById('login-btn').textContent = 'Sign In';
    }
  } catch (err) {
    errBox.textContent = 'Network error. Please try again.';
    errBox.classList.remove('hidden');
  }
  document.getElementById('twofa-code').value = '';
  btn.disabled = false;
  btn.textContent = 'Verify';
});
</script>

<?php include ROOT_PATH . '/includes/consent_banner.php'; ?>
</body>
</html>
