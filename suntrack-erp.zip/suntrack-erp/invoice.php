<?php
/**
 * Printable invoice — /invoice.php?id=N
 *
 * An A4 invoice page. "Download PDF" uses the browser's own Save-as-PDF
 * (works on phones and laptops, and prints ₱ and Filipino names correctly,
 * which a bare PDF library's built-in fonts cannot). ?print=1 opens the print
 * dialog straight away.
 *
 * Who may open it: Management and Admin (any invoice), and the client the
 * invoice belongs to. Everyone else gets 404, so invoice numbers cannot be
 * probed.
 */
require_once __DIR__ . '/config/config.php';
require_login(false);

$role = current_role();
$id = (int)($_GET['id'] ?? 0);
$pdo = db();

$stmt = $pdo->prepare(
    "SELECT i.*, c.client_code, c.address, c.city, c.province, u.full_name AS client_name, u.email AS client_email,
            u.phone AS client_phone, p.project_code, p.site_name, p.capacity_kw
     FROM invoices i
     JOIN clients c ON c.id = i.client_id
     JOIN users u ON u.id = c.user_id
     LEFT JOIN projects p ON p.id = i.project_id
     WHERE i.id = :id"
);
$stmt->execute([':id' => $id]);
$inv = $stmt->fetch();

$allowed = $inv && (in_array($role, ['admin', 'manager', 'staff'], true)
    || ($role === 'client' && (int)$inv['client_id'] === (int)current_profile_id()));
if (!$allowed) {
    http_response_code(404);
    die('Invoice not found.');
}

// Voided payments are corrections, not money received: left off the invoice.
$pay = $pdo->prepare('SELECT amount, payment_method, reference, paid_at FROM payments p WHERE invoice_id = :i AND ' . billing_valid_payment('p') . ' ORDER BY paid_at, id');
$pay->execute([':i' => $id]);
$payments = $pay->fetchAll();
$paid = array_sum(array_map(fn($p) => (float)$p['amount'], $payments));
$balance = max(0, (float)$inv['amount'] - $paid);

$company = [
    'name'    => setting('company_name', 'SunTrack Solar'),
    'address' => setting('company_address', ''),
    'phone'   => setting('company_phone', ''),
    'email'   => setting('company_email', ''),
    'tin'     => setting('company_tin', ''),
];
// An invoice raised for a released material request carries its own lines
// (frozen at release). Otherwise, show the project's installed materials.
$lines = invoice_lines((int)$inv['id']);
$materials = $lines
    ? ['items' => [], 'total' => 0, 'count' => 0]
    : ($inv['project_id'] ? project_material_costs((int)$inv['project_id']) : ['items' => [], 'total' => 0, 'count' => 0]);
$peso = fn($n) => '₱' . number_format((float)$n, 2);
$date = fn($d) => $d ? date('F j, Y', strtotime($d)) : '—';
$description = trim(($inv['project_code'] ? 'Solar project ' . $inv['project_code'] . ($inv['site_name'] ? ' — ' . $inv['site_name'] : '') : 'Solar services')
    . ($inv['capacity_kw'] ? ' (' . rtrim(rtrim((string)$inv['capacity_kw'], '0'), '.') . ' kW)' : ''));
$statusColor = ['PAID' => '#059669', 'OVERDUE' => '#dc2626', 'CANCELLED' => '#64748b', 'PENDING' => '#d97706'][$inv['payment_status']] ?? '#334155';
$back = ['client' => 'client/', 'admin' => 'admin/'][$role] ?? 'management/';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Invoice <?= h($inv['invoice_code']) ?> — <?= h($company['name']) ?></title>
<link rel="stylesheet" href="<?= APP_BASE_URL ?>/assets/vendor/inter/inter.css">
<style>
  * { box-sizing: border-box; }
  body { margin: 0; background: #f1f5f9; font-family: 'Inter', Arial, sans-serif; color: #0f172a; }
  .bar { max-width: 820px; margin: 16px auto 0; padding: 0 16px; display: flex; gap: 8px; justify-content: flex-end; flex-wrap: wrap; }
  .bar a, .bar button { font: 600 14px 'Inter', Arial, sans-serif; padding: 10px 16px; border-radius: 10px; border: 1px solid #cbd5e1; background: #fff; color: #334155; text-decoration: none; cursor: pointer; }
  .bar button.primary { background: #f97316; border-color: #f97316; color: #fff; }
  .sheet { max-width: 820px; margin: 12px auto 32px; background: #fff; padding: 40px; border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,.08); }
  .row { display: flex; justify-content: space-between; gap: 24px; flex-wrap: wrap; }
  h1 { margin: 0; font-size: 28px; letter-spacing: 1px; }
  .muted { color: #64748b; font-size: 13px; line-height: 1.55; }
  .label { font-size: 11px; font-weight: 700; text-transform: uppercase; color: #94a3b8; letter-spacing: .5px; margin-bottom: 4px; }
  .status { display: inline-block; font-weight: 700; font-size: 12px; padding: 4px 10px; border-radius: 999px; border: 2px solid <?= $statusColor ?>; color: <?= $statusColor ?>; }
  table { width: 100%; border-collapse: collapse; margin-top: 28px; font-size: 14px; }
  th { text-align: left; font-size: 11px; text-transform: uppercase; color: #64748b; border-bottom: 2px solid #0f172a; padding: 8px 6px; }
  td { padding: 12px 6px; border-bottom: 1px solid #e2e8f0; vertical-align: top; }
  .num { text-align: right; white-space: nowrap; }
  .totals { margin-left: auto; width: 300px; max-width: 100%; margin-top: 16px; font-size: 14px; }
  .totals div { display: flex; justify-content: space-between; padding: 6px 0; }
  .totals .grand { border-top: 2px solid #0f172a; font-weight: 800; font-size: 17px; padding-top: 10px; }
  .foot { margin-top: 36px; padding-top: 16px; border-top: 1px solid #e2e8f0; }
  @media (max-width: 600px) { .sheet { padding: 22px; } h1 { font-size: 22px; } }
  @page { size: A4; margin: 14mm; }
  @media print {
    body { background: #fff; }
    .bar { display: none; }
    .sheet { box-shadow: none; margin: 0; padding: 0; max-width: none; border-radius: 0; }
  }
</style>
</head>
<body>
  <div class="bar">
    <a href="<?= APP_BASE_URL ?>/<?= $back ?>">&larr; Back</a>
    <button type="button" class="primary" onclick="window.print()">Download PDF / Print</button>
  </div>

  <div class="sheet">
    <div class="row">
      <div>
        <div style="font-size:20px;font-weight:800;color:#f97316"><?= h($company['name']) ?></div>
        <div class="muted">
          <?php foreach (['address', 'phone', 'email'] as $k): if ($company[$k] !== ''): ?><?= h($company[$k]) ?><br><?php endif; endforeach; ?>
          <?php if ($company['tin'] !== ''): ?>TIN: <?= h($company['tin']) ?><?php endif; ?>
        </div>
      </div>
      <div style="text-align:right">
        <h1>INVOICE</h1>
        <div style="font-weight:700;margin:4px 0 8px"><?= h($inv['invoice_code']) ?></div>
        <span class="status"><?= h($inv['payment_status']) ?></span>
      </div>
    </div>

    <div class="row" style="margin-top:32px">
      <div>
        <div class="label">Bill to</div>
        <div style="font-weight:700"><?= h($inv['client_name']) ?> <span class="muted">(<?= h($inv['client_code']) ?>)</span></div>
        <div class="muted">
          <?= h(implode(', ', array_filter([$inv['address'], $inv['city'], $inv['province']]))) ?><br>
          <?= h($inv['client_email']) ?><?= $inv['client_phone'] ? ' · ' . h($inv['client_phone']) : '' ?>
        </div>
      </div>
      <div class="muted" style="text-align:right">
        <div><span class="label" style="display:inline">Issued</span> <?= h($date($inv['created_at'])) ?></div>
        <div><span class="label" style="display:inline">Due</span> <?= h($date($inv['due_date'])) ?></div>
        <?php if ($inv['payment_date']): ?><div><span class="label" style="display:inline">Paid</span> <?= h($date($inv['payment_date'])) ?></div><?php endif; ?>
      </div>
    </div>

    <?php if ($lines): ?>
    <div class="muted" style="margin-top:24px"><strong style="color:#0f172a"><?= h($description) ?></strong><?= $inv['notes'] ? ' — ' . h($inv['notes']) : '' ?></div>
    <table style="margin-top:8px">
      <thead><tr><th>Item</th><th>Category</th><th class="num">Qty</th><th class="num">Unit price</th><th class="num">Amount</th></tr></thead>
      <tbody>
        <?php foreach ($lines as $l): ?>
        <tr>
          <td><div style="font-weight:600"><?= h($l['item_name']) ?></div>
            <div class="muted"><?= h($l['sku'] ?? '') ?><?= $l['model'] ? ' · ' . h($l['model']) : '' ?></div></td>
          <td><?= h($l['category'] ?? '') ?></td>
          <td class="num"><?= (int)$l['quantity'] ?></td>
          <td class="num"><?= h($peso($l['unit_price'])) ?></td>
          <td class="num"><?= h($peso($l['line_total'])) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?>
    <table>
      <thead><tr><th>Description</th><th class="num">Amount</th></tr></thead>
      <tbody>
        <tr>
          <td><div style="font-weight:600"><?= h($description) ?></div>
            <?php if ($inv['notes']): ?><div class="muted"><?= h($inv['notes']) ?></div><?php endif; ?></td>
          <td class="num"><?= h($peso($inv['amount'])) ?></td>
        </tr>
      </tbody>
    </table>
    <?php endif; ?>

    <?php if ($materials['items']): ?>
    <div class="label" style="margin-top:28px">Materials used for this installation</div>
    <table style="margin-top:6px">
      <thead><tr><th>Item</th><th>Category</th><th class="num">Qty</th><th class="num">Unit price</th><th class="num">Amount</th></tr></thead>
      <tbody>
        <?php foreach ($materials['items'] as $m): ?>
        <tr>
          <td><div style="font-weight:600"><?= h($m['item_name']) ?></div>
            <div class="muted"><?= h($m['sku']) ?><?= $m['model'] ? ' · ' . h($m['model']) : '' ?></div></td>
          <td><?= h($m['category']) ?></td>
          <td class="num"><?= (int)$m['quantity'] ?></td>
          <td class="num"><?= h($peso($m['unit_price'])) ?></td>
          <td class="num"><?= h($peso($m['line_total'])) ?></td>
        </tr>
        <?php endforeach; ?>
        <tr>
          <td colspan="4" class="num" style="font-weight:700">Total materials (<?= (int)$materials['count'] ?> item<?= $materials['count'] === 1 ? '' : 's' ?>)</td>
          <td class="num" style="font-weight:800"><?= h($peso($materials['total'])) ?></td>
        </tr>
      </tbody>
    </table>
    <?php endif; ?>

    <div class="totals">
      <div><span>Total</span><span><?= h($peso($inv['amount'])) ?></span></div>
      <div><span>Paid</span><span><?= h($peso($paid)) ?></span></div>
      <div class="grand"><span><?= $inv['payment_status'] === 'CANCELLED' ? 'Cancelled' : 'Balance due' ?></span><span><?= h($peso($inv['payment_status'] === 'CANCELLED' ? 0 : $balance)) ?></span></div>
    </div>

    <?php if ($payments): ?>
    <table>
      <thead><tr><th>Payment date</th><th>Method</th><th>Reference</th><th class="num">Amount</th></tr></thead>
      <tbody>
        <?php foreach ($payments as $p): ?>
        <tr><td><?= h($date($p['paid_at'])) ?></td><td><?= h($p['payment_method'] ?: '—') ?></td><td><?= h($p['reference'] ?: '—') ?></td><td class="num"><?= h($peso($p['amount'])) ?></td></tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>

    <div class="foot muted">
      Thank you for choosing <?= h($company['name']) ?>. Please quote <b><?= h($inv['invoice_code']) ?></b> when paying.
      This invoice was generated by SunTrack ERP on <?= h(date('F j, Y')) ?>.
    </div>
  </div>
<?php if (!empty($_GET['print'])): ?>
<script>window.addEventListener('load', () => setTimeout(() => window.print(), 300));</script>
<?php endif; ?>
</body>
</html>
