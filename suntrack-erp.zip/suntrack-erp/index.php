<?php
require_once __DIR__ . '/config/config.php';

if (is_logged_in()) {
    header('Location: ' . redirect_path_for_role(current_role()));
} else {
    header('Location: ' . APP_BASE_URL . '/login.php');
}
exit;
